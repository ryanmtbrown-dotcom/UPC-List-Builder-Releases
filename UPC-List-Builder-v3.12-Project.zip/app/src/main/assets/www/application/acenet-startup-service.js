/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/application/acenet-startup-service.js
 * Owner: Application Startup / AceNet Runtime State Boundary
 * Role: Startup/runtime state service
 * Responsibility: Owns web-side AceNet startup invocation, accepts registered native startup/health callbacks, and projects authoritative native state into the shared web AceNet runtime state.
 * Does not own: Native credential/session mechanics; service-health classification; item extraction; normal lookup; Settings feature policy; diagnostics persistence.
 * Side effects: Calls the injected native startup capability, updates the injected shared runtime state, resolves the startup handoff, refreshes AceNet UI policy, and emits observational diagnostics.
 * Related code: Native startup/session authority belongs to AceNetSessionManager/Coordinator; callback registration belongs to Bridge Registration; feature policy belongs to Settings Controller; overall boot sequencing belongs to StartupOrchestrator.
 */
const UPCAceNetStartupService=(()=>{
 function create({
  diagnostic,nativeBridgeProvider,getRuntimeState,normalizeHealthStatus,
  refreshLoginStatus,reconcileAutomaticPricing,syncFeatureUi,reportStartupProgress
 }={}){
  if(typeof diagnostic!=='function'||typeof nativeBridgeProvider!=='function'||typeof getRuntimeState!=='function')throw new Error('AceNet Startup Service platform/state dependencies are incomplete.');
  if(typeof normalizeHealthStatus!=='function'||typeof refreshLoginStatus!=='function'||typeof reconcileAutomaticPricing!=='function'||typeof syncFeatureUi!=='function'||typeof reportStartupProgress!=='function')throw new Error('AceNet Startup Service policy dependencies are incomplete.');
  const diag=diagnostic;
  let startupResolver=null;

  function parseNativePayload(raw,event){
   try{return typeof raw==='string'?JSON.parse(raw):raw||{}}
   catch(e){diag(event+'_parse_failed',{message:e?.message||String(e)});return null}
  }
  function applyNativeState(payload,{startup=false}={}){
   const state=getRuntimeState();
   if(startup&&payload.status!=null)state.startupStatus=String(payload.status||'').toUpperCase()||state.startupStatus;
   if(typeof payload.authenticated==='boolean')state.authenticated=payload.authenticated;
   const healthSource=startup?payload.healthStatus:payload.status;
   if(healthSource!=null){
    const health=normalizeHealthStatus(healthSource);
    if(health)state.healthStatus=health;
   }
   if(Number.isFinite(Number(payload.consecutiveEmptyBodies)))state.consecutiveEmptyBodies=Number(payload.consecutiveEmptyBodies);
   if(Number.isFinite(Number(payload.consecutivePriceFailures)))state.consecutivePriceFailures=Number(payload.consecutivePriceFailures);
   if(payload.reason!=null)state.reason=String(payload.reason||'');
   if(payload.message!=null)state.message=String(payload.message||'');
   return state;
  }
  function resolveStartupIfTerminal(payload){
   if(payload?.startupResolved!==true||!startupResolver)return false;
   const resolve=startupResolver;startupResolver=null;resolve(payload);return true;
  }
  function acceptNativeStartupStatus(raw){
   const payload=parseNativePayload(raw,'acenet_startup_status_callback');if(!payload)return null;
   const state=applyNativeState(payload,{startup:true});
   diag('acenet_startup_status_callback',{
    status:state.startupStatus,authenticated:state.authenticated===true,healthStatus:state.healthStatus,
    startupResolved:payload.startupResolved===true,startupPhase:payload.startupPhase||null,progress:Number.isFinite(Number(payload.progress))?Number(payload.progress):null
   });
   reportStartupProgress(payload);
   refreshLoginStatus();reconcileAutomaticPricing('native_startup_status_callback');
   resolveStartupIfTerminal(payload);
   return payload;
  }
  function acceptNativeHealthStatus(raw){
   const payload=parseNativePayload(raw,'acenet_health_status_callback');if(!payload)return null;
   const state=applyNativeState(payload);
   diag('acenet_health_status_callback',{
    healthStatus:state.healthStatus,authenticated:state.authenticated===true,reason:state.reason||null,
    consecutiveEmptyBodies:state.consecutiveEmptyBodies,consecutivePriceFailures:state.consecutivePriceFailures
   });
   reconcileAutomaticPricing('native_health_status_callback');
   return payload;
  }
  async function run(){
   const state=getRuntimeState(),bridge=nativeBridgeProvider(),canBegin=typeof bridge?.beginAceNetStartup==='function';
   try{
    let waitForTerminal=null;
    if(canBegin){
     waitForTerminal=new Promise(resolve=>{startupResolver=resolve});
     bridge.beginAceNetStartup();
    }
    let status={};try{status=JSON.parse(bridge?.getAceNetLoginStatus?.()||'{}')}catch{}
    diag('acenet_startup_status_initial_read',{startupResolved:status.startupResolved===true,authenticated:status.authenticated===true,healthStatus:status.healthStatus||null});
    if(!canBegin){
     startupResolver=null;
     state.startupStatus='UNAVAILABLE';state.healthStatus='UNAVAILABLE';state.message='AceNet native service is unavailable in this runtime. Library-only pricing is active.';refreshLoginStatus();
    }else if(status.startupResolved!==true){
     await waitForTerminal;
    }else{
     startupResolver=null;
    }
    try{status=JSON.parse(bridge?.getAceNetLoginStatus?.()||'{}')}catch{status={}}
    state.authenticated=status.authenticated===true;
    if(status.healthStatus!=null){const health=normalizeHealthStatus(status.healthStatus);if(health)state.healthStatus=health}
    if(status.startupResolved===true&&!['SIGNED_IN','UNAVAILABLE','OFFLINE','UNVERIFIED'].includes(String(state.startupStatus||'')))state.startupStatus=state.authenticated?'SIGNED_IN':'UNAVAILABLE';
    reconcileAutomaticPricing('startup_final_snapshot');syncFeatureUi();
    const authenticated=state.authenticated===true,health=normalizeHealthStatus(state.healthStatus),ready=authenticated&&health==='ONLINE',knownUnavailable=health==='DOWN'||health==='UNAVAILABLE';
    if(!ready&&!knownUnavailable)throw new Error('AceNet startup terminated without a conclusive service-health state');
    return{ready,knownUnavailable,authenticated,healthStatus:health,status:state.startupStatus||null,message:ready?'AceNet sign-in and retained-worker verification completed.':'AceNet status is known unavailable for live comparison; library-only pricing is active.'};
   }catch(e){
    startupResolver=null;
    state.startupStatus='UNAVAILABLE';state.healthStatus='UNAVAILABLE';state.message='AceNet startup status could not be established. Library-only pricing is active.';refreshLoginStatus();
    diag('acenet_startup_boundary_failed',{message:e?.message||String(e)});
    return{ready:false,knownUnavailable:true,authenticated:state.authenticated===true,healthStatus:'UNAVAILABLE',status:state.startupStatus||'UNAVAILABLE',message:state.message,error:e?.message||String(e)};
   }
  }
  return Object.freeze({run,acceptNativeStartupStatus,acceptNativeHealthStatus});
 }
 return Object.freeze({create});
})();
window.UPCAceNetStartupService=UPCAceNetStartupService;
