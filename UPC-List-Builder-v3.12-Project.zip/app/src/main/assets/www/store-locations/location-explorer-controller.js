/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/store-locations/location-explorer-controller.js
 * Owner: Store Locations / Planogram Explorer Presentation
 * Role: Workspace controller
 * Responsibility: Owns focused item browsing, explicit correction review, display choice and start-from-scan creation wizard.
 * Does not own: Product pricing authority, full layout drafts, raw location storage, scanner hardware or Work Sessions.
 * Side effects: Manipulates Explorer DOM, invokes injected domain services and established app navigation/scanner UI.
 * Related code: location-explorer-service.js, location-explorer-edit-service.js, location-work-controller.js.
 */
const UPCLocationExplorerController=(()=>{
 'use strict';
 function create({repository,read,edit,policy,elementById,documentRef,showScreen,goBack,startScanner,
  normalizeUPC,normalizeSKU,confirmUser,workController,idFactory,productImageService,priceService,comparisonEnabled}={}){
  if(!repository||!read||!edit||!policy||!elementById||!documentRef||!showScreen||!goBack||!workController)throw Error('Explorer UI dependencies missing');
  const $=elementById,doc=documentRef;let model=null,index=0,identity=null,pending=null,undo=null,busy=false,token=0,insertScanning=false;
  const el=(tag,className='',content='')=>{const e=doc.createElement(tag);if(className)e.className=className;if(content!=null)e.textContent=String(content);return e};
  const text=(id,value)=>{$(id).textContent=String(value??'')};
  const show=(id,visible)=>$(id).classList.toggle('hidden',!visible);
  const status=(message,kind='info')=>{text('locationExplorerStatus',message||'');$('locationExplorerStatus').dataset.kind=kind};
  function active(){return !$('locationExplorerScreen').classList.contains('hidden')}
  async function guard(fn){if(busy)return;busy=true;try{await fn()}catch(e){status(e?.message||String(e),'error')}finally{busy=false}}
  function resetViews(){$('locationExplorerScreen').classList.remove('has-display');show('locationExplorerChoices',false);show('locationExplorerMissing',false);show('locationExplorerWizard',false);show('locationExplorerDisplay',false);show('locationExplorerEditMenu',false);show('locationExplorerEdit',false);show('locationExplorerReview',false)}
  async function open(){showScreen('locationExplorerScreen','Planogram Explorer');resetViews();model=null;pending=null;undo=null;identity=null;index=0;insertScanning=false;
   $('locationExplorerLookup').value='';$('locationExplorerInputMode').value='AUTO';status('Scan an item or enter a UPC/SKU to find its display.');}
  const current=()=>model?.items?.[index]||null;
  function locate(identity,rows){return rows.findIndex(p=>policy.same(p,identity))}
  const currency=value=>{const n=UPCPriceAuthority.money(value);return n===null?'—':'$'+n};
  function setImage(imageId,emptyId,url=null){
   const img=$(imageId),empty=$(emptyId);
   if(url){img.src=url;img.classList.remove('hidden');empty.classList.add('hidden')}
   else{img.removeAttribute('src');img.classList.add('hidden');empty.classList.remove('hidden')}
  }
  function enrich(details,imageId,emptyId,priceId,generation){
   const item=details?.product,valid=details?.catalogFound&&item?.status==='FOUND';
   setImage(imageId,emptyId);
   text(priceId,!valid?'—':typeof comparisonEnabled==='function'&&!comparisonEnabled()?'Disabled':'Checking…');
   if(!valid)return;
   if(productImageService?.lookupProductImage)void productImageService.lookupProductImage(item).then(result=>{
    if(generation!==token)return;
    const url=String(result?.url||'');
    if(url.startsWith('https://')||url.startsWith('data:image/')){setImage(imageId,emptyId,url);$(imageId).alt='Product image for '+details.description}
    else $(emptyId).textContent='Image unavailable';
   }).catch(()=>{if(generation===token)$(emptyId).textContent='Image unavailable'});
   if(typeof comparisonEnabled!=='function'||!comparisonEnabled()||!item.sku||!priceService?.requestPrice)return;
   void priceService.requestPrice(normalizeSKU(item.sku),{upcEnrichment:false}).then(result=>{
    if(generation!==token)return;
    const verified=result?.status==='VERIFIED'&&normalizeSKU(result.sku)===normalizeSKU(item.sku)&&Number.isFinite(result.price);
    text(priceId,verified?currency(result.price):'Unavailable');
   }).catch(()=>{if(generation===token)text(priceId,'Unavailable')});
  }
  async function search(value,type='AUTO',format=null){
   const generation=++token;model=null;identity=await read.resolveIdentity(value,type,format);pending=null;undo=null;
   const choices=await read.candidates(identity);if(generation!==token)return;resetViews();
   if(!choices.length){
    const details=await read.details(identity);if(generation!==token)return;
    show('locationExplorerMissing',true);
    text('locationExplorerMissingItem',identity.skuKey?'SKU '+identity.skuKey:'UPC '+(identity.upcKey||'—'));
    text('locationExplorerMissingDescription',details.description);
    text('locationExplorerMissingSku',details.sku);text('locationExplorerMissingUpc',details.upc);
    text('locationExplorerMissingRetail',currency(details.retail));
    enrich(details,'locationExplorerMissingImage','locationExplorerMissingImageEmpty','locationExplorerMissingAceNet',generation);
    status('No current planogram or confirmed store layout includes this item.','warning');return;
   }
   if(choices.length===1){await choose(choices[0].modularId);return}
   const host=$('locationExplorerChoicesList');host.replaceChildren();
   for(const choice of choices){const button=el('button','locationExplorerChoice',choice.area+' · '+choice.name+' · '+(choice.physical?'Store-confirmed':'Ace source'));
    button.type='button';button.addEventListener('click',()=>void guard(()=>choose(choice.modularId)));host.append(button)}
   show('locationExplorerChoices',true);status('Multiple locations match. Choose the display you are standing at.');
  }
  async function choose(modularId,mode=null,focusIdentity=identity){
   model=await read.display(modularId,mode);const desired=locate(focusIdentity,model.items);
   if(desired>=0)index=desired;else if(model.mode==='STORE'&&locate(focusIdentity,model.ace)>=0){model=await read.display(modularId,'ACE');index=locate(focusIdentity,model.items)}
   else index=0;
   pending=null;resetViews();$('locationExplorerScreen').classList.add('has-display');show('locationExplorerDisplay',true);status('');await render();
  }
  async function render(){
   if(!model)return;
   const generation=++token,item=current(),items=model.items;
   const sections=model.modular.physicalSectionIds||[];
   const feet=model.mode==='ACE'?Number(model.source?.nominalWidthFt):sections.length*4;
   text('locationExplorerTitle',model.modular.name);
   text('locationExplorerArea',model.area.name||('Aisle '+(model.area.aisle||model.area.id)));
   text('locationExplorerSpan',model.mode==='ACE'?(model.source?.nominalFourFootSections?model.source.nominalFourFootSections+' × 4-foot Ace bays':'Official Ace source'):(sections.length?sections.length+' × 4-foot physical sections':'Custom fixture'));
   text('locationExplorerFootage',Number.isFinite(feet)&&feet>0?feet+' ft':'Footage unavailable');
   const store=$('locationExplorerStoreMode'),ace=$('locationExplorerAceMode');
   store.disabled=!model.store.length;ace.disabled=!model.ace.length;
   store.classList.toggle('active',model.mode==='STORE');ace.classList.toggle('active',model.mode==='ACE');
   text('locationExplorerEvidence',model.mode==='STORE'?'Saved physical layout · confirmed locations':'Official Ace source · not physically verified');
   text('locationExplorerCount',items.length?'Item '+(index+1)+' of '+items.length:'No merchandise positions');
   text('locationExplorerSection',item?(item.sourceOnly?'Ace source sequence · shelf / peg unverified':item.physicalSectionId?'Section '+item.physicalSectionId+' · '+(item.fixtureType==='SHELF'?'Shelf ':'Row ')+(item.rowOrdinal??'not recorded'):'Physical display · precise position not recorded'):'No current position');
   text('locationExplorerLocationHeading',item?.sourceOnly?'Ace planogram placement':'Confirmed store placement');
   text('locationExplorerLocationSummary',item?(item.sourceOnly?'Assigned to '+model.modular.name+' · not physically verified':(model.area.name||'Aisle '+model.area.aisle)+' · '+policy.position(item)):'No position');
   text('locationExplorerLocationWarning',item?.sourceOnly?'Source order is not verified physical left-to-right shelf order.':'This location is recorded in the saved physical layout.');
   text('locationExplorerSourceCoordinates',item?.sourceOnly?'Imported source coordinates (not shelf or peg positions): '+policy.position(item):'');
   $('locationExplorerPrevious').disabled=index===0;$('locationExplorerNext').disabled=index>=items.length-1;
   $('locationExplorerUndo').disabled=!undo;
   const prev=items[index-1],next=items[index+1];
   text('locationExplorerPreviousHint',prev?(prev.skuKey?'SKU '+prev.skuKey:'Previous item'):'Start of display');
   text('locationExplorerNextHint',next?(next.skuKey?'SKU '+next.skuKey:'Next item'):'End of display');
   text('locationExplorerItemName',item?'Loading merchandise details…':'No items in this view');
   for(const id of ['locationExplorerSku','locationExplorerUpc','locationExplorerRetail','locationExplorerAceNetRetail','locationExplorerOrderMultiple','locationExplorerRetailUnits'])text(id,'—');
   setImage('locationExplorerImage','locationExplorerImageEmpty');$('locationExplorerImageEmpty').textContent='No image';
   show('locationExplorerEditButton',!!item&&!item.sourceOnly);show('locationExplorerConfirmPosition',!!item&&!!item.sourceOnly);
   const jump=$('locationExplorerSelectItem');jump.replaceChildren();
   items.forEach((position,i)=>{const option=el('option','',(i+1)+'. '+(position.skuKey?'SKU '+position.skuKey:'UPC '+(position.upcKey||'—'))+(position.sourceOnly?' · Ace source':' · '+policy.position(position)));option.value=String(i);jump.append(option)});
   jump.value=String(index);
   if(!item)return;
   const details=await read.details(item);if(generation!==token)return;
   text('locationExplorerItemName',details.description);
   text('locationExplorerSku',details.sku);text('locationExplorerUpc',details.upc);
   text('locationExplorerRetail',currency(details.retail));
   text('locationExplorerOrderMultiple',details.orderMultiple??'—');
   text('locationExplorerRetailUnits',details.retailUnits??'—');
   enrich(details,'locationExplorerImage','locationExplorerImageEmpty','locationExplorerAceNetRetail',generation);
  }
  async function mode(name){if(!model)return;const previous=current(),focus=previous?.skuKey||previous?.upcKey;
   model=await read.display(model.modular.id,name);index=Math.max(0,model.items.findIndex(p=>p.skuKey===focus||p.upcKey===focus));await render();}
  async function step(amount){if(!model)return;index=Math.max(0,Math.min(model.items.length-1,index+amount));await render();}
  function editForm(action='FACINGS'){const p=current();if(!p||p.sourceOnly)return;insertScanning=false;pending=null;show('locationExplorerReview',false);show('locationExplorerEditMenu',false);show('locationExplorerEdit',true);
   const section=$('locationExplorerEditSection');section.replaceChildren();
   for(const s of model.modular.physicalSectionIds||[]){const option=el('option','','SEC '+s);option.value=String(s);section.append(option)}
   if(!section.options.length){const o=el('option','','Custom fixture');o.value='';section.append(o)}
   section.value=p.physicalSectionId||section.options[0].value;
   $('locationExplorerEditRow').value=String(p.rowOrdinal||1);$('locationExplorerEditFacing').value=String(p.facings||1);
   $('locationExplorerEditIdentifier').value='';$('locationExplorerEditIdType').value='UPC';$('locationExplorerEditAction').value=action;
   const target=$('locationExplorerAnchor');target.replaceChildren();
   for(const o of model.store.filter(x=>x.id!==p.id)){const opt=el('option','',((o.skuKey?'SKU '+o.skuKey:'UPC '+o.upcKey))+' · '+policy.position(o));opt.value=o.id;target.append(opt)}
   syncEdit();status('Review a proposed correction. Nothing changes until you confirm.');}
  function openEditMenu(){if(!current()||current().sourceOnly)return;show('locationExplorerEditMenu',true);show('locationExplorerEdit',false);show('locationExplorerReview',false)}
  function syncEdit(){const action=$('locationExplorerEditAction').value;
   show('locationExplorerEditInsert',action.startsWith('INSERT_'));
   show('locationExplorerEditTarget',action==='MOVE_TO');
   show('locationExplorerEditAnchor',action==='MOVE_BEFORE'||action==='MOVE_AFTER');
   show('locationExplorerEditFacings',action==='FACINGS');
   $('locationExplorerPrepare').textContent=action==='REMOVE'?'Review Removal':'Preview Correction';
  }
  async function prepare(){const p=current(),action=$('locationExplorerEditAction').value;if(!p)return;
   const args={targetId:p.id};
   if(action==='FACINGS')args.facings=Number($('locationExplorerEditFacing').value);
   if(action==='MOVE_TO'){args.section=$('locationExplorerEditSection').value||null;args.row=Number($('locationExplorerEditRow').value)}
   if(action==='MOVE_BEFORE'||action==='MOVE_AFTER')args.anchorId=$('locationExplorerAnchor').value;
   if(action.startsWith('INSERT_')){
    const type=$('locationExplorerEditIdType').value,entered=$('locationExplorerEditIdentifier').value;
    args.identity=await read.resolveIdentity(type==='UPC'?normalizeUPC(entered):normalizeSKU(entered),type);
    const facts=args.identity.skuKey?await repository.bySku(args.identity.skuKey):await repository.byUpc(args.identity.upcKey);
    const activeDisplays=await repository.listModulars(),activeIds=new Set(activeDisplays.filter(m=>m.active!==false).map(m=>m.id));
    const already=(facts.placements||[]).some(x=>x.physicalEvidence===true&&activeIds.has(x.modularId)&&policy.same(x,args.identity));
    args.identity.role=already?'SECONDARY':'HOME';
    args.identity.storeAdded=!model.sourceMembers.some(m=>policy.same(m,args.identity));
   }
   pending=await edit.prepare(model.modular.id,action,args);
   const host=$('locationExplorerReviewText');host.replaceChildren();
   host.append(el('strong','',action.replace(/_/g,' ')),el('p','',`Affected: ${pending.changed.length} positions updated, ${pending.removed.length} removed.`));
   host.append(el('p','','Before: '+policy.position(p)));
   const after=pending.placements.find(x=>x.id===pending.focusId);
   host.append(el('p','','After: '+(after?policy.position(after):'Placement removed from this display')));
   if(action.startsWith('INSERT_')&&args.identity.role==='SECONDARY')host.append(el('p','locationExplorerWarning','This item has another stocked location. Separate placement confirmation is required.'));
   if(pending.requiresSecondary.length)host.append(el('p','locationExplorerWarning',pending.requiresSecondary.length+' affected secondary positions require separate approval.'));
   show('locationExplorerReview',true);status('Check the before/after summary, then confirm or cancel.');
  }
  async function commit(){if(!pending)return;
   const before=pending,selected=current(),approved=[];
   if(before.action==='REMOVE'&&!await confirmUser('Remove this one accepted physical placement? The official Ace planogram and product catalog remain unchanged.','Remove Placement',{okLabel:'Remove'}))return;
   for(const p of before.requiresSecondary){
    if(!await confirmUser('Approve this separate stocking position for '+(p.skuKey?'SKU '+p.skuKey:'UPC '+p.upcKey)+' at '+policy.position(p)+'?','Confirm Secondary Location')){
     status('Secondary location confirmation declined. No changes were saved.','warning');return}
    approved.push(p.id);
   }
   const result=await edit.commit(before,approved);undo=result.undo;const focus=result.focusId;pending=null;insertScanning=false;
   model=await read.display(model.modular.id,'STORE');index=Math.max(0,model.items.findIndex(p=>p.id===focus));
   show('locationExplorerEdit',false);show('locationExplorerReview',false);await render();status('Confirmed physical correction saved. Other displays and official Ace source were preserved.');
  }
  async function undoLast(){if(!undo)return;const previous=undo;
   if(!await confirmUser('Undo the most recent Explorer correction? Other changes made since then will block this action.','Undo Correction'))return;
   await edit.undo(previous);undo=null;model=await read.display(model.modular.id,'STORE');index=Math.min(index,Math.max(0,model.items.length-1));await render();status('Last Explorer correction reversed.');}
  async function confirmSourcePosition(){const p=current();if(!p||!p.sourceOnly)return;identity={skuKey:p.skuKey,upcKey:p.upcKey};await wizard(true);}
  async function wizard(fromSource=false){resetViews();show('locationExplorerWizard',true);const mods=(await repository.listModulars()).filter(m=>m.active!==false);
   const choices=$('locationExplorerWizardExisting');choices.replaceChildren();const def=el('option','','Create a new display');def.value='';choices.append(def);
   const preferred=fromSource?model?.modular.id:null;
   for(const m of mods){const opt=el('option','',m.name+' · '+(m.physicalSectionIds?.length?(m.physicalSectionIds.length*4)+' feet':'Custom fixture'));opt.value=m.id;choices.append(opt)}
   choices.value=preferred||'';$('locationExplorerWizardNew').classList.toggle('hidden',!!preferred);
   $('locationExplorerWizardAreaType').value='AISLE';$('locationExplorerWizardAisle').value='';$('locationExplorerWizardDisplay').value='';
   $('locationExplorerWizardStartSection').value='1';$('locationExplorerWizardEndSection').value='1';
   text('locationExplorerWizardItem',identity?.skuKey?'SKU '+identity.skuKey:'UPC '+(identity?.upcKey||'—'));
   await updateWizardSection();
   status('Choose an existing display or create a new physical location. The first item will carry into the existing layout builder.');
  }
  async function startWizard(){if(!identity)throw Error('Scan an item before creating a physical layout');
   if(await workController.hasUnfinishedDraft?.())throw Error('An unfinished physical layout draft exists. Resume or discard it before starting a different display.');
   let id=$('locationExplorerWizardExisting').value,section=null;
   if(!id){
    const areaType=$('locationExplorerWizardAreaType').value,aisle=$('locationExplorerWizardAisle').value.trim(),name=$('locationExplorerWizardDisplay').value.trim();
    if(!name||name.length>100)throw Error('Enter a display name (up to 100 characters)');
    const areas=await repository.listAreas(),mods=await repository.listModulars();let area,sections=[];
    if(areaType==='AISLE'){
     if(!/^\d{1,3}[A-Za-z]?$/.test(aisle))throw Error('Enter a valid aisle number');
     const start=Number($('locationExplorerWizardStartSection').value),end=Number($('locationExplorerWizardEndSection').value);
     if(!Number.isSafeInteger(start)||!Number.isSafeInteger(end)||start<1||end<start||end-start>=25)throw Error('Select a real four-foot section range (up to 25 sections)');
     sections=Array.from({length:end-start+1},(_,i)=>String(start+i));
     area=areas.find(a=>a.active!==false&&a.kind==='AISLE'&&String(a.aisle)===aisle);
     if(!area)area={id:'area:'+idFactory(),kind:'AISLE',aisle,name:'Aisle '+aisle,active:true};
     const collision=mods.find(m=>m.active!==false&&m.area?.kind==='AISLE'&&m.area?.aisle===aisle&&sections.some(s=>m.physicalSectionIds?.includes(s)));
     if(collision)throw Error('Those sections already belong to '+collision.name+'. Choose the existing display or a different section.');
    }else{
     const label=$('locationExplorerWizardCustom').value.trim();if(!label||label.length>100)throw Error('Name the custom area');
     area=areas.find(a=>a.active!==false&&a.kind==='CUSTOM'&&a.name?.toLowerCase()===label.toLowerCase());
     if(!area)area={id:'area:'+idFactory(),kind:'CUSTOM',name:label,active:true};
    }
    if(!areas.some(a=>a.id===area.id))await repository.saveArea(area);
    id='explorer-display:'+idFactory();
    await repository.saveModular({id,name,area:{kind:area.kind,id:area.id,...(area.kind==='AISLE'?{aisle:area.aisle}:{name:area.name})},physicalSectionIds:sections,
     fixtureId:area.kind==='CUSTOM'?'fixture:'+id:null,active:true});section=sections[0]||null;
   }else{
    const m=await repository.getModular(id);if(!m||m.active===false)throw Error('The selected display is no longer active');
    const s=$('locationExplorerWizardSection').value.trim();section=m.physicalSectionIds?.includes(s)?s:m.physicalSectionIds?.[0]||null;
   }
   showScreen('locationScreen','Planograms & Locations');$('locationLayoutTab').click();
   await workController.beginFromExplorer({modularId:id,section,identity});
   status('Layout builder opened with your original scanned item.');
  }
  async function updateWizardSection(){const id=$('locationExplorerWizardExisting').value;show('locationExplorerWizardNew',!id);
   const area=$('locationExplorerWizardSectionArea');show('locationExplorerWizardSectionArea',!!id);if(!id)return;
   const m=await repository.getModular(id);const s=$('locationExplorerWizardSection');s.replaceChildren();
   for(const section of m?.physicalSectionIds||[]){const o=el('option','','SEC '+section);o.value=section;s.append(o)}
   if(!s.options.length){const o=el('option','','Custom fixture');o.value='';s.append(o)}
  }
  async function onAcceptedScan({upc,format=null}={}){
   if(!active())return false;
   if(insertScanning&& !$('locationExplorerEdit').classList.contains('hidden')){
    $('locationExplorerEditIdType').value='UPC';$('locationExplorerEditIdentifier').value=normalizeUPC(upc);insertScanning=false;
    status('Scanned insertion UPC. Preview the correction to continue.');return true;
   }
   $('locationExplorerInputMode').value='UPC';$('locationExplorerLookup').value=upc;await guard(()=>search(normalizeUPC(upc),'UPC',format));return true;
  }
  function bind(){
   $('locationExploreOpen').addEventListener('click',()=>void guard(open));
   $('locationExplorerFind').addEventListener('click',()=>void guard(()=>search($('locationExplorerLookup').value,$('locationExplorerInputMode').value)));
   $('locationExplorerLookup').addEventListener('keydown',e=>{if(e.key==='Enter')void guard(()=>search(e.target.value,$('locationExplorerInputMode').value))});
   $('locationExplorerScan').addEventListener('click',()=>startScanner());$('locationExplorerPrevious').addEventListener('click',()=>void guard(()=>step(-1)));
   $('locationExplorerNext').addEventListener('click',()=>void guard(()=>step(1)));$('locationExplorerStoreMode').addEventListener('click',()=>void guard(()=>mode('STORE')));
   $('locationExplorerAceMode').addEventListener('click',()=>void guard(()=>mode('ACE')));
   $('locationExplorerSelectItem').addEventListener('change',e=>void guard(async()=>{index=Number(e.target.value);await render()}));
   $('locationExplorerEditButton').addEventListener('click',openEditMenu);
   $('locationExplorerEditMenuCancel').addEventListener('click',()=>show('locationExplorerEditMenu',false));
   doc.querySelectorAll('#locationExplorerEditMenu [data-explorer-edit]').forEach(button=>button.addEventListener('click',()=>editForm(button.dataset.explorerEdit)));$('locationExplorerEditCancel').addEventListener('click',()=>{insertScanning=false;pending=null;show('locationExplorerEdit',false);show('locationExplorerReview',false);show('locationExplorerEditMenu',true)});
   $('locationExplorerEditAction').addEventListener('change',()=>{pending=null;show('locationExplorerReview',false);syncEdit()});
   $('locationExplorerEditScan').addEventListener('click',()=>{insertScanning=true;startScanner()});
   $('locationExplorerPrepare').addEventListener('click',()=>void guard(prepare));$('locationExplorerConfirm').addEventListener('click',()=>void guard(commit));
   $('locationExplorerCancelReview').addEventListener('click',()=>{pending=null;show('locationExplorerReview',false)});
   $('locationExplorerUndo').addEventListener('click',()=>void guard(undoLast));
   $('locationExplorerConfirmPosition').addEventListener('click',()=>void guard(confirmSourcePosition));
   $('locationExplorerNewLayout').addEventListener('click',()=>void guard(()=>wizard()));
   $('locationExplorerExit').addEventListener('click',()=>goBack('explorer_not_found_exit'));
   $('locationExplorerWizardExisting').addEventListener('change',()=>void guard(updateWizardSection));
   $('locationExplorerWizardAreaType').addEventListener('change',()=>{
    const aisle=$('locationExplorerWizardAreaType').value==='AISLE';show('locationExplorerWizardAisleFields',aisle);show('locationExplorerWizardCustomFields',!aisle)});
   $('locationExplorerWizardStart').addEventListener('click',()=>void guard(startWizard));
   $('locationExplorerWizardCancel').addEventListener('click',()=>{resetViews();if(model){$('locationExplorerScreen').classList.add('has-display');show('locationExplorerDisplay',true);void render()}else show('locationExplorerMissing',true)});
  }
  return Object.freeze({open,active,onAcceptedScan,bind});
 }
 return Object.freeze({create});
})();
