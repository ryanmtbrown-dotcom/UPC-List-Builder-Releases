/**
 * OWNERSHIP:
 * File: app/src/main/java/com/rmtb/upclistbuilder/AppUpdateService.kt
 * Owner: Native Application Update
 * Role: Platform service
 * Responsibility: Owns update metadata checks, APK download, verification/install handoff, update status, and native update lifecycle.
 * Does not own: Release-version authority, web update UI, application business state, or file-export semantics.
 * Side effects: Performs approved network/download/package-install platform operations and emits status callbacks.
 * Related code: Update decisions belong to UpdatePolicy.kt; web presentation belongs to application/update-status-service.js.
 */
package com.rmtb.upclistbuilder

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import kotlin.concurrent.thread

/**
 * Owns native update-feed retrieval, APK verification, and installer launch.
 * Presentation and diagnostic mirroring are supplied by callbacks from the activity composition root.
 */
class AppUpdateService(
    private val activity: AppCompatActivity,
    private val onStatus: (String) -> Unit,
    private val onLifecycle: (String, String, String?) -> Unit
) {
    private var automaticStartupCheckStarted = false
    private var installerPending = false

    fun beginStartupCheck(currentVersion: String) {
        if (automaticStartupCheckStarted) return
        automaticStartupCheckStarted = true
        checkForUpdate(currentVersion)
    }

    fun checkForUpdate(currentVersion: String) = thread(name = "upc-update-check") {
        try {
            onStatus("Checking for updates…")
            onLifecycle("CHECKING", "Checking for updates…", null)
            val manifestUrl = "https://raw.githubusercontent.com/ryanmtbrown-dotcom/UPC-List-Builder-Releases/main/update.json?ts=${System.currentTimeMillis()}"
            val connection = openUpdateConnection(manifestUrl, "application/json")
            val code = connection.responseCode
            val body = readHttpBody(connection, code)
            if (code != HttpURLConnection.HTTP_OK) {
                val detail = when (code) {
                    HttpURLConnection.HTTP_NOT_FOUND -> "HTTP 404 · public update feed is not published yet"
                    403 -> "HTTP 403 · public update feed denied the request"
                    429 -> "HTTP 429 · update feed rate limit reached"
                    else -> "HTTP $code · ${connection.responseMessage ?: "request failed"}"
                }
                throw IllegalStateException(detail)
            }
            val manifest = UpdatePolicy.parseManifest(body)
            val candidate = manifest.version
            if (!UpdatePolicy.isNewerVersion(candidate, currentVersion)) {
                val message = "Up to date · v$currentVersion"
                onStatus(message)
                onLifecycle("NO_UPDATE", message, candidate)
                return@thread
            }

            val dir = File(activity.cacheDir, "updates")
            if (!dir.exists() && !dir.mkdirs()) throw IllegalStateException("Could not create update cache directory")
            val apk = File(dir, "UPC-List-Builder-v$candidate.apk")
            val partial = File(dir, "UPC-List-Builder-v$candidate.apk.part")
            if (partial.exists() && !partial.delete()) throw IllegalStateException("Could not clear stale update staging file")
            if (apk.exists() && !apk.delete()) throw IllegalStateException("Could not clear stale downloaded update")

            onStatus("Update v$candidate found · downloading…")
            onLifecycle("DOWNLOADING", "Update v$candidate found · downloading…", candidate)
            val download = openUpdateConnection(manifest.apkUrl, "application/vnd.android.package-archive")
            val downloadCode = download.responseCode
            if (downloadCode !in 200..299) {
                readHttpBody(download, downloadCode)
                throw IllegalStateException("APK download failed · HTTP $downloadCode")
            }
            val total = if (manifest.size > 0) manifest.size else download.contentLengthLong.takeIf { it > 0 } ?: -1L
            onStatus("Downloading v$candidate…")
            var copied = 0L
            download.inputStream.use { input ->
                java.io.FileOutputStream(partial, false).use { output ->
                    val buffer = ByteArray(64 * 1024)
                    var lastPercent = -1
                    while (true) {
                        val count = input.read(buffer)
                        if (count < 0) break
                        output.write(buffer, 0, count)
                        copied += count
                        if (total > 0) {
                            val percent = ((copied * 100) / total).toInt().coerceIn(0, 100)
                            if (percent >= lastPercent + 5) {
                                lastPercent = percent
                                onStatus("Downloading v$candidate · $percent%")
                            }
                        }
                    }
                    output.fd.sync()
                }
            }
            if (!partial.exists()) throw IllegalStateException("Update staging file disappeared after download")
            if (partial.length() < 1024L) throw IllegalStateException("Downloaded APK staging file is empty or incomplete")
            if (manifest.size > 0 && partial.length() != manifest.size) throw IllegalStateException("Downloaded APK size does not match update manifest")
            if (!sha256(partial).equals(manifest.sha256, ignoreCase = true)) {
                partial.delete()
                throw IllegalStateException("Downloaded APK checksum verification failed")
            }
            if (!partial.renameTo(apk)) throw IllegalStateException("Verified update could not be finalized from staging file")
            if (!apk.exists() || apk.length() < 1024L) throw IllegalStateException("Finalized APK is empty or incomplete")

            onStatus("v$candidate verified · opening Android installer")
            activity.runOnUiThread {
                if (installDownloadedApk(apk)) {
                    onLifecycle("INSTALLING", "Installing v$candidate…", candidate)
                } else {
                    onLifecycle("UPDATE_DEFERRED", "Update v$candidate is ready but Android install permission is required.", candidate)
                }
            }
        } catch (e: Exception) {
            val detail = e.message?.take(180) ?: e.javaClass.simpleName
            val message = "Update check failed · $detail"
            onStatus(message)
            onLifecycle("CHECK_FAILED", message, null)
        }
    }

    fun onResume() {
        if (!installerPending) return
        installerPending = false
        onLifecycle("INSTALLER_RETURNED", "Update installation did not replace the running app; continuing with the current version.", null)
    }

    private fun openUpdateConnection(url: String, accept: String): HttpURLConnection =
        (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 12000
            readTimeout = 30000
            instanceFollowRedirects = true
            setRequestProperty("Accept", accept)
            setRequestProperty("User-Agent", "UPC-List-Builder-Android/${activity.packageName}")
            setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
            setRequestProperty("Cache-Control", "no-cache")
        }

    private fun readHttpBody(connection: HttpURLConnection, code: Int): String {
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        return stream?.bufferedReader()?.use { it.readText() }.orEmpty()
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buffer = ByteArray(64 * 1024)
            while (true) {
                val count = input.read(buffer)
                if (count < 0) break
                digest.update(buffer, 0, count)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    private fun installDownloadedApk(apk: File): Boolean {
        if (!activity.packageManager.canRequestPackageInstalls()) {
            onStatus("Allow UPC List Builder to install updates, then tap Check for Updates again.")
            activity.startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${activity.packageName}")))
            return false
        }
        val uri = FileProvider.getUriForFile(activity, "${activity.packageName}.fileprovider", apk)
        installerPending = true
        activity.startActivity(Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        })
        return true
    }
}
