import {readWebRuntimeSource,readNativeRuntimeSource} from './helpers/runtime-source-tree.mjs';
import fs from 'node:fs';
import assert from 'node:assert/strict';

const main=readNativeRuntimeSource();
const app=readWebRuntimeSource();
const worker=fs.readFileSync('app/src/main/java/com/rmtb/upclistbuilder/PersistentAceNetWorker.kt','utf8');

assert.doesNotMatch(main,/longArrayOf\(4_500L, 7_000L, 12_000L\)|startup_prime_attempt_outer_timeout|startAceNetStartupPrime/);
assert.match(main,/startup_retailer_session_ready/);
assert.match(main,/val template=aceNetPersistentRetailerTemplate/);
assert.match(main,/aceNetSessionManager\.markRetailerSessionReady\(\)/);
assert.match(main,/startAceNetStartupPersistentVerification\(template,1\)/);

const verifierStart=main.indexOf('private fun startAceNetStartupPersistentVerification');
const verifierEnd=main.indexOf('\n    private fun deliverAceNetProductionFailure',verifierStart);
const verifier=main.slice(verifierStart,verifierEnd);
assert.match(verifier,/aceNetRetrievalService\.prime\(template,aceNetWarmupSku\)/);
assert.match(verifier,/boundedAttempt<3/);
assert.match(verifier,/startup_persistent_worker_terminal_error/);
assert.match(verifier,/startup_persistent_worker_three_timeouts/);
assert.match(verifier,/timeoutAuthority","PersistentAceNetWorker"/);

assert.match(worker,/AceNetTimingPolicy\.ITEM_ATTEMPT_MS/,'startup prime must use the shared twelve-second item attempt policy');
assert.match(worker,/persistent_worker_sku_evidence_still_pending/,'delayed SKU evidence must remain observable without a premature startup-prime cutoff');
assert.doesNotMatch(app,/UI_WAIT_TIMEOUT|60000|cancelAceNetStartupWarmup\?\.\(\)/);
assert.match(app,/startupHeldUntilTerminal:true/);
assert.match(app,/knownUnavailable=health==='DOWN'\|\|health==='UNAVAILABLE'/);
console.log('conclusive startup verification through Stage 6 retrieval service PASS');
