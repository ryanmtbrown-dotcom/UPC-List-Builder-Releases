/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/app.v059.js
 * Owner: Application Bootstrap
 * Role: Bootstrap adapter
 * Responsibility: Loads immutable release metadata and starts the Application Shell.
 * Does not own: Startup orchestration, navigation, diagnostics, settings, lookup, persistence, or feature business logic.
 * Side effects: Invokes UPCApplicationShell.start only.
 * Related code: All application behavior belongs to the focused owner named in SOURCE_OWNERSHIP_MAP.md.
 */
const UPC_RELEASE=Object.freeze({version:'3.13',build:'v3.13-20261013-compact-planogram-explorer'});
UPCApplicationShell.start({release:UPC_RELEASE});
