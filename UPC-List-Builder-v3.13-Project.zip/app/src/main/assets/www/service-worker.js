/*
 * OWNERSHIP:
 * File: app/src/main/assets/www/service-worker.js
 * Owner: Browser/PWA Platform
 * Role: Service worker
 * Responsibility: Owns non-native browser cache/install fallback lifecycle for the current static web runtime.
 * Does not own: Android updater/install behavior; application business state; AceNet/session authority.
 * Side effects: Browser Cache API and service-worker lifecycle events only.
 * Related code: Browser install UI belongs to platform/web-install-service.js; release identity is synchronized from gradle.properties.
 */
const BUILD_ID='v3.13-20261013-compact-planogram-explorer';
const CACHE='upc-list-builder-v3.13-20261013-compact-planogram-explorer';
const FALLBACKS=['./index.html','./styles.v059.css?v=v3.13-20261013-compact-planogram-explorer','./store-locations/location-explorer.css?v=v3.13-20261013-compact-planogram-explorer','./application/dialogs.css?v=v3.13-20261013-compact-planogram-explorer','./dsd/dsd.css?v=v3.13-20261013-compact-planogram-explorer','./administration/data-management.css?v=v3.13-20261013-compact-planogram-explorer','./misc/misc-workspace.css?v=v3.13-20261013-compact-planogram-explorer','./app.v059.js?v=v3.13-20261013-compact-planogram-explorer','./store-locations/location-explorer-policy.js?v=v3.13-20261013-compact-planogram-explorer','./store-locations/location-explorer-service.js?v=v3.13-20261013-compact-planogram-explorer','./store-locations/location-explorer-edit-service.js?v=v3.13-20261013-compact-planogram-explorer','./store-locations/location-explorer-controller.js?v=v3.13-20261013-compact-planogram-explorer','./store-locations/location-explorer-feature.js?v=v3.13-20261013-compact-planogram-explorer','./library-workflow-v093.js','./db.js','./diagnostics/diagnostic-repository.js?v=v3.13-20261013-compact-planogram-explorer','./diagnostics/diagnostic-journal.js?v=v3.13-20261013-compact-planogram-explorer','./diagnostics/diagnostic-service.js?v=v3.13-20261013-compact-planogram-explorer','./diagnostics/diagnostic-operation-service.js?v=v3.13-20261013-compact-planogram-explorer','./xlsx-importer.js','./xlsx-exporter.js','./catalog/standard-export-schema.js','./ace-misc.js','./vendor/jszip.min.js','./assets/splash/approved_upc_list_builder_splash.png'];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(FALLBACKS)).then(()=>self.skipWaiting())));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(ks=>Promise.all(ks.filter(k=>k.startsWith('upc-list-builder-')&&k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('message',e=>{if(e.data?.type==='SKIP_WAITING')self.skipWaiting();if(e.data?.type==='CLEAR_OLD_CACHES')e.waitUntil(caches.keys().then(ks=>Promise.all(ks.filter(k=>k!==CACHE).map(k=>caches.delete(k)))))});
self.addEventListener('fetch',e=>{if(e.request.method!=='GET')return;const u=new URL(e.request.url);if(u.origin!==self.location.origin)return;if(e.request.mode==='navigate'){e.respondWith(fetch(e.request,{cache:'no-store'}).then(r=>r&&r.ok?r:Promise.reject(new Error('navigation network response not ok'))).catch(()=>caches.match('./index.html')));return}e.respondWith(fetch(e.request,{cache:'no-store'}).then(r=>{if(r&&r.ok){const cp=r.clone();caches.open(CACHE).then(c=>c.put(e.request,cp)).catch(()=>{})}return r}).catch(()=>caches.match(e.request)))});
