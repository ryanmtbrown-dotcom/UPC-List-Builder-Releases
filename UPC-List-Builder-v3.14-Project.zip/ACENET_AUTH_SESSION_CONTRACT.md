# AceNet Authentication / Session Contract

> **REQUIRED REFERENCE RULE:** Read `AI_START_HERE.md`, `CURRENT_ARCHITECTURE_AUTHORITY.md`, `ACENET_SESSION_RETRIEVAL_BOUNDARY_CONTRACT.md`, `APPLICATION_LIFECYCLE_CONTRACT.md`, `ACENET_SERVICE_HEALTH_CONTRACT.md`, and `NETWORK_CONNECTIVITY_CONTRACT.md` before changing authentication/session behavior.

**STATUS: CURRENT — automated verification complete; final physical Android validation pending**

## Purpose

Own encrypted credentials and reusable AceNet authentication/session readiness without turning authentication into requested-item proof.

## Credential ownership

`AceNetSessionManager` owns encrypted AceNet credential save/load/delete.

Credentials use Android Keystore-backed AES/GCM storage.

Credentials, password values, tokens, cookie values, and encryption material must not be logged or exposed except through the explicit current credential-management bridge capability.

`MainActivity` does not own credential cryptography.

## Session facts

The session manager owns persisted/current facts including:

- authenticated session state;
- Home verification;
- retailer session readiness/verification;
- successful lookup timestamp;
- session establishment timestamp;
- session generation;
- refresh-required state;
- reusable-session decision.

Authentication, Home readiness, retailer readiness, worker readiness, and verified requested-item evidence are distinct states.

## Cold startup

Cold startup does not blindly trust stale retained WebView/cookie authentication.

After connectivity preflight permits verification:

1. load saved credentials when available;
2. establish/verify AceNet authentication;
3. prove authenticated Home state;
4. establish the legitimate retailer SSO/session/template handoff;
5. hand the validated retailer template to `AceNetRetrievalService`;
6. prime the retained worker with known-good SKU 50177;
7. exact-SKU + valid-price worker evidence establishes item-service ONLINE/readiness;
8. native terminal startup state is published through the registered `UPCNativeAceNetStartupStatus` callback with explicit `startupResolved`, then projected by `UPCAceNetStartupService` before application Ready.

The transient startup/authentication path does not extract the warm-up price itself. Startup completion does not depend on an unregistered DOM event.

## Retailer SSO

A legitimate retailer SAML/STS transition after Home authentication is session establishment, not automatic session expiry.

Cold-start retailer SSO transit is bounded by the same native startup session-readiness deadline that owns transient authentication/readiness. It may consume only the remaining session-readiness window; it must not hold the application indefinitely waiting for a later retailer navigation. If that deadline expires while Home authentication remains proven, startup terminalizes AceNet as operationally UNAVAILABLE, preserves authentication evidence, releases the application into library-only operation, and leaves later AceNet recovery to the existing session/retrieval paths. Retained-worker proof remains governed by its separate item-attempt timing policy.

Genuine credential-login controls after an unexpected return to login invalidate the current authentication proof and enter the bounded recovery path.

Retailer SSO failure or inconclusive worker proof does not erase independently proven Home authentication; sign-in state and service-health state remain separate.

## Session reuse and age

A reusable session may avoid unnecessary credential re-entry/re-authentication.

Session reuse is based on persisted session timestamps/readiness state, not on keeping the transient Home WebView alive.

The current refresh interval is approximately 55 minutes. When the session is stale/refresh-required, the coordinator must establish a fresh session rather than trusting old in-memory flags/cookies.

Cold startup intentionally starts a fresh session generation.

Brief foreground/background transitions may retain a reusable session/idle worker according to `APPLICATION_LIFECYCLE_CONTRACT.md`.

## Recovery

Authentication/network retry and retailer-bootstrap retry are separately bounded.

An expected first login after intentional fresh-session reset is not itself counted as a recovery failure.

Production request repair follows the current cause-directed soft/hard recovery rules in `ACENET_SESSION_RETRIEVAL_BOUNDARY_CONTRACT.md`; it must not create a second item extractor.

## Ownership boundaries

`AceNetSessionManager` must not:

- create/navigate WebViews;
- inspect ItemDetail DOM;
- extract price/UPC/catalog data;
- dispatch application item callbacks.

`AceNetProductionCoordinator` owns transient authentication/readiness navigation and request/session coordination.

`PersistentAceNetWorker` alone owns requested-item extraction.

## Diagnostics

Record bounded evidence for:

- session generation;
- authentication/Home/retailer readiness transitions;
- session age/reuse decision;
- fresh-session/reset reason;
- SSO/login classification;
- retry/recovery reason;
- worker prime handoff/result;
- native→web startup callback delivery and terminal `startupResolved` state.

Do not record secrets.

## Verification

Tests protect encrypted credential ownership, session-state ownership, no WebView/extraction inside Session Manager, retailer readiness handoff, stale-session refresh, startup worker prime, and sign-in/service-health separation.
