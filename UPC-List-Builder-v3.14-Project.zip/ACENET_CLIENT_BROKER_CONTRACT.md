# AceNet Client / Broker Contract

> **REQUIRED REFERENCE RULE:** Read `AI_START_HERE.md`, `CURRENT_ARCHITECTURE_AUTHORITY.md`, `ACENET_ITEM_RETRIEVAL_CONTRACT.md`, and `ACENET_AUTH_SESSION_CONTRACT.md` before changing request brokerage.

**STATUS: CURRENT — automated architecture verification complete; final physical Android validation pending**

## Purpose

`UPCAceNetClient` is the single JavaScript owner of production AceNet request bookkeeping.

It owns:

- request ID creation;
- one shared pending-request map;
- normalized expected-SKU correlation;
- native bridge invocation;
- caller safety timeouts;
- supersession/cancellation;
- terminal callback correlation;
- pending-state cleanup;
- typed result delivery.

It does not own authentication/session readiness, WebView lifecycle, remote navigation, item extraction, retained-worker behavior, catalog refresh policy, persistence policy, or presentation/list behavior.

## Typed capabilities

The broker exposes:

- `requestPrice(sku,{upcEnrichment})`;
- `requestUpcs(sku)`;
- `requestCatalog(sku,{misc,repair})`.

Price, UPC-set, and catalog evidence retain distinct validation rules; a generic untyped success path is prohibited.

## Native bridge compatibility

Current native request methods:

- `lookupAceNetPrice`;
- `lookupAceNetPriceWithUpcs`;
- `lookupAceNetUpcs`;
- `lookupAceNetCatalog`;
- `lookupAceNetMiscCatalog`;
- `lookupAceNetRepairCatalog`.

Current result callbacks:

- `UPCNativeAceNetPriceResult`;
- `UPCNativeAceNetUpcResult`;
- `UPCNativeAceNetCatalogResult`.

The JavaScript broker does not redefine native navigation, session establishment, worker modes, exact-SKU proof, or extraction selectors.

## Expected-SKU correlation

Every request records the normalized SKU expected by its caller.

A callback becomes verified evidence only when its returned normalized SKU satisfies the capability-specific exact-SKU requirement.

Unknown/stale IDs are ignored after diagnostics where applicable. Timeout, cancellation, supersession, or prior completion permanently closes that request.

## Ownership timeouts

Caller timers are cleanup/ownership boundaries, not retrieval engines.

Current JavaScript fallback budgets remain above native retrieval/recovery timing and must not preempt the native worker/recovery path.

The installed runtime may obtain the authoritative production broker ownership budget from `getAceNetProductionBrokerTimeoutMs`; the JavaScript fallback remains bounded for environments without that capability.

Every timeout resolves exactly once and removes pending state.

## Price supersession

Normal price presentation is latest-request-owned.

Starting a new price-family request supersedes older pending price-family work and resolves it as `SUPERSEDED`.

UPC-only and catalog workflows remain caller-sequential and are not globally superseded just because a price request starts.

## Price evidence

Price-only dispatch uses `lookupAceNetPrice`.

Price+UPC dispatch uses `lookupAceNetPriceWithUpcs`.

Verified price evidence requires:

- native `found === true`;
- status `FOUND`;
- exact normalized SKU;
- valid positive parsed price;
- for price+UPC, at least one valid UPC selector value.

## UPC-set evidence

Verified UPC evidence requires:

- native `found === true`;
- status `FOUND`;
- exact normalized SKU;
- at least one valid deduplicated UPC.

The broker returns evidence only. Current relationship persistence/reconciliation belongs to `UPCIdentifierRelationshipService`.

## Catalog evidence

Full catalog verification requires:

- native `found === true`;
- status `FOUND`;
- exact normalized SKU;
- catalog object.

`FOUND_PARTIAL` may map to `VERIFIED_PARTIAL` only for repair mode. Ordinary catalog and MISC catalog must not inherit repair partial semantics.

## Diagnostics

Request lifecycle mechanism is diagnosed by the broker; workflow-specific diagnostics remain with callers.

Credential secrets and other protected values remain subject to `DIAGNOSTICS_CONTRACT.md`.

## Ownership rule

Workflow code must not maintain separate price/UPC/catalog request maps, request IDs, timers, bridge-correlation state, or terminal cleanup.

Thin caller wrappers are allowed only when they delegate state ownership entirely to `UPCAceNetClient`.

## Verification

Maintained tests must protect:

- one broker request-state owner;
- native method/callback compatibility;
- expected-SKU correlation;
- timeout cleanup;
- price supersession;
- typed evidence validation;
- absence of duplicate request maps in application/workflow code.
