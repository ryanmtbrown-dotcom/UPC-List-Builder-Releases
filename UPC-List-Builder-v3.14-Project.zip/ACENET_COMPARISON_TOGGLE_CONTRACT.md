# AceNet Comparison / UPC Enrichment Session Controls Contract

> **REQUIRED REFERENCE RULE:** Read `SETTINGS_PERSISTENCE_CONTRACT.md`, `ACENET_SERVICE_HEALTH_CONTRACT.md`, and `NORMAL_ITEM_SEARCH_CONTRACT.md` before changing these controls.

**STATUS: CURRENT**

## Purpose

Define user preference state and effective operational availability for optional AceNet comparison pricing and UPC enrichment.

## Startup defaults

At a conclusive startup service decision:

- authenticated + ONLINE initializes Comparison Pricing ON and UPC Enrichment ON;
- UNAVAILABLE/DOWN initializes both OFF.

This initialization happens once per running process/session.

## User authority

After startup, user changes are authoritative running-session preference state.

They are not persisted across restarts.

A manual OFF choice is not automatically reversed by ordinary later health observations; the next application startup performs a new default decision.

## Parent dependency

Comparison Pricing is the parent capability.

Effective UPC Enrichment requires:

- effective Comparison Pricing ON; and
- the running-session enrichment preference ON.

Turning comparison OFF makes enrichment effectively OFF/disabled without necessarily erasing its remembered session preference.

Changing enrichment affects subsequent requests; an already-running request uses the capability snapshot taken when it began.

### Hard operational invariant

UPC Enrichment may be turned OFF while Comparison Pricing remains ON.

UPC Enrichment must never be operationally ON while Comparison Pricing is OFF. No workflow may use the enrichment preference as permission to dispatch AceNet traffic after the parent comparison/access capability is disabled.

This dependency is intentional. Comparison may be disabled because network access is poor/unavailable, AceNet is under maintenance, or the user needs an expedited workflow. Enrichment cannot derive data from the same live AceNet source while that source is intentionally disabled or unavailable.

Work captured while AceNet cannot be used may be queued locally for a later **user-initiated** live refresh. That deferred queue is not permission to dispatch while Comparison Pricing remains OFF.

## User retry authority and service health

User preference and current service health are distinct.

DOWN/UNAVAILABLE/DEGRADED health remains visible as operational evidence and may cause startup to initialize the optional features OFF, but health does not disable the controls or permanently veto later requests.

After startup:

- Comparison Pricing and UPC Enrichment controls remain user-operable;
- turning Comparison Pricing ON does not itself start authentication or session work;
- when current health is ONLINE/available, subsequent lookups use the normal existing AceNet request/session path without a special re-establishment attempt;
- when current health is DOWN or UNAVAILABLE, explicitly turning Comparison Pricing ON arms one native one-shot recovery authorization;
- toggling ON does not itself authenticate or establish a session;
- the next production AceNet request consumes that authorization exactly once and enters the existing hard fresh-session recovery path;
- after consumption, later requests while health remains DOWN/UNAVAILABLE are rejected without starting another session recovery until the user explicitly toggles Comparison Pricing OFF and ON again;
- the existing native AceNet coordinator owns the authorization token, authentication/session/readiness recovery, worker priming, and bounded redispatch for that one request;
- failure of that request may update health evidence, but it does not silently switch the user's running-session preference back OFF;
- UPC Enrichment preference may be changed independently, while effective enrichment still requires Comparison Pricing ON.

## Presentation

When the user comparison preference is OFF, normal lookup does not request/present live AceNet comparison value.

When ON with healthy/available service state, normal lookup uses the ordinary retained-session path. When ON was explicitly selected by the user while health was DOWN/UNAVAILABLE, only the next production request is authorized to force fresh-session recovery. AceNet Price remains an independent background value and does not replace Library Price.

## Diagnostics and verification

Diagnostics record preference source, effective state, authentication/health context, one-shot arm/disarm/consume events, recovery action, and running-session semantics.

Tests protect startup defaults, session-only storage, parent dependency, always-operable user controls, one-shot user recovery after unavailable health, no repeated recovery on later scans without re-arming, and truthful health presentation.
