# AceNet Item Data Extraction Reference

> **REQUIRED REFERENCE RULE:** Read `ACENET_ITEM_RETRIEVAL_CONTRACT.md` and `CATALOG_REFRESH_POLICY_CONTRACT.md` before changing production extraction.

**STATUS: CURRENT REQUIRED REFERENCE**

## Purpose

Define the proven production AceNet ItemDetail evidence sources and field semantics used by the sole retained worker.

Do not invent selectors from field names and do not use generic label/placeholder text as field authority.

## Production modes

The same retained worker supports distinct capabilities:

- `PRODUCTION_PRICE` — exact SKU + retail price only;
- `PRODUCTION_PRICE_UPCS` — exact SKU + retail price + ordered UPC selector values;
- `PRODUCTION_UPCS` — exact SKU + ordered UPC selector values;
- `PRODUCTION_CATALOG` — exact SKU + complete Local catalog field set;
- `PRODUCTION_MISC_CATALOG` — catalog set plus MISC-required OM Weight;
- `PRODUCTION_REPAIR_CATALOG` — same exact-field family; may return verified partial evidence at terminal deadline.

A mode extracts only evidence required by that capability.

## Exact item identity

Exact requested SKU proof is mandatory before any result becomes verified item evidence.

Authoritative SKU element:

`ctl00_ctl00_contentMainPlaceHolder_MainContent_headerSkuDataBar_lblSkuNr`

SKU mismatch is terminal mismatch evidence.

## Retail price

Production comparison PRICE uses the exact retailer **Store Retail** element `lblHeaderSellingDataStoreRetail` (`data-storeretail` or text). Its value must be valid and tied to the verified exact SKU. The separate `divStrL1L2` Ace/L1 retail element may populate the *Ace Retail Price* catalog field, but is never a fallback for Store/Level 2 comparison price. Generic `RetailPrice` selectors are not authoritative comparison evidence. Missing Store Retail must remain inconclusive rather than creating a false price change.

PRICE mode does not enumerate UPC controls.

## Exact catalog elements

Current authoritative ItemDetail elements:

- SKU — `ctl00_ctl00_contentMainPlaceHolder_MainContent_headerSkuDataBar_lblSkuNr`
- Description — `ctl00_ctl00_contentMainPlaceHolder_MainContent_headerSkuDataBar_lblLongDescr`
- Manufacturer Number — `ctl00_ctl00_contentMainPlaceHolder_MainContent_headerSkuDataBar_lblMfgNr`
- Retailer Each Cost — `spnEachCost`
- Order Multiple — `spnEachOM`
- OM Weight — `spnEachWeight`
- Commodity Group — `ctl00_ctl00_contentMainPlaceHolder_MainContent_headerSkuDataBar_lblComGrpBcrumb`
- Merchandise Class — `ctl00_ctl00_contentMainPlaceHolder_MainContent_headerSkuDataBar_lblMerchClsBcrumb`
- Product Group — `ctl00_ctl00_contentMainPlaceHolder_MainContent_headerSkuDataBar_lblProdGrpBcrumb`
- UPC selector — `ctl00_ctl00_contentMainPlaceHolder_MainContent_mainItemData_lvAceItemDetails_ctrl0_ddlUPC`

Placeholder `-`, label-only text such as `OM Weight:`, and unrelated tab text such as `SPECS` are not values.

Generic fuzzy field searches are not production authority for these fields.

## Catalog field semantics

Preserved AceNet concepts:

- SKU;
- Ace Retail Price;
- Retailer Each Cost;
- Description;
- Manufacturer Number;
- Order Multiple;
- OM Weight;
- Master/default UPC;
- all ordered UPC selector values;
- Commodity Group;
- Merchandise Class Number;
- Product Group Number.

Retail Units is not AceNet-authoritative.

Case Cost and Case Quantity are not claimed as direct AceNet ItemDetail fields.

Department is not a direct ItemDetail value in this reference; downstream mapping may derive business department only from an explicitly governed mapping.

## Classification normalization

Classification breadcrumb elements may expose values such as `56 - FASTENERS`.

Raw evidence may preserve the observed breadcrumb text in diagnostics/retrieval payloads.

Durable Local Library classification fields normalize and retain the numeric code only.

MISC similarly normalizes numeric classification codes when consuming older breadcrumb-form Master/Local data.

## UPC evidence

UPC values are read from the authoritative selector in current order.

The first/default selector value is canonical under the relationship/catalog policy. Remaining unique values are alternates.

UPC-only mode does not inspect price controls.

## Event-driven extraction

The retained worker uses MutationObserver-based extraction on the loaded ItemDetail document and currently readable nested iframe documents.

Newly readable documents may be enrolled as mutations occur.

Each observation executes one unified extraction pass; catalog fields accumulate until complete.

There is no independent poller/timer per field.

The worker's native terminal deadline is a safety boundary, not a polling engine.

## Completeness

Ordinary `PRODUCTION_CATALOG` requires its complete configured field set before `FOUND`.

`PRODUCTION_MISC_CATALOG` additionally requires valid OM Weight.

`PRODUCTION_REPAIR_CATALOG` uses the same exact selectors. When exact SKU is proven but one or more fields remain missing at terminal deadline, it may return `FOUND_PARTIAL` with the positively observed field set and explicit missing-field names.

Partial evidence does not infer missing values.

## Forensic fallback

When required catalog evidence remains incomplete, diagnostics may capture bounded sanitized main/iframe HTML structure, script references, IDs/names/labels, and observer state sufficient to diagnose extraction.

Never capture credential secrets, cookie values, auth tokens, SAML/assertion content, form/input values, or retail-price values in forensic trace.

Forensics are diagnostic evidence only and are not an alternate production selector source.

## Image work

Product-image discovery is a separate feature owner. Image/CDN failures are not item-retrieval/service-health authority.
