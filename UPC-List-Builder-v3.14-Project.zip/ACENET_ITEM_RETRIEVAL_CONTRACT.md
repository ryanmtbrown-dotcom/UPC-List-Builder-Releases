# AceNet Item Retrieval Contract

> **REQUIRED REFERENCE RULE:** Read `ACENET_ITEM_DATA_EXTRACTION_REFERENCE.md`, `ACENET_SESSION_RETRIEVAL_BOUNDARY_CONTRACT.md`, `ACENET_CLIENT_BROKER_CONTRACT.md`, and `ACENET_AUTH_SESSION_CONTRACT.md` before changing production retrieval.

**STATUS: CURRENT — automated verification complete; final physical Android validation pending**

## Purpose

Define one authoritative, sequential production ItemDetail engine and its capability-specific evidence rules.

## Sole engine

`PersistentAceNetWorker` is the only production ItemDetail navigation/extraction engine.

`AceNetRetrievalService` alone constructs/retains it and exposes prime/search/destroy lifecycle.

Transient coordinator WebViews may establish authentication/retailer readiness but must not extract production item evidence.

No warmed/transient search WebView is a second production engine.

## Sequential ownership

The retained worker handles one active request at a time.

Every request has:

- request ID;
- capability mode;
- normalized requested SKU;
- bounded attempt timeout;
- exact-SKU evidence requirement;
- one terminal result.

Late evidence after terminal cleanup is ignored.

## Current timing

Authoritative timing policy:

- structure inspection: 3 seconds;
- malformed/structural confirmation: 5 seconds;
- item attempt: 12 seconds;
- soft recovery canary: 5 seconds;
- hard recovery budget: 25 seconds;
- full production incident: 50 seconds;
- JavaScript broker ownership: 52 seconds.

The JavaScript broker ceiling remains above native recovery ownership.

Mode-specific extraction is event-driven; these clocks bound ownership/recovery rather than poll the DOM.

## Capability rules

### PRODUCTION_PRICE

Requires:

- exact requested SKU;
- valid positive retail price.

Does not enumerate UPCs/catalog fields.

### PRODUCTION_PRICE_UPCS

Requires:

- exact requested SKU;
- valid positive retail price;
- non-empty valid ordered UPC selector set.

### PRODUCTION_UPCS

Requires:

- exact requested SKU;
- non-empty valid ordered UPC selector set.

Does not inspect retail-price controls for its own result.

### PRODUCTION_CATALOG

Requires exact SKU plus the complete ordinary catalog field set defined by `ACENET_ITEM_DATA_EXTRACTION_REFERENCE.md`.

One loaded ItemDetail document supplies the complete item. It must not chain separate PRICE/UPC/metadata requests.

### PRODUCTION_MISC_CATALOG

Uses the catalog field family and additionally requires OM Weight.

### PRODUCTION_REPAIR_CATALOG

Uses the exact same catalog selectors.

If exact SKU is proven and positively observed fields exist but required fields remain missing at terminal deadline, repair mode may return `FOUND_PARTIAL` plus explicit missing fields.

Other catalog modes do not inherit partial-success semantics.

## Exact-SKU authority

Returned SKU must exactly match requested normalized SKU before item evidence is accepted.

A different SKU terminates as mismatch.

No SKU proof by terminal boundary is inconclusive/unverified, not successful item evidence.

A rendered page that explicitly identifies the requested SKU as not found may terminate as conclusive `NOT_FOUND`. A page that does not contain literal not-found text may also terminate as `NOT_FOUND` when the retained worker observes the same healthy empty ItemDetail state at both the normal structure checkpoint and the confirmation checkpoint: expected authenticated retailer host/path, document complete, no Chromium/network-error evidence, normal ItemDetail SKU/price/description shell and scripts/iframes present, SKU element present, returned SKU blank, and no SKU evidence observed. The current checkpoints are approximately 3 seconds and 5 seconds.

Body-text length and similar forensic measurements remain diagnostic evidence; they are not sole business classifiers.

Production `NOT_FOUND` is a healthy service-path response, not successful item evidence, and must not enter session repair merely because the SKU does not exist.

When the exact requested SKU is positively verified but the UPC selector remains absent at both checkpoints, catalog modes may return `FOUND_NO_UPC_DATA` only when the retained catalog snapshot is otherwise complete and `masterUpc` is the sole missing required field. This is verified item evidence with unavailable UPC-selector data, not `NOT_FOUND`, not a transport timeout, and not authority to replace the current UPC relationship set.

## Navigation/extraction

The worker navigates using the validated retailer ItemDetail template handed off from session readiness.

Extraction follows the exact current selectors/reference and MutationObserver-driven readiness.

Generic label/fuzzy selector fallback is not catalog authority.

A main-frame HTTP 404 receives a short observation window before terminal fallback so a rendered AceNet item-not-found page can be classified by the same DOM owner. If recognized not-found evidence does not appear, the worker preserves the raw 404 as `MAIN_FRAME_HTTP_404_UNCLASSIFIED` and captures bounded sanitized page forensics for diagnosis.

## Recovery

A production request first uses the ready worker when current session/readiness permits.

On authenticated worker failure, the coordinator may perform one bounded soft retained-session canary repair.

When session is stale/unusable or soft repair is insufficient, one bounded hard authentication/retailer-session recovery may occur.

After repair:

1. validate retailer template;
2. prime worker with known-good SKU;
3. redispatch original request ID/mode/SKU through the retained worker.

There is no transient item-extraction fallback.

Cause-directed server/network/session classification governs whether recovery is appropriate.

## Lifecycle

Healthy idle worker retention/background rules follow `APPLICATION_LIFECYCLE_CONTRACT.md`.

An active worker interrupted by full backgrounding does not launch recovery while the application is non-visible.

## Diagnostics

Trace meaningful navigation/extraction/recovery boundaries with request/mode/SKU-safe correlation, timing, exact-SKU state, missing-field state, and terminal classification.

Forensic diagnostics remain subject to `NATIVE_TRACE_CONTRACT.md`.

A diagnostic snapshot is never item evidence and cannot create a FOUND result.

## Verification

Tests protect:

- sole worker construction;
- sole item selector ownership;
- all current modes;
- exact-SKU rejection and conclusive NOT_FOUND classification from explicit text or stable healthy-empty ItemDetail structure;
- exact-SKU `FOUND_NO_UPC_DATA` classification only when `masterUpc` is the sole missing required catalog field;
- event-driven extraction;
- current timing policy;
- repair-only partial behavior;
- soft/hard recovery then original request redispatch;
- no transient item fallback;
- lifecycle cleanup.
