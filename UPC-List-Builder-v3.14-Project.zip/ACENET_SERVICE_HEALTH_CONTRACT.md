# AceNet Service Health Contract

> **REQUIRED REFERENCE RULE:** Read `NETWORK_CONNECTIVITY_CONTRACT.md`, `ACENET_AUTH_SESSION_CONTRACT.md`, `ACENET_ITEM_RETRIEVAL_CONTRACT.md`, and `DIAGNOSTICS_CONTRACT.md` before changing health classification.

**STATUS: CURRENT — automated verification complete; final physical Android validation pending**

## Purpose

Publish truthful AceNet operational health from authoritative evidence while keeping sign-in, device connectivity, request-specific failure, and global server availability distinct.

AceNet Health is the application's best bounded determination of whether the current authenticated/request path can return useful item evidence for the present request or a near-term subsequent request. It is not a general public server-status monitor. The classifier balances workflow delay against AceNet's value as the preferred live source.

## Health states

Current health may include:

- `ONLINE`;
- `DOWN`;
- `UNAVAILABLE`;
- `DEGRADED`;
- `CHECKING`;
- `UNKNOWN`.

Authentication state is separate from health.

A user may be signed in while item-service health is UNKNOWN or temporarily UNAVAILABLE.

## ONLINE evidence

Verified exact-SKU successful item evidence from the authoritative retained worker is strong ONLINE evidence.

Startup known-good worker prime exact-SKU + valid-price success establishes ONLINE.

Later successful verified production retrieval may restore ONLINE after transient/inconclusive failures.

## Authoritative server-unavailable evidence

Observed main-frame HTTP server responses 500, 502, 503, or 504 may establish `OBSERVED_SERVER_UNAVAILABLE` / global server-down evidence.

DOWN requires authoritative service/server evidence; it is not inferred from ordinary connectivity or missing data.

## HTTP/auth classifications

Main-frame HTTP evidence is classified by cause, including:

- 401 → authentication required;
- 403 → access denied;
- a rendered, explicitly recognized item-not-found response → conclusive `NOT_FOUND`; this is healthy item-service evidence because AceNet successfully answered the item question;
- raw main-frame 404 → a short observation window allows the rendered page to prove legitimate `NOT_FOUND`; if no recognized not-found evidence appears, the 404 remains abnormal operational HTTP evidence;
- 500/502/503/504 → observed server unavailable.

These classifications retain raw provenance. A conclusive production `NOT_FOUND` may restore/retain ONLINE health; an unclassified raw 404 does not prove global DOWN but may make the current item-service path operationally UNAVAILABLE.

## What does not prove DOWN

The following do not independently establish global DOWN:

- DNS/transport/connectivity error;
- no/weak network;
- `ERR_EMPTY_RESPONSE`;
- timeout;
- missing price/UPC/catalog field;
- SKU mismatch;
- malformed/incomplete page evidence;
- incidental subresource/CDN/image error;
- Android lifecycle movement/backgrounding;
- `navigator.onLine === false`;
- Android network validation UNKNOWN.

They may terminate/degrade the affected request or lead to operational UNAVAILABLE according to bounded recovery policy.

The former 1,000-visible-character / 500-ms production workaround is retired and is not current health authority.

## Startup health

Connectivity preflight first distinguishes device/network availability from service health.

Startup then establishes authentication/retailer readiness and delegates known-good item proof to the retained worker.

- verified worker success → ONLINE;
- authoritative observed server-down evidence → DOWN;
- bounded inability to establish an operational session after allowed recovery → UNAVAILABLE;
- inconclusive evidence without authoritative down proof remains UNKNOWN/DEGRADED as appropriate.

Startup does not declare service success merely because Home authentication succeeded.

Authentication-network retry and retailer-bootstrap retry have independent startup retry budgets; consuming one does not silently consume the other.

Retailer SSO transit during cold startup may consume only the remaining native startup session-readiness window. Expiration of that window while authentication is still proven classifies the startup item-service path as operationally UNAVAILABLE and releases library-only operation. That deadline is bounded readiness evidence and does not establish DOWN; only authoritative server evidence may do that. Retained-worker proof continues under its separate item-attempt timing policy when retailer readiness is established in time.

Three retained-worker startup timeout results classify the item service operationally UNAVAILABLE unless stronger authoritative server evidence establishes DOWN. A retained-worker transient transport failure such as `ERR_EMPTY_RESPONSE`, connection reset/closed/aborted, or transport timeout receives at most one additional startup item attempt before terminal operational classification.

Startup work retained while Android is backgrounded may establish ONLINE normally. A non-ONLINE operational result produced while startup was backgrounded receives one foreground revalidation before it becomes the current usable-service conclusion; lifecycle movement itself does not create UNAVAILABLE or DOWN.

Native health transitions are published through `UPCNativeAceNetHealthStatus`, registered once by `platform/bridge-registration.js`, and projected by `UPCAceNetStartupService` into shared web runtime state. The web projection does not classify health; it reflects native authority and lets Settings choose startup defaults and user-retry authorization without becoming a second health classifier.

## Production cause-directed recovery

A request failure is classified before recovery.

Current production incident policy may use:

- one soft retained-session known-good canary repair;
- one hard fresh-session recovery only when retained-session canary or authentication evidence justifies it;
- one final worker item attempt inside the total incident budget.

A first item timeout without exact-SKU field evidence uses the soft known-good canary before any full sign-in reset. If that canary succeeds and the requested SKU still times out, the request terminates as an item-specific timeout while the verified session remains healthy. A repeated transient transport failure after a successful canary likewise terminates the item request without forcing reauthentication.

If the soft canary itself fails with a classified transient transport error, the current item-service path becomes operationally UNAVAILABLE without spending the hard sign-in recovery budget because no authentication-loss evidence exists. Device-connectivity and authoritative server evidence retain their existing distinct classifications.

Network/server evidence that makes retry inappropriate is not blindly treated as stale-session repair.

A second terminal failure after bounded recovery may yield operational UNAVAILABLE without fabricating DOWN.

## Optional feature controls and recovery probes

Health informs startup defaults and remains visible operational evidence, but it does not permanently suppress or disable the user controls after startup.

If the user explicitly enables Comparison Pricing while current health is DOWN/UNAVAILABLE, Settings arms one native recovery authorization. The next production AceNet request consumes that authorization and forces the existing hard fresh-session recovery path. The authorization is consumed before recovery begins, so failure cannot cause every later scan to repeat session establishment. Later requests while health remains DOWN/UNAVAILABLE are rejected without recovery until the user explicitly re-arms by toggling Comparison Pricing OFF and ON again. A failed recovery may preserve/update health state but does not silently rewrite the user's running-session toggle preference.

## Diagnostics

Health evidence records:

- raw source callback/result;
- request/phase role;
- status/error/HTTP code;
- main-frame status;
- classification, including device-connectivity versus transient-transport failure;
- whether evidence is global server-down authority;
- recovery attempt/reason;
- resulting health transition;
- native→web health callback delivery and the projected runtime state.

Diagnostics must not infer health beyond the owning classifier.

## Verification

Tests protect server-code classification, raw provenance, device-connectivity versus transient-transport distinction, authentication/health separation, startup worker proof, soft-canary-first timeout recovery, no unnecessary hard repair after a verified canary, no false DOWN from lifecycle/connectivity/subresources, and retired workaround absence.
