# AceNet Session / Retrieval Boundary Contract

> **REQUIRED REFERENCE RULE:** Read `AI_START_HERE.md`, `CURRENT_ARCHITECTURE_AUTHORITY.md`, `ACENET_AUTH_SESSION_CONTRACT.md`, `ACENET_ITEM_RETRIEVAL_CONTRACT.md`, `ACENET_CLIENT_BROKER_CONTRACT.md`, `APPLICATION_LIFECYCLE_CONTRACT.md`, and `NATIVE_TRACE_CONTRACT.md` before changing native AceNet session/readiness or item retrieval.

**STATUS: CURRENT — automated architecture verification complete; final physical Android validation pending**

## Purpose

Keep native AceNet authentication/session/readiness ownership separate from authoritative item-page retrieval.

Required dependency direction:

`UPCAceNetClient → AndroidNative/AceNetProductionCoordinator → AceNetRetrievalService → one PersistentAceNetWorker`

Session establishment/repair uses `AceNetSessionManager` plus the coordinator's transient authentication/readiness WebView path. Transient WebViews are not production item-retrieval engines.

## AceNetSessionManager ownership

`AceNetSessionManager` owns:

- encrypted credential persistence/load/delete;
- authenticated-session state;
- session freshness and refresh-required state;
- Home verification;
- retailer readiness/verification;
- successful-lookup/session timestamps;
- session generation/history;
- reusable-session decisions.

It must not create/navigate WebViews, inspect item-page DOM, extract item evidence, or dispatch application result callbacks.

Session readiness is permission/evidence that retrieval may proceed. It is not evidence that a requested item was found.

## AceNetRetrievalService ownership

`AceNetRetrievalService` is the thin retained-worker lifecycle/dispatch owner.

It owns:

- creation of the one `PersistentAceNetWorker`;
- ready/busy state exposure;
- typed search dispatch;
- priming;
- destruction/invalidation.

It must not contain selectors, DOM extraction, exact-SKU proof logic, or a second navigation engine.

No other production owner may construct a retained worker.

## PersistentAceNetWorker sole-engine rule

`PersistentAceNetWorker` is the one authoritative production ItemDetail engine.

It owns:

- retailer ItemDetail navigation after valid session/template handoff;
- exact returned-SKU proof;
- PRICE extraction;
- PRICE+UPC extraction;
- UPC-only extraction;
- ordinary catalog extraction;
- MISC catalog extraction;
- repair catalog extraction and repair-only partial-result semantics;
- event-driven item DOM observation;
- evidence deadlines;
- terminal worker result delivery.

Selectors/field meanings remain governed by `ACENET_ITEM_RETRIEVAL_CONTRACT.md` and `ACENET_ITEM_DATA_EXTRACTION_REFERENCE.md`.

## Transient WebView boundary

The coordinator's transient WebView path may perform session/readiness work that requires navigation:

- fresh credential login;
- authenticated Home proof;
- legitimate retailer wrapper/template discovery;
- retailer STS/SAML session establishment;
- reauthentication/session repair;
- validated query-bearing retailer-template preservation.

The narrow `AceNetResultBridge` accepts wrapper/readiness evidence only. Non-wrapper item evidence is ignored and treated as an architecture violation.

Transient navigation into the retailer realm may establish readiness, but must not extract price, UPC, catalog fields, or requested-item proof.

## Readiness states

These are distinct:

- authenticated/Home verified;
- retailer session ready;
- retained worker ready;
- verified requested-item evidence.

A readiness transition must never be reported as requested-item success.

## Startup handoff

After authentication and retailer readiness:

1. coordinator hands the validated retailer template to `AceNetRetrievalService`;
2. the service primes the worker with the known-good warm-up SKU;
3. the worker alone performs exact-SKU + price proof;
4. startup health consumes that worker result under current bounded retry policy.

Startup must not duplicate worker price extraction.

## Production request and repair

A ready worker receives the original typed production request through `AceNetRetrievalService.search()`.

Known DOWN/UNAVAILABLE health normally remains an admission stop for production AceNet requests. The sole exception is an explicit one-shot authorization armed by the user's Comparison Pricing OFF→ON action while health is known unavailable/down. The coordinator owns that authorization token. The next production request consumes it before any recovery work begins, creates the normal production incident, and enters the hard fresh-session repair path. The token is then false regardless of success or failure. Later production requests while health remains DOWN/UNAVAILABLE return unavailable without session establishment until the user explicitly re-arms. When health is ONLINE/available, the ordinary retained-session/worker path is used and the one-shot recovery mechanism is not involved.

If session/worker readiness is insufficient:

1. retain original request ID/mode/SKU;
2. for item timeout, malformed, or transport evidence that does not itself prove authentication loss, use the retained-session soft known-good canary first when applicable;
3. if the canary proves the session healthy, redispatch the requested item once; a second item-specific timeout or classified transient transport failure terminates that request without full reauthentication;
4. only when canary/authentication evidence justifies it, repair authentication/retailer readiness through the transient path;
5. validate the retailer template;
6. prime the worker;
7. redispatch the original request through `AceNetRetrievalService.search()`.

The actual requested item's evidence must always come from `PersistentAceNetWorker`.

No transient production item-extraction fallback is permitted.

## Saved-credential test

The native saved-credential test may use the transient authentication/readiness path, but successful requested-item proof is worker-owned exact-SKU + price evidence.

## Lifecycle

A healthy idle worker may remain across harmless background/foreground transitions according to `APPLICATION_LIFECYCLE_CONTRACT.md`.

Active interruption, stale-session refresh, worker loss, and explicit invalidation are bounded recovery/destruction cases. Recovery may recreate/prime the single worker through `AceNetRetrievalService`; it may not create a second engine.

## Forbidden duplicate ownership

Verification must reject:

- worker construction outside `AceNetRetrievalService`;
- session/credential SharedPreferences ownership outside `AceNetSessionManager`;
- item selectors in `MainActivity` or `AceNetProductionCoordinator`;
- item extraction through `AceNetResultBridge`;
- transient production fallback returning item evidence;
- duplicate exact-SKU proof/navigation outside `PersistentAceNetWorker`;
- tests that freeze retired implementation location.

## Verification

Automated coverage must include:

- sole worker construction/selector ownership;
- wrapper-only transient observation;
- startup readiness → worker prime;
- price, price+UPC, UPC-only, ordinary catalog, MISC catalog, and repair catalog;
- repair-only partial result;
- authenticated session reuse;
- stale/expired-session repair;
- soft-canary-first timeout/transient transport handling and repaired request redispatch;
- background/foreground behavior;
- saved-credential test through the worker;
- one-shot user recovery authorization arm/consume behavior after known DOWN/UNAVAILABLE health;
- no repeated session recovery on subsequent requests without explicit re-arming.

Real-device validation remains required before final release completion.
