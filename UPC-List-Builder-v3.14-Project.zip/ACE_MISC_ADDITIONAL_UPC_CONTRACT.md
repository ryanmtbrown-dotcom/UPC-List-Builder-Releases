# ACE New Items MISC UPC / Verification Contract

> **REQUIRED REFERENCE RULE:** Read `AI_START_HERE.md`, `ACE_MISC_ADDITIONAL_UPC_CONTRACT.md` dependencies in `DOCUMENTATION_INDEX.md`, `CATALOG_REFRESH_POLICY_CONTRACT.md`, `IDENTIFIER_RELATIONSHIP_SERVICE_CONTRACT.md`, and the AceNet retrieval contracts before changing MISC resolution/export behavior.

**STATUS: CURRENT — automated verification complete; final physical Android validation pending**

## Purpose

Define ACE New Items MISC resolution, exact-SKU live verification, ordered UPC completeness, snapshot authority, and export safety.

## Current ownership

- `ace-misc.js` — workbook/domain/export-row rules;
- `UPCMiscDraftModel` — draft/completeness transformations;
- `UPCMiscResolutionService` — Master → Local → AceNet resolution and live exact-SKU refresh;
- `UPCMiscVerificationService` — retry, NOT_FOUND confirmation, export-readiness;
- `UPCMiscMaintenanceService` — saved-session maintenance;
- `UPCMiscSnapshotService` — snapshot construction helpers;
- `UPCMiscRuntimeResolver` — exported resolver registration/guard;
- `UPCMiscWorkspaceController` — manual/bulk UI orchestration and active session mutation.

The callable global resolver is `window.UPCAceMiscResolver.resolveSkuCandidate`; consumers use the runtime guard and must not reach a hidden lexical resolver.

## Resolution authority

MISC resolves exact SKU through:

1. official Master;
2. durable Local;
3. exact-SKU `PRODUCTION_MISC_CATALOG` when current live evidence is required.

Ambiguous local catalog SKU is terminal and must not be sent to AceNet.

A Master+Local miss resolved by complete exact-SKU AceNet catalog evidence is persisted to Local Library and verified before MISC reports success.

There is no promoted-Master compatibility path.

## Mandatory live verification

A durable Master/Local row is baseline catalog evidence, not by itself complete MISC export proof.

Known rows receive current exact-SKU MISC catalog verification when needed by the current resolution path.

For Master-backed items:

- physical Master remains protected by Catalog Refresh Policy;
- current AceNet-owned fields may overlay the transient MISC snapshot;
- Retail Units remains library/default authority;
- complete current UPC evidence reconciles identity/canonical UPC according to policy.

For Local-backed items:

- current full catalog evidence applies through Local refresh/user-correction policy;
- refreshed Local row becomes the baseline for the MISC snapshot.

## UPC completeness states

- `VERIFIED_COMPLETE` — complete exact-SKU AceNet selector set verified; exportable.
- `VERIFIED_NO_ACENET_UPC_DATA` — exact SKU and all non-UPC required MISC fields verified, AceNet exposes no usable UPC selector/master UPC, and the current Library/relationship UPC set is retained as the best available set; exportable.
- `PENDING_ACENET` — unavailable/inconclusive verification; draft only.
- `NEEDS_USER_CONFIRMATION` — conclusive AceNet NOT_FOUND; user must confirm complete known UPC set.
- `USER_CONFIRMED_COMPLETE` — explicit user confirmation after NOT_FOUND; exportable.

MISC export accepts the three complete/exportable states.

Opening/exporting a pending saved MISC session may retry unresolved items when AceNet becomes available.

## Ordered UPC semantics

Complete exact-SKU selector evidence preserves unique UPC order.

First/default selector UPC is canonical/master under current relationship policy; later values are alternates.

Current relationships are persisted through `UPCIdentifierRelationshipService`.

`VERIFIED_NO_ACENET_UPC_DATA` does **not** replace, merge, or delete UPC relationships because AceNet did not provide a complete UPC set. The MISC snapshot overlays the verified live AceNet-owned non-UPC fields onto the existing Master/Local baseline and preserves the known current Library/relationship UPC order for export.

Duplicate ingestion is idempotent; cross-SKU relationships create explicit conflict state.

No additional AceNet request is issued merely to mirror already-verified MISC relationships into identity state.

## Canonical draft/snapshot

MISC stores the export-relevant canonical snapshot with the item.

Export uses that saved verified draft/snapshot; it must not silently reconstruct current user data from unrelated Master/Local state at export time.

Export rejects an item missing its canonical draft.

User edits that affect export update both visible draft fields and saved export snapshot/ordered UPC state.

## Catalog evidence

MISC catalog extraction uses the authoritative exact ItemDetail elements in `ACENET_ITEM_DATA_EXTRACTION_REFERENCE.md`.

OM Weight is required for MISC catalog completeness.

Classification breadcrumb-form Master/Local values are normalized to numeric Commodity Group / Merchandise Class / Product Group codes before canonical MISC mapping. Commodity Group continues through the existing POSDEPT mapping.

Retail Units remains Master → Local → default 1 and is not retrieved from AceNet.

## Bulk behavior

Bulk MISC processing is strictly sequential.

Manual and bulk MISC use the same resolver.

Each SKU reaches a terminal added/skipped/failed result; one failure does not abort later SKUs.

Already-present SKU is not duplicated.

A batch may operate without live AceNet only where current local/verification state genuinely satisfies the workflow; incomplete UPC evidence remains non-exportable.

## Additional verification action

The MISC-only “Verify UPCs with AceNet” action retries pending items through full exact-SKU MISC catalog retrieval.

Conclusive NOT_FOUND uses explicit user confirmation rather than pretending the selector set was observed.

Exact-SKU `FOUND_NO_UPC_DATA` does not ask the user to confirm a fictional AceNet UPC set. If a current Master/Local UPC is available, the item becomes `VERIFIED_NO_ACENET_UPC_DATA`; if no current Library UPC exists, verification remains blocked because no export UPC is available.

No analogous DSD additional-UPC action exists.

## Export

MISC export:

- emits one row per ordered known UPC for each SKU;
- retains one blank row between SKU groups;
- blocks incomplete verification;
- uses the canonical saved draft;
- delegates final file delivery to the standard platform file-delivery owner.

## Diagnostics and verification

Tests protect exact-SKU proof, stable NOT_FOUND classification, selector completeness, verified-no-UPC fallback without relationship mutation, Master/Local/AceNet order, Local persistence, runtime resolver ownership, manual/bulk convergence, classification normalization, canonical draft export, relationship ingestion, no promoted-Master fallback, and MISC-only verification UI.
