# AI START HERE

**Status:** CURRENT FIRST-STOP AUTHORITY

This repository is the active UPC List Builder source. Git history is the historical record; do not preserve obsolete implementations, handoff snapshots, transition ledgers, or research artifacts in the active tree merely as backup.

## Required reading chain

Before changing production code:

1. Read `CURRENT_ARCHITECTURE_AUTHORITY.md`.
2. Read `SOURCE_OWNERSHIP_MAP.md`.
3. Read the relevant directory `README.md` for the source area being changed.
4. Read the current subsystem contract(s) listed in `DOCUMENTATION_INDEX.md`.
5. If the work affects release/version/deployment/package/updater behavior, also read `RELEASE_VERSIONING_CONTRACT.md` and `DEPLOYMENT_CONTRACT.md`. Read `TERMUX_DEPLOYMENT_CONTRACT.md` only when the Termux fallback/recovery path is being used.

## REQUIRED current-architecture routing

`CURRENT_ARCHITECTURE_AUTHORITY.md` is the architecture authority for:
- source ownership;
- dependency direction;
- composition boundaries;
- state/side-effect/lifecycle ownership;
- architecture-stage status;
- allowed exceptions requiring later review.

`SOURCE_OWNERSHIP_MAP.md` answers where a responsibility belongs and which file/service owns it.

Behavioral contracts remain authoritative for product behavior inside their subsystem. Architecture documentation may relocate responsibility but may not silently redefine established product behavior.

## REQUIRED reading-chain rule

If a current authority or behavioral contract names another current document as required for the task, read that document before changing the governed behavior.

Do not follow references to deleted historical transition/handoff/research documents. Git history provides that evidence when regression reconstruction is genuinely necessary.

## Implementation rules

- One significant responsibility has one authoritative owner.
- Do not recreate behavior in a second module because it is convenient.
- Do not move code out of one oversized file into another catch-all.
- UI/workspace code depends on services/domain owners; services depend on repository/platform adapters; repositories adapt physical storage.
- Diagnostics are observational and must never become business authority.
- Web/native behavior crosses through the documented bridge/platform boundary.
- New feature code belongs in the directory named by its domain ownership guide.
- Tests verify current requirements; a stale test that freezes obsolete implementation location must be corrected rather than forcing architecture backward.
- Obsolete production code and obsolete documentation are deleted when safe. Git is rollback/history.

## Current architecture program

The New Architecture Upgrade has implemented and verified Stages 1–13.

Remaining:
- Stage 14: final verification/release, deployment, installation, and physical Android troubleshooting.

Do not begin a later stage until the current stage is verified and closed.

## Release/deployment rule

GitHub-native deployment is the normal release path. Use `DEPLOYMENT_CONTRACT.md` as the deployment authority: verify the exact candidate head, merge the verified head into `main`, follow the exact `main` push run to terminal success, and verify the public updater feed. Termux is fallback/recovery only and is governed by `TERMUX_DEPLOYMENT_CONTRACT.md` when explicitly selected.

Public updater publication remains main-only. Draft PRs may run verification/build/package checks but must not update the public updater feed.

## Project boundaries worth remembering

- `gradle.properties` is the authored release-identity authority.
- `scripts/sync-release-identity.mjs` derives static web identity copies and verification rejects drift.
- `MainActivity.kt` is Android lifecycle/WebView/bridge composition, not a native feature monolith.
- `application/application-shell.js` is web composition, not a business-logic owner.
- `AceNetProductionCoordinator.kt` is a reviewed native session/request state-machine exception; further splitting requires a proven independent state boundary.
- Work Session physical persistence belongs to `work-sessions/work-session-repository.js`; workflow mutation belongs to `work-sessions/work-session-service.js`.
- Product identity/catalog changes must read `PRODUCT_DATA_AUTHORITY_CONTRACT.md`; research/deferred-refresh changes must also read `IDENTITY_RESEARCH_RESOLUTION_CONTRACT.md`. AceNet is live authority for current Ace merchandise fields it exposes, Master is the offline/enriched snapshot of the same upstream Ace data, third-party Local records cover the non-Ace portion of store merchandise, and scans/manual identifiers are lookup keys rather than competing catalog sources.
- `skuUpcs` is current relationship state only. Do not add historical/retired UPC↔SKU fallback data without a newly approved business requirement.
- UPC Enrichment is subordinate to AceNet Comparison: enrichment may be turned off independently, but must never operate while AceNet Comparison is off.
- DSD and MISC domain semantics remain separate.
- New store-location and planogram import contracts: read `STORE_LOCATION_CONTRACT.md` and `PLANOGRAM_IMPORT_CONTRACT.md` before implementing either Build 1 or Build 2. At B1.0 these are **contract authorities only**; the importer, location registry, and lookup feature are not yet deployed.
- Structured diagnostics use operation/span evidence with bounded web/native retention and must remain observational.

## Documentation authority

Use `DOCUMENTATION_INDEX.md` to locate current contracts. If documentation and source disagree, investigate and correct the inconsistency; do not document a contradiction as if it were intentional.

Historical chronology belongs in Git commits/tags/releases, not active source comments or root Markdown archives.
