# Application Data Backup / Restore Contract

> **REQUIRED REFERENCE RULE:** Read `AI_START_HERE.md`, `CURRENT_ARCHITECTURE_AUTHORITY.md`, `REPOSITORY_BOUNDARIES_CONTRACT.md`, and `NATIVE_ANDROID_BRIDGE_CONTRACT.md` before changing backup/restore.

**STATUS: CURRENT**

## Purpose

Provide a user-controlled, independently verifiable snapshot/restore of durable web application data.

Backup is recovery protection, not a second application datastore and not a diagnostic archive.

## Included durable stores

The backup contains complete data for:

- `lists`;
- `library`;
- `meta`;
- `libraryUpdateQueue`;
- `skuUpcs`;
- `skuIdentity`;
- `upcIdentityResolution`;
- `identityResearchQueue`.

Diagnostics are excluded.

AceNet passwords, cookies, authentication tokens, Android Keystore material, and native credential/session secrets are excluded.

## Format

Every backup includes:

- stable format ID/version;
- application-data schema version;
- created timestamp;
- running release version/build ID;
- IndexedDB database name/version;
- deterministic ordered store manifest;
- per-store and total record counts;
- explicit diagnostics/credentials exclusions;
- complete records for every required store.

A generated backup must validate before delivery.

## Restore validation

Before confirmation or mutation, reject:

- malformed JSON;
- unknown format/version;
- unsupported application-data schema;
- wrong IndexedDB database;
- backup requiring a newer DB version;
- missing/extra/reordered required-store declaration;
- missing/non-array payload;
- manifest/count mismatch;
- failure to declare diagnostics/credentials excluded.

Rejected validation changes no current data.

## Atomic restore

After successful validation and explicit user confirmation, restore replaces all required stores in one multi-store IndexedDB read/write transaction.

Any clear/write failure aborts the transaction.

A failed restore must not leave mixed old/restored state.

Successful restore reloads the application so in-memory state cannot continue from pre-restore data.

## Delivery

The backup controller gives validated JSON plus filename/MIME metadata to `platform/file-export-delivery-service.js`.

That platform owner uses the existing native `AndroidNative.exportFile` capability or browser Blob fallback.

Backup does not implement duplicate delivery mechanics or broaden native filesystem access.

## UI safeguards

Settings exposes separate Export Data Backup and Restore Data Backup actions.

Restore requires selected file, successful validation, summary, and explicit confirmation that current saved application data will be replaced.

## Verification

Tests protect deterministic manifest/counts, generated-backup validation, malformed/incompatible rejection before mutation, excluded secrets/diagnostics, atomic replacement, injected-failure rollback, release identity, settings wiring, and standard file-delivery delegation.


## Location storage backup boundary (B1.2)
New current authoritative location stores `storeAreas`, `storeModulars`, `storeSources`, `storeSourceMembers`, `storePlacements`, `storeHistory`, and `storeImportReceipts` are included in the complete-data manifest. The backup data schema is 2, and backup format is 2. A pre-location backup with schema 1 is **rejected before opening a write transaction**, with an explanatory error. It must never silently erase live locations. This is an explicit protection, not a historical location migration. All included stores are replaced together in one atomic transaction. The `diagnostics` exclusion and credentials exclusion remain unchanged.
