# Application Lifecycle / Background-Resume Contract

> **REQUIRED REFERENCE RULE:** Read `AI_START_HERE.md`, `CURRENT_ARCHITECTURE_AUTHORITY.md`, `ACENET_AUTH_SESSION_CONTRACT.md`, `ACENET_SESSION_RETRIEVAL_BOUNDARY_CONTRACT.md`, and `DIAGNOSTICS_CONTRACT.md` before changing lifecycle behavior.

**STATUS: CURRENT — automated verification complete; final physical Android validation pending**

## Purpose

Prevent Android background/foreground transitions, startup prerequisites, and update/install transitions from creating false AceNet health evidence, reviving stale requests, or racing version-sensitive startup work.

## Startup prerequisite ordering

Cold application startup is serialized:

1. resolve application update status;
2. if the current build continues, complete required local-data migration/preparation;
3. establish Master/Local catalog readiness;
4. explicitly release native AceNet startup verification;
5. bound transient AceNet authentication/retailer-readiness work to the native startup session-readiness window rather than allowing an unbounded SSO navigation wait;
6. if retailer readiness succeeds in time, allow retained-worker proof to run under its separate item-attempt timing policy;
7. release the main application after AceNet reaches ONLINE, DOWN, or operationally UNAVAILABLE for this startup.

Android page-load completion must not independently start updater and AceNet authentication in parallel.

If an installer is launched for a newer verified build, the old process must not begin AceNet/version-sensitive migration work merely to be replaced. If update installation is deferred/cancelled, the current build may continue the normal prerequisite chain.

Required migration/preparation owns splash priority while active.

## Background and foreground behavior

- Android lifecycle movement is not evidence that AceNet is DOWN.
- `onPause`/`onResume` alone do not reset AceNet or create duplicate network work.
- When the Activity becomes fully non-visible during startup, the in-flight AceNet startup WebView/worker remains owned by the same coordinator and is allowed to continue while the application process survives.
- Foreground return does not automatically replace a still-running retained startup request.
- If retained startup work reaches ONLINE while backgrounded, that verified result remains authoritative.
- If retained startup work reaches a non-ONLINE operational terminal result while backgrounded, exactly one foreground warm-up revalidation is required before that background-associated failure becomes the current usable-service conclusion. Authoritative DOWN evidence remains authoritative.
- A non-startup request interrupted by full backgrounding continues to receive explicit `INTERRUPTED` terminal evidence under the existing production lifecycle rule.
- Backgrounding with no request in flight does not log out, destroy credentials, clear lists/settings, change feature state, or manufacture health evidence.
- Process/Activity destruction remains a legitimate boundary; a later cold start creates new startup ownership rather than reviving destroyed process state.

## Retained worker lifecycle

An idle, ready persistent retailer worker is retained across harmless background/foreground transitions while the Activity remains alive and current session evidence remains reusable.

An active retained-worker lookup interrupted by full backgrounding must not start the ordinary recovery/fallback path while the application is non-visible.

If the worker is genuinely absent/unready on foreground return, it may be re-primed through the retained authenticated session when that session remains reusable.

Process/Activity destruction, authentication loss, worker failure, explicit invalidation, or stale session evidence remain legitimate destructive/recovery boundaries.

## Session-age behavior

Cold Activity startup follows one authoritative startup sequence and must not race a competing foreground re-warm.

Later foreground resumes may reuse an idle ready worker only when current AceNet session evidence is still reusable.

At/beyond the conservative refresh threshold, in-memory authentication flags alone are insufficient; the session follows the fresh session/warm-up path.

Brief background/foreground transitions below the threshold may retain the current worker/session optimization when otherwise valid.

Backgrounding itself never creates DOWN evidence.

## Fresh-session generation

Cold startup creates one fresh AceNet WebView session generation and follows normal STS authentication. Expected STS redirects caused by session clearing do not create a second generation.

A later foreground revalidation after a background-associated non-ONLINE startup result reuses the existing bounded warm-up/session recovery owner; process destruction or an actually stale/unusable session may create a new generation.

## Ownership

`MainActivity` owns Android lifecycle callbacks.

AceNet-specific lifecycle semantics are delegated to `AceNetProductionCoordinator`, which owns the request/session state those decisions consume.

`AceNetSessionManager` owns reusable-session state/timestamps.

`AceNetRetrievalService` / `PersistentAceNetWorker` own retained-worker lifecycle as defined by the session/retrieval contract.

Update-installer resume behavior belongs to `AppUpdateService`.

Lifecycle code must not reconstruct those states in `MainActivity`.

## Diagnostics

Record:

- foreground/background transitions;
- time away when known;
- whether a request was active;
- request kind/phase;
- whether startup work was retained across backgrounding;
- explicit absence of a lifecycle-created health decision;
- whether retained startup was still active or had completed on foreground return;
- one foreground revalidation when a backgrounded startup completed non-ONLINE;
- worker retained/interrupted/re-primed decisions.

Backgrounded startup appears as one timed `ANDROID_BACKGROUND_STARTUP` operation whose observations cover background entry, retained request ownership, foreground return, continued execution, terminal retention, or one bounded foreground revalidation.

This observability is diagnostic-only and must not alter lifecycle or AceNet operational behavior.

`navigator.onLine` is network-interface evidence only; it must not be represented as proof of Internet/AceNet reachability.

Inferred item-page failures, timeouts, or missing values may terminate/degrade the affected operation but do not manufacture global server-DOWN evidence. Observed main-frame 500/502/503/504 evidence remains subject to the current service-health contract.

## Verification

Automated tests must protect:

- no false DOWN on lifecycle interruption;
- startup retention across backgrounding and one bounded foreground revalidation after a background-associated non-ONLINE terminal result;
- active non-startup interruption terminalization;
- idle worker retention;
- stale-session refresh behavior;
- absence of duplicate cold-start warm-up;
- prerequisite ordering;
- delegation from `MainActivity` to focused owners;
- diagnostic-only observability.

Final physical validation must include background during startup, foreground recovery, idle background/return, stale-session resume, and interrupted active lookup behavior.
