# Catalog Field Mapping Contract

> **REQUIRED REFERENCE RULE:** Read `AI_START_HERE.md`, `CURRENT_ARCHITECTURE_AUTHORITY.md`, and the affected catalog contract before changing field mapping.

**STATUS: CURRENT**

## Purpose

Protect canonical catalog-field meanings while normalizing representation. Mapping may normalize aliases/format; it must not invent facts or silently exchange meanings between fields.

## Canonical meanings

A resolved item may carry:

- UPC;
- SKU;
- description;
- Library/AceNet/Label price values according to price authority;
- Order Multiple;
- Retail Units;
- catalog record identity/provenance;
- preserved source `fields`.

UPC and SKU remain distinct identifiers under `IDENTIFIER_RESOLUTION_CONTRACT.md`.

`Retail Units` and `Order Multiple` are distinct. OM is never substituted for RU.

## Accepted catalog aliases

Reusable aliases include:

- description: `Description`, `Article Description`;
- cost: `Retailer Each Cost`, `Cost`;
- manufacturer number: `MFG #`, `Manufacturer Number`, `MFG Number`;
- order multiple: `Order Multiple`;
- weight: `Weight`, `OM Weight`;
- Ace retail price: `Ace Retail Price`, `Retailer Each Price`, `Price`;
- retail units: `Retail Units`;
- commodity group: `Commodity Group`;
- merchandise class: `Merchandise Class Number`, `Merchant Class`, `Merchandise Class`;
- product group: `Product Group Number`.

Unknown source fields remain preserved where the source record/workbook preserves them.

## Current owners

`catalog/standard-export-schema.js` / `UPCStandardExportSchema` owns two pure field-identity contracts: `MASTER_HEADERS`, the 30 columns present in the supported Master Library and selectable for ordinary exports, and `ACE_MISC_HEADERS`, the exact 33-column ACE MISC header sequence. The three MISC-only headers are `POSDEPT`, `VENDOR`, and `S/O (72) Y`; they are not selectable Master-field checkboxes. The schema owns no workbook composition, Settings persistence, MISC row/validation semantics, or file delivery.

`catalog/catalog-mappers.js` / `UPCCatalogMappers` owns reusable representation helpers including:

- canonical Local field aliases;
- header lookup;
- AceNet weight normalization;
- Local classification-code normalization.

It is pure mapping code with no storage, network, refresh-policy, or UI authority.

## Boundaries

AceNet enrichment may supplement catalog evidence only after exact-SKU verification under current retrieval/refresh policy.

This contract does not own:

- persistence;
- import/generation activation;
- AceNet transport/extraction;
- Retail Units derivation;
- price authority;
- lookup orchestration;
- UI presentation.

## Verification

Tests protect alias acceptance, field separation, source-field preservation, and the prohibition on RU/OM conflation or mapper-owned side effects.
