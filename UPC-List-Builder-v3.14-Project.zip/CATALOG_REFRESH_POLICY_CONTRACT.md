# Catalog Refresh Policy Contract

> **REQUIRED REFERENCE RULE:** Read `AI_START_HERE.md`, `CURRENT_ARCHITECTURE_AUTHORITY.md`, `EFFECTIVE_CATALOG_RESOLVER_CONTRACT.md`, `IDENTIFIER_RELATIONSHIP_SERVICE_CONTRACT.md`, `MASTER_LIBRARY_CONTRACT.md`, `ACENET_ITEM_RETRIEVAL_CONTRACT.md`, and `ACENET_SESSION_RETRIEVAL_BOUNDARY_CONTRACT.md` before changing catalog refresh behavior.

**STATUS: CURRENT**

## Purpose

`UPCCatalogRefreshPolicy` is the single decision owner for applying verified AceNet evidence to catalog/relationship state.

Retrieval supplies evidence. Policy decides permitted actions. `UPCCatalogRefreshService` executes the policy through Master/Local repositories and `UPCIdentifierRelationshipService`.

The service does not call raw `UPCDB`.

## Exact-SKU gate

No catalog mutation plan is applicable unless:

- returned SKU exactly matches requested SKU; and
- the caller explicitly marks the evidence exact-SKU verified.

Timeout, unavailable, mismatch, parse failure, supersession, ambiguity, or other unverified/inconclusive evidence cannot mutate catalog data.

## Official Master Library

Official Master is an imported snapshot, not a routine AceNet-enrichment destination.

Fresh verified AceNet price may govern current presentation/comparison, but is not persisted to the Master row.

AceNet must not rewrite official Master:

- description;
- Retailer Each Cost;
- Manufacturer Number;
- Order Multiple;
- Retail Units;
- OM Weight;
- Ace Retail Price;
- Commodity Group;
- Merchandise Class Number;
- Product Group Number.

The only AceNet-driven persistent Master mutation is canonical UPC correction proven by a complete exact-SKU UPC set.

That correction must:

- update the mapped UPC/EAN field;
- update matching `upcKey` and `originalUPC`;
- preserve SKU and all unrelated Master fields;
- abort if the target record/generation/SKU no longer matches;
- reject collision with another active Master SKU.

Local rows are never copied/promoted into Master by refresh policy.

## Local Library

Verified full-catalog evidence may create a new durable Local record or refresh a current Local record.

AceNet-refreshable Local fields are:

- Retailer Each Cost;
- Manufacturer Number;
- Order Multiple;
- OM Weight;
- Ace Retail Price;
- Commodity Group;
- Merchandise Class Number;
- Product Group Number.

Description is fill-only during ordinary refresh: AceNet may fill a missing description but does not replace an existing Local description.

User corrections outrank automated refresh.

Retailer Each Cost accepts the current normalized numeric forms, including decorated AceNet labels, but must reject missing/nonnumeric/negative values where required.

Retail Units is never AceNet-authoritative. It remains Master → Local → default 1.

## Partial repair

`VERIFIED_PARTIAL` repair evidence may apply positively verified returned mutable fields.

A missing field is not deletion evidence. Missing partial evidence preserves stored values.

User corrections remain protected.

Partial UPC evidence may merge observed relationships but must not:

- delete relationships absent from the partial response;
- change canonical Master UPC;
- retire existing current relationships.

## Complete UPC evidence

For complete exact-SKU verified UPC evidence:

- first/default ordered UPC is canonical;
- complete ordered set replaces the prior current SKU UPC set through `UPCIdentifierRelationshipService`;
- former canonical UPC remains secondary only if still returned;
- absent prior UPCs are removed from current membership and become reusable;
- Master or Local canonical UPC may be corrected through the appropriate guarded repository path.

## ACE MISC consumer behavior

ACE MISC consumes this policy; it does not broaden persistence authority.

For a known official Master SKU, a verified full exact-SKU MISC catalog may overlay current AceNet-owned fields into the transient MISC working/export snapshot while leaving the physical Master row protected except for the guarded canonical UPC correction.

For a Local SKU, full catalog evidence applies through the Local mutation/user-correction policy before the refreshed row becomes the MISC baseline.

MISC verification states remain:

- `VERIFIED_COMPLETE` — complete exact-SKU AceNet selector set; exportable;
- `PENDING_ACENET` — unresolved/inconclusive; draft only, not exportable;
- `NEEDS_USER_CONFIRMATION` — conclusive AceNet NOT_FOUND; user confirmation required;
- `USER_CONFIRMED_COMPLETE` — user confirmed complete known UPC set after NOT_FOUND; exportable.

Only the two complete states are export authority.

## Diagnostics

Diagnostics must expose:

- policy accepted/rejected;
- exact-SKU gate outcome;
- target layer;
- bounded per-field action classes;
- canonical UPC change attempts/results;
- relationship replacement/merge counts;
- Local creation/update/read-back;
- user-correction preservation;
- partial missing-field handling;
- collision/generation/record/SKU guard failures;
- MISC reconciliation outcome.

Diagnostics must not record credential secrets.

## Verification

Maintained tests protect:

- exact-SKU mutation gate;
- official Master protection;
- guarded Master UPC correction;
- Local mutable-field policy;
- user corrections;
- Retail Units authority;
- complete relationship replacement;
- partial non-destructive merge;
- verified new Local creation;
- MISC snapshot/persistence boundaries;
- execution through `UPCCatalogRefreshService`, not application shell/raw database.
