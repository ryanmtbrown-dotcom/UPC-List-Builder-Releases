# Combined Master Export Contract

> **REQUIRED REFERENCE RULE:** Read `MASTER_LIBRARY_CONTRACT.md`, `REPOSITORY_BOUNDARIES_CONTRACT.md`, and `SOURCE_OWNERSHIP_MAP.md` before changing Combined Master Export.

**STATUS: CURRENT**

## Purpose

Produce a read-only interoperability workbook containing official Master rows plus eligible Local-only rows without changing either physical catalog layer.

`UPCCombinedMasterExport` is the sole composition owner.

## Inputs

Read only:

- active Master metadata/header mapping;
- active official Master rows;
- durable Local Library rows.

Do not call AceNet, refresh catalog fields, mutate relationships, or mutate Master/Local persistence.

## Composition

Official Master has precedence.

For each Local row:

- if normalized SKU overlaps official Master, suppress Local from output;
- if canonical UPC overlaps official Master, suppress Local from output;
- otherwise append the Local-only row once;
- ambiguous duplicate Local identity is a hard error.

Current active Master contains official rows only; no promoted-Master compatibility classification/filter exists.

## Workbook schema

Use preserved active Master `meta.headers` in exact order.

Official rows preserve stored source fields, including unknown fields.

Local-only rows project available values into those headers and leave unavailable source columns blank.

Current mapped Master SKU/UPC columns remain identifier columns.

Secondary UPC relationships do not create duplicate Combined Master catalog rows.

The export guarantees schema/value interoperability required by the separate Excel workflow; it does not claim byte-for-byte preservation of unsupported original workbook package/style/formula/sheet content.

## Filename and delivery

Filename is user-editable.

Suggestion derives from imported Master filename plus `-Combined.xlsx`.

Workbook generation uses shared `XLSXExporter`.

Validated bytes/metadata are handed to the standard web file-delivery owner, which uses native `AndroidNative.exportFile` or browser fallback.

Combined Master does not own platform delivery.

## Diagnostics

Required bounded events:

- `combined_master_export_composed`;
- `combined_master_export_started`;
- `combined_master_export_completed`;
- `combined_master_export_failed`.

Suppressed identity evidence is sampled/bounded.

## Failure behavior

Missing active Master/mappings, missing required Local identity, ambiguous Local identity, workbook generation failure, or file delivery failure stops export without persistence mutation.

## Verification

Tests protect official precedence, Local-only inclusion, overlap suppression, exact header order, unknown official field preservation, read-only ownership, async workbook generation, diagnostics, and standard delivery delegation.
