# UPC List Builder — Current Architecture Authority

**Status:** CURRENT AUTHORITY  
**Release baseline:** current release identity is authored by `gradle.properties`  
**Current architecture checkpoint:** Stages 1–13 implemented and verified; Stage 14 physical Android troubleshooting and closure are in progress  
**Authority companion:** `SOURCE_OWNERSHIP_MAP.md`

## REQUIRED REFERENCE RULE

Read `AI_START_HERE.md`, this document, `SOURCE_OWNERSHIP_MAP.md`, the affected directory ownership README, and current subsystem contract(s) before changing architecture or responsibility placement.

## Authority order

1. Current explicit user instruction.
2. `AI_START_HERE.md`.
3. This architecture authority.
4. `SOURCE_OWNERSHIP_MAP.md` for responsibility/source placement.
5. Current behavioral contract(s) for affected behavior.
6. Current source as implementation evidence.
7. Maintained tests as verification evidence.
8. `DEPLOYMENT_CONTRACT.md` for release/deployment; `TERMUX_DEPLOYMENT_CONTRACT.md` only for the Termux fallback/recovery path.

Tests do not create product behavior and do not freeze obsolete filenames.

## Architectural model

### Web application
`app.v059.js` is a minimal bootstrap. `application/application-shell.js` is the composition root.

Dependency direction:
`UI/workspace controller → application/domain service → repository/platform adapter → physical infrastructure`.

The shell constructs owners and injects dependencies. It must not reclaim feature business logic.

Presentation ownership follows the same boundary discipline. `styles.v059.css` owns the shared portrait-first design system, tokens, shell/home/builder/settings/list primitives, and cross-surface visual consistency. Focused stylesheets under `application/`, `dsd/`, `administration/`, and `misc/` retain their own presentation scope and consume shared tokens without moving behavior or state ownership.

### Persistence
`db.js` owns raw IndexedDB mechanics. Focused repositories own physical store adaptation. Workflow/domain code mutates durable state only through approved service/repository boundaries.

Important owners:
- Master: `master-repository.js`
- Local: `local-repository.js`
- identity: `identity-repository.js` + `identifier-relationship-service.js`
- Work Sessions: `work-sessions/work-session-repository.js` + `work-sessions/work-session-service.js`
- diagnostics: `diagnostics/diagnostic-repository.js`

### Lookup/catalog
Normal lookup orchestration belongs to `lookup/normal-lookup-controller.js`. Presentation, image lookup, manual input, local identifier resolution, Effective Catalog selection, catalog refresh, and relationship persistence remain separate focused owners.

`catalog/standard-export-schema.js` owns two explicit field-identity contracts: the 30 Master Library columns selectable for ordinary exports and the exact 33-column ACE MISC header sequence. `ace-misc.js` owns the exact ACE MISC row/layout formatter, including UPC row expansion and separator rows. Field Session Export may invoke that formatter only when the durable Force ACE MISC Format preference is enabled. The schema does not own workbook composition or preference persistence.

### Product data authority and identity resolution
Product authority is governed by `PRODUCT_DATA_AUTHORITY_CONTRACT.md` and `IDENTITY_RESEARCH_RESOLUTION_CONTRACT.md`.

- AceNet is the live upstream authority for current Ace merchandise fields exposed through the user-facing system, including complete current secondary-UPC membership for an exact SKU.
- Master Library is the offline/enriched snapshot of the same underlying Ace data and remains the primary offline Ace catalog authority when live AceNet cannot be used.
- Ace-derived Local records are persisted Ace data and remain subordinate to newer verified AceNet evidence.
- `THIRD_PARTY_VENDOR` Local records cover the non-Ace portion of store merchandise; AceNet absence alone does not invalidate them.
- Scanned/manual UPCs and SKUs are lookup keys/observations, not independent catalog authorities.
- Official Ace SKU identity outranks conflicting locally generated SKU identity.
- `skuUpcs` is current-state identity only; complete current AceNet evidence may retire prior relationships and no historical identity fallback is retained merely for historicity.
- Items Needing Research is an actionable resolution workspace. Deferred live refresh is SKU-keyed current work and may dispatch only when AceNet Comparison is enabled.
- UPC Enrichment is a subordinate capability of AceNet Comparison: it may be disabled independently, but it cannot operate while the parent live-AceNet capability is off.

### DSD and MISC
ACE New DSD and ACE MISC are independent workspaces/domains.
- Optional external ChatGPT/MCP invoice submission is an isolated, default-disabled adapter under `dsd/`; it stages untrusted invoice data and hands an editable draft directly to the existing DSD Work Session, domain-validation, and export boundaries. The ChatGPT adapter owns pairing, pending listing and rejection, not a duplicate invoice/item editor. It never mutates AceNet, Master, Local, or identifier authority.
- The independent `integrations/chatgpt-mcp/` service owns OAuth-protected, user-isolated pending batches and device pairing; Android stores the per-device token in a dedicated Keystore-backed `ChatGPTConnectionVault`, not in AceNet credential storage. No imported invoice is authoritative until saved by the local DSD workflow.
- DSD domain/workbook rules: `ace-dsd.js`
- DSD workspace: `dsd/dsd-workspace-controller.js`
- MISC domain primitives: `ace-misc.js`
- MISC draft/resolution/verification/maintenance/workspace: focused files under `misc/`

Do not reconstruct MISC data from unrelated Master/Local state at export time. Sharing the neutral standard field identity does not merge MISC workbook semantics with ordinary Field Session export behavior.

### Planned store locations and planogram import (B1.0 contracts only)
`STORE_LOCATION_CONTRACT.md` and `PLANOGRAM_IMPORT_CONTRACT.md` govern the upcoming two-build location feature. B1.0 contracts, B1.1 pure policy, B1.2 IndexedDB repository and backup safeguards, B1.3 location maintenance UI, and B1.4–B1.5 candidate plugin/device import modules have been authored on the isolated feature branch. Cloudflare migration/deployment and Android production release have not been authorized. Proposed pure location policies, focused location repository, app UI, and isolated planogram server validator/queue must respect the current dependency direction and preserve existing DSD/price/catalog authority. These contracts do not authorize live deployment.

### Native Android
`MainActivity.kt` owns Android lifecycle, WebView hosting, one `AndroidNative` bridge, and focused native-owner composition.

Focused native owners include updater, file export, diagnostics, scanner, product-image search, AceNet session/retrieval/extraction/classification/incident handling.

`AceNetProductionCoordinator.kt` remains the reviewed exception for the interdependent AceNet production/session request state machine. Stage 13 re-reviewed it below the hard 2,300-line ceiling and reconfirmed that the remaining coordination state is too lifecycle-coupled for a safe ownership split. Further extraction requires a proven independent state/lifecycle/input-output/error-recovery boundary.

### Platform support
Android APK is the native release target. The non-native browser/PWA install/service-worker path remains supported/isolated because no product decision has deprecated it.

`gradle.properties` is the single authored release identity. Native runtime uses generated `BuildConfig.UPC_BUILD_ID`; static web copies are synchronized by `scripts/sync-release-identity.mjs`.

Ordinary web file delivery is a platform concern owned by `platform/file-export-delivery-service.js`. Domain/application exporters prepare validated content and metadata; the platform adapter alone chooses the existing native `exportFile` bridge or browser Blob fallback. Diagnostic export remains specialized under the diagnostics subsystem.

Global native callbacks register only through `platform/bridge-registration.js`. Native AceNet startup/health state is projected into web runtime state by `application/acenet-startup-service.js`; native classification remains in the native AceNet owners and Settings retains feature/UI policy.

### Diagnostics
Structured diagnostics use canonical schema-v2 operation/span records.

Web:
- schema/sanitization/scoping: `diagnostics/diagnostic-service.js`
- retention/batching: `diagnostics/diagnostic-journal.js`
- IndexedDB store access: `diagnostics/diagnostic-repository.js`
- operation adapter: `diagnostics/diagnostic-operation-service.js`
- export/reconstruction: `diagnostics/diagnostic-export-service.js`

Native:
- persistence/retention: `NativeDiagnosticJournal.kt`
- formatting/redaction: `NativeDiagnosticRecordFormatter.kt`

Diagnostics never create lookup, authentication, health, persistence, or UI business truth.

## State, side effects, lifecycle, and workflow ownership

The authoritative detailed map is `SOURCE_OWNERSHIP_MAP.md`. It defines:
- state owner/read/mutation boundaries;
- approved network/storage/native/DOM/timer side-effect owners;
- lifecycle-resource ownership;
- major web/native and domain/persistence boundaries;
- critical workflow maps.

A source change that contradicts that map requires an intentional architecture change and same-change documentation/test updates.

## Source documentation rule

Every substantive first-party production JS/CSS/Kotlin source file carries one concise `OWNERSHIP:` header identifying file, owner, role, responsibility, non-ownership, side effects, and related placement.

Major source directories carry README scope documentation.

Do not create broad ownership language merely to justify a mixed-responsibility file. Mixed ownership discovered during review must be separated when safe or explicitly carried to the next approved architecture stage with a concrete reason.

## Obsolete-code/documentation rule

Git is the historical record. Active source must not retain:
- deprecated implementations with no supported requirement;
- old/new duplicate systems;
- stale migrations with no supported migration target;
- obsolete tests/docs;
- commented-out historical implementations;
- transition/handoff/research files retained only as backup.

Stage 13 completed the repo-wide structural cleanup/audit. Future obsolete material must be deleted when safe or carried only under an explicit current requirement with ownership evidence.

## Verified architecture-stage status

Completed and verified:
1. current-state authority/test decoupling;
2. Work Session ownership;
3. catalog/data-management ownership;
4. normal item-lookup pipeline;
5. DSD and MISC independent workspaces;
6. web monolith decomposition;
7. native Android decomposition;
8. release identity/platform support boundary;
9. ownership-aligned UI/style extraction;
10. DSD firearm-department control;
11. structured diagnostics/observability;
12. source/ownership documentation, directory scope, current-document reconciliation, and automated ownership enforcement;
13. final structural cleanup/architecture audit.

Stage 13 closure audit confirmed:
- all 101 first-party production JS/CSS/Kotlin files have enforced current ownership documentation;
- no duplicate business owner remained after the repo-wide state/side-effect/lifecycle audit;
- ordinary file delivery is centralized behind one web platform adapter while diagnostic export remains intentionally specialized;
- active behavioral contracts describe current behavior rather than version/stage amendment history;
- supported migration code remains only where a current migration requirement still exists;
- `AceNetProductionCoordinator.kt` remains the reviewed state-machine exception at or below the enforced hard 2,300-line ceiling because no safe independent state/lifecycle/error-recovery split has been proven. The verifier, rather than a hard-coded historical line count in this document, is the current size authority.

Remaining:
14. final verification/release, deployment, installation, and physical troubleshooting.

## Verification cadence

Substantive architecture code changes require targeted checks during implementation and one full maintained verifier at stage end. Native/build/package checks are required when the stage touches those boundaries. Avoid repeated full release simulation for documentation-only changes unless executable verification/build machinery also changed.

Stage 13 completed the deeper repo-wide structural audit. Stage 14 performs the final release/deployment/physical-device path.

## Scope-safe stopping rule

Do not advance to a later architecture stage while the current stage has an unresolved substantive verification failure. A clean stage boundary is the preferred handoff point.
