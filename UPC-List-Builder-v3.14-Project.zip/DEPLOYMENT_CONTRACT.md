# UPC List Builder Deployment Contract

**STATUS: CURRENT DEPLOYMENT AUTHORITY**

## Purpose

Define the authoritative release/deployment path for UPC List Builder. GitHub-native deployment is the normal release path. Termux is a fallback/recovery path only.

This contract governs release verification, merge-to-main deployment, exact-run proof, public updater publication, final project-archive integrity, and deployment failure handling.

## Required references

Before release/deployment work, read:
- `AI_START_HERE.md`;
- `RELEASE_VERSIONING_CONTRACT.md`;
- `UPDATER_SETUP.md`;
- `verify-project.sh`;
- `package-release.sh`;
- `.github/workflows/build-apk.yml`.

Read `TERMUX_DEPLOYMENT_CONTRACT.md`, `install-release-termux.sh`, and `deploy-termux.sh` only when the Termux fallback/recovery path is actually being used.

## GitHub-native deployment — normal path

1. Prepare the changed release on a branch derived from the intended current `main` base.
2. Advance the deployable release identity in `gradle.properties` and synchronize derived web identity with `scripts/sync-release-identity.mjs`.
3. Run targeted checks while implementing. The complete maintained verifier must pass before release.
4. Open a pull request against `main`. The exact PR head SHA is the candidate identity.
5. Require the exact PR-head workflow run to pass the maintained verifier, release-authority load, Android dependency resolution, signed APK build, release APK preparation, `package-release.sh` final ZIP audit, and verified workflow-artifact upload.
6. A draft PR must not publish the stable public updater feed. Candidate-only publication, when intentionally enabled, must never replace `update.json` or `UPC-List-Builder-latest.apk`.
7. Before merging, confirm the PR head has not moved since the successful candidate run. Merge the exact verified head into `main`.
8. Capture the resulting `main` commit SHA and verify the repository's `main` branch points to that exact SHA.
9. Locate the push-triggered `build-apk.yml` run whose `head_sha` exactly equals that `main` SHA. Never infer deployment success from the newest run, a fixed delay, or a run for another SHA.
10. Follow that exact run to terminal completion.
11. Require `Publish public updater feed` to complete successfully on that exact `push` run. The workflow condition `github.event_name == 'push' && github.ref == 'refs/heads/main'` is the stable publication boundary.
12. Read the public release repository's `update.json` after publication. Confirm version, versionCode, build ID, APK SHA-256, and APK byte size match the verified release output.
13. Only after both the exact `main` run and public feed verification succeed may the release be reported as publicly deployed.

## Retained stable rollback evidence

The main-push publication step must verify the *previous* public `update.json`
SHA-256 and APK byte size before replacing `UPC-List-Builder-latest.apk`.
It retains the previous APK and exact metadata as versioned files, for example
`UPC-List-Builder-v3.00-Rollback.apk` and `UPC-List-Builder-v3.00-update.json`.
If the prior feed and binary disagree, or an existing versioned rollback copy disagrees,
publication stops without modifying the public updater feed. Source commit history
remains the rollback implementation authority; a rollback to an older implementation
for already-upgraded Android installations must advance versionCode in a new release,
not attempt to install a lower versionCode over a higher one.

## Public updater boundary

The stable updater feed is owned by the push-to-`main` workflow. Pull-request verification may build, package, and upload private workflow artifacts, but it may not publish the stable updater feed.

## Final project-archive integrity gate

A deployable project ZIP is not complete until the final ZIP itself passes `package-release.sh`. The gate must include hidden deployment files, exclude `.git` and generated `release-out` installers/metadata (delivered as separate release artifacts), reopen the finished ZIP, extract to a clean directory, rerun `verify-project.sh`, and calculate SHA-256 only after that audit passes.

Required-entry and forbidden-entry checks must operate on the captured archive-entry set without an early-closing producer→`grep -q` pipeline under `set -o pipefail`; a successful match must never be misclassified as missing because the producer receives SIGPIPE.

## Verified workflow artifact handoff

Successful verification/build runs upload the verified release artifact defined by the workflow: the exact audited project ZIP, signed versioned APK, and generated updater metadata. Artifact upload is evidence/handoff only; it does not itself publish the stable updater feed.

## Failure handling

- Do not merge a candidate whose exact PR-head run failed.
- Do not claim deployment while the exact `main` run is queued, in progress, cancelled, or failed.
- Inspect the exact failed step/log and correct the evidence-based cause.
- Do not bypass verifier/build/package/publication gates with a different APK or manual updater copy.
- A transport/status-query failure is not evidence that the build failed; re-read the exact run state.

## Termux fallback / recovery

Termux is not the default deployment path. Use it only when the user explicitly requests it or the GitHub-native path is unavailable and a local authenticated recovery path is required.

When Termux is selected, `TERMUX_DEPLOYMENT_CONTRACT.md` is the detailed executable procedure.

## User-facing release handoff

For normal GitHub-native deployment, do not require the user to run Termux commands. Report the exact candidate and `main` SHAs, exact workflow-run results, public updater verification, and provide the complete audited project ZIP with each release/update. Provide the signed APK when useful for physical testing.
