# Diagnostics Contract

> **REQUIRED REFERENCE RULE:** Read `AI_START_HERE.md`, `CURRENT_ARCHITECTURE_AUTHORITY.md`, and `SOURCE_OWNERSHIP_MAP.md` before changing diagnostic ownership.

**STATUS: CURRENT — structured diagnostics implemented; final physical Android validation pending**

## Purpose

Provide reconstructable diagnostic evidence across web and native architectural boundaries without becoming business state.

Diagnostics are observational only. Failure to record diagnostic evidence must never change lookup, persistence, authentication, navigation, export, or other business outcomes.

## Canonical event model

Meaningful records support:

- sequence;
- UTC/Alaska timestamps;
- severity;
- operation ID;
- span ID;
- parent span ID;
- domain;
- module;
- function;
- event;
- phase;
- purpose;
- bounded input/state summary;
- expected result;
- actual/result;
- duration/timing;
- next-state or handoff information;
- bounded error/source/stack evidence where available.

High-value operations should produce START/observation/terminal evidence. An observed START without a terminal phase remains visible as unfinished evidence; diagnostics never invent completion.

## What is logged

Permanent instrumentation targets meaningful boundaries such as:

- startup/lifecycle transitions;
- bridge/native handoffs, including AceNet startup/health callback delivery;
- AceNet session/retrieval operations, including soft-canary recovery choice, transient transport classification, post-canary item terminalization, and whether hard session repair was started;
- lookup resolution;
- imports/exports, including ordinary export preference resolution, selected-field versus forced ACE MISC mode, and terminal file-delivery evidence;
- persistence mutations;
- DSD/MISC workflow operations;
- recovery/failure paths.

Small pure helpers are not automatically traced.

## Web owners

- schema, sanitization, scoping, Deep Diagnostic Mode: `diagnostics/diagnostic-service.js`
- retention/batching: `diagnostics/diagnostic-journal.js`
- diagnostics-store persistence: `diagnostics/diagnostic-repository.js`
- operation/span adaptation: `diagnostics/diagnostic-operation-service.js`
- export/reconstruction: `diagnostics/diagnostic-export-service.js`

Web diagnostics persist through the IndexedDB `diagnostics` store.

## Web retention

Normal mode:

- five most recent distinct Alaska calendar dates containing diagnostic activity;
- maximum 12,000 events;
- maximum 25,000,000 estimated serialized bytes;
- required INFO/WARN/ERROR/FATAL evidence.

Deep Diagnostic Mode:

- same five-active-Alaska-day rule;
- maximum 30,000 events;
- maximum 50,000,000 estimated serialized bytes;
- DEBUG/TRACE enabled and populated by focused, bounded lookup/AceNet timing, Level 2 price-source selection, and diagnostic export/bridge progress observations while the mode is active;
- extra evidence is observational, never a new catalog data authority; it never stores credentials, full AceNet page content, or an event per diagnostic transfer chunk;
- user control is available from both the Settings page and the Diagnostics overlay;
- both UI surfaces delegate to `diagnostics/diagnostic-ui-controller.js`; Settings Controller does not own or duplicate diagnostic-mode behavior.

When count/byte ceilings require pruning, older non-error evidence is removed before ERROR/FATAL evidence where possible. Truncation is diagnosed.

Legacy localStorage diagnostic keys are migration input only; localStorage is not the active journal.

## Native safety journal

`NativeDiagnosticJournal.kt` owns queueing, internal-file persistence, legacy migration, and retention.

`NativeDiagnosticRecordFormatter.kt` owns canonical native formatting/redaction.

Native ceiling:

- 4,000 events;
- 4,000,000 bytes.

SharedPreferences is legacy migration input only.

## Sanitization

Diagnostic payloads are bounded by depth, key count, array entries, and string length.

Redact credentials, password values, authorization/bearer values, cookies, tokens, SAML/assertion values, secrets, and matching sensitive URL query values.

Safe AceNet/WebView evidence may retain bounded host/path/status/reason/structure/selector facts, query-parameter names, payload length/hash/type, parser outcome, transport failure class/error code, and bounded sanitized excerpts.

## Operation/span ownership

Existing startup/lookup/subsystem wrappers emit canonical operation/span records through `diagnostics/diagnostic-operation-service.js`.

High-value DSD/MISC workflows may create explicit spans through the diagnostic service.

Correlation identifiers are evidence only. Application behavior must not depend on diagnostic state.

## Console/logging boundary

Routine JavaScript logging uses structured diagnostics.

Raw web console output is permitted only for:

- fatal bootstrap failure before diagnostics exist;
- emergency diagnostic persistence failure when the journal cannot record itself.

Raw native Android logging is limited to diagnostic-persistence emergency fallback.

## Export

`DIAGNOSTIC_EXPORT_CONTRACT.md` governs export.

Export remains non-destructive and includes retained web/native evidence, a merged timeline, operation/span summaries, and unfinished-span evidence.

## Physical validation

Final Android validation must verify retention, export, Deep Diagnostic Mode, native/web merge, and failure-path evidence on a real device before release completion.
