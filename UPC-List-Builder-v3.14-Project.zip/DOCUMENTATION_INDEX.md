# UPC List Builder Documentation Index

**Status:** CURRENT DOCUMENTATION ROUTER  
**Purpose:** Identify which documents are current authorities, behavioral contracts, operational procedures, and directory ownership guides.

Git history is the historical record. Superseded transition ledgers, handoff snapshots, and research packages do not belong in the active documentation surface.

## Required reading order

1. `AI_START_HERE.md`
2. `CURRENT_ARCHITECTURE_AUTHORITY.md`
3. `SOURCE_OWNERSHIP_MAP.md`
4. The current behavioral contract(s) for the subsystem being changed
5. `DEPLOYMENT_CONTRACT.md` for packaging, deployment, release, or public updater work; `TERMUX_DEPLOYMENT_CONTRACT.md` only when the fallback/recovery path is used

Tests are verification evidence. They do not create product behavior or freeze obsolete file locations.

## Current architecture authorities

- `CURRENT_ARCHITECTURE_AUTHORITY.md` — application architecture, dependency direction, composition boundaries, current stage status.
- `SOURCE_OWNERSHIP_MAP.md` — authoritative responsibility-to-source map, state ownership, side-effect ownership, lifecycle ownership, and workflow maps.
- Directory `README.md` files under production source — local placement/scope rules.
- `REPOSITORY_BOUNDARIES_CONTRACT.md` — persistence/repository ownership.
- `NATIVE_ANDROID_BRIDGE_CONTRACT.md` — web/native capability boundary.
- `APPLICATION_LIFECYCLE_CONTRACT.md` — Android/background-resume lifecycle.
- `UI_OPERATION_LIFECYCLE_CONTRACT.md` — asynchronous request/presentation ownership.
- `DIAGNOSTICS_CONTRACT.md` and `DIAGNOSTIC_EXPORT_CONTRACT.md` — structured observability/export behavior.

## Product and domain contracts

### Lookup, identity, pricing
- `PRODUCT_DATA_AUTHORITY_CONTRACT.md` — AceNet/Master/Local/third-party authority and lookup-key semantics.
- `IDENTITY_RESEARCH_RESOLUTION_CONTRACT.md` — research resolution and deferred live-refresh behavior.
- `NORMAL_ITEM_SEARCH_CONTRACT.md`
- `IDENTIFIER_RESOLUTION_CONTRACT.md`
- `LOCAL_IDENTIFIER_RESOLVER_CONTRACT.md`
- `IDENTIFIER_RELATIONSHIP_SERVICE_CONTRACT.md`
- `PRODUCT_IDENTITY_INDEX_CONTRACT.md`
- `ITEM_PRESENTATION_CONTRACT.md`
- `PRICE_AUTHORITY_CONTRACT.md`
- `RETAIL_UNITS_CONTRACT.md`

### Catalog and Master/Local data
- `MASTER_LIBRARY_CONTRACT.md`
- `EFFECTIVE_CATALOG_RESOLVER_CONTRACT.md`
- `CATALOG_FIELD_MAPPING_CONTRACT.md`
- `CATALOG_REFRESH_POLICY_CONTRACT.md`
- `COMBINED_MASTER_EXPORT_CONTRACT.md`

### AceNet
- `ACENET_AUTH_SESSION_CONTRACT.md`
- `ACENET_CLIENT_BROKER_CONTRACT.md`
- `ACENET_ITEM_RETRIEVAL_CONTRACT.md`
- `ACENET_SESSION_RETRIEVAL_BOUNDARY_CONTRACT.md`
- `ACENET_SERVICE_HEALTH_CONTRACT.md`
- `NETWORK_CONNECTIVITY_CONTRACT.md`
- `ACENET_COMPARISON_TOGGLE_CONTRACT.md`
- `ACENET_ITEM_DATA_EXTRACTION_REFERENCE.md`
- `ACE_MISC_ADDITIONAL_UPC_CONTRACT.md`

### Optional ChatGPT integration
- `integrations/chatgpt-mcp/README.md` — deployment, user-specific OAuth, device pairing, retained batch queue, limitations, and setup. Source-owned independently from on-device DSD.
- `app/src/main/assets/www/dsd/README.md` — optional DSD import UI and handoff owner.

### Store locations and AI planogram import (Build 1 contracts, runtime pending)
- `STORE_LOCATION_CONTRACT.md` — current layout, source membership, last-known item references, custom areas, exclusive sections, and Build 1/2 boundaries.
- `PLANOGRAM_IMPORT_CONTRACT.md` — AI + existing @UPC plugin interpretation, strict structured validation, Cloudflare D1 transfer, device review, and reconciliation safeguards.
- `app/src/main/assets/www/store-locations/README.md` — location domain source ownership, scope and privacy boundaries.

### Work Sessions, settings, navigation, backup
- `LIST_MANAGEMENT_CONTRACT.md`
- `SETTINGS_PERSISTENCE_CONTRACT.md`
- `NAVIGATION_CONTRACT.md`
- `APPLICATION_DATA_BACKUP_CONTRACT.md`

## Release and operations

- `RELEASE_VERSIONING_CONTRACT.md` — single release-identity authority and synchronization rules.
- `DEPLOYMENT_CONTRACT.md` — canonical GitHub-native deployment, exact-run proof, updater publication, and release-archive procedure.
- `TERMUX_DEPLOYMENT_CONTRACT.md` — fallback/recovery procedure when Termux is explicitly selected.
- `UPDATER_SETUP.md` — updater repository/feed configuration.

## Directory ownership guides

Current production directory README files define what belongs in:
- web runtime root;
- application;
- catalog;
- diagnostics;
- DSD;
- Field Session;
- identity;
- lookup;
- MISC;
- platform;
- pricing;
- scanner;
- Work Sessions;
- administration presentation;
- native Android package.

## Documentation rules

- Current docs describe current approved behavior/ownership, not chronological implementation history.
- A responsibility move must update source ownership header, relevant directory README, `SOURCE_OWNERSHIP_MAP.md`, current architecture authority, affected behavioral contract(s), and architecture tests in the same change.
- Obsolete/historical documents are deleted from active source after their useful current requirements are absorbed into current authorities/contracts.
- New root Markdown files require an explicit current authority purpose and verifier update.
