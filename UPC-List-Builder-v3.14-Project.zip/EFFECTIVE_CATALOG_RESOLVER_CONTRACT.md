# Effective Catalog Resolver Contract

> **REQUIRED REFERENCE RULE:** Read `AI_START_HERE.md`, `CURRENT_ARCHITECTURE_AUTHORITY.md`, and `REPOSITORY_BOUNDARIES_CONTRACT.md` before changing Effective Catalog behavior.

**STATUS: CURRENT**

## Purpose

Provide one read-only local answer to: “What catalog record is currently usable for this normalized SKU or directly indexed UPC?”

Master and Local remain physically separate. Effective Catalog selects between them without merging stores.

## Owner and dependencies

`UPCEffectiveCatalogResolver` reads only through:

- `UPCMasterRepository`;
- `UPCLocalRepository`.

It has no network, persistence-mutation, UI, prompt, Work Session, or identity-write authority.

Local reads use a bounded resolver-level timeout so a stuck IndexedDB read cannot leave local resolution pending indefinitely.

## SKU resolution

For normalized SKU:

1. query official Master;
2. Master ambiguity is explicit `AMBIGUOUS`;
3. one Master row is `FOUND` with `MASTER_LIBRARY` provenance;
4. if Master misses, query Local;
5. Local ambiguity is explicit `AMBIGUOUS`;
6. one Local row is `FOUND` with `LOCAL_LIBRARY` provenance;
7. otherwise return `NOT_FOUND`.

There is no promoted-Master compatibility layer in current runtime.

## Direct UPC resolution

For normalized UPC:

1. Master direct index is authoritative before Local;
2. 11-digit input preserves unique-prefix lookup behavior;
3. scanner `ean_13` input with a leading zero may retry as UPC-A only after the exact 13-digit layer misses;
4. Master ambiguity is explicit;
5. if Master misses, the same direct-index/fallback rules apply to Local;
6. Local ambiguity is explicit;
7. otherwise return `NOT_FOUND`.

Supplemental/current secondary UPC relationship resolution is outside this owner and belongs to `UPCLocalIdentifierResolver` + `UPCIdentifierRelationshipService`.

## inspectSKU

`inspectSKU(normalizedSku)` returns both physical Master and Local lookup evidence for specialized consumers that genuinely need layer-specific facts, such as Retail Units fallback or MISC snapshot construction.

It must not become an ordinary-workflow escape hatch for reimplementing Master-first selection.

## Output/provenance

Found results expose the selected row, lookup mode, physical record identifiers, record origin, and provenance.

Current found provenance is:

- `MASTER_LIBRARY`;
- `LOCAL_LIBRARY`.

Callers may use provenance for diagnostics/presentation/routing but may not infer mutation authority from it.

## Verification

Automated tests protect:

- Master-first, then Local selection;
- explicit ambiguity;
- 11-digit prefix behavior;
- format-aware EAN-13 fallback;
- Local-only resolution without network;
- bounded local-read timeout;
- absence of promoted compatibility;
- absence of network/UI/write dependencies;
- consumption by normal lookup, MISC, and Retail Units through approved boundaries.
