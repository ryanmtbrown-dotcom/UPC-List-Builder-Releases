# Identifier Relationship Service Contract

> **REQUIRED REFERENCE RULE:** Read `REPOSITORY_BOUNDARIES_CONTRACT.md` and `EFFECTIVE_CATALOG_RESOLVER_CONTRACT.md` before changing relationship semantics.

**STATUS: CURRENT**

## Purpose

`UPCIdentifierRelationshipService` is the workflow-facing owner of current UPC↔SKU membership, current SKU UPC sets, identity conflicts/resolutions, SKU replacement state, and identity research state.

Relationship state is living current state, not history.

### No historical identity fallback

A retired UPC↔SKU association must not remain queryable as an alternate identity source after current complete evidence removes it. The application has no current business workflow that requires former identity membership. Keeping obsolete associations would create a future risk that lookup code mistakes historical identity for current authority.

Git history and bounded diagnostics may explain implementation events when needed; they do not create business identity state.

It does not own product description, price, cost, classification fields, catalog rows, AceNet navigation, or list presentation.

## Complete exact-SKU evidence

A complete successful exact-SKU selector result defines the current UPC set for that SKU.

For `COMPLETE` evidence:

- returned SKU must exactly match the requested SKU;
- selector evidence must be complete;
- at least one valid UPC must exist;
- current UPC membership is atomically replaced;
- new UPCs are inserted;
- previously stored UPCs absent from the complete set are deleted;
- derived resolution/conflict rows are recomputed from current candidates;
- explicit conflict preference survives only while its preferred SKU remains a current candidate;
- an unused UPC resolution row is deleted;
- removed UPCs are immediately reusable;
- ordered selector position retains current master-UPC semantics.

A provisional user-supplied UPC→SKU association excluded by the complete exact-SKU set must not be re-added.

No inactive relationship history is retained merely for diagnostics.

## Partial evidence

Verified `PARTIAL` evidence is non-destructive.

It may merge observed relationships but must not:

- delete relationships absent from the partial result;
- demote an established master UPC;
- treat missing partial evidence as authoritative removal.

## Inconclusive/unverified evidence

Timeout, unavailable, ambiguity, mismatch, or any result lacking exact-SKU verification must not perform verified-set replacement.

## Atomic replacement

Current `skuUpcs` membership and affected `upcIdentityResolution` rows update in one transaction so stale membership/resolution cannot become separately committed visible states.

Current IndexedDB schema remains version 8.

## UPC resolution

`resolveUPC` returns:

- `KNOWN` with one current SKU;
- `CONFLICT` when current candidates/resolution disagree or remain unresolved;
- `UNKNOWN` when no current relationship exists.

A stale preferred SKU outside the current candidate set is not authority.

## Other identity state

The service owns workflow-facing access to:

- current SKU UPC enumeration;
- SKU catalog/replacement status;
- explicit replacement relationships;
- conflict resolution;
- identity research queue create/read/update/remove.

Workflow code must not query physical identity stores directly to make identity decisions.

## Mutation boundary

Relationship/identity state mutates here. Catalog mutation belongs to catalog refresh/repository owners.

## Verification

Tests protect complete replacement, partial merge, current-state deletion/reuse, conflict preservation only while valid, atomic membership/resolution updates, schema stability, and absence of direct workflow access to `UPCIdentityRepository`.
