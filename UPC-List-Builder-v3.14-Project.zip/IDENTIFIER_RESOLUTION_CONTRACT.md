# UPC / SKU Identifier Resolution Contract

> **REQUIRED REFERENCE RULE:** Read `LOCAL_IDENTIFIER_RESOLVER_CONTRACT.md`, `IDENTIFIER_RELATIONSHIP_SERVICE_CONTRACT.md`, and `NORMAL_ITEM_SEARCH_CONTRACT.md` before changing identifier routing.

**STATUS: CURRENT**

## Normalization and mode

- UPC and SKU are distinct lookup modes.
- Manual UPC input containing only 1–10 digits is automatically treated as SKU input.
- SKU uses the existing normalized SKU form and exact SKU resolution.
- UPC is normalized to digits.
- 11-digit UPC uses established unique-prefix catalog lookup.
- Other UPC lengths use exact catalog lookup.
- Scanner `ean_13` with leading zero may retry as UPC-A only after exact 13-digit local catalog lookup misses.
- Multiple candidates are explicit `AMBIGUOUS`; no arbitrary first-row selection is permitted.
- Identifier classification does not determine pricing authority.

## Local resolution

Normal SKU/UPC resolution uses `UPCLocalIdentifierResolver`, which reconciles Effective Catalog with current saved relationship state.

A supplemental/current secondary UPC may resolve to one saved SKU when relationship evidence is unambiguous.

Direct catalog and relationship disagreement is an explicit conflict, not a query-order winner.

## Unknown UPC identity

A completely unknown normal UPC may collect a user-supplied SKU for validation.

That association remains provisional until validated by:

- one unique Effective Catalog SKU; or
- verified exact-SKU AceNet evidence.

Unverified user input must not poison durable relationship state.

After successful validation, current relationship state is written through `UPCIdentifierRelationshipService`.

## ACE MISC boundary

ACE MISC does not use the normal unknown-UPC Product Identity workflow.

Dedicated MISC manual/bulk resolution follows its own Master → Local → AceNet rules through the MISC resolution owner while using shared normalization/current relationship evidence where applicable.

## Diagnostics

Normal lookup records raw identifier, requested/effective mode, normalized key, scanner format where applicable, lifecycle timing, expected result, and actual result.

## Verification

Tests protect normalization, mode correction, prefix/EAN fallback, explicit ambiguity/conflict, shared Local Identifier Resolver routing, validated-before-commit user identity, and separation of MISC-specific resolution.
