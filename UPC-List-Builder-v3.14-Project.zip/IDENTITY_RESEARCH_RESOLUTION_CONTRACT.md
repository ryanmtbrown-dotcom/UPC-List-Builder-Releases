# Identity Research Resolution Contract

> **REQUIRED REFERENCE RULE:** Read `PRODUCT_DATA_AUTHORITY_CONTRACT.md`, `PRODUCT_IDENTITY_INDEX_CONTRACT.md`, `IDENTIFIER_RELATIONSHIP_SERVICE_CONTRACT.md`, and `NORMAL_ITEM_SEARCH_CONTRACT.md` before changing research/deferred identity work.

**STATUS: CURRENT**

## Purpose

Define Items Needing Research as an actionable current-work queue rather than a retry-only list or historical archive.

## Research records

A research record may contain:

- current SKU;
- one or more observed UPCs;
- reason;
- classification;
- current status;
- detection/check/review timestamps;
- workflow source.

Research state is not catalog authority and does not manufacture current UPC↔SKU identity.

## User resolution actions

The Identity Work owner must allow the user to:

- Recheck with AceNet;
- Correct SKU;
- Correct UPC;
- Mark Third-Party Vendor;
- Mark Recall;
- Mark Old / Deprecated Supplier;
- Keep Unknown / Review Later;
- Delete the active research item.

Correcting SKU/UPC changes the research task only. Authoritative relationship/catalog persistence still requires the normal validation owners.

Recall and Old/Deprecated Supplier are actionable classifications and may remain visible until the user completes the physical/pricing work and deletes/closes the task.

Unknown/Review Later remains active for later investigation.

Delete removes the active task. It does not create a historical identity record.

## Third-party resolution

Mark Third-Party Vendor collects the Local fields required by the current implementation, persists a `THIRD_PARTY_VENDOR` Local record through Local Repository ownership, records the current local UPC↔SKU relationship, and removes the completed research/deferred work.

Official Master SKU/UPC collisions block third-party ownership.

## Deferred live refresh

When AceNet is unavailable or intentionally disabled, normal workflows may retain a SKU for later live verification.

Deferred refresh is:

- keyed/deduplicated by SKU;
- allowed to retain observed UPC context;
- stored as current work, not history;
- explicitly processed by the user through **Refresh Pending Item Data**;
- forbidden from dispatching while AceNet Comparison is effectively OFF;
- processed sequentially through the existing AceNet catalog and Catalog Refresh owners.

Verified success persists current catalog/UPC evidence and removes the pending row.

Conclusive `NOT_FOUND` or SKU mismatch moves/keeps the item in research and removes the pending refresh row.

Unavailable/inconclusive results remain pending.

ACE New Items MISC retains its own required UPC-verification/retry workflow and must not be collapsed into this generic queue.

## Diagnostics

Diagnostics distinguish:

- research edit/classification/delete;
- third-party resolution;
- deferred queue add/dedup;
- deferred batch start/item result/completion;
- AceNet-disabled deferral;
- conclusive `NOT_FOUND` versus unavailable/inconclusive results.

Diagnostics remain observational and do not become identity authority.

## Verification

Tests simulate typo correction, offline deferral, later verified refresh, conclusive not-found, third-party conversion, recall/old-supplier classification, unknown revisit, delete, and the hard prohibition on deferred network dispatch while AceNet Comparison is OFF.
