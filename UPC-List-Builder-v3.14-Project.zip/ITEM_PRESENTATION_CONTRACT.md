# Item Presentation Contract

> **REQUIRED REFERENCE RULE:** Read `UI_OPERATION_LIFECYCLE_CONTRACT.md`, `NORMAL_ITEM_SEARCH_CONTRACT.md`, and `PRICE_AUTHORITY_CONTRACT.md` before changing item presentation.

**STATUS: CURRENT**

## Purpose

Protect the item-result surface without creating lookup or pricing authority.

## Current owner

`UPCItemPresentationController` owns:

- lookup presentation generation;
- CHECKING/reset state;
- pending item state;
- stale-generation rejection;
- final preview rendering;
- AceNet price-row presentation;
- product-image presentation handoff.

`UPCProductImageService` separately owns image discovery/cache/native result correlation and has no preview-DOM, identity, or price authority.

## Required behavior

- Beginning a lookup creates a new presentation generation.
- Prior pending/visible item state is cleared.
- Add is disabled while the owning lookup is pending.
- Only the current generation may finish/present.
- Older generations cannot clear or overwrite newer presentation.
- `FOUND`, `NOT_FOUND`, `AMBIGUOUS`, and conflict/terminal states are presented truthfully.
- Presentation never fabricates identity, price, or catalog evidence.

## Progressive presentation

A usable Master/Local result may be presented immediately while optional AceNet price enrichment continues in the background.

AceNet price may appear later only for the still-current presentation generation. The AceNet Level 2 row uses a muted amber spinner/border while live evidence is pending, returns to its ordinary styling on a verified live result, and uses a red unavailable style only after a terminal failure. This is presentation-only: no waiting toggle, delayed offline Master price, scan blocker, historic status record, or export-column change is permitted. Third-party vendor prices do not use AceNet pending/error styling.

A stale background result cannot mutate a newer item.

The primary displayed price and Price Difference are selected by the shared Level 2 price authority: verified live AceNet Store Retail first, otherwise offline Master/ACE-derived Local Level 2. The separately labeled Master Level 2 and AceNet Level 2 rows show their own evidence; no corporate Ace Retail or unknown historical cached price may appear as Level 2. Third-party vendor pricing remains independent.

## Product image

Image retrieval is asynchronous presentation enrichment only. It must not redefine item identity, catalog authority, or pricing.

## Diagnostics and verification

Presentation diagnostics include generation ownership, lifecycle result, expected/actual state, and timing.

Tests protect stale-value clearing, pending Add disablement, generation ownership, stale rejection, progressive enrichment, and truthful source/value presentation.
