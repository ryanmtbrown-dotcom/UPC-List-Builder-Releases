# List Management and Work Session Contract

> **REQUIRED REFERENCE RULE:** Read `AI_START_HERE.md`, `CURRENT_ARCHITECTURE_AUTHORITY.md`, `SOURCE_OWNERSHIP_MAP.md`, and the affected Field Session/DSD/MISC contract before changing Work Session behavior.

**STATUS: CURRENT**

## Purpose

Protect Work Session creation, persistence, opening, mutation, deletion, list-specific settings, and type-specific routing while keeping DSD/MISC domain semantics in their focused owners.

## Persistence ownership

`UPCWorkSessionRepository` owns physical IndexedDB `lists` CRUD.

`UPCWorkSessionService` owns workflow-facing create/open/save/list/remove behavior.

Controllers/workspaces must not access raw `lists` storage.

The supported one-time legacy localStorage list import may read `upcFieldLists.v0.01`, normalize supported data, and persist through Work Session Service. It is migration input, not a competing runtime list store.

## Planogram Explorer session type

The New Field Session > List Type selector includes **View Planogram**. Selecting it hides Default Purpose, and **Start Session** opens the existing Planogram Explorer directly. This is a transient browsing/editing session, not a merchandise list: no Work Session record, list ID, saved empty list, capture, or default purpose is created. It retains normal Explorer scan, history, Back navigation, direct edit confirmation, and local layout-draft behavior. Ordinary Field Session, ACE MISC and ACE DSD list creation remain unchanged. The redundant View Planogram shortcut inside an already created ordinary list is not necessary.

## Common Work Session behavior

A new session receives:

- unique ID;
- creation/update timestamps;
- session type;
- empty item/capture collections where appropriate;
- current per-list settings.

It is persisted before normal use.

Adding an ordinary resolved item persists before reporting success; persistence failure rolls the just-added in-memory item back.

Edits/removals persist through the same boundary.

Deleting a saved session requires confirmation and removes only that selected session. Deleting the active session clears the active reference.

Duplicate handling is explicit; duplicate input never silently becomes a second item contrary to the owning workflow's rules.

## Open List presentation

For ordinary Field Session lists, **purpose is more important than the creation date**:

- primary card title is the default purpose when available;
- Alaska creation date/time is secondary metadata;
- a legacy/no-purpose ordinary list displays `Field Session`;
- MISC displays `ACE New Items MISC.`;
- DSD cards display `ACE New DSD Items` with secondary manufacturer, primary manufacturer and primary invoice/PO/placeholder number as available. They use smaller DSD-only typography and no date/time subtitle; existing saved DSD lists derive the label from `dsdInvoice`, not old stored timestamp names.
- search may match purpose, retained stored name, or formatted creation date for ordinary lists; DSD search also matches manufacturer names and invoice identifiers.

Presentation does not change stored identity/order.

## Per-list price fields/settings

List items may retain `libraryPrice`, `aceNetPrice`, and `labelPrice` independently.

Per-list:

- label-price prompting;
- automatic price-difference adding

travel with the Work Session.

Automatic price-difference adding cannot remain enabled when label-price prompting is disabled.

A newly created ordinary **Price Change** Work Session defaults both label-price prompting and automatic price-difference adding to ON. Other new ordinary purposes keep their own current defaults. Existing saved lists retain their stored per-list values.

Feature/presentation settings do not rewrite stored Library/Label/AceNet values.

### Missing shelf-label observations

- The label-price modal displays the known SKU in red above its title, with a separate description and sufficient responsive/scrollable space. When no verified SKU is available, it identifies the observed UPC without inventing a SKU.
- With per-list label-price prompting enabled, an eligible found item or unknown scanned/typed UPC can reach the prompt, including after cancellation of optional unknown-UPC SKU entry. Ambiguous or conflicted catalog identity cannot be silently selected. The actual scanned UPC is retained as the field observation even when a separate canonical item UPC exists.
- An explicit **Missing Label** action is available in the price modal and on the item screen after a skipped or saved price; marking directly adds the observation to the active ordinary Field Session. Ordinary MISC and DSD workflows are excluded.
- **Missing Label** is a supplemental, persistent item tag, independent of numeric `labelPrice`. An entered `0.00` is a valid observation, Skip is blank, and neither automatically marks a label missing. Saved items may set/clear Missing Label using the normal item editor.
- Unknown UPC label observations can be recorded with `sku: null`, no invented Library/AceNet price, and a General Review primary purpose. They do not create Master/Local records, current UPC/SKU relationships, or fabricated catalog authority. Conventional unresolved Add-to-Library work retains its existing separate routing when no label observation is being recorded.
- The established automatic Price Change rule still requires two numeric prices with a genuine difference. A missing label alone never becomes a price-change comparison.

## Add-to-Local-Library handoff

An ordinary item whose current purpose includes Add to Library and has a normalized SKU feeds the shared durable `libraryUpdateQueue`.

This is a queue handoff; Work Session persistence is not another Local Library persistence owner.

Retired list-shadow pending state is not a current user-facing Add-to-Local-Library machine.

## Field Session export

`UPCFieldSessionExportService` owns Field Session XLSX/tagged-ZIP composition, NIF capture packaging, export naming, selected-field row shaping, Price Change workflow columns, and non-fatal cached export-base behavior.

Ordinary export behavior has two explicit modes.

With **Force ACE MISC Format OFF**, purpose workbooks use only the Settings-owned selected subset of the Catalog-owned 30 Master Library fields. Unchecked Master fields are omitted entirely. Checked fields are populated from evidence already stored on each Work Session item and remain blank when that item does not carry a value. Price Change appends `Label Price` and `Price Difference`; those workflow fields are not individual Master-field checkboxes.

With **Force ACE MISC Format ON**, ordinary purpose files keep their purpose-specific filenames and reuse the exact ACE MISC formatter: all 33 ACE MISC columns, original order/styling, one row per available saved UPC, and blank separator rows between items. **Price Change is the single exception:** append `Label Price` as column 34 after all 33 ACE MISC columns, with the saved observed value repeated on each UPC row, currency-formatted, and blank when skipped or unavailable. `Price Difference` is not appended in forced mode. When register-price collection is chosen, `Register Price` is additionally appended as column 35, after `Label Price`, with per-UPC values or blanks for unchecked UPCs. All other forced-format purposes and the actual ACE MISC workspace export remain exactly 33 columns with no workflow extras. The dedicated Missing Label report is a field-observation report, not an ACE MISC merchandise import, and retains its own UPC-first layout in either format setting.

**Register Price collection for Price Change:** On Export of a Work Session containing Price Change items, present an explicit Yes/No choice to collect register prices. No continues the established export without a Register Price column. Yes opens a non-scrollable, viewport-contained register-price collector with one observed UPC at a time, an offline barcode, known SKU/description, independent Label/Library prices, large cents-entry keypad, Previous, Save Price & Next (requires a price), NIF (UPC-specific), Clear Saved Price, Save for Later, and Export Now. The collector may be stopped and resumed at any UPC and may export with any number of prices captured, including none; missing Register Price cells remain blank and entered zero remains numeric zero. Each saved register price is keyed to the exact UPC on its Work Session item, not to the SKU, and a saved resume cursor is retained in the Work Session via Work Session Service. Forced ACE MISC Price Change export appends `Label Price` and then `Register Price` after the 33 canonical columns, retaining UPC row expansion and blank separator rows. Standard Price Change export appends Register Price after its existing workflow fields. Other exports and MISC/DSD remain unchanged. Each normal lookup result with a renderable displayed UPC may open an offline barcode-only viewer from the small UPC-adjacent button, without modifying catalog data. All new modals are non-scrollable; every required control must fit within the available phone or landscape viewport.

No ordinary export mode performs AceNet/network retrieval or Master/Local/identity mutation at export time. Forced ACE MISC mode may read already-verified local SKU-to-UPC relationship evidence through the injected identity owner so all currently known UPCs can receive their required MISC rows. Other exported field values come from evidence already persisted with the Work Session item. Purpose files retain explicit names such as `NIF - <date>.xlsx`, `Price Change - <date>.xlsx`, `General Review - <date>.xlsx`, `Add to Library - <date>.xlsx`, and `Duplicate Item - <date>.xlsx`, and `Missing Label - <date>.xlsx`.

The Missing Label report contains Observed `UPC/EAN`, `ACE SKU` when known, `Description`, `Label Price`, `Library Price`, and `Lookup Status`. Missing numeric values remain blank rather than zero. It never calls AceNet or interprets an unknown identifier as a verified SKU.

The dedicated ACE MISC Work Session retains its own verification/readiness rules even though its exact formatter is reusable. ACE DSD remains independent. Field Session Export receives the active session snapshot and does not read/write the physical Work Session store.

Final ordinary native/browser file delivery is delegated to `platform/file-export-delivery-service.js`.

## ACE MISC Work Sessions

`UPCMiscWorkspaceController` owns manual/bulk MISC session UI/orchestration.

Focused MISC draft/resolution/verification/maintenance owners retain their respective semantics.

MISC bulk import reuses the Alaska-date daily identity:

`ACE New Items MISC. · <Alaska date>`

If today's session does not exist, exactly one normal MISC Work Session is created.

A SKU already on today's list is skipped rather than duplicated.

One failed bulk SKU does not roll back prior successful items or stop later SKUs.

Export-relevant edits update both visible draft fields and the stored export snapshot/ordered UPC set so UI/export state cannot diverge.

MISC persistence crosses Work Session Service only.

## ACE New DSD Work Sessions

`UPCDsdWorkspaceController` owns DSD session UI/editing.

`ace-dsd.js` owns DSD invoice/item/workbook rules.

Current DSD behavior:

- invoice department is the default for new items;
- each item may override with another valid Myers department;
- item department is authoritative for department column and generated SKU;
- before editing an invoice default, supported older saved rows without item-level department are frozen to their prior effective department;
- item may store optional serial number exported to `Serial#`;
- preload-previous clears serial number while copying allowed previous fields;
- completed compatible DSD XLSX can be imported as a new editable DSD Work Session;
- invoice fields/items may be edited and re-exported;
- one DSD may contain multiple invoice identifiers stored space-separated;
- exported name is `ACE New DSD Items <manufacturer> [second manufacturer] <invoice> [additional invoices].xlsx`;
- manufacturer fields may not contain digits;
- each invoice identifier contains at least one digit;
- older underscore-separated filenames remain import-compatible;
- import does not guess a secondary manufacturer split;
- mixed item departments require invoice-default review because original default is not encoded;
- imported retail uses Direct Retail/MSRP where the workbook cannot encode the prior method.

DSD has no AceNet/Master/Local/identity dependency.

Final file delivery uses the shared standard platform delivery owner.

## Optional ChatGPT invoice staging

The optional ChatGPT MCP integration is OFF until enabled by the device user. An authenticated paired device may list, import or reject its own pending invoices. Import creates an editable ACE New DSD Items Work Session directly: all corrections use the existing Edit Invoice, Edit Item, Delete and Export controls, with no separate ChatGPT review screen. Missing required case cost or retail/MSRP/markup remains incomplete and must not silently become zero. The invoice-level default department is required for export, but individual item departments are optional and inherit that default. The ChatGPT staging normalization sets absent DSD order multiples to 1 (one merchandise unit), independently of the invoice quantity ordered; case cost must then represent one item's verified cost. Explicit item departments override the invoice default, serialized items are assigned department 46 by staging, and identifiable ammunition with no item department defaults to 46. Mixed item departments are valid in one invoice. Verified zero-cost promotional displays are excluded from staging while other zero-cost merchandise is retained. The v2.99 pricing handoff is preserved: empty cost, order multiple, markup and retail remain unknown rather than zero; item markup takes priority when per-item method is omitted, while explicit direct-retail overrides remain authoritative; otherwise invoice default controls. Complete markup drafts without an authored retail are calculated by the DSD owner only after department, cost, quantity and markup are known. Editing an invoice default may fill previously missing markup retail but never overwrite a manual retail. Export validation blocks incomplete drafts.

The importer delegates to the existing ACE DSD workspace, which persists the editable draft through Work Session Service. The DSD domain enforces invoice/item requirements before export. It does not write the Master Library, Local Library, identity relationships, or MISC state. External batch ID is saved with the session to prevent repeated imports if remote acknowledgement fails. Only successful local persistence permits remote acknowledgement. Disconnect revokes only the ChatGPT device token; it must not erase saved sessions.

## Diagnostics

Create/open/add/edit/remove/delete operations retain lifecycle evidence.

DSD/MISC/Field-specific high-value operations emit their focused diagnostic evidence.

Diagnostics never become Work Session state.

## Verification

Tests protect:

- persistence-before-success;
- add rollback;
- open ordering;
- selected deletion;
- per-list settings;
- purpose-first saved-list presentation;
- queue handoff;
- Field export boundaries;
- MISC daily reuse/sequential behavior;
- DSD department/SKU/serial/import/export behavior;
- Work Session repository/service ownership;
- absence of raw list-store access from domain controllers.

## Register NIF observations

Register-price review does not provide an unrestricted forward-skip action. Advancing forward requires a recorded price (including true zero), or explicit NIF marking for that exact UPC. NIF records are persisted on the same Work Session and exported to that Work Session’s NIF worksheet; alternate UPCs for the same SKU must not be tagged or exported as NIF unless individually observed. NIF and entered Register Price are mutually exclusive for an individual UPC; later edits may correct NIF. NIF is an additional register observation, NOT a replacement for Price Change: an item whose Label Price differs from verified live AceNet Level 2 (or saved Master/Local Level 2 when live verification is absent) retains its Price Change tag and Price Change worksheet row after NIF is marked. Its Register Price cell remains blank, and that UPC also appears in the same session's NIF worksheet. The app must never remove Price Change or convert a price discrepancy to a NIF-only record. Previous, Save for Later, and partial Export Now do not require all UPCs to be completed. Failed saves revert the NIF change and cursor.
