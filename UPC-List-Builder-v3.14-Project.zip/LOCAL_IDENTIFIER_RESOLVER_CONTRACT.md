# Local Identifier Resolver Contract

> **REQUIRED REFERENCE RULE:** Read `IDENTIFIER_RELATIONSHIP_SERVICE_CONTRACT.md` and `EFFECTIVE_CATALOG_RESOLVER_CONTRACT.md` before changing local identity resolution.

**STATUS: CURRENT**

## Purpose

`UPCLocalIdentifierResolver` produces local SKU/UPC identity truth using only:

- `UPCEffectiveCatalogResolver`;
- `UPCIdentifierRelationshipService`.

It performs no network access and no mutation.

## SKU input

Normalize SKU and resolve through Effective Catalog.

Relationship lookup is not required merely to locate a catalog SKU.

## UPC input

Direct Effective Catalog evidence and current relationship evidence are gathered together.

Deterministic reconciliation:

- direct catalog ambiguity → `AMBIGUOUS`;
- unresolved relationship conflict → `CONFLICT`;
- direct catalog + no relationship → direct `FOUND`;
- relationship-only → resolve relationship SKU through Effective Catalog;
- direct + relationship resolving to same effective catalog identity → `FOUND`;
- direct + relationship disagreement → `CONFLICT`;
- relationship SKU ambiguous in catalog → `AMBIGUOUS`;
- known relationship whose SKU is absent from Effective Catalog → `SKU_NOT_FOUND`;
- neither source knows UPC → `UNKNOWN`.

No query-order winner is allowed when evidence disagrees.

## Outputs

Possible status includes:

- `FOUND`;
- `AMBIGUOUS`;
- `CONFLICT`;
- `UNKNOWN`;
- `SKU_NOT_FOUND`;
- `INVALID`.

Found results carry effective catalog/provenance evidence. Conflict results carry enough bounded evidence for caller diagnostics.

## Boundaries

The resolver must not:

- call AceNet/native retailer bridges;
- prompt;
- write catalog/relationship/list/queue state.

Normal Search and MISC consumers decide what to do after the reported local result.

## Workflow convergence and performance

Normal Search and ACE MISC manual UPC handling consume the same local UPC reconciliation path where applicable.

Relationship lookup remains indexed/local via current identity-store indexes rather than full-store scans.

## Verification

Tests protect read-only/network-free ownership, deterministic reconciliation, indexed relationship lookup, and use by normal lookup/MISC.
