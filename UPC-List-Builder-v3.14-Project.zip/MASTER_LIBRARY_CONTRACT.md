# Master Library Contract

> **REQUIRED REFERENCE RULE:** Read `AI_START_HERE.md`, `CURRENT_ARCHITECTURE_AUTHORITY.md`, `SOURCE_OWNERSHIP_MAP.md`, `REPOSITORY_BOUNDARIES_CONTRACT.md`, and `CATALOG_REFRESH_POLICY_CONTRACT.md` before changing Master Library behavior.

**STATUS: CURRENT**

## Purpose

Master Library is the authoritative imported local catalog layer. It stores one official active generation, preserves source fields/mapping metadata, and provides deterministic indexed lookup evidence.

Durable Local Library is a separate physical/current authority and is not copied into Master.

## Ownership

`UPCMasterRepository` owns workflow-facing Master persistence.

`library-workflow-v093.js` owns import/mapping workflow.

`catalog/master-library-controller.js` owns Master Library presentation/navigation.

`UPCEffectiveCatalogResolver` consumes Master before Local for ordinary local resolution.

Master Library does not own normal lookup orchestration, AceNet authentication/retrieval, price-authority policy, Local Library persistence, identity relationships, or XLSX parser internals.

## Active generation

- Exactly one generation named by `meta/library.generation` is authoritative.
- Search/read APIs ignore rows from other generations.
- No active generation means no Master match.

## Import and activation

Replacement import follows:

1. parse/validate workbook;
2. user confirms distinct UPC and SKU mappings;
3. stage a complete new official generation;
4. persist metadata pointing to that generation;
5. verify persisted active generation;
6. clean older generations.

A failed staged generation does not become searchable.

Staging strips prior storage `id` / `generation` metadata and lets IndexedDB allocate current storage identity.

Importing an official workbook does not copy or merge Local Library rows into the Master generation.

Local Library remains durable and separate across Master replacement.

## Lookup semantics

### Exact UPC
Return a row only when exactly one active-generation row matches.

Multiple matches are explicit ambiguity.

### 11-digit UPC prefix
Return a row only when exactly one active-generation UPC begins with the requested prefix.

Once more than one match is established, no row is selected.

### SKU
Use normalized SKU and return a row only when exactly one active-generation indexed SKU matches.

No retired fallback full-generation SKU scan may return.

### Active reads
Bulk active-record reads return only the current generation.

## Mapping/reindex

UPC and SKU mappings must use different source columns.

Reindexing rebuilds current generation search keys/mapping metadata; it does not create a replacement generation.

Unknown source workbook fields remain preserved on official rows.

## Master mutation boundary

Official Master rows are not routine live-enrichment targets.

There is no direct Master AceNet price writer or broad AceNet field writer.

Fresh verified AceNet price may be used by current presentation but does not rewrite the imported Master row.

The only current AceNet-driven Master mutation is guarded canonical UPC correction under `CATALOG_REFRESH_POLICY_CONTRACT.md`.

The correction must prove:

- active Master exists;
- target record belongs to active generation;
- expected normalized SKU still matches;
- verified next UPC is valid;
- no conflicting active Master identity owns that UPC.

It updates the mapped UPC field, `upcKey`, and `originalUPC` together and preserves unrelated fields.

## Local Library separation

Local-only records remain in durable Local Library.

There is no current Push Local Library to Master workflow, promoted-Master row type, reconciliation/restoration path, or Local-to-Master promotion state.

Combined Master Export is the read-only interoperability mechanism for producing official Master plus Local-only rows without changing either store.

Database Viewer presents official Master and Local Library separately. Local presentation may annotate whether an official Master currently supplies the same identity; viewing does not mutate either layer.

## Immediate local result

A unique Master hit is usable immediately.

AceNet is not a prerequisite for presenting the Master item or Library Price.

Optional AceNet enrichment remains background/current-generation-owned according to normal search/presentation policy.

## Diagnostics

Master management diagnostics include as applicable:

- operation ID;
- Alaska-local start/finish time;
- purpose/expected/actual/result;
- duration;
- file name/size;
- parsed/valid counts;
- selected mappings;
- previous/staged/active generation IDs;
- stage of failure and exception evidence.

Diagnostics must not claim activation until persisted metadata identifies the generation as active.

## Failure behavior

- parse/preparation failure leaves current active generation unchanged;
- staged-write failure does not activate partial data;
- activation verification failure does not report success;
- ambiguity never silently selects a row;
- guarded UPC correction failure does not mutate a stale/wrong record.

## Verification

Tests protect:

- generation-scoped exact UPC/prefix/SKU lookup;
- ambiguity;
- stage → activate → verify → cleanup ordering;
- mapping reindex preserving generation;
- staging removal of prior storage identity;
- official-only import;
- Local separation;
- absence of retired promotion/repair/direct-price machinery;
- guarded canonical Master UPC correction;
- management diagnostics.
