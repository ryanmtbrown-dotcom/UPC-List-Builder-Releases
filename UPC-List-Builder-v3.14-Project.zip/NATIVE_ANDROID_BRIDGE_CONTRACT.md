# Native Android Bridge Contract

> **REQUIRED REFERENCE RULE:** Read `AI_START_HERE.md`, `CURRENT_ARCHITECTURE_AUTHORITY.md`, `SOURCE_OWNERSHIP_MAP.md`, and the relevant native subsystem contract before changing bridge capabilities.

**STATUS: CURRENT**

## Purpose

Protect the JavaScript-to-Android capability boundary while keeping Android implementation inside focused native owners.

## Single production interface

The main application WebView exposes exactly one application interface:

`AndroidNative`

`MainActivity` owns registration/composition of that interface. Focused native services own implementation.

Current bridge capabilities include:

- scanner launch and platform identification;
- runtime-asset probe reporting;
- native diagnostic-journal read;
- network-connectivity state read;
- native AceNet broker timeout read;
- startup/manual update checks;
- diagnostic export;
- generic file export;
- product-image lookup;
- keyboard request;
- AceNet startup/test/cancel;
- encrypted AceNet credential presence/read/save/delete;
- encrypted optional ChatGPT MCP device-token save/read/delete through isolated `ChatGPTConnectionVault` (never AceNet credential manager);
- saved-credential test;
- typed AceNet PRICE, PRICE+UPC, UPC, catalog, MISC-catalog, and repair-catalog requests;
- one-shot AceNet user-recovery authorization arm/disarm control;
- AceNet login/session status.

Retired laboratory/experimental bridge methods are not part of the current capability surface.

## Delegation ownership

`MainActivity` delegates:

- AceNet coordination, including one-shot user-recovery authorization state, to `AceNetProductionCoordinator`;
- update/download/install work to `AppUpdateService`;
- generic and diagnostic file export to `NativeFileExportService`;
- durable native diagnostic storage to `NativeDiagnosticJournal`;
- product-image search to the focused image-search owner;
- scanner activity/camera work to scanner owners.

`MainActivity` must not reabsorb those implementations.

## Remote/transient WebViews

Transient AceNet WebViews must never receive the full `AndroidNative` interface.

The narrow `AceNetResultBridge` is request/view-bound and may report only the readiness/result evidence authorized by the AceNet session/retrieval boundary. It must not expose credentials, filesystem access, updater access, scanner access, or arbitrary native execution.

Production item extraction remains owned by `PersistentAceNetWorker`, not the transient bridge.

## Callback registration

Global JavaScript callback families register through `platform/bridge-registration.js`.

AceNet startup and health publication use the native callbacks `UPCNativeAceNetStartupStatus` and `UPCNativeAceNetHealthStatus`. Bridge Registration routes both to `application/acenet-startup-service.js`, which projects native state into the shared web runtime state. Terminal startup payloads include explicit `startupResolved` truth from the native coordinator. No parallel DOM-event startup completion mechanism is supported.

Duplicate callback registration is prohibited. Registration/unregistration must preserve one authoritative callback owner per runtime.

## Security boundary

The main packaged `AndroidNative` bridge must never accompany an untrusted main-frame page or foreign iframe. The main WebView allows only the exact packaged `appassets.androidplatform.net/assets/www/index.html` document to navigate in-app, blocks subframe navigations, and hands user-clicked outside HTTP(S) links to an external browser. Packaged web CSP disallows frames and objects. This defense applies to all native bridge methods, including optional ChatGPT tokens and existing AceNet credentials.


- Main WebView file access remains disabled.
- Main WebView content access remains disabled.
- AceNet credentials remain encrypted with Android Keystore-backed AES/GCM storage owned by `AceNetSessionManager`.
- JavaScript receives saved credentials only through the explicit credential-management capability.
- Diagnostic/runtime-probe methods must not expose credential secrets, authorization tokens, cookie values, or unrestricted filesystem data.
- Bridge methods touching Android UI run on the UI thread where required.

## File export

Ordinary web export callers route through `platform/file-export-delivery-service.js`, which may call the existing `AndroidNative.exportFile` method. Android writing remains owned by `NativeFileExportService` / `NativeDownloadsWriter`.

Diagnostic export remains a specialized diagnostics path. Large JSON exports use the four focused `AndroidNative` methods `beginDiagnosticExport`, `appendDiagnosticExportChunk`, `finishDiagnosticExport`, and `abortDiagnosticExport`, with acknowledgment/error events routed only through `UPCNativeDiagnosticExportTransferEvent` in `platform/bridge-registration.js`. The dedicated native writer owns a single background worker; interrupted Downloads entries are rolled back. Normal `exportFile` remains unchanged. Diagnostic transfer never accepts arbitrary file destinations or MIME types.

## Verification

Maintained tests must protect:

- one `AndroidNative` registration;
- the expected current capability surface;
- absence of retired laboratory methods;
- disabled WebView file/content access;
- credential crypto ownership outside `MainActivity`;
- narrow transient-WebView bridge scope;
- focused native delegation rather than implementation duplication;
- registered AceNet startup/health callback pairing, explicit startup terminality, and absence of orphan parallel completion events.

## ZIP diagnostic download

The existing diagnostic four-method bridge protocol is unchanged. `NativeFileExportService` accepts `.zip` requests for its acknowledged diagnostic transfer and sends one JSON entry through `PendingDiagnosticDownload` using Java standard ZIP compression on the background worker. The normal `.json` native legacy path remains supported; ordinary file/Excel exports stay separate. MediaStore uses `application/zip` for ZIP files. No credential-bearing evidence or diagnostic-only results feed business rules.
