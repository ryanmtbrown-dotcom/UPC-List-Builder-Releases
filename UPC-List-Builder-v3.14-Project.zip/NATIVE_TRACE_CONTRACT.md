# Native Diagnostic Trace Contract

> **REQUIRED REFERENCE RULE:** Read `DIAGNOSTICS_CONTRACT.md`, `ACENET_SESSION_RETRIEVAL_BOUNDARY_CONTRACT.md`, and `NATIVE_ANDROID_BRIDGE_CONTRACT.md` before changing native trace evidence.

**STATUS: CURRENT**

## Purpose

Preserve bounded forensic native/WebView evidence while keeping diagnostics subordinate to subsystem authority.

A trace event is evidence, not permission to change business/session/health state unless the owning contract permits that conclusion.

## Current evidence

Native trace may record bounded:

- request/lane/operation correlation;
- elapsed timing;
- safe URL host/path metadata;
- main-frame navigation start/finish;
- HTTP/WebView errors;
- retained-worker readiness/observer/DOM state;
- wrapper-target/readiness state;
- extraction terminal classification;
- result-delivery errors;
- warning/error console evidence;
- safe cookie-name presence;
- bounded sanitized page/script/form/iframe structure when needed;
- application runtime-asset probe evidence.

Non-main-frame CDN/image/resource noise is not promoted to production service failure.

## Retained-worker forensic boundary

When item evidence remains unresolved, trace may capture bounded sanitized structural evidence from the retained worker.

It must not record:

- credential/password values;
- cookie values;
- auth tokens;
- SAML/assertion values;
- form/input values;
- retail price values;
- unbounded page bodies.

## Runtime asset probe

Native diagnostics record `app_runtime_asset_probe` independently of application self-diagnostics.

Evidence may include:

- installed package/release identity;
- expected native build ID;
- WebView cache mode;
- page/index build ID;
- loaded packaged script URLs;
- JavaScript release marker;
- exported runtime capability/readiness state.

The probe uses exported global capabilities such as `UPCAppRuntimeCapabilities`, `UPCAppRuntimeReady`, and `UPCAceMiscResolver` rather than assuming lexical declarations are global.

Runtime asset mismatch is an application packaging/cache diagnosis and must not be classified as AceNet service failure.

## Retention and performance

Native trace persists through `NativeDiagnosticJournal` and follows the native 4,000-event / 4,000,000-byte ceiling.

Instrumentation must not synchronously rewrite large retained journals on the WebView/UI critical path.

## Verification

Tests protect native forwarding/provenance, retained-worker evidence, runtime probe availability, redaction boundaries, non-main-frame non-authority, and absence of credential-secret logging.
