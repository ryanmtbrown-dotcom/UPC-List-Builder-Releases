# Navigation Contract

**STATUS: CURRENT**

## Purpose

Protect ordinary in-app screen routing and Back/Home behavior.

## Required behavior

- Exactly one primary application screen is active after `show`.
- Non-home navigation may push the prior primary screen.
- Reset navigation clears the application navigation stack.
- Home resets the application stack and saves the current Work Session when active.
- Back returns to the prior app screen when available; otherwise Home.
- Browser/Android WebView history Back is translated through the same app Back behavior rather than becoming a second navigation model.
- Navigation does not mutate item-search authority, catalog data, AceNet service state, or other domain truth.

## Ownership

`application/navigation-controller.js` owns navigation/history state and listeners.

The Application Shell injects save/current-screen dependencies but does not duplicate navigation state.

## Diagnostics and verification

Primary navigation records from/to screen, stack depth, expected/actual result, terminal outcome, and timing.

Tests protect single-screen activation, push/reset, Home, Back fallback, popstate routing, and lifecycle diagnostics.
