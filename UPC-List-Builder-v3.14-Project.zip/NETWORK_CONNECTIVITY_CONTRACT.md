# Network / Connectivity Classification Contract

> **REQUIRED REFERENCE RULE:** Read `ACENET_SERVICE_HEALTH_CONTRACT.md`, `APPLICATION_LIFECYCLE_CONTRACT.md`, and `DIAGNOSTICS_CONTRACT.md` before changing connectivity classification.

**STATUS: CURRENT — automated verification complete; final physical Android validation pending**

## Purpose

Prevent device/network failures from being mislabeled as proof that AceNet's server is down.

## WebView/network error rules

Main-frame transport failures such as DNS failure, connection timeout/reset/refusal, SSL/transport failure, weak/no connectivity, and `ERR_EMPTY_RESPONSE` terminate/degrade the affected request as network/connectivity evidence.

They:

- retain raw callback/error provenance;
- do not independently set global AceNet health DOWN;
- may cause the affected lookup to continue/fallback according to current lookup/price policy.

Incidental subresource/CDN/image failures are not server-DOWN authority.

Later verified exact-SKU success remains valid evidence that AceNet item service is operational.

## Android connectivity preflight

Startup may inspect `ConnectivityManager` / `NetworkCapabilities`.

Classification:

- no active network → `UNAVAILABLE`;
- no Internet capability → `UNAVAILABLE`;
- captive portal → `UNAVAILABLE`;
- Internet-capable but not Android-validated → `UNKNOWN`;
- connectivity-inspection failure → `UNKNOWN`;
- validated Internet-capable network → available for direct AceNet verification.

`UNKNOWN` is evidence uncertainty, not a veto. Direct bounded AceNet verification proceeds so real service evidence can decide.

Successful AceNet evidence may establish ONLINE even when Android preflight was UNKNOWN.

`navigator.onLine` is network-interface evidence only and never proof of Internet/AceNet reachability.

## Server-unavailable distinction

Inferred page failures, result timeouts, or missing required lookup evidence may terminate/degrade an operation but do not manufacture global server-DOWN evidence.

Observed main-frame HTTP 500/502/503/504 may provide authoritative server-unavailable evidence under `ACENET_SERVICE_HEALTH_CONTRACT.md`.

HTTP 404 is application/resource response evidence, not a transport failure. Its item-not-found versus abnormal-resource meaning belongs to the item-retrieval/service-health classifiers.

## Diagnostics

Record:

- raw network code/description;
- host/path/URL where safe;
- main-frame flag;
- source callback/function;
- request/phase role;
- Android network capabilities/validation;
- resulting Internet reachability;
- explicit distinction between network evidence and server-DOWN evidence.

## Verification

Tests protect network-error terminalization, raw provenance, no automatic DOWN from network/subresource failures, UNKNOWN-versus-UNAVAILABLE preflight rules, and successful direct verification after uncertain preflight.
