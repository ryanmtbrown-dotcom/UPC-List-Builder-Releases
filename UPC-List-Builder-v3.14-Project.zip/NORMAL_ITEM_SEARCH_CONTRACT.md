# Normal Item Search Contract

> **REQUIRED REFERENCE RULE:** Read `AI_START_HERE.md`, `PRODUCT_DATA_AUTHORITY_CONTRACT.md`, `IDENTITY_RESEARCH_RESOLUTION_CONTRACT.md`, `IDENTIFIER_RESOLUTION_CONTRACT.md`, `LOCAL_IDENTIFIER_RESOLVER_CONTRACT.md`, `ITEM_PRESENTATION_CONTRACT.md`, `PRICE_AUTHORITY_CONTRACT.md`, `CATALOG_REFRESH_POLICY_CONTRACT.md`, and the AceNet broker/retrieval contracts before changing normal search.

**STATUS: CURRENT — automated verification complete; final physical Android validation pending**

## Purpose

Resolve normal UPC/SKU input through current local authority first, present usable local results immediately, and use AceNet as bounded optional enrichment/recovery without allowing stale work to overwrite newer presentation.

## Input/routing

- UPC and SKU normalization/mode behavior follows `IDENTIFIER_RESOLUTION_CONTRACT.md`.
- UPC local reconciliation delegates to `UPCLocalIdentifierResolver.resolveUPC(...)`.
- SKU local resolution delegates to `UPCLocalIdentifierResolver.resolveSKU(...)`.
- Normal search does not reimplement Master/Local/identity repository routing.
- ambiguity/conflict is terminal and explicit.
- Current authority order for an unresolved item is `Master Library -> durable Local Library -> AceNet`.

## Local-first presentation

A unique Master or Local result is usable immediately.

The item presentation generation is begun/reset before lookup and only the current generation may present/finish.

A local result is rendered without waiting for AceNet.

Library Price remains its own value/source.

A stale/superseded lookup cannot overwrite a newer item.

## Background AceNet price

When effective AceNet Comparison Pricing is enabled and service state permits:

1. local item is already presented;
2. `UPCAceNetPriceService` requests price-only evidence through `UPCAceNetClient`;
3. verified exact-SKU price is presented only if the same presentation generation still owns the item.

Known DOWN/UNAVAILABLE skips live comparison dispatch.

AceNet Price is independent and does not replace Library Price.

## Deferred UPC enrichment

Current normal search uses **price-first deferred UPC enrichment**.

Visible price retrieval uses price-only `PRODUCTION_PRICE`.

After verified price presentation, if the request's captured UPC-enrichment capability is enabled, a separate bounded UPC enrichment request may run.

Verified complete exact-SKU UPC evidence is reconciled through Catalog Refresh / Identifier Relationship owners with relationship source `ACENET_NORMAL_ENRICHMENT`.

UPC enrichment failure does not revoke an already verified/presented price.

Late enrichment cannot attach UPCs to another SKU or repaint a newer item.

## Missing local SKU recovery

When requested/identity-resolved SKU is absent from both Master and Local:

1. request full exact-SKU AceNet catalog evidence;
2. on complete verified success, persist immediately to Local Library through the shared Catalog Refresh Service;
3. persist/reconcile complete UPC relationships;
4. verify Local read-back;
5. re-read the item through normal local authority;
6. present success from durable Local state.

The successful current path does not use the retired price-only deferred queue or direct active-Master write path.

Conclusive AceNet `NOT_FOUND` is distinct from local miss and may route to research according to Product Identity policy. Normal Search consumes the shared retained-worker/coordinator classification; it must not manufacture `NOT_FOUND` merely because Master/Local missed or because an AceNet request timed out.

The shared worker may establish `NOT_FOUND` from explicit not-found text or from the stable healthy-empty ItemDetail structure defined by `ACENET_ITEM_RETRIEVAL_CONTRACT.md`. Normal and MISC therefore receive the same typed terminal classification for the same page evidence.

Timeout/unavailable/mismatch/incomplete evidence remains inconclusive and visibly terminates without claiming catalog absence.

When live AceNet cannot be used after a Master/Local miss, the supplied SKU and observed UPC context are retained in research plus the SKU-keyed pending-live-refresh work queue. The lookup must not silently lose the unresolved item.

## Unknown UPC identity

After local UPC resolution reports unknown, normal Product Identity workflow may request a provisional user SKU and validate it under `IDENTIFIER_RESOLUTION_CONTRACT.md`.

Unresolved relationship conflicts stop without silent selection.

MISC does not use this normal unknown-UPC interaction.

Ordinary Field Session price/label capture is independent of successful catalog identification: when prompting is enabled, an unknown scanned or typed UPC may still present the label-price modal after optional SKU entry is cancelled or SKU resolution fails. The observed UPC remains available for a Missing Label or price observation, without creating a claimed SKU/catalog relationship. Any `FOUND` UPC/SKU path that reaches a terminal item presentation is also eligible for the prompt. Identity conflicts and ambiguity do not bypass their existing terminal protections.

## Local record refresh

Found Ace-derived Local items may receive current full-catalog refresh through Catalog Refresh Service according to Local field/user-correction rules when AceNet Comparison and UPC Enrichment are effectively enabled.

When UPC Enrichment is OFF but Comparison remains ON, ordinary Local presentation uses price-only live comparison rather than the complete UPC/catalog enrichment path.

Third-party-vendor Local items do not automatically dispatch AceNet background refresh; AceNet absence is expected for that dataset.

Official Master remains physically protected from broad live refresh.

## Retail Units

Retail Units is resolved separately through `UPCRetailUnitsResolver`, which uses Effective Catalog physical evidence:

1. Master RU;
2. Local RU;
3. default 1.

Retail Units never triggers AceNet.

## Price Change / list integration

Normal search may provide independent `libraryPrice`, `aceNetPrice`, and `labelPrice` values to the active Field Session.

List purpose/business action remains owned by Field Session/List Item controllers.

## Diagnostics

Normal lookup records:

- operation ID/generation;
- raw/effective identifier;
- local resolution outcome/provenance;
- local presentation timing;
- total-to-presentation time;
- whether AceNet background work launched;
- AceNet price/enrichment terminal outcome;
- missing-SKU persistence/read-back outcome;
- supersession/inconclusive state.

Local presentation success must not be withheld until background enrichment ends.

## Verification

Tests protect local resolver ownership, immediate local presentation, stale-generation rejection, known-unavailable gate, shared broker usage, shared typed NOT_FOUND handling, price-before-UPC enrichment, current relationship handoff, full-catalog durable missing-SKU recovery, Retail Units independence, and absence of promoted/retired persistence paths.
