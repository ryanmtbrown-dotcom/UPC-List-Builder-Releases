# ChatGPT Planogram Import Contract — Build 1

**Status:** Required interface/security/validation contract, not a deployed importer. **Baseline:** UPC List Builder main `2ae0f2084b2b7de3931aa5d77f8f8b0d25718ce8`. **Parent:** Two-Build Location Implementation Plan v4. **Applies to:** ChatGPT AI interpretation → existing @UPC plugin tool → authenticated Cloudflare D1 queue → paired Android app's structured receiver → IndexedDB.

## Non-negotiable pipeline boundary

An employee supplies the Ace PDF *to ChatGPT*. The AI interprets content and visual geometry. The existing @UPC integration gets **new, planogram-specific structured submission and status tools**, not a substitute standalone importer. Cloudflare and Android receive **validated structured records**, never original PDF bytes, image blobs, OCR jobs, or a new coded document-conversion engine. Portable, deterministic schema validation, identity checks, row reconciliation, and atomic persistence are permitted; they do **not** independently parse PDFs. The current DSD invoice importer, owner isolation, user pairing, workbook schemas, and DSD tool semantics must remain unchanged.

The existing DSD `submit_dsd_import` tool is **not** a planogram transport. Implement separate planogram tool declarations under `tools.mjs`, strict `planogram-validate.mjs` and bounded `planogram-queue.mjs`, and a separate `/api/v1/planograms` device route and D1 migration. OAuth `dsd:write` does not automatically authorize `planogram:write`. Tool invocation must have operation-appropriate scope; device operations must verify bound owner through the existing paired-token mechanism. The consent screen must describe planogram permissions accurately, not continue describing only invoices when planogram scope is requested.

## Source-evidence contract: merchandise, not every PDF line

The **Ace Hardware Product Report** provides the membership roster and source placement facts. The SKU diagrams, cover view, shelving profiles and fixture notes provide relative placement/fixture context. Sources may disagree or omit a field: report discrepancies, do not fill from guesses. Source fixtures, peg hooks, wire-front/divider quantities, signs, empty displays, and rack hardware do not automatically become sellable expected merchandise. A fixture's own part number may appear in a Product Report, so classify by description/context as well as report placement. Do not classify every SKU in a fixture report as merchandise. A merchandising item with a zero price remains merchandise if other evidence establishes it; price is not a planogram membership test.

Six required real-world document families supplied as acceptance references:

| Planogram | Source code | Nominal width | Source pattern that must be supported |
| --- | --- | --- | --- |
| Screwdrivers | `S2SCRWDV` | 4 ft | peg hooks and waterfall-rack fixture items; fixture exclusions |
| Sockets/Wrenches | `S2CMSCKT` | 12 ft | three source segments, shelves, pegboard, nonmerchandise signs |
| Snips/Pliers | `S2CMPLRS` | 8 ft | two source segments and source peg ROW/COL coordinates |
| Tape | `S1TAPE04` | 8 ft | shelves and peg hooks; SKU `12704` repeated in Product Report; one SKU need not imply two ordering labels |
| Hand/Power Sandpaper | `S1SANDHP` | 12 ft | specialty fixture/pocket racks and shelf rows; position may be approximate |
| Nails/Screws | `N5NLSSCW` | 8 ft | dense shelf report, nominal ROW and source fixture locations |

These source codes and examples are sample *document evidence*, not a release claim that all source report rows were fully extracted or verified. Future Ace PDFs may use different tables. Do not assume all 12-foot sources have three segments or all 8-foot sources have two.

## Versioned validated submission schema — `PLANOGRAM_IMPORT_V1`

**Top-level required:** `schemaVersion`, `source`, `sourceSegments`, `placements`, `reconciliation`, `exclusions`, `unresolved`, `manifest`. Additional unknown fields are rejected or flagged as an incompatible future version; no silently discarded unfamiliar fields. The specific wire JSON types/limits are finalized as part of Build 1 B1.4, then **the exact same version and required meanings are enforced** in MCP tool schema, server validator, queue assembly, and Android structured receiver.

`source` contains `planogramId` (stable source code if supplied), `name`, optional `commodityCode/group`, optional `liveDate` **only if printed**, `nominalWidthFt` when document supports it, `sourceFilename` for user inspection, and `sourceIdentityEvidence`. Do not assume a PDF's filename is official identity. `sourceSegments` preserve source segment order, fixture identifiers, optional drawing-relative evidence; a source segment is never a physical store section.

Every `placements[]` row represents one **documented source placement**, with a unique within-import `sourceRowId`, `sku` string when listed, original `upcOrGtin` string (preserve leading zeroes), `description` when present, `sourceSegment`, `fixtureType` (`PEG`, `SHELF`, `SPCFIX`, `OTHER`, `UNKNOWN`), optional source `reportRow`, `reportColumn`, optional source fixture/location and facings, and `membershipDisposition` (`MERCHANDISE`, `NON_MERCHANDISE`, or `UNRESOLVED`). Distinguish exact report values from interpreted source-relative row/column. An unresolved SKU/UPC is not silently matched to another product.

`reconciliation` contains mutually explainable counts for **all report rows**: `sourceReportRows`, `submittedRowRecords`, `merchandiseRows`, `excludedNonMerchandiseRows`, `unresolvedRows`, `distinctMerchandiseSkus`, and `unrepresentedRows` (normally zero for a complete import). Repeated merchandise rows are retained as separate *source placements* while unique SKU membership is counted once per source. Preserve the reason and source context for each excluded/unresolved row; negative, impossible, or mismatched totals reject acceptance. No successful `complete` label if rows were skipped, or source report totals cannot be substantiated. The employee can review explicitly incomplete evidence without it being silently committed as complete authoritative membership.

`exclusions[]` and `unresolved[]` include a row reference, narrow reason/category, and supporting source snippet/page or documented ambiguity. `manifest` contains validated chunk identifiers/counts, canonical content digest and submission status. Exact caps must be explicit and testable; never silently truncate a large 12-foot planogram. Chunk completion requires all validated unique chunk indices, matching source/owner/batch identity, totals and digest, and a single atomic promotion to a readable complete batch. Unfinished chunks are not device-visible accepted imports.

## SKU and UPC identity safeguards

Keep original `sku` and GTIN/UPC strings. Validate digit length/check digit before any canonical comparison. Padded GTIN-14 can correspond to another barcode form only through an explicit, safe validated conversion rule; do not indiscriminately strip leading zeroes. Reuse existing product-identity resolver for known SKU/UPC lookup; planogram import cannot create SKU↔UPC relationships in Master, Local, or `skuUpcs`. Conflicting or ambiguous source identifiers remain unresolved in the import review. The source PDF may not supply UPC for every merchandise row; no invented UPCs. No automatic catalog creation, pricing inference, retail calculation, or product order status.

## Validation chain and transaction sequence

1. **ChatGPT interpreter:** distinguish planogram versus invoice; collect Product Report merchandise rows and source geometry; provide explicit missing, excluded, and unresolved evidence; no submission without user approval when required by tool workflow.
2. **Planogram MCP input schema:** reject wrong schema version, missing identities, illegal field types, excessive strings/arrays, inconsistent report counts, invalid enum values, duplicate `sourceRowId` within a batch, bad chunk sequence, and invoice payloads presented as planograms. Do not assume a submitted JSON object is true just because it came from an LLM.
3. **Cloudflare validator/storage:** rerun deterministic validation and count reconciliation independently, strictly isolate each owner/subject, enforce per-operation OAuth scope, bounded request size and expiration, digest/idempotency, chunk-assembly atomicity, repeat-submit matching, and source-manifest immutability after completion. No D1 PDFs or base64 images. Never mix DSD invoice batches with planogram batches.
4. **Android structured receiver:** authenticate paired device, list/get **owner's** completed planogram batches, locally revalidate schema/counts/digest and unknown identifier warnings, show premium review of source ID, placements, excluded and unresolved counts, and require a separate aisle/custom-area assignment. Do not auto-pick a physical area from PDF title, nominal feet, or name similarity.
5. **Location repository:** atomically insert/replace **current structured source**, preserve factual compact last-known product associations, and preserve existing approved current physical placements unless employee separately approves editing them. New empty modular may be seeded as source-derived `ACE_IMPORT` with explicit unverified position status. An unassigned source has no invented aisle. Existing assignment overlap is a conflict with named holder.
6. **ACK:** only after durable local commit. If local commit fails, do not ACK. If ACK fails after local success, preserve idempotent local import receipt and retry ACK without duplicate placements or history entries. Never delete a user's pending import solely because a network response is missing.

## Security and operational failure cases

- Explicit planogram tool uses `planogram:write` or reviewed equivalent, independent of existing `dsd:write` semantics; `scope` enforcement must occur on the *specific tool and HTTP route* rather than solely discovery. Reauthorization can be required and must not silently broaden existing consent.
- Existing device token storage in Android secure pairing vault stays authoritative. Tokens, invoice content, user personal information and GitHub OAuth secrets are never included in diagnostics or error responses.
- Owner A cannot list, read, submit as, acknowledge, reject, or probe existence of owner B's batch. Identical IDs or digests across owners remain isolated.
- Oversized payloads are bounded; receiver cannot interpret partial chunk data as complete. Corrupt digest, wrong sequence, missing counts, wrong source code, invalid GTIN, or malformed JSON cause review/validation failure, **never truncation or guessed completion**.
- Retry same batch with matching digest is idempotent; same ID with different payload/digest is rejected. Expiration removes stale *staging* only, not accepted local planograms or last-known product references.
- On source replacement, uncertain identity (`planogramId` changed or only similar name) requires user selection. Never silently fuzzy-replace. A removed previous source member keeps an accurate `Last known Ace planogram` association; it is not reported as a **current** source expectation.
- Offline device still uses local accepted placement lookup; no per-product cloud requests. Import polling failures do not slow or break pricing and DSD operations.

## Release gates — focused contract tests

Use six reference PDF families for model-assisted **pre-release** interpretation tests and structured fixtures for deterministic validators. Specifically verify:

1. Diagram peg coordinates cannot be displayed as literal physical hook `R/C` on a compressed installation.
2. SKU `12704` on two Tape source rows contributes **one distinct source SKU**, with two source placement records, not an automatically confirmed duplicate ordering label.
3. Screwdrivers waterfall-rack numbers and Sockets tool-information signs can be classified as nonmerchandise despite appearing in source document reports.
4. Sandpaper `SPECIALTY_FIXTURE` row is not fabricated as a peg hook position.
5. Six source families reconcile merchandise, excluded and unresolved row counts with explicit no-silent-missing check.
6. Wrong owner, wrong scope, malformed schema, oversized payload/chunks, digest mismatch, missing chunk, duplicated chunk with different content, stale/replayed batch, and ACK-before-persist must fail safely.
7. Existing DSD pairing, invoice staging, manufacturer/cost/UPC verification, and exact workbook exports pass unaffected.
8. No complete claim when any underlying source row was not represented, excluded with reason, or explicitly identified as unresolved.

Do not claim source-perfect extraction from fixture-only unit tests. End-to-end ChatGPT visual interpretation on supplied actual PDFs and physical Android review are separate mandatory acceptance proofs.

## Owned implementation and stop gates

`tools.mjs` owns schema/tool declaration; new `planogram-validate.mjs` owns portable validation; new `planogram-queue.mjs` owns D1 planogram staging; `index.mjs` owns API/operation authorization; `auth.mjs` owns OAuth consent; a dedicated migration owns new D1 tables; app `planogram-import-{adapter,service,controller}.js` owns device transfer/review; `location-repository.js` owns local durable commit. Keep DSD `validate.mjs`, `queue.mjs`, and all invoice semantics unchanged. B1.0 writes only approved documents/test fixtures/allowlist entries. B1.4 implements MCP and server checks, B1.5 implements client checks, and B1.7 verifies deployed candidates. None of these stages is authorization to deploy to live Cloudflare or publish an APK.
## Required AI width and position evidence (v3.08)
- The **ChatGPT plugin** (not Android PDF extraction) must provide `source.nominalWidthFt`, `source.nominalFourFootSections` and `source.widthEvidence` traced to the Ace source. The app validates consistent numbers but never interprets PDF dimensions itself. An eight-foot official Tape planogram occupies two nominal four-foot bays.
- The AI must preserve each merchandise row's source `sourceSegment`, `reportRow`, and `reportColumn` from the Product Report. PEG merchandise must contain all available report coordinates; do not invent or discard them pending a physical audit. Optional exact special-fixture zones are `LFT`, `CL`, `CTR`, `CR`, `RGT` when the source explicitly supports them.
- **Display hierarchy:** approved current store placement, then most precise active Ace planogram position, then factual last-known source when currently absent. Accepted source positions are available immediately. Physical confirmation is never a gate for showing them.
- A deliberate re-import of the same POG ID asks for confirmation and atomically updates source-derived positions, keeping the original assigned aisle/sections, approved physical corrections, deliberate item removals, and last-known source references. No blanket deletion of location data is permitted. Re-run the five existing planograms through AI/plugin after updating the connector.
- Source-to-store mapping is one-to-one only if segment ordinals and number of bays support it. Otherwise display the occupied physical span plus `PSn` for the known Ace planogram section; do not invent a physical section when a modular is compressed/expanded.
- General/item/price-change lookups display compact factual data only (`A8 · S1 · R19 · P44`, `A8 · S2 · SF · R3 · CR`); history and source paragraphs belong in Planograms review, not a scrolled lookup card.
