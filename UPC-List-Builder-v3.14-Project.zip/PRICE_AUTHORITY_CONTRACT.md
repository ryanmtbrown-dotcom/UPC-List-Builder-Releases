# Price Authority Contract

> **REQUIRED REFERENCE RULE:** Read `NORMAL_ITEM_SEARCH_CONTRACT.md`, `ACENET_COMPARISON_TOGGLE_CONTRACT.md`, and `ITEM_PRESENTATION_CONTRACT.md` before changing price semantics.

**STATUS: CURRENT**

## Independent price-source model

Library Price, AceNet Price, and Label Price are independent values.

- For Ace-sourced merchandise, the **price-check comparison authority is verified current AceNet Store Retail (Level 2), falling back to the current Master/ACE_DERIVED Local `Level 2 Retail Price` field only when verified live Store Retail is unavailable**. Never substitute `Ace Retail Price`, `Retailer Each Price`, or a generic `Price` field; absent Level 2 evidence produces an unavailable value, not a false comparison. The original Master Level 2 field is retained as independent offline catalog evidence and is not rewritten by ordinary price comparison. Third-party Local vendor products retain their independent vendor-price model.
- AceNet comparison price comes only from verified exact-SKU current **Store Retail** evidence (`lblHeaderSellingDataStoreRetail`); this is the live Level 2 / shelf-price comparison. The Ace/Level-1 product price is a separate catalog concept and is never a price-check fallback.
- Label Price is user/list workflow input where applicable.

AceNet Price never silently overwrites Library Price in durable Master data.

Presentation labels each source truthfully. The primary lookup price and its live price-difference display must use the same `UPCPriceAuthority.observedPrice` Level 2 selector as saved Work Sessions and exports, including when a verified asynchronous AceNet price arrives. The independent Master Level 2 row remains the offline evidence; the AceNet Level 2 row displays only verified Store Retail.

Price Difference uses the intended Library/Label values for that workflow and does not redefine source authority.

## Comparison

When effective AceNet Comparison Pricing is OFF, current normal presentation omits/hides live AceNet comparison while preserving Library/Label values.

When ON and service state permits, verified AceNet price may appear asynchronously for the still-current item generation.

A stale AceNet result cannot alter another item's values.

## Persistence

Work Session items may store `libraryPrice`, `aceNetPrice`, and `labelPrice` independently. A stored AceNet number is presented as verified only when it carries `aceNetPriceAuthority=LEVEL2_STORE_RETAIL` from the corrected live extractor. Historical values lacking that marker are not silently promoted into verified Store Retail pricing. They remain in the original saved record but display as unavailable until a fresh verified lookup.

Official Master live price is not rewritten by ordinary comparison/enrichment.

Local catalog price refresh is governed by Catalog Refresh Policy, not this presentation contract.

## Verification

Tests protect the three independent fields, truthful labels, background AceNet presentation, price-difference calculation, and no source conflation.
