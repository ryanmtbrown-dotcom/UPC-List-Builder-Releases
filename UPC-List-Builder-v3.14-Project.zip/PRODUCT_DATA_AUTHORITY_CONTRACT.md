# Product Data Authority Contract

> **REQUIRED REFERENCE RULE:** Read `IDENTIFIER_RELATIONSHIP_SERVICE_CONTRACT.md`, `PRODUCT_IDENTITY_INDEX_CONTRACT.md`, `MASTER_LIBRARY_CONTRACT.md`, and `ACENET_COMPARISON_TOGGLE_CONTRACT.md` before changing catalog authority or identifier-learning behavior.

**STATUS: CURRENT**

## Purpose

Define which persisted data represents Ace merchandise, which data represents third-party merchandise, and how scans/manual identifiers are allowed to participate in lookup.

The store merchandise universe contains Ace-sourced merchandise plus third-party-vendor merchandise. These are complementary portions of one total merchandise set, not competing copies of the same source data.

## Ace-sourced merchandise

AceNet is the live upstream authority for fields exposed by the user-facing AceNet system and is the authority for the current complete secondary-UPC set of an exact SKU.

The Master Library is a periodic Home Office snapshot derived from the same underlying Ace data. It is:

- less current than live AceNet;
- available offline;
- enriched with some fields not exposed through the user-facing AceNet interface.

When current verified AceNet evidence directly contradicts an older Master or Ace-derived Local value for a field AceNet owns, current AceNet wins.

When AceNet cannot be used, Master remains the primary offline Ace catalog authority.

## Local Library roles

Local Library contains two record origins:

- `ACE_DERIVED` — a locally persisted AceNet record, commonly for an Ace SKU absent from the regional Master Library;
- `THIRD_PARTY_VENDOR` — a manually resolved product outside the Ace catalog.

An Ace-derived Local record is cached Ace data and remains subordinate to newer verified AceNet evidence.

A third-party-vendor Local record is the sole catalog source for that non-Ace portion of store merchandise. AceNet absence alone does not invalidate it.

## Official SKU authority

Locally generated SKUs are operational identifiers, not authority over future Ace assignments.

If a current official Master/AceNet SKU conflicts with a locally generated SKU, official Ace identity wins. Local data must be corrected/reclassified rather than overriding official identity.

Third-party Local creation must therefore refuse a SKU or UPC already assigned by current official Master data. Later verified AceNet evidence may convert a previously third-party Local record into Ace-derived current data when Ace officially claims that SKU.

## Scans and manual identifiers

A scanned UPC or manually typed UPC/SKU is a lookup key and user observation, not another catalog source.

The application may use that key to reach:

- Master;
- current SKU↔UPC relationships;
- Local Library;
- AceNet.

User-entered identity may support current work when live evidence is unavailable, but it never outranks later verified complete AceNet identity for Ace merchandise.

## Current relationship state

`skuUpcs` represents current lookup relationships only.

Do not add a historical/retired UPC↔SKU table merely because an association once existed. Retaining obsolete associations creates a risk that future lookup code treats stale identity as current authority.

Current complete exact-SKU AceNet evidence may remove obsolete relationships according to `IDENTIFIER_RELATIONSHIP_SERVICE_CONTRACT.md`.

## Third-party presentation and future routing

A `THIRD_PARTY_VENDOR` item uses the existing price-check surface with the live-source label rendered as **Vendor Price**.

Future ACE New Items MISC → DSD routing for third-party items is intentionally deferred. The origin field added now is the durable prerequisite; the larger DSD data-capture workflow is not implied by this contract.

## Verification

Tests protect AceNet-over-snapshot authority, official-SKU collision handling, third-party Local persistence, Ace-derived Local reclamation after verified AceNet evidence, lookup-key semantics, and the prohibition against historical relationship authority.
