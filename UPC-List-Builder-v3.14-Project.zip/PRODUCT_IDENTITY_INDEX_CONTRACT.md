# Product Identity / Work Queues Contract

> **REQUIRED REFERENCE RULE:** Read `AI_START_HERE.md`, `CURRENT_ARCHITECTURE_AUTHORITY.md`, `PRODUCT_DATA_AUTHORITY_CONTRACT.md`, `IDENTITY_RESEARCH_RESOLUTION_CONTRACT.md`, `IDENTIFIER_RELATIONSHIP_SERVICE_CONTRACT.md`, `LOCAL_IDENTIFIER_RESOLVER_CONTRACT.md`, `CATALOG_REFRESH_POLICY_CONTRACT.md`, and the AceNet retrieval contracts before changing identity behavior.

**STATUS: CURRENT**

## Purpose

Maintain durable current product-identity relationships and user-manageable unresolved/deferred work without changing Master Library authority or duplicating AceNet retrieval engines.

## Durable identity state

Current durable identity data includes:

- `skuUpcs` — current many-UPC membership per SKU;
- `skuIdentity` — SKU catalog/replacement status;
- `upcIdentityResolution` — normal/conflict/resolved UPC state;
- `identityResearchQueue` — unresolved research tasks;
- `libraryUpdateQueue` — deferred Add-to-Local-Library work;
- `meta.deferredAceNetRefreshQueue` — SKU-keyed current work captured for a later user-initiated live refresh.

Duplicate relationship writes are idempotent.

Replacement relationships are directional and cycle-protected.

A UPC associated with multiple current candidate SKUs becomes an explicit unresolved conflict; no winner is guessed.

## Normal UPC/SKU consumption

Normal UPC lookup uses local Master/Local evidence first.

After a direct local UPC miss, current saved identity relationships may resolve one unambiguous SKU.

A completely unknown UPC may ask the user for a SKU. The entered identifier is a lookup key, not an independent catalog source. A unique local catalog result may support current local relationship use; when live complete AceNet evidence is available, that evidence governs current Ace secondary-UPC membership and may replace/remove the locally observed association.

When AceNet cannot be used, unresolved SKU/UPC context is retained as research/deferred work rather than silently discarded.

A locally resolved item uses the same normal background AceNet-price enrichment boundary as an ordinary item.

## Catalog classification after local miss

For an exact SKU absent from Master and Local:

- verified complete exact-SKU AceNet catalog success is persisted immediately to durable Local Library;
- persistence is verified by read-back;
- complete ordered UPC relationships are recorded;
- SKU catalog status becomes `LOCAL_LIBRARY`;
- the normal successful discovery path does not remain deferred in Add to Local Library.

Conclusive AceNet `NOT_FOUND` may classify the item as `ACENET_NOT_FOUND` and place it in Items Needing Research.

**Timeout, unavailable, superseded, parse failure**, mismatch, or other inconclusive results are not catalog absence and must remain distinguishable from `NOT_FOUND`.

## Work queues

### Add to Local Library

This queue is for legacy/deferred repair work that still lacks durable Local completion.

The user-facing explanation identifies a deferred item verified in AceNet but not yet durably persisted to Local Library.

Legitimate sources converge on the durable SKU-keyed queue; duplicate SKU submissions are idempotent.

The batch action snapshots the queue and processes one SKU at a time.

For each SKU:

- one retained-worker `PRODUCTION_CATALOG` request supplies exact-SKU full-catalog + complete UPC evidence;
- successful complete evidence persists to Local, records relationships, verifies persistence, and removes the queue row;
- failure/unavailable/mismatch/incomplete evidence leaves that SKU queued;
- one failed SKU does not prevent later snapshot SKUs from running.

The batch does not chain PRICE, UPC-only, or per-field requests to synthesize a catalog response.

Retail Units remains outside AceNet and defaults to 1 for a genuinely new Local row when no Master/Local RU exists.

### Items Needing Research

Research contains unresolved/inconclusive or conclusively absent identities requiring later attention.

Users may recheck, correct SKU, correct UPC, classify Recall, classify Old/Deprecated Supplier, keep Unknown/Review Later, convert a verified manual case to Third-Party Vendor Local data, or deliberately delete a research task.

Correcting a research SKU changes/moves the task only; it does not manufacture a durable UPC↔SKU relationship before validation.

Recheck:

- shows immediate busy state and blocks repeat taps while active;
- verified success reclassifies/persists through current catalog policy;
- explicit `NOT_FOUND` remains research;
- inconclusive result remains research;
- refreshes queue presentation after terminal action.

### Pending Live Refresh

Normal lookup may capture a SKU when AceNet is intentionally disabled or temporarily unavailable. The queue is deduplicated by SKU and may retain observed UPC context.

The user initiates **Refresh Pending Item Data** after AceNet Comparison is enabled. Processing is sequential and uses the shared exact-SKU catalog/Catalog Refresh path so complete current UPC evidence is harvested through the relationship owner.

Conclusive NOT_FOUND or SKU mismatch becomes research; unavailable/inconclusive work remains pending. ACE MISC keeps its separate required verification queue.

### SKU Conflicts

A conflict means one UPC has multiple current SKU candidates without a valid current resolution.

The user may:

- choose a current SKU; or
- choose Unknown / research later.

Choosing a current SKU:

- records directional replacement relationships for nonpreferred candidates through the cycle-protected identity owner;
- preserves direction evidence such as scanned-replaces-existing versus existing-replaces-scanned;
- resolves the UPC only when the preferred SKU is a current candidate;
- adds the selected current SKU once to the Alaska-date-scoped `ACE New Items · <date>` Work Session, creating it if necessary.

Unknown leaves the conflict unresolved.

Failed/cyclic replacement does not remove the conflict.

## MISC identity ingestion

After MISC obtains a complete exact-SKU verified UPC set, those current relationships are recorded through `UPCIdentifierRelationshipService`.

No second AceNet request is created just for identity ingestion.

Duplicate relationships remain idempotent; cross-SKU membership creates/updates explicit conflict state.

MISC keeps its own ordered UPC/export semantics.

## Local correction and repair

Database/identity management may edit mutable Local Library fields and request verified repair.

User-corrected Local fields are overrides and must not be silently replaced by automatic repair.

`VERIFIED_PARTIAL` repair:

- applies only positively verified returned fields;
- records missing fields for evidence/provenance;
- preserves stored values when evidence is missing;
- may merge observed UPC relationships;
- must not delete absent relationships or change canonical UPC.

Imported Master rows remain protected/read-only except for the separately guarded Master canonical UPC rule.

## Database Viewer

Database Viewer presents identity/work records as readable mobile-first cards/lists.

Current identity stores/queues remain browseable as complete collections; search/filter may assist but does not replace whole-list visibility.

Manageable research/deferred Local work exposes appropriate edit/remove actions. Protected Master identity remains read-only.

## Diagnostics

Identity workflow diagnostics distinguish:

- provisional user identity;
- post-validation relationship commit;
- local catalog classification;
- durable AceNet-to-Local persistence/read-back;
- research classification and recheck result;
- conflict resolution/unknown outcome;
- deferred Local update requested/completed/deferred;
- exact reason for inconclusive versus `NOT_FOUND`.

Diagnostic evidence does not become identity authority.

## Verification

Tests protect:

- schema/store presence and restart persistence;
- provisional-before-validation user identity;
- Master/Local classification;
- immediate verified Local persistence;
- explicit distinction between `NOT_FOUND` and inconclusive outcomes;
- queue presentation/lifecycle;
- conflict/replacement cycle rules;
- MISC current relationship ingestion;
- sequential deferred Local batch behavior;
- repair/user-override rules;
- absence of promoted-Master reconciliation.
