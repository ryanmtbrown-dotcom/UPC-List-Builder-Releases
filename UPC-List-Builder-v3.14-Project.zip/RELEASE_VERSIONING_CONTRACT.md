# Release and Versioning Contract

**STATUS: SEALED CURRENT CONTRACT**

## Purpose

Keep Android package metadata, web runtime identity, diagnostics, release artifacts, and updater metadata synchronized to one authored release identity.

## Authored authority

`gradle.properties` is the single authored source for:
- `UPC_VERSION_NAME`
- `UPC_VERSION_CODE`
- `UPC_BUILD_ID`

Do not independently hand-edit current release identity in web or Kotlin runtime files.

## Derived runtime identity

Android package metadata reads Gradle properties.

Native runtime build identity uses generated `BuildConfig.UPC_BUILD_ID`; Kotlin source must not copy the current build ID literal.

Static web assets necessarily contain derived identity/cache markers. `scripts/sync-release-identity.mjs` synchronizes:
- `app.v059.js`
- `index.html`
- `service-worker.js`
- `manifest.webmanifest`

`verify-project.sh` runs synchronization in check mode and fails on drift rather than silently mutating committed source.

The obsolete `build.json` identity copy is forbidden.

## Version-change procedure

For a changed deployable release:
1. update `gradle.properties` version name/code/build ID;
2. run `node scripts/sync-release-identity.mjs`;
3. run the complete verifier;
4. follow `DEPLOYMENT_CONTRACT.md` for the GitHub-native default release path. Use `TERMUX_DEPLOYMENT_CONTRACT.md` only for an explicitly selected fallback/recovery deployment.

Version code must remain positive and advance for deployable Android releases.

## Diagnostics and artifacts

Diagnostic exports display the running release version/build from current runtime authority.

APK/project package/update metadata must describe the same release identity. A build artifact produced from another SHA or another identity is not proof for the intended release.

## Publication boundary

Draft architecture pull requests may verify source, dependencies, signed APK generation, and project packaging. They must not modify the public updater feed.

Push-to-main release workflow remains the updater publication authority.

Candidate artifacts, when supported by the workflow, must not overwrite `update.json` or the stable latest APK.

## Verified workflow artifact handoff

Every successful verification/build run uploads one private GitHub Actions artifact named for the current release. It contains:
- the exact audited project ZIP produced by `package-release.sh`;
- the versioned signed APK produced by the same run;
- the generated `update.json` metadata.

This artifact is a handoff mechanism only. Uploading it does not publish the public updater feed and does not replace the main-push publication boundary.

## Platform boundary

Android is the native release target. Browser/PWA cache identity is still synchronized to the same build ID but browser install/service-worker behavior does not own native update/install policy.

## Tests

Permanent tests/guards protect:
- Gradle as authored authority;
- synchronized web build markers;
- BuildConfig-derived native identity;
- absence of obsolete `build.json`;
- diagnostic runtime identity;
- deployment authority routing through `DEPLOYMENT_CONTRACT.md`, with `TERMUX_DEPLOYMENT_CONTRACT.md` retained as fallback/recovery only.

Release/versioning does not independently redefine subsystem behavior.
