# Repository Boundaries Contract

> **REQUIRED REFERENCE RULE:** Read `AI_START_HERE.md`, `CURRENT_ARCHITECTURE_AUTHORITY.md`, and `SOURCE_OWNERSHIP_MAP.md` before changing persistence ownership.

**STATUS: CURRENT**

## Purpose

Keep workflow/domain code above focused repository/service boundaries while preserving the current IndexedDB schema and durable record shapes.

Required dependency direction:

`controller/workspace → domain/application service → repository facade → UPCDB → IndexedDB`

Repositories adapt physical persistence. They do not own UI, navigation, AceNet session/retrieval policy, or unrelated domain behavior.

## Raw IndexedDB owner

`db.js` is the sole direct `indexedDB` owner.

Current database identity remains `upc-list-builder`, schema version 8. Current stores include:

- `lists`
- `library`
- `meta`
- `diagnostics`
- `libraryUpdateQueue`
- `skuUpcs`
- `skuIdentity`
- `upcIdentityResolution`
- `identityResearchQueue`

A repository refactor does not authorize renaming/removing stores, changing the database version, or silently reshaping durable records.

## Work Session persistence

`UPCWorkSessionRepository` is the sole production adapter for physical `lists` CRUD.

`UPCWorkSessionService` is the workflow-facing owner for create/open/save/list/delete behavior.

Field Session, DSD, MISC, migration preparation, and MISC maintenance must cross the Work Session service/repository boundary rather than call raw list-store APIs.

## Master Repository

`UPCMasterRepository` owns workflow-facing access to:

- active Master metadata;
- active Master records;
- exact/prefix UPC lookup;
- exact SKU lookup;
- canonical Master UPC correction;
- generation staging, activation support, cleanup/discard, and reindexing.

It does not own Local Library rows, identity relationships, UI, AceNet transport, or broad live AceNet overwrite of official Master rows.

## Local Repository

`UPCLocalRepository` owns workflow-facing access to:

- durable Local Library metadata/records;
- exact/prefix UPC and exact SKU Local lookup;
- verified AceNet Local staging;
- user corrections;
- Local AceNet verification state;
- canonical Local UPC correction;
- repair-candidate reads;
- Add-to-Local/update queue persistence.

It does not own Work Sessions, Master records, identity conflict policy, or MISC session maintenance.

## Identity Repository and relationship service

`UPCIdentityRepository` owns physical persistence adaptation for current SKU↔UPC membership, SKU identity/replacement state, UPC conflict/resolution state, and identity research state.

Workflow/domain callers use `UPCIdentifierRelationshipService` for current relationship semantics. They do not call the Identity Repository directly unless explicitly documented as an infrastructure/inspection owner.

## Migration Repository

`UPCMigrationRepository` owns only currently supported bounded migration/retirement work.

Current supported responsibilities are:

- one-time import/normalization of supported legacy Work Session data through `UPCWorkSessionService`;
- one-time deprecated-state retirement still required by the maintained migration contract.

The existing implementation name `retireStage9LegacyState()` and durable migration marker remain stable migration identifiers; they do not authorize historical runtime machinery to return.

Migration code may inspect only the stores explicitly required by that migration and must be idempotent. Obsolete migrations are deleted when their support target is retired.

## Other approved UPCDB consumers

Direct `UPCDB` use outside the named repository facades is limited to explicitly audited infrastructure:

- application composition obtaining the database handle for backup/restore;
- complete application-data backup/restore;
- the migration owner described above.

Read-only database inspection composes through repository surfaces rather than becoming another raw persistence owner.

## Cross-domain rules

- Normal lookup mutates catalog/identity state only through Catalog Refresh Service and Identifier Relationship Service.
- DSD and MISC workspace owners persist sessions only through Work Session Service.
- MISC maintenance traverses/saves MISC Work Sessions through Work Session Service; Local Repository is not a Work Session owner.
- Combined Master Export is read-only over Master/Local repository data.
- Field Session export is read-only over the active Work Session snapshot supplied by composition.
- Database viewer/inspection does not gain mutation authority.
- Repository facades never call upward into UI/workflow owners.

## Verification

Maintained architecture tests must prove:

- `indexedDB` access remains isolated to `db.js`;
- raw `UPCDB` use stays within the approved infrastructure set;
- no production code outside `work-session-repository.js` performs raw `lists` CRUD;
- repository load order remains above `db.js` and below workflow consumers;
- Effective Catalog and relationship services consume repository facades rather than raw storage;
- no duplicate Master/Local/Identity persistence owner appears;
- IndexedDB version/store identity remains unchanged unless a separately approved schema migration changes it.


## Store location persistence (Build 1)
The raw storage adapter alone creates location object stores and indexes. `store-locations/location-repository.js` is the sole approved location domain storage facade and may call `UPCDB.open()` to make short multi-store transactions. It must not write Master/Local, SKU/UPC relationship state, work lists, or DSD invoice queues. It must provide SKU-indexed reads and atomic source/layout/association updates. The existing Application Data Backup owner alone performs full-store snapshot/restore.
