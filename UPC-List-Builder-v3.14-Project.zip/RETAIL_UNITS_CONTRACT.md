# Retail Units Contract

> **REQUIRED REFERENCE RULE:** Read `EFFECTIVE_CATALOG_RESOLVER_CONTRACT.md` and `CATALOG_FIELD_MAPPING_CONTRACT.md` before changing Retail Units behavior.

**STATUS: CURRENT**

## Purpose

Define Retail Units authority independently of Order Multiple and AceNet retrieval.

## Current Local Library fallback

For a normalized SKU, `UPCRetailUnitsResolver` obtains physical evidence through `UPCEffectiveCatalogResolver.inspectSKU()`.

Authority order:

1. unique Master Library Retail Units when valid;
2. otherwise unique Local Library Retail Units when valid;
3. otherwise default `1`.

A local lookup failure may use the current safe default/failure result without starting network work.

## Rules

- Retail Units and Order Multiple are separate fields.
- Order Multiple is never substituted for Retail Units.
- AceNet is not Retail Units authority.
- Resolving Retail Units never dispatches an AceNet request.
- Consumers receive value plus truthful source such as `MASTER_LIBRARY`, `LOCAL_LIBRARY`, or current default classification.

## Diagnostics and verification

Resolution records operation lifecycle, selected source, value/default reason, and local lookup failure where applicable.

Tests protect Master → Local → default order, Effective Catalog ownership, no direct repository bypass, and no AceNet dependency.
