# Termux Fallback / Recovery Deployment Contract

**STATUS: CURRENT FALLBACK PROCEDURE**

**Scope:** GitHub-native deployment is the normal release path under `DEPLOYMENT_CONTRACT.md`. This document is authoritative only when Termux fallback/recovery is explicitly selected.

> **REQUIRED REFERENCE RULE:** Every current project authority, contract, script, workflow, or setup file named by this document for the task being performed is a **REQUIRED READ**, not an optional reference. Follow its current instructions before acting; if it points to another current authority, that next file is REQUIRED too. `AI_START_HERE.md` remains the REQUIRED first-stop authority.


`AI_START_HERE.md` and `DEPLOYMENT_CONTRACT.md` are the policy authorities. When the Termux fallback is selected, `deploy-termux.sh` is the sole executable authority for post-copy deployment from `~/upc-list-builder-android`.

Mandatory sequence:
1. Work only in the existing authenticated `~/upc-list-builder-android` Git repository. Never replace `.git`.
2. Run the complete `verify-project.sh` gate and `git diff --check` before commit.
3. Commit and push `main` exactly once. The push is what triggers the normal APK workflow.
4. Capture the exact pushed HEAD SHA.
5. Poll GitHub Actions until the push-triggered `build-apk.yml` run whose `headSha` exactly equals that SHA is registered. Do not guess the newest run and do not use a fixed sleep as proof.
6. Print the current run list while waiting so deployment activity is visible.
7. Automatically run `gh run watch <exact-run-id> --exit-status`. Termux fallback deployment must never return to the prompt after push without watching the exact build to terminal success/failure.
8. On failure, automatically print and preserve the complete failed-job log before exiting nonzero. Do not guess at compiler errors.
9. Do not manually `workflow_dispatch` during routine deployment; that can create duplicate/wrong-source builds.
10. GitHub `Build signed APK` is the authoritative native compile gate. Local static verification is necessary but not sufficient.

Historical release documents may describe old deployment procedures only when explicitly marked historical/superseded. They are not executable authorities.

## Mandatory final release-archive integrity gate
A deployable project ZIP is not complete until the FINAL ZIP itself has been reopened and audited. Verification of the source/work tree alone is insufficient.

Before a project ZIP is delivered:
1. Build the archive from the complete project tree while excluding only explicitly forbidden release artifacts such as `.git`.
2. Reopen/list the finished ZIP rather than trusting the packaging command.
3. Confirm every deployment-critical file exists INSIDE the ZIP, including hidden paths. At minimum this includes `.github/workflows/build-apk.yml`, `AI_START_HERE.md`, `TERMUX_DEPLOYMENT_CONTRACT.md`, `verify-project.sh`, `deploy-termux.sh`, `package-release.sh`, Gradle project files, Android application source/assets, signing material required by the existing workflow, and every current contract/test required by `verify-project.sh`.
4. Extract the final ZIP into a clean temporary directory and run `verify-project.sh` from that extracted copy.
5. Run `git diff --check` against the working project before packaging when Git metadata is available; `.git` itself must never be placed in the release ZIP.
6. Reject the release if any required hidden file is absent, if extraction verification fails, or if `.git` is present.
7. Calculate and report SHA-256 only AFTER this final archive audit passes. A ZIP modified after hashing must be re-audited and re-hashed.

`package-release.sh` is the executable release-archive gate. A future deployable package must not be handed to the user unless that script (or an explicitly equivalent replacement authorized in this contract) succeeds against the exact ZIP being delivered.


## Release ZIP installation into the persistent Termux repository

The persistent repository may contain files that were valid in an older release but intentionally removed in a newer release.
Therefore **a release ZIP must never be installed with a plain overlay unzip into the repository root**. Overlay extraction leaves
obsolete files behind, and `verify-project.sh` is intentionally required to reject that mixed-version tree.

Before extracting a new project ZIP into `$HOME/upc-list-builder-android`, preserve `.git` but remove every project-controlled
path from the previous working tree. The canonical installer is `install-release-termux.sh`, which:

1. verifies the expected existing Git repository, origin, and `main` branch;
2. removes all tracked and untracked project files/directories except `.git`;
3. extracts the selected release ZIP into the now-clean repository working tree;
4. restores executable permissions for release scripts;
5. runs `verify-project.sh` before deployment.

This clean replacement is mandatory for release ZIP upgrades. It does not delete `.git`, Git history, the configured origin,
or authentication. `deploy-termux.sh` remains the commit/push/build authority after installation.

## REQUIRED Termux fallback user-facing handoff — exact canonical procedure

**REQUIRED:** Before giving Termux fallback deployment instructions, read this file AND the current `install-release-termux.sh`, `deploy-termux.sh`, `verify-project.sh`, `package-release.sh`, and `.github/workflows/build-apk.yml`. Do not provide deployment commands from memory.

**REQUIRED Termux fallback changed-release procedure:** For every newly changed project ZIP, the final response must provide one complete copy/paste Termux block that:
1. sets `ZIP` to the exact delivered ZIP filename in `/storage/emulated/0/Download/`;
2. confirms the ZIP exists;
3. enters the existing authenticated `~/upc-list-builder-android` repository;
4. copies the currently installed `install-release-termux.sh` to a temporary path outside the repository before replacement;
5. runs that preserved installer against the new ZIP, which cleans the old project tree while preserving `.git`, extracts the release, restores executable permissions, and verifies the installed release;
6. returns to `~/upc-list-builder-android`;
7. runs the release's own `deploy-termux.sh` with the release/change description.

The canonical template is:

```bash
cd ~/upc-list-builder-android || exit 1

ZIP="/storage/emulated/0/Download/EXACT_DELIVERED_PROJECT_ZIP.zip"

[ -f "$ZIP" ] || {
  echo "ERROR: release ZIP not found in Download: $ZIP"
  exit 1
}

TMP_INSTALL="/data/data/com.termux/files/usr/tmp/install-release-termux-current.sh"
cp install-release-termux.sh "$TMP_INSTALL" || exit 1
chmod +x "$TMP_INSTALL" || exit 1

bash "$TMP_INSTALL" "$ZIP" || exit 1

cd ~/upc-list-builder-android || exit 1

bash ./deploy-termux.sh "EXACT RELEASE/CHANGE DESCRIPTION"
```

**REQUIRED:** Replace both placeholders before presenting the block. Never give the placeholders to the user as if they were executable final instructions.

**REQUIRED:** Do not append a separate manual `git add`, `git commit`, `git push`, arbitrary `gh workflow run`, fixed sleep, newest-run guess, or manual build-watch sequence. `deploy-termux.sh` owns verification, `git diff --check`, the single commit/push, exact pushed-HEAD SHA capture, exact workflow-run discovery, live `gh run watch`, and automatic failed-job log preservation.

**REQUIRED no-change exception:** `bash ./deploy-termux.sh --rebuild-head` is only for an intentional rebuild of an already-pushed, unchanged HEAD. It is NOT the normal deployment command for a newly changed release ZIP. If `deploy-termux.sh` reports `no release changes to commit`, determine whether the intended release was already pushed before instructing `--rebuild-head`; do not use it to conceal a failed installation or missing project changes.

**REQUIRED fallback final-answer check:** Before sending Termux fallback instructions, compare the proposed Termux block against this section line-by-line. If clean install, exact ZIP filename, preserved installer, release deployment command, exact-SHA watch ownership, or failure-log ownership is missing, the response is incomplete.

## REQUIRED bounded network recovery
Canonical Termux fallback deployment must tolerate transient DNS/network failures without losing a verified release commit. Git push, origin-SHA confirmation, and GitHub API operations use bounded retries with hard per-attempt timeouts. If a prior release run already created the intended local HEAD but failed before push, rerunning the same `deploy-termux.sh "release description"` command must resume that preserved commit; do not reinstall the ZIP or manufacture a duplicate commit. A transport failure from `gh run watch` is not sufficient evidence that the build failed: query the exact run's authoritative status/conclusion and reattach while it remains queued/in-progress or GitHub is temporarily unreachable. Preserve failed-job logs only after the exact run reports a completed non-success conclusion.
