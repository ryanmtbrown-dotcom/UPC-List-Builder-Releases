# UI Operation Lifecycle / Request Ownership Contract

> **REQUIRED REFERENCE RULE:** Read `AI_START_HERE.md`, `CURRENT_ARCHITECTURE_AUTHORITY.md`, and the affected lookup/navigation/dialog contract before changing asynchronous UI ownership.

**STATUS: CURRENT**

## Purpose

Prevent asynchronous work from leaving presentation indefinitely pending or allowing stale work to overwrite newer state.

## Lookup presentation ownership

- Long-running lookup presentation has an explicit current generation/owner.
- A newer lookup supersedes prior presentation ownership.
- Stale generations are rejected rather than allowed to clear/replace the current pending/result surface.
- Terminal lookup paths finish the current generation before rendering terminal state.
- Loading/pending state is presentation state only; it never creates item, authentication, service-health, price, catalog, or persistence authority.

`UPCItemPresentationController` owns the presentation generation.

Master/Local presentation may complete the foreground lookup while optional AceNet enrichment continues as background work bound to the same generation. A newer generation makes older enrichment presentation-ineligible without requiring the user to wait for it.

## Native AceNet request ownership

AceNet request correlation is request-ID based through `UPCAceNetClient`.

Unknown, stale, superseded, timed-out, or otherwise closed native results do not regain presentation ownership.

Request bookkeeping belongs to the broker; presentation eligibility belongs to the presentation controller.

## Unknown identity terminalization

A General List unknown-UPC/SKU-validation path may not remain pending indefinitely.

When the approved local/AceNet validation boundaries finish without verified exact-SKU evidence, the owning lookup generation finishes pending presentation before the Items Needing Research result is shown.

Supersession and stale-result rejection remain unchanged.

## Application dialogs

User-facing message, confirmation, and text-entry interactions use the shared in-app dialog service.

Replacing browser-native alert/confirm/prompt presentation does not change the calling workflow's business decision, cancellation behavior, or validation semantics.

The PWA install prompt is a browser installation capability, not an application message dialog, and remains outside this rule.

## Diagnostics

Ownership decisions record enough evidence to identify:

- requested generation/request ID;
- current owner;
- supersession/stale rejection;
- terminal result;
- pending-state completion.

Diagnostics remain observational.

## Verification

Tests protect:

- generation increment/current-owner behavior;
- stale generation rejection;
- request-ID ownership;
- stale native result rejection;
- terminal pending-state removal;
- unknown-identity terminalization;
- shared dialog presentation without changing caller semantics.
