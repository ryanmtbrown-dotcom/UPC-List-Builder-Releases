# UPC List Builder updater setup — v0.60+

> **REQUIRED REFERENCE RULE:** `AI_START_HERE.md` and `DEPLOYMENT_CONTRACT.md` are REQUIRED reads for release/deployment work governed by this document. `TERMUX_DEPLOYMENT_CONTRACT.md` is additionally required only when the Termux fallback/recovery path is used. Current workflow and release-delivery files named here are REQUIRED reads before changing their behavior.

The private source repository is `ryanmtbrown-dotcom/UPC-List-Builder`.
The public binary feed repository is `ryanmtbrown-dotcom/UPC-List-Builder-Releases`.

Required source-repository Actions secret:

`UPDATER_REPO_TOKEN`

Use a fine-grained GitHub PAT scoped only to `UPC-List-Builder-Releases` with Repository Contents: Read and write. Do not embed this token in Android code.

On each push to `main`, the APK workflow builds the stable-signed APK and publishes these files to the public release repository's `main` branch:

- `update.json`
- `UPC-List-Builder-latest.apk`
- `README.md`

The app checks the raw public `update.json`, verifies the APK's size and SHA-256 before opening the Android installer.

The publishing step intentionally has no retry loop and has an 8-minute timeout so it cannot hang indefinitely.

The build workflow serializes runs by workflow/ref with `cancel-in-progress: true`. A newer `main` release commit cancels superseded in-progress builds before they can race to publish different APKs under the same release identity. README filename literals must be shell-safe and must not execute command substitutions.


## Verified candidate delivery
For same-repository pull-request verification, the workflow may publish versioned candidate files to the public binary repository after the complete verifier, Android APK build, and `package-release.sh` audit pass. Candidate publication is limited to `UPC-List-Builder-v<version>-Candidate.apk` and `UPC-List-Builder-v<version>-Project.zip`; it MUST NOT modify `update.json` or `UPC-List-Builder-latest.apk`. The normal push-to-main publication remains the only updater-feed authority.
