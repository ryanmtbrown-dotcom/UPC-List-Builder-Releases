plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

val upcBuildId = providers.gradleProperty("UPC_BUILD_ID").get()

android {
    namespace = "com.rmtb.upclistbuilder"
    compileSdk = 36
    signingConfigs {
        create("stable") {
            storeFile = rootProject.file("signing/upc-list-builder.jks")
            storePassword = "upclistbuilder"
            keyAlias = "upclistbuilder"
            keyPassword = "upclistbuilder"
        }
    }
    defaultConfig {
        applicationId = "com.rmtb.upclistbuilder"
        minSdk = 26
        targetSdk = 36
        versionCode = providers.gradleProperty("UPC_VERSION_CODE").get().toInt()
        versionName = providers.gradleProperty("UPC_VERSION_NAME").get()
        buildConfigField("String", "UPC_BUILD_ID", "\"$upcBuildId\"")
    }
    buildFeatures { buildConfig = true }
    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("stable") }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.17.0")
    implementation("androidx.appcompat:appcompat:1.7.1")
    implementation("androidx.activity:activity-ktx:1.11.0")
    implementation("androidx.webkit:webkit:1.14.0")
    implementation("androidx.camera:camera-core:1.5.0")
    implementation("androidx.camera:camera-camera2:1.5.0")
    implementation("androidx.camera:camera-lifecycle:1.5.0")
    implementation("androidx.camera:camera-view:1.5.0")
    implementation("com.google.mlkit:barcode-scanning:17.3.0")
}
