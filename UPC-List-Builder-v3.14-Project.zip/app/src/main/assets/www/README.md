# Web Runtime Ownership

OWNS: the first-party packaged web runtime executed in browser or Android WebView.

MAY CONTAIN: foundational domain owners, application/workspace controllers, repositories, platform adapters, diagnostics, and presentation styles.

DOES NOT OWN: Android API implementation, native AceNet page extraction, or hidden duplicate business authorities.

LAYERING: UI/workspace → services/domain → repositories → `db.js`; platform calls cross explicit adapters/bridge boundaries. New feature code should go in a named domain directory rather than the root when such a directory exists.

The authoritative placement map is `SOURCE_OWNERSHIP_MAP.md`.

PRESENTATION SYSTEM: `styles.v059.css` owns shared portrait-first design tokens, shell/home/builder/settings/list primitives, and cross-surface visual consistency. Owner-specific stylesheets under application/, dsd/, administration/, and misc/ consume those shared tokens while retaining their own domain presentation ownership. HTML/CSS presentation work must preserve JavaScript IDs, behavioral data attributes, form relationships, and event-delegation structure unless proven safe.
