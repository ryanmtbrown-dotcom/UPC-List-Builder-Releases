/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/ace-misc.js
 * Owner: ACE MISC Domain
 * Role: Domain/export service
 * Responsibility: Owns MISC workbook/domain primitives, the exact ACE MISC row/layout formatter, export row composition, verification-state constants, and approved MISC UPC-domain helpers.
 * Does not own: MISC workspace UI; Work Session persistence; normal lookup; native AceNet session/extraction; raw IndexedDB.
 * Side effects: May build XLSX bytes and use approved relationship capabilities; file delivery is delegated by the MISC workspace through the platform boundary; no raw catalog-store authority.
 * Related code: ACE MISC header identity belongs to catalog/standard-export-schema.js; ordinary Field Session export may invoke the pure available-evidence formatter; new MISC workflow code belongs in misc/; persistence belongs to Work Session/catalog/identity owners.
 */
const ACEMisc=(()=>{
 const HEADERS=UPCStandardExportSchema.ACE_MISC_HEADERS;
 const YELLOW=[0,3,4,5,6,14,16,18,21,23,24,25,30,31];
 const POS={10:'55',14:'56',20:'57',28:'58',30:'59',34:'60',40:'61',46:'62',50:'63',56:'64',58:'67',60:'68',64:'69',70:'70',76:'71',80:'72',84:'73',88:'74',90:'75',94:'77'};
 const SOURCES=[
  ['ACE SKU'],['RSC'],['Article Status'],['Description'],['MFG #'],['Order Multiple'],['Retail Units'],['Length of OM (Inch)'],['Width of OM (Inch)'],['Height of OM (Inch)'],['Cubic Feet of OM'],['Weight'],['RSC Quantity'],['Expected Arrival Date of Next RSC PO'],['Retailer Each Cost'],['Price Strategy'],['Ace Retail Price'],['Level 1 Retail Price'],['Level 2 Retail Price'],['AH.COM Retail Price'],['Velocity Code'],null,['Ace Vendor Number'],['Commodity Group'],['Merchandise Class Number'],['Product Group Number'],['Product Definition Code'],['Discovery Item'],['Last Purchase Date'],['Country of Origin'],null,null,null
 ];
 const UPC_VERIFICATION=Object.freeze({
  VERIFIED_COMPLETE:'VERIFIED_COMPLETE',
   VERIFIED_NO_ACENET_UPC_DATA:'VERIFIED_NO_ACENET_UPC_DATA',
  PENDING_ACENET:'PENDING_ACENET',
  NEEDS_USER_CONFIRMATION:'NEEDS_USER_CONFIRMATION',
  USER_CONFIRMED_COMPLETE:'USER_CONFIRMED_COMPLETE'
 });
  const EXPORTABLE_UPC_VERIFICATION=new Set([UPC_VERIFICATION.VERIFIED_COMPLETE,UPC_VERIFICATION.VERIFIED_NO_ACENET_UPC_DATA,UPC_VERIFICATION.USER_CONFIRMED_COMPLETE]);
 const normSku=UPCIdentifierNormalization.normalizeSKU;
 const normUpc=UPCIdentifierNormalization.normalizeUPC;
 const pick=(fields,names)=>{for(const n of names||[]){const k=Object.keys(fields||{}).find(x=>x.trim().toLowerCase()===n.toLowerCase());if(k)return fields[k]??''}return''};
 const nonblank=v=>String(v??'').trim()!=='';
 const positiveWhole=v=>nonblank(v)&&Number.isFinite(Number(v))&&Number(v)>0&&Number.isInteger(Number(v));
 const nonnegativeNumber=v=>nonblank(v)&&Number.isFinite(Number(v))&&Number(v)>=0;
 function validateRow(row,sku,upc){
  const errors=[];
  if(!/^\d+$/.test(String(row[0]??'').trim()))errors.push('ACE SKU must be numeric');
  if(!nonblank(row[3]))errors.push('Description is missing');
  if(!nonblank(row[4]))errors.push('MFG # is missing');
  if(!positiveWhole(row[5]))errors.push('Order Multiple must be a positive whole number');
  if(!positiveWhole(row[6]))errors.push('Retail Units must be a positive whole number');
  if(!nonnegativeNumber(row[11]))errors.push('Weight must be numeric');
  if(!nonnegativeNumber(row[14]))errors.push('Retailer Each Cost must be numeric');
  if(!nonnegativeNumber(row[16]))errors.push('Ace Retail Price must be numeric');
  if(!/^\d+$/.test(String(row[21]??'')))errors.push('UPC/EAN must be numeric');
  if(!/^\d+$/.test(String(row[23]??'')))errors.push('Commodity Group is missing or invalid');
  if(!/^\d+$/.test(String(row[24]??'')))errors.push('Merchandise Class Number is missing or invalid');
  if(!/^\d+$/.test(String(row[25]??'')))errors.push('Product Group Number is missing or invalid');
  if(!/^\d+$/.test(String(row[30]??'')))errors.push('POSDEPT is missing or invalid');
  if(nonblank(row[31]))errors.push('VENDOR must be blank');
  if(nonblank(row[32]))errors.push('S/O (72) Y must be blank');
  if(errors.length)throw new Error(`SKU ${sku}, UPC ${upc}: ${errors.join('; ')}.`);
 }
 function cleanNumber(v){const n=String(v??'').replace(/[$,\s]/g,'').match(/-?\d+(?:\.\d+)?/);return n?n[0]:''}
 function codeNumber(v){const m=String(v??'').match(/\d+/);return m?m[0]:''}
 function normalizeOrderedUpcs(upcs){return[...new Set((Array.isArray(upcs)?upcs:[]).map(normUpc).filter(x=>/^\d{6,14}$/.test(x)))]}
 function snapshotFromBaseRow(baseRow,orderedUpcs,source,sku,{upcVerification=null}={}){
  const base=[...baseRow];while(base.length<HEADERS.length)base.push('');base.length=HEADERS.length;base[21]='';
  const ordered=normalizeOrderedUpcs(orderedUpcs);if(!ordered.length)throw new Error(`SKU ${sku}: no UPC value is available for the ACE MISC draft.`);
  for(const upc of ordered){const row=[...base];row[21]=upc;validateRow(row,sku,upc)}
  return{version:2,source,capturedAt:new Date().toISOString(),baseRow:base,orderedUpcs:ordered,upcVerification};
 }
 function firstNonblank(...values){for(const value of values)if(value!==null&&value!==undefined&&String(value).trim()!=='')return value;return''}
 function availableBaseRow(item){
  const fields=item?.fields||{},base=HEADERS.map((_,i)=>SOURCES[i]?pick(fields,SOURCES[i]):''),commodity=codeNumber(firstNonblank(base[23],item?.commodityGroup)),pos=POS[Number(commodity)]||'';
  base[0]=firstNonblank(item?.sku,base[0]);base[3]=firstNonblank(item?.description,base[3]);base[5]=firstNonblank(item?.orderMultiple,base[5]);base[6]=firstNonblank(item?.retailUnits,base[6]);base[16]=firstNonblank(base[16],item?.recordOrigin==='THIRD_PARTY_VENDOR'?item?.libraryPrice:null);base[23]=commodity||base[23];base[30]=pos;base[31]='';base[32]='';base[21]='';
  return base;
 }
 function availableItemUpcs(item){
  const fields=item?.fields||{},groups=[item?.allUpcs,item?.upcs,item?.aceNetUpcs,item?.catalog?.allUpcs,item?.aceNetCatalog?.allUpcs],values=[];
  for(const group of groups)if(Array.isArray(group))values.push(...group);
  values.push(item?.upc,item?.scannedUpc,item?.rawUPC,pick(fields,['UPC/EAN','UPC']));
  return normalizeOrderedUpcs(values);
 }
 // Field Session-owned observation columns are opt-in. Canonical MISC remains 33 columns.
 function optionalAvailableColumns({trailingColumn=null,trailingColumns=null}={}){
  if(trailingColumn!=null&&trailingColumns!=null)throw new Error('Specify one trailing-column mode only.');
  const columns=trailingColumns!=null?trailingColumns:(trailingColumn==null?[]:[trailingColumn]);
  if(!Array.isArray(columns)||columns.some(c=>!c||typeof c.header!=='string'||!c.header.trim()||typeof c.valueForItem!=='function'))throw new Error('Invalid trailing column for available-evidence export.');
  if(new Set(columns.map(c=>c.header)).size!==columns.length)throw new Error('Duplicate trailing export column.');
  return columns;
 }
 function rowsFromAvailableItems(items,options={}){
  const source=Array.isArray(items)?items:[],columns=optionalAvailableColumns(options),rows=[];
  source.forEach((item,index)=>{
   const base=availableBaseRow(item),upcs=availableItemUpcs(item);
   const append=upc=>{const row=[...base];if(upc)row[21]=upc;columns.forEach(c=>row.push(c.valueForItem(item,upc||'')));rows.push(row)};
   if(upcs.length)upcs.forEach(append);else append('');
   if(index<source.length-1)rows.push(Array(HEADERS.length+columns.length).fill(''));
  });
  return rows;
 }
 function buildWorkbookRows(rows,{trailingColumnHeader=null,trailingColumnHeaders=null}={}){
  const extras=trailingColumnHeaders!=null?trailingColumnHeaders:(trailingColumnHeader!=null?[trailingColumnHeader]:[]);
  const headers=extras.length?[...HEADERS,...extras]:HEADERS;
  const options={sheetName:'ACE New Items MISC.',textColumns:[0,4,21,22,23,24,25,26,29,30,31,32],headerFillColumns:extras.length?[...YELLOW,...extras.map((_,index)=>HEADERS.length+index)]:YELLOW,stripeRows:true,stripeLastColumn:headers.length-1,maxColumnWidth:60};
  if(extras.length)options.currencyColumns=extras.map((_,index)=>HEADERS.length+index);
  return XLSXExporter.build(headers,rows,options);
 }
 async function buildAvailableFormat(items,options={}){
  const columns=optionalAvailableColumns(options),rows=rowsFromAvailableItems(items,options);
  return buildWorkbookRows(rows,{trailingColumnHeaders:columns.map(c=>c.header)});
 }
 function libraryBaseRow(record,sku,kind){
  if(!record)throw new Error(`SKU ${sku}: ${kind} Library record is unavailable.`);
  const fields=record.fields||{},commodity=codeNumber(pick(fields,['Commodity Group'])),merchandiseClass=codeNumber(pick(fields,['Merchandise Class Number'])),productGroup=codeNumber(pick(fields,['Product Group Number'])),pos=POS[Number(commodity)];
  if(!pos)throw new Error(`SKU ${sku}: ${kind} Library Commodity Group ${commodity||'(blank)'} has no POSDEPT mapping.`);
  const base=HEADERS.map((_,i)=>SOURCES[i]?pick(fields,SOURCES[i]):'');base[0]=base[0]||sku;base[23]=commodity;base[24]=merchandiseClass;base[25]=productGroup;base[30]=pos;base[31]='';base[32]='';
  return base;
 }
 function snapshotFromMasterRecord(record,sku,orderedUpcs){
  return snapshotFromBaseRow(libraryBaseRow(record,sku,'Master'),orderedUpcs,'MASTER_LIBRARY_DRAFT',sku);
 }
 function snapshotFromLocalRecord(record,sku,orderedUpcs){
  return snapshotFromBaseRow(libraryBaseRow(record,sku,'Local'),orderedUpcs,'LOCAL_LIBRARY_DRAFT',sku);
 }
 function snapshotFromLibraryAndAceNet(record,sku,catalog,{libraryKind='MASTER',source='LIBRARY_PLUS_LIVE_ACENET',fallbackUpcs=[],upcVerification=UPC_VERIFICATION.VERIFIED_COMPLETE}={}){
  const kind=String(libraryKind||'MASTER').toUpperCase()==='LOCAL'?'Local':'Master',base=libraryBaseRow(record,sku,kind),c=catalog&&typeof catalog==='object'?catalog:{};
  const liveCommodity=codeNumber(c.commodityGroup),liveMerch=codeNumber(c.merchandiseClassNumber),liveProduct=codeNumber(c.productGroupNumber),livePos=POS[Number(liveCommodity)];
  if(!livePos)throw new Error(`SKU ${sku}: AceNet Commodity Group ${liveCommodity||'(blank)'} has no POSDEPT mapping.`);
  if(!nonblank(base[3])&&nonblank(c.description))base[3]=String(c.description).trim();
  base[4]=String(c.manufacturerNumber||'').trim();
  base[5]=codeNumber(c.orderMultiple);
  // Retail Units (column 6) deliberately remains library-owned.
  base[11]=UPCCatalogMappers.normalizeAceNetWeight(c.omWeight);
  base[14]=cleanNumber(c.retailerEachCost);
  base[16]=cleanNumber(c.aceRetailPrice);
  base[23]=liveCommodity;base[24]=liveMerch;base[25]=liveProduct;base[30]=livePos;
  const liveUpcs=normalizeOrderedUpcs(c.allUpcs),orderedUpcs=liveUpcs.length?liveUpcs:normalizeOrderedUpcs(fallbackUpcs);
  return snapshotFromBaseRow(base,orderedUpcs,source,sku,{upcVerification});
 }
 function snapshotFromAceNetCatalog(catalog,sku,retailUnits=1){
  const c=catalog&&typeof catalog==='object'?catalog:{},commodity=codeNumber(c.commodityGroup),pos=POS[Number(commodity)];
  if(!pos)throw new Error(`SKU ${sku}: AceNet Commodity Group ${commodity||'(blank)'} has no POSDEPT mapping.`);
  const base=Array(HEADERS.length).fill('');
  base[0]=String(sku||'').replace(/\D/g,'');base[3]=String(c.description||'').trim();base[4]=String(c.manufacturerNumber||'').trim();
  base[5]=codeNumber(c.orderMultiple);base[6]=positiveWhole(retailUnits)?String(retailUnits):'1';
  base[11]=UPCCatalogMappers.normalizeAceNetWeight(c.omWeight);base[14]=cleanNumber(c.retailerEachCost);base[16]=cleanNumber(c.aceRetailPrice);
  base[23]=commodity;base[24]=codeNumber(c.merchandiseClassNumber);base[25]=codeNumber(c.productGroupNumber);base[30]=pos;base[31]='';base[32]='';
  return snapshotFromBaseRow(base,c.allUpcs,'ACENET_REQUIRED_FIELDS',sku,{upcVerification:UPC_VERIFICATION.VERIFIED_COMPLETE});
 }
 function alaskaExportDate(date=new Date()){const parts=new Intl.DateTimeFormat('en-US',{timeZone:'America/Anchorage',year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(date),g=t=>parts.find(x=>x.type===t)?.value||'';return`${g('month')}.${g('day')}.${g('year')}`}
 function filename(date=new Date()){return`Ace New Misc Items ${alaskaExportDate(date)}.xlsx`}
 async function rowsForList(list){
  if(!list?.items?.length)throw new Error('There are no items in the ACE New Items MISC. list.');
  const rows=[],seenSku=new Set(),uniqueItems=[];
  for(const item of list.items){
   const sku=normSku(item.sku);
   if(!sku)throw new Error('ACE MISC. list contains an item without a SKU.');
   if(seenSku.has(sku))throw new Error(`Duplicate item cannot be exported: SKU ${item.sku||sku} appears more than once on the list.`);
   seenSku.add(sku);uniqueItems.push(item);
  }
  for(let itemIndex=0;itemIndex<uniqueItems.length;itemIndex++){
   const item=uniqueItems[itemIndex],sku=normSku(item.sku),verification=String(item?.aceMiscUpcVerification||item?.aceMiscSnapshot?.upcVerification||'');
   if(!EXPORTABLE_UPC_VERIFICATION.has(verification)){
    const reason=verification===UPC_VERIFICATION.NEEDS_USER_CONFIRMATION?'AceNet reported the SKU was not found; confirm all known UPCs first.':'complete UPC verification is still pending.';
    throw new Error(`SKU ${item.sku||sku} cannot be exported: ${reason}`);
   }
   const snapshot=item?.aceMiscSnapshot||null;
   if(!snapshot?.baseRow||!Array.isArray(snapshot?.orderedUpcs))throw new Error(`SKU ${item.sku||sku} is missing its canonical ACE MISC draft. Reverify or repair this item before export.`);
   const base=[...snapshot.baseRow],ordered=normalizeOrderedUpcs(snapshot.orderedUpcs);
   if(!ordered.length)throw new Error(`SKU ${item.sku||sku} has no UPC available for ACE MISC. export.`);
   for(const upc of ordered){const row=[...base];row[21]=upc;validateRow(row,item.sku||sku,upc);rows.push(row)}
   if(itemIndex<uniqueItems.length-1)rows.push(Array(HEADERS.length).fill(''));
  }
  return rows;
 }
 async function build(list){
  const rows=await rowsForList(list);
  return buildWorkbookRows(rows);
 }
 async function exportList(list){
  const bytes=await build(list),name=filename();
  return{name,rowCount:(await rowsForList(list)).length,bytes,mime:XLSXExporter.MIME};
 }
 async function enrichSkuUpcs(sku,upcs,source='ACENET_MISC_VERIFIED'){
  const normalizedSku=normSku(sku),normalized=normalizeOrderedUpcs(upcs);
  if(!normalizedSku)throw new Error('ACE MISC. item is missing a SKU.');
  const before=await UPCIdentifierRelationshipService.getSkuUpcs(normalizedSku),existing=new Set(before.map(x=>x.upcKey)),added=normalized.filter(x=>!existing.has(x));
  if(normalized.length)await UPCIdentifierRelationshipService.recordVerifiedSkuUpcs(normalizedSku,normalized,source,{completeness:'COMPLETE',exactSkuVerified:true});
  return{sku:normalizedSku,selectorCount:normalized.length,addedCount:added.length,addedUpcs:added}
 }
 return{HEADERS,YELLOW,POS,UPC_VERIFICATION,filename,validateRow,snapshotFromMasterRecord,snapshotFromLocalRecord,snapshotFromLibraryAndAceNet,snapshotFromAceNetCatalog,rowsFromAvailableItems,buildAvailableFormat,rowsForList,build,exportList,enrichSkuUpcs};
})();
