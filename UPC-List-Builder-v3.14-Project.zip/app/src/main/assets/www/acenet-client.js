/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/acenet-client.js
 * Owner: Web AceNet Transport Boundary
 * Role: Request broker
 * Responsibility: Owns typed JavaScript AceNet request IDs, pending correlation, safety timers, bridge dispatch, supersession, and callback completion.
 * Does not own: Native authentication/session repair; page extraction; catalog persistence; UI presentation.
 * Side effects: Uses the injected Android bridge and bounded request timers; holds in-memory pending request state.
 * Related code: AceNet workflow policy belongs to lookup/misc services; native transport/extraction belongs to focused Kotlin owners.
 */
const UPCAceNetClient=(()=>{
 let configured=false,deps=null;
 const requests=new Map();
 const BROKER_TIMEOUT_FALLBACK_MS=52000;
 const productionBrokerTimeout=native=>{
  const value=Number(native?.getAceNetProductionBrokerTimeoutMs?.());
  return Number.isFinite(value)&&value>=1000?value:BROKER_TIMEOUT_FALLBACK_MS;
 };

 function configure(options={}){
  const required=['normalizeSKU','normalizeUPC','parsePrice'];
  for(const key of required)if(typeof options[key]!=='function')throw new Error(`AceNet Client requires ${key}.`);
  deps={
   normalizeSKU:options.normalizeSKU,
   normalizeUPC:options.normalizeUPC,
   parsePrice:options.parsePrice,
   diag:typeof options.diag==='function'?options.diag:()=>{},
   bridgeProvider:typeof options.bridgeProvider==='function'?options.bridgeProvider:()=>globalThis.window?.AndroidNative||null
  };
  configured=true;
 }
 function need(){if(!configured||!deps)throw new Error('AceNet Client is not configured.');return deps}
 const requestId=(prefix)=>`${prefix}-${Date.now()}-${Math.random().toString(36).slice(2,9)}`;
 const parseRaw=raw=>typeof raw==='string'?JSON.parse(raw):raw;
 function cleanup(id){
  const req=requests.get(id);if(!req)return null;
  if(req.timer)clearTimeout(req.timer);
  requests.delete(id);
  return req;
 }
 function finish(id,result){
  const req=cleanup(id);if(!req)return false;
  req.resolve(result);return true;
 }
 function start({kind,prefix,sku,bridge,timeoutMs=0,metadata={},timeoutResult,startFailedResult,onStarted,onTimeout,onStartFailed}){
  const d=need(),expectedSku=d.normalizeSKU(sku),native=d.bridgeProvider();
  return new Promise(resolve=>{
   if(!expectedSku||typeof native?.[bridge]!=='function'){
    resolve(typeof startFailedResult==='function'?startFailedResult({expectedSku,requestId:null,status:'UNAVAILABLE'}):{status:'UNAVAILABLE',sku:expectedSku});
    return;
   }
   const id=requestId(prefix),startedAt=Date.now(),req={kind,expectedSku,startedAt,resolve,timer:null,bridge,...metadata};
   if(timeoutMs>0){
    req.timer=setTimeout(()=>{
     const pending=cleanup(id);if(!pending)return;
     onTimeout?.({requestId:id,req:pending,elapsedMs:Date.now()-startedAt});
     resolve(typeof timeoutResult==='function'?timeoutResult({expectedSku,requestId:id,req:pending}):{status:'TIMEOUT',sku:expectedSku,requestId:id});
    },timeoutMs);
   }
   requests.set(id,req);
   onStarted?.({requestId:id,req});
   try{native[bridge](id,expectedSku)}
   catch(error){
    cleanup(id);
    onStartFailed?.({requestId:id,req,error});
    resolve(typeof startFailedResult==='function'?startFailedResult({expectedSku,requestId:id,status:'START_FAILED',error,req}):{status:'START_FAILED',sku:expectedSku,requestId:id});
   }
  });
 }
 function supersedePriceRequests(){
  const d=need();
  for(const [id,req] of [...requests]){
   if(req.kind!=='PRICE')continue;
   cleanup(id);
   req.resolve({source:'ACENET',status:'SUPERSEDED',price:null,sku:req.expectedSku,upcs:[],upcEnrichment:req.upcEnrichment,requestId:id});
   d.diag('acenet_live_check_superseded',{requestId:id,sku:req.expectedSku});
  }
 }
 function requestPrice(sku,{upcEnrichment=false}={}){
  const d=need(),expectedSku=d.normalizeSKU(sku),bridge=upcEnrichment?'lookupAceNetPriceWithUpcs':'lookupAceNetPrice',native=d.bridgeProvider();
  if(!expectedSku||typeof native?.[bridge]!=='function')return Promise.resolve({source:'ACENET',status:'UNAVAILABLE',price:null,sku:expectedSku,upcs:[],upcEnrichment:Boolean(upcEnrichment)});
  supersedePriceRequests();
  return start({
   kind:'PRICE',prefix:'price',sku:expectedSku,bridge,timeoutMs:productionBrokerTimeout(native),metadata:{upcEnrichment:Boolean(upcEnrichment)},
   timeoutResult:({expectedSku,requestId,req})=>({source:'ACENET',status:'TIMEOUT',price:null,sku:expectedSku,upcs:[],upcEnrichment:req.upcEnrichment,requestId}),
   startFailedResult:({expectedSku,requestId,status})=>({source:'ACENET',status,price:null,sku:expectedSku,upcs:[],upcEnrichment:Boolean(upcEnrichment),...(requestId?{requestId}:{})}),
   onStarted:({requestId,req})=>d.diag('acenet_live_check_started',{requestId,sku:req.expectedSku,upcEnrichment:req.upcEnrichment,bridge:req.bridge}),
   onTimeout:({requestId,req,elapsedMs})=>d.diag('acenet_live_check_js_timeout',{requestId,sku:req.expectedSku,upcEnrichment:req.upcEnrichment,elapsedMs}),
   onStartFailed:({requestId,req,error})=>d.diag('acenet_live_check_start_failed',{requestId,sku:req.expectedSku,upcEnrichment:req.upcEnrichment,message:error?.message||String(error)})
  });
 }
 function requestUpcs(sku){
  const d=need(),native=d.bridgeProvider();
  return start({
   kind:'UPCS',prefix:'ACENET_UPCS',sku,bridge:'lookupAceNetUpcs',timeoutMs:productionBrokerTimeout(native),
   timeoutResult:({expectedSku})=>({status:'TIMEOUT',sku:expectedSku,upcs:[]}),
   startFailedResult:({expectedSku,status})=>({status:status==='UNAVAILABLE'?'UNAVAILABLE':'BRIDGE_ERROR',sku:expectedSku,upcs:[]})
  });
 }
 function requestCatalog(sku,{misc=false,repair=false}={}){
  const d=need(),bridge=repair?'lookupAceNetRepairCatalog':(misc?'lookupAceNetMiscCatalog':'lookupAceNetCatalog'),prefix=repair?'repair-catalog':(misc?'misc-catalog':'catalog'),native=d.bridgeProvider();
  return start({
   kind:'CATALOG',prefix,sku,bridge,timeoutMs:productionBrokerTimeout(native),metadata:{misc:Boolean(misc),repair:Boolean(repair)},
   timeoutResult:({expectedSku,requestId,req})=>({source:'ACENET',status:'TIMEOUT',sku:expectedSku,catalog:null,misc:req.misc,repair:req.repair,requestId}),
   startFailedResult:({expectedSku,requestId,status,req})=>({source:'ACENET',status,sku:expectedSku,catalog:null,misc:req?.misc??Boolean(misc),repair:req?.repair??Boolean(repair),...(requestId?{requestId}:{})}),
   onStarted:({requestId,req})=>d.diag('acenet_catalog_enrichment_started',{requestId,sku:req.expectedSku,misc:req.misc,repair:req.repair,bridge:req.bridge}),
   onTimeout:({requestId,req,elapsedMs})=>d.diag('acenet_catalog_enrichment_js_timeout',{requestId,sku:req.expectedSku,misc:req.misc,repair:req.repair,elapsedMs}),
   onStartFailed:({requestId,req,error})=>d.diag('acenet_catalog_enrichment_start_failed',{requestId,sku:req.expectedSku,misc:req.misc,repair:req.repair,message:error?.message||String(error)})
  });
 }
 function acceptPriceResult(raw){
  const d=need();let req=null,id='';
  try{
   const p=parseRaw(raw);id=String(p?.requestId||'');req=requests.get(id);
   if(!req||req.kind!=='PRICE'){d.diag('acenet_live_check_stale_result_ignored',{requestId:id,sku:p?.sku||null});return false}
   const returnedSku=d.normalizeSKU(p?.sku),skuMatches=returnedSku===req.expectedSku,price=d.parsePrice(p?.price),upcs=[...new Set((p?.catalog?.allUpcs||[]).map(d.normalizeUPC).filter(x=>/^\d{6,14}$/.test(x)))],upcsReady=!req.upcEnrichment||upcs.length>0,verified=p?.found===true&&p?.status==='FOUND'&&skuMatches&&price!==null&&upcsReady;
   d.diag('acenet_live_check_result',{requestId:id,expectedSku:req.expectedSku,returnedSku,status:p?.status||null,found:p?.found===true,skuMatches,validPrice:price!==null,upcEnrichment:req.upcEnrichment,upcCount:upcs.length,upcsReady,elapsedMs:Date.now()-req.startedAt});
   return finish(id,{source:'ACENET',status:verified?'VERIFIED':(p?.status||'INVALID_RESULT'),price:verified?price:null,sku:returnedSku,upcs,upcEnrichment:req.upcEnrichment,requestId:id});
  }catch(error){
   d.diag('acenet_live_check_result_parse_failed',{requestId:id,message:error?.message||String(error)});
   if(req)return finish(id,{source:'ACENET',status:'PARSE_ERROR',price:null,sku:req.expectedSku,upcs:[],upcEnrichment:req.upcEnrichment,requestId:id});
   return false;
  }
 }
 function acceptUpcsResult(raw){
  const d=need();let req=null,id='';
  try{
   const p=parseRaw(raw);id=String(p?.requestId||'');req=requests.get(id);
   if(!req||req.kind!=='UPCS')return false;
   const returnedSku=d.normalizeSKU(p?.sku),skuMatches=returnedSku===req.expectedSku,upcs=[...new Set((p?.catalog?.allUpcs||[]).map(d.normalizeUPC).filter(x=>/^\d{6,14}$/.test(x)))],ok=p?.found===true&&p?.status==='FOUND'&&skuMatches&&upcs.length>0;
   return finish(id,{status:ok?'VERIFIED':(p?.status||'INVALID_RESULT'),sku:returnedSku,upcs});
  }catch(error){
   if(req)return finish(id,{status:'PARSE_ERROR',sku:req.expectedSku,upcs:[]});
   return false;
  }
 }
 function acceptCatalogResult(raw){
  const d=need();let req=null,id='';
  try{
   const p=parseRaw(raw);id=String(p?.requestId||'');req=requests.get(id);
   if(!req||req.kind!=='CATALOG'){d.diag('acenet_catalog_stale_result_ignored',{requestId:id});return false}
    const sku=d.normalizeSKU(p?.sku),catalog=p?.catalog&&typeof p.catalog==='object'?p.catalog:null,full=p?.found===true&&p?.status==='FOUND'&&sku===req.expectedSku&&catalog,partial=req.repair===true&&p?.found===true&&p?.status==='FOUND_PARTIAL'&&sku===req.expectedSku&&catalog,noUpc=p?.found===true&&p?.status==='FOUND_NO_UPC_DATA'&&sku===req.expectedSku&&catalog,missingFields=Array.isArray(p?.missingFields)?p.missingFields.map(x=>String(x||'').trim()).filter(Boolean):[];
    d.diag('acenet_catalog_enrichment_result',{requestId:id,expectedSku:req.expectedSku,returnedSku:sku,status:p?.status||null,verified:Boolean(full||partial||noUpc),partial:Boolean(partial),noUpcData:Boolean(noUpc),missingFields,misc:req.misc===true,repair:req.repair===true,elapsedMs:Date.now()-req.startedAt});
    return finish(id,{source:'ACENET',status:full?'VERIFIED':(partial?'VERIFIED_PARTIAL':(noUpc?'VERIFIED_NO_UPC_DATA':(p?.status||'INVALID_RESULT'))),sku,catalog:(full||partial||noUpc)?catalog:null,missingFields:(full||partial||noUpc)?missingFields:[],misc:req.misc===true,repair:req.repair===true,requestId:id});
  }catch(error){
   if(req)return finish(id,{source:'ACENET',status:'PARSE_ERROR',sku:req.expectedSku,catalog:null,requestId:id,misc:req.misc===true,repair:req.repair===true});
   d.diag('acenet_catalog_enrichment_parse_failed',{requestId:id,message:error?.message||String(error)});return false;
  }
 }
 function cancelAll(reason='CANCELLED'){
  for(const [id,req] of [...requests]){
   cleanup(id);
   if(req.kind==='PRICE')req.resolve({source:'ACENET',status:reason,price:null,sku:req.expectedSku,upcs:[],upcEnrichment:req.upcEnrichment,requestId:id});
   else if(req.kind==='CATALOG')req.resolve({source:'ACENET',status:reason,sku:req.expectedSku,catalog:null,misc:req.misc,repair:req.repair,requestId:id});
   else req.resolve({status:reason,sku:req.expectedSku,upcs:[]});
  }
 }
 return Object.freeze({configure,requestPrice,requestUpcs,requestCatalog,acceptPriceResult,acceptUpcsResult,acceptCatalogResult,cancelAll});
})();
window.UPCAceNetClient=UPCAceNetClient;
