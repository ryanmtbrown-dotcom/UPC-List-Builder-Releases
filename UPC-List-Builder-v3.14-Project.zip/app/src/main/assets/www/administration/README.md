# Administration Presentation Directory Ownership

OWNS: administration/data-management presentation styles only.

DOES NOT OWN: Database Viewer composition, catalog/identity persistence, repair policy, or application state.

Behavior belongs to the focused application/catalog/identity owners named in `SOURCE_OWNERSHIP_MAP.md`.
