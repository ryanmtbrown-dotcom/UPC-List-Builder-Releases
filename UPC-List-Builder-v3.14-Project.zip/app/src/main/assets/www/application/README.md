# Application Directory Ownership

OWNS: composition-facing application workflows: startup, navigation, settings, durable ordinary-export field and Force ACE MISC Format preference presentation/persistence coordination, dialogs, backup orchestration, release/update presentation, and shell integration.

MAY CONTAIN: controllers/services that coordinate multiple domain capabilities.

ACENET RUNTIME STATE: `acenet-startup-service.js` owns the web projection of authoritative native AceNet startup/health callbacks into shared runtime state. It does not classify native health or own Settings feature policy.

DOES NOT OWN: catalog rules, DSD/MISC business rules, raw persistence primitives, native Android implementation, or AceNet extraction.

SIDE EFFECTS: DOM/navigation/settings interactions only through each focused owner; cross-domain dependencies are injected by the application shell.

OPTIONAL DSD INTEGRATION: Application Shell wires `UPCDsdChatGPTImport` into the DSD workspace through injected domain, Work Session, and native credential services. Shell does not interpret invoice fields or persist external credentials.
