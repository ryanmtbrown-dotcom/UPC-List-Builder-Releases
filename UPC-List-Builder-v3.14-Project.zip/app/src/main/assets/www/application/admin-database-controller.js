/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/application/admin-database-controller.js
 * Owner: Application Administration
 * Role: Controller
 * Responsibility: Owns Database Viewer/admin UI orchestration, repair command presentation, and coordination of catalog/identity maintenance capabilities.
 * Does not own: Raw database primitives; catalog/identity business rules; repository implementation.
 * Side effects: Mutates DOM and invokes injected inspection/maintenance services; no direct raw IndexedDB ownership.
 * Related code: Data composition belongs to catalog/database-inspection-service.js; repair rules belong to focused catalog/identity services.
 */
const UPCAdminDatabaseController=(()=>{
 function create({
  elementById,escapeHtml,normalizeSku,normalizeUpc,relationshipService,localRepository,
  databaseInspectionService,miscMaintenanceService,miscSnapshotService,miscWorkspaceController,catalogMaintenanceService,
  identityWorkController,messageUser,promptUser,confirmUser,alertUser,diagnostic
 }={}){
  if(typeof elementById!=='function'||typeof normalizeSku!=='function'||typeof normalizeUpc!=='function'||!relationshipService||!localRepository)throw new Error('Admin Database Controller persistence dependencies are incomplete.');
  if(!databaseInspectionService||!miscMaintenanceService||!miscSnapshotService||!miscWorkspaceController||!catalogMaintenanceService||!identityWorkController)throw new Error('Admin Database Controller service dependencies are incomplete.');
  const $=elementById,esc=escapeHtml,normalizeSKU=normalizeSku,normalizeUPC=normalizeUpc;
  const UPCIdentifierRelationshipService=relationshipService,UPCLocalRepository=localRepository,UPCDatabaseInspectionService=databaseInspectionService,UPCMiscMaintenanceService=miscMaintenanceService;
  const appMessage=messageUser,appPrompt=promptUser,appConfirm=confirmUser,diag=diagnostic;
  
  const DATABASE_VIEWER_DEFS=Object.freeze([
   {key:'masterLibrary',label:'Master Library'},
   {key:'localLibrary',label:'Local Library'},
   {key:'skuUpcs',label:'SKU ↔ UPC Associations'},
   {key:'skuIdentity',label:'SKU Identity'},
   {key:'upcIdentityResolution',label:'UPC Identity Resolution'},
   {key:'libraryUpdateQueue',label:'Add to Local Library'},
   {key:'identityResearchQueue',label:'Items Needing Research'},
   {key:'deferredAceNetRefreshQueue',label:'Pending Live Refresh'},
   {key:'skuConflicts',label:'SKU Conflicts'}
  ]);
  let databaseViewerSnapshot=null,databaseViewerKey='skuUpcs',databaseViewerPage=0;
  const DATABASE_VIEWER_PAGE_SIZE=200;
  function databaseViewerPrimary(row,key){
   const f=row?.fields||{};
   if(key==='skuUpcs')return `SKU ${row.skuKey||'—'} · UPC ${row.upcKey||'—'}`;
   if(key==='skuIdentity')return `SKU ${row.skuKey||'—'} · ${row.catalogStatus||'UNKNOWN'}`;
   if(key==='upcIdentityResolution'||key==='skuConflicts')return `UPC ${row.upcKey||'—'} · ${row.status||'UNKNOWN'}`;
   if(key==='libraryUpdateQueue'||key==='identityResearchQueue'||key==='deferredAceNetRefreshQueue')return `SKU ${row.sku||row.skuKey||'—'} · ${row.status||'PENDING'}`;
   const sku=row?.skuKey||f['ACE SKU']||f.SKU||'—',upc=row?.upcKey||row?.originalUPC||f['UPC/EAN']||f.UPC||'—',desc=f.Description||f['Article Description']||'';
   return `SKU ${sku} · UPC ${upc}${desc?` · ${desc}`:''}`;
  }
  function databaseViewerJson(row){try{return JSON.stringify(row,null,2)}catch{return String(row)}}
  function databaseViewerLabel(key){return String(key||'').replace(/([a-z0-9])([A-Z])/g,'$1 $2').replace(/[_-]+/g,' ').replace(/\b\w/g,x=>x.toUpperCase())}
  function databaseViewerValue(value){if(value==null||value==='')return '—';if(Array.isArray(value))return value.length?value.join(', '):'—';if(typeof value==='object')return Object.entries(value).map(([k,v])=>`${databaseViewerLabel(k)}: ${databaseViewerValue(v)}`).join('\n');return String(value)}
  function databaseViewerEntries(row){const out=[];for(const [k,v] of Object.entries(row||{})){if(k==='fields'&&v&&typeof v==='object'){for(const [fk,fv] of Object.entries(v))out.push([fk,fv]);continue}if(k==='suppressedByMaster'&&v==null)continue;out.push([k,v])}return out}
  function databaseViewerFieldClass(key,value){const text=String(value??'');return text.length>34||Array.isArray(value)||typeof value==='object'?'databaseViewerField isWide':'databaseViewerField'}
  const LOCAL_CORRECTION_FIELDS=[
   {key:'description',label:'Description',aliases:['Description','Article Description']},
   {key:'manufacturerNumber',label:'MFG #',aliases:['MFG #','Manufacturer Number','MFG Number']},
   {key:'orderMultiple',label:'Order Multiple',aliases:['Order Multiple']},
   {key:'retailUnits',label:'Retail Units',aliases:['Retail Units']},
   {key:'omWeight',label:'Weight',aliases:['Weight','OM Weight']},
   {key:'retailerEachCost',label:'Retailer Each Cost',aliases:['Retailer Each Cost','Cost']},
   {key:'aceRetailPrice',label:'Ace Retail Price',aliases:['Ace Retail Price','Retailer Each Price','Price']},
   {key:'commodityGroup',label:'Commodity Group',aliases:['Commodity Group']},
   {key:'merchandiseClassNumber',label:'Merchandise Class Number',aliases:['Merchandise Class Number','Merchant Class','Merchandise Class']},
   {key:'productGroupNumber',label:'Product Group Number',aliases:['Product Group Number']}
  ];
  function localCorrectionValue(row,spec){const fields=row?.fields||{},key=Object.keys(fields).find(h=>spec.aliases.some(a=>h.trim().toLowerCase()===a.toLowerCase()));return key?fields[key]:''}
  async function persistCorrectedSnapshot(sku,row){
   const snapshot=await miscSnapshotService.correctedSnapshotForLocalRow(sku,row),stored=await UPCMiscMaintenanceService.replaceSnapshotsForSku(sku,snapshot),currentUpdated=await miscWorkspaceController.syncCurrentSnapshot(sku,snapshot);return{snapshot,...stored,currentUpdated};
  }
  async function editLocalLibraryFromDatabase(sku){
   const row=await UPCLocalRepository.getRecordBySku(sku);if(!row){await appMessage('This Local Library record no longer exists.','Correct Local Library');return}
   const menu=LOCAL_CORRECTION_FIELDS.map((x,i)=>`${i+1}. ${x.label}`).join('\n'),choice=await appPrompt(`Choose the field to correct by number:\n\n${menu}`,'','Correct Local Library');if(choice==null)return;
   const spec=LOCAL_CORRECTION_FIELDS[Number(choice)-1];if(!spec){await appMessage('Enter one of the listed field numbers.','Correct Local Library');return}
   const next=await appPrompt(`Correct ${spec.label} for SKU ${sku}.`,String(localCorrectionValue(row,spec)??''),`Correct ${spec.label}`);if(next==null)return;
   const result=await UPCLocalRepository.correctFields(sku,{[spec.key]:next},{source:'USER_CORRECTION',preserveUser:true});if(result.updated)await persistCorrectedSnapshot(sku,result.row);
   diag('database_viewer_local_library_corrected',{sku:normalizeSKU(sku),field:spec.key,updated:Boolean(result.updated)});await refreshManagedDatabaseViewer();
  }
  async function refreshLocalLibraryFromAceNet(sku,{quiet=false}={}){
   const out=await catalogMaintenanceService.refreshLocalLibraryFromAceNet(sku);
   if(!quiet){
    if(out.status!=='COMPLETED')await appMessage(`AceNet could not verify SKU ${sku} right now. No local data was changed.`,'Refresh Local Library');
    else{await refreshManagedDatabaseViewer();await appMessage(out.partial?`SKU ${out.sku} was verified with partial AceNet evidence. Available verified fields were refreshed; missing fields were preserved.`:`SKU ${out.sku} refreshed from verified AceNet data.`,'Local Data Refreshed')}
   }
   return out;
  }
  let localDataRepairRunning=false;
  async function runAceNetLocalDataRepair(){
   if(localDataRepairRunning)return;const button=$('repairAceNetLocalData');localDataRepairRunning=true;if(button){button.disabled=true;button.textContent='Repairing…'}
   try{
    const summary=await catalogMaintenanceService.repairAll();
    if(!summary.candidateCount){await appMessage('No known invalid AceNet-derived Local Library or ACE MISC values were found.','Local Data Repair');return}
    await refreshManagedDatabaseViewer();const detail=summary.partialDetails.length?`\n\nVerified partial repairs:\n${summary.partialDetails.join('\n')}`:'';
    await appMessage(`Local data repair finished. ${summary.completed} fully repaired; ${summary.partial} verified and partially repaired; ${summary.failed} failed.${detail}`,'Local Data Repair');
   }finally{localDataRepairRunning=false;if(button){button.disabled=false;button.textContent='Repair AceNet-derived Local Data'}}
  }
  function databaseViewerActions(row,key){const sku=String(row?.sku||row?.skuKey||'');if(key==='localLibrary')return `<div class="databaseViewerActions"><button type="button" class="secondary" data-db-edit-local="${esc(sku)}">Correct Fields</button><button type="button" class="secondary" data-db-refresh-local="${esc(sku)}">Refresh from AceNet</button></div>`;if(key==='identityResearchQueue')return `<div class="databaseViewerActions"><button type="button" class="secondary" data-db-edit-research="${esc(sku)}">Edit SKU</button><button type="button" class="dbDelete" data-db-delete-research="${esc(sku)}">Remove</button></div>`;if(key==='libraryUpdateQueue')return `<div class="databaseViewerActions"><button type="button" class="dbDelete" data-db-delete-library="${esc(sku)}">Remove</button></div>`;return '<div class="databaseViewerReadonly">Read-only record</div>'}
  function renderDatabaseViewer(){const tabs=$('databaseViewerTabs'),records=$('databaseViewerRecords'),count=$('databaseViewerCount'),filter=$('databaseViewerFilter');if(!tabs||!records||!count||!databaseViewerSnapshot)return;tabs.innerHTML=DATABASE_VIEWER_DEFS.map(d=>`<button type="button" data-db-view="${d.key}" class="${d.key===databaseViewerKey?'active':''}">${esc(d.label)} · ${(databaseViewerSnapshot[d.key]||[]).length}</button>`).join('');tabs.querySelectorAll('[data-db-view]').forEach(b=>b.onclick=()=>{databaseViewerKey=b.dataset.dbView;databaseViewerPage=0;if(filter)filter.value='';renderDatabaseViewer()});const allRows=databaseViewerSnapshot[databaseViewerKey]||[],q=String(filter?.value||'').trim().toLowerCase(),filtered=q?allRows.filter(row=>databaseViewerJson(row).toLowerCase().includes(q)):allRows;const pages=Math.max(1,Math.ceil(filtered.length/DATABASE_VIEWER_PAGE_SIZE));databaseViewerPage=Math.min(databaseViewerPage,pages-1);const start=databaseViewerPage*DATABASE_VIEWER_PAGE_SIZE,shown=filtered.slice(start,start+DATABASE_VIEWER_PAGE_SIZE);count.textContent=`${filtered.length.toLocaleString()} record${filtered.length===1?'':'s'}${q?` of ${allRows.length.toLocaleString()}`:''} · page ${databaseViewerPage+1} of ${pages}`;records.innerHTML=shown.length?shown.map(row=>`<article class="databaseViewerRecord"><div class="databaseViewerCardHead"><strong>${esc(databaseViewerPrimary(row,databaseViewerKey))}</strong></div><div class="databaseViewerCardBody"><div class="databaseViewerFields">${databaseViewerEntries(row).map(([k,v])=>`<div class="${databaseViewerFieldClass(k,v)}"><span>${esc(databaseViewerLabel(k))}</span><strong>${esc(databaseViewerValue(v))}</strong></div>`).join('')}</div>${databaseViewerActions(row,databaseViewerKey)}</div></article>`).join(''):'<div class="databaseViewerEmpty">No records in this dataset.</div>';const prev=$('databaseViewerPrev'),next=$('databaseViewerNext');if(prev){prev.disabled=databaseViewerPage<=0;prev.onclick=()=>{if(databaseViewerPage>0){databaseViewerPage--;renderDatabaseViewer();records.scrollTop=0}}}if(next){next.disabled=databaseViewerPage>=pages-1;next.onclick=()=>{if(databaseViewerPage<pages-1){databaseViewerPage++;renderDatabaseViewer();records.scrollTop=0}}}}
  async function refreshManagedDatabaseViewer(){await refreshDatabaseViewerSummary();renderDatabaseViewer();await identityWorkController.refreshWorkQueues()}
  async function editResearchFromDatabase(oldSku){const next=await appPrompt('Correct the SKU for this research record.',oldSku,'Edit Research SKU');if(next==null)return;const normalized=normalizeSKU(next);if(!normalized){await appMessage('Enter a valid SKU.','Edit Research SKU');return}await UPCIdentifierRelationshipService.updateResearchSku(oldSku,next);diag('database_viewer_research_sku_corrected',{oldSku:normalizeSKU(oldSku),newSku:normalized});await refreshManagedDatabaseViewer()}
  async function removeResearchFromDatabase(sku){if(!await appConfirm(`Remove SKU ${sku} from Items Needing Research?\n\nUse this when the scanned item does not require further investigation.`,'Remove Research Item',{okLabel:'Remove'}))return;await UPCIdentifierRelationshipService.discardResearch(sku);diag('database_viewer_research_removed',{sku:normalizeSKU(sku)});await refreshManagedDatabaseViewer()}
  async function removeLibraryQueueFromDatabase(sku){if(!await appConfirm(`Remove SKU ${sku} from Add to Local Library?\n\nThis removes the pending work item; it does not delete an imported Master Library record.`,'Remove Pending Library Item',{okLabel:'Remove'}))return;await UPCLocalRepository.removeUpdateQueueSku(sku);diag('database_viewer_library_queue_removed',{sku:normalizeSKU(sku)});await refreshManagedDatabaseViewer()}
  async function refreshDatabaseViewerSummary(){const summary=$('databaseViewerSummary');try{const snap=await UPCDatabaseInspectionService.snapshot();databaseViewerSnapshot=snap;const origins=snap.localOriginCounts||{aceDerived:0,thirdPartyVendor:0};if(summary)summary.textContent=`Master ${(snap.masterLibrary||[]).length.toLocaleString()} · Local ${(snap.localLibrary||[]).length.toLocaleString()} (Ace ${Number(origins.aceDerived||0).toLocaleString()} / Third-Party ${Number(origins.thirdPartyVendor||0).toLocaleString()}) · Associations ${(snap.skuUpcs||[]).length.toLocaleString()} · Research ${(snap.identityResearchQueue||[]).length.toLocaleString()} · Pending Refresh ${(snap.deferredAceNetRefreshQueue||[]).length.toLocaleString()} · Conflicts ${(snap.skuConflicts||[]).length.toLocaleString()}`;diag('database_viewer_snapshot_loaded',{...Object.fromEntries(DATABASE_VIEWER_DEFS.map(d=>[d.key,(snap[d.key]||[]).length])),localAceDerived:Number(origins.aceDerived||0),localThirdPartyVendor:Number(origins.thirdPartyVendor||0)});return snap}catch(e){if(summary)summary.textContent='Database counts unavailable';diag('database_viewer_snapshot_failed',{message:e?.message||String(e)});throw e}}
  async function openDatabaseViewer(){try{await refreshDatabaseViewerSummary();databaseViewerKey='skuUpcs';databaseViewerPage=0;const filter=$('databaseViewerFilter');if(filter)filter.value='';renderDatabaseViewer();$('databaseViewerOverlay')?.classList.remove('hidden');diag('database_viewer_opened',{defaultDataset:databaseViewerKey})}catch(e){alert(`Database Viewer could not be opened: ${e?.message||e}`)}}
  function closeDatabaseViewer(){$('databaseViewerOverlay')?.classList.add('hidden');diag('database_viewer_closed',{dataset:databaseViewerKey})}
  
  function bind({on}={}){
   if(typeof on!=='function')throw new Error('Admin Database Controller requires the shared event binder.');
   on('openDatabaseViewer','click',openDatabaseViewer);on('closeDatabaseViewer','click',closeDatabaseViewer);
   on('databaseViewerFilter','input',()=>{databaseViewerPage=0;renderDatabaseViewer()});
   on('databaseViewerRecords','click',async e=>{const editLocal=e.target.closest?.('[data-db-edit-local]'),refreshLocal=e.target.closest?.('[data-db-refresh-local]'),edit=e.target.closest?.('[data-db-edit-research]'),delResearch=e.target.closest?.('[data-db-delete-research]'),delLibrary=e.target.closest?.('[data-db-delete-library]');try{if(editLocal)await editLocalLibraryFromDatabase(editLocal.dataset.dbEditLocal);else if(refreshLocal)await refreshLocalLibraryFromAceNet(refreshLocal.dataset.dbRefreshLocal);else if(edit)await editResearchFromDatabase(edit.dataset.dbEditResearch);else if(delResearch)await removeResearchFromDatabase(delResearch.dataset.dbDeleteResearch);else if(delLibrary)await removeLibraryQueueFromDatabase(delLibrary.dataset.dbDeleteLibrary)}catch(err){diag('database_viewer_manage_failed',{message:err?.message||String(err)});await appMessage(err?.message||String(err),'Database Viewer')}});
   on('repairAceNetLocalData','click',runAceNetLocalDataRepair);
  }
  return Object.freeze({bind,refreshSummary:refreshDatabaseViewerSummary,openDatabaseViewer,closeDatabaseViewer,runAceNetLocalDataRepair});
 }
 return Object.freeze({create});
})();
window.UPCAdminDatabaseController=UPCAdminDatabaseController;
