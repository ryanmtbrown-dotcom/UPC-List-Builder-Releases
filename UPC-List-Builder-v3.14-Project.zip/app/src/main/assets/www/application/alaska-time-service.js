/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/application/alaska-time-service.js
 * Owner: Application Time Semantics
 * Role: Pure time service
 * Responsibility: Owns Alaska-local date/session naming helpers required by application workflows.
 * Does not own: Scheduling policy, persistence, diagnostics timestamps outside its exposed helpers, or UI.
 * Side effects: Reads system time/time-zone formatting only.
 * Related code: Callers consume formatted time values; domain behavior remains with the caller.
 */
const UPCAlaskaTimeService=(()=>{
 function create({timeZone='America/Anchorage'}={}){
  function dateParts(date=new Date()){const parts=new Intl.DateTimeFormat('en-US',{timeZone,year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(date),get=type=>parts.find(p=>p.type===type)?.value||'';return{year:get('year'),month:get('month'),day:get('day')}}
  function dateStamp(date=new Date()){const d=dateParts(date);return `${d.year}-${d.month}-${d.day}`}
  function sessionName(date=new Date()){return new Intl.DateTimeFormat('en-US',{timeZone,month:'short',day:'numeric',year:'numeric'}).format(date)}
  return Object.freeze({dateParts,dateStamp,sessionName,timeZone});
 }
 return Object.freeze({create});
})();
window.UPCAlaskaTimeService=UPCAlaskaTimeService;
