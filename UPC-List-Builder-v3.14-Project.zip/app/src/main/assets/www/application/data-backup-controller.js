/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/application/data-backup-controller.js
 * Owner: Application Backup Workflow
 * Role: Controller
 * Responsibility: Owns backup/restore user interaction, confirmation, file-acquisition workflow, delivery handoff, and operation diagnostics around the backup domain service.
 * Does not own: Backup serialization/atomic restore mechanics; standard file-delivery mechanics; unrelated settings or persistence.
 * Side effects: Mutates backup UI and invokes the injected file-delivery boundary plus Data Backup domain service.
 * Related code: Backup mechanics belong to ../data-backup.js.
 */
const UPCDataBackupController=(()=>{
 function create({
  elementById,dataBackup,databaseProvider,appVersion,buildId,diagnostic,startOperation,finishOperation,
  messageUser,confirmUser,nativeBridgeProvider,locationRef,fileDelivery
 }={}){
  if(typeof elementById!=='function'||!dataBackup||typeof databaseProvider!=='function')throw new Error('Data Backup Controller data dependencies are incomplete.');
  if(typeof diagnostic!=='function'||typeof startOperation!=='function'||typeof finishOperation!=='function')throw new Error('Data Backup Controller diagnostic dependencies are incomplete.');
  if(typeof messageUser!=='function'||typeof confirmUser!=='function'||typeof nativeBridgeProvider!=='function'||typeof fileDelivery?.deliverText!=='function')throw new Error('Data Backup Controller interaction dependencies are incomplete.');
  const $=elementById,diag=diagnostic;
  function setStatus(message){const el=$('dataBackupStatus');if(el)el.textContent=String(message||'')}
  async function exportBackup(){
   const operationId=`DATA_BACKUP_EXPORT:${Date.now()}`;startOperation('DATA_BACKUP_EXPORT',operationId,'Create a restorable application-data backup.','The backup contains every required durable application-data store, excludes diagnostics and credentials, validates before delivery, and does not alter saved data.',{});
   try{
    setStatus('Preparing and validating backup…');
    const backup=await dataBackup.createBackup({appVersion,buildId}),checked=dataBackup.validateBackup(backup,{maxIndexedDbVersion:backup.indexedDb.version});
    if(!checked.valid)throw new Error('Generated backup did not validate: '+checked.errors.join(' '));
    const payload=JSON.stringify(backup,null,2),filename=dataBackup.filename(appVersion,backup.createdAt),bridge=nativeBridgeProvider(),platform=bridge?.platform?.()||'web';
    diag('data_backup_export_validated',{filename,platform,indexedDbVersion:backup.indexedDb.version,totalRecords:backup.manifest.totalRecords,stores:backup.manifest.stores,diagnosticsIncluded:false,credentialsIncluded:false});
    const delivery=fileDelivery.deliverText(payload,filename,'application/json');
    setStatus(delivery.platform==='native'?`Backup validated · ${backup.manifest.totalRecords} records · saving to Downloads…`:`Backup downloaded · ${backup.manifest.totalRecords} records`);
    finishOperation(operationId,`Validated application-data backup prepared with ${backup.manifest.totalRecords} records.`,'PASS',{filename,platform,totalRecords:backup.manifest.totalRecords,stores:backup.manifest.stores});
   }catch(e){
    const message=e?.message||String(e);setStatus('Backup failed · '+message);diag('data_backup_export_failed',{message});finishOperation(operationId,'Application-data backup failed.','FAIL',{message});await messageUser(message,'Backup Failed');
   }
  }
  async function restoreFile(file){
   if(!file)return;
   const operationId=`DATA_BACKUP_RESTORE:${Date.now()}`;startOperation('DATA_BACKUP_RESTORE',operationId,'Validate and restore a selected application-data backup.','No current data changes unless the complete backup validates and the user explicitly confirms replacement. Restore then commits all durable stores atomically.',{name:file.name||null,size:file.size??null});
   try{
    setStatus('Validating selected backup…');
    const raw=await file.text(),db=await databaseProvider(),checked=dataBackup.validateBackup(raw,{maxIndexedDbVersion:Number(db.version||0)});
    if(!checked.valid){
     const reason=checked.errors.join('\n');setStatus('Backup not valid · no data changed');diag('data_backup_restore_rejected',{name:file.name||null,errors:checked.errors});finishOperation(operationId,'Selected backup was rejected before any data mutation.','FAIL',{errors:checked.errors});
     await messageUser(`This backup cannot be restored. No current data was changed.\n\n${reason}`,'Backup Not Valid');return;
    }
    const backup=checked.backup,storeSummary=backup.manifest.stores.map(x=>`${x.name}: ${x.count}`).join('\n');
    const confirmed=await confirmUser(`Backup created: ${backup.createdAt}\nRelease: v${backup.release.version}\nRecords: ${backup.manifest.totalRecords}\n\n${storeSummary}\n\nRestoring this backup means current saved application data will be replaced. Diagnostics and AceNet credentials are not part of the backup. Continue?`,'Restore Data Backup',{okLabel:'Restore'});
    if(!confirmed){setStatus('Restore cancelled · no data changed');finishOperation(operationId,'Validated backup restore was cancelled by the user.','PASS',{cancelled:true,totalRecords:backup.manifest.totalRecords});return}
    setStatus('Restoring validated backup…');
    const result=await dataBackup.restoreBackup(backup,{database:db});
    diag('data_backup_restore_completed',{name:file.name||null,createdAt:backup.createdAt,totalRecords:result.totalRecords,stores:result.stores});setStatus(`Restore complete · ${result.totalRecords} records`);
    finishOperation(operationId,`Application-data restore completed atomically with ${result.totalRecords} records.`,'PASS',{totalRecords:result.totalRecords,stores:result.stores});
    await messageUser('The backup was restored successfully. The application will reload now so every screen uses the restored data.','Restore Complete');locationRef.reload();
   }catch(e){
    const message=e?.message||String(e);setStatus('Restore failed · current data preserved');diag('data_backup_restore_failed',{name:file.name||null,message});finishOperation(operationId,'Application-data restore failed; the restore transaction did not complete.','FAIL',{message});await messageUser(`Restore failed. Current saved data was not intentionally replaced.\n\n${message}`,'Restore Failed');
   }finally{const input=$('restoreDataBackupFile');if(input)input.value=''}
  }
  function bind({on}={}){
   if(typeof on!=='function')throw new Error('Data Backup Controller requires the shared event binder.');
   on('exportDataBackup','click',exportBackup);
   on('restoreDataBackup','click',()=>$('restoreDataBackupFile')?.click());
   on('restoreDataBackupFile','change',e=>restoreFile(e.target.files?.[0]||null));
  }
  return Object.freeze({bind,exportBackup,restoreFile,setStatus});
 }
 return Object.freeze({create});
})();
window.UPCDataBackupController=UPCDataBackupController;
