/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/application/dialog-service.js
 * Owner: Application Dialog Presentation
 * Role: UI service
 * Responsibility: Owns application modal/prompt/confirm/message presentation mechanics.
 * Does not own: Business validation, navigation policy, persistence, or domain state.
 * Side effects: Creates/mutates dialog DOM and resolves user interaction promises.
 * Related code: Feature owners decide when/why to prompt; dialog styling belongs to dialogs.css.
 */
const UPCDialogService=(()=>{
 function create({elementById,setTimeoutFn}={}){
  if(typeof elementById!=='function')throw new Error('Dialog Service requires an element lookup capability.');
  const $=elementById,delay=typeof setTimeoutFn==='function'?setTimeoutFn:setTimeout;let tail=Promise.resolve();
  function dialog(options={}){
   const run=()=>new Promise(resolve=>{
    const overlay=$('appDialogOverlay'),title=$('appDialogTitle'),message=$('appDialogMessage'),wrap=$('appDialogInputWrap'),input=$('appDialogInput'),cancel=$('appDialogCancel'),ok=$('appDialogOk');
    if(!overlay||!title||!message||!wrap||!input||!cancel||!ok){resolve(options.kind==='confirm'?false:options.kind==='prompt'?null:true);return}
    title.textContent=String(options.title||'UPC List Builder');message.textContent=String(options.message||'');const wantsInput=options.kind==='prompt',wantsCancel=options.kind==='confirm'||wantsInput;
    wrap.classList.toggle('hidden',!wantsInput);cancel.classList.toggle('hidden',!wantsCancel);input.value=wantsInput?String(options.value??''):'';input.placeholder=String(options.placeholder||'');ok.textContent=String(options.okLabel||'OK');cancel.textContent=String(options.cancelLabel||'Cancel');
    const finish=value=>{overlay.classList.add('hidden');ok.onclick=null;cancel.onclick=null;input.onkeydown=null;resolve(value)};
    ok.onclick=()=>finish(wantsInput?input.value:true);cancel.onclick=()=>finish(wantsInput?null:false);input.onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();ok.click()}};
    overlay.classList.remove('hidden');delay(()=>{if(wantsInput){input.focus();input.select()}else ok.focus()},0);
   });
   const next=tail.then(run,run);tail=next.catch(()=>{});return next;
  }
  function message(value,title='UPC List Builder'){return dialog({kind:'message',title,message:value})}
  function confirm(value,title='Please Confirm',options={}){return dialog({kind:'confirm',title,message:value,...options})}
  function prompt(value,initial='',title='Enter Information'){return dialog({kind:'prompt',title,message:value,value:initial})}
  function installCompatibility(windowRef){
   if(!windowRef)return;
   windowRef.UPCAppMessage=message;windowRef.UPCAppConfirm=confirm;windowRef.UPCAppPrompt=prompt;
   windowRef.alert=value=>{void message(String(value??''))};
  }
  return Object.freeze({dialog,message,confirm,prompt,installCompatibility});
 }
 return Object.freeze({create});
})();
window.UPCDialogService=UPCDialogService;
