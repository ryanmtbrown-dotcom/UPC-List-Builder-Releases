/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/application/dom-adapter.js
 * Owner: Application DOM Infrastructure
 * Role: DOM adapter
 * Responsibility: Owns small shared DOM access/mutation helpers injected into application owners.
 * Does not own: Feature rendering policy, navigation, state, persistence, or business rules.
 * Side effects: Reads/mutates DOM only through its narrow adapter API.
 * Related code: Feature-specific rendering stays with its controller/presentation owner.
 */
const UPCDomAdapter=(()=>{
 function create({documentRef,diagnostic}={}){
  if(!documentRef||typeof diagnostic!=='function')throw new Error('DOM Adapter dependencies are incomplete.');
  const elementById=id=>documentRef.getElementById(id),queryAll=selector=>documentRef.querySelectorAll(selector),querySelector=selector=>documentRef.querySelector(selector);
  function setText(id,value){const el=elementById(id);if(el)el.textContent=value}
  function bind(id,event,handler){const el=elementById(id);if(!el){diagnostic('boot_missing_element',{id,event});return false}el.addEventListener(event,handler);return true}
  return Object.freeze({elementById,queryAll,querySelector,setText,bind});
 }
 return Object.freeze({create});
})();
window.UPCDomAdapter=UPCDomAdapter;
