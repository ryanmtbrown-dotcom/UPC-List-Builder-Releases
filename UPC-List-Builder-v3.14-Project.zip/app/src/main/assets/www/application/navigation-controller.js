/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/application/navigation-controller.js
 * Owner: Application Navigation
 * Role: Controller
 * Responsibility: Owns screen selection, history/back-stack behavior, navigation lifecycle, and navigation diagnostics.
 * Does not own: Feature business logic, persistence, lookup routing, or dialog implementation.
 * Side effects: Mutates screen visibility/history and installs its bounded navigation listeners.
 * Related code: Feature entry actions belong to the target controller; listener lifecycle belongs here.
 */
const UPCNavigationController=(()=>{
 function create({elementById,querySelector,historyRef,locationRef,diagnostic,startOperation,finishOperation,saveCurrent,homeTitle='Scan. Build. Organize.'}={}){
  if(typeof elementById!=='function'||typeof querySelector!=='function'||!historyRef||!locationRef)throw new Error('Navigation Controller view/history dependencies are incomplete.');
  if(typeof diagnostic!=='function'||typeof startOperation!=='function'||typeof finishOperation!=='function'||typeof saveCurrent!=='function')throw new Error('Navigation Controller lifecycle dependencies are incomplete.');
  const $=elementById,diag=diagnostic,subsystemOperationStart=startOperation,subsystemOperationFinish=finishOperation;
  let activeScreen='boot',navStack=[];
  function show(id,title,{push=true,reset=false,historyWrite=true}={}){
   const previous=activeScreen,navOp=`NAVIGATION:${Date.now()}:${Math.random().toString(36).slice(2,8)}`;
   subsystemOperationStart('NAVIGATION',navOp,`Navigate from ${previous||'none'} to ${id}.`,'Exactly one requested application screen becomes active; navigation history changes only as requested.',{from:previous||null,to:id,title,push,reset,historyWrite});
   if(reset)navStack=[];else if(push&&previous&&previous!==id)navStack.push({id:previous,title:$('screenTitle')?.textContent||'Main Menu'});
   activeScreen=id;
   if(historyWrite&&id!=='boot'){try{const state={upcScreen:id,title,depth:navStack.length};if(reset)historyRef.replaceState(state,'',locationRef.href);else if(push&&previous!==id)historyRef.pushState(state,'',locationRef.href)}catch(e){diag('navigation_history_error',{message:e.message})}}
   ['home','nameScreen','dsdScreen','builder','listScreen','openScreen','importScreen','locationScreen','locationExplorerScreen','settingsScreen'].forEach(x=>$(x).classList.toggle('hidden',x!==id));
   $('screenTitle').textContent=title;
   const isHome=id==='home';$('navBack').classList.toggle('hidden',isHome);$('navMenu').classList.toggle('hidden',isHome);querySelector('.appbar')?.classList.toggle('subpage',!isHome);
   diag('navigation_changed',{from:previous,to:id,title,stackDepth:navStack.length,stack:navStack.map(x=>x.id)});
   subsystemOperationFinish(navOp,`Navigation completed on ${id}; stack depth=${navStack.length}.`,'PASS',{from:previous||null,to:id,stackDepth:navStack.length,activeScreen});
  }
  function goHome(source='home_button'){saveCurrent();diag('navigation_home_requested',{source,from:activeScreen});show('home',homeTitle,{push:false,reset:true})}
  function goBack(source='back_button'){const target=navStack.pop();diag('navigation_back_requested',{source,from:activeScreen,target:target?.id||'home',remainingDepth:navStack.length});if(target)show(target.id,target.title||'Main Menu',{push:false,historyWrite:false});else goHome(source)}
  function bind({windowRef,documentRef}={}){
   const back=$('navBack'),home=$('navMenu'),builderHome=$('builderBackHome');
   if(back)back.onclick=()=>goBack('header_back');if(home)home.onclick=()=>goHome('header_home');if(builderHome)builderHome.onclick=()=>goHome('builder_home_button');
   windowRef?.addEventListener?.('popstate',e=>{diag('browser_popstate',{state:e.state,activeScreen});if(activeScreen!=='home')goBack('browser_back')});
   documentRef?.addEventListener?.('click',e=>{const builder=e.target.closest?.('#builderBackHome');if(builder){e.preventDefault();e.stopPropagation();goHome('builder_home_capture');return}const menu=e.target.closest?.('#navMenu');if(menu){e.preventDefault();e.stopPropagation();goHome('header_home_capture');return}const navBack=e.target.closest?.('#navBack');if(navBack){e.preventDefault();e.stopPropagation();goBack('header_back_capture')}},true);
  }
  function currentScreen(){return activeScreen}
  function stack(){return[...navStack]}
  return Object.freeze({show,goHome,goBack,currentScreen,stack,bind});
 }
 return Object.freeze({create});
})();
window.UPCNavigationController=UPCNavigationController;
