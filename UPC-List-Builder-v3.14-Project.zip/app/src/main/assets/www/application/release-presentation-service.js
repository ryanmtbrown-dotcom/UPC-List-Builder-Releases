/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/application/release-presentation-service.js
 * Owner: Application Release Presentation
 * Role: Presentation service
 * Responsibility: Owns displaying current release/version metadata in the UI.
 * Does not own: Release authority, updater behavior, build synchronization, or persistence.
 * Side effects: DOM text/presentation only.
 * Related code: Release identity authority is gradle.properties; update behavior belongs to update-status/AppUpdateService.
 */
const UPCReleasePresentationService=(()=>{
 function create({elementById,version}={}){
  if(typeof elementById!=='function')throw new Error('Release Presentation Service dependencies are incomplete.');
  const $=elementById;
  function apply(){const home=$('homeVersion'),settings=$('settingsVersion');if(home)home.innerHTML=`v${version}&nbsp; • &nbsp;© 2026 RMTB Designs`;if(settings)settings.textContent=`v${version}`}
  return Object.freeze({apply});
 }
 return Object.freeze({create});
})();
window.UPCReleasePresentationService=UPCReleasePresentationService;
