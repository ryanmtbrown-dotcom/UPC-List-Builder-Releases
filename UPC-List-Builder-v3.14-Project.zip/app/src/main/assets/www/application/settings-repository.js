/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/application/settings-repository.js
 * Owner: Settings Persistence
 * Role: Repository facade
 * Responsibility: Owns durable ordinary-list export preferences: selected Master Library fields and the Force ACE MISC Format choice.
 * Does not own: Settings UI, export schema identity, workbook composition, feature business rules, credentials, or unrelated domain state.
 * Side effects: Reads/writes the approved settings store through UPCDB and retires superseded export/display preference records when current preferences initialize.
 * Related code: Settings workflow belongs to settings-controller.js; export field identity belongs to catalog/standard-export-schema.js.
 */
const UPCSettingsRepository=(()=>{
 const EXPORT_PREFERENCES_KEY='listExportPreferences';
 const PREVIOUS_EXPORT_HEADERS_KEY='listExportHeaders';
 const LEGACY_DISPLAY_HEADERS_KEY='displayHeaders';
 function create({db}={}){
  if(!db)throw new Error('Settings Repository database dependency is incomplete.');
  async function getExportPreferences(){return db.get('meta',EXPORT_PREFERENCES_KEY)}
  async function initializeExportPreferences(defaultHeaders=[],defaultForceAceMiscFormat=true){
   const allowed=[...new Set((Array.isArray(defaultHeaders)?defaultHeaders:[]).map(value=>String(value??'').trim()).filter(Boolean))],allowedSet=new Set(allowed),normalizeHeaders=headers=>(Array.isArray(headers)?headers:[]).map(value=>String(value??'').trim()).filter((value,index,array)=>allowedSet.has(value)&&array.indexOf(value)===index);
   const current=await getExportPreferences();
   if(current&&Array.isArray(current.headers)&&typeof current.forceAceMiscFormat==='boolean'){
    const normalized={...current,key:EXPORT_PREFERENCES_KEY,headers:normalizeHeaders(current.headers)};if(normalized.headers.length!==current.headers.length||normalized.headers.some((header,index)=>header!==current.headers[index]))await db.put('meta',normalized);await db.remove('meta',PREVIOUS_EXPORT_HEADERS_KEY);await db.remove('meta',LEGACY_DISPLAY_HEADERS_KEY);return normalized;
   }
   const previous=await db.get('meta',PREVIOUS_EXPORT_HEADERS_KEY),migrated=Array.isArray(previous?.headers)?normalizeHeaders(previous.headers):allowed;
   const record={key:EXPORT_PREFERENCES_KEY,headers:migrated,forceAceMiscFormat:defaultForceAceMiscFormat===true};
   await db.put('meta',record);await db.remove('meta',PREVIOUS_EXPORT_HEADERS_KEY);await db.remove('meta',LEGACY_DISPLAY_HEADERS_KEY);return record;
  }
  async function saveExportPreferences({headers=[],forceAceMiscFormat=true}={}){
   const record={key:EXPORT_PREFERENCES_KEY,headers:Array.isArray(headers)?[...headers]:[],forceAceMiscFormat:forceAceMiscFormat===true};
   await db.put('meta',record);return record;
  }
  return Object.freeze({getExportPreferences,initializeExportPreferences,saveExportPreferences});
 }
 return Object.freeze({create,EXPORT_PREFERENCES_KEY,PREVIOUS_EXPORT_HEADERS_KEY,LEGACY_DISPLAY_HEADERS_KEY});
})();
window.UPCSettingsRepository=UPCSettingsRepository;
