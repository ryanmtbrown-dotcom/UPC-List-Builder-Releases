/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/application/startup-orchestrator.js
 * Owner: Application Startup
 * Role: Orchestrator
 * Responsibility: Owns ordered startup stages, readiness gating, splash progress, bounded startup watchdog behavior, and startup completion.
 * Does not own: AceNet authentication mechanics; migration implementation; catalog rules; general navigation; business persistence.
 * Side effects: Owns startup timers/stages and invokes injected startup capabilities; emits diagnostics only.
 * Related code: Subsystem readiness work belongs to injected owners; application composition belongs to Application Shell.
 */
const UPCStartupOrchestrator=(()=>{
 function create({
  elementById,diagnostic,beginDiagnosticSession,startOperation,finishOperation,
  performanceNow,startedAt,requestFrame,windowRef,nativeBridgeProvider,appVersion,
  minSplashMs=1800,watchdogMs=35000
 }={}){
  if(typeof elementById!=='function'||typeof diagnostic!=='function'||typeof beginDiagnosticSession!=='function')throw new Error('Startup Orchestrator diagnostic/view dependencies are incomplete.');
  if(typeof startOperation!=='function'||typeof finishOperation!=='function'||typeof performanceNow!=='function'||typeof requestFrame!=='function')throw new Error('Startup Orchestrator lifecycle dependencies are incomplete.');
  if(!windowRef||typeof nativeBridgeProvider!=='function')throw new Error('Startup Orchestrator platform dependencies are incomplete.');
  const $=elementById,diag=diagnostic,origin=Number.isFinite(Number(startedAt))?Number(startedAt):performanceNow();
  const updateTerminal=new Set(['NO_UPDATE','CHECK_FAILED','UPDATE_DEFERRED','INSTALLER_RETURNED','NATIVE_UNAVAILABLE']);
  let ready=false,progress=0,begun=false,watchdog=null,updateDecision=null,updateResolver=null;
  let updateExemptionStartedAt=null,updateExemptMs=0;
  const startupCeilingMs=30000;

  function elapsedMs(){return Math.max(0,Math.round(performanceNow()-origin))}
  function ordinaryElapsedMs(){return Math.max(0,elapsedMs()-updateExemptMs-(updateExemptionStartedAt==null?0:Math.max(0,performanceNow()-updateExemptionStartedAt)))}
  function isReady(){return ready}
  function snapshot(){return{progress,appReady:ready,elapsedMs:elapsedMs()}}
  function setProgress(value){
   progress=Math.max(progress,Math.max(0,Math.min(100,Number(value)||0)));
   const el=$('splashProgress');if(el)el.value=progress;const pct=$('splashPercent');if(pct)pct.textContent=`${Math.round(progress)}%`;
   return progress;
  }
  function setStage(value,label){
   const stage=$('splashStage');if(stage&&label)stage.textContent=label;
   const visibleProgress=setProgress(value);
   diag('startup_progress',{value:visibleProgress,label,requestedValue:Number(value)||0});
   return visibleProgress;
  }
  function acceptAceNetProgress(raw){
   if(ready)return snapshot();
   const payload=raw&&typeof raw==='object'?raw:{};
   const nativeProgress=Number(payload.progress);
   const terminal=payload.startupResolved===true;
   const label=String(payload.message||'').trim();
   let requested=progress;
   if(terminal)requested=Math.max(progress,96);
   else if(Number.isFinite(nativeProgress))requested=Math.max(56,Math.min(94,nativeProgress));
   else requested=Math.max(progress,56);
   if(label)setStage(requested,label);else setProgress(requested);
   diag('startup_acenet_progress_projected',{
    phase:payload.startupPhase||null,
    nativeProgress:Number.isFinite(nativeProgress)?nativeProgress:null,
    visibleProgress:progress,
    terminal
   });
   return snapshot();
  }
  function begin(){
   if(begun)return false;begun=true;
   beginDiagnosticSession();
   startOperation('STARTUP_TOTAL','Run the complete application startup sequence.','Startup reaches an explicit terminal Ready/degraded state with every meaningful operation timed and explained.');
   startOperation('APPLICATION_CORE','Load the application core.','The application JavaScript initializes and startup diagnostics begin.');
   finishOperation('APPLICATION_CORE','Application core loaded and this startup session was created.','PASS',{progress:12});
   setStage(12,'Loading application core…');
   watchdog=windowRef.setTimeout?.(()=>{
    const splash=$('splash');if(!splash||ready)return;
    if(updateExemptionStartedAt==null)diag('startup_watchdog_over_ceiling',{progress,appReady:ready,ordinaryElapsedMs:ordinaryElapsedMs(),result:'GUARD_CHECK'});
   },watchdogMs);
   return true;
  }
  function finishSplash(){
   const splash=$('splash');if(!splash||!ready)return;
   const remaining=Math.max(0,minSplashMs-elapsedMs());
   windowRef.setTimeout?.(()=>{if(watchdog!=null)windowRef.clearTimeout?.(watchdog);splash.classList.add('exit');windowRef.setTimeout?.(()=>splash.remove(),320)},remaining);
  }
  function acceptUpdateLifecycle(raw){
   try{
    const p=typeof raw==='string'?JSON.parse(raw):raw||{},state=String(p.state||'UNKNOWN').toUpperCase();
    updateDecision={...p,state};diag('startup_update_lifecycle',updateDecision);
    if((state==='DOWNLOADING'||state==='INSTALLING')&&updateExemptionStartedAt==null)updateExemptionStartedAt=performanceNow();
    else if(updateTerminal.has(state)&&updateExemptionStartedAt!=null){updateExemptMs+=Math.max(0,performanceNow()-updateExemptionStartedAt);updateExemptionStartedAt=null;}
    if(!ready){
     if(state==='CHECKING')setStage(42,p.message||'Checking for updates…');
     else if(state==='DOWNLOADING')setStage(44,p.message||'Downloading update…');
     else if(state==='INSTALLING')setStage(46,p.message||'Installing update…');
    }
    if(updateTerminal.has(state)&&updateResolver){const resolve=updateResolver;updateResolver=null;resolve(updateDecision)}
    return updateDecision;
   }catch(e){
    const decision={state:'CHECK_FAILED',message:'Update status could not be parsed.'};updateDecision=decision;diag('startup_update_lifecycle_parse_failed',{message:e?.message||String(e)});
    if(updateResolver){const resolve=updateResolver;updateResolver=null;resolve(decision)}
    return decision;
   }
  }
  function awaitUpdateDecision(){
   const bridge=nativeBridgeProvider();
   if(!bridge?.beginStartupUpdateCheck)return Promise.resolve({state:'NATIVE_UNAVAILABLE',message:'Native update service is unavailable.'});
   if(updateDecision&&updateTerminal.has(updateDecision.state))return Promise.resolve(updateDecision);
   return new Promise(resolve=>{
    updateResolver=resolve;
    try{bridge.beginStartupUpdateCheck(appVersion)}
    catch(e){updateResolver=null;resolve({state:'CHECK_FAILED',message:e?.message||'Update check could not start.'})}
   });
  }
  async function run({prepareSavedData,refreshLibraryStatus,refreshSavedListSummary,runAceNetStartup}={}){
   if(typeof prepareSavedData!=='function'||typeof refreshLibraryStatus!=='function'||typeof refreshSavedListSummary!=='function'||typeof runAceNetStartup!=='function')throw new Error('Startup Orchestrator prerequisite capabilities are incomplete.');
   if(!begun)begin();
   try{
    startOperation('UPDATE_CHECK','Resolve application update status before version-specific startup work.','The current build either confirms no newer update, completes the update handoff, or records that update checking is unavailable.');
    setStage(42,'Checking for updates…');diag('boot_stage',{stage:'startup_update_check'});
    const update=await awaitUpdateDecision();
    finishOperation('UPDATE_CHECK',update?.message||('Update state: '+String(update?.state||'UNKNOWN')),update?.state==='CHECK_FAILED'?'INCONCLUSIVE':'PASS',{state:update?.state||'UNKNOWN',candidateVersion:update?.candidateVersion||null});

    startOperation('SAVED_DATA','Prepare saved application data.','Legacy/saved list data and required one-time migrations can be prepared without error.');
    setStage(48,'Preparing local data…');diag('boot_stage',{stage:'startup_data_begin'});await new Promise(requestFrame);await prepareSavedData();
    finishOperation('SAVED_DATA','Saved application data prepared successfully.','PASS');

    setStage(55,'Checking Master Library…');diag('boot_stage',{stage:'startup_data_migrated'});
    startOperation('MASTER_LIBRARY','Check Master Library availability and saved-list summary.','Master Library status and saved-list summary can be read without preventing startup.');
    await Promise.all([refreshLibraryStatus(),refreshSavedListSummary()]);
    finishOperation('MASTER_LIBRARY','Master Library status and saved-list summary completed.','PASS');

    setStage(56,'Starting AceNet readiness checks…');diag('boot_stage',{stage:'startup_acenet_warmup'});
    startOperation('ACENET_STARTUP','Prepare the authenticated AceNet retailer worker.','Attempt native AceNet startup within the remaining ordinary 30-second launch window; never block local access indefinitely.');
    const budgetMs=Math.max(0,startupCeilingMs-ordinaryElapsedMs());
    diag('startup_acenet_ui_budget',{budgetMs,ordinaryElapsedMs:ordinaryElapsedMs(),startupCeilingMs,updateExemptMs});
    const ace=await runAceNetStartup({maxWaitMs:budgetMs});
    finishOperation('ACENET_STARTUP',ace.message,ace.ready?'PASS':'INCONCLUSIVE',{deferred:!ace.ready,warmup:true,authenticated:ace.authenticated===true,healthStatus:ace.healthStatus,status:ace.status||null,uiBudgetMs:budgetMs,...(ace.error?{message:ace.error}: {})});

    startOperation('APPLICATION_READY','Complete application startup.','The application opens with local functionality when AceNet verification is late; updates/installations are separately timed.');
    setStage(100,'Ready');diag('boot_stage',{stage:'startup_data_ready'});
    finishOperation('APPLICATION_READY','Startup checks completed and the application is entering Ready.','PASS',{progress:100});
   }catch(e){
    diag('startup_data_error',{message:e?.message||String(e),stack:e?.stack||null});
    startOperation('STARTUP_EXCEPTION','Complete startup without an unhandled startup exception.','No startup task throws an unhandled exception.');
    finishOperation('STARTUP_EXCEPTION',`Startup task failed: ${e?.message||String(e)}`,'FAIL',{stack:e?.stack||null});
   }finally{
    ready=true;const elapsed=elapsedMs();diag('app_ready',{elapsedMs:elapsed});finishOperation('STARTUP_TOTAL',`Application startup finished in ${elapsed} ms.`,'PASS',{elapsedMs:elapsed});finishSplash();
   }
   return snapshot();
  }
  return Object.freeze({begin,run,setStage,setProgress,acceptAceNetProgress,isReady,snapshot,elapsedMs,acceptUpdateLifecycle,awaitUpdateDecision});
 }
 return Object.freeze({create});
})();
window.UPCStartupOrchestrator=UPCStartupOrchestrator;
