/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/application/update-status-service.js
 * Owner: Application Update Presentation
 * Role: Service/controller
 * Responsibility: Owns web UI inquiry/display of native update status and update-check actions.
 * Does not own: Update download/install policy, network transport, release identity, or package signing.
 * Side effects: Calls the injected native update bridge and updates UI status.
 * Related code: Native update mechanics belong to AppUpdateService.kt; policy belongs to UpdatePolicy.kt.
 */
const UPCUpdateStatusService=(()=>{
 function create({elementById,diagnostic,nativeBridgeProvider,appVersion}={}){
  if(typeof elementById!=='function'||typeof diagnostic!=='function'||typeof nativeBridgeProvider!=='function')throw new Error('Update Status Service dependencies are incomplete.');
  const $=elementById,diag=diagnostic;
  function checkForUpdate(){diag('update_check_requested',{version:appVersion});const bridge=nativeBridgeProvider();if(bridge?.checkForUpdate)bridge.checkForUpdate(appVersion);else{const st=$('updateStatus');if(st)st.textContent='Updates are available in the Android app.'}}
  function acceptNativeStatus(message){const text=String(message||''),el=$('updateStatus');if(el)el.textContent=text;diag('update_status',{message:text});return text}
  function bind(){const button=$('checkUpdates');if(button)button.onclick=checkForUpdate}
  return Object.freeze({checkForUpdate,acceptNativeStatus,bind});
 }
 return Object.freeze({create});
})();
window.UPCUpdateStatusService=UPCUpdateStatusService;
