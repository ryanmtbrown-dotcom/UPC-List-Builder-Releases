/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/catalog-refresh-policy.js
 * Owner: Catalog Refresh Policy
 * Role: Pure policy
 * Responsibility: Owns deterministic decisions about when catalog evidence may refresh/replace fields.
 * Does not own: Persistence, network requests, UI, Work Sessions, or AceNet session behavior.
 * Side effects: None; policy evaluation is side-effect free.
 * Related code: Execution belongs to catalog/catalog-refresh-service.js.
 */
const UPCCatalogRefreshPolicy=(()=>{
 const normalizeSKU=value=>UPCIdentifierNormalization.normalizeSKU(value);
 const normalizeUPC=value=>UPCIdentifierNormalization.normalizeUPC(value);
 const FIELD_ALIASES=Object.freeze({
  description:['Description','Article Description'],
  retailerEachCost:['Retailer Each Cost','Cost'],
  manufacturerNumber:['MFG #','Manufacturer Number','MFG Number'],
  orderMultiple:['Order Multiple'],
  retailUnits:['Retail Units'],
  omWeight:['Weight','OM Weight'],
  aceRetailPrice:['Ace Retail Price','Retailer Each Price','Price'],
  level2RetailPrice:['Level 2 Retail Price'],
  masterUpc:['UPC/EAN','UPC'],
  commodityGroup:['Commodity Group'],
  merchandiseClassNumber:['Merchandise Class Number','Merchant Class','Merchandise Class'],
  productGroupNumber:['Product Group Number']
 });
 const LOCAL_MUTABLE=Object.freeze(['retailerEachCost','manufacturerNumber','orderMultiple','omWeight','aceRetailPrice','level2RetailPrice','commodityGroup','merchandiseClassNumber','productGroupNumber']);
 const blank=value=>value===null||value===undefined||String(value).trim()==='';
 const read=(record,canonical)=>{
  if(canonical==='masterUpc')return normalizeUPC(record?.upcKey||record?.originalUPC||'');
  const fields=record?.fields||{},aliases=FIELD_ALIASES[canonical]||[],key=Object.keys(fields).find(h=>aliases.some(a=>h.trim().toLowerCase()===a.toLowerCase()));
  return key?fields[key]:null;
 };
 const action=(name,value,reason,previous=null)=>Object.freeze({action:name,value:value??null,previous:previous??null,reason});
 function plan(options={}){
  const target=String(options.target||'').toUpperCase(),expectedSku=normalizeSKU(options.expectedSku),evidence=options.evidence&&typeof options.evidence==='object'?options.evidence:{},returnedSku=normalizeSKU(evidence.sku),exact=options.exactSkuVerified===true&&Boolean(expectedSku)&&Boolean(returnedSku)&&returnedSku===expectedSku;
  const verifiedAt=String(options.verifiedAt||new Date().toISOString()),stored=options.storedRecord||null,userCorrections=stored?.userCorrections&&typeof stored.userCorrections==='object'?stored.userCorrections:{},missing=new Set((options.missingFields||[]).map(x=>String(x||'').trim()).filter(Boolean)),repairPartial=options.repairPartial===true,completeUpcSet=options.completeUpcSet===true;
  if(!['MASTER_LIBRARY','LOCAL_LIBRARY'].includes(target))return Object.freeze({status:'REJECTED',reason:'UNSUPPORTED_TARGET',target,sku:expectedSku,verifiedAt,fieldActions:{},relationship:{action:'PRESERVE',reason:'UNSUPPORTED_TARGET'}});
  if(!exact)return Object.freeze({status:'REJECTED',reason:'EXACT_SKU_NOT_VERIFIED',target,sku:expectedSku,returnedSku,verifiedAt,fieldActions:{},relationship:{action:'PRESERVE',reason:'EXACT_SKU_NOT_VERIFIED'}});
  const fieldActions={sku:action('PRESERVE',expectedSku,'SKU_IS_CANONICAL_IDENTITY',expectedSku)};
  const setLocalField=(canonical,next)=>{
   const previous=read(stored,canonical);
   if(userCorrections[canonical]){fieldActions[canonical]=action('PRESERVE',previous,'USER_CORRECTION_PROTECTED',previous);return;}
   if(repairPartial&&missing.has(canonical)){
    fieldActions[canonical]=action('PRESERVE',previous,'PARTIAL_OR_MISSING_EVIDENCE_NOT_DESTRUCTIVE',previous);return;
   }
   if(blank(next)){fieldActions[canonical]=action('PRESERVE',previous,'NO_VERIFIED_VALUE',previous);return;}
   fieldActions[canonical]=String(previous??'')===String(next)?action('NO_OP',next,'VERIFIED_VALUE_UNCHANGED',previous):action('UPDATE',next,'VERIFIED_LOCAL_REFRESH_VALUE',previous);
  };
  if(target==='MASTER_LIBRARY'){
   for(const key of ['description','retailerEachCost','manufacturerNumber','orderMultiple','retailUnits','omWeight','aceRetailPrice','level2RetailPrice','commodityGroup','merchandiseClassNumber','productGroupNumber'])fieldActions[key]=action('PRESERVE',read(stored,key),'MASTER_SNAPSHOT_FIELD_PROTECTED',read(stored,key));
  }else{
   for(const key of LOCAL_MUTABLE)setLocalField(key,evidence[key]);
   const priorDescription=read(stored,'description');
   if(userCorrections.description)fieldActions.description=action('PRESERVE',priorDescription,'USER_CORRECTION_PROTECTED',priorDescription);
   else if(repairPartial&&missing.has('description'))fieldActions.description=action('PRESERVE',priorDescription,'PARTIAL_OR_MISSING_EVIDENCE_NOT_DESTRUCTIVE',priorDescription);
   else if(blank(priorDescription)&&!blank(evidence.description))fieldActions.description=action('UPDATE',evidence.description,'DESCRIPTION_FILL_ONLY',priorDescription);
   else fieldActions.description=action('PRESERVE',priorDescription,blank(evidence.description)?'NO_VERIFIED_VALUE':'DESCRIPTION_CREATION_ONLY',priorDescription);
   fieldActions.retailUnits=action('PRESERVE',read(stored,'retailUnits'),'RETAIL_UNITS_NOT_ACENET_AUTHORITATIVE',read(stored,'retailUnits'));
  }
  const observed=[...(Array.isArray(evidence.allUpcs)?evidence.allUpcs:[]),evidence.masterUpc].map(normalizeUPC).filter(Boolean),dedup=[...new Set(observed)],masterUpc=normalizeUPC(evidence.masterUpc)||dedup[0]||'',ordered=masterUpc?[masterUpc,...dedup.filter(x=>x!==masterUpc)]:dedup;
  const priorMaster=read(stored,'masterUpc');
  if(completeUpcSet&&masterUpc)fieldActions.masterUpc=priorMaster===masterUpc?action('NO_OP',masterUpc,'VERIFIED_MASTER_UPC_UNCHANGED',priorMaster):action('UPDATE',masterUpc,'VERIFIED_CANONICAL_MASTER_UPC',priorMaster);
  else fieldActions.masterUpc=action('PRESERVE',priorMaster,completeUpcSet?'COMPLETE_SET_MISSING_MASTER_UPC':'UPC_SET_NOT_COMPLETE',priorMaster);
  const partialMergeUpcs=repairPartial&&priorMaster?[priorMaster,...dedup.filter(x=>x!==priorMaster)]:[];
  const relationship=completeUpcSet&&ordered.length
   ?Object.freeze({action:'REPLACE',upcs:ordered,masterUpc,reason:'COMPLETE_EXACT_SKU_SET'})
   :(repairPartial&&dedup.length&&partialMergeUpcs.length?Object.freeze({action:'MERGE',upcs:partialMergeUpcs,masterUpc:priorMaster,reason:'PARTIAL_REPAIR_PRESERVE_EXISTING_CANONICAL'}):Object.freeze({action:'PRESERVE',upcs:[],masterUpc:priorMaster||null,reason:repairPartial&&dedup.length?'PARTIAL_WITHOUT_EXISTING_CANONICAL_NOT_APPLIED':'NO_COMPLETE_RELATIONSHIP_EVIDENCE'}));
  return Object.freeze({status:'APPLICABLE',reason:'VERIFIED_EXACT_SKU',target,sku:expectedSku,returnedSku,verifiedAt,fieldActions:Object.freeze(fieldActions),relationship});
 }
 return Object.freeze({plan,FIELD_ALIASES,LOCAL_MUTABLE});
})();
window.UPCCatalogRefreshPolicy=UPCCatalogRefreshPolicy;
