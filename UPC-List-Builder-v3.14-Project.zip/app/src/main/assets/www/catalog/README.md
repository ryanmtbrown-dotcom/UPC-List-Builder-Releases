# Catalog Directory Ownership

OWNS: catalog mapping, the 30-field Master export identity and 33-field ACE MISC header identity, refresh execution, maintenance/repair orchestration, read-only inspection, Master Library presentation control, and Retail Units resolution.

DOES NOT OWN: ordinary workbook composition, export preference persistence, ACE MISC row/layout formatting and validation, raw IndexedDB infrastructure, normal lookup UI, Work Session persistence, AceNet authentication/session state, or DSD/MISC UI.

DEPENDENCY RULE: catalog services consume repository/relationship/AceNet capabilities explicitly; direct raw `UPCDB` access is prohibited outside approved repository/inspection infrastructure. Local records distinguish Ace-derived cache data from third-party-vendor data according to `PRODUCT_DATA_AUTHORITY_CONTRACT.md`.
