/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/catalog/catalog-maintenance-service.js
 * Owner: Catalog Maintenance
 * Role: Application/domain service
 * Responsibility: Owns verified Local/MISC repair candidate selection and sequential catalog-maintenance orchestration.
 * Does not own: Raw persistence, UI, AceNet session mechanics, or general normal lookup.
 * Side effects: Calls injected catalog/AceNet/repository services and may persist only through approved owners.
 * Related code: User-facing maintenance UI belongs to admin controllers; field authority belongs to Catalog Refresh Service/Policy.
 */
const UPCCatalogMaintenanceService=(()=>{
 function create({
  requestCatalog,
  refreshService,
  localRepository,
  miscMaintenanceService,
  normalizeSku,
  buildCorrectedSnapshot,
  buildSnapshotFromCatalog,
  syncCurrentSnapshot,
  diagnostic
 }={}){
  if(typeof requestCatalog!=='function'||!refreshService||!localRepository||!miscMaintenanceService||typeof normalizeSku!=='function')throw new Error('Catalog Maintenance Service dependencies are incomplete.');
  if(typeof buildCorrectedSnapshot!=='function'||typeof buildSnapshotFromCatalog!=='function'||typeof syncCurrentSnapshot!=='function')throw new Error('Catalog Maintenance Service snapshot dependencies are incomplete.');
  const diag=typeof diagnostic==='function'?diagnostic:()=>{};

  async function refreshLocalLibraryFromAceNet(sku){
   const result=await requestCatalog(sku,{repair:true}),partial=result.status==='VERIFIED_PARTIAL';
   if((result.status!=='VERIFIED'&&!partial)||!result.catalog)return{sku,status:result.status};
   const key=normalizeSku(sku),catalog={...result.catalog,sku:key},missingFields=[...new Set((result.missingFields||[]).map(x=>String(x||'').trim()).filter(Boolean))],localRow=await localRepository.getRecordBySku(key);
   let applied=null;
   if(localRow)applied=await refreshService.applyCatalogRefreshPolicyToExistingRecord({sku:key,target:'LOCAL_LIBRARY',record:localRow,evidence:catalog,exactSkuVerified:normalizeSku(result.sku)===key,source:'ACENET_REPAIR',relationshipSource:'ACENET_LOCAL_REPAIR',completeUpcSet:!partial,repairPartial:partial,missingFields});
   const freshLocal=await localRepository.getRecordBySku(key);
   let snapshot=null,stored={itemsUpdated:0},currentUpdated=false;
   if(freshLocal)snapshot=await buildCorrectedSnapshot(key,freshLocal);
   else if(!partial)snapshot=buildSnapshotFromCatalog(catalog,key,1);
   if(snapshot){stored=await miscMaintenanceService.replaceSnapshotsForSku(key,snapshot);currentUpdated=await syncCurrentSnapshot(key,snapshot)}
   diag('local_data_acenet_repaired',{sku:key,verification:partial?'PARTIAL':'COMPLETE',missingFields,localUpdated:Boolean(applied?.storage?.updated),missingFieldsPreserved:partial,relationshipAction:applied?.plan?.relationship?.action||'NONE',snapshotItemsUpdated:stored.itemsUpdated,currentUpdated});
   return{sku:key,status:'COMPLETED',partial,missingFields,localUpdated:Boolean(applied?.storage?.updated),snapshotItemsUpdated:stored.itemsUpdated,currentUpdated};
  }

  async function collectRepairCandidates(){
   const [local,misc]=await Promise.all([localRepository.findRepairCandidates(),miscMaintenanceService.findSnapshotRepairCandidates()]),bySku=new Map();
   for(const entry of [...local,...misc]){
    const key=normalizeSku(entry.sku),prior=bySku.get(key)||{sku:key,reasons:new Set()};
    (entry.reasons||[]).forEach(reason=>prior.reasons.add(reason));bySku.set(key,prior);
   }
   return [...bySku.values()].map(entry=>({sku:entry.sku,reasons:[...entry.reasons]}));
  }

  async function repairAll(){
   const candidates=await collectRepairCandidates();
   let completed=0,partial=0,failed=0;const partialDetails=[];
   for(const entry of candidates){
    try{
     const out=await refreshLocalLibraryFromAceNet(entry.sku);
     if(out.status==='COMPLETED'){if(out.partial){partial++;partialDetails.push(`${entry.sku}: ${(out.missingFields||[]).join(', ')||'field unavailable'}`)}else completed++}
     else failed++;
    }catch(e){failed++;diag('local_data_repair_item_failed',{sku:entry.sku,reasons:[...entry.reasons],message:e?.message||String(e)})}
   }
   return{candidateCount:candidates.length,completed,partial,failed,partialDetails};
  }

  return Object.freeze({refreshLocalLibraryFromAceNet,collectRepairCandidates,repairAll});
 }
 return Object.freeze({create});
})();
window.UPCCatalogMaintenanceService=UPCCatalogMaintenanceService;
