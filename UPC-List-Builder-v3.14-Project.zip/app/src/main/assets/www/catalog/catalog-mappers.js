/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/catalog/catalog-mappers.js
 * Owner: Catalog Domain Mapping
 * Role: Pure mapper
 * Responsibility: Owns reusable catalog header aliases, field lookup, weight/classification normalization, and Local field mapping primitives.
 * Does not own: Persistence, lookup orchestration, UI, or network.
 * Side effects: None; mapping/normalization only.
 * Related code: Catalog refresh/inspection owners consume these helpers.
 */
const UPCCatalogMappers=(()=>{
 const LOCAL_LIBRARY_FIELD_ALIASES=Object.freeze({
  description:['Description','Article Description'],
  retailerEachCost:['Retailer Each Cost','Cost'],
  manufacturerNumber:['MFG #','Manufacturer Number','MFG Number'],
  orderMultiple:['Order Multiple'],
  omWeight:['Weight','OM Weight'],
  aceRetailPrice:['Ace Retail Price','Retailer Each Price','Price'],
  level2RetailPrice:['Level 2 Retail Price'],
  retailUnits:['Retail Units'],
  commodityGroup:['Commodity Group'],
  merchandiseClassNumber:['Merchandise Class Number','Merchant Class','Merchandise Class'],
  productGroupNumber:['Product Group Number']
 });
 function normalizeAceNetWeight(value){
  const raw=String(value??'').trim();if(!raw)return'';
  const m=raw.replace(/,/g,'').match(/(?:^|\s)(\d+(?:\.\d+)?|\.\d+)(?=\s*[A-Za-z]|\s*$)/);
  if(!m)return'';
  const n=Number(m[1]);return Number.isFinite(n)&&n>=0?String(n):'';
 }
 function findHeader(meta,aliases){
  const headers=Array.isArray(meta?.headers)?meta.headers:[];
  return (aliases||[]).map(a=>headers.find(h=>String(h).trim().toLowerCase()===String(a).toLowerCase())).find(Boolean)||null;
 }
 function normalizeLocalClassificationCode(value){const m=String(value??'').trim().match(/\d+/);return m?m[0]:''}
 return Object.freeze({LOCAL_LIBRARY_FIELD_ALIASES,normalizeAceNetWeight,findHeader,normalizeLocalClassificationCode});
})();
window.UPCCatalogMappers=UPCCatalogMappers;
