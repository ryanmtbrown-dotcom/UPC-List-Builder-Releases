/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/catalog/catalog-refresh-service.js
 * Owner: Catalog Refresh
 * Role: Domain service
 * Responsibility: Owns execution of Catalog Refresh Policy, verified catalog persistence, UPC reconciliation, and policy-routed field refresh.
 * Does not own: UI, raw IndexedDB, native session/extraction, Work Session persistence.
 * Side effects: Mutates Master/Local/identity state only through injected repositories/relationship service after verified evidence.
 * Related code: Refresh decisions come from catalog-refresh-policy.js; maintenance orchestration belongs to catalog-maintenance-service.js.
 */
const UPCCatalogRefreshService=(()=>{
 function create({
  policy,
  masterRepository,
  localRepository,
  relationshipService,
  effectiveResolver,
  normalizeSku,
  normalizeUpc,
  resolveRetailUnits,
  diagnostic
 }={}){
  if(!policy||!masterRepository||!localRepository||!relationshipService||!effectiveResolver)throw new Error('Catalog Refresh Service requires catalog repositories, policy, relationship service, and effective resolver.');
  if(typeof normalizeSku!=='function'||typeof normalizeUpc!=='function'||typeof resolveRetailUnits!=='function')throw new Error('Catalog Refresh Service normalization and Retail Units dependencies are required.');
  const UPCCatalogRefreshPolicy=policy,UPCMasterRepository=masterRepository,UPCLocalRepository=localRepository,UPCIdentifierRelationshipService=relationshipService,UPCEffectiveCatalogResolver=effectiveResolver;
  const normalizeSKU=normalizeSku,normalizeUPC=normalizeUpc,resolveAceNetRetailUnits=resolveRetailUnits,diag=typeof diagnostic==='function'?diagnostic:()=>{};

async function applyCatalogRefreshPolicyToExistingRecord({sku,target,record,evidence,exactSkuVerified=false,source='ACENET_REFRESH',relationshipSource=source,completeUpcSet=false,repairPartial=false,missingFields=[]}={}){
 const key=normalizeSKU(sku),plan=UPCCatalogRefreshPolicy.plan({target,expectedSku:key,storedRecord:record,evidence:evidence&&typeof evidence==='object'?evidence:{},exactSkuVerified:exactSkuVerified===true,completeUpcSet,repairPartial,missingFields});
 if(plan.status!=='APPLICABLE'){diag('catalog_refresh_policy_rejected',{sku:key,target,reason:plan.reason,returnedSku:plan.returnedSku||null,exactSkuVerified:exactSkuVerified===true,source});throw new Error(`Catalog Refresh Policy rejected ${key}: ${plan.reason}`)}
 let storage={updated:false},relationships=null;
 if(target==='MASTER_LIBRARY'){
   const changes=[];let row=record;
   if(plan.fieldActions.masterUpc?.action==='UPDATE'){
     diag('catalog_refresh_master_upc_update_started',{sku:key,recordId:record?.id??null,previousMasterUpc:plan.fieldActions.masterUpc.previous||null,nextMasterUpc:plan.fieldActions.masterUpc.value,source,verifiedAt:plan.verifiedAt});
     try{
      const updated=await UPCMasterRepository.updateMasterUpc(record.id,key,plan.fieldActions.masterUpc.value,{source,verifiedAt:plan.verifiedAt});
      row=updated?.row||row;if(updated?.change?.changed)changes.push(updated.change);
      diag('catalog_refresh_master_upc_update_completed',{sku:key,recordId:record?.id??null,changed:Boolean(updated?.change?.changed),previousMasterUpc:updated?.change?.before??plan.fieldActions.masterUpc.previous??null,nextMasterUpc:updated?.change?.after??plan.fieldActions.masterUpc.value,source,verifiedAt:plan.verifiedAt});
     }catch(e){diag('catalog_refresh_master_upc_update_failed',{sku:key,recordId:record?.id??null,previousMasterUpc:plan.fieldActions.masterUpc.previous||null,nextMasterUpc:plan.fieldActions.masterUpc.value,source,message:e?.message||String(e),guard:e?.libraryGuard||null});throw e}
   }
   storage={updated:changes.length>0,row,changes};
 }else if(target==='LOCAL_LIBRARY'){
   const changes={};
   for(const [field,decision] of Object.entries(plan.fieldActions))if(decision?.action==='UPDATE'&&!['masterUpc','sku','retailUnits'].includes(field))changes[field]=decision.value;
   const changed=Object.keys(changes).length?await UPCLocalRepository.correctFields(key,changes,{source,preserveUser:true}):{updated:false,applied:[]};
   const masterUpc=plan.fieldActions.masterUpc?.action==='UPDATE'?await UPCLocalRepository.updateMasterUpc(key,plan.fieldActions.masterUpc.value,{source}):{updated:false};
   storage={updated:Boolean(changed.updated||masterUpc.updated),changed,masterUpc,preservedMissingFields:[...missingFields]};
   await UPCLocalRepository.setAceNetVerification(key,{status:repairPartial?'PARTIAL':'COMPLETE',missingFields});
 }
 if(plan.relationship.action==='REPLACE')relationships=await UPCIdentifierRelationshipService.recordVerifiedSkuUpcs(key,plan.relationship.upcs,relationshipSource,{completeness:'COMPLETE',exactSkuVerified:true});
 else if(plan.relationship.action==='MERGE')relationships=await UPCIdentifierRelationshipService.recordVerifiedSkuUpcs(key,plan.relationship.upcs,relationshipSource,{completeness:'PARTIAL',exactSkuVerified:true});
 diag('catalog_refresh_policy_applied',{sku:key,target,source,fieldActions:Object.fromEntries(Object.entries(plan.fieldActions).map(([k,v])=>[k,v.action])),relationshipAction:plan.relationship.action,storageUpdated:Boolean(storage?.updated),relationshipCount:relationships?.upcs?.length||0,verifiedAt:plan.verifiedAt});
 return{plan,storage,relationships};
}
async function reconcileVerifiedUpcSetWithCatalog(sku,upcs,{returnedSku=null,exactSkuVerified=false,source='ACENET_UPCS',relationshipSource=source,persistRelationships=true}={}){
 const key=normalizeSKU(sku),returned=normalizeSKU(returnedSku),ordered=[...new Set((Array.isArray(upcs)?upcs:[]).map(normalizeUPC).filter(Boolean))];if(!key||!ordered.length)return{updated:false,reason:'NO_VERIFIED_UPCS',upcs:[]};if(exactSkuVerified!==true||!returned||returned!==key)return{updated:false,reason:'EXACT_SKU_NOT_VERIFIED',upcs:ordered,returnedSku:returned||null};
 const evidence=await UPCEffectiveCatalogResolver.inspectSKU(key);if(evidence.master.count>1||evidence.local.count>1)return{updated:false,reason:'AMBIGUOUS_CATALOG',upcs:ordered};
 const officialMaster=evidence.master.count===1&&evidence.master.row,local=evidence.local.count===1?evidence.local.row:null,target=officialMaster?'MASTER_LIBRARY':local?'LOCAL_LIBRARY':null,record=officialMaster?evidence.master.row:local;
 let applied=null;
 if(target)applied=await applyCatalogRefreshPolicyToExistingRecord({sku:key,target,record,evidence:{sku:returned,masterUpc:ordered[0],allUpcs:ordered},exactSkuVerified:true,source,relationshipSource,completeUpcSet:true});
 else if(persistRelationships)applied={relationships:await UPCIdentifierRelationshipService.recordVerifiedSkuUpcs(key,ordered,relationshipSource,{completeness:'COMPLETE',exactSkuVerified:true}),storage:{updated:false}};
 return{updated:Boolean(applied?.storage?.updated),reason:target?'CATALOG_AND_IDENTITY_RECONCILED':'IDENTITY_ONLY',target,upcs:ordered,applied};
}

async function persistVerifiedAceNetCatalogToLocalLibrary(sku,catalog,{source='ACENET_CATALOG',relationshipSource=source}={}){
 const key=normalizeSKU(sku),raw=catalog&&typeof catalog==='object'?catalog:null;
 if(!key||!raw)throw new Error('Verified AceNet catalog data is required for Local Library persistence.');
 if(!normalizeSKU(raw.sku)||normalizeSKU(raw.sku)!==key)throw new Error(`AceNet catalog SKU ${normalizeSKU(raw.sku)||'blank'} does not match requested SKU ${key}.`);
 const ru=await resolveAceNetRetailUnits(key),normalized={...raw,sku:key,retailUnits:String(ru.value||'1')};
 const upcs=[...new Set([normalized.masterUpc,...(Array.isArray(normalized.allUpcs)?normalized.allUpcs:[])].map(normalizeUPC).filter(Boolean))];
 if(!upcs.length)throw new Error(`AceNet catalog for SKU ${key} has no verified UPC selector values.`);
 const evidence=await UPCEffectiveCatalogResolver.inspectSKU(key);if(evidence.master.count>1||evidence.local.count>1)throw new Error(`Catalog refresh for SKU ${key} is ambiguous.`);
 const officialMaster=evidence.master.count===1&&evidence.master.row,local=evidence.local.count===1?evidence.local.row:null;
 diag('local_library_catalog_persist_started',{sku:key,source,relationshipSource,upcCount:upcs.length,masterUpc:normalizeUPC(normalized.masterUpc)||upcs[0],officialMaster:Boolean(officialMaster),localPresent:Boolean(local),retailUnitsSource:ru.source});
 if(officialMaster){
   const applied=await applyCatalogRefreshPolicyToExistingRecord({sku:key,target:'MASTER_LIBRARY',record:evidence.master.row,evidence:{...normalized,masterUpc:normalizeUPC(normalized.masterUpc)||upcs[0],allUpcs:upcs},exactSkuVerified:true,source,relationshipSource,completeUpcSet:true});
   await UPCLocalRepository.removeUpdateQueueSku(key);await UPCIdentifierRelationshipService.removeResearch(key);await UPCIdentifierRelationshipService.setSkuIdentityStatus(key,{catalogStatus:'MASTER_LIBRARY',source});
   diag('catalog_refresh_master_existing_applied',{sku:key,source,changedFields:applied.storage?.changes?.map(x=>x.key)||[],masterUpc:applied.plan.relationship.masterUpc,upcCount:applied.relationships?.upcs?.length||upcs.length});
   return{status:'MASTER_PRESENT',sku:key,staged:{created:false,updated:Boolean(applied.storage?.updated),reason:'official_master_refresh',row:applied.storage?.row||evidence.master.row},upcs,localRow:null,refresh:applied};
 }
 if(local){
   const applied=await applyCatalogRefreshPolicyToExistingRecord({sku:key,target:'LOCAL_LIBRARY',record:local,evidence:{...normalized,masterUpc:normalizeUPC(normalized.masterUpc)||upcs[0],allUpcs:upcs},exactSkuVerified:true,source,relationshipSource,completeUpcSet:true});
   await UPCLocalRepository.removeUpdateQueueSku(key);await UPCIdentifierRelationshipService.removeResearch(key);await UPCIdentifierRelationshipService.setSkuIdentityStatus(key,{catalogStatus:'LOCAL_LIBRARY',source});
   const fresh=await UPCLocalRepository.lookupSKU(key);if(fresh.count!==1||!fresh.row)throw new Error(`Local Library refresh for SKU ${key} could not be verified by read-back.`);
   return{status:'COMPLETED',sku:key,staged:{created:false,updated:Boolean(applied.storage?.updated),reason:'policy_refresh',row:fresh.row},upcs,localRow:fresh.row,relationships:applied.relationships,refresh:applied};
 }
 const gate=UPCCatalogRefreshPolicy.plan({target:'LOCAL_LIBRARY',expectedSku:key,storedRecord:null,evidence:{...normalized,masterUpc:normalizeUPC(normalized.masterUpc)||upcs[0],allUpcs:upcs},exactSkuVerified:true,completeUpcSet:true});
 if(gate.status!=='APPLICABLE')throw new Error(`Catalog Refresh Policy rejected new Local SKU ${key}: ${gate.reason}`);
 const staged=await UPCLocalRepository.stageAceNetItem({...normalized,masterUpc:gate.relationship.masterUpc||normalized.masterUpc,allUpcs:gate.relationship.upcs});
 if(!staged?.created&&!staged?.updated)throw new Error(`Local Library persistence blocked for SKU ${key}: ${staged?.reason||'unknown'}`);
 const merged=await UPCIdentifierRelationshipService.recordVerifiedSkuUpcs(key,gate.relationship.upcs,relationshipSource,{completeness:'COMPLETE',exactSkuVerified:true});
 await UPCIdentifierRelationshipService.setSkuIdentityStatus(key,{catalogStatus:'LOCAL_LIBRARY',source});await UPCLocalRepository.removeUpdateQueueSku(key);await UPCIdentifierRelationshipService.removeResearch(key);
 const localRead=await UPCLocalRepository.lookupSKU(key);if(localRead.count!==1||!localRead.row)throw new Error(`Local Library persistence for SKU ${key} could not be verified by read-back.`);
 const readBackUpc=normalizeUPC(localRead.row.upcKey||localRead.row.originalUPC);if(!readBackUpc||readBackUpc!==gate.relationship.masterUpc)throw new Error(`Local Library read-back for SKU ${key} did not preserve the verified master UPC.`);
 diag('local_library_catalog_persist_verified',{sku:key,source,created:Boolean(staged.created),updated:Boolean(staged.updated),localRecordId:localRead.row.id??null,masterUpc:readBackUpc,upcCount:merged.upcs?.length||upcs.length,conflictCount:merged.conflictCount??0});
 return{status:'COMPLETED',sku:key,staged,upcs:gate.relationship.upcs,localRow:localRead.row,relationships:merged};
}

  return Object.freeze({applyCatalogRefreshPolicyToExistingRecord,reconcileVerifiedUpcSetWithCatalog,persistVerifiedAceNetCatalogToLocalLibrary});
 }
 return Object.freeze({create});
})();
window.UPCCatalogRefreshService=UPCCatalogRefreshService;
