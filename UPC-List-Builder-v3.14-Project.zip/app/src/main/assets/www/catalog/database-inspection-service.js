/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/catalog/database-inspection-service.js
 * Owner: Catalog/Identity Inspection
 * Role: Read-only inspection service
 * Responsibility: Owns cross-domain Database Viewer dataset composition and provenance/status annotation through repository reads.
 * Does not own: UI rendering, persistence mutation, repair execution, or raw database mechanics.
 * Side effects: Reads approved repository/service data only.
 * Related code: Admin presentation belongs to application/admin-database-controller.js; mutations belong to maintenance/relationship owners.
 */
const UPCDatabaseInspectionService=(()=>{
 const normalizeSKU=UPCIdentifierNormalization.normalizeSKU;
 function annotateLocalRecords(meta,activeRows,localRows){
  const official=Array.isArray(activeRows)?activeRows:[],locals=Array.isArray(localRows)?localRows:[],skuHeader=meta?.skuHeader||'';
  const sameIdentity=(a,b)=>{
   const au=String(a?.upcKey||''),bu=String(b?.upcKey||''),as=normalizeSKU(a?.skuKey||a?.fields?.[skuHeader]),bs=normalizeSKU(b?.skuKey||b?.fields?.[skuHeader]);
   return Boolean((au&&bu&&au===bu)||(as&&bs&&as===bs));
  };
  return locals.map(row=>{
   const suppressedBy=official.find(master=>sameIdentity(master,row));
   return {...row,localLibraryState:suppressedBy?'SUPPRESSED_BY_MASTER':'ACTIVE',suppressedByMaster:suppressedBy?{id:suppressedBy.id??null,upcKey:suppressedBy.upcKey||null,skuKey:suppressedBy.skuKey||null}:null};
  });
 }
 async function snapshot(){
  const [meta,masterLibrary,localRows,skuUpcs,skuIdentity,upcIdentityResolution,libraryUpdateQueue,identityResearchQueue,deferredAceNetRefreshQueue]=await Promise.all([
   UPCMasterRepository.getMetadata(),
   UPCMasterRepository.getActiveRecords(),
   UPCLocalRepository.getRecords(),
   UPCIdentityRepository.listSkuUpcs(),
   UPCIdentityRepository.listSkuIdentity(),
   UPCIdentityRepository.listUpcResolutions(),
   UPCLocalRepository.getUpdateQueue(),
   UPCIdentityRepository.getResearchQueue(),
   UPCIdentityRepository.getDeferredRefreshQueue()
  ]);
  const localLibrary=annotateLocalRecords(meta,masterLibrary,localRows),skuConflicts=upcIdentityResolution.filter(x=>x.status==='UNRESOLVED_CONFLICT'),localOriginCounts={aceDerived:localLibrary.filter(x=>String(x.localOrigin||'ACE_DERIVED')!=='THIRD_PARTY_VENDOR').length,thirdPartyVendor:localLibrary.filter(x=>String(x.localOrigin||'')==='THIRD_PARTY_VENDOR').length};
  return{masterLibrary,localLibrary,skuUpcs,skuIdentity,upcIdentityResolution,libraryUpdateQueue,identityResearchQueue,deferredAceNetRefreshQueue,skuConflicts,localOriginCounts};
 }
 return Object.freeze({annotateLocalRecords,snapshot});
})();
window.UPCDatabaseInspectionService=UPCDatabaseInspectionService;
