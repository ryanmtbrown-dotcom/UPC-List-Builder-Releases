/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/catalog/master-library-controller.js
 * Owner: Master Library Presentation
 * Role: Controller
 * Responsibility: Owns Master Library screen binding, status/progress presentation, and navigation-facing UI coordination.
 * Does not own: Import/export transformation, raw persistence, catalog refresh policy, or lookup.
 * Side effects: Mutates Master Library DOM and calls injected workflow/navigation owners.
 * Related code: Library workflow mechanics belong to ../library-workflow-v093.js.
 */
const UPCMasterLibraryController=(()=>{
 function create({elementById,masterRepository,diagnostic,showScreen,navigationProvider,workflowProvider,goBack,documentRef}={}){
  if(typeof elementById!=='function'||!masterRepository||typeof diagnostic!=='function'||typeof showScreen!=='function')throw new Error('Master Library Controller dependencies are incomplete.');
  const $=elementById,diag=diagnostic;
  function formatBytes(n){if(!Number.isFinite(Number(n))||Number(n)<=0)return '—';const units=['B','KB','MB','GB'];let value=Number(n),i=0;while(value>=1024&&i<units.length-1){value/=1024;i++}return `${value.toFixed(i?1:0)} ${units[i]}`}
  function formatDate(value){if(!value)return '—';try{return new Intl.DateTimeFormat(undefined,{year:'numeric',month:'short',day:'numeric',hour:'numeric',minute:'2-digit'}).format(new Date(value))}catch{return String(value)}}
  function progress(stage,pct,detail=''){const stageEl=$('progressStage'),detailEl=$('progressDetail'),bar=$('progressBar');if(stageEl)stageEl.textContent=stage;if(detailEl)detailEl.textContent=detail;if(bar)bar.value=Math.max(0,Math.min(100,pct));diag('import_progress',{stage,pct,detail})}
  async function refreshStatus(){
   const meta=await masterRepository.getMetadata(),loaded=!!meta?.generation;
   const status=$('libraryStatus');if(status)status.textContent=loaded?`${Number(meta.recordCount||0).toLocaleString()} records · ${meta.fileName||'Library'}`:'No library imported';
   const pairs={
    homeLibraryRecords:loaded?Number(meta.recordCount||0).toLocaleString():'—',homeLibraryDate:loaded?formatDate(meta.importedAt):'—',
    homeLibraryFile:loaded?(meta.fileName||'Imported library'):'Import a master XLSX to enable item matching.',homeLibraryFileMenu:loaded?(meta.fileName||'Imported library'):'',
    homeLibrarySize:loaded?`${formatBytes(meta.fileSize)} · XLSX`:'—',libraryDetailFile:loaded?(meta.fileName||'Imported library'):'No library imported',
    libraryDetailRecords:loaded?Number(meta.recordCount||0).toLocaleString():'—',libraryDetailDate:loaded?formatDate(meta.importedAt):'—',
    libraryDetailSize:loaded?formatBytes(meta.fileSize):'—',libraryDetailUPC:loaded?(meta.upcHeader||'UPC'):'—'
   };
   for(const [id,val] of Object.entries(pairs)){const el=$(id);if(el)el.textContent=val}
   for(const id of ['homeLibraryState','libraryDetailState']){const el=$(id);if(el){el.textContent=loaded?'READY':'NOT LOADED';el.classList.toggle('good',loaded)}}
   return meta;
  }
  async function open(){
   progress('Waiting for file',0,'');diag('master_library_open_requested',{activeScreen:navigationProvider?.()?.currentScreen?.()||null});showScreen('importScreen','Master Library');
   try{await refreshStatus();await workflowProvider?.()?.refreshQueue?.();diag('master_library_open_ready',{deprecatedRuntimeRetired:true})}
   catch(e){diag('master_library_status_refresh_failed',{name:e?.name,message:e?.message,stack:e?.stack});progress('Ready for file',0,'Current library status could not be refreshed. You can still choose an XLSX file.')}
  }
  function bind(){
   const openButton=$('importLibrary');if(openButton)openButton.onclick=()=>void open();
   const back=$('importBack');if(back)back.onclick=()=>goBack('screen_back');
   documentRef?.addEventListener?.('click',e=>{const master=e.target.closest?.('#importLibrary');if(!master)return;e.preventDefault();e.stopPropagation();void open()},true);
  }
  return Object.freeze({bind,open,progress,refreshStatus,formatBytes,formatDate});
 }
 return Object.freeze({create});
})();
window.UPCMasterLibraryController=UPCMasterLibraryController;
