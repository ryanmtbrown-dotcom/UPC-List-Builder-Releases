/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/catalog/retail-units-resolver.js
 * Owner: Retail Units Domain
 * Role: Read-only resolver
 * Responsibility: Owns Master → Local → default Retail Units evidence selection through Effective Catalog.
 * Does not own: Persistence mutation, UI, network, or pricing authority.
 * Side effects: Reads injected catalog resolver and emits diagnostics/operation timing only.
 * Related code: Catalog record selection belongs to Effective Catalog Resolver.
 */
const UPCRetailUnitsResolver=(()=>{
 function create({effectiveResolver,normalizeSku,diagnostic,startOperation,finishOperation}={}){
  if(!effectiveResolver||typeof normalizeSku!=='function'||typeof startOperation!=='function'||typeof finishOperation!=='function')throw new Error('Retail Units Resolver dependencies are incomplete.');
  const diag=typeof diagnostic==='function'?diagnostic:()=>{};
  async function resolveAceNetRetailUnits(returnedSku){
   const key=normalizeSku(returnedSku),id=`RETAIL_UNITS:${Date.now()}:${key}`;startOperation('RETAIL_UNITS',id,'Resolve Retail Units for the resolved SKU.','Retail Units comes from a unique Master Library row first, then the durable Local Library row; if neither provides a value, RU defaults to 1. AceNet is never authoritative for RU.',{sku:key,aceNetRuAuthority:false});
   const extract=row=>{const fields=row?.fields||{},header=Object.keys(fields).find(x=>x.trim().toLowerCase()==='retail units'),raw=header?fields[header]:null,n=Number(String(raw??'').trim());return Number.isInteger(n)&&n>0?String(n):null};
   try{
    const evidence=await effectiveResolver.inspectSKU(key),master=evidence.master,local=evidence.local;
    if(master?.count===1&&master.row){const value=extract(master.row);if(value){finishOperation(id,`Retail Units resolved to ${value} from Master Library.`,'PASS',{sku:key,retailUnits:value,source:'MASTER_LIBRARY',libraryRecordId:master.row.id??null});return{value,source:'MASTER_LIBRARY',libraryRecordId:master.row.id??null}}}
    if(local?.count===1&&local.row){const value=extract(local.row);if(value){finishOperation(id,`Retail Units resolved to ${value} from Local Library.`,'PASS',{sku:key,retailUnits:value,source:'LOCAL_LIBRARY',localRecordId:local.row.id??null});return{value,source:'LOCAL_LIBRARY',localRecordId:local.row.id??null}}}
    finishOperation(id,'No authoritative Retail Units value was available; defaulted to 1.','PASS',{sku:key,retailUnits:'1',source:'DEFAULT_NO_LIBRARY_RU',masterMatchCount:master?.count??0,localMatchCount:local?.count??0});return{value:'1',source:'DEFAULT_NO_LIBRARY_RU'};
   }catch(e){diag('acenet_retail_units_library_lookup_failed',{sku:key,message:e?.message||String(e)});finishOperation(id,'Retail Units lookup failed; safely defaulted to 1.','PASS',{sku:key,retailUnits:'1',source:'DEFAULT_LIBRARY_LOOKUP_FAILED',error:e?.message||String(e)});return{value:'1',source:'DEFAULT_LIBRARY_LOOKUP_FAILED'}}
  }
  return Object.freeze({resolve:resolveAceNetRetailUnits,resolveAceNetRetailUnits});
 }
 return Object.freeze({create});
})();
window.UPCRetailUnitsResolver=UPCRetailUnitsResolver;
