/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/catalog/standard-export-schema.js
 * Owner: Catalog Field Identity
 * Role: Pure schema
 * Responsibility: Owns the ordered 30-column Master Library field set selectable for ordinary exports and the ordered 33-column ACE MISC export header identity.
 * Does not own: Workbook composition, user preference persistence, ACE MISC row/validation semantics, Work Session state, or file delivery.
 * Side effects: None; immutable field identity and selection normalization only.
 * Related code: Ordinary workbook shaping belongs to field-session/field-session-export-service.js; exact ACE MISC formatting belongs to ace-misc.js; selection persistence belongs to application/settings-repository.js.
 */
const UPCStandardExportSchema=(()=>{
 const MASTER_HEADERS=Object.freeze([
  'ACE SKU','RSC','Article Status','Description','MFG #','Order Multiple','Retail Units',
  'Length of OM (Inch)','Width of OM (Inch)','Height of OM (Inch)','Cubic Feet of OM','Weight',
  'RSC Quantity','Expected Arrival Date of Next RSC PO','Retailer Each Cost','Price Strategy',
  'Ace Retail Price','Level 1 Retail Price','Level 2 Retail Price','AH.COM Retail Price','Velocity Code',
  'UPC/EAN','Ace Vendor Number','Commodity Group','Merchandise Class Number','Product Group Number',
  'Product Definition Code','Discovery Item','Last Purchase Date','Country of Origin'
 ]);
 const ACE_MISC_HEADERS=Object.freeze([...MASTER_HEADERS,'POSDEPT','VENDOR','S/O (72) Y']);
 const MASTER_ALLOWED=new Set(MASTER_HEADERS);
 function normalizeMasterSelection(headers){
  const selected=new Set((Array.isArray(headers)?headers:[]).map(value=>String(value??'').trim()).filter(value=>MASTER_ALLOWED.has(value)));
  return MASTER_HEADERS.filter(header=>selected.has(header));
 }
 function defaultMasterSelection(){return [...MASTER_HEADERS]}
 return Object.freeze({MASTER_HEADERS,ACE_MISC_HEADERS,normalizeMasterSelection,defaultMasterSelection});
})();
window.UPCStandardExportSchema=UPCStandardExportSchema;
