/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/combined-master-export.js
 * Owner: Combined Master Export
 * Role: Read-only composition/export service
 * Responsibility: Owns composition of official Master rows plus eligible Local-only rows and workbook export preparation.
 * Does not own: Master/Local mutation; identity repair; AceNet lookup; general file-system implementation.
 * Side effects: Reads approved repository data, builds XLSX bytes, and hands them to approved browser/native delivery.
 * Related code: Catalog authority remains with repositories/resolvers; generic XLSX mechanics belong to xlsx-exporter.js.
 */
const UPCCombinedMasterExport=(()=>{
 'use strict';
 const normSku=UPCIdentifierNormalization.normalizeSKU;
 const normUpc=UPCIdentifierNormalization.normalizeUPCUnicodeCompatible;
 const emit=(event,data)=>{try{if(typeof diag==='function')diag(event,data)}catch{}};
 function requireMetadata(meta){
  if(!meta?.generation)throw new Error('Import a Master Library before exporting Combined Master.');
  const headers=Array.isArray(meta.headers)?meta.headers.filter(h=>String(h??'').trim()!==''):[];
  if(!headers.length)throw new Error('The active Master Library has no preserved workbook headers.');
  if(!meta.skuHeader||!headers.includes(meta.skuHeader))throw new Error('The active Master Library SKU column mapping is unavailable.');
  if(!meta.upcHeader||!headers.includes(meta.upcHeader))throw new Error('The active Master Library UPC column mapping is unavailable.');
  return headers;
 }
 const skuOf=(row,meta)=>normSku(row?.skuKey??row?.fields?.[meta.skuHeader]??'');
 const upcOf=(row,meta)=>normUpc(row?.originalUPC??row?.upcKey??row?.fields?.[meta.upcHeader]??'');
 function valuesFor(row,meta,headers){
  return headers.map(header=>{
   if(header===meta.skuHeader)return row?.fields?.[header]??row?.skuKey??'';
   if(header===meta.upcHeader)return row?.fields?.[header]??row?.originalUPC??row?.upcKey??'';
   return row?.fields?.[header]??'';
  });
 }
 async function compose(){
  const [meta,active,locals]=await Promise.all([UPCMasterRepository.getMetadata(),UPCMasterRepository.getActiveRecords(),UPCLocalRepository.getRecords()]);
  const headers=requireMetadata(meta),activeRows=Array.isArray(active)?active:[],localRows=Array.isArray(locals)?locals:[];
  const official=activeRows,officialSkus=new Set(),officialUpcs=new Set();
  for(const row of official){const sku=skuOf(row,meta),upc=upcOf(row,meta);if(sku)officialSkus.add(sku);if(upc)officialUpcs.add(upc)}
  const localIdentity=localRows.map(row=>{const sku=skuOf(row,meta),upc=upcOf(row,meta);if(!sku||!upc)throw new Error('A Local Library record is missing the mapped SKU or canonical UPC required for Combined Master export.');return{row,sku,upc}});
  const included=[],suppressed=[],seenSkus=new Set(),seenUpcs=new Set();
  for(const {row,sku,upc} of localIdentity){
   if(officialSkus.has(sku)||officialUpcs.has(upc)){suppressed.push({sku,upc,reason:officialSkus.has(sku)?'OFFICIAL_MASTER_SKU':'OFFICIAL_MASTER_UPC'});continue}
   if(seenSkus.has(sku)||seenUpcs.has(upc))throw new Error(`Local Library contains ambiguous duplicate identity for SKU ${sku} / UPC ${upc}.`);
   seenSkus.add(sku);seenUpcs.add(upc);included.push(row);
  }
  const outputRows=[...official,...included];
  return Object.freeze({meta,headers,rows:outputRows.map(row=>valuesFor(row,meta,headers)),stats:Object.freeze({officialRows:official.length,localRows:localRows.length,localRowsIncluded:included.length,localRowsSuppressed:suppressed.length,outputRows:outputRows.length}),suppressed:Object.freeze(suppressed)});
 }
 function suggestedFilename(meta){const raw=String(meta?.fileName||'Master-Library.xlsx').trim(),base=(raw.replace(/\.xlsx$/i,'').trim()||'Master-Library');return `${base}-Combined.xlsx`}
 function ensureFilename(value,meta){const raw=String(value??'').trim()||suggestedFilename(meta),safe=raw.replace(/[\\/:*?"<>|]/g,'-').replace(/\s+/g,' ').trim();return /\.xlsx$/i.test(safe)?safe:`${safe}.xlsx`}
 async function buildWorkbook(composition){const meta=composition.meta,headers=composition.headers,textColumns=[headers.indexOf(meta.upcHeader),headers.indexOf(meta.skuHeader)].filter(x=>x>=0);return await XLSXExporter.build(headers,composition.rows,{sheetName:'Master Library',textColumns:[...new Set(textColumns)],maxColumnWidth:60})}
 async function exportWorkbook(composition,filename,fileDelivery){
  const name=ensureFilename(filename,composition.meta),stats=composition.stats;emit('combined_master_export_started',{fileName:name,...stats,headerCount:composition.headers.length});
  try{
   if(typeof fileDelivery?.deliverBytes!=='function')throw new Error('Combined Master file-delivery boundary is unavailable.');
   const bytes=await buildWorkbook(composition);
   fileDelivery.deliverBytes(bytes,name,XLSXExporter.MIME);
   emit('combined_master_export_completed',{fileName:name,byteCount:bytes.length,...stats,headerCount:composition.headers.length});
   return{name,rowCount:stats.outputRows,byteCount:bytes.length,exported:true,stats};
  }catch(e){emit('combined_master_export_failed',{fileName:name,errorName:e?.name||null,errorMessage:e?.message||String(e),...stats});throw e}
 }
 async function exportInteractive({promptUser,fileDelivery}={}){
  if(typeof promptUser!=='function'||typeof fileDelivery?.deliverBytes!=='function')throw new Error('Combined Master export interaction dependencies are incomplete.');
  const composition=await compose(),suppressedSample=composition.suppressed.slice(0,25);emit('combined_master_export_composed',{...composition.stats,headerCount:composition.headers.length,suppressedSample,suppressedSampleTruncated:composition.suppressed.length>suppressedSample.length});
  const initial=suggestedFilename(composition.meta),chosen=await promptUser('Enter the Combined Master workbook filename. The export is read-only and does not change Master or Local Library data.',initial,'Export Combined Master');
  if(chosen===null)return{cancelled:true,stats:composition.stats};
  return exportWorkbook(composition,chosen,fileDelivery);
 }
 return Object.freeze({compose,buildWorkbook,exportWorkbook,exportInteractive,suggestedFilename});
})();
window.UPCCombinedMasterExport=UPCCombinedMasterExport;
