/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/data-backup.js
 * Owner: Application Data Backup Domain
 * Role: Backup/restore infrastructure service
 * Responsibility: Owns complete application-data snapshot validation, creation, and atomic restore transactions for approved durable stores.
 * Does not own: Backup UI; diagnostics; native file picker/delivery; domain policy changes.
 * Side effects: Direct IndexedDB transaction access is permitted here because complete backup/restore is its infrastructure responsibility.
 * Related code: UI/orchestration belongs to application/data-backup-controller.js; store-specific workflow writes belong to repositories.
 */
const UPCDataBackup=(()=>{
 const FORMAT='UPC_LIST_BUILDER_DATA_BACKUP';
 const BACKUP_FORMAT_VERSION=2;
 const APPLICATION_DATA_SCHEMA_VERSION=2;
 const DATABASE_NAME='upc-list-builder';
 const CORE_STORES=Object.freeze(['lists','library','meta','libraryUpdateQueue','skuUpcs','skuIdentity','upcIdentityResolution','identityResearchQueue','storeAreas','storeModulars','storeSources','storeSourceMembers','storePlacements','storeHistory','storeImportReceipts']);
 const EXCLUDED_STORES=Object.freeze(['diagnostics']);

 function clone(value){return value===undefined?undefined:JSON.parse(JSON.stringify(value))}
 function parseBackup(input){
   if(typeof input==='string'){try{return JSON.parse(input)}catch(e){return{__parseError:e?.message||String(e)}}}
   return input;
 }
 function sameStrings(a,b){return Array.isArray(a)&&a.length===b.length&&a.every((x,i)=>x===b[i])}
 function validateBackup(input,options={}){
   const backup=parseBackup(input),errors=[];
   if(!backup||typeof backup!=='object'||Array.isArray(backup)){errors.push('Backup root must be a JSON object.');return{valid:false,errors,backup:null}}
   if(backup.__parseError){errors.push('Backup JSON could not be parsed.');return{valid:false,errors,backup:null}}
   if(backup.format!==FORMAT)errors.push('Backup format is not recognized.');
   if(backup.backupFormatVersion!==BACKUP_FORMAT_VERSION)errors.push('Backup format version is not supported.');
   if(backup.applicationDataSchemaVersion!==APPLICATION_DATA_SCHEMA_VERSION)errors.push(Number(backup.applicationDataSchemaVersion)<APPLICATION_DATA_SCHEMA_VERSION?'This backup predates location storage. Restore was blocked to prevent erasing current location records.':'Application data schema version is not supported.');
   if(!backup.indexedDb||backup.indexedDb.name!==DATABASE_NAME)errors.push('Backup belongs to a different IndexedDB database.');
   const dbVersion=Number(backup.indexedDb?.version);
   if(!Number.isInteger(dbVersion)||dbVersion<1)errors.push('IndexedDB version is missing or invalid.');
   const maxDbVersion=Number(options.maxIndexedDbVersion);
   if(Number.isInteger(maxDbVersion)&&dbVersion>maxDbVersion)errors.push('Backup was created by a newer IndexedDB schema.');
   const manifest=backup.manifest;
   if(!manifest||typeof manifest!=='object')errors.push('Backup manifest is missing.');
   const manifestStores=Array.isArray(manifest?.stores)?manifest.stores:[];
   const manifestNames=manifestStores.map(x=>x?.name);
   if(!sameStrings(manifestNames,CORE_STORES))errors.push('Backup manifest does not contain the required stores in canonical order.');
   if(manifest?.credentialsIncluded!==false)errors.push('Backup must explicitly exclude credentials.');
   if(manifest?.diagnosticsIncluded!==false)errors.push('Backup must explicitly exclude diagnostics.');
   if(!sameStrings(manifest?.excludedStores,EXCLUDED_STORES))errors.push('Backup excluded-store manifest is invalid.');
   if(!backup.stores||typeof backup.stores!=='object'||Array.isArray(backup.stores))errors.push('Backup store payload is missing.');
   const payloadNames=backup.stores&&typeof backup.stores==='object'?Object.keys(backup.stores):[];
   if(!sameStrings(payloadNames,CORE_STORES))errors.push('Backup store payload does not exactly match the required store set.');
   let total=0;
   for(const name of CORE_STORES){
     const rows=backup.stores?.[name];
     if(!Array.isArray(rows)){errors.push(`Backup store ${name} is not an array.`);continue}
     const entry=manifestStores.find(x=>x?.name===name),count=rows.length;total+=count;
     if(!entry||entry.count!==count)errors.push(`Backup manifest count does not match ${name}.`);
   }
   if(Number.isInteger(manifest?.totalRecords)&&manifest.totalRecords!==total)errors.push('Backup total record count does not match its stores.');
   else if(!Number.isInteger(manifest?.totalRecords))errors.push('Backup total record count is missing or invalid.');
   if(typeof backup.createdAt!=='string'||!Number.isFinite(Date.parse(backup.createdAt)))errors.push('Backup creation timestamp is missing or invalid.');
   if(!backup.release||typeof backup.release.version!=='string'||typeof backup.release.buildId!=='string')errors.push('Backup release identity is missing.');
   return{valid:errors.length===0,errors,backup:errors.length?null:backup,summary:{indexedDbVersion:dbVersion,totalRecords:total,stores:manifestStores.map(x=>({name:x.name,count:x.count}))}};
 }
 function requestResult(request){return new Promise((resolve,reject)=>{request.onsuccess=()=>resolve(request.result);request.onerror=()=>reject(request.error||new Error('IndexedDB request failed.'))})}
 function transactionDone(tx){return new Promise((resolve,reject)=>{tx.oncomplete=()=>resolve();tx.onerror=()=>reject(tx.error||new Error('IndexedDB transaction failed.'));tx.onabort=()=>reject(tx.error||new Error('IndexedDB transaction aborted.'))})}
 async function readCoreStores(db){
   const tx=db.transaction(CORE_STORES,'readonly'),done=transactionDone(tx),stores=Object.fromEntries(CORE_STORES.map(name=>[name,[]]));
   await Promise.all(CORE_STORES.map(async name=>{stores[name]=await requestResult(tx.objectStore(name).getAll())}));
   await done;return stores;
 }
 async function createBackup(options={}){
   const db=options.database||await UPCDB.open();
   if(db.name&&db.name!==DATABASE_NAME)throw new Error('Unexpected IndexedDB database.');
   const stores=await readCoreStores(db),createdAt=new Date().toISOString();
   const storeManifest=CORE_STORES.map(name=>({name,count:stores[name].length}));
   const backup={
     format:FORMAT,
     backupFormatVersion:BACKUP_FORMAT_VERSION,
     applicationDataSchemaVersion:APPLICATION_DATA_SCHEMA_VERSION,
     createdAt,
     release:{version:String(options.appVersion||''),buildId:String(options.buildId||'')},
     indexedDb:{name:DATABASE_NAME,version:Number(db.version||0)},
     manifest:{
       stores:storeManifest,
       totalRecords:storeManifest.reduce((sum,x)=>sum+x.count,0),
       excludedStores:[...EXCLUDED_STORES],
       diagnosticsIncluded:false,
       credentialsIncluded:false
     },
     stores
   };
   const checked=validateBackup(backup,{maxIndexedDbVersion:Number(db.version||0)});
   if(!checked.valid)throw new Error('Generated backup failed validation: '+checked.errors.join(' '));
   return backup;
 }
 async function restoreBackup(input,options={}){
   const db=options.database||await UPCDB.open();
   const checked=validateBackup(input,{maxIndexedDbVersion:Number(db.version||0)});
   if(!checked.valid)throw new Error('Backup validation failed: '+checked.errors.join(' '));
   const backup=checked.backup;
   const tx=db.transaction(CORE_STORES,'readwrite'),done=transactionDone(tx);
   try{
     for(const name of CORE_STORES){
       const store=tx.objectStore(name);
       store.clear();
       for(const row of backup.stores[name])store.put(clone(row));
     }
   }catch(e){try{tx.abort()}catch{}try{await done}catch{}throw e}
   await done;
   return{restored:true,totalRecords:backup.manifest.totalRecords,stores:backup.manifest.stores.map(x=>({...x})),createdAt:backup.createdAt};
 }
 function filename(appVersion,createdAt=new Date().toISOString()){
   const stamp=String(createdAt).replace(/[:.]/g,'-');
   return`UPC_List_Builder_Data_Backup_v${String(appVersion||'unknown')}_${stamp}.json`;
 }
 return Object.freeze({
   FORMAT,BACKUP_FORMAT_VERSION,APPLICATION_DATA_SCHEMA_VERSION,DATABASE_NAME,CORE_STORES,EXCLUDED_STORES,
   createBackup,validateBackup,restoreBackup,filename
 });
})();
window.UPCDataBackup=UPCDataBackup;
