/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/db.js
 * Owner: Web Persistence Infrastructure
 * Role: Raw IndexedDB adapter
 * Responsibility: Owns database opening/schema, low-level store primitives, indexes, and explicitly retained physical persistence mechanics.
 * Does not own: UI/workflow orchestration; Master-vs-Local selection; Database Viewer composition; business policy.
 * Side effects: Direct IndexedDB reads/writes and transactions.
 * Related code: Feature code must use repository/service owners; new cross-domain behavior does not belong here.
 */
const UPCDB=(()=>{
 const DB='upc-list-builder',VER=9;
 const normalizeSKU=UPCIdentifierNormalization.normalizeSKU,normalizeUPC=UPCIdentifierNormalization.normalizeUPC,normalizeImportedUPC=UPCIdentifierNormalization.normalizeUPCUnicodeCompatible;
 const {normalizeAceNetWeight,findHeader,normalizeLocalClassificationCode,LOCAL_LIBRARY_FIELD_ALIASES}=UPCCatalogMappers;
 function open(){return new Promise((res,rej)=>{const r=indexedDB.open(DB,VER);r.onupgradeneeded=()=>{const d=r.result;
   if(!d.objectStoreNames.contains('lists'))d.createObjectStore('lists',{keyPath:'id'});
   if(!d.objectStoreNames.contains('library')){const s=d.createObjectStore('library',{keyPath:'id',autoIncrement:true});s.createIndex('upcKey','upcKey',{unique:false});s.createIndex('generationUPC',['generation','upcKey'],{unique:false});s.createIndex('generationSKU',['generation','skuKey'],{unique:false})}else{const s=r.transaction.objectStore('library');if(!s.indexNames.contains('generationUPC'))s.createIndex('generationUPC',['generation','upcKey'],{unique:false});if(!s.indexNames.contains('generationSKU'))s.createIndex('generationSKU',['generation','skuKey'],{unique:false})}
   if(!d.objectStoreNames.contains('meta'))d.createObjectStore('meta',{keyPath:'key'});
   if(!d.objectStoreNames.contains('diagnostics'))d.createObjectStore('diagnostics',{keyPath:'id',autoIncrement:true});
   if(!d.objectStoreNames.contains('libraryUpdateQueue')){const s=d.createObjectStore('libraryUpdateQueue',{keyPath:'skuKey'});s.createIndex('status','status',{unique:false});s.createIndex('detectedAt','detectedAt',{unique:false})}
   if(!d.objectStoreNames.contains('skuUpcs')){const s=d.createObjectStore('skuUpcs',{keyPath:['skuKey','upcKey']});s.createIndex('skuKey','skuKey',{unique:false});s.createIndex('upcKey','upcKey',{unique:false})}
   if(!d.objectStoreNames.contains('skuIdentity')){const s=d.createObjectStore('skuIdentity',{keyPath:'skuKey'});s.createIndex('catalogStatus','catalogStatus',{unique:false});s.createIndex('replacementStatus','replacementStatus',{unique:false});s.createIndex('replacementSkuKey','replacementSkuKey',{unique:false})}
   if(!d.objectStoreNames.contains('upcIdentityResolution')){const s=d.createObjectStore('upcIdentityResolution',{keyPath:'upcKey'});s.createIndex('status','status',{unique:false});s.createIndex('preferredSkuKey','preferredSkuKey',{unique:false})}
   if(!d.objectStoreNames.contains('identityResearchQueue')){const s=d.createObjectStore('identityResearchQueue',{keyPath:'skuKey'});s.createIndex('status','status',{unique:false});s.createIndex('detectedAt','detectedAt',{unique:false})}
   // Build 1 location stores. Append-only upgrade from schema 8; preserve every existing record.
   if(!d.objectStoreNames.contains('storeAreas')){const s=d.createObjectStore('storeAreas',{keyPath:'id'});s.createIndex('byNormalizedName','normalizedName',{unique:false})}
   if(!d.objectStoreNames.contains('storeModulars')){const s=d.createObjectStore('storeModulars',{keyPath:'id'});s.createIndex('byAreaId','areaId',{unique:false})}
   if(!d.objectStoreNames.contains('storeSources')){const s=d.createObjectStore('storeSources',{keyPath:'id'});s.createIndex('byModular','modularId',{unique:false})}
   if(!d.objectStoreNames.contains('storeSourceMembers')){const s=d.createObjectStore('storeSourceMembers',{keyPath:['sourceId','skuKey']});s.createIndex('bySku','skuKey',{unique:false});s.createIndex('byUpc','upcKey',{unique:false});s.createIndex('bySource','sourceId',{unique:false})}
   if(!d.objectStoreNames.contains('storePlacements')){const s=d.createObjectStore('storePlacements',{keyPath:'id'});s.createIndex('bySku','skuKey',{unique:false});s.createIndex('byUpc','upcKey',{unique:false});s.createIndex('byModular','modularId',{unique:false})}
   if(!d.objectStoreNames.contains('storeHistory')){const s=d.createObjectStore('storeHistory',{keyPath:['skuKey','kind','contextId']});s.createIndex('bySku','skuKey',{unique:false})}
   if(!d.objectStoreNames.contains('storeImportReceipts'))d.createObjectStore('storeImportReceipts',{keyPath:'batchId'});
 };r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)})}
 async function tx(store,mode,fn){const d=await open();return new Promise((res,rej)=>{const t=d.transaction(store,mode),s=t.objectStore(store);let out;try{out=fn(s,t)}catch(e){rej(e);return}t.oncomplete=()=>res(out);t.onerror=()=>rej(t.error);t.onabort=()=>rej(t.error)})}
 async function put(store,v){return tx(store,'readwrite',s=>s.put(v))}
 async function get(store,k){const d=await open();return new Promise((res,rej)=>{const r=d.transaction(store).objectStore(store).get(k);r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)})}
 async function all(store){const d=await open();return new Promise((res,rej)=>{const r=d.transaction(store).objectStore(store).getAll();r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)})}
 async function clear(store){return tx(store,'readwrite',s=>s.clear())}
 async function remove(store,k){return tx(store,'readwrite',s=>s.delete(k))}
 async function lookupUniqueExact(key){const meta=await get('meta','library');if(!meta?.generation)return{row:null,count:0,mode:'EXACT'};const d=await open();return new Promise((res,rej)=>{const r=d.transaction('library').objectStore('library').index('generationUPC').getAll(IDBKeyRange.only([meta.generation,key]),2);r.onsuccess=()=>res({row:r.result.length===1?r.result[0]:null,count:r.result.length,mode:'EXACT'});r.onerror=()=>rej(r.error)})}
 async function lookupUniquePrefix(prefix){const meta=await get('meta','library');if(!meta?.generation)return{row:null,count:0,mode:'PREFIX_11'};const d=await open();return new Promise((res,rej)=>{const index=d.transaction('library').objectStore('library').index('generationUPC'),range=IDBKeyRange.bound([meta.generation,prefix],[meta.generation,prefix+'\uffff']),rows=[];const q=index.openCursor(range);q.onsuccess=()=>{const c=q.result;if(!c)return res({row:rows.length===1?rows[0]:null,count:rows.length,mode:'PREFIX_11'});if(String(c.value.upcKey||'').startsWith(prefix)){rows.push(c.value);if(rows.length>=2)return res({row:null,count:2,mode:'PREFIX_11'})}c.continue()};q.onerror=()=>rej(q.error)})}

 async function lookupUniqueSKU(key){const meta=await get('meta','library');if(!meta?.generation)return{row:null,count:0,mode:'SKU_EXACT'};const wanted=normalizeSKU(key);if(!wanted)return{row:null,count:0,mode:'SKU_EXACT'};const db=await open(),indexed=await new Promise((res,rej)=>{const r=db.transaction('library').objectStore('library').index('generationSKU').getAll(IDBKeyRange.only([meta.generation,wanted]),2);r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)});return{row:indexed.length===1?indexed[0]:null,count:indexed.length,mode:'SKU_EXACT'}}
 async function getActiveLibraryRecords(){const meta=await get('meta','library');if(!meta?.generation)return[];const db=await open();return new Promise((res,rej)=>{const rows=[],q=db.transaction('library').objectStore('library').openCursor();q.onsuccess=()=>{const c=q.result;if(!c)return res(rows);if(c.value.generation===meta.generation)rows.push(c.value);c.continue()};q.onerror=()=>rej(q.error)})}
 async function deleteActiveLibraryRows(recordIds,expectedGeneration){
   const ids=[...new Set((Array.isArray(recordIds)?recordIds:[]).filter(id=>id!==null&&id!==undefined))];if(!ids.length)return{deleted:0,recordIds:[]};
   const meta=await get('meta','library');if(!meta?.generation)throw new Error('No active Master Library.');
   const generation=String(expectedGeneration||meta.generation);if(generation!==String(meta.generation))throw new Error('Active Master generation changed before retirement.');
   const db=await open();return new Promise((res,rej)=>{const t=db.transaction('library','readwrite'),store=t.objectStore('library');let pending=ids.length,deleted=0,failed=false;
     const done=()=>{pending--;if(pending===0&&!failed)res({deleted,recordIds:ids})};
     for(const id of ids){const req=store.get(id);req.onerror=()=>{if(failed)return;failed=true;try{t.abort()}catch{};rej(req.error||new Error('Master retirement row read failed.'))};req.onsuccess=()=>{if(failed)return;const row=req.result;if(!row||String(row.generation)!==generation){failed=true;try{t.abort()}catch{};rej(new Error('Master retirement row no longer belongs to the active generation.'));return}const del=store.delete(id);del.onerror=()=>{if(failed)return;failed=true;try{t.abort()}catch{};rej(del.error||new Error('Master retirement row delete failed.'))};del.onsuccess=()=>{deleted++;done()}}}
     t.onerror=()=>{if(!failed)rej(t.error||new Error('Master retirement transaction failed.'))};t.onabort=()=>{if(!failed)rej(t.error||new Error('Master retirement transaction aborted.'))};
   })}
  async function updateActiveLibraryMasterUpc(recordId,expectedSku,masterUpc,{source='ACENET_VERIFIED',verifiedAt=null}={}){
   const meta=await get('meta','library');if(!meta?.generation)throw new Error('No active Master Library.');
   const wantedSku=normalizeSKU(expectedSku),nextUpc=normalizeUPC(masterUpc);if(!wantedSku||!nextUpc)throw new Error('SKU and verified Master UPC are required.');
   const d=await open();return new Promise((res,rej)=>{
    const t=d.transaction('library','readwrite'),s=t.objectStore('library'),r=s.get(recordId);let updated=null,abortError=null,change=null;
    const abort=(message,guard={})=>{abortError=new Error(message);abortError.libraryGuard=guard;try{t.abort()}catch{}};
    r.onsuccess=()=>{
     const row=r.result,rowPresent=Boolean(row),generationMatches=Boolean(row&&row.generation===meta.generation),storedSku=normalizeSKU(row?.skuKey||row?.fields?.[meta.skuHeader||'ACE SKU']),skuMatches=Boolean(row&&storedSku===wantedSku);
     if(!rowPresent||!generationMatches||!skuMatches){abort('Resolved Master Library row is not an eligible active Master record for canonical UPC correction.',{requestedRecordId:recordId??null,rowPresent,expectedSku:wantedSku,storedSku:storedSku||null,activeGeneration:meta.generation,storedGeneration:row?.generation??null,generationMatches,skuMatches});return}
     const fields={...(row.fields||{})},upcHeader=meta.upcHeader||findHeader(meta,['UPC/EAN','UPC'])||Object.keys(fields).find(k=>['upc/ean','upc'].includes(k.trim().toLowerCase()));
     if(!upcHeader){abort('Master Library UPC column is not available on the resolved row.');return}
     const priorUpc=normalizeUPC(row.upcKey||row.originalUPC||fields[upcHeader]);
     if(priorUpc===nextUpc){updated=row;change={key:'masterUpc',header:upcHeader,before:priorUpc,after:nextUpc,changed:false};return}
     const q=s.index('generationUPC').getAll(IDBKeyRange.only([meta.generation,nextUpc]),2);
     q.onsuccess=()=>{
      const collision=(q.result||[]).find(x=>x.id!==row.id);
      if(collision){abort('Verified AceNet Master UPC is already assigned to another active Master SKU.',{newMasterUpc:nextUpc,expectedSku:wantedSku,conflictingRecordId:collision.id??null,conflictingSku:normalizeSKU(collision.skuKey||collision?.fields?.[meta.skuHeader||'ACE SKU'])||null});return}
      fields[upcHeader]=nextUpc;const at=String(verifiedAt||new Date().toISOString());
      updated={...row,skuKey:wantedSku,upcKey:nextUpc,originalUPC:nextUpc,fields,aceNetMasterUpcVerifiedAt:at,aceNetMasterUpcSource:String(source||'ACENET_VERIFIED')};
      change={key:'masterUpc',header:upcHeader,before:priorUpc,after:nextUpc,changed:true};s.put(updated);
     };
     q.onerror=()=>abort('Could not verify Master UPC uniqueness before correction.');
    };
    r.onerror=()=>{abortError=r.error||new Error('Master Library row read failed.');try{t.abort()}catch{}};
    t.oncomplete=()=>res({updated:Boolean(change?.changed),row:updated,change});
    t.onerror=()=>rej(t.error||abortError||new Error('Master Library canonical UPC correction failed.'));
    t.onabort=()=>rej(abortError||t.error||new Error('Master Library canonical UPC correction aborted.'));
   });
 }
 async function updateLocalLibraryMasterUpc(sku,masterUpc,{source='ACENET_VERIFIED',verifiedAt=null}={}){
   const key=normalizeSKU(sku),next=normalizeUPC(masterUpc);if(!key||!next)throw new Error('SKU and verified Master UPC are required.');
   const meta=await get('meta','library'),local=await get('meta','localLibraryAdditions')||{key:'localLibraryAdditions',records:[]},records=Array.isArray(local.records)?[...local.records]:[],idx=records.findIndex(r=>normalizeSKU(r?.skuKey||r?.fields?.[meta?.skuHeader||'ACE SKU'])===key);
   if(idx<0)return{updated:false,row:null,reason:'LOCAL_NOT_FOUND'};
   const row={...records[idx],fields:{...(records[idx].fields||{})}},header=meta?.upcHeader||findHeader(meta,['UPC/EAN','UPC'])||Object.keys(row.fields).find(h=>['upc/ean','upc'].includes(h.trim().toLowerCase()));
   if(!header)throw new Error('Local Library UPC column is unavailable.');
   const before=normalizeUPC(row.upcKey||row.originalUPC||row.fields[header]);
   if(before===next)return{updated:false,row,reason:'UNCHANGED',before,after:next};
   const at=String(verifiedAt||new Date().toISOString());row.fields[header]=next;row.upcKey=next;row.originalUPC=next;row.updatedAt=at;row.aceNetMasterUpcVerifiedAt=at;row.aceNetMasterUpcSource=String(source||'ACENET_VERIFIED');records[idx]=row;
   await put('meta',{...local,records,updatedAt:at});return{updated:true,row,reason:'UPDATED',before,after:next};
 }

 async function enqueueLibrarySku(candidate={}){
   const skuKey=normalizeSKU(candidate?.sku);if(!skuKey)throw new Error('SKU is required for Add to Local Library.');
   const existing=await get('libraryUpdateQueue',skuKey),now=new Date().toISOString(),sources=[...new Set([...(existing?.sources||[]),String(candidate?.source||existing?.source||'ADD_TO_LIBRARY')].filter(Boolean))];
   const row={...(existing||{}),skuKey,sku:String(candidate.sku),recordId:candidate.recordId??existing?.recordId??null,
     libraryState:String(candidate.libraryState||existing?.libraryState||'NOT_FOUND').toUpperCase(),
     libraryPrice:candidate.libraryPrice??existing?.libraryPrice??null,aceNetPrice:candidate.aceNetPrice??existing?.aceNetPrice??null,
     detectedAt:existing?.detectedAt||now,lastQueuedAt:now,status:'PENDING',queueReason:String(candidate.queueReason||existing?.queueReason||'ADD_TO_LIBRARY'),
     attempts:Number(existing?.attempts||0),lastError:existing?.lastError??null,source:sources[0],sources};
   await put('libraryUpdateQueue',row);return{queued:true,reason:row.queueReason,row};
 }
 async function enqueueLibraryUpdate(candidate){
   const skuKey=normalizeSKU(candidate?.sku);if(!skuKey)throw new Error('SKU is required for Library Update Queue.');
   const aceNetPrice=Number(candidate?.aceNetPrice);
   if(!Number.isFinite(aceNetPrice)||aceNetPrice<=0)throw new Error('Verified AceNet retail price is required.');
   const libraryState=String(candidate?.libraryState||'FOUND').toUpperCase();
   if(libraryState==='AMBIGUOUS')return{queued:false,reason:'AMBIGUOUS_LIBRARY_SKU'};
   const rawLibraryPrice=candidate?.libraryPrice,libraryPrice=rawLibraryPrice==null||rawLibraryPrice===''?null:Number(rawLibraryPrice);
   if(libraryState==='FOUND'&&Number.isFinite(libraryPrice)&&libraryPrice>0&&Math.abs(aceNetPrice-libraryPrice)<0.005)return{queued:false,reason:'PRICE_MATCH'};
   const queueReason=libraryState==='NOT_FOUND'?'SKU_NOT_IN_LIBRARY':(!Number.isFinite(libraryPrice)||libraryPrice<=0?'LIBRARY_PRICE_UNAVAILABLE':'PRICE_DIFFERENT');
   return enqueueLibrarySku({...candidate,sku:skuKey,libraryState,libraryPrice:Number.isFinite(libraryPrice)&&libraryPrice>0?libraryPrice.toFixed(2):null,aceNetPrice:aceNetPrice.toFixed(2),queueReason,source:candidate?.source||'ACENET_PRICE_VERIFIED'});
 }
 async function getLibraryUpdateQueue(){return (await all('libraryUpdateQueue')).sort((a,b)=>String(a.detectedAt||'').localeCompare(String(b.detectedAt||'')))}
 async function clearLibraryUpdateQueue(){return clear('libraryUpdateQueue')}
 async function removeLibraryUpdateQueueSku(sku){const skuKey=normalizeSKU(sku);if(skuKey)await remove('libraryUpdateQueue',skuKey)}



 async function stageLocalLibraryAceNetItem(catalog){
   const meta=await get('meta','library');if(!meta?.generation)throw new Error('Import a Master Library before staging Local Library records.');
   const c=catalog&&typeof catalog==='object'?catalog:{},sku=normalizeSKU(c.sku),masterUpc=normalizeUPC(c.masterUpc);
   if(!sku)throw new Error('AceNet SKU is required for Local Library staging.');
   if(!masterUpc)throw new Error('AceNet master UPC is required for Local Library staging.');
   const local=await get('meta','localLibraryAdditions')||{key:'localLibraryAdditions',records:[]},records=Array.isArray(local.records)?[...local.records]:[];
   const existingLocalIndex=records.findIndex(x=>normalizeSKU(x?.skuKey||x?.fields?.[meta.skuHeader||'ACE SKU'])===sku);
   const current=await lookupUniqueSKU(sku);
   if(current.count>1)return{created:false,updated:false,reason:'sku_ambiguous',row:null,count:current.count};
   if(current.count===1&&existingLocalIndex<0)return{created:false,updated:false,reason:'sku_exists',row:current.row||null,count:1,officialMasterProtected:true};
   const aliases={sku:['ACE SKU','SKU'],upc:['UPC/EAN','UPC'],description:['Description','Article Description'],retailerEachCost:['Retailer Each Cost','Cost'],manufacturerNumber:['MFG #','Manufacturer Number','MFG Number'],orderMultiple:['Order Multiple'],omWeight:['Weight','OM Weight'],aceRetailPrice:['Ace Retail Price','Retailer Each Price','Price'],level2RetailPrice:['Level 2 Retail Price'],retailUnits:['Retail Units'],commodityGroup:['Commodity Group'],merchandiseClassNumber:['Merchandise Class Number','Merchant Class','Merchandise Class'],productGroupNumber:['Product Group Number']};
   const resolved={sku:meta.skuHeader||findHeader(meta,aliases.sku),upc:meta.upcHeader||findHeader(meta,aliases.upc)};for(const [key,names] of Object.entries(aliases))if(!resolved[key])resolved[key]=findHeader(meta,names);
   const required=['sku','upc','description','retailerEachCost','manufacturerNumber','orderMultiple','aceRetailPrice','commodityGroup','merchandiseClassNumber','productGroupNumber'],missingHeaders=required.filter(k=>!resolved[k]);if(missingHeaders.length)throw new Error('Master Library is missing required Local Library columns: '+missingHeaders.join(', '));
   const money=v=>{const raw=String(v??'').trim();if(!raw||/-\s*\$?\s*\d/.test(raw))return'';const m=raw.replace(/,/g,'').match(/(?:^|[^\d])\$?\s*(\d+(?:\.\d+)?|\.\d+)(?=$|[^\d])/);if(!m)return'';const n=Number(m[1]);return Number.isFinite(n)&&n>=0?n.toFixed(2):''},clean=v=>String(v??'').trim();
   const values={sku:clean(c.sku),upc:masterUpc,description:clean(c.description),retailerEachCost:money(c.retailerEachCost),manufacturerNumber:clean(c.manufacturerNumber),orderMultiple:clean(c.orderMultiple),omWeight:normalizeAceNetWeight(c.omWeight),aceRetailPrice:money(c.aceRetailPrice),level2RetailPrice:money(c.level2RetailPrice),retailUnits:clean(c.retailUnits)||'1',commodityGroup:normalizeLocalClassificationCode(c.commodityGroup),merchandiseClassNumber:normalizeLocalClassificationCode(c.merchandiseClassNumber),productGroupNumber:normalizeLocalClassificationCode(c.productGroupNumber)};
   const missingValues=required.filter(k=>!values[k]);if(missingValues.length)throw new Error('AceNet catalog result is missing required Local Library values: '+missingValues.join(', '));
   const fields={};for(const [key,header] of Object.entries(resolved))if(header&&values[key]!==undefined)fields[header]=values[key];
   const now=new Date().toISOString(),entry={id:existingLocalIndex>=0?(records[existingLocalIndex].id||crypto.randomUUID()):crypto.randomUUID(),upcKey:masterUpc,skuKey:sku,originalUPC:masterUpc,fields,source:'LOCAL_ADDITION',localOrigin:'ACE_DERIVED',savedAt:records[existingLocalIndex]?.savedAt||now,updatedAt:now,aceNetVerification:{status:'COMPLETE',missingFields:[],verifiedAt:now}};
   if(existingLocalIndex>=0){
     const prior=records[existingLocalIndex]||{},userCorrections={...(prior.userCorrections||{})};
     for(const [canonical,correction] of Object.entries(userCorrections)){const aliasesForField=LOCAL_LIBRARY_FIELD_ALIASES?.[canonical]||[];const header=Object.keys(entry.fields).find(h=>aliasesForField.some(a=>h.trim().toLowerCase()===a.toLowerCase()));if(header&&correction?.value!==undefined)entry.fields[header]=correction.value}
     entry.userCorrections=userCorrections;entry.correctionHistory=prior.correctionHistory||[];records[existingLocalIndex]=entry;
   }else records.push(entry);
   await put('meta',{...local,records,updatedAt:now});
   return{created:existingLocalIndex<0,updated:existingLocalIndex>=0,reason:existingLocalIndex<0?'staged':'updated',row:entry,count:1,resolvedHeaders:resolved,masterPresent:current.count===1};
 }
 function normalizeLocalCorrectionValue(key,value){
   const raw=String(value??'').trim();
   if(['retailerEachCost','aceRetailPrice','level2RetailPrice'].includes(key)){const m=raw.replace(/[$,\s]/g,'').match(/^-?\d+(?:\.\d+)?$/);if(!m||Number(m[0])<0)throw new Error('Enter a valid nonnegative monetary value.');return Number(m[0]).toFixed(2)}
   if(key==='omWeight'){const v=normalizeAceNetWeight(raw);if(v==='')throw new Error('Enter a numeric weight.');return v}
   if(['orderMultiple','retailUnits'].includes(key)){const n=Number(raw);if(!Number.isInteger(n)||n<=0)throw new Error('Enter a positive whole number.');return String(n)}
   if(['commodityGroup','merchandiseClassNumber','productGroupNumber'].includes(key)){const code=normalizeLocalClassificationCode(raw);if(!code)throw new Error('Enter a numeric code.');return code}
   if(!raw)throw new Error('Value cannot be blank.');return raw;
 }
 async function stageLocalLibraryThirdPartyItem(candidate={}){
   const meta=await get('meta','library');if(!meta?.generation)throw new Error('Import a Master Library before adding third-party Local Library records.');
   const sku=normalizeSKU(candidate.sku),upc=normalizeUPC(candidate.upc),description=String(candidate.description||'').trim(),rawPrice=String(candidate.vendorPrice??candidate.price??'').replace(/[$,\s]/g,''),price=Number(rawPrice);
   if(!sku||!upc||!description||!Number.isFinite(price)||price<0)throw new Error('Third-party Local Library items require SKU, UPC, description, and a valid nonnegative vendor price.');
   const [officialSku,officialUpc]=await Promise.all([lookupUniqueSKU(sku),lookupUniqueExact(upc)]);
   if(officialSku.count>0)throw new Error('This SKU is now assigned by the official Master Library and cannot be owned by a third-party Local record.');
   if(officialUpc.count>0)throw new Error('This UPC is now assigned by the official Master Library and cannot be owned by a third-party Local record.');
   const local=await get('meta','localLibraryAdditions')||{key:'localLibraryAdditions',records:[]},records=Array.isArray(local.records)?[...local.records]:[],skuHeader=meta.skuHeader||findHeader(meta,['ACE SKU','SKU']),upcHeader=meta.upcHeader||findHeader(meta,['UPC/EAN','UPC']),descriptionHeader=findHeader(meta,['Description','Article Description']),priceHeader=findHeader(meta,['Ace Retail Price','Retailer Each Price','Price']);
   if(!skuHeader||!upcHeader||!descriptionHeader||!priceHeader)throw new Error('Master Library mapping does not expose the fields required for a third-party Local record.');
   const existingIndex=records.findIndex(r=>normalizeSKU(r?.skuKey||r?.fields?.[skuHeader])===sku),existing=existingIndex>=0?records[existingIndex]:null;
   if(existing&&String(existing.localOrigin||'ACE_DERIVED')!=='THIRD_PARTY_VENDOR')throw new Error('This SKU already exists as an Ace-derived Local Library record.');
   const now=new Date().toISOString(),fields={...(existing?.fields||{})};fields[skuHeader]=String(candidate.sku).trim();fields[upcHeader]=upc;fields[descriptionHeader]=description;fields[priceHeader]=price.toFixed(2);
   const row={...(existing||{}),id:existing?.id||crypto.randomUUID(),skuKey:sku,upcKey:upc,originalUPC:upc,fields,source:'LOCAL_ADDITION',localOrigin:'THIRD_PARTY_VENDOR',vendorName:String(candidate.vendorName||existing?.vendorName||'').trim(),savedAt:existing?.savedAt||now,updatedAt:now,aceNetVerification:{status:'NOT_APPLICABLE',missingFields:[],verifiedAt:null}};
   if(existingIndex>=0)records[existingIndex]=row;else records.push(row);
   await put('meta',{...local,records,updatedAt:now});return{created:existingIndex<0,updated:existingIndex>=0,row};
 }

 async function getLocalLibraryRecordBySku(sku){
   const key=normalizeSKU(sku),[meta,local]=await Promise.all([get('meta','library'),get('meta','localLibraryAdditions')]),rows=Array.isArray(local?.records)?local.records:[],skuHeader=meta?.skuHeader||'ACE SKU';
   return rows.find(r=>normalizeSKU(r?.skuKey||r?.fields?.[skuHeader])===key)||null;
 }
 async function correctLocalLibraryFields(sku,changes,{source='USER_CORRECTION',preserveUser=true}={}){
   const key=normalizeSKU(sku);if(!key)throw new Error('SKU is required.');
   const meta=await get('meta','library'),local=await get('meta','localLibraryAdditions')||{key:'localLibraryAdditions',records:[]},records=Array.isArray(local.records)?[...local.records]:[];
   const idx=records.findIndex(r=>normalizeSKU(r?.skuKey||r?.fields?.[meta?.skuHeader||'ACE SKU'])===key);if(idx<0)throw new Error(`Local Library SKU ${sku} was not found.`);
   const row={...records[idx],fields:{...(records[idx].fields||{})}},now=new Date().toISOString(),userCorrections={...(row.userCorrections||{})},history=Array.isArray(row.correctionHistory)?[...row.correctionHistory]:[],applied=[];
   for(const [canonical,value] of Object.entries(changes||{})){
     const aliases=LOCAL_LIBRARY_FIELD_ALIASES[canonical];if(!aliases)continue;
     if(source!=='USER_CORRECTION'&&preserveUser&&userCorrections[canonical])continue;
     const header=findHeader(meta,aliases)||Object.keys(row.fields).find(h=>aliases.some(a=>h.trim().toLowerCase()===a.toLowerCase()));if(!header)continue;
     const next=normalizeLocalCorrectionValue(canonical,value),before=row.fields[header]??'';if(String(before)===String(next))continue;
     row.fields[header]=next;applied.push({canonical,header,before,after:next,source,at:now});
     if(source==='USER_CORRECTION')userCorrections[canonical]={value:next,correctedAt:now};
   }
   if(!applied.length)return{updated:false,row,applied:[]};
   row.userCorrections=userCorrections;row.correctionHistory=[...history,...applied].slice(-100);row.correctedAt=now;row.correctedBy=source;records[idx]=row;
   await put('meta',{...local,records,updatedAt:now});return{updated:true,row,applied};
 }
 async function clearLocalLibraryAceNetFields(sku,canonicals=[]){
   const key=normalizeSKU(sku);if(!key)throw new Error('SKU is required.');
   const meta=await get('meta','library'),local=await get('meta','localLibraryAdditions')||{key:'localLibraryAdditions',records:[]},records=Array.isArray(local.records)?[...local.records]:[];
   const idx=records.findIndex(r=>normalizeSKU(r?.skuKey||r?.fields?.[meta?.skuHeader||'ACE SKU'])===key);if(idx<0)return{updated:false,row:null,cleared:[]};
   const row={...records[idx],fields:{...(records[idx].fields||{})}},userCorrections={...(row.userCorrections||{})},history=Array.isArray(row.correctionHistory)?[...row.correctionHistory]:[],now=new Date().toISOString(),cleared=[];
   for(const canonical of [...new Set((Array.isArray(canonicals)?canonicals:[]).map(x=>String(x||'').trim()).filter(Boolean))]){
     const aliases=LOCAL_LIBRARY_FIELD_ALIASES[canonical];if(!aliases||userCorrections[canonical])continue;
     const header=findHeader(meta,aliases)||Object.keys(row.fields).find(h=>aliases.some(a=>h.trim().toLowerCase()===a.toLowerCase()));if(!header)continue;
     const before=row.fields[header]??'';if(String(before)==='')continue;row.fields[header]='';cleared.push({canonical,header,before,after:'',source:'ACENET_REPAIR_ABSENT',at:now});
   }
   if(!cleared.length)return{updated:false,row,cleared:[]};
   row.correctionHistory=[...history,...cleared].slice(-100);row.correctedAt=now;row.correctedBy='ACENET_REPAIR_ABSENT';records[idx]=row;
   await put('meta',{...local,records,updatedAt:now});return{updated:true,row,cleared};
 }
 async function setLocalLibraryAceNetVerification(sku,{status='UNKNOWN',missingFields=[]}={}){
   const key=normalizeSKU(sku);if(!key)throw new Error('SKU is required.');
   const meta=await get('meta','library'),local=await get('meta','localLibraryAdditions')||{key:'localLibraryAdditions',records:[]},records=Array.isArray(local.records)?[...local.records]:[];
   const idx=records.findIndex(r=>normalizeSKU(r?.skuKey||r?.fields?.[meta?.skuHeader||'ACE SKU'])===key);if(idx<0)return{updated:false,row:null};
   const now=new Date().toISOString(),normalizedMissing=[...new Set((Array.isArray(missingFields)?missingFields:[]).map(x=>String(x||'').trim()).filter(Boolean))];
   const row={...records[idx],localOrigin:'ACE_DERIVED',aceNetVerification:{status:String(status||'UNKNOWN').toUpperCase(),missingFields:normalizedMissing,verifiedAt:now}};
   records[idx]=row;await put('meta',{...local,records,updatedAt:now});return{updated:true,row};
 }
 async function findLocalLibraryRepairCandidates(){
   const [meta,local]=await Promise.all([get('meta','library'),get('meta','localLibraryAdditions')]),rows=Array.isArray(local?.records)?local.records:[],out=[];
   for(const row of rows){const fields=row.fields||{},read=k=>{const aliases=LOCAL_LIBRARY_FIELD_ALIASES[k]||[],h=findHeader(meta,aliases)||Object.keys(fields).find(x=>aliases.some(a=>x.trim().toLowerCase()===a.toLowerCase()));return h?fields[h]:''},reasons=[];
     const desc=String(read('description')||'').trim(),w=String(read('omWeight')||'').trim(),cg=String(read('commodityGroup')||'').trim(),mc=String(read('merchandiseClassNumber')||'').trim(),pg=String(read('productGroupNumber')||'').trim();
     if(!desc||/^specs$/i.test(desc))reasons.push('description');if(!normalizeAceNetWeight(w))reasons.push('omWeight');if(!/^\s*\d+/.test(cg))reasons.push('commodityGroup');if(!/^\s*\d+/.test(mc))reasons.push('merchandiseClassNumber');if(!/^\s*\d+/.test(pg))reasons.push('productGroupNumber');
     if(reasons.length)out.push({sku:row.skuKey||normalizeSKU(row?.fields?.[meta?.skuHeader||'ACE SKU']),reasons,row});
   }return out;
 }
 async function reindexActiveLibrary(upcHeader,skuHeader){const meta=await get('meta','library');if(!meta?.generation)throw new Error('No active Master Library.');if(!upcHeader||!skuHeader||upcHeader===skuHeader)throw new Error('Choose different UPC and SKU columns.');const db=await open(),generation=meta.generation;await new Promise((res,rej)=>{const t=db.transaction('library','readwrite'),s=t.objectStore('library'),q=s.openCursor();q.onsuccess=()=>{const c=q.result;if(!c)return;if(c.value.generation===generation){const f=c.value.fields||{},raw=f[upcHeader]??'',upcKey=normalizeImportedUPC(raw),skuKey=normalizeSKU(f[skuHeader]);c.update({...c.value,originalUPC:raw,upcKey,skuKey})}c.continue()};q.onerror=()=>rej(q.error);t.oncomplete=res;t.onerror=()=>rej(t.error)});meta.upcHeader=upcHeader;meta.skuHeader=skuHeader;meta.mappingUpdatedAt=new Date().toISOString();await put('meta',meta);return meta}
 async function upsertSkuUpcs(sku,upcs,source='ACENET'){
   const skuKey=normalizeSKU(sku);if(!skuKey)return{skuKey:'',masterUpc:null,upcs:[],inserted:0,updated:0};
   const normalized=[...new Set((Array.isArray(upcs)?upcs:[]).map(normalizeUPC).filter(Boolean))];
   if(!normalized.length)return{skuKey,masterUpc:null,upcs:[],inserted:0,updated:0};
   const d=await open();let masterUpc=normalized[0];
   return new Promise((res,rej)=>{
     const t=d.transaction('skuUpcs','readwrite'),store=t.objectStore('skuUpcs'),idx=store.index('skuKey'),q=idx.openCursor(IDBKeyRange.only(skuKey));
     const existing=[];let inserted=0,updated=0;
     q.onsuccess=()=>{const c=q.result;if(c){existing.push(c.value);c.continue();return}
       const now=new Date().toISOString(),wanted=new Set(normalized),existingMaster=existing.find(row=>Boolean(row.isMaster))?.upcKey||null;
       masterUpc=existingMaster||normalized[0];
       for(const row of existing){
         const next={...row,isMaster:Boolean(row.isMaster),source:wanted.has(row.upcKey)?source:row.source,lastSeenAt:wanted.has(row.upcKey)?now:row.lastSeenAt};
         if(wanted.has(row.upcKey)){store.put(next);updated++}
       }
       for(const upcKey of normalized){
         if(existing.some(x=>x.upcKey===upcKey))continue;
         store.put({skuKey,upcKey,isMaster:!existingMaster&&upcKey===masterUpc,source,firstSeenAt:now,lastSeenAt:now});inserted++;
       }
     };
     q.onerror=()=>rej(q.error);t.oncomplete=()=>res({skuKey,masterUpc,upcs:normalized,inserted,updated});t.onerror=()=>rej(t.error)
   });
 }
 async function getSkuUpcs(sku){
   const skuKey=normalizeSKU(sku);if(!skuKey)return[];
   const d=await open();return new Promise((res,rej)=>{const r=d.transaction('skuUpcs').objectStore('skuUpcs').index('skuKey').getAll(IDBKeyRange.only(skuKey));r.onsuccess=()=>res((r.result||[]).sort((a,b)=>Number(b.isMaster)-Number(a.isMaster)||(a.firstSeenAt||'').localeCompare(b.firstSeenAt||'')));r.onerror=()=>rej(r.error)})
 }
 async function lookupSkuByUpc(upc){
   const upcKey=normalizeUPC(upc);if(!upcKey)return[];
   const d=await open();return new Promise((res,rej)=>{const r=d.transaction('skuUpcs').objectStore('skuUpcs').index('upcKey').getAll(IDBKeyRange.only(upcKey));r.onsuccess=()=>res(r.result||[]);r.onerror=()=>rej(r.error)})
 }


 const IDENTITY_CATALOG_STATUSES=new Set(['UNKNOWN','MASTER_LIBRARY','LOCAL_LIBRARY','ACENET_VERIFIED','ACENET_NOT_FOUND','NEEDS_LOCAL_LIBRARY']);
 const IDENTITY_REPLACEMENT_STATUSES=new Set(['NONE','CURRENT_REPLACEMENT','REPLACED']);
 async function getSkuIdentity(sku){const skuKey=normalizeSKU(sku);return skuKey?get('skuIdentity',skuKey):null}
 async function setSkuIdentityStatus(sku,patch={}){
   const skuKey=normalizeSKU(sku);if(!skuKey)throw new Error('SKU is required for identity state.');
   const existing=await get('skuIdentity',skuKey),now=new Date().toISOString();
   const catalogStatus=String(patch.catalogStatus??existing?.catalogStatus??'UNKNOWN').toUpperCase();
   const replacementStatus=String(patch.replacementStatus??existing?.replacementStatus??'NONE').toUpperCase();
   if(!IDENTITY_CATALOG_STATUSES.has(catalogStatus))throw new Error(`Unsupported catalog status: ${catalogStatus}`);
   if(!IDENTITY_REPLACEMENT_STATUSES.has(replacementStatus))throw new Error(`Unsupported replacement status: ${replacementStatus}`);
   const replacementSkuKey=patch.replacementSku==null?(existing?.replacementSkuKey||null):normalizeSKU(patch.replacementSku)||null;
   if(replacementStatus==='REPLACED'&&!replacementSkuKey)throw new Error('A replaced SKU requires a current replacement SKU.');
   if(replacementSkuKey===skuKey)throw new Error('A SKU cannot replace itself.');
   const row={...(existing||{}),skuKey,sku:String(patch.sku??existing?.sku??sku),catalogStatus,replacementStatus,replacementSkuKey,
     firstSeenAt:existing?.firstSeenAt||now,lastSeenAt:now,source:String(patch.source??existing?.source??'IDENTITY_INDEX')};
   await put('skuIdentity',row);return row;
 }
 async function assertReplacementAcyclic(replacedSku,currentSku){
   const replacedKey=normalizeSKU(replacedSku),currentKey=normalizeSKU(currentSku);if(!replacedKey||!currentKey)throw new Error('Both replaced and current SKU are required.');
   if(replacedKey===currentKey)throw new Error('A SKU cannot replace itself.');
   const seen=new Set([replacedKey]);let cursor=currentKey;
   while(cursor){if(seen.has(cursor))throw new Error('Replacement relationship would create a cycle.');seen.add(cursor);const row=await get('skuIdentity',cursor);cursor=row?.replacementStatus==='REPLACED'?normalizeSKU(row.replacementSkuKey):''}
   return{replacedKey,currentKey};
 }
 async function setSkuReplacement(replacedSku,currentSku,source='USER_RESOLUTION'){
   const {replacedKey,currentKey}=await assertReplacementAcyclic(replacedSku,currentSku),now=new Date().toISOString();
   const oldRow=await get('skuIdentity',replacedKey),currentRow=await get('skuIdentity',currentKey);
   await put('skuIdentity',{...(oldRow||{}),skuKey:replacedKey,sku:String(oldRow?.sku??replacedSku),catalogStatus:oldRow?.catalogStatus||'UNKNOWN',replacementStatus:'REPLACED',replacementSkuKey:currentKey,firstSeenAt:oldRow?.firstSeenAt||now,lastSeenAt:now,source});
   await put('skuIdentity',{...(currentRow||{}),skuKey:currentKey,sku:String(currentRow?.sku??currentSku),catalogStatus:currentRow?.catalogStatus||'UNKNOWN',replacementStatus:'CURRENT_REPLACEMENT',replacementSkuKey:null,firstSeenAt:currentRow?.firstSeenAt||now,lastSeenAt:now,source});
   return{replacedSkuKey:replacedKey,currentSkuKey:currentKey};
 }
 async function getUpcIdentityResolution(upc){const upcKey=normalizeUPC(upc);return upcKey?get('upcIdentityResolution',upcKey):null}
 async function recordIdentityRelationship(sku,upc,source='USER'){
   const skuKey=normalizeSKU(sku),upcKey=normalizeUPC(upc);if(!skuKey||!upcKey)throw new Error('SKU and UPC are required for an identity relationship.');
   const d=await open(),now=new Date().toISOString();return new Promise((res,rej)=>{
     const t=d.transaction(['skuUpcs','upcIdentityResolution'],'readwrite'),relationships=t.objectStore('skuUpcs'),resolutions=t.objectStore('upcIdentityResolution'),relationshipKey=[skuKey,upcKey];let output=null;
     const priorRelationshipReq=relationships.get(relationshipKey);
     priorRelationshipReq.onsuccess=()=>{
       const priorRelationship=priorRelationshipReq.result;
       relationships.put(priorRelationship?{...priorRelationship,source:priorRelationship.source||source,lastSeenAt:now}:{skuKey,upcKey,isMaster:false,source,firstSeenAt:now,lastSeenAt:now});
       const candidatesReq=relationships.index('upcKey').getAll(IDBKeyRange.only(upcKey));
       candidatesReq.onsuccess=()=>{
         const unique=[...new Set((candidatesReq.result||[]).map(x=>normalizeSKU(x.skuKey)).filter(Boolean))].sort(),existingReq=resolutions.get(upcKey);
         existingReq.onsuccess=()=>{
           const existing=existingReq.result,status=unique.length>1?'UNRESOLVED_CONFLICT':'NORMAL',preferredSkuKey=unique.length===1?unique[0]:null;
           output={...(existing||{}),upcKey,status,preferredSkuKey,candidateSkuKeys:unique,resolutionTag:status==='NORMAL'?'SINGLE_SKU':null,firstSeenAt:existing?.firstSeenAt||now,lastSeenAt:now,source};
           resolutions.put(output);
         };
       };
     };
     t.oncomplete=()=>res(output);t.onerror=()=>rej(t.error||new Error('Identity relationship transaction failed.'));t.onabort=()=>rej(t.error||new Error('Identity relationship transaction aborted.'));
   });
 }
 async function recordVerifiedSkuUpcs(sku,upcs,source='ACENET_VERIFIED'){
   const merged=await upsertSkuUpcs(sku,upcs,source),resolutions=[];
   for(const upc of merged.upcs)resolutions.push(await recordIdentityRelationship(merged.skuKey,upc,source));
   return{...merged,resolutions,conflictCount:resolutions.filter(x=>x?.status==='UNRESOLVED_CONFLICT').length};
 }
 async function replaceSkuUpcSet(sku,upcs,source='VERIFIED_COMPLETE_SET'){
   const skuKey=normalizeSKU(sku);if(!skuKey)throw new Error('SKU is required for UPC-set replacement.');
   const normalized=[...new Set((Array.isArray(upcs)?upcs:[]).map(normalizeUPC).filter(Boolean))];
   if(!normalized.length)throw new Error('A complete verified UPC set must contain at least one UPC.');
   const masterUpc=normalized[0],d=await open(),now=new Date().toISOString();
   return new Promise((res,rej)=>{
     const t=d.transaction(['skuUpcs','upcIdentityResolution'],'readwrite'),relationships=t.objectStore('skuUpcs'),resolutions=t.objectStore('upcIdentityResolution');
     let output=null;
     const existingReq=relationships.index('skuKey').getAll(IDBKeyRange.only(skuKey));
     existingReq.onsuccess=()=>{
       const existing=existingReq.result||[],existingByUpc=new Map(existing.map(row=>[row.upcKey,row])),wanted=new Set(normalized),removedRows=existing.filter(row=>!wanted.has(row.upcKey));
       let inserted=0,updated=0;
       for(const row of removedRows)relationships.delete([skuKey,row.upcKey]);
       for(const upcKey of normalized){
         const prior=existingByUpc.get(upcKey),next={...(prior||{}),skuKey,upcKey,isMaster:upcKey===masterUpc,source,firstSeenAt:prior?.firstSeenAt||now,lastSeenAt:now};
         if(!prior)inserted++;
         else if(Boolean(prior.isMaster)!==next.isMaster||String(prior.source||'')!==String(next.source||''))updated++;
         relationships.put(next);
       }
       const affected=[...new Set([...existing.map(row=>row.upcKey),...normalized])],resolutionRows=[];
       let pending=affected.length;
       const finishOne=()=>{pending--;if(pending===0)output={skuKey,masterUpc,upcs:normalized,inserted,updated,removed:removedRows.length,removedUpcs:removedRows.map(row=>row.upcKey),resolutions:resolutionRows,conflictCount:resolutionRows.filter(row=>row?.status==='UNRESOLVED_CONFLICT').length}};
       for(const upcKey of affected){
         const candidatesReq=relationships.index('upcKey').getAll(IDBKeyRange.only(upcKey));
         candidatesReq.onsuccess=()=>{
           const candidates=[...new Set((candidatesReq.result||[]).map(row=>normalizeSKU(row.skuKey)).filter(Boolean))].sort(),priorReq=resolutions.get(upcKey);
           priorReq.onsuccess=()=>{
             const prior=priorReq.result;
             if(!candidates.length){
               resolutions.delete(upcKey);
               resolutionRows.push({upcKey,status:'DELETED',preferredSkuKey:null,candidateSkuKeys:[]});
             }else{
               const retainResolved=candidates.length>1&&prior?.status==='RESOLVED'&&candidates.includes(normalizeSKU(prior.preferredSkuKey));
               const status=candidates.length===1?'NORMAL':retainResolved?'RESOLVED':'UNRESOLVED_CONFLICT',preferredSkuKey=candidates.length===1?candidates[0]:retainResolved?normalizeSKU(prior.preferredSkuKey):null;
               const row={...(prior||{}),upcKey,status,preferredSkuKey,candidateSkuKeys:candidates,resolutionTag:status==='NORMAL'?'SINGLE_SKU':retainResolved?(prior.resolutionTag||'UNKNOWN'):null,firstSeenAt:prior?.firstSeenAt||now,lastSeenAt:now,source:retainResolved?(prior.source||source):source};
               resolutions.put(row);resolutionRows.push(row);
             }
             finishOne();
           };
         };
       }
     };
     t.oncomplete=()=>res(output);t.onerror=()=>rej(t.error||new Error('UPC-set replacement transaction failed.'));t.onabort=()=>rej(t.error||new Error('UPC-set replacement transaction aborted.'));
   });
 }
 async function resolveUpcConflict(upc,preferredSku,resolutionTag='UNKNOWN'){
   const upcKey=normalizeUPC(upc),preferredSkuKey=normalizeSKU(preferredSku);if(!upcKey||!preferredSkuKey)throw new Error('UPC and preferred SKU are required.');
   const candidates=[...new Set((await lookupSkuByUpc(upcKey)).map(x=>x.skuKey).filter(Boolean))].sort();
   if(!candidates.includes(preferredSkuKey))throw new Error('Preferred SKU must already be associated with this UPC.');
   const tag=String(resolutionTag||'UNKNOWN').toUpperCase();if(!['SCANNED_REPLACES_EXISTING','EXISTING_REPLACES_SCANNED','UNKNOWN'].includes(tag))throw new Error(`Unsupported conflict resolution: ${tag}`);
   if(tag==='UNKNOWN'){const row={upcKey,status:'UNRESOLVED_CONFLICT',preferredSkuKey:null,candidateSkuKeys:candidates,resolutionTag:'UNKNOWN',lastSeenAt:new Date().toISOString()};await put('upcIdentityResolution',row);return row}
   for(const candidate of candidates)if(candidate!==preferredSkuKey)await setSkuReplacement(candidate,preferredSkuKey,'UPC_CONFLICT_RESOLUTION');
   const row={upcKey,status:'RESOLVED',preferredSkuKey,candidateSkuKeys:candidates,resolutionTag:tag,lastSeenAt:new Date().toISOString()};await put('upcIdentityResolution',row);return row;
 }


 async function enqueueIdentityResearch(candidate={}){
   const skuKey=normalizeSKU(candidate.sku);if(!skuKey)throw new Error('SKU is required for Items Needing Research.');
   const now=new Date().toISOString(),existing=await get('identityResearchQueue',skuKey),upcs=[...new Set([...(existing?.upcs||[]),...(candidate.upcs||[]).map(normalizeUPC)].filter(Boolean))];
   const row={...(existing||{}),skuKey,sku:String(candidate.sku),upcs,status:'PENDING',reason:String(candidate.reason||'NOT_IN_MASTER_OR_ACENET'),detectedAt:existing?.detectedAt||now,lastCheckedAt:now,source:String(candidate.source||'IDENTITY_RESOLUTION')};
   await put('identityResearchQueue',row);return row;
 }
 async function getIdentityResearch(sku){const skuKey=normalizeSKU(sku);return skuKey?get('identityResearchQueue',skuKey):null}
 async function updateIdentityResearch(sku,patch={}){
   const skuKey=normalizeSKU(sku);if(!skuKey)throw new Error('SKU is required for Items Needing Research.');
   const existing=await get('identityResearchQueue',skuKey);if(!existing)throw new Error('This research record no longer exists.');
   const now=new Date().toISOString(),next={...existing,lastReviewedAt:now};
   if(patch.status!=null)next.status=String(patch.status).toUpperCase();
   if(patch.classification!=null)next.classification=String(patch.classification).toUpperCase();
   if(patch.reason!=null)next.reason=String(patch.reason);
   if(Array.isArray(patch.upcs))next.upcs=[...new Set(patch.upcs.map(normalizeUPC).filter(Boolean))];
   await put('identityResearchQueue',next);return next;
 }
 async function updateIdentityResearchUpc(sku,upc){
   const skuKey=normalizeSKU(sku),upcKey=normalizeUPC(upc);if(!skuKey||!upcKey)throw new Error('SKU and corrected UPC are required.');
   const existing=await get('identityResearchQueue',skuKey);if(!existing)throw new Error('This research record no longer exists.');
   const now=new Date().toISOString(),row={...existing,upcs:[upcKey],status:'PENDING',classification:'UNKNOWN',lastReviewedAt:now,correctedFromUpcs:[...(existing.upcs||[])]};
   await put('identityResearchQueue',row);return row;
 }
 async function enqueueDeferredAceNetRefresh(candidate={}){
   const skuKey=normalizeSKU(candidate.sku);if(!skuKey)throw new Error('SKU is required for deferred AceNet refresh.');
   const meta=await get('meta','deferredAceNetRefreshQueue')||{key:'deferredAceNetRefreshQueue',records:[]},records=Array.isArray(meta.records)?[...meta.records]:[],idx=records.findIndex(r=>normalizeSKU(r.skuKey||r.sku)===skuKey),prior=idx>=0?records[idx]:null,now=new Date().toISOString(),upcs=[...new Set([...(prior?.upcs||[]),...(candidate.upcs||[])].map(normalizeUPC).filter(Boolean))],sources=[...new Set([...(prior?.sources||[]),candidate.source||prior?.source||'DEFERRED_LOOKUP'].filter(Boolean).map(String))];
   const row={...(prior||{}),skuKey,sku:String(candidate.sku).trim(),upcs,status:'PENDING',reason:String(candidate.reason||prior?.reason||'ACENET_DEFERRED'),source:sources[0],sources,firstQueuedAt:prior?.firstQueuedAt||now,lastQueuedAt:now,lastError:prior?.lastError||null};
   if(idx>=0)records[idx]=row;else records.push(row);await put('meta',{...meta,records,updatedAt:now});return row;
 }
 async function getDeferredAceNetRefreshQueue(){const meta=await get('meta','deferredAceNetRefreshQueue'),records=Array.isArray(meta?.records)?meta.records:[];return [...records].sort((a,b)=>String(a.firstQueuedAt||'').localeCompare(String(b.firstQueuedAt||'')))}
 async function removeDeferredAceNetRefreshSku(sku){const skuKey=normalizeSKU(sku);if(!skuKey)return false;const meta=await get('meta','deferredAceNetRefreshQueue');if(!Array.isArray(meta?.records))return false;const records=meta.records.filter(r=>normalizeSKU(r.skuKey||r.sku)!==skuKey);if(records.length===meta.records.length)return false;await put('meta',{...meta,records,updatedAt:new Date().toISOString()});return true}

 async function getIdentityResearchQueue(){return (await all('identityResearchQueue')).sort((a,b)=>String(a.detectedAt||'').localeCompare(String(b.detectedAt||'')))}
 async function removeIdentityResearch(sku){const skuKey=normalizeSKU(sku);if(skuKey)await remove('identityResearchQueue',skuKey)}
 async function updateIdentityResearchSku(oldSku,newSku){
   const oldKey=normalizeSKU(oldSku),newKey=normalizeSKU(newSku);if(!oldKey||!newKey)throw new Error('Both current and corrected SKU are required.');
   const existing=await get('identityResearchQueue',oldKey);if(!existing)throw new Error('This research record no longer exists.');if(oldKey===newKey)return existing;
   const target=await get('identityResearchQueue',newKey),now=new Date().toISOString(),upcs=[...new Set([...(target?.upcs||[]),...(existing.upcs||[])].map(normalizeUPC).filter(Boolean))];
   const row={...(target||existing),skuKey:newKey,sku:String(newSku).trim(),upcs,status:'PENDING',detectedAt:target?.detectedAt||existing.detectedAt||now,lastCheckedAt:now,source:existing.source||target?.source||'NORMAL_LOOKUP',correctedFromSkuKey:oldKey};
   await put('identityResearchQueue',row);await remove('identityResearchQueue',oldKey);return row;
 }
 async function discardIdentityResearch(sku){const skuKey=normalizeSKU(sku);if(!skuKey)return false;const existing=await get('identityResearchQueue',skuKey);if(!existing)return false;await remove('identityResearchQueue',skuKey);return true}

 async function lookupUniqueLocalSKU(key){
   const wanted=normalizeSKU(key);if(!wanted)return{row:null,count:0,mode:'LOCAL_SKU_EXACT'};
   const local=await get('meta','localLibraryAdditions'),meta=await get('meta','library'),skuHeader=meta?.skuHeader||'ACE SKU',matches=[];
   for(const row of (Array.isArray(local?.records)?local.records:[])){if(normalizeSKU(row?.skuKey||row?.fields?.[skuHeader])===wanted){matches.push(row);if(matches.length>=2)break}}
   return{row:matches.length===1?matches[0]:null,count:matches.length,mode:'LOCAL_SKU_EXACT'};
 }
 async function lookupUniqueLocalExact(key){
   const wanted=normalizeUPC(key);if(!wanted)return{row:null,count:0,mode:'LOCAL_EXACT'};
   const local=await get('meta','localLibraryAdditions'),matches=[];
   for(const row of (Array.isArray(local?.records)?local.records:[])){const upc=normalizeUPC(row?.upcKey||row?.originalUPC);if(upc===wanted){matches.push(row);if(matches.length>=2)break}}
   return{row:matches.length===1?matches[0]:null,count:matches.length,mode:'LOCAL_EXACT'};
 }
 async function lookupUniqueLocalPrefix(prefix){
   const wanted=normalizeUPC(prefix);if(!wanted)return{row:null,count:0,mode:'LOCAL_PREFIX_11'};
   const local=await get('meta','localLibraryAdditions'),matches=[];
   for(const row of (Array.isArray(local?.records)?local.records:[])){const upc=normalizeUPC(row?.upcKey||row?.originalUPC);if(upc.startsWith(wanted)){matches.push(row);if(matches.length>=2)break}}
   return{row:matches.length===1?matches[0]:null,count:matches.length,mode:'LOCAL_PREFIX_11'};
 }


 async function getIdentityConflictQueue(){
   const rows=(await all('upcIdentityResolution')).filter(x=>x.status==='UNRESOLVED_CONFLICT').sort((a,b)=>String(a.lastSeenAt||'').localeCompare(String(b.lastSeenAt||'')));
   for(const row of rows){const rels=await lookupSkuByUpc(row.upcKey);row.candidateRelationships=rels.filter(x=>(row.candidateSkuKeys||[]).includes(x.skuKey)).map(x=>({skuKey:x.skuKey,source:x.source||null,firstSeenAt:x.firstSeenAt||null,lastSeenAt:x.lastSeenAt||null})).sort((a,b)=>String(a.firstSeenAt||'').localeCompare(String(b.firstSeenAt||'')))}
   return rows;
 }

 async function lookupUPC(key){const r=await lookupUniqueExact(key);return r.row}
 async function stageLibrary(records,onProgress,options={}){
   const d=await open(),generation=crypto.randomUUID(),chunk=2500;
   for(let i=0;i<records.length;i+=chunk){await new Promise((res,rej)=>{const t=d.transaction('library','readwrite'),s=t.objectStore('library');for(const x of records.slice(i,i+chunk)){const {id:_oldId,generation:_oldGeneration,...source}=x||{},fields=source.fields||{},sku=fields[options.skuHeader||'ACE SKU']??'';s.add({...source,generation,skuKey:normalizeSKU(sku)})}t.oncomplete=res;t.onerror=()=>rej(t.error||new Error('Master Library staging transaction failed.'));t.onabort=()=>rej(t.error||new Error('Master Library staging transaction aborted.'))});onProgress?.(Math.min(i+chunk,records.length),records.length);await new Promise(r=>setTimeout(r,0))}
   return generation;
 }
 async function cleanupLibraries(activeGeneration){const d=await open();return new Promise((res,rej)=>{const t=d.transaction('library','readwrite'),s=t.objectStore('library'),r=s.openCursor();r.onsuccess=()=>{const c=r.result;if(!c)return;if(c.value.generation!==activeGeneration)c.delete();c.continue()};t.oncomplete=res;t.onerror=()=>rej(t.error)})}
 async function discardLibraryGeneration(generation){if(!generation)return;const d=await open();return new Promise((res,rej)=>{const t=d.transaction('library','readwrite'),s=t.objectStore('library'),r=s.openCursor();r.onsuccess=()=>{const c=r.result;if(!c)return;if(c.value.generation===generation)c.delete();c.continue()};t.oncomplete=res;t.onerror=()=>rej(t.error)})}
 return{open,put,get,all,clear,remove,lookupUPC,lookupUniqueExact,lookupUniquePrefix,lookupUniqueSKU,lookupUniqueLocalExact,lookupUniqueLocalPrefix,lookupUniqueLocalSKU,getActiveLibraryRecords,deleteActiveLibraryRows,updateActiveLibraryMasterUpc,updateLocalLibraryMasterUpc,stageLocalLibraryAceNetItem,stageLocalLibraryThirdPartyItem,getLocalLibraryRecordBySku,correctLocalLibraryFields,clearLocalLibraryAceNetFields,setLocalLibraryAceNetVerification,findLocalLibraryRepairCandidates,enqueueLibrarySku,enqueueLibraryUpdate,getLibraryUpdateQueue,clearLibraryUpdateQueue,removeLibraryUpdateQueueSku,upsertSkuUpcs,getSkuUpcs,lookupSkuByUpc,getSkuIdentity,setSkuIdentityStatus,setSkuReplacement,getUpcIdentityResolution,recordIdentityRelationship,recordVerifiedSkuUpcs,replaceSkuUpcSet,resolveUpcConflict,enqueueIdentityResearch,getIdentityResearch,updateIdentityResearch,updateIdentityResearchUpc,getIdentityResearchQueue,removeIdentityResearch,updateIdentityResearchSku,discardIdentityResearch,enqueueDeferredAceNetRefresh,getDeferredAceNetRefreshQueue,removeDeferredAceNetRefreshSku,getIdentityConflictQueue,reindexActiveLibrary,stageLibrary,cleanupLibraries,discardLibraryGeneration};
})();
