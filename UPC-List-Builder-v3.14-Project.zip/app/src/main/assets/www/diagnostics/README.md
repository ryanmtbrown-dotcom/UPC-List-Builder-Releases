# Diagnostics Directory Ownership

OWNS: structured diagnostic event schema, operation/span adaptation, retention, IndexedDB journal persistence, export/reconstruction, native-event ingestion, runtime readiness evidence, and diagnostics UI.

DOES NOT OWN: business success/failure decisions, lookup authority, service-health business policy, catalog mutation, or recovery decisions.

SIDE EFFECTS: diagnostic persistence/export only. Diagnostic failure must not change application behavior.

DEEP DIAGNOSTIC UI: `diagnostic-ui-controller.js` owns both supported Deep Diagnostic Mode surfaces: the Settings row and the Diagnostics overlay button. Other controllers may expose navigation/surfaces but must not call `diagnosticService.toggleDeepMode()` directly.

EXPORT SAFETY: bounded chunk serializer owns transport backpressure and lifecycle acknowledgement; native writer alone owns partial-file cleanup and final publication. UI preview is bounded independently of full file content.

DEEP MODE: scoped TRACE/DEBUG records at lookup and native diagnostic-transfer boundaries are emitted only while Deep Diagnostic is enabled; normal-mode persistence, worklists, and Excel schemas are unchanged. Native Android diagnostic downloads are streaming ZIP files containing the canonical JSON, with the browser JSON fallback intact.
