/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/diagnostics/acenet-native-diagnostic-service.js
 * Owner: AceNet Diagnostics
 * Role: Diagnostic adapter/service
 * Responsibility: Owns ingestion/translation of native AceNet status, readiness, forensic, and callback evidence into structured web diagnostics.
 * Does not own: AceNet business/session decisions, retry policy, catalog writes, or UI lookup results.
 * Side effects: Reads native bridge diagnostic state and emits observational diagnostic events.
 * Related code: Business AceNet state remains with startup/session/coordinator owners; storage belongs to diagnostic journal/repository.
 */
const UPCAceNetNativeDiagnosticService=(()=>{
 function create({diagnostic,isStartupReady,startOperation,finishOperation,observeOperation}={}){
  if(typeof diagnostic!=='function'||typeof isStartupReady!=='function'||typeof startOperation!=='function'||typeof finishOperation!=='function'||typeof observeOperation!=='function')throw new Error('AceNet Native Diagnostic Service dependencies are incomplete.');
  const diag=diagnostic;
  function explain(p={}){
   const event=String(p?.event||'');
   const map={
    session_reused:['Reuse the retained authenticated AceNet home session.','A retained authenticated home may be reused only after its search controls and user/store context are reverified.'],
    warm_home_reused:['Reuse the retained AceNet home WebView for this request.','The retained home remains only a transport optimization; the requested SKU must still be freshly searched and verified.'],
    session_cookie_reused_cold_view:['Attempt AceNet using retained cookies in a new WebView.','Retained cookies may assist authentication, but the new view must still prove authenticated home state.'],
    session_expired:['Record that the retained AceNet session returned to authentication.','The session is no longer treated as authenticated and recovery may run only through the bounded recovery path.'],
    session_recovery_started:['Begin the single automatic AceNet session-recovery attempt.','The stale session is cleared/logged out and saved encrypted credentials are used for one bounded reauthentication attempt.'],
    session_reauthentication_started:['Restart AceNet authentication after recovery cleanup.','Saved credentials establish a fresh authenticated session before the interrupted lookup is retried.'],
    session_recovery_stopped:['Stop automatic session recovery.','Automatic recovery never loops indefinitely; a second recovery requirement terminates explicitly.'],
    session_extension_scheduled:['Schedule AceNet session maintenance.','Authenticated foreground use schedules maintenance relative to the newest authenticated, extended, or successful-lookup timestamp.'],
    session_extension_started:['Extend the current AceNet session.','The extension checks the authenticated AceNet session without changing item-search identity or pricing authority.'],
    session_extension_succeeded:['Record successful AceNet session extension.','The extension timestamp advances only after a successful timeout-check response.'],
    session_extension_failed:['Record failed AceNet session extension.','Failed extension removes authenticated-session authority and preserves the technical failure evidence.'],
    authenticated_home_ready:['Verify the AceNet authenticated home.','Search controls plus user/store context prove the home session before an item search is invoked.'],
    search_function_invoked:['Invoke a fresh AceNet SKU search.','The requested SKU is submitted through the verified Product search control and must be independently verified in the result.'],
    popup_requested:['Observe the AceNet result-window request.','The popup/result WebView remains correlated to the current request and does not create item identity by itself.'],
    result_poll:['Inspect the current AceNet result.','Polling remains bounded and reports observed SKU, price, catalog, authentication, not-found, multiple-result, or pending evidence without inventing a result.'],
    result_target_inspection:['Inspect the active AceNet result target.','The current opener/popup target is inspected without allowing a stale target to become authoritative.'],
    lookup_timing_summary:['Complete the native AceNet lookup timing record.','The terminal status records total, search-to-result, result-phase, and inspection timing for the same request.'],
    resource_error:['Record an observed WebView/network resource error.','The raw callback evidence is retained with main-frame status and source; a connectivity failure is not by itself proof that the AceNet server is DOWN.'],
    http_error:['Record an observed HTTP error response.','The actual HTTP status, reason, host, frame role, and callback provenance are retained; only explicitly classified main-frame server responses may establish observed service DOWN.'],
    service_health_terminal:['Apply a terminal AceNet service-health decision from an observed server response.','A genuine main-frame HTTP 500/502/503/504 response is preserved verbatim, marked observed rather than inferred, and terminates work that cannot succeed.'],
    http_authentication_required:['Classify an observed HTTP 401 response.','HTTP 401 is treated as authentication/session evidence rather than a server-down conclusion.'],
    http_access_denied:['Classify an observed HTTP 403 response.','HTTP 403 is treated as an access/authorization failure rather than a server-down conclusion.'],
    http_resource_not_found:['Classify an observed HTTP 404 response.','HTTP 404 proves that a server answered but the required resource was unavailable; it does not prove a global AceNet server outage.'],
    application_backgrounded:['Record that Android moved UPC List Builder fully into the background.','An in-flight startup may continue under the same request/session ownership; backgrounding alone makes no AceNet health decision.'],
    startup_request_retained_for_background:['Retain the in-flight AceNet startup request across Android backgrounding.','The existing startup WebView/worker remains authoritative while the process survives; no duplicate startup request is created.'],
    backgrounded_startup_still_running_after_foreground:['Observe a retained startup that is still running after foreground return.','The same startup request continues without restart or duplicate recovery.'],
    backgrounded_startup_terminal_retained:['Accept a terminal result produced by startup work that continued across backgrounding.','ONLINE or authoritative DOWN evidence remains valid; lifecycle movement alone does not rewrite the result.'],
    backgrounded_startup_foreground_revalidation_started:['Revalidate a non-ONLINE backgrounded startup after foreground return.','Exactly one foreground warm-up revalidation is started before a background-associated operational failure becomes the current usable-service conclusion.'],
    backgrounded_startup_health_publication_deferred:['Defer a non-ONLINE background-startup health publication.','A background-associated operational failure stays native until foreground revalidation; ONLINE and authoritative DOWN remain publishable.'],
    backgrounded_startup_terminal_deferred:['Hold non-ONLINE background-startup completion for foreground revalidation.','The startup request is closed natively without publishing a final unavailable state; foreground return performs one bounded revalidation.'],
    active_request_interrupted_for_background:['Terminate a non-startup AceNet request interrupted by Android backgrounding.','The request ends explicitly as INTERRUPTED without changing AceNet service health.'],
    application_foregrounded:['Record that UPC List Builder returned to the Android foreground.','The diagnostic reports how long the app was away and whether startup continued while backgrounded.']
   };
   const m=map[event]||[`Record AceNet native event ${event||'unknown'}.`,'Preserve the observed native evidence and its request/session context without silently changing unrelated subsystem policy.'];
   const fail=/failed|error|expired|stopped/i.test(event);
   let actual=`Native AceNet event ${event||'unknown'} observed in phase ${p?.phase||'UNKNOWN'}${Number.isFinite(Number(p?.elapsedMs))?` at ${Number(p.elapsedMs)} ms`:''}.`;
   if(event==='application_backgrounded')actual=`Android moved the app to the background. Request in flight: ${p?.requestInFlight===true?'YES':'NO'}; request kind: ${p?.requestKind||'none'}; phase: ${p?.phase||'UNKNOWN'}; startup continues: ${p?.startupContinues===true?'YES':'NO'}. No AceNet health decision was made by this lifecycle event.`;
   else if(event==='startup_request_retained_for_background')actual=`Startup request ${p?.requestId||'unknown'} was retained across backgrounding. Prior phase: ${p?.priorPhase||'UNKNOWN'}; policy: ${p?.policy||'CONTINUE_IN_BACKGROUND_REVALIDATE_FAILURE_ON_FOREGROUND'}.`;
   else if(event==='backgrounded_startup_still_running_after_foreground')actual=`The retained startup request is still running after foreground return; policy: ${p?.policy||'CONTINUE_EXISTING_REQUEST'}.`;
   else if(event==='backgrounded_startup_terminal_retained')actual=`Background-retained startup completed with health ${p?.healthStatus||'UNKNOWN'} and no lifecycle-driven rewrite was required.`;
   else if(event==='backgrounded_startup_foreground_revalidation_started')actual=`A single foreground revalidation started for a non-ONLINE result produced by a startup that ran while backgrounded.`;
   else if(event==='active_request_interrupted_for_background')actual=`Active ${p?.requestKind||'AceNet'} request ${p?.requestId||'unknown'} was terminated as INTERRUPTED because the app entered the background. Health decision: ${p?.healthDecision||'NONE'}; DOWN declared: ${p?.downDeclared===true?'YES':'NO'}.`;
   else if(event==='application_foregrounded')actual=`App returned to the foreground after ${Number(p?.backgroundDurationMs)||0} ms away. Startup continued while backgrounded: ${p?.startupContinuedInBackground===true?'YES':'NO'}.`;
   return{whatWeAreDoing:m[0],expectedResult:m[1],actualResult:actual,result:fail?'FAIL':'OBSERVED'};
  }
  function accept(raw){
   try{
    const p=typeof raw==='string'?JSON.parse(raw):raw||{};p.contractDiagnostic=explain(p);diag('acenet_native_trace',p);
    if(isStartupReady())return p;
    const event=String(p?.event||'');
    if(event==='application_backgrounded'&&p?.startupContinues===true){startOperation('ANDROID_BACKGROUND_STARTUP','Continue AceNet startup while Android is backgrounded.','The existing startup request remains authoritative while the process survives; lifecycle movement alone creates no health result.');observeOperation('ANDROID_BACKGROUND_STARTUP','Retain startup across backgrounding.','The current startup request continues without duplicate authentication or worker creation.','Android backgrounded the app while startup verification remained active.','OBSERVED',p)}
    else if(event==='startup_request_retained_for_background'){observeOperation('ANDROID_BACKGROUND_STARTUP','Retain startup request ownership.','The same request/session generation remains authoritative while backgrounded.',`Retained startup request ${p?.requestId||'unknown'} across backgrounding.`,'OBSERVED',p)}
    else if(event==='application_foregrounded'&&p?.startupContinuedInBackground===true){observeOperation('ANDROID_BACKGROUND_STARTUP','Return while startup work was retained.','Foreground return does not automatically restart a surviving startup request.',`Returned after ${Number(p?.backgroundDurationMs)||0} ms with retained startup ownership.`,'OBSERVED',p)}
    else if(event==='backgrounded_startup_still_running_after_foreground'){observeOperation('ANDROID_BACKGROUND_STARTUP','Continue retained startup after foreground return.','The same request keeps running until it reaches a terminal result.','Retained startup is still active after foreground return.','OBSERVED',p)}
    else if(event==='backgrounded_startup_terminal_deferred'){observeOperation('ANDROID_BACKGROUND_STARTUP','Hold background-startup failure for foreground revalidation.','A non-ONLINE operational result is not published as final while the app is backgrounded.','Background startup reached a non-ONLINE terminal result; foreground revalidation is pending.','OBSERVED',p)}
    else if(event==='backgrounded_startup_terminal_retained'){finishOperation('ANDROID_BACKGROUND_STARTUP',`Background-retained startup completed with health ${p?.healthStatus||'UNKNOWN'}.`,p?.healthStatus==='ONLINE'?'PASS':'INCONCLUSIVE',p)}
    else if(event==='backgrounded_startup_foreground_revalidation_started'){finishOperation('ANDROID_BACKGROUND_STARTUP','Background-retained startup produced a non-ONLINE operational result; one foreground revalidation started.','PASS',p)}
    else if(event==='login_submission'){startOperation('ACENET_LOGIN','Establish the AceNet authenticated session.','AceNet accepts the saved credentials when authentication is required and proceeds toward an authenticated home session.');if(p?.accepted===true)finishOperation('ACENET_LOGIN','AceNet login submission was accepted.','PASS',p)}
    else if(event==='authenticated_home_ready'){startOperation('ACENET_HOME','Verify the authenticated AceNet home page.','An authenticated AceNet home page is available with required user/store context.');finishOperation('ACENET_HOME','Authenticated AceNet home page is ready.','PASS',p)}
    else if(event==='startup_authentication_verified_before_canary'){startOperation('ACENET_AUTHENTICATION','Confirm the current AceNet session before testing item service.','The session is authenticated before the startup pricing-health probe begins.');finishOperation('ACENET_AUTHENTICATION','Authentication verified; startup pricing-health probe may proceed.','PASS',p);startOperation('ACENET_ITEM_SERVICE','Verify AceNet pricing availability with canary SKU 50177.','The requested canary resolves and a valid AceNet retail price is detected; complete catalog enrichment is not required for startup health.')}
    else if(event==='startup_canary_health_evidence'){const evidence=String(p?.evidence||'UNKNOWN'),price=p?.price??p?.retailPrice??null,sku=p?.returnedSku||p?.sku||'unknown';finishOperation('ACENET_ITEM_SERVICE',`Canary SKU ${sku} produced startup health evidence ${evidence}${price!=null?` with retail price ${price}`:''}.`,evidence==='RETAIL_PRICE'?'PASS':'INCONCLUSIVE',p);startOperation('ACENET_HEALTH','Determine AceNet service health from startup evidence.','AceNet health reflects the strongest authenticated pricing-service evidence without inventing success or failure.')}
    else if(event==='result_watchdog_fired'){finishOperation('ACENET_ITEM_SERVICE','The item-result watchdog expired before sufficient pricing-health evidence completed.','INCONCLUSIVE',p)}
    else if(event==='health_state'){startOperation('ACENET_HEALTH','Determine AceNet service health from startup evidence.','AceNet health reflects the strongest authenticated pricing-service evidence without inventing success or failure.');finishOperation('ACENET_HEALTH',`AceNet health is ${p?.status||'UNKNOWN'} (${p?.reason||'no reason supplied'}).`,p?.status==='ONLINE'?'PASS':(p?.status==='DOWN'?'FAIL':'INCONCLUSIVE'),p)}
    return p;
   }catch(e){diag('acenet_native_trace_parse_failed',{message:e?.message||String(e)});return null}
  }
  return Object.freeze({explain,accept});
 }
 return Object.freeze({create});
})();
window.UPCAceNetNativeDiagnosticService=UPCAceNetNativeDiagnosticService;
