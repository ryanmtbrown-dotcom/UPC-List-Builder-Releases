/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/diagnostics/diagnostic-export-service.js
 * Owner: Diagnostics Export
 * Role: Export/reconstruction service
 * Responsibility: Owns non-destructive diagnostic snapshot assembly, web/native chronological merge, operation/span summaries, and export delivery.
 * Does not own: Diagnostic retention mutation, business state, failure inference beyond recorded evidence, or application recovery.
 * Side effects: Reads diagnostic/native evidence, builds export JSON, and invokes approved browser/native file delivery.
 * Related code: Event schema belongs to diagnostic-service.js; persistence belongs to diagnostic-journal/repository.
 */
const UPCDiagnosticExportService=(()=>{
 function create({elementById,diagRows,markCurrentStartupSession,diagnostic,diagnosticStatus,startOperation,finishOperation,appVersion,appBuild,startupSessionId,startupSnapshot,navigationSnapshot,scannerSnapshot,nativeBridgeProvider,windowRef,documentRef,navigatorRef,locationRef,matchMediaFn,secureContext,urlRef,blobCtor}={}){
  if(typeof elementById!=='function'||typeof diagRows!=='function'||typeof markCurrentStartupSession!=='function'||typeof diagnostic!=='function')throw new Error('Diagnostic Export Service journal dependencies are incomplete.');
  if(typeof startOperation!=='function'||typeof finishOperation!=='function'||typeof startupSnapshot!=='function'||typeof navigationSnapshot!=='function'||typeof scannerSnapshot!=='function')throw new Error('Diagnostic Export Service lifecycle dependencies are incomplete.');
  const $=elementById,diag=diagnostic,subsystemOperationStart=startOperation,subsystemOperationFinish=finishOperation,APP_VERSION=appVersion,APP_BUILD=appBuild;
  const window=windowRef,document=documentRef,navigator=navigatorRef,location=locationRef,matchMedia=matchMediaFn,Blob=blobCtor,URL=urlRef;
  const eventTime=row=>Number(row?.timestampEpochMs)||Date.parse(row?.timestamp||row?.at||0)||0;
  function normalizeNativeRow(row,index){
   if(row?.schemaVersion===2)return row;
   const payload=row?.payload&&typeof row.payload==='object'?row.payload:{};
   return{schemaVersion:1,sequence:null,timestamp:row?.timestamp||row?.at||null,timestampEpochMs:Number(row?.atEpochMs)||Date.parse(row?.timestamp||row?.at||0)||0,alaskaDate:row?.alaskaDate||null,severity:row?.severity||(/error|failed|timeout/i.test(String(row?.event||''))?'ERROR':'INFO'),sourceJournal:'ANDROID_NATIVE',operationId:payload.operationId||payload.requestId||null,spanId:payload.spanId||null,parentSpanId:payload.parentSpanId||null,domain:row?.domain||'ACENET',module:row?.module||'native/legacy',function:row?.function||payload.sourceFunction||payload.decisionSourceFunction||null,event:row?.event||`native_event_${index}`,phase:row?.phase||'EVENT',purpose:row?.purpose||null,expected:row?.expected||null,actual:row?.actual||null,result:row?.result||null,durationMs:row?.durationMs??payload.elapsedMs??null,details:payload,legacyNormalized:true};
  }
  function operationSummary(timeline){
   const operations=new Map(),spans=new Map();
   for(const row of timeline){
    const operationId=row?.operationId;if(operationId){const op=operations.get(operationId)||{operationId,eventCount:0,firstAt:null,lastAt:null,domains:new Set(),modules:new Set(),results:[],errors:0};op.eventCount++;op.firstAt=op.firstAt||row.timestamp||row.at||null;op.lastAt=row.timestamp||row.at||op.lastAt;if(row.domain)op.domains.add(row.domain);if(row.module)op.modules.add(row.module);if(row.result)op.results.push(row.result);if(['ERROR','FATAL'].includes(String(row.severity||'').toUpperCase()))op.errors++;operations.set(operationId,op)}
    const spanId=row?.spanId;if(spanId){const span=spans.get(spanId)||{spanId,operationId:operationId||null,parentSpanId:row.parentSpanId||null,module:row.module||null,function:row.function||null,purpose:row.purpose||null,startedAt:null,terminalAt:null,terminalPhase:null,lastEvent:null};const phase=String(row.phase||'').toUpperCase();if(phase==='START')span.startedAt=row.timestamp||row.at||null;if(['SUCCESS','ERROR','WARN','CANCELLED'].includes(phase)){span.terminalAt=row.timestamp||row.at||null;span.terminalPhase=phase}span.lastEvent=row.event||null;spans.set(spanId,span)}
   }
   const operationRows=[...operations.values()].map(x=>({...x,domains:[...x.domains],modules:[...x.modules],results:[...new Set(x.results)]}));
   const spanRows=[...spans.values()],unfinishedSpans=spanRows.filter(x=>x.startedAt&&!x.terminalAt);
   return{operationCount:operationRows.length,spanCount:spanRows.length,unfinishedSpanCount:unfinishedSpans.length,operations:operationRows,spans:spanRows,unfinishedSpans};
  }
  function diagPayload(){
   const vv=window.visualViewport,sw=navigator.serviceWorker;let rows=diagRows();const exportedAt=new Date().toISOString();
   const currentStartup=markCurrentStartupSession();rows=currentStartup.rows;
   let nativeJournal=[];try{nativeJournal=JSON.parse(nativeBridgeProvider?.()?.getNativeDiagnosticJournal?.()||'[]')}catch(e){nativeJournal=[{event:'native_journal_read_failed',severity:'ERROR',error:String(e?.message||e)}]}
   nativeJournal=Array.isArray(nativeJournal)?nativeJournal.map(normalizeNativeRow):[];
   const timeline=[...rows,...nativeJournal].sort((a,b)=>eventTime(a)-eventTime(b)||(Number(a?.sequence)||0)-(Number(b?.sequence)||0));
   const last=timeline.length?timeline[timeline.length-1]:null,lastAt=last?.timestamp||last?.at||null,lastMs=lastAt?Date.parse(lastAt):NaN;
   const ace=[...timeline].reverse().find(r=>String(r.domain||'').toUpperCase()==='ACENET'||String(r.event||'').toLowerCase().includes('acenet')||String(r.event||'').toLowerCase().includes('result_poll'));
   const aceAt=ace?.timestamp||ace?.at||null,aceMs=aceAt?Date.parse(aceAt):NaN,operations=operationSummary(timeline);
   let networkConnectivity={source:'WEB_FALLBACK',networkInterfaceReportedOnline:navigator.onLine,internetReachability:'UNKNOWN'};try{networkConnectivity=JSON.parse(nativeBridgeProvider?.()?.getNetworkConnectivityState?.()||JSON.stringify(networkConnectivity))}catch(e){networkConnectivity.error=String(e?.message||e)}
   return{diagnosticSchemaVersion:2,version:APP_VERSION,buildId:APP_BUILD,generatedAt:exportedAt,diagnosticExportedAt:exportedAt,lastEventAt:lastAt,millisecondsSinceLastEvent:Number.isFinite(lastMs)?Math.max(0,Date.parse(exportedAt)-lastMs):null,lastAceNetEventAt:aceAt,millisecondsSinceLastAceNetEvent:Number.isFinite(aceMs)?Math.max(0,Date.parse(exportedAt)-aceMs):null,location:location.href,userAgent:navigator.userAgent,platform:navigator.platform||null,language:navigator.language||null,networkInterfaceReportedOnline:navigator.onLine,internetReachability:networkConnectivity.internetReachability||'UNKNOWN',networkConnectivity,aceNetReachability:'SEE_EVENT_EVIDENCE',currentStartupSessionId:currentStartup.currentStartupSessionId,currentStartupCount:currentStartup.currentCount,currentStartupInvariant:currentStartup.invariant,diagnosticMode:typeof diagnosticStatus==='function'?diagnosticStatus():null,diagnosticCoverage:{javascriptJournalEventCount:rows.length,nativeJournalEventCount:nativeJournal.length,mergedTimelineEventCount:timeline.length,nativeJournalAvailable:Array.isArray(nativeJournal)},operationSummary:operations,nativeDiagnosticJournal:nativeJournal,visibility:document.visibilityState,standalone:matchMedia('(display-mode: standalone)').matches||navigator.standalone===true,secureContext:secureContext(),mediaDevices:!!navigator.mediaDevices,barcodeDetector:'BarcodeDetector'in window,serviceWorker:{supported:!!sw,controlled:!!sw?.controller,controllerUrl:sw?.controller?.scriptURL||null,state:sw?.controller?.state||null},viewport:{innerWidth:window.innerWidth,innerHeight:window.innerHeight,dpr:window.devicePixelRatio,screenWidth:window.screen.width,screenHeight:window.screen.height,visualWidth:vv?.width||null,visualHeight:vv?.height||null},startup:startupSnapshot(),navigation:navigationSnapshot(),scanner:scannerSnapshot(),eventCount:rows.length,events:rows,timeline};
  }
  function showDiagnostics(){
   // The overlay is a bounded preview, not a second full Deep Diagnostic export.
   const p=diagPayload(),mode=p.diagnosticMode?.deepDiagnosticMode?'DEEP':'NORMAL';
   $('diagSummary').textContent=`v${p.version} · ${mode} · ${p.diagnosticCoverage.mergedTimelineEventCount} events · ${p.operationSummary.unfinishedSpanCount} unfinished spans`;
   const preview={version:p.version,buildId:p.buildId,diagnosticMode:p.diagnosticMode,diagnosticCoverage:p.diagnosticCoverage,
    operationCounts:{operationCount:p.operationSummary.operationCount,spanCount:p.operationSummary.spanCount,unfinishedSpanCount:p.operationSummary.unfinishedSpanCount},
    explanation:'Bounded on-screen preview. Download the full diagnostic JSON to inspect every retained event.',
    lastEvents:p.timeline.slice(-80)};
   $('diagLog').textContent=JSON.stringify(preview,null,2);$('diagOverlay').classList.remove('hidden');
  }
  // Build valid JSON incrementally. Never stringify a full Deep Diagnostic payload:
  // timeline duplicates the journal and may exceed 100 MB when serialized.
  function* diagnosticJsonFragments(value){
   if(Array.isArray(value)){
    yield '[';for(let index=0;index<value.length;index++){if(index)yield ',';yield* diagnosticJsonFragments(value[index]===undefined?null:value[index])}yield ']';return;
   }
   if(value&&typeof value==='object'){
    yield '{';let first=true;for(const [key,part] of Object.entries(value)){
     if(part===undefined||typeof part==='function'||typeof part==='symbol')continue;
     if(!first)yield ',';first=false;yield JSON.stringify(key)+':';yield* diagnosticJsonFragments(part);
    }yield '}';return;
   }
   yield JSON.stringify(value)??'null';
  }
  const TRANSFER_CHARS=24000,DIAGNOSTIC_ACK_TIMEOUT_MS=60*1000;
  function createDiagnosticChunkIterator(payload){
   const iterator=diagnosticJsonFragments(payload),pending={rest:''};
   return{next(){
    let chunk='';while(chunk.length<TRANSFER_CHARS){
     if(!pending.rest){const next=iterator.next();if(next.done)break;pending.rest=next.value}
     let take=Math.min(TRANSFER_CHARS-chunk.length,pending.rest.length);
     // Never split a UTF-16 surrogate pair across JavaScriptInterface calls.
     if(take<pending.rest.length&&take>0){const code=pending.rest.charCodeAt(take-1);if(code>=0xD800&&code<=0xDBFF)take--}
     if(take===0)break;
     chunk+=pending.rest.slice(0,take);pending.rest=pending.rest.slice(take);
    }
    return chunk?{value:chunk,done:false}:{done:true};
   }};
  }
  // Deep-mode progress evidence is intentionally sparse and is not part of an
  // in-flight snapshot. It will be available in subsequent diagnostic exports.
  function deepEvidence(event,data,severity='DEBUG'){
   if(diagnosticStatus?.()?.deepDiagnosticMode===true&&typeof diag.event==='function')
    diag.event(event,data,{severity,phase:'OBSERVATION',function:'downloadDiagnostics'});
  }
  let activeTransfer=null;
  function finishDiagnosticTransfer(result,message){
   const active=activeTransfer;if(!active)return;
   activeTransfer=null;clearTimeout(active.watchdog);
   const text=message|| (result==='PASS'?'Diagnostic file saved.':'Diagnostic export interrupted.');
   deepEvidence('deep_diagnostic_export_terminal',{result,chunkCount:active.chunkCount,elapsedMs:Math.round(Date.now()-active.startedAt),archiveType:'zip'});
   if(result!=='PASS'){try{active.bridge.abortDiagnosticExport?.(active.id)}catch(_){/* best-effort native cleanup */}}
   diag('diagnostic_export_terminal',{result,message:text,transferId:active.id,chunkCount:active.chunkCount});
   subsystemOperationFinish(active.operationId,text,result,{module:'diagnostics/diagnostic-export-service',function:'downloadDiagnostics',transferId:active.id,chunkCount:active.chunkCount});
   acceptNativeExportStatus(result==='PASS'?'Saved to Downloads · '+active.name:'Diagnostic export failed · '+text);
  }
  function armTransferWatchdog(active){
   clearTimeout(active.watchdog);
   active.watchdog=setTimeout(()=>{if(activeTransfer===active)finishDiagnosticTransfer('FAIL','Android did not acknowledge the export within 60 seconds.')},DIAGNOSTIC_ACK_TIMEOUT_MS);
  }
  function sendNextDiagnosticChunk(){
   const active=activeTransfer;if(!active)return;
   try{
    const next=active.chunks.next();
    if(next.done){deepEvidence('deep_diagnostic_export_chunks_complete',{chunkCount:active.chunkCount,elapsedMs:Math.round(Date.now()-active.startedAt)},'TRACE');active.bridge.finishDiagnosticExport(active.id);armTransferWatchdog(active);return}
    active.chunkCount++;
    if(active.chunkCount===1||active.chunkCount%256===0)deepEvidence('deep_diagnostic_export_chunk_checkpoint',{chunkCount:active.chunkCount,elapsedMs:Math.round(Date.now()-active.startedAt)},'TRACE');
    active.bridge.appendDiagnosticExportChunk(active.id,next.value);
    armTransferWatchdog(active);
   }catch(error){finishDiagnosticTransfer('FAIL',error?.message||String(error))}
  }
  function acceptNativeExportTransferEvent(raw){
   let event;try{event=typeof raw==='string'?JSON.parse(raw):raw}catch(_){return false}
   const active=activeTransfer;if(!active||event?.id!==active.id)return false;
   if(event.phase==='ready'||event.phase==='saved'||event.phase==='error')deepEvidence('deep_diagnostic_native_transfer_phase',{phase:event.phase,chunkCount:active.chunkCount,elapsedMs:Math.round(Date.now()-active.startedAt)},'DEBUG');
   if(event.phase==='error'||event.phase==='aborted')finishDiagnosticTransfer('FAIL',event.message||'Native export cancelled.');
   else if(event.phase==='saved')finishDiagnosticTransfer('PASS','Android confirmed that the diagnostic file was saved.');
   else if(event.phase==='ready'||event.phase==='chunk'){
    armTransferWatchdog(active);
    setTimeout(()=>{if(activeTransfer===active)sendNextDiagnosticChunk()},0);
   }
   return true;
  }
  async function downloadDiagnostics(){
   if(activeTransfer){acceptNativeExportStatus('Diagnostic export already in progress.');return false}
   const exportId=`DIAGNOSTIC_EXPORT:${Date.now()}`;
   subsystemOperationStart('DIAGNOSTIC_EXPORT',exportId,'Export the current diagnostic record.','Prepare and save complete retained evidence without altering diagnostic history.',{eventCountBeforeExport:diagRows().length,module:'diagnostics/diagnostic-export-service',function:'downloadDiagnostics'});
   let payloadObject;
   try{payloadObject=diagPayload()}catch(error){subsystemOperationFinish(exportId,'Diagnostic snapshot preparation failed.','FAIL',{message:error?.message||String(error)});acceptNativeExportStatus('Diagnostic export failed · Could not prepare snapshot.');return false}
   const jsonName=`UPC_List_Builder_Diagnostic_v${APP_VERSION}_${new Date().toISOString().replace(/[:.]/g,'-')}.json`;
   const bridge=nativeBridgeProvider?.(),nativeStreaming=typeof bridge?.beginDiagnosticExport==='function'&&typeof bridge?.appendDiagnosticExportChunk==='function'&&typeof bridge?.finishDiagnosticExport==='function';
   const name=nativeStreaming?jsonName.replace(/\.json$/,'.zip'):jsonName;
   diag('diagnostic_export_requested',{name,platform:nativeStreaming?'android-native':'web',eventCount:payloadObject.eventCount,timelineEventCount:payloadObject.diagnosticCoverage.mergedTimelineEventCount,unfinishedSpanCount:payloadObject.operationSummary.unfinishedSpanCount,currentStartupSessionId:startupSessionId});
   const chunks=createDiagnosticChunkIterator(payloadObject);
   if(nativeStreaming){
    const id='diag_'+Date.now()+'_'+Math.random().toString(36).slice(2,10);
    const active={id,name,bridge,chunks,chunkCount:0,operationId:exportId,watchdog:null,startedAt:Date.now()};
    activeTransfer=active;armTransferWatchdog(active);
    try{bridge.beginDiagnosticExport(id,name)}catch(error){finishDiagnosticTransfer('FAIL',error?.message||String(error))}
    return true;
   }
   // Browser fallback also yields between chunks rather than creating one giant string.
   try{
    const parts=[];let next,count=0;
    while(!(next=chunks.next()).done){parts.push(next.value);if(++count%8===0)await new Promise(resolve=>setTimeout(resolve,0))}
    const blob=new Blob(parts,{type:'application/json'}),a=document.createElement('a');
    a.href=URL.createObjectURL(blob);a.download=name;document.body.appendChild(a);a.click();a.remove();
    setTimeout(()=>URL.revokeObjectURL(a.href),1500);
    subsystemOperationFinish(exportId,'Browser download initiated.','PASS',{name,eventCount:payloadObject.eventCount,module:'diagnostics/diagnostic-export-service'});
    return true;
   }catch(error){subsystemOperationFinish(exportId,'Browser diagnostic export failed.','FAIL',{message:error?.message||String(error)});return false}
  }
  function acceptNativeExportStatus(message){const text=String(message||'');diag('diagnostic_export_status',{message:text});const el=$('diagSummary');if(el)el.textContent=text;return text}
  return Object.freeze({diagPayload,showDiagnostics,downloadDiagnostics,acceptNativeExportStatus,acceptNativeExportTransferEvent,operationSummary,diagnosticJsonFragments,createDiagnosticChunkIterator});
 }
 return Object.freeze({create});
})();
window.UPCDiagnosticExportService=UPCDiagnosticExportService;
