/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/diagnostics/diagnostic-journal.js
 * Owner: Diagnostics Retention
 * Role: Journal service
 * Responsibility: Owns retained web diagnostic history, pruning ceilings, batching, CURRENT-startup marking, and one-time legacy journal migration.
 * Does not own: Diagnostic schema semantics, business state, export interpretation, or raw IndexedDB implementation.
 * Side effects: Maintains in-memory/pending journal state, flush timer, and calls Diagnostic Repository; emergency console only if persistence itself fails.
 * Related code: Event schema belongs to diagnostic-service.js; physical storage belongs to diagnostic-repository.js.
 */
const UPCDiagnosticJournal=(()=>{
 const DIAG_KEY='upcListBuilder.diagnostics.v0.10';
 const DIAG_PREVIOUS_KEYS=['upcListBuilder.diagnostics.v0.09','upcListBuilder.diagnostics.v0.08','upcListBuilder.diagnostics.v0.07'];
 const DIAG_RETAINED_ACTIVE_DAYS=5;
 const DIAG_EMERGENCY_MAX_BYTES=25000000;
 const DIAG_DEEP_MAX_BYTES=50000000;
 const DIAG_NORMAL_MAX_EVENTS=12000;
 const DIAG_DEEP_MAX_EVENTS=30000;
 function create({repository,legacyStorage,timeZone='America/Anchorage',startupSessionId,appVersion,appBuild,getSinceBootMs,getScreen,isAppReady,getDeepMode=()=>false}={}){
  if(!repository||typeof repository.readAll!=='function'||typeof getSinceBootMs!=='function'||typeof getScreen!=='function'||typeof isAppReady!=='function')throw new Error('Diagnostic Journal dependencies are incomplete.');
  const ALASKA_TZ=timeZone;
  let rows=[],pending=[],initialized=false,flushTimer=null,flushPromise=Promise.resolve(),lastPersistenceError=null;
  function alaskaDiagnosticStamp(date=new Date()){
   const parts=new Intl.DateTimeFormat('en-US',{timeZone:ALASKA_TZ,year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',fractionalSecondDigits:3,hour12:false,timeZoneName:'short'}).formatToParts(date),g=t=>parts.find(p=>p.type===t)?.value||'';
   return{date:`${g('year')}-${g('month')}-${g('day')}`,time:`${g('hour')}:${g('minute')}:${g('second')}.${g('fractionalSecond')}`,zone:g('timeZoneName')||'Alaska Time'};
  }
  function diagnosticAlaskaDate(row){
   if(/^\d{4}-\d{2}-\d{2}$/.test(String(row?.alaskaDate||'')))return row.alaskaDate;
   const d=new Date(row?.timestamp||row?.at||row?.timestampEpochMs||0);return Number.isNaN(d.getTime())?'unknown':alaskaDiagnosticStamp(d).date;
  }
  function rowBytes(row){try{return JSON.stringify(row).length}catch{return 0}}
  function errorPriority(row){return ['ERROR','FATAL'].includes(String(row?.severity||'').toUpperCase())?1:0}
  function pruneDiagnosticRows(source){
   const dates=[];for(const row of source){const d=diagnosticAlaskaDate(row);if(d!=='unknown'&&!dates.includes(d))dates.push(d)}
   const keepDates=new Set(dates.slice(-DIAG_RETAINED_ACTIVE_DAYS));let out=source.filter(row=>{const d=diagnosticAlaskaDate(row);return d==='unknown'||keepDates.has(d)});
   const deep=getDeepMode()===true,maxEvents=deep?DIAG_DEEP_MAX_EVENTS:DIAG_NORMAL_MAX_EVENTS,maxBytes=deep?DIAG_DEEP_MAX_BYTES:DIAG_EMERGENCY_MAX_BYTES;
   let totalBytes=out.reduce((n,row)=>n+rowBytes(row),2),dropped=source.length-out.length;
   while(out.length>maxEvents||totalBytes>maxBytes){
    let index=out.findIndex(row=>errorPriority(row)===0);if(index<0)index=0;
    totalBytes-=rowBytes(out[index]);out.splice(index,1);dropped++;
   }
   return{rows:out,dropped,maxEvents,maxBytes,totalBytes,deep};
  }
  function readLegacyRows(){
   if(!legacyStorage)return[];
   for(const key of [DIAG_KEY,...DIAG_PREVIOUS_KEYS]){try{const parsed=JSON.parse(legacyStorage.getItem(key)||'[]');if(Array.isArray(parsed)&&parsed.length)return parsed}catch{}}
   return[];
  }
  async function initialize(){
   if(initialized)return rows;
   let loaded=[];try{loaded=await repository.readAll()}catch(e){lastPersistenceError=String(e?.message||e)}
   if(!loaded.length){
    const legacy=readLegacyRows();
    if(legacy.length){
     loaded=legacy.map(row=>({...row,schemaVersion:row.schemaVersion||1,sourceJournal:row.sourceJournal||'WEB_LEGACY_LOCALSTORAGE',legacyImported:true}));
     try{await repository.replaceAll(loaded);for(const key of [DIAG_KEY,...DIAG_PREVIOUS_KEYS])legacyStorage?.removeItem?.(key)}catch(e){lastPersistenceError=String(e?.message||e)}
    }
   }
   const pruned=pruneDiagnosticRows(loaded);rows=pruned.rows;initialized=true;
   if(pruned.dropped){try{await repository.replaceAll(rows)}catch(e){lastPersistenceError=String(e?.message||e)}}
   return rows;
  }
  function append(row){
   rows.push(row);pending.push(row);
   if(flushTimer===null)flushTimer=setTimeout(()=>{flushTimer=null;flushDiagnosticRows()},500);
   return row;
  }
  function makeRetentionNotice(result){
   const now=new Date(),ak=alaskaDiagnosticStamp(now);
   return{schemaVersion:2,sequence:null,timestamp:now.toISOString(),timestampEpochMs:now.getTime(),alaskaDate:ak.date,alaskaTime:ak.time,alaskaZone:ak.zone,severity:'WARN',sourceJournal:'WEB',startupSessionId,appVersion,appBuild,sinceBootMs:getSinceBootMs(),screen:getScreen(),domain:'DIAGNOSTICS',module:'diagnostics/diagnostic-journal',function:'pruneDiagnosticRows',event:'diagnostic_retention_truncated',phase:'WARN',purpose:'Keep the diagnostic journal within bounded retention limits.',expected:'Journal remains within active-day, event-count, and byte ceilings.',actual:`Dropped ${result.dropped} oldest retained events.`,result:'TRUNCATED',details:{droppedRows:result.dropped,maxEvents:result.maxEvents,maxBytes:result.maxBytes,totalBytes:result.totalBytes,deepDiagnosticMode:result.deep}};
  }
  function flushDiagnosticRows(){
   const batch=pending.splice(0);if(!batch.length)return flushPromise;
   const pruned=pruneDiagnosticRows(rows);let rewrite=pruned.dropped>0;
   if(rewrite){rows=pruned.rows;const notice=makeRetentionNotice(pruned);rows.push(notice)}
   flushPromise=flushPromise.then(async()=>{
    try{if(rewrite)await repository.replaceAll(rows);else await repository.appendBatch(batch);lastPersistenceError=null}
    catch(e){lastPersistenceError=String(e?.message||e);try{console.error('[UPC-DIAG-EMERGENCY] persistence failure',e)}catch{}}
   });
   return flushPromise;
  }
  function markCurrentStartupSession(){
   let currentCount=0,changed=false;
   for(const row of rows){
    if(row?.event!=='startup_session_started')continue;
    const same=row.startupSessionId===startupSessionId;if(same)currentCount++;
    if(Boolean(row.currentStartup)!==same){row.currentStartup=same;changed=true}
    if(row?.details&&typeof row.details==='object'&&Boolean(row.details.currentStartup)!==same){row.details.currentStartup=same;changed=true}
    if(row?.data&&typeof row.data==='object'&&Boolean(row.data.currentStartup)!==same){row.data.currentStartup=same;changed=true}
   }
   if(changed){
    pending=[];
    if(flushTimer!==null){clearTimeout(flushTimer);flushTimer=null}
    const snapshot=[...rows];
    flushPromise=flushPromise.then(()=>repository.replaceAll(snapshot)).catch(e=>{lastPersistenceError=String(e?.message||e)});
   }
   return{rows:[...rows],currentCount,currentStartupSessionId:startupSessionId,invariant:currentCount===1?'PASS':'FAIL'};
  }
  function diagRows(){return [...rows]}
  function clear(){rows=[];pending=[];if(flushTimer!==null){clearTimeout(flushTimer);flushTimer=null}flushPromise=flushPromise.then(()=>repository.clear()).catch(e=>{lastPersistenceError=String(e?.message||e)});return true}
  function beginStartupDiagnosticSession(record){
   append(record);return markCurrentStartupSession();
  }
  function status(){const pruned=pruneDiagnosticRows(rows);return{initialized,eventCount:rows.length,estimatedBytes:pruned.totalBytes,deepDiagnosticMode:getDeepMode()===true,lastPersistenceError,retainedActiveDays:DIAG_RETAINED_ACTIVE_DAYS,maxEvents:pruned.maxEvents,maxBytes:pruned.maxBytes}}
  return Object.freeze({initialize,append,diagRows,markCurrentStartupSession,alaskaDiagnosticStamp,beginStartupDiagnosticSession,flushDiagnosticRows,clear,status});
 }
 return Object.freeze({create,DIAG_KEY,DIAG_PREVIOUS_KEYS,DIAG_RETAINED_ACTIVE_DAYS,DIAG_EMERGENCY_MAX_BYTES,DIAG_DEEP_MAX_BYTES,DIAG_NORMAL_MAX_EVENTS,DIAG_DEEP_MAX_EVENTS});
})();
window.UPCDiagnosticJournal=UPCDiagnosticJournal;
