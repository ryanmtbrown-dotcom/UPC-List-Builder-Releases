/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/diagnostics/diagnostic-operation-service.js
 * Owner: Diagnostics Operation Lifecycle
 * Role: Adapter/service
 * Responsibility: Adapts existing lookup/subsystem/startup operation trackers to canonical operation/span diagnostic records.
 * Does not own: Business success authority, workflow execution, durable persistence, or domain retry policy.
 * Side effects: Maintains in-memory operation trackers and emits structured diagnostics only.
 * Related code: Generic timing state comes from operation-tracker.js; canonical schema belongs to diagnostic-service.js.
 */
const UPCDiagnosticOperationService=(()=>{
 function create({operationTracker,diagnosticService,diagnostic,alaskaStamp,startupNow}={}){
  if(!operationTracker||typeof operationTracker.create!=='function'||typeof alaskaStamp!=='function'||typeof startupNow!=='function')throw new Error('Diagnostic Operation Service dependencies are incomplete.');
  const scoped=diagnosticService?.scope?.({domain:'OPERATIONS',module:'diagnostics/diagnostic-operation-service'})||null;
  const fallback=typeof diagnostic==='function'?diagnostic:()=>{};
  const emit=(event,data,context={})=>scoped?.emit?scoped.emit(event,data,context):fallback(event,{...data,...context});
  const lookupOperationTracker=operationTracker.create();
  const subsystemOperationTracker=operationTracker.create();
  const startupOperationTracker=operationTracker.create({now:startupNow,reuseActive:true,retainCompleted:true});
  const spanId=(kind,id)=>`${id}:${kind}`;
  function baseContext(kind,id,technical={},phase='EVENT'){
   return{operationId:id,spanId:spanId(kind,id),parentSpanId:technical?.parentSpanId||null,phase,module:technical?.module||'diagnostics/diagnostic-operation-service',function:technical?.function||null};
  }
  function lookupOperationStart(id,what,expected,technical={}){
   const now=new Date(),ak=alaskaStamp(now),{state}=lookupOperationTracker.start(id,{what,expected,startedAt:now.toISOString(),startedAlaska:`${ak.date} ${ak.time} ${ak.zone}`,spanId:spanId('LOOKUP',id)});state.startedPerformanceMs=state.startedMs;
   emit('item_search_operation_started',{operationId:id,lifecycle:'STARTED',whatWeAreDoing:what,expectedResult:expected,actualResult:'Operation started.',result:'IN_PROGRESS',timing:{startedAtAlaska:state.startedAlaska,durationMs:null},technical},{...baseContext('LOOKUP',id,technical,'START'),domain:'LOOKUP',purpose:what,expected,inputSummary:technical});return state;
  }
  function lookupOperationFinish(id,actual,result='PASS',technical={}){
   const outcome=lookupOperationTracker.finish(id);if(outcome.missing)return null;const state=outcome.state,now=new Date(),ak=alaskaStamp(now),duration=outcome.durationMs;state.completed=true;
   emit('item_search_operation_completed',{operationId:id,lifecycle:'COMPLETED',whatWeAreDoing:state.what,expectedResult:state.expected,actualResult:actual,result,timing:{startedAtAlaska:state.startedAlaska,finishedAtAlaska:`${ak.date} ${ak.time} ${ak.zone}`,durationMs:duration},technical},{...baseContext('LOOKUP',id,technical,result==='FAIL'?'ERROR':'SUCCESS'),domain:'LOOKUP',purpose:state.what,expected:state.expected,actual,result,durationMs:duration,stateSummary:technical});return duration;
  }
  function lookupOperationObserve(id,what,expected,actual,result='OBSERVED',technical={}){
   const outcome=lookupOperationTracker.observe(id),state=outcome.state;emit('item_search_operation_observation',{operationId:id,whatWeAreDoing:what,expectedResult:expected,actualResult:actual,result,timing:{startedAtAlaska:state?.startedAlaska||null,durationMs:outcome.durationMs},technical},{...baseContext('LOOKUP',id,technical,'EVENT'),domain:'LOOKUP',purpose:what,expected,actual,result,durationMs:outcome.durationMs,stateSummary:technical});
  }
  function subsystemOperationStart(subsystem,id,what,expected,technical={}){
   const now=new Date(),ak=alaskaStamp(now),{state}=subsystemOperationTracker.start(id,{subsystem,what,expected,startedAlaska:`${ak.date} ${ak.time} ${ak.zone}`,spanId:spanId(subsystem,id)});state.startedPerformanceMs=state.startedMs;
   emit('subsystem_operation_started',{subsystem,operationId:id,lifecycle:'STARTED',whatWeAreDoing:what,expectedResult:expected,actualResult:'Operation started.',result:'IN_PROGRESS',timing:{startedAtAlaska:state.startedAlaska,durationMs:null},technical},{...baseContext(subsystem,id,technical,'START'),domain:subsystem,purpose:what,expected,inputSummary:technical});return state;
  }
  function subsystemOperationFinish(id,actual,result='PASS',technical={}){
   const outcome=subsystemOperationTracker.finish(id);if(outcome.missing)return null;const state=outcome.state,now=new Date(),ak=alaskaStamp(now),duration=outcome.durationMs;
   emit('subsystem_operation_completed',{subsystem:state.subsystem,operationId:id,lifecycle:'COMPLETED',whatWeAreDoing:state.what,expectedResult:state.expected,actualResult:actual,result,timing:{startedAtAlaska:state.startedAlaska,finishedAtAlaska:`${ak.date} ${ak.time} ${ak.zone}`,durationMs:duration},technical},{...baseContext(state.subsystem||'SUBSYSTEM',id,technical,result==='FAIL'?'ERROR':'SUCCESS'),domain:state.subsystem||'SUBSYSTEM',purpose:state.what,expected:state.expected,actual,result,durationMs:duration,stateSummary:technical});return duration;
  }
  function startupOperationStart(id,what,expected,technical={}){
   const now=new Date(),ak=alaskaStamp(now),started=startupOperationTracker.start(id,{what,expected,startedAt:now.toISOString(),startedAlaska:`${ak.date} ${ak.time} ${ak.zone}`,spanId:spanId('STARTUP',id)}),state=started.state;state.startedSinceStartupMs=state.startedMs;
   if(started.reused)return state;emit('startup_operation_started',{operationId:id,lifecycle:'STARTED',whatWeAreDoing:what,expectedResult:expected,actualResult:'Operation started.',result:'IN_PROGRESS',timing:{startedAtAlaska:state.startedAlaska,startedSinceStartupMs:state.startedSinceStartupMs,durationMs:null},technical},{...baseContext('STARTUP',id,technical,'START'),domain:'STARTUP',purpose:what,expected,inputSummary:technical});return state;
  }
  function startupOperationFinish(id,actual,result='PASS',technical={}){
   let outcome=startupOperationTracker.finish(id);
   if(outcome.missing){startupOperationStart(id,`Complete startup operation ${id}.`,'The operation completes with an explicitly recorded result.');outcome=startupOperationTracker.finish(id)}
   const state=outcome.state;
   if(outcome.duplicate){emit('startup_operation_duplicate_completion_ignored',{operationId:id,retainedResult:state.result||null,ignoredResult:result,ignoredActualResult:actual},{...baseContext('STARTUP',id,technical,'WARN'),domain:'STARTUP',severity:'WARN',actual,result:'IGNORED'});return outcome.durationMs}
   const now=new Date(),ak=alaskaStamp(now),duration=outcome.durationMs;state.result=result;state.finishedAt=now.toISOString();state.finishedSinceStartupMs=state.finishedMs;
   emit('startup_operation_completed',{operationId:id,lifecycle:'COMPLETED',whatWeAreDoing:state.what,expectedResult:state.expected,actualResult:actual,result,timing:{startedAtAlaska:state.startedAlaska,finishedAtAlaska:`${ak.date} ${ak.time} ${ak.zone}`,startedSinceStartupMs:state.startedSinceStartupMs,finishedSinceStartupMs:state.finishedSinceStartupMs,durationMs:duration},technical},{...baseContext('STARTUP',id,technical,result==='FAIL'?'ERROR':'SUCCESS'),domain:'STARTUP',purpose:state.what,expected:state.expected,actual,result,durationMs:duration,stateSummary:technical});return duration;
  }
  function startupOperationObserve(id,what,expected,actual,result='OBSERVED',technical={}){
   const st=startupOperationStart(id,what,expected,technical);if(result==='PASS'||result==='FAIL'||result==='INCONCLUSIVE')return startupOperationFinish(id,actual,result,technical);
   const observation=startupOperationTracker.observe(id),since=observation.state?observation.state.startedMs+(observation.durationMs||0):startupNow();
   emit('startup_operation_observation',{operationId:id,whatWeAreDoing:what,expectedResult:expected,actualResult:actual,result,timing:{startedAtAlaska:st.startedAlaska,sinceStartupMs:since,durationMs:observation.durationMs},technical},{...baseContext('STARTUP',id,technical,'EVENT'),domain:'STARTUP',purpose:what,expected,actual,result,durationMs:observation.durationMs,stateSummary:technical});
  }
  return Object.freeze({lookupOperationStart,lookupOperationFinish,lookupOperationObserve,subsystemOperationStart,subsystemOperationFinish,startupOperationStart,startupOperationFinish,startupOperationObserve});
 }
 return Object.freeze({create});
})();
window.UPCDiagnosticOperationService=UPCDiagnosticOperationService;
