/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/diagnostics/diagnostic-repository.js
 * Owner: Diagnostics Persistence
 * Role: Repository
 * Responsibility: Owns physical IndexedDB access to the diagnostics store, including batch append/replace/clear.
 * Does not own: Retention policy, event schema, business state, export, or UI.
 * Side effects: Direct IndexedDB diagnostics-store transactions through UPCDB.
 * Related code: Retention belongs to diagnostic-journal.js; no non-diagnostic store access belongs here.
 */
const UPCDiagnosticRepository=(()=>{
 const STORE='diagnostics';
 function create({db}={}){
  if(!db||typeof db.open!=='function'||typeof db.all!=='function'||typeof db.clear!=='function')throw new Error('Diagnostic Repository database dependency is incomplete.');
  async function readAll(){const rows=await db.all(STORE);return (Array.isArray(rows)?rows:[]).sort((a,b)=>Number(a.id||0)-Number(b.id||0))}
  async function appendBatch(rows=[]){
   if(!rows.length)return 0;
   const database=await db.open();
   return new Promise((resolve,reject)=>{
    const tx=database.transaction(STORE,'readwrite'),store=tx.objectStore(STORE);
    for(const row of rows){const {id:_id,...value}=row||{};store.add(value)}
    tx.oncomplete=()=>resolve(rows.length);tx.onerror=()=>reject(tx.error||new Error('Diagnostic batch append failed.'));tx.onabort=()=>reject(tx.error||new Error('Diagnostic batch append aborted.'));
   });
  }
  async function replaceAll(rows=[]){
   const database=await db.open();
   return new Promise((resolve,reject)=>{
    const tx=database.transaction(STORE,'readwrite'),store=tx.objectStore(STORE);store.clear();
    for(const row of rows){const {id:_id,...value}=row||{};store.add(value)}
    tx.oncomplete=()=>resolve(rows.length);tx.onerror=()=>reject(tx.error||new Error('Diagnostic replacement failed.'));tx.onabort=()=>reject(tx.error||new Error('Diagnostic replacement aborted.'));
   });
  }
  async function clear(){await db.clear(STORE);return true}
  return Object.freeze({readAll,appendBatch,replaceAll,clear});
 }
 return Object.freeze({create,STORE});
})();
window.UPCDiagnosticRepository=UPCDiagnosticRepository;
