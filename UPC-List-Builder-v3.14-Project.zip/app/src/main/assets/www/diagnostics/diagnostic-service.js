/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/diagnostics/diagnostic-service.js
 * Owner: Structured Diagnostics
 * Role: Cross-cutting service
 * Responsibility: Owns canonical diagnostic schema, severity/phase normalization, sanitization, operation/span IDs, scoped emitters, Deep Diagnostic Mode, and error source enrichment.
 * Does not own: Business decisions, recovery, persistence mechanics, or domain state.
 * Side effects: Emits to Diagnostic Journal and stores the Deep Diagnostic preference through the injected settings storage.
 * Related code: Retention belongs to journal/repository; callers remain authoritative for business outcomes.
 */
const UPCDiagnosticService=(()=>{
 const DEEP_MODE_KEY='upcListBuilder.deepDiagnostics.v1';
 const LEVELS=new Set(['TRACE','DEBUG','INFO','WARN','ERROR','FATAL']);
 function create({journal,settingsStorage,appVersion,appBuild,startupSessionId,getSinceBootMs,getScreen,timeZone='America/Anchorage'}={}){
  if(!journal||typeof journal.append!=='function'||typeof journal.initialize!=='function')throw new Error('Diagnostic Service journal dependency is incomplete.');
  if(typeof getSinceBootMs!=='function'||typeof getScreen!=='function')throw new Error('Diagnostic Service runtime dependencies are incomplete.');
  let sequence=0,spanCounter=0;
  const activeSpans=new Map();
  function isDeepMode(){try{return settingsStorage?.getItem?.(DEEP_MODE_KEY)==='1'}catch{return false}}
  function setDeepMode(enabled){try{settingsStorage?.setItem?.(DEEP_MODE_KEY,enabled?'1':'0')}catch{};return isDeepMode()}
  function toggleDeepMode(){return setDeepMode(!isDeepMode())}
  function severityFor(event,requested){
   const explicit=String(requested||'').toUpperCase();if(LEVELS.has(explicit))return explicit;
   const value=String(event||'').toLowerCase();if(/fatal/.test(value))return'FATAL';if(/error|failed|failure|exception|rejected/.test(value))return'ERROR';if(/warn|timeout|truncat|degraded|unavailable|blocked/.test(value))return'WARN';return'INFO';
  }
  function phaseFor(event,requested){
   if(requested)return String(requested).toUpperCase();
   const value=String(event||'').toLowerCase();if(/started|begin/.test(value))return'START';if(/completed|complete|success|presented|saved|exported/.test(value))return'SUCCESS';if(/error|failed|failure|exception/.test(value))return'ERROR';if(/warn|timeout|blocked|unavailable|degraded/.test(value))return'WARN';return'EVENT';
  }
  function redactKey(key){return /password|passwd|authorization|bearer|secret|credential(value)?|cookie(value|header)?|token(value)?|saml|assertion/i.test(String(key||''))}
  function sanitizeString(value,limit){let text=String(value??'');text=text.replace(/([?&](?:token|auth|code|saml|assertion|password|session)=)[^&#\s]+/gi,'$1[redacted]');return text.length>limit?text.slice(0,limit)+`…[truncated ${text.length-limit} chars]`:text}
  function sanitize(value,{depth=0,maxDepth=5,stringLimit=isDeepMode()?16000:4000,arrayLimit=isDeepMode()?200:50,keyLimit=isDeepMode()?200:80}={}){
   if(value==null||typeof value==='number'||typeof value==='boolean')return value;
   if(typeof value==='string')return sanitizeString(value,stringLimit);
   if(value instanceof Error)return{name:value.name,message:sanitizeString(value.message,stringLimit),stack:sanitizeString(value.stack||'',isDeepMode()?32000:8000)};
   if(depth>=maxDepth)return'[max-depth]';
   if(Array.isArray(value)){const slice=value.slice(0,arrayLimit).map(x=>sanitize(x,{depth:depth+1,maxDepth,stringLimit,arrayLimit,keyLimit}));if(value.length>arrayLimit)slice.push(`[+${value.length-arrayLimit} more]`);return slice}
   if(typeof value==='object'){
    const out={},entries=Object.entries(value).slice(0,keyLimit);
    for(const [key,item] of entries)out[key]=redactKey(key)?'[redacted]':sanitize(item,{depth:depth+1,maxDepth,stringLimit,arrayLimit,keyLimit});
    if(Object.keys(value).length>keyLimit)out.__truncatedKeys=Object.keys(value).length-keyLimit;
    return out;
   }
   return sanitizeString(value,stringLimit);
  }
  function sourceLocation(error){
   const stack=String(error?.stack||'');const match=stack.match(/(?:at\s+[^\n(]*\s*\()?([^\s()]+\.js):(\d+):(\d+)\)?/);
   return match?{source:match[1],line:Number(match[2]),column:Number(match[3])}:null;
  }
  function normalizeDetails(data){return sanitize(data&&typeof data==='object'?data:{value:data})}
  function createRow(event,data={},context={}){
   const severity=severityFor(event,context.severity);if(['TRACE','DEBUG'].includes(severity)&&!isDeepMode())return null;
   const now=new Date(),ak=journal.alaskaDiagnosticStamp(now),details=normalizeDetails(data),error=context.error instanceof Error?context.error:null;
   const operationId=context.operationId||details.operationId||details.lookupOperationId||details.lookupId||details.requestId||null;
   const row={
    schemaVersion:2,sequence:++sequence,timestamp:now.toISOString(),timestampEpochMs:now.getTime(),alaskaDate:ak.date,alaskaTime:ak.time,alaskaZone:ak.zone,
    severity,sourceJournal:'WEB',startupSessionId,appVersion,appBuild,sinceBootMs:getSinceBootMs(),screen:getScreen(),
    operationId,spanId:context.spanId||details.spanId||null,parentSpanId:context.parentSpanId||details.parentSpanId||null,
    domain:String(context.domain||details.domain||'APPLICATION').toUpperCase(),module:context.module||details.module||'unknown',function:context.function||details.function||details.sourceFunction||details.decisionSourceFunction||null,
    event:String(event||'diagnostic_event'),phase:phaseFor(event,context.phase),purpose:context.purpose||details.whatWeAreDoing||null,
    inputSummary:sanitize(context.inputSummary??details.inputSummary??null),stateSummary:sanitize(context.stateSummary??details.stateSummary??null),
    expected:context.expected??details.expectedResult??details.expected??null,actual:context.actual??details.actualResult??details.actual??null,result:context.result??details.result??null,
    durationMs:Number.isFinite(Number(context.durationMs??details?.timing?.durationMs))?Number(context.durationMs??details.timing.durationMs):null,
    nextState:context.nextState??details.nextState??null,handoff:sanitize(context.handoff??details.handoff??null),details,deepDiagnosticMode:isDeepMode()
   };
   if(error){row.errorCode=context.errorCode||error.code||error.name||'ERROR';row.errorMessage=sanitizeString(error.message||String(error),4000);row.sourceLocation=sourceLocation(error);row.stack=sanitizeString(error.stack||'',isDeepMode()?32000:8000)}
   else if(['ERROR','FATAL'].includes(severity)){
    const legacyStack=typeof details.stack==='string'?details.stack:'',legacyMessage=details.message??details.errorMessage??details.error??null;
    row.errorCode=context.errorCode||details.errorCode||details.code||null;
    row.errorMessage=legacyMessage==null?null:sanitizeString(legacyMessage,4000);
    row.sourceLocation=legacyStack?sourceLocation({stack:legacyStack}):null;
    row.stack=legacyStack?sanitizeString(legacyStack,isDeepMode()?32000:8000):null;
   }
   return row;
  }
  function emit(event,data={},context={}){try{const row=createRow(event,data,context);return row?journal.append(row):null}catch{return null}}
  function scope({domain='APPLICATION',module='unknown'}={}){
   const base={domain,module};
   const diag=(event,data={})=>emit(event,data,base);
   diag.event=(event,data={},context={})=>emit(event,data,{...base,...context});
   diag.start=(spec={})=>{
    const operationId=spec.operationId||`${String(spec.domain||domain).toUpperCase()}-${Date.now()}-${sequence+1}`,spanId=spec.spanId||`${operationId}:S${++spanCounter}`,startedMs=performance.now();
    const handle={operationId,spanId,parentSpanId:spec.parentSpanId||null,startedMs,domain:spec.domain||domain,module:spec.module||module,function:spec.function||null,purpose:spec.purpose||null,expected:spec.expected||null};
    activeSpans.set(spanId,handle);emit(spec.event||'operation_started',spec.details||{},{...handle,phase:'START',severity:spec.severity||'INFO',inputSummary:spec.inputSummary,stateSummary:spec.stateSummary,purpose:handle.purpose,expected:handle.expected});return handle;
   };
   diag.success=(handle,spec={})=>finishSpan(handle,'SUCCESS',spec);
   diag.error=(handle,error,spec={})=>finishSpan(handle,'ERROR',{...spec,error});
   diag.warn=(event,data={},context={})=>emit(event,data,{...base,...context,severity:'WARN',phase:context.phase||'WARN'});
   diag.handoff=(handle,to={},spec={})=>emit(spec.event||'operation_handoff',spec.details||{},{...base,...handle,phase:'HANDOFF',purpose:spec.purpose||handle?.purpose,handoff:{from:{module:handle?.module,function:handle?.function},to},nextState:spec.nextState||null});
   return Object.freeze({diag,emit:(event,data={},context={})=>emit(event,data,{...base,...context})});
  }
  function finishSpan(handle,phase,spec={}){
   if(!handle)return null;const active=activeSpans.get(handle.spanId)||handle,durationMs=Math.max(0,Math.round(performance.now()-Number(active.startedMs||performance.now())));activeSpans.delete(handle.spanId);
   return emit(spec.event||(phase==='ERROR'?'operation_failed':'operation_completed'),spec.details||{},{...active,phase,severity:phase==='ERROR'?'ERROR':(spec.severity||'INFO'),durationMs,purpose:spec.purpose||active.purpose,expected:spec.expected||active.expected,actual:spec.actual||null,result:spec.result||(phase==='ERROR'?'FAIL':'PASS'),error:spec.error||null,errorCode:spec.errorCode||null,nextState:spec.nextState||null});
  }
  async function initialize(){const existing=await journal.initialize();sequence=existing.reduce((max,row)=>Math.max(max,Number(row?.sequence)||0),0);return existing}
  function startupRecord(data={}){
   const scoped=scope({domain:'STARTUP',module:'application/application-shell'});
   const row=createRow('startup_session_started',{...data,currentStartup:true},{domain:'STARTUP',module:'application/application-shell',function:'boot',phase:'START',purpose:'Start a new application diagnostic session.',expected:'Exactly one retained startup session is marked CURRENT.',actual:'Startup diagnostic session created.',result:'IN_PROGRESS'});
   if(row){row.currentStartup=true;journal.beginStartupDiagnosticSession(row)}return row;
  }
  function status(){return{...journal.status(),deepDiagnosticMode:isDeepMode(),schemaVersion:2}}
  return Object.freeze({initialize,emit,scope,isDeepMode,setDeepMode,toggleDeepMode,startupRecord,status,sanitize});
 }
 return Object.freeze({create,DEEP_MODE_KEY});
})();
window.UPCDiagnosticService=UPCDiagnosticService;
