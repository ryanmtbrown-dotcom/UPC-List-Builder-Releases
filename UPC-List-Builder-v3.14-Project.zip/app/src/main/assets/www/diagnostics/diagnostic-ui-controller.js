/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/diagnostics/diagnostic-ui-controller.js
 * Owner: Diagnostics UI
 * Role: Controller
 * Responsibility: Owns Diagnostics overlay binding, copy/download/clear actions, and Deep Diagnostic Mode control.
 * Does not own: Diagnostic schema, retention policy, export assembly, or business state.
 * Side effects: Mutates diagnostics DOM, clipboard, and calls diagnostic/export/journal services.
 * Related code: Export belongs to diagnostic-export-service.js; mode/schema belongs to diagnostic-service.js.
 */
const UPCDiagnosticUiController=(()=>{
 function create({elementById,exportService,journal,diagnosticService,diagnostic,navigatorRef}={}){
  if(typeof elementById!=='function'||!exportService||!journal||!diagnosticService||typeof diagnostic!=='function')throw new Error('Diagnostic UI Controller dependencies are incomplete.');
  const $=elementById,diag=diagnostic;
  function refreshMode(){
   const active=diagnosticService.isDeepMode()===true;
   const overlayButton=$('toggleDeepDiag');if(overlayButton){overlayButton.setAttribute('aria-pressed',active?'true':'false');overlayButton.textContent=`Deep Diagnostics: ${active?'On':'Off'}`}
   const settingsButton=$('settingsDeepDiag');if(settingsButton)settingsButton.setAttribute('aria-pressed',active?'true':'false');
   const settingsStatus=$('settingsDeepDiagStatus');if(settingsStatus)settingsStatus.textContent=active?'On — DEBUG/TRACE evidence enabled':'Off — standard diagnostic evidence only';
  }
  function toggleDeepModeFromUi(source,{showOverlay=false}={}){
   const active=diagnosticService.toggleDeepMode();
   diag('deep_diagnostic_mode_changed',{enabled:active,source,normalMaxBytes:25000000,deepMaxBytes:50000000,normalMaxEvents:12000,deepMaxEvents:30000});
   refreshMode();if(showOverlay)show();
  }
  function show(){refreshMode();exportService.showDiagnostics()}
  function bind(){
   const open=$('diagnostics');if(open)open.onclick=show;
   const close=$('closeDiag');if(close)close.onclick=()=>$('diagOverlay')?.classList.add('hidden');
   const download=$('downloadDiag');if(download)download.onclick=exportService.downloadDiagnostics;
   const settingsDownload=$('settingsDiag');if(settingsDownload)settingsDownload.onclick=exportService.downloadDiagnostics;
   const copy=$('copyDiag');if(copy)copy.onclick=async()=>{
    const status=journal.status();
    if(status.estimatedBytes>1000000){const summary=$('diagSummary');if(summary)summary.textContent='Diagnostic is too large for clipboard. Use Download for complete evidence.';return}
    try{await navigatorRef?.clipboard?.writeText?.(JSON.stringify(exportService.diagPayload(),null,2));diag('diagnostic_copied')}
    catch(e){diag('diagnostic_copy_failed',{message:e?.message||String(e),stack:e?.stack||null})}
   };
   const clear=$('clearDiag');if(clear)clear.onclick=()=>{journal.clear();diag('diagnostic_log_cleared');show()};
   const deep=$('toggleDeepDiag');if(deep)deep.onclick=()=>toggleDeepModeFromUi('diagnostics_overlay',{showOverlay:true});
   const settingsDeep=$('settingsDeepDiag');if(settingsDeep)settingsDeep.onclick=()=>toggleDeepModeFromUi('settings');
   refreshMode();
  }
  return Object.freeze({bind,refreshMode});
 }
 return Object.freeze({create});
})();
window.UPCDiagnosticUiController=UPCDiagnosticUiController;
