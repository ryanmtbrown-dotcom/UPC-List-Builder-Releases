/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/diagnostics/runtime-readiness-service.js
 * Owner: Runtime Readiness Diagnostics
 * Role: Diagnostic service
 * Responsibility: Owns observational checks that required runtime functions/capabilities are present after composition.
 * Does not own: Application readiness authority, feature recovery, business state, or persistence.
 * Side effects: Reads runtime capability presence and emits diagnostics; may report through the native diagnostic bridge.
 * Related code: Startup readiness decisions remain with StartupOrchestrator and subsystem owners.
 */
const UPCRuntimeReadinessService=(()=>{
 function create({elementById,windowRef,documentRef,locationRef,diagnostic,release}={}){
  if(typeof elementById!=='function'||!windowRef||!documentRef||!locationRef||typeof diagnostic!=='function')throw new Error('Runtime Readiness Service dependencies are incomplete.');
  const $=elementById,diag=diagnostic;
  function evaluate(capabilities={}){
   const state=Object.fromEntries(Object.entries(capabilities).map(([key,value])=>[key,typeof value]));
   windowRef.UPCAppRuntimeCapabilities=Object.freeze({...state});
   const missing=Object.entries(state).filter(([,type])=>type!=='function').map(([key])=>key);windowRef.UPCAppRuntimeReady=missing.length===0;
   diag('runtime_asset_fingerprint',{release,indexBuildId:documentRef.querySelector('meta[name="build-id"]')?.content||null,scriptSources:[...documentRef.scripts].map(x=>x.src||'[inline]'),resolverOwnerType:typeof windowRef.UPCAceMiscResolver,requiredFunctions:state,missingRequiredFunctions:missing,runtimeReady:windowRef.UPCAppRuntimeReady,href:locationRef.href});
   if(missing.length){diag('runtime_required_function_missing',{release,missingRequiredFunctions:missing,requiredFunctions:state});const lookup=$('lookup'),bulk=$('aceMiscBulkRun');if(lookup)lookup.disabled=true;if(bulk)bulk.disabled=true}
   return Object.freeze({capabilities:state,missing,ready:windowRef.UPCAppRuntimeReady});
  }
  return Object.freeze({evaluate});
 }
 return Object.freeze({create});
})();
window.UPCRuntimeReadinessService=UPCRuntimeReadinessService;
