# DSD Directory Ownership

OWNS: ACE New DSD workspace/UI orchestration and DSD-specific presentation.

DOMAIN AUTHORITY: `../ace-dsd.js` owns DSD field/workbook rules; `dsd-workspace-controller.js` owns UI/session workflow.

DOES NOT OWN: AceNet lookup, Master/Local catalog authority, identity relationships, raw Work Session persistence, or native file implementation.

PERSISTENCE: DSD state is saved only through the injected Work Session boundary.

OPTIONAL CHATGPT IMPORT: `dsd-chatgpt-import.js` owns opt-in secure device pairing, pending-batch listing, Import into DSD, and owner-scoped Reject Pending. It has no duplicate invoice/item editor. Imported data creates an editable draft through `dsd-workspace-controller.js` and the Work Session service; `ace-dsd.js` remains the single DSD validation, pricing, SKU, and XLSX authority. The adapter preserves explicit item departments and resolves omitted ones from the invoice default. The pairing screen uses shared app design tokens and requires user confirmation before revoking a paired device. Remote acknowledgement follows successful local persistence. It must not read/write raw IndexedDB, AceNet, Master, Local, or identity tables. No credentials belong in browser localStorage or exported diagnostics.

PRICING HANDOFF: Preserve v2.99 source semantics in `../ace-dsd.js` and `dsd-workspace-controller.js`: blank fields are not zero-valued, explicit direct/manual retail is not overwritten, and missing markup retail may be completed when the invoice department is subsequently supplied.
