/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/dsd/dsd-chatgpt-import.js
 * Owner: Optional ChatGPT DSD Import Adapter
 * Role: User-controlled connection, pending batch selection, rejection, and DSD session handoff.
 * Responsibility: Pair a single installation, fetch and reject pending batches, import into the existing DSD editable session.
 * Does not own: DSD domain/pricing, Work Session persistence, raw IndexedDB, OAuth identities, or AceNet/Local catalog.
 * Side effects: DSD import DOM, HTTPS requests on user action, non-secret local preference, native encrypted credential bridge.
 * Related code: DSD business validation remains in ../ace-dsd.js; Work Session persistence remains in ../work-sessions/. Android secrets belong to ChatGPTConnectionVault.
 */
const UPCDsdChatGPTImport=(()=>{
 const PREF_KEY='upc.chatgpt.dsd.enabled.v1';
 const normalizeUrl=value=>{
  const url=new URL(String(value||'').trim());
  if(url.protocol!=='https:'||!url.hostname||url.username||url.password||url.search||url.hash||url.pathname.replace(/\/+$/,'')!=='')throw Error('Enter a secure HTTPS MCP server origin, without a path or credentials.');
  return url.origin;
 };
 function create({domain,elementById,escapeHtml,nativeBridgeProvider,acceptImported,listSessions,fetchFn=fetch,storage=localStorage,diagnostic=()=>{},confirmUser}={}){
  if(!domain||typeof acceptImported!=='function'||typeof listSessions!=='function')throw Error('DSD ChatGPT import dependencies incomplete.');
  const $=elementById,esc=escapeHtml,diag=diagnostic;
  let transient=null,available=[];
  const enabled=()=>storage.getItem(PREF_KEY)==='true';
  const native=()=>nativeBridgeProvider?.();
  function connection(){
   try{const value=native()?.getChatGPTConnection?.();if(value){const parsed=JSON.parse(value);if(parsed.token&&parsed.url)return parsed}}catch(_){}
   return transient;
  }
  function status(message){const el=$('dsdChatGPTStatus');if(el)el.textContent=message}
  function sync(){
   const on=enabled(),conn=connection();
   $('dsdChatGPTEnabled').checked=on;
   $('dsdChatGPTPanel')?.setAttribute('data-connection',!on?'off':conn?'connected':'not-paired');
   $('dsdChatGPTControls').classList.toggle('hidden',!on);
   $('dsdChatGPTActions').classList.toggle('hidden',!on||!conn);
   $('dsdChatGPTPairControls').classList.toggle('hidden',!on||!!conn);
   if(conn&&!$('dsdChatGPTUrl').value)$('dsdChatGPTUrl').value=conn.url;
   status(!on?'Imports off.':conn?'Connected · Ready to check for invoices.':'Not paired · Enter a pairing code below.');
  }
  async function request(path,{method='GET',body,requireConnection=true}={}){
   const conn=connection(),base=requireConnection?conn?.url:normalizeUrl($('dsdChatGPTUrl').value);
   if(!base)throw Error('Connect your device first.');
   const abort=new AbortController(),timeout=setTimeout(()=>abort.abort(),15000);
   try{
    const result=await fetchFn(base+path,{method,cache:'no-store',signal:abort.signal,
      headers:{'Content-Type':'application/json',...(requireConnection?{Authorization:'Bearer '+conn.token}:{})},
      ...(body?{body:JSON.stringify(body)}:{})});
    const payload=await result.json().catch(()=>({}));
    if(!result.ok)throw Error(payload.error||`Connection returned HTTP ${result.status}.`);
    return payload;
   }finally{clearTimeout(timeout)}
  }
  async function pair(){
   if(!enabled())return;
   try{
    const url=normalizeUrl($('dsdChatGPTUrl').value),code=$('dsdChatGPTCode').value.trim();
    if(!/^[A-Za-z0-9_-]{24}$/.test(code))throw Error('Enter the 24-character one-time pairing code from ChatGPT.');
    status('Connecting securely…');
    const data=await request('/api/v1/device/claim',{method:'POST',body:{code},requireConnection:false});
    if(!/^[A-Za-z0-9_-]{43}$/.test(data.token||''))throw Error('Invalid server response.');
    if(typeof native()?.saveChatGPTConnection==='function'){
     if(!native().saveChatGPTConnection(url,data.token))throw Error('Android secure storage rejected the connection.');
    }else{
     transient={url,token:data.token}; // Browser preview: memory only, never localStorage.
    }
    $('dsdChatGPTCode').value='';
    sync();
    if(!native()?.saveChatGPTConnection)status('Connected for this browser session only. Android uses encrypted persistent storage.');
    diag('dsd_chatgpt_paired',{nativeProtected:Boolean(native()?.saveChatGPTConnection)});
   }catch(error){status(error.message||'Connection failed.')}
  }
  async function disconnect(){
   if(!connection())return status('No device connection to revoke.');
   // Revocation affects the paired device, not saved DSD invoices.
   // Fail closed when the app confirmation service is unavailable.
   if(typeof confirmUser!=='function')return status('Confirmation is unavailable. Connection unchanged.');
   if(!await confirmUser(
    'Disconnect ChatGPT from this device? Access will be revoked and pairing will be required again. Saved DSD invoices will not be deleted.',
    'Disconnect ChatGPT',{okLabel:'Disconnect'}))return;
   try{
    await request('/api/v1/device',{method:'DELETE'});
    if(native()?.deleteChatGPTConnection && !native().deleteChatGPTConnection())throw Error('Could not clear Android secure storage.');
    transient=null;available=[];
    $('dsdChatGPTBatchArea').classList.add('hidden');
    sync();
    status('Disconnected · Device access revoked.');
    diag('dsd_chatgpt_disconnected',{});
   }catch(error){status('Could not revoke the device connection: '+error.message+'. Try again before clearing app data.')}
  }
  async function check(){
   if(!enabled()||!connection())return status('Enable and connect ChatGPT first.');
   try{
    status('Checking for invoices…');
    const data=await request('/api/v1/batches'),list=Array.isArray(data.batches)?data.batches:[];
    available=list.slice(0,50);
    const box=$('dsdChatGPTBatchArea'),select=$('dsdChatGPTBatch');
    select.innerHTML=available.map(x=>`<option value="${esc(x.id)}">${esc(x.manufacturer)} · ${esc(x.invoiceNumber)} · ${Number(x.itemCount)||0} items</option>`).join('');
    box.classList.toggle('hidden',!available.length);
    status(available.length?`${available.length} pending invoice${available.length===1?'':'s'} · Choose one below.`:'No pending invoices.');
    diag('dsd_chatgpt_batches_checked',{pendingCount:available.length});
   }catch(error){status('Could not check imports: '+error.message)}
  }
  async function importSelected(){
   const id=$('dsdChatGPTBatch').value;
   if(!available.some(x=>x.id===id))return status('Select a pending invoice.');
   try{
    status('Importing into ACE New DSD Items…');
    const data=await request('/api/v1/batches/'+encodeURIComponent(id));
    if(data.state!=='pending'||!Array.isArray(data.items))throw Error('Invoice is no longer pending.');
    const previous=await listSessions();
    if(!previous.some(x=>x.dsdImportBatchId===id)){
     // Existing DSD invoice and item editor is the only review and edit UI.
     await acceptImported({invoice:data.invoice,items:data.items,warnings:data.warnings,
      dsdImportBatchId:id,sourceFilename:data.sourceFilename});
    }
    // A receipt follows local persistence or an already-saved batch only.
    try{
     await request('/api/v1/batches/'+encodeURIComponent(id)+'/ack',{method:'POST'});
    }catch(error){
     status('Saved on this phone, but the pending receipt was not cleared. Check again to retry: '+error.message);
     return;
    }
    
    available=available.filter(x=>x.id!==id);
    const select=$('dsdChatGPTBatch');
    select.innerHTML=available.map(x=>`<option value="${esc(x.id)}">${esc(x.manufacturer)} · ${esc(x.invoiceNumber)} · ${Number(x.itemCount)||0} items</option>`).join('');
    $('dsdChatGPTBatchArea').classList.toggle('hidden',!available.length);
    status('Invoice imported into ACE New DSD Items. Use the existing editor for changes.');
    diag('dsd_chatgpt_import_confirmed',{batchId:id,importedToExistingEditor:true});
   }catch(error){
    status('Could not import invoice: '+(error.message||'Unknown error')+'. Nothing was acknowledged remotely.');
   }
  }
  async function rejectSelected(){
   const id=$('dsdChatGPTBatch').value,invoice=available.find(x=>x.id===id);
   if(!invoice)return status('Select a pending invoice.');
   if(typeof confirmUser==='function'&&!await confirmUser(
    'Reject pending invoice '+invoice.invoiceNumber+'? This removes only the queued ChatGPT copy, not any saved DSD list.',
    'Reject Pending Invoice',{okLabel:'Reject'}))return;
   try{
    status('Rejecting pending invoice…');
    await request('/api/v1/batches/'+encodeURIComponent(id),{method:'DELETE'});
    await check();
    status('Pending invoice rejected and removed from the queue.');
    diag('dsd_chatgpt_import_rejected',{batchId:id});
   }catch(error){status('Could not reject pending invoice: '+(error.message||'Unknown error'))}
  }
  function bind({on}={}){
   if(typeof on!=='function')throw Error('DSD ChatGPT controller requires event binder.');
   on('dsdChatGPTEnabled','change',e=>{storage.setItem(PREF_KEY,e.target.checked?'true':'false');sync()});
   on('dsdChatGPTPair','click',()=>{void pair()});
   on('dsdChatGPTDisconnect','click',()=>{void disconnect()});
   on('dsdChatGPTCheck','click',()=>{void check()});
   on('dsdChatGPTLoad','click',()=>{void importSelected()});
   on('dsdChatGPTReject','click',()=>{void rejectSelected()});
   sync();
  }
  return Object.freeze({bind,sync,check});
 }
 return Object.freeze({create,normalizeUrl});
})();
window.UPCDsdChatGPTImport=UPCDsdChatGPTImport;
