/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/effective-catalog-resolver.js
 * Owner: Effective Catalog Domain
 * Role: Read-only resolver
 * Responsibility: Owns deterministic official-Master-first then Local catalog selection for normalized SKU/UPC evidence.
 * Does not own: Catalog mutation; network requests; UI; identity writes; Work Sessions.
 * Side effects: Reads injected repository facades and uses a bounded local-read timeout; performs no writes.
 * Related code: Catalog mutation belongs to catalog refresh/maintenance services; presentation belongs to lookup owners.
 */
const UPCEffectiveCatalogResolver=(()=>{
 const keyOf=value=>String(value??'').trim();
 const LOCAL_LOOKUP_TIMEOUT_MS=1500;
 function boundedLocalRead(promise,operation,key){
  return new Promise((resolve,reject)=>{
   let settled=false;
   const timer=setTimeout(()=>{
    if(settled)return;settled=true;
    const error=new Error(`Local catalog ${operation} did not settle within ${LOCAL_LOOKUP_TIMEOUT_MS} ms.`);
    error.code='LOCAL_LOOKUP_TIMEOUT';error.operation=operation;error.key=key;reject(error);
   },LOCAL_LOOKUP_TIMEOUT_MS);
   Promise.resolve(promise).then(value=>{if(settled)return;settled=true;clearTimeout(timer);resolve(value)},error=>{if(settled)return;settled=true;clearTimeout(timer);reject(error)});
  });
 }
 const emptyLayer=mode=>({row:null,count:0,mode});
 const notFound=(key,lookupMode,observations=[])=>({status:'NOT_FOUND',key,row:null,lookupMode,matches:0,provenance:'NONE',masterRecordId:null,activeMasterRecordId:null,localRecordId:null,recordOrigin:null,observations});
 const ambiguous=(key,lookupMode,matches,provenance,observations=[])=>({status:'AMBIGUOUS',key,row:null,lookupMode,matches,provenance,masterRecordId:null,activeMasterRecordId:null,localRecordId:null,recordOrigin:null,observations});
 function found(key,row,{lookupMode,provenance,observations=[]}={}){
  const local=String(provenance||'').startsWith('LOCAL_LIBRARY'),masterId=local?null:(row?.id??null);
  return{status:'FOUND',key,row,lookupMode,matches:1,provenance,masterRecordId:masterId,activeMasterRecordId:masterId,localRecordId:local?(row?.id??null):null,recordOrigin:row?.source||null,observations};
 }
 async function inspectSKUInternal(input){
  const key=keyOf(input);
  if(!key)return{key,master:emptyLayer('SKU_EMPTY'),local:emptyLayer('LOCAL_SKU_EMPTY')};
  const master=await UPCMasterRepository.lookupSKU(key),local=await UPCLocalRepository.lookupSKU(key);
  return{key,master,local};
 }
 async function resolveSKUInternal(input){
  const key=keyOf(input),observations=[];
  if(!key)return notFound(key,'SKU_EMPTY',observations);
  const master=await UPCMasterRepository.lookupSKU(key);
  if(master.count>1)return ambiguous(key,master.mode,master.count,'MASTER_LIBRARY_AMBIGUOUS',observations);
  if(master.row)return found(key,master.row,{lookupMode:master.mode,provenance:'MASTER_LIBRARY',observations});
  const local=await UPCLocalRepository.lookupSKU(key);
  if(local.count>1)return ambiguous(key,local.mode,local.count,'LOCAL_LIBRARY_AMBIGUOUS',observations);
  if(local.row)return found(key,local.row,{lookupMode:local.mode,provenance:'LOCAL_LIBRARY',observations});
  return notFound(key,'MASTER_LOCAL_SKU_MISS',observations);
 }
 async function resolveDirectUPCInternal(input,{format=null}={}){
  const key=keyOf(input),observations=[];
  if(!key)return notFound(key,'EMPTY',observations);
  let master=key.length===11?await UPCMasterRepository.lookupPrefixUPC(key):await UPCMasterRepository.lookupExactUPC(key);
  if(master.count===0&&key.length===13&&key.startsWith('0')&&format==='ean_13'){
   const converted=key.slice(1),fallback=await UPCMasterRepository.lookupExactUPC(converted);
   observations.push({type:'EAN13_TO_UPCA',input:key,converted,count:fallback.count,authority:'MASTER_LIBRARY'});
   if(fallback.count)master={...fallback,mode:'EAN13_TO_UPCA'};
  }
  if(master.count>1)return ambiguous(key,master.mode,master.count,'MASTER_LIBRARY_AMBIGUOUS',observations);
  if(master.row)return found(key,master.row,{lookupMode:master.mode,provenance:'MASTER_LIBRARY',observations});
  let local=key.length===11?await UPCLocalRepository.lookupPrefixUPC(key):await UPCLocalRepository.lookupExactUPC(key);
  if(local.count===0&&key.length===13&&key.startsWith('0')&&format==='ean_13'){
   const converted=key.slice(1),fallback=await UPCLocalRepository.lookupExactUPC(converted);
   observations.push({type:'EAN13_TO_UPCA',input:key,converted,count:fallback.count,authority:'LOCAL_LIBRARY'});
   if(fallback.count)local={...fallback,mode:'LOCAL_EAN13_TO_UPCA'};
  }
  if(local.count>1)return ambiguous(key,local.mode,local.count,'LOCAL_LIBRARY_AMBIGUOUS',observations);
  if(local.row)return found(key,local.row,{lookupMode:local.mode,provenance:'LOCAL_LIBRARY',observations});
  return notFound(key,'MASTER_LOCAL_UPC_MISS',observations);
 }
 const inspectSKU=input=>{const key=keyOf(input);return boundedLocalRead(inspectSKUInternal(input),'inspectSKU',key)};
 const resolveSKU=input=>{const key=keyOf(input);return boundedLocalRead(resolveSKUInternal(input),'resolveSKU',key)};
 const resolveDirectUPC=(input,options={})=>{const key=keyOf(input);return boundedLocalRead(resolveDirectUPCInternal(input,options),'resolveDirectUPC',key)};
 return Object.freeze({resolveSKU,resolveDirectUPC,inspectSKU,LOCAL_LOOKUP_TIMEOUT_MS});
})();
window.UPCEffectiveCatalogResolver=UPCEffectiveCatalogResolver;
