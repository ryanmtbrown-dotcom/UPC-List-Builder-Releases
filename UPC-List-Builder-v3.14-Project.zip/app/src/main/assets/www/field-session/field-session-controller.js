/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/field-session/field-session-controller.js
 * Owner: Field Session Workflow
 * Role: Controller
 * Responsibility: Owns Field Session item/tag/list interaction, unresolved-item workflow, and Field Session-specific session mutations.
 * Does not own: Raw Work Session persistence, catalog identity policy, scanner camera, or export file mechanics.
 * Side effects: Mutates Field Session DOM/session through injected owners and invokes approved presentation/list/identity capabilities.
 * Related code: Persistence belongs to Work Session Service; export belongs to field-session-export-service.js.
 */
const UPCFieldSessionController=(()=>{
 function create({
  elementById,getCurrent,getPending,saveCurrent,newId,normalizeUpc,parseMoney,
  primaryPurposeTags,fieldTags,miscType='ACE_NEW_ITEMS_MISC',diagnostic,alertUser,
  presentationProvider,listItemProvider,libraryWorkflowProvider,unresolvedOriginProvider,recordUnresolved
 }={}){
  if(typeof elementById!=='function'||typeof getCurrent!=='function'||typeof getPending!=='function'||typeof saveCurrent!=='function')throw new Error('Field Session Controller state dependencies are incomplete.');
  if(typeof newId!=='function'||typeof normalizeUpc!=='function'||typeof parseMoney!=='function'||typeof diagnostic!=='function')throw new Error('Field Session Controller utility dependencies are incomplete.');
  const $=elementById,diag=diagnostic,primaryTags=Array.isArray(primaryPurposeTags)?primaryPurposeTags:[],tags=Array.isArray(fieldTags)?fieldTags:[];
  let supplementalPurposeDraft=[];

  function tagId(tag){return tag==='NIF'?'tagNif':tag==='Price Change'?'tagPriceChange':'tagGeneralReview'}
  function applyDefaultTagSelection(){
   supplementalPurposeDraft=[];const selected=tags.includes(getCurrent()?.defaultTag)?getCurrent().defaultTag:null;
   tags.forEach(t=>{const el=$(tagId(t));if(el){el.checked=t===selected;el.closest('label')?.classList.remove('supplementalPurpose')}});
  }
  function configureTags(){applyDefaultTagSelection()}
  function applyNotFoundSystemPurpose(){
   supplementalPurposeDraft=[];tags.forEach(t=>{const el=$(tagId(t));if(el){el.checked=false;el.disabled=true;el.closest('label')?.classList.remove('supplementalPurpose')}});
   const panel=$('tagPanel');if(panel){panel.dataset.systemPurpose='Add to Library';panel.classList.add('systemPurposeLocked')}
   diag('add_to_library_purpose_applied',{upc:getPending()?.upc||null});
  }
  function releaseNotFoundSystemPurpose(){
   tags.forEach(t=>{const el=$(tagId(t));if(el)el.disabled=false});
   const panel=$('tagPanel');if(panel){delete panel.dataset.systemPurpose;panel.classList.remove('systemPurposeLocked')}
  }
  function selectExclusiveTag(tag){
   if(!tags.includes(tag))return;supplementalPurposeDraft=[];
   tags.forEach(t=>{const el=$(tagId(t));if(el){el.checked=t===tag;el.closest('label')?.classList.remove('supplementalPurpose')}});
   diag('item_purpose_selected',{tag,listDefault:getCurrent()?.defaultTag||null});
  }
  function toggleSupplementalPurpose(tag){
   if(!tags.includes(tag))return;const primary=tags.find(t=>$(tagId(t))?.checked&&!supplementalPurposeDraft.includes(t));if(tag===primary)return;
   const i=supplementalPurposeDraft.indexOf(tag);if(i>=0)supplementalPurposeDraft.splice(i,1);else supplementalPurposeDraft.push(tag);
   const el=$(tagId(tag));if(el){el.checked=supplementalPurposeDraft.includes(tag);el.closest('label')?.classList.toggle('supplementalPurpose',el.checked)}
   diag('item_supplemental_purpose_toggled',{tag,enabled:supplementalPurposeDraft.includes(tag),primary});
  }
  function bindPurposeTags(){
   tags.forEach(tag=>{const el=$(tagId(tag));if(!el)return;let timer=null,longPress=false;
    const start=()=>{longPress=false;timer=setTimeout(()=>{longPress=true;toggleSupplementalPurpose(tag)},550)},cancel=()=>{if(timer){clearTimeout(timer);timer=null}};
    el.closest('label')?.addEventListener('pointerdown',start);el.closest('label')?.addEventListener('pointerup',cancel);el.closest('label')?.addEventListener('pointercancel',cancel);
    el.addEventListener('click',e=>{if(longPress){e.preventDefault();e.stopPropagation();longPress=false}});
    el.addEventListener('change',()=>{if(!longPress&&el.checked)selectExclusiveTag(tag)});
   });
  }
  function existingListItemForUPC(upc){const n=normalizeUpc(upc);return getCurrent()?.items?.find(x=>normalizeUpc(x.upc)===n)||null}
  async function addPending({missingLabel=false}={}){
   const current=getCurrent(),pending=getPending();
   if($('itemPreview')?.classList.contains('lookupPending')){diag('add_to_list_blocked',{reason:'lookup_pending'});return{status:'BLOCKED'}}
   if(!current){diag('add_to_list_blocked',{reason:'no_current_list'});alertUser('Start or open a list first.');return{status:'NO_SESSION'}}
   if(current.sessionType===miscType)return{status:'WRONG_WORKSPACE'};
   if(!pending?.upc){diag('add_to_list_blocked',{reason:'no_pending_item'});alertUser('Scan or enter an item first.');return{status:'NO_ITEM'}}
   const isUnresolved=pending.status==='NOT_FOUND'||pending.needsLocalLibrary===true,observedLabel=String($('labelPrice')?.value??'').trim()!=='';const isAddToLibrary=isUnresolved&&!missingLabel&&!observedLabel;
   if(isAddToLibrary){
    const origin=unresolvedOriginProvider?.();if(origin){const entered=String($('upc')?.value||pending.sku||pending.upc||'').trim(),type=pending.requestedIdentifierType==='SKU'?'SKU':'UPC';await recordUnresolved?.(entered,type,origin);$('status').textContent=`Unresolved ${type} saved for follow-up.`;diag('add_to_list_redirected_to_unresolved',{identifier:entered,identifierType:type,origin});return{status:'UNRESOLVED'}}
   }
   const rawLabel=isAddToLibrary?'':String($('labelPrice')?.value??'').trim(),labelPrice=isAddToLibrary?null:(rawLabel===''?null:parseMoney(rawLabel)),libraryPrice=isAddToLibrary?null:parseMoney(pending.price),aceNetPrice=isAddToLibrary?null:parseMoney(pending.aceNetPrice);
   const primary=missingLabel||isUnresolved&&!isAddToLibrary?'General Review':isAddToLibrary?'Add to Library':(tags.find(t=>$(tagId(t))?.checked&&!supplementalPurposeDraft.includes(t))||current.defaultTag||null),supplements=missingLabel||isAddToLibrary?[]:[...supplementalPurposeDraft],itemTags=[];if(primary)itemTags.push(primary);supplements.forEach(t=>{if(!itemTags.includes(t))itemTags.push(t)});if(missingLabel)itemTags.push('Missing Label');
   const existing=existingListItemForUPC(pending.upc);if(existing){diag('duplicate_item_detected_at_commit',{upc:pending.upc,sku:pending.sku||null,listType:current.sessionType});const addDuplicate=await presentationProvider()?.promptDuplicateItem?.(existing);if(!addDuplicate){$('status').textContent='Duplicate item was not added.';return{status:'DUPLICATE_CANCELLED'}}itemTags.push('Duplicate Item')}
   const now=new Date().toISOString(),item={...pending,id:newId(),addedAt:now,scannedAt:now,tags:itemTags,primaryPurpose:primary,supplementalPurposes:supplements,libraryPrice,aceNetPrice,labelPrice};
   const comparisonPrice=UPCPriceAuthority.observedPrice(item);
   item.priceDifference=comparisonPrice!=null&&labelPrice!=null?Math.round((labelPrice-comparisonPrice)*100)/100:null;
   current.items.push(item);
   try{
    await saveCurrent();if(isAddToLibrary)await libraryWorkflowProvider?.()?.enqueueFromListItem?.(current,item);
    $('itemCount').textContent=String(current.items.length);diag('item_added',{listId:current.id,upc:item.upc,labelPrice:item.labelPrice,libraryPrice:item.libraryPrice,aceNetPrice:item.aceNetPrice,tags:item.tags,primaryPurpose:item.primaryPurpose,supplementalPurposes:item.supplementalPurposes,count:current.items.length});
    $('status').textContent=existing?'Duplicate location added to list.':(item.labelPrice==null?'Added to list · no label price captured':'Added to list');$('addToList').disabled=true;if($('markMissingLabel'))$('markMissingLabel').disabled=true;listItemProvider?.()?.renderList?.();return{status:'ADDED',item,count:current.items.length};
   }catch(e){current.items.pop();diag('item_add_failed',{upc:item.upc,name:e?.name,message:e?.message,stack:e?.stack});alertUser(`Could not add item: ${e?.message||e}`);return{status:'FAILED',error:e}}
  }
  function itemPrimaryPurpose(item){return primaryTags.includes(item?.primaryPurpose)?item.primaryPurpose:(primaryTags.find(t=>(item?.tags||[]).includes(t))||'')}
  function editFieldCurrentValue(item,key){if(key==='primaryPurpose')return itemPrimaryPurpose(item);if(key==='missingLabel')return (item.tags||[]).includes('Missing Label')?'Yes':'No';if(key==='duplicateItem')return (item.tags||[]).includes('Duplicate Item')?'Yes':'No';const v=item[key]??item.fields?.[key];return v==null?'':String(v)}
  async function editItemField(index,key,raw){
   const current=getCurrent(),item=current?.items?.[index];if(!item||!key)return null;if(current.sessionType===miscType)return null;
   const before=editFieldCurrentValue(item,key);
   if(key==='primaryPurpose'){const supplements=Array.isArray(item.supplementalPurposes)?item.supplementalPurposes.filter(t=>primaryTags.includes(t)&&t!==raw):[];item.primaryPurpose=raw||null;item.supplementalPurposes=supplements;item.tags=(item.tags||[]).filter(t=>!primaryTags.includes(t));if(raw)item.tags.unshift(raw);supplements.forEach(t=>{if(!item.tags.includes(t))item.tags.push(t)})}
   else if(key==='duplicateItem'){item.tags=(item.tags||[]).filter(t=>t!=='Duplicate Item');if(raw==='Yes')item.tags.push('Duplicate Item')}
   else if(key==='missingLabel'){if(raw!=='Yes'&&raw!=='No')throw new Error('Missing Label must be Yes or No.');item.tags=(item.tags||[]).filter(t=>t!=='Missing Label');if(raw==='Yes')item.tags.push('Missing Label')}
   else if(key==='libraryPrice'||key==='labelPrice'){item[key]=raw===''?null:parseMoney(raw);if(key==='libraryPrice')item.price=item[key]}
   else{item[key]=raw;if(item.fields&&Object.prototype.hasOwnProperty.call(item.fields,key))item.fields[key]=raw}
   const lib=UPCPriceAuthority.observedPrice(item),label=parseMoney(item.labelPrice);item.priceDifference=(lib!=null&&label!=null)?Math.round((label-lib)*100)/100:null;
   await saveCurrent();diag('item_edited',{index,upc:item.upc,field:key,before,after:editFieldCurrentValue(item,key)});return item;
  }
  async function removeItem(index){
   const current=getCurrent();if(!current||current.sessionType===miscType||index<0||index>=current.items.length)return null;
   const [removed]=current.items.splice(index,1);await saveCurrent();await libraryWorkflowProvider?.()?.removeSourceItem?.(current.id,removed?.id);diag('item_removed',{upc:removed?.upc,index,listId:current.id});return removed;
  }
  function closeLabelPricePrompt(){$('labelPricePrompt')?.classList.add('hidden')}
  function promptForScannedLabelPrice(){
   const current=getCurrent(),pending=getPending();if(!current?.promptLabelPriceAfterScan)return Promise.resolve(null);
   return new Promise(resolve=>{const overlay=$('labelPricePrompt'),display=$('labelPricePromptValue'),item=$('labelPricePromptItem'),pad=$('labelPriceKeypad');if(!overlay||!display||!pad){resolve(null);return}
    item.textContent=pending?.description||`UPC ${pending?.scannedUpc||pending?.upc||'unknown'}`;const identity=$('labelPricePromptSku');if(identity)identity.textContent=pending?.status==='FOUND'&&pending?.sku?`SKU ${pending.sku}`:`SKU Not Found · UPC ${pending?.scannedUpc||pending?.upc||'unknown'}`;let raw='';const render=()=>{display.textContent=raw||'0.00';display.classList.toggle('is-empty',!raw)};render();overlay.classList.remove('hidden');let finished=false;
    const finish=value=>{if(finished)return;finished=true;closeLabelPricePrompt();pad.onclick=null;$('skipLabelPrice').onclick=null;$('saveLabelPrice').onclick=null;$('missingLabelFromPrompt').onclick=null;resolve(value)};
    pad.onclick=e=>{const key=e.target.closest('[data-price-key]')?.dataset.priceKey;if(!key)return;if(key==='backspace')raw=raw.slice(0,-1);else if(key==='clear')raw='';else if(key==='.'&&!raw.includes('.'))raw=(raw||'0')+'.';else if(/^\d$/.test(key)){const decimals=raw.includes('.')?raw.split('.')[1].length:0;if(decimals<2&&raw.length<9)raw+=key}render()};
    $('skipLabelPrice').onclick=()=>finish(null);$('missingLabelFromPrompt').onclick=()=>finish({missingLabel:true});$('saveLabelPrice').onclick=()=>{const value=parseMoney(raw);if(value==null||value<0){display.classList.add('invalid');setTimeout(()=>display.classList.remove('invalid'),350);return}finish(value)};diag('label_price_integrated_keypad_opened',{upc:pending?.upc,sku:pending?.sku});
   });
  }
  async function applyScannedLabelPricePrompt(){
   const current=getCurrent(),pending=getPending(),generation=presentationProvider()?.currentGeneration?.(),value=await promptForScannedLabelPrice();
   const superseded=Number.isInteger(generation)?presentationProvider()?.currentGeneration?.()!==generation:getPending()!==pending;
   if(superseded||getCurrent()?.id!==current?.id){diag('label_price_prompt_stale_discarded',{upc:pending?.upc});return}
   if(value?.missingLabel===true){if($('labelPrice'))$('labelPrice').value='';const saved=await listItemProvider?.()?.addPending?.({missingLabel:true});diag('missing_label_prompt_save',{upc:pending?.scannedUpc||pending?.upc,sku:pending?.sku||null,status:saved?.status||'NO_HANDLER'});return}
   if(value!=null&&$('labelPrice')){$('labelPrice').value=Number(value).toFixed(2);$('manualPriceEntry')?.classList.remove('hidden');presentationProvider()?.updatePriceDifference?.();const libraryPrice=UPCPriceAuthority.observedPrice(pending),different=libraryPrice!=null&&Math.abs(Number(value)-libraryPrice)>=0.005;diag('manual_label_price_captured',{upc:pending?.upc,labelPrice:value,libraryPrice,different,autoAdd:current?.autoAddPriceDifference===true});if(different&&current?.autoAddPriceDifference===true){selectExclusiveTag('Price Change');$('status').textContent=`Label price $${Number(value).toFixed(2)} differs from library price. Adding to Price Change…`;await listItemProvider?.()?.addPending?.();diag('price_difference_auto_added',{labelPrice:value,libraryPrice});return}$('status').textContent=different?`Label price $${Number(value).toFixed(2)} recorded. Price differs; review and add the item.`:`Label price $${Number(value).toFixed(2)} matches the library price.`}
   else if(current?.promptLabelPriceAfterScan){if($('labelPrice'))$('labelPrice').value='';$('manualPriceEntry')?.classList.remove('hidden');presentationProvider()?.updatePriceDifference?.();diag('manual_label_price_skipped',{upc:pending?.upc})}
  }
  function bind({on}={}){bindPurposeTags();if(typeof on==='function')on('labelPrice','input',()=>presentationProvider()?.updatePriceDifference?.())}
  return Object.freeze({bind,configureTags,applyDefaultTagSelection,applyNotFoundSystemPurpose,releaseNotFoundSystemPurpose,selectExclusiveTag,addPending,editItemField,removeItem,existingListItemForUPC,applyScannedLabelPricePrompt,editFieldCurrentValue});
 }
 return Object.freeze({create});
})();
window.UPCFieldSessionController=UPCFieldSessionController;
