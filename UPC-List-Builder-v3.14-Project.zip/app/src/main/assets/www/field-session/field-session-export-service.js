/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/field-session/field-session-export-service.js
 * Owner: Field Session Export
 * Role: Export service
 * Responsibility: Owns ordinary Field Session XLSX/package composition, selected-Master-field row shaping, forced ACE MISC formatter handoff, purpose-specific filenames, diagnostics, and export delivery handoff.
 * Does not own: Master/ACE MISC field identity, Settings persistence, ACE MISC row/layout semantics, DSD semantics, Work Session mutation, raw native filesystem implementation, or catalog writes.
 * Side effects: Reads current session/export preferences and verified local SKU-to-UPC relationship evidence, builds XLSX/ZIP bytes, emits export diagnostics, and hands output to the injected standard file-delivery boundary.
 * Related code: Field identity belongs to catalog/standard-export-schema.js; exact forced ACE MISC formatting belongs to ace-misc.js; Settings persistence belongs to application/settings-repository.js; generic ordinary workbook writing belongs to xlsx-exporter.js.
 */
const UPCFieldSessionExportService=(()=>{
 const EXPORT_BASE_KEY='upcListBuilder.lastExportBase.v1';
 const PRICE_CHANGE_FIELDS=Object.freeze(['Label Price','Price Difference']);
 const CURRENCY_FIELDS=new Set(['Retailer Each Cost','Ace Retail Price','Level 1 Retail Price','Level 2 Retail Price','AH.COM Retail Price','Label Price','Price Difference','Register Price']);
 const TEXT_FIELDS=new Set(['ACE SKU','RSC','Article Status','MFG #','Velocity Code','UPC/EAN','Ace Vendor Number','Commodity Group','Merchandise Class Number','Product Group Number','Product Definition Code','Discovery Item','Country of Origin']);

 function create({getCurrentSession,exportTags,dateStamp,promptUser,alertUser,diagnostic,startOperation,finishOperation,storage,zipCtor,xlsxExporter,fileDelivery,exportSchema,getExportPreferences,aceMiscFormatter,getKnownUpcsForSku}={}){
  if(typeof getCurrentSession!=='function'||!Array.isArray(exportTags)||typeof dateStamp!=='function')throw new Error('Field Session Export Service session dependencies are incomplete.');
  if(typeof promptUser!=='function'||typeof alertUser!=='function'||typeof startOperation!=='function'||typeof finishOperation!=='function'||!storage||typeof zipCtor!=='function'||!xlsxExporter||typeof fileDelivery?.deliverBytes!=='function')throw new Error('Field Session Export Service export dependencies are incomplete.');
  if(!exportSchema||!Array.isArray(exportSchema.MASTER_HEADERS)||!Array.isArray(exportSchema.ACE_MISC_HEADERS)||typeof exportSchema.normalizeMasterSelection!=='function'||typeof exportSchema.defaultMasterSelection!=='function'||typeof getExportPreferences!=='function'||typeof aceMiscFormatter?.buildAvailableFormat!=='function'||typeof getKnownUpcsForSku!=='function')throw new Error('Field Session Export Service schema/settings/MISC-format/identity dependencies are incomplete.');
  const diag=typeof diagnostic==='function'?diagnostic:()=>{};

  function safeExportName(v){return String(v||'').trim().replace(/[\\/:*?"<>|]+/g,'_').replace(/\s+/g,' ').slice(0,90)}
  function suggestedExportName(){let previous='';try{previous=storage.getItem(EXPORT_BASE_KEY)||''}catch(e){diag('export_base_read_failed',{name:e?.name,message:e?.message});}return `${previous||'Field Export'} - ${dateStamp()}`}
  function rememberExportBase(full){const dateSuffix=new RegExp(`\\s*-\\s*${dateStamp().replace(/-/g,'\\-')}$`),base=String(full).replace(dateSuffix,'').trim();if(!base)return false;try{storage.setItem(EXPORT_BASE_KEY,base);return true}catch(e){diag('export_base_cache_write_failed',{name:e?.name,message:e?.message,nonFatal:true});return false}}

  async function currentExportPreferences(){
   const prefs=await getExportPreferences(),headers=Array.isArray(prefs?.headers)?exportSchema.normalizeMasterSelection(prefs.headers):exportSchema.defaultMasterSelection(),forceAceMiscFormat=prefs?.forceAceMiscFormat!==false;
   diag('field_session_export_preferences_resolved',{selectedMasterCount:headers.length,totalMasterFields:exportSchema.MASTER_HEADERS.length,forceAceMiscFormat,aceMiscColumnCount:exportSchema.ACE_MISC_HEADERS.length,preferenceSource:prefs?'SAVED':'DEFAULT'});
   return{headers,forceAceMiscFormat};
  }
  function pickField(fields,header){const key=Object.keys(fields||{}).find(name=>String(name).trim().toLowerCase()===String(header).trim().toLowerCase());return key===undefined?'':fields[key]??''}
  function firstNonblank(...values){for(const value of values){if(value!==null&&value!==undefined&&String(value).trim()!=='')return value}return''}
  function standardValue(item,header){
   const fields=item?.fields||{},stored=pickField(fields,header);
   switch(header){
    case'ACE SKU':return firstNonblank(item?.sku,stored);
    case'Description':return firstNonblank(item?.description,stored);
    case'Order Multiple':return firstNonblank(item?.orderMultiple,stored);
    case'Retail Units':return firstNonblank(item?.retailUnits,stored);
    case'UPC/EAN':return firstNonblank(item?.upc,stored);
    case'Level 2 Retail Price':return item?.recordOrigin==='THIRD_PARTY_VENDOR'?stored:(UPCPriceAuthority.observedPrice(item)??'');
    case'Ace Retail Price':return stored;
    default:return stored;
   }
  }
  function numericOrBlank(value){if(value===null||value===undefined||String(value).trim()==='')return'';const n=Number(String(value).replace(/[$,]/g,''));return Number.isFinite(n)?n:value}
  function workflowFieldsForPurpose(purpose){return purpose==='Price Change'?[...PRICE_CHANGE_FIELDS]:[]}
  function workflowValues(item,purpose){
   if(purpose!=='Price Change')return[];
   const label=(item?.labelPrice!==null&&item?.labelPrice!==undefined&&item?.labelPrice!==''&&Number.isFinite(Number(item.labelPrice)))?Number(item.labelPrice):'';
   const verified=UPCPriceAuthority.observedPrice(item),library=verified===null?'':verified;
   const difference=(library!==''&&label!=='')?Number((label-library).toFixed(2)):'';
   return[label,difference];
  }
  function registerPriceForItem(item,upc){
   const prices=item?.registerPricesByUpc;
   if(!prices||typeof prices!=='object'||!Object.prototype.hasOwnProperty.call(prices,String(upc??'')))return'';
   // A UPC confirmed NIF has no scanned register price, even if old data
   // accidentally retained a stale numeric value for the same UPC.
   if(Array.isArray(item?.registerNifUpcs)&&item.registerNifUpcs.includes(String(upc??'')))return'';
   const value=prices[String(upc??'')];
   if(value==null||String(value).trim()==='')return'';
   const n=Number(value);return Number.isFinite(n)&&n>=0&&n<=9999999.99?Math.round(n*100)/100:'';
  }
  async function registerReviewEntries(rows,preferences){
   const originals=Array.isArray(rows)?rows:[],force=preferences?.forceAceMiscFormat!==false;
   // UPC expansion may create temporary enriched copies. Never attach editable
   // register observations to those copies: keep the original persisted item.
   const enriched=force?await rowsWithKnownUpcs(originals):originals;
   return originals.flatMap((item,index)=>{
    const upcs=force?aceMiscFormatter.rowsFromAvailableItems([enriched[index]]).map(row=>String(row[21]??'')):[String(item.upc??'')];
    return upcs.filter(Boolean).map(upc=>({item,upc}));
   });
  }
  function columnIndexes(headers,names){const wanted=new Set(names),out=[];headers.forEach((header,index)=>{if(wanted.has(header))out.push(index)});return out}

  async function rowsWithKnownUpcs(rows){
   const out=[];
   for(const item of (Array.isArray(rows)?rows:[])){
    const sku=String(item?.sku??'').trim();if(!sku){out.push(item);continue}
    try{const known=await getKnownUpcsForSku(sku),upcs=(Array.isArray(known)?known:[]).map(row=>row?.upcKey??row?.upc).filter(value=>String(value??'').trim()!=='');out.push(upcs.length?{...item,allUpcs:[...(Array.isArray(item?.allUpcs)?item.allUpcs:[]),...upcs]}:item);diag('field_session_export_known_upcs_resolved',{sku,knownUpcCount:upcs.length,source:'LOCAL_IDENTITY_RELATIONSHIPS'})}
    catch(e){diag('field_session_export_known_upcs_read_failed',{sku,name:e?.name,message:e?.message,stack:e?.stack,nonFatal:true});out.push(item)}
   }
   return out;
  }

  async function workbookForRows(rows,purpose,preferencesOverride=null,{includeRegisterPrice=false}={}){
    // Field observations are not catalog records. Keep the exact ACE MISC format unchanged.
    if(purpose==='Missing Label'){
     const headers=['UPC/EAN','ACE SKU','Description','Label Price','Library Price','Lookup Status'];
     const data=rows.map(item=>{
      const observedUpc=firstNonblank(item?.scannedUpc,item?.upc);
      const label=numericOrBlank(item?.labelPrice),library=numericOrBlank(UPCPriceAuthority.observedPrice(item));
      return[observedUpc,firstNonblank(item?.sku),firstNonblank(item?.description),label,library,firstNonblank(item?.status,item?.lookupStatus,'NOT_FOUND')];
     });
     diag('field_session_export_missing_labels_shaped',{rowCount:rows.length,columnCount:headers.length,observationsOnly:true});
     return xlsxExporter.build(headers,data,{sheetName:'Missing Label',textColumns:[0,1],currencyColumns:[3,4],maxColumnWidth:60});
    }
   if(purpose==='NIF'){
    // NIF discovered during register review is UPC-specific, not an entire SKU's known UPC set.
    rows=rows.flatMap(item=>Array.isArray(item?.registerNifUpcs)&&item.registerNifUpcs.length?item.registerNifUpcs.map(upc=>({...item,upc,scannedUpc:upc,rawUPC:upc,allUpcs:[upc],upcs:[],aceNetUpcs:[],catalog:null,aceNetCatalog:null,fields:{...item.fields,'UPC/EAN':upc,UPC:upc},nifExportUpc:upc})): [item]);
   }
   const prefs=preferencesOverride&&typeof preferencesOverride==='object'?{headers:exportSchema.normalizeMasterSelection(preferencesOverride.headers),forceAceMiscFormat:preferencesOverride.forceAceMiscFormat===true}:await currentExportPreferences();
   if(prefs.forceAceMiscFormat){
    const formatRows=purpose==='NIF'?await Promise.all(rows.map(async item=>item.nifExportUpc?item:(await rowsWithKnownUpcs([item]))[0])):await rowsWithKnownUpcs(rows);
    const priceChange=purpose==='Price Change',includeRegister=priceChange&&includeRegisterPrice===true;
    const trailingColumn=priceChange?{header:'Label Price',valueForItem:item=>workflowValues(item,'Price Change')[0]}:null;
    const trailingColumns=includeRegister?[trailingColumn,{header:'Register Price',valueForItem:(item,upc)=>registerPriceForItem(item,upc)}]:null;
    // Price Change shows the actual comparison authority in the Level 2 column:
    // current verified AceNet Store Retail, otherwise the saved Master/Local Level 2.
    // Do not change other MISC columns or the canonical ACE MISC workspace export.
    const pricedRows=priceChange?formatRows.map(item=>{
     if(item?.recordOrigin==='THIRD_PARTY_VENDOR')return item;
     const currentLevel2=UPCPriceAuthority.observedPrice(item);
     return currentLevel2===null?item:{...item,fields:{...item.fields,'Level 2 Retail Price':currentLevel2.toFixed(2)}};
    }):formatRows;
    const workbook=await aceMiscFormatter.buildAvailableFormat(pricedRows,includeRegister?{trailingColumns}:{trailingColumn});
    diag('field_session_export_workbook_shaped',{purpose,rowCount:rows.length,formatRowSourceCount:formatRows.length,format:'ACE_MISC_FORCED',columnCount:exportSchema.ACE_MISC_HEADERS.length+(priceChange?1:0)+(includeRegister?1:0),selectedMasterHeaders:prefs.headers,workflowHeaders:priceChange?(includeRegister?['Label Price','Register Price']:['Label Price']):[]});
    return workbook;
   }
   const masterHeaders=prefs.headers,includeRegister=purpose==='Price Change'&&includeRegisterPrice===true,workflowHeaders=workflowFieldsForPurpose(purpose),headers=[...masterHeaders,...workflowHeaders,...(includeRegister?['Register Price']:[])];
   if(!headers.length)throw new Error('Select at least one List Export Field in Settings before exporting this list.');
   const data=rows.map(item=>[...masterHeaders.map(header=>CURRENCY_FIELDS.has(header)?numericOrBlank(standardValue(item,header)):standardValue(item,header)),...workflowValues(item,purpose),...(includeRegister?[registerPriceForItem(item,String(item.upc??''))]:[])]);
   const textColumns=columnIndexes(headers,TEXT_FIELDS),currencyColumns=columnIndexes(headers,CURRENCY_FIELDS);
   diag('field_session_export_workbook_shaped',{purpose,rowCount:rows.length,format:'SELECTED_MASTER_FIELDS',columnCount:headers.length,selectedMasterHeaders:masterHeaders,workflowHeaders});
   return xlsxExporter.build(headers,data,{sheetName:purpose||'UPC List',textColumns,currencyColumns,headerFillColumns:purpose==='Price Change'?headers.map((header,index)=>CURRENCY_FIELDS.has(header)&&(['Label Price','Price Difference','Register Price'].includes(header))?index:-1).filter(index=>index>=0):[],maxColumnWidth:60});
  }

  async function exportTaggedPackage({includeRegisterPrice=false}={}){
   const operationId=`FIELD_SESSION_EXPORT:${Date.now()}:${Math.random().toString(36).slice(2,8)}`,current=getCurrentSession(),captures=current?.captures||[];
   startOperation('FIELD_SESSION_EXPORT',operationId,'Build and deliver the ordinary tagged export package.','Each populated purpose receives a purpose-named XLSX using either the saved selected Master fields or the exact ACE MISC layout when Force ACE MISC Format is enabled; NIF captures remain packaged separately.',{listId:current?.id||null,sessionType:current?.sessionType||null,itemCount:current?.items?.length||0,captureCount:captures.length});
   try{
    if(!current||(!current.items?.length&&!captures.length)){finishOperation(operationId,'No ordinary list items or NIF captures were available to export.','INCONCLUSIVE',{reason:'empty_session'});alertUser('There are no list items or captured NIF labels to export.');return{status:'EMPTY'}}
    const requested=await promptUser('Name this export package:',suggestedExportName(),'Export Package');if(requested===null){finishOperation(operationId,'Export package naming was cancelled.','INCONCLUSIVE',{reason:'user_cancelled'});return{status:'CANCELLED'}}
    const packageName=safeExportName(requested);if(!packageName){finishOperation(operationId,'Export package name was blank after normalization.','INCONCLUSIVE',{reason:'invalid_package_name'});alertUser('Enter a name for the export.');return{status:'INVALID_NAME'}}
    rememberExportBase(packageName);
    const preferences=await currentExportPreferences(),zip=new zipCtor(),root=zip.folder(packageName),date=dateStamp();let fileCount=0;
    for(const tag of exportTags){
     const rows=(current.items||[]).filter(x=>(x.tags||[]).includes(tag));
     if(tag==='NIF'){
      if(rows.length||captures.length){
       const nif=root.folder('NIF');
       if(rows.length){nif.file(`NIF - ${date}.xlsx`,await workbookForRows(rows,'NIF',preferences,{includeRegisterPrice}));fileCount++}
       captures.forEach((capture,index)=>{nif.file(`NIF_Capture_${String(index+1).padStart(3,'0')}.jpg`,capture.jpegBase64,{base64:true});fileCount++});
      }
     }else if(rows.length){root.file(`${tag} - ${date}.xlsx`,await workbookForRows(rows,tag,preferences,{includeRegisterPrice}));fileCount++}
    }
    if(!fileCount){finishOperation(operationId,'No populated purpose workbooks or NIF captures were available after export classification.','INCONCLUSIVE',{reason:'no_exportable_purpose'});alertUser('No tagged items or NIF captures are available to export.');return{status:'EMPTY'}}
    const bytes=await zip.generateAsync({type:'uint8array',compression:'DEFLATE',compressionOptions:{level:6}}),filename=`${packageName}.zip`;
    await Promise.resolve(fileDelivery.deliverBytes(bytes,filename,'application/zip'));
    diag('tagged_package_export_requested',{filename,fileCount,captures:captures.length,selectedMasterHeaders:preferences.headers,forceAceMiscFormat:preferences.forceAceMiscFormat});
    finishOperation(operationId,`Delivered ${filename} with ${fileCount} export file(s).`,'PASS',{filename,fileCount,captureCount:captures.length,selectedMasterHeaders:preferences.headers,forceAceMiscFormat:preferences.forceAceMiscFormat});return{status:'EXPORTED',filename,fileCount};
   }catch(e){finishOperation(operationId,`Field Session export failed: ${e?.message||e}.`,'FAIL',{name:e?.name||null,message:e?.message||String(e)});diag('tagged_package_export_failed',{name:e?.name,message:e?.message,stack:e?.stack});alertUser(`Export failed: ${e?.message||e}`);return{status:'FAILED',error:e}}
  }

  async function exportCurrentXlsx(tagFilter=null,{includeRegisterPrice=false}={}){
   const operationId=`FIELD_SESSION_XLSX:${Date.now()}:${Math.random().toString(36).slice(2,8)}`,current=getCurrentSession(),purpose=tagFilter||'UPC List';
   startOperation('FIELD_SESSION_EXPORT',operationId,'Build and deliver one ordinary XLSX workbook.','The workbook uses the saved selected Master-field layout or exact ACE MISC layout according to the current Force ACE MISC Format preference.',{listId:current?.id||null,purpose});
   try{
    if(!current?.items?.length){finishOperation(operationId,'No items were available for direct XLSX export.','INCONCLUSIVE',{reason:'empty_session'});alertUser('There are no items in the current list to export.');return}
    const rows=current.items.filter(item=>!tagFilter||(item.tags||[]).includes(tagFilter));if(!rows.length){finishOperation(operationId,`No ${purpose} items were available for direct XLSX export.`,'INCONCLUSIVE',{reason:'no_matching_items',purpose});alertUser(`There are no ${tagFilter||''} items to export.`);return}
    const preferences=await currentExportPreferences(),bytes=await workbookForRows(rows,purpose,preferences,{includeRegisterPrice}),suffix=tagFilter?`_${tagFilter.replace(/\s+/g,'_')}`:'',filename=`UPC_List_${(current.name||'Export').replace(/[^A-Za-z0-9._-]+/g,'_')}${suffix}.xlsx`;
    await Promise.resolve(fileDelivery.deliverBytes(bytes,filename,xlsxExporter.MIME));diag('list_export_requested',{filename,rows:rows.length,tagFilter,format:preferences.forceAceMiscFormat?'ACE_MISC_FORCED':'SELECTED_MASTER_FIELDS',selectedMasterHeaders:preferences.headers});finishOperation(operationId,`Delivered ${filename}.`,'PASS',{filename,rowCount:rows.length,purpose,forceAceMiscFormat:preferences.forceAceMiscFormat,selectedMasterHeaders:preferences.headers});
   }catch(e){finishOperation(operationId,`Direct XLSX export failed: ${e?.message||e}.`,'FAIL',{name:e?.name||null,message:e?.message||String(e)});diag('list_export_failed',{name:e?.name,message:e?.message,stack:e?.stack});alertUser(`Export failed: ${e?.message||e}`);return{status:'FAILED',error:e}}
  }

  return Object.freeze({safeExportName,suggestedExportName,rememberExportBase,currentExportPreferences,rowsWithKnownUpcs,registerReviewEntries,registerPriceForItem,workbookForRows,exportTaggedPackage,exportCurrentXlsx});
 }
 return Object.freeze({create,EXPORT_BASE_KEY});
})();
window.UPCFieldSessionExportService=UPCFieldSessionExportService;
