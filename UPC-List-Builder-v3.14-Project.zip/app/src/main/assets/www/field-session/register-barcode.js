/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/field-session/register-barcode.js
 * Owner: Field Session Register Barcode
 * Role: Domain presentation utility
 * Responsibility: Renders deterministic offline EAN/UPC and numeric Code 128 SVG from exact observed UPC values.
 * Does not own: Catalog identity validation, barcode scanning, file delivery, or Work Session state.
 * Side effects: Only mutates an injected SVG DOM node; no network, catalog, or persistence access.
 * Related code: Register collection and lookup viewing belong to register-price-controller.js.
 */
const UPCRegisterBarcode=(()=>{
 const L=['0001101','0011001','0010011','0111101','0100011','0110001','0101111','0111011','0110111','0001011'];
 const G=['0100111','0110011','0011011','0100001','0011101','0111001','0000101','0010001','0001001','0010111'];
 const R=['1110010','1100110','1101100','1000010','1011100','1001110','1010000','1000100','1001000','1110100'];
 const PARITY=['LLLLLL','LLGLGG','LLGGLG','LLGGGL','LGLLGG','LGGLLG','LGGGLL','LGLGLG','LGLGGL','LGGLGL'];
 const CODE128='212222,222122,222221,121223,121322,131222,122213,122312,132212,221213,221312,231212,112232,122132,122231,113222,123122,123221,223211,221132,221231,213212,223112,312131,311222,321122,321221,312212,322112,322211,212123,212321,232121,111323,131123,131321,112313,132113,132311,211313,231113,231311,112133,112331,132131,113123,113321,133121,313121,211331,231131,213113,213311,213131,311123,311321,331121,312113,312311,332111,314111,221411,431111,111224,111422,121124,121421,141122,141221,112214,112412,122114,122411,142112,142211,241211,221114,413111,241112,134111,111242,121142,121241,114212,124112,124211,411212,421112,421211,212141,214121,412121,111143,111341,131141,114113,114311,411113,411311,113141,114131,311141,411131,211412,211214,211232,2331112'.split(',');
 const validDigits=upc=>/^\d+$/.test(upc);
 function checksum(digits){let sum=0;for(let i=digits.length-1,weight=3;i>=0;i--,weight=weight===3?1:3)sum+=Number(digits[i])*weight;return(10-sum%10)%10}
 function withValidCheck(digits){return checksum(digits.slice(0,-1))===Number(digits.at(-1))}
 function eanBits(digits,format){
  if(format==='UPC'){
   const left=digits.slice(0,6).split('').map(x=>L[+x]).join(''),right=digits.slice(6).split('').map(x=>R[+x]).join('');
   return '101'+left+'01010'+right+'101';
  }
  if(format==='EAN13'){
   const modes=PARITY[Number(digits[0])];
   const left=digits.slice(1,7).split('').map((x,i)=>(modes[i]==='L'?L:G)[+x]).join('');
   const right=digits.slice(7).split('').map(x=>R[+x]).join('');
   return '101'+left+'01010'+right+'101';
  }
  const left=digits.slice(0,4).split('').map(x=>L[+x]).join('');
  const right=digits.slice(4).split('').map(x=>R[+x]).join('');
  return '101'+left+'01010'+right+'101';
 }
 function code128Bits(digits){
  const even=digits.length%2===0,values=even?[105,...digits.match(/\d{2}/g).map(Number)]:[104,...digits.split('').map(x=>Number(x)+16)];
  const sum=values.reduce((total,value,i)=>total+(i===0?value:value*i),0);
  values.push(sum%103,106);
  return values.map(value=>{
   const widths=CODE128[value];let bits='';for(let i=0;i<widths.length;i++)bits+=(i%2===0?'1':'0').repeat(Number(widths[i]));return bits;
  }).join('');
 }
 function plan(value){
  const upc=String(value??'').trim();
  if(!validDigits(upc)||upc.length<6||upc.length>18)return{ok:false,upc,format:null,warning:'This identifier cannot be displayed as a barcode. Enter its register price manually.'};
  let format=null,warning='';
  if(upc.length===12&&withValidCheck(upc))format='UPC';
  else if(upc.length===13&&withValidCheck(upc))format='EAN13';
  else if(upc.length===8&&withValidCheck(upc))format='EAN8';
  else{
   format='CODE128';
   warning=[8,12,13].includes(upc.length)?'UPC/EAN check digit did not validate. Code 128 shown instead; confirm your register accepts it.':'Code 128 fallback: verify your register accepts this barcode format.';
  }
  const bits=format==='CODE128'?code128Bits(upc):eanBits(upc,format);
  return{ok:true,upc,format,bits,warning};
 }
 function render(svg,value){
  const result=plan(value);if(!svg)return result;
  while(svg.firstChild)svg.removeChild(svg.firstChild);
  svg.setAttribute('role','img');svg.setAttribute('aria-label',result.ok?`${result.format} barcode for ${result.upc}`:'Barcode unavailable');
  if(!result.ok){svg.removeAttribute('viewBox');return result}
  const ns='http://www.w3.org/2000/svg',quiet=15,modules=result.bits.length,unit=2.4,width=(modules+quiet*2)*unit,height=105;
  svg.setAttribute('viewBox',`0 0 ${width} ${height}`);svg.setAttribute('preserveAspectRatio','xMidYMid meet');
  const backdrop=svg.ownerDocument.createElementNS(ns,'rect');backdrop.setAttribute('width',String(width));backdrop.setAttribute('height',String(height));backdrop.setAttribute('fill','#fff');svg.appendChild(backdrop);
  // One rect per uninterrupted black run retains exact integer module boundaries at any viewport size.
  for(let i=0;i<modules;){if(result.bits[i]==='0'){i++;continue}let end=i+1;while(end<modules&&result.bits[end]==='1')end++;
   const bar=svg.ownerDocument.createElementNS(ns,'rect');bar.setAttribute('x',String((quiet+i)*unit));bar.setAttribute('y','1');bar.setAttribute('width',String((end-i)*unit));bar.setAttribute('height','103');bar.setAttribute('fill','#000');svg.appendChild(bar);i=end;
  }
  return result;
 }
 return Object.freeze({plan,render,checksum});
})();
window.UPCRegisterBarcode=UPCRegisterBarcode;
