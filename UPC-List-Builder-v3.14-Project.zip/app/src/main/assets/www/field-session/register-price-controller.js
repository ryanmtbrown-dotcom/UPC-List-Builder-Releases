/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/field-session/register-price-controller.js
 * Owner: Field Session Register Price Workflow
 * Role: Controller
 * Responsibility: Owns register-price collection, UPC navigation, save/resume decisions, and read-only barcode-viewer dialogs.
 * Does not own: Catalog/UPC identity, spreadsheet formatting, raw list persistence, scanner camera, or Android native code.
 * Side effects: Mutates active Work Session through injected save boundary and presents injected modal/SVG controls.
 * Related code: register-barcode.js encodes barcodes; field-session-export-service.js builds spreadsheets; Work Session Service persists sessions.
 */
const UPCRegisterPriceController=(()=>{
 function create({elementById,getCurrent,saveCurrent,exportService,barcode,alertUser,diagnostic}={}){
  if(typeof elementById!=='function'||typeof getCurrent!=='function'||typeof saveCurrent!=='function'||!exportService||typeof exportService.registerReviewEntries!=='function'||typeof exportService.exportTaggedPackage!=='function'||!barcode||typeof barcode.render!=='function'||typeof barcode.plan!=='function')throw new Error('Register Price Controller dependencies are incomplete.');
  const $=elementById,diag=typeof diagnostic==='function'?diagnostic:()=>{},warn=typeof alertUser==='function'?alertUser:()=>{};
  let session=null,entries=[],index=0,digits='',modified=false,clearRequested=false,busy=false,sourceButton=null,statusMessage='';
  const review=()=>$('registerPriceOverlay'),question=()=>$('registerExportQuestionOverlay');
  const active=()=>session&&getCurrent()===session&&Array.isArray(session.items);
  const readPrice=entry=>exportService.registerPriceForItem(entry.item,entry.upc);
  const isNif=entry=>Array.isArray(entry?.item?.registerNifUpcs)&&entry.item.registerNifUpcs.includes(entry.upc);
  const isPriced=entry=>readPrice(entry)!==''&&!isNif(entry);
  const dollars=amount=>amount===''||amount==null?'—':`$${Number(amount).toFixed(2)}`;
  const cursor=()=>entries[index]?{itemId:String(entries[index].item.id??''),upc:entries[index].upc}:null;
  const hasPriceChanges=()=>Boolean(getCurrent()?.items?.some(item=>(item.tags||[]).includes('Price Change')));
  const setText=(id,value)=>{const el=$(id);if(el)el.textContent=String(value)};
  function syncResumeButton(){const button=$('resumeRegisterPrices'),current=getCurrent();if(!button)return;const saved=current?.registerPriceReview;button.classList.toggle('hidden',!current||!saved||!Array.isArray(current.items)||!current.items.some(item=>(item.tags||[]).includes('Price Change')))}
  function showError(value){statusMessage=value;setText('registerReviewStatus',value);diag('register_price_review_notice',{message:value})}
  function currentCents(){return clearRequested?0:modified?Number(digits||'0'):Math.round(Number(readPrice(entries[index])||0)*100)}
  function showBarcode(svgId,detailsId,value){const output=barcode.render($(svgId),value);setText(detailsId,output.ok?`${output.format} · ${output.upc}`:`UPC ${output.upc||'unavailable'}`);return output}
  function updateControls(){
   const buttonIds=['registerReviewPrevious','registerReviewNext','registerReviewNif','registerReviewClear','registerReviewSaveLater','registerReviewExport','registerReviewKeypad'];
   for(const id of buttonIds){const el=$(id);if(el)el.disabled=busy}
   if($('registerReviewPrevious'))$('registerReviewPrevious').disabled=busy||index===0;
   if($('registerReviewNext'))$('registerReviewNext').disabled=busy||!(modified&&digits!==''||isPriced(entries[index]));
  }
  function render(){
   if(!active()||!entries[index])return;
   const entry=entries[index],{item,upc}=entry,total=entries.length,checked=entries.filter(isPriced).length,nifs=entries.filter(isNif).length;
   setText('registerReviewPosition',`${index+1} / ${total}`);setText('registerReviewChecked',`${checked} priced · ${nifs} NIF · ${total-checked-nifs} unchecked`);
   setText('registerReviewSku',item.sku?`SKU ${item.sku}`:'SKU unavailable');
   setText('registerReviewDescription',item.description||'Description unavailable');
   setText('registerReviewUpc',upc||'No UPC');
   setText('registerReviewLabel',dollars(item.labelPrice));setText('registerReviewLibrary',dollars(UPCPriceAuthority.observedPrice(item)));
   const plan=showBarcode('registerReviewBarcode','registerReviewBarcodeFormat',upc);
   setText('registerReviewBarcodeWarning',plan.warning||'');
   const stored=readPrice(entry);setText('registerReviewStored',isNif(entry)?'Marked NIF':stored===''?'Not checked':`Saved ${dollars(stored)}`);setText('registerReviewNif',isNif(entry)?'Undo NIF':'NIF');
   setText('registerReviewPrice',`$${(currentCents()/100).toFixed(2)}`);
   $('registerReviewPrice')?.classList.toggle('is-placeholder',clearRequested||!modified&&stored==='');
   $('registerReviewClear')?.classList.toggle('hidden',stored===''&&!modified&&!clearRequested);
   setText('registerReviewStatus',statusMessage||(index===total-1?'Last UPC. Export any time, or save to continue later.':''));
   updateControls();
  }
  function editKey(key){
   if(busy||!active()||!entries.length)return;
   if(key==='clear'){digits='';modified=true;clearRequested=false}
   else if(key==='backspace'){digits=modified?digits.slice(0,-1):String(Math.round(Number(readPrice(entries[index])||0)*100)).slice(0,-1);modified=true;clearRequested=false}
   else if(/^\d$/.test(key)){const base=modified?digits:'';if(base.length>=9)return;digits=(base+key).replace(/^0+(?=\d)/,'');modified=true;clearRequested=false}
   render();
  }
  function applyDraft(){
   if(!modified&&!clearRequested)return;
   const entry=entries[index],price=Math.round(Number(digits||'0'))/100;
   if(price>9999999.99)throw new Error('Register Price is too large.');
   if(!entry.item.registerPricesByUpc||typeof entry.item.registerPricesByUpc!=='object'||Array.isArray(entry.item.registerPricesByUpc))entry.item.registerPricesByUpc={};
   if(clearRequested)delete entry.item.registerPricesByUpc[entry.upc];else entry.item.registerPricesByUpc[entry.upc]=price;
  }
  async function persist(resumeIndex=index,{markNif=false,undoNif=false}={}){
   if(!active())throw new Error('The active list has changed. Reopen the register review.');
   const entry=entries[index],prior=entry.item.registerPricesByUpc?{...entry.item.registerPricesByUpc}:undefined,priorNifs=Array.isArray(entry.item.registerNifUpcs)?[...entry.item.registerNifUpcs]:undefined,priorTags=Array.isArray(entry.item.tags)?[...entry.item.tags]:undefined,priorAutoTagged=entry.item.registerNifAutoTagged,priorReview=session.registerPriceReview?{...session.registerPriceReview}:undefined;
   try{
    if(markNif){
     if(!Array.isArray(entry.item.registerNifUpcs))entry.item.registerNifUpcs=[];
     if(!entry.item.registerNifUpcs.includes(entry.upc))entry.item.registerNifUpcs.push(entry.upc);
     if(!Array.isArray(entry.item.tags))entry.item.tags=[];
     if(!entry.item.tags.includes('NIF')){entry.item.tags.push('NIF');entry.item.registerNifAutoTagged=true;}
     if(entry.item.registerPricesByUpc)delete entry.item.registerPricesByUpc[entry.upc];
    }else{
     applyDraft();
     if((undoNif||modified&&!clearRequested)&&isNif(entry)){
      entry.item.registerNifUpcs=entry.item.registerNifUpcs.filter(upc=>upc!==entry.upc);
      if(!entry.item.registerNifUpcs.length&&entry.item.registerNifAutoTagged){entry.item.tags=entry.item.tags.filter(tag=>tag!=='NIF');delete entry.item.registerNifAutoTagged;}
     }
    }
    const resume=entries[resumeIndex]||entries[index];session.registerPriceReview={cursorItemId:String(resume.item.id??''),cursorUpc:resume.upc,updatedAt:new Date().toISOString()};
    await saveCurrent();modified=false;clearRequested=false;digits='';statusMessage='';syncResumeButton();
    diag('register_price_review_saved',{listId:session.id,upc:entry.upc,position:index+1,total:entries.length,checked:entries.filter(isPriced).length});
    return true;
   }catch(e){
    if(prior===undefined)delete entry.item.registerPricesByUpc;else entry.item.registerPricesByUpc=prior;
    if(priorNifs===undefined)delete entry.item.registerNifUpcs;else entry.item.registerNifUpcs=priorNifs;
    if(priorTags===undefined)delete entry.item.tags;else entry.item.tags=priorTags;
    if(priorAutoTagged===undefined)delete entry.item.registerNifAutoTagged;else entry.item.registerNifAutoTagged=priorAutoTagged;
    if(priorReview===undefined)delete session.registerPriceReview;else session.registerPriceReview=priorReview;
    showError(`Save failed: ${e?.message||e}. Retry without leaving this item.`);return false;
   }
  }
  async function action(fn){if(busy||!active())return;busy=true;updateControls();try{await fn()}catch(e){showError(`Action failed: ${e?.message||e}`)}finally{busy=false;if(!review().classList.contains('hidden'))render()}}
  async function navigate(next){await action(async()=>{if(!await persist(next))return;index=next;render()})}
  async function savePriceNext(){await action(async()=>{if((!modified||digits==='')&&!isPriced(entries[index])){showError('Enter a register price or select NIF before continuing.');return}const next=Math.min(entries.length-1,index+1);if(await persist(next)){index=next;render()}})}
  async function markNif(){await action(async()=>{const wasMarked=isNif(entries[index]);const next=wasMarked?index:Math.min(entries.length-1,index+1);if(await persist(next,wasMarked?{undoNif:true}:{markNif:true})){index=next;render()}})}
  async function saveLater(){await action(async()=>{if(!await persist())return;review().classList.add('hidden');session=null;entries=[];sourceButton?.focus?.()})}
  async function exportNow(){await action(async()=>{
   if(!await persist())return;
   review().classList.add('hidden');
   const result=await exportService.exportTaggedPackage({includeRegisterPrice:true});
   if(result?.status==='EXPORTED'){session=null;entries=[];sourceButton?.focus?.()}
   else{review().classList.remove('hidden');showError(result?.status==='CANCELLED'?'Export cancelled. Your register prices are saved.':'Export did not complete. Your register prices are saved.');}
  })}
  async function openCollector(){
   if(busy)return;
   const current=getCurrent();if(!current||!hasPriceChanges()){warn('This list has no Price Change items to review.');return}
   busy=true;try{
    const rows=current.items.filter(x=>(x.tags||[]).includes('Price Change'));
    const prefs=await exportService.currentExportPreferences();
    const available=await exportService.registerReviewEntries(rows,prefs);
    if(getCurrent()!==current)throw new Error('The active list changed during UPC loading.');
    entries=available.filter(x=>String(x.upc??'').trim()!=='');
    if(!entries.length){warn('No UPC values are available for register scanning in this list.');session=null;return}
    session=current;const saved=current.registerPriceReview||{};
    const resume=entries.findIndex(x=>String(x.item.id??'')===String(saved.cursorItemId??'')&&x.upc===saved.cursorUpc);
    index=resume>=0?resume:0;digits='';modified=false;clearRequested=false;statusMessage='';review().classList.remove('hidden');render();$('registerReviewSaveLater')?.focus?.();
    diag('register_price_review_opened',{listId:session.id,total:entries.length,resumed:resume>=0});
   }catch(e){session=null;entries=[];warn(`Unable to open register review: ${e?.message||e}`)}finally{busy=false;if(active()&&!review().classList.contains('hidden'))render()}
  }
  function offerExport(){
   const current=getCurrent();if(current?.sessionType==='ACE_NEW_ITEMS_MISC')return;
   sourceButton=$('exportPackage');if(!hasPriceChanges()){void exportService.exportTaggedPackage();return}
   question()?.classList.remove('hidden');$('registerExportYes')?.focus?.();
  }
  function answerNo(){question()?.classList.add('hidden');void exportService.exportTaggedPackage({includeRegisterPrice:false})}
  function answerYes(){question()?.classList.add('hidden');void openCollector()}
  function answerCancel(){question()?.classList.add('hidden');sourceButton?.focus?.()}
  function openBarcode(upc){
   const result=barcode.plan(upc);if(!result.ok)return false;
   const modal=$('registerBarcodeOverlay');if(!modal)return false;
   const rendered=showBarcode('registerLookupBarcode','registerLookupBarcodeDetails',result.upc);
   setText('registerLookupBarcodeWarning',rendered.warning||'');modal.classList.remove('hidden');$('registerBarcodeClose')?.focus?.();return true;
  }
  function closeBarcode(){$('registerBarcodeOverlay')?.classList.add('hidden');$('previewBarcodeButton')?.focus?.()}
  function bind(){
   $('registerExportYes').onclick=answerYes;$('registerExportNo').onclick=answerNo;$('registerExportCancel').onclick=answerCancel;
   $('registerReviewKeypad').onclick=e=>{const key=e.target.closest('[data-register-key]')?.dataset.registerKey;if(key)editKey(key)};
   $('registerReviewPrevious').onclick=()=>navigate(Math.max(0,index-1));
   $('registerReviewNext').onclick=()=>savePriceNext();
   $('registerReviewNif').onclick=()=>markNif();
   $('registerReviewClear').onclick=()=>action(async()=>{digits='';modified=false;clearRequested=true;if(!await persist())return;render()});
   $('registerReviewSaveLater').onclick=()=>saveLater();$('registerReviewExport').onclick=()=>exportNow();
   $('resumeRegisterPrices').onclick=()=>openCollector();$('registerBarcodeClose').onclick=closeBarcode;
   document.addEventListener('keydown',e=>{
    if(!review()?.classList.contains('hidden')){if(/^\d$/.test(e.key)){e.preventDefault();editKey(e.key)}else if(e.key==='Backspace'){e.preventDefault();editKey('backspace')}else if(e.key==='Escape'){e.preventDefault();void saveLater()}}
    else if(!$('registerBarcodeOverlay')?.classList.contains('hidden')&&e.key==='Escape')closeBarcode();
    else if(!question()?.classList.contains('hidden')&&e.key==='Escape')answerCancel();
   });
   syncResumeButton();
  }
  return Object.freeze({bind,offerExport,openCollector,openBarcode,closeBarcode,syncResumeButton});
 }
 return Object.freeze({create});
})();
window.UPCRegisterPriceController=UPCRegisterPriceController;
