/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/identifier-normalization.js
 * Owner: Identifier Domain
 * Role: Pure utility
 * Responsibility: Owns canonical SKU/UPC normalization shared across workflows.
 * Does not own: Lookup policy; persistence; relationship state; UI.
 * Side effects: None; pure normalization only.
 * Related code: Identity resolution belongs to relationship/local-identifier services.
 */
const UPCIdentifierNormalization=(()=>{
 const normalizeSKU=value=>String(value??'').normalize('NFKC').replace(/\s+/g,'').replace(/d$/i,'').toLowerCase();
 const normalizeUPC=value=>String(value??'').replace(/[^\d]/g,'');
 const normalizeUPCUnicodeCompatible=value=>String(value??'').normalize('NFKC').replace(/[^\d]/g,'');
 return Object.freeze({normalizeSKU,normalizeUPC,normalizeUPCUnicodeCompatible});
})();
window.UPCIdentifierNormalization=UPCIdentifierNormalization;
