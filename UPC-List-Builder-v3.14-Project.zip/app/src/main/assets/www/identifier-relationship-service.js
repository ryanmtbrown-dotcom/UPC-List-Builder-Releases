/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/identifier-relationship-service.js
 * Owner: Identifier Relationship Domain
 * Role: Workflow-facing identity service
 * Responsibility: Owns current SKU↔UPC membership, UPC conflict/resolution state, verified replacement, and identity research operations.
 * Does not own: Raw IndexedDB; catalog field policy; UI; AceNet transport.
 * Side effects: Reads/writes identity state through UPCIdentityRepository; no direct DOM or network access.
 * Related code: Physical persistence belongs to identity-repository.js; user-facing conflict work belongs to identity/identity-work-controller.js.
 */
const UPCIdentifierRelationshipService=(()=>{
 const normalizeSKU=UPCIdentifierNormalization.normalizeSKU,normalizeUPC=UPCIdentifierNormalization.normalizeUPC;
 const normalizeSet=upcs=>[...new Set((Array.isArray(upcs)?upcs:[]).map(normalizeUPC).filter(Boolean))];
 async function resolveUPC(upc){
  const upcKey=normalizeUPC(upc);if(!upcKey)return{status:'UNKNOWN',upcKey:'',sku:null,candidateSkuKeys:[],resolution:null,relationships:[]};
  const [resolution,relationships]=await Promise.all([UPCIdentityRepository.getUpcResolution(upcKey),UPCIdentityRepository.lookupSkuByUpc(upcKey)]);
  const relationshipCandidates=[...new Set((relationships||[]).map(row=>normalizeSKU(row?.skuKey)).filter(Boolean))].sort(),preferred=normalizeSKU(resolution?.preferredSkuKey);
  if(preferred&&!relationshipCandidates.includes(preferred)){
    return{status:'CONFLICT',upcKey,sku:null,candidateSkuKeys:[...new Set([...relationshipCandidates,preferred])].sort(),resolution,relationships,reason:'STALE_RESOLUTION_DISAGREES_WITH_RELATIONSHIPS'};
  }
  if(resolution?.status==='RESOLVED'&&preferred&&relationshipCandidates.includes(preferred)){
    return{status:'KNOWN',upcKey,sku:preferred,candidateSkuKeys:relationshipCandidates,resolution,relationships,reason:'EXPLICIT_RESOLUTION'};
  }
  if(resolution?.status==='UNRESOLVED_CONFLICT'||relationshipCandidates.length>1){
    return{status:'CONFLICT',upcKey,sku:null,candidateSkuKeys:relationshipCandidates,resolution,relationships,reason:'MULTIPLE_CURRENT_SKUS'};
  }
  if(relationshipCandidates.length===1){
    return{status:'KNOWN',upcKey,sku:relationshipCandidates[0],candidateSkuKeys:relationshipCandidates,resolution,relationships,reason:'SINGLE_CURRENT_SKU'};
  }
  return{status:'UNKNOWN',upcKey,sku:null,candidateSkuKeys:[],resolution,relationships,reason:'NO_CURRENT_RELATIONSHIP'};
 }
 async function recordVerifiedSkuUpcs(sku,upcs,source='ACENET_VERIFIED',options={}){
  const skuKey=normalizeSKU(sku),normalized=normalizeSet(upcs),exactSkuVerified=options?.exactSkuVerified===true,completeness=String(options?.completeness||'PARTIAL').toUpperCase();
  if(!skuKey)throw new Error('SKU is required for verified relationship evidence.');
  if(!exactSkuVerified)return{applied:false,reason:'EXACT_SKU_NOT_VERIFIED',skuKey,masterUpc:null,upcs:normalized,inserted:0,updated:0,removed:0,removedUpcs:[],resolutions:[],conflictCount:0,completeness};
  if(!normalized.length)return{applied:false,reason:'NO_VERIFIED_UPCS',skuKey,masterUpc:null,upcs:[],inserted:0,updated:0,removed:0,removedUpcs:[],resolutions:[],conflictCount:0,completeness};
  if(completeness==='COMPLETE'){
    const result=await UPCIdentityRepository.replaceSkuUpcSet(skuKey,normalized,source);
    return{...result,applied:true,reason:'COMPLETE_SET_REPLACED',completeness:'COMPLETE',destructiveReconciliation:true};
  }
  if(completeness==='PARTIAL'){
    const result=await UPCIdentityRepository.recordVerifiedSkuUpcs(skuKey,normalized,source);
    return{...result,applied:true,reason:'PARTIAL_SET_MERGED',completeness:'PARTIAL',destructiveReconciliation:false,removed:0,removedUpcs:[]};
  }
  return{applied:false,reason:'UNSUPPORTED_COMPLETENESS',skuKey,masterUpc:null,upcs:normalized,inserted:0,updated:0,removed:0,removedUpcs:[],resolutions:[],conflictCount:0,completeness};
 }
 async function classifyResearch(sku,classification){
  const normalized=String(classification||'UNKNOWN').toUpperCase(),allowed=new Set(['UNKNOWN','RECALL','OLD_DEPRECATED_SUPPLIER']);
  if(!allowed.has(normalized))throw new Error('Unsupported research classification.');
  return UPCIdentityRepository.updateResearch(sku,{classification:normalized,status:normalized==='UNKNOWN'?'REVIEW_LATER':'ACTION_REQUIRED'});
 }
 async function updateResearchUpc(sku,upc){return UPCIdentityRepository.updateResearchUpc(sku,upc)}
 async function enqueueDeferredAceNetRefresh(candidate){return UPCIdentityRepository.enqueueDeferredRefresh(candidate)}
 return Object.freeze({
  resolveUPC,
  recordVerifiedSkuUpcs,
  getSkuUpcs:UPCIdentityRepository.getSkuUpcs,
  recordRelationship:UPCIdentityRepository.recordRelationship,
  getSkuIdentity:UPCIdentityRepository.getSkuIdentity,
  setSkuIdentityStatus:UPCIdentityRepository.setSkuIdentityStatus,
  setSkuReplacement:UPCIdentityRepository.setSkuReplacement,
  resolveConflict:UPCIdentityRepository.resolveConflict,
  enqueueResearch:UPCIdentityRepository.enqueueResearch,
  getResearch:UPCIdentityRepository.getResearch,
  getResearchQueue:UPCIdentityRepository.getResearchQueue,
  removeResearch:UPCIdentityRepository.removeResearch,
  updateResearchSku:UPCIdentityRepository.updateResearchSku,
  updateResearchUpc,
  classifyResearch,
  enqueueDeferredAceNetRefresh,
  getDeferredAceNetRefreshQueue:UPCIdentityRepository.getDeferredRefreshQueue,
  removeDeferredAceNetRefresh:UPCIdentityRepository.removeDeferredRefresh,
  discardResearch:UPCIdentityRepository.discardResearch,
  getConflictQueue:UPCIdentityRepository.getConflictQueue
 });
})();
window.UPCIdentifierRelationshipService=UPCIdentifierRelationshipService;
