/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/identity-repository.js
 * Owner: Identity Persistence
 * Role: Repository facade
 * Responsibility: Owns physical persistence access for identity relationships, resolution rows, replacement state, and research state.
 * Does not own: Identity business rules; UI; catalog mutation; network.
 * Side effects: Direct UPCDB identity-store calls are permitted only as repository adaptation.
 * Related code: Workflow callers should use Identifier Relationship Service rather than this facade directly.
 */
const UPCIdentityRepository=(()=>Object.freeze({
 upsertSkuUpcs:UPCDB.upsertSkuUpcs,
 getSkuUpcs:UPCDB.getSkuUpcs,
 lookupSkuByUpc:UPCDB.lookupSkuByUpc,
 getSkuIdentity:UPCDB.getSkuIdentity,
 setSkuIdentityStatus:UPCDB.setSkuIdentityStatus,
 setSkuReplacement:UPCDB.setSkuReplacement,
 getUpcResolution:UPCDB.getUpcIdentityResolution,
 recordRelationship:UPCDB.recordIdentityRelationship,
 recordVerifiedSkuUpcs:UPCDB.recordVerifiedSkuUpcs,
 replaceSkuUpcSet:UPCDB.replaceSkuUpcSet,
 resolveConflict:UPCDB.resolveUpcConflict,
 enqueueResearch:UPCDB.enqueueIdentityResearch,
 getResearch:UPCDB.getIdentityResearch,
 updateResearch:UPCDB.updateIdentityResearch,
 updateResearchUpc:UPCDB.updateIdentityResearchUpc,
 getResearchQueue:UPCDB.getIdentityResearchQueue,
 removeResearch:UPCDB.removeIdentityResearch,
 updateResearchSku:UPCDB.updateIdentityResearchSku,
 discardResearch:UPCDB.discardIdentityResearch,
 enqueueDeferredRefresh:UPCDB.enqueueDeferredAceNetRefresh,
 getDeferredRefreshQueue:UPCDB.getDeferredAceNetRefreshQueue,
 removeDeferredRefresh:UPCDB.removeDeferredAceNetRefreshSku,
 getConflictQueue:UPCDB.getIdentityConflictQueue,
 listSkuUpcs:()=>UPCDB.all('skuUpcs'),
 listSkuIdentity:()=>UPCDB.all('skuIdentity'),
 listUpcResolutions:()=>UPCDB.all('upcIdentityResolution')
}))();
window.UPCIdentityRepository=UPCIdentityRepository;
