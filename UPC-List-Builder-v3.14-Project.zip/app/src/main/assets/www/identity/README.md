# Identity Directory Ownership

OWNS: user-facing identity conflict/research work queues, research resolution actions, deferred live-refresh orchestration, and identity-resolution workflow presentation.

DOES NOT OWN: physical identity persistence, current SKU↔UPC relationship rules, catalog lookup policy, or raw IndexedDB.

DEPENDENCIES: workflow state is resolved through Identifier Relationship Service and approved catalog/Local/work-session/AceNet services. Deferred refresh may dispatch only when the injected AceNet Comparison capability is enabled.
