/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/identity/identity-work-controller.js
 * Owner: Identity Work UI
 * Role: Controller
 * Responsibility: Owns user-facing identity conflict/research queues, resolution actions, unresolved-origin workflow, and identity-work presentation.
 * Does not own: Physical identity persistence, core relationship rules, catalog refresh policy, or normal lookup orchestration.
 * Side effects: Mutates Identity Work DOM and calls injected relationship/catalog/work-session owners.
 * Related code: Current relationship authority belongs to identifier-relationship-service.js.
 */
const UPCIdentityWorkController=(()=>{
 function create({
 elementById,escapeHtml,normalizeSku,normalizeUpc,localRepository,relationshipService,catalogRefreshService,
 requestCatalog,normalLookupProvider,workSessionService,getCurrentSession,newId,sessionName,
 messageUser,alertUser,promptUser,confirmUser,comparisonEnabled,libraryWorkflowProvider,diagnostic
}={}){
 if(typeof elementById!=='function'||typeof normalizeSku!=='function'||typeof normalizeUpc!=='function'||!localRepository||!relationshipService)throw new Error('Identity Work Controller repository dependencies are incomplete.');
 if(!catalogRefreshService||typeof requestCatalog!=='function'||typeof normalLookupProvider!=='function'||!workSessionService)throw new Error('Identity Work Controller service dependencies are incomplete.');
 if(typeof promptUser!=='function'||typeof confirmUser!=='function'||typeof comparisonEnabled!=='function')throw new Error('Identity Work Controller resolution dependencies are incomplete.');
 const $=elementById,esc=escapeHtml,diag=typeof diagnostic==='function'?diagnostic:()=>{};
 let batchRunning=false,deferredRefreshRunning=false;

 function conflictRelationshipRoles(conflict){
  const rels=Array.isArray(conflict?.candidateRelationships)?conflict.candidateRelationships:[],ordered=[...rels].sort((a,b)=>String(a.firstSeenAt||'').localeCompare(String(b.firstSeenAt||'')));
  return{oldest:ordered[0]?.skuKey||null,newest:ordered.at(-1)?.skuKey||null};
 }

 async function processQueuedLocalLibrarySku(sku){
  const key=normalizeSku(sku);if(!key)return{sku:key,status:'INVALID_SKU'};
  diag('identity_local_library_update_requested',{sku:key,batch:true});
  const result=await requestCatalog(key);
  if(result.status!=='VERIFIED'||!result.catalog){diag('identity_local_library_update_deferred',{sku:key,status:result.status,batch:true});return{sku:key,status:result.status}}
  const returned=normalizeSku(result.sku||result.catalog?.sku);
  if(returned!==key){diag('identity_local_library_update_deferred',{sku:key,status:'SKU_MISMATCH',returnedSku:returned||null,batch:true});return{sku:key,status:'SKU_MISMATCH'}}
  const persisted=await catalogRefreshService.persistVerifiedAceNetCatalogToLocalLibrary(key,{...result.catalog,sku:key},{source:'ACENET_CATALOG_BATCH',relationshipSource:'ACENET_CATALOG'});
  if(persisted.status==='MASTER_PRESENT'){
   await localRepository.removeUpdateQueueSku(key);await relationshipService.setSkuIdentityStatus(key,{catalogStatus:'MASTER_LIBRARY',source:'ACENET_CATALOG_BATCH'});
   diag('identity_local_library_update_completed',{sku:key,alreadyInOfficialMaster:true,batch:true});return{sku:key,status:'COMPLETED',upcCount:persisted.upcs.length,staged:false};
  }
  diag('identity_local_library_update_completed',{sku:key,created:Boolean(persisted.staged?.created),updated:Boolean(persisted.staged?.updated),upcCount:persisted.upcs.length,batch:true});
  return{sku:key,status:'COMPLETED',upcCount:persisted.upcs.length,staged:true};
 }

 async function recheckResearchSku(sku){
  const key=normalizeSku(sku);if(!key)return{status:'INVALID_SKU'};
  diag('identity_research_recheck_requested',{sku:key});
  const existing=await normalLookupProvider().lookupItemBySku(key);
  if(existing.status==='FOUND'&&String(existing.recordOrigin||'')!=='THIRD_PARTY_VENDOR'){
   await relationshipService.removeResearch(key);await relationshipService.removeDeferredAceNetRefresh(key);
   await relationshipService.setSkuIdentityStatus(key,{catalogStatus:String(existing.librarySource||'').startsWith('LOCAL_LIBRARY')?'LOCAL_LIBRARY':'MASTER_LIBRARY',source:'RESEARCH_RECHECK'});
   diag('identity_research_recheck_reclassified',{sku:key,status:'FOUND_IN_LIBRARY',librarySource:existing.librarySource||null});return{status:'FOUND_IN_LIBRARY'};
  }
  if(!comparisonEnabled()){await relationshipService.enqueueDeferredAceNetRefresh({sku:key,upcs:(await relationshipService.getResearch(key))?.upcs||[],reason:'RESEARCH_RECHECK_DEFERRED',source:'RESEARCH_RECHECK'});diag('identity_research_recheck_deferred',{sku:key,reason:'acenet_disabled'});return{status:'DEFERRED'}}
  const result=await requestCatalog(key),returned=normalizeSku(result.sku||result.catalog?.sku);
  if(result.status==='VERIFIED'&&result.catalog&&returned===key){
   const persisted=await catalogRefreshService.persistVerifiedAceNetCatalogToLocalLibrary(key,{...result.catalog,sku:key},{source:'RESEARCH_RECHECK',relationshipSource:'ACENET_RESEARCH_RECHECK'});
   await relationshipService.removeDeferredAceNetRefresh(key);
   diag('identity_research_recheck_reclassified',{sku:key,status:persisted.status==='MASTER_PRESENT'?'MASTER_LIBRARY':'LOCAL_LIBRARY'});
   return{status:'ADD_TO_LOCAL_LIBRARY'};
  }
  if(result.status==='NOT_FOUND'){diag('identity_research_recheck_still_not_found',{sku:key});return{status:'NOT_FOUND'}}
  if(result.status==='VERIFIED'&&returned!==key){await relationshipService.classifyResearch(key,'UNKNOWN');diag('identity_research_recheck_sku_mismatch',{sku:key,returnedSku:returned||null});return{status:'SKU_MISMATCH'}}
  diag('identity_research_recheck_inconclusive',{sku:key,status:result.status});return{status:'INCONCLUSIVE',technicalStatus:result.status};
 }

 async function runAddToLocalLibraryBatch(){
  if(batchRunning)return;
  const queued=await localRepository.getUpdateQueue();if(!queued.length){alertUser('There are no Add to Local Library items waiting.');return}
  batchRunning=true;diag('identity_local_library_batch_started',{queued:queued.length});await refreshWorkQueues();let completed=0,deferred=0,failed=0;
  try{
   for(const row of queued){
    const key=normalizeSku(row.sku||row.skuKey);
    try{const out=await processQueuedLocalLibrarySku(key);if(out.status==='COMPLETED')completed++;else deferred++}
    catch(e){failed++;diag('identity_local_library_batch_item_failed',{sku:key,message:e?.message||String(e)})}
    await refreshWorkQueues();
   }
   diag('identity_local_library_batch_completed',{queued:queued.length,completed,deferred,failed});
   alertUser(`Add to Local Library finished. ${completed} completed; ${deferred} deferred; ${failed} failed. Deferred/failed SKUs remain queued.`);
  }finally{batchRunning=false;await refreshWorkQueues();libraryWorkflowProvider?.()?.refreshQueue?.().catch(()=>{})}
 }

 async function processDeferredAceNetRefresh(row){
  const key=normalizeSku(row?.sku||row?.skuKey);if(!key)return{status:'INVALID_SKU'};
  const result=await requestCatalog(key),returned=normalizeSku(result.sku||result.catalog?.sku);
  if(result.status==='VERIFIED'&&result.catalog&&returned===key){
   const persisted=await catalogRefreshService.persistVerifiedAceNetCatalogToLocalLibrary(key,{...result.catalog,sku:key},{source:'DEFERRED_ACENET_REFRESH',relationshipSource:'ACENET_DEFERRED_REFRESH'});
   await relationshipService.removeDeferredAceNetRefresh(key);
   diag('identity_deferred_refresh_completed',{sku:key,upcCount:persisted.upcs?.length||0,libraryStatus:persisted.status});return{status:'COMPLETED'};
  }
  if(result.status==='NOT_FOUND'){
   await relationshipService.enqueueResearch({sku:key,upcs:row?.upcs||[],reason:'NOT_IN_MASTER_LOCAL_OR_ACENET',source:'DEFERRED_ACENET_REFRESH'});
   await relationshipService.removeDeferredAceNetRefresh(key);
   diag('identity_deferred_refresh_classified_research',{sku:key,status:'NOT_FOUND'});return{status:'NOT_FOUND'};
  }
  if(result.status==='VERIFIED'&&returned!==key){
   await relationshipService.enqueueResearch({sku:key,upcs:row?.upcs||[],reason:'ACENET_SKU_MISMATCH',source:'DEFERRED_ACENET_REFRESH'});
   await relationshipService.removeDeferredAceNetRefresh(key);
   diag('identity_deferred_refresh_classified_research',{sku:key,status:'SKU_MISMATCH',returnedSku:returned||null});return{status:'SKU_MISMATCH'};
  }
  diag('identity_deferred_refresh_deferred',{sku:key,status:result.status||'UNAVAILABLE'});return{status:result.status||'UNAVAILABLE'};
 }

 async function runDeferredAceNetRefreshBatch(){
  if(deferredRefreshRunning)return;
  const queued=await relationshipService.getDeferredAceNetRefreshQueue();
  if(!queued.length){await messageUser('There are no pending items waiting for a live AceNet refresh.','Pending Item Data');return}
  if(!comparisonEnabled()){await messageUser('Turn on AceNet Comparison before refreshing pending item data. UPC enrichment and live catalog retrieval cannot run while AceNet access is disabled.','AceNet Required');return}
  deferredRefreshRunning=true;diag('identity_deferred_refresh_batch_started',{queued:queued.length});await refreshWorkQueues();
  let completed=0,research=0,deferred=0,failed=0;
  try{
   for(const row of queued){
    try{const out=await processDeferredAceNetRefresh(row);if(out.status==='COMPLETED')completed++;else if(['NOT_FOUND','SKU_MISMATCH'].includes(out.status))research++;else deferred++}
    catch(e){failed++;diag('identity_deferred_refresh_item_failed',{sku:normalizeSku(row?.sku||row?.skuKey),message:e?.message||String(e)})}
    await refreshWorkQueues();
   }
   diag('identity_deferred_refresh_batch_completed',{queued:queued.length,completed,research,deferred,failed});
   await messageUser(`Pending item refresh finished. ${completed} updated; ${research} moved to research; ${deferred} still deferred; ${failed} failed.`,'Pending Item Data');
  }finally{deferredRefreshRunning=false;await refreshWorkQueues()}
 }

 async function createThirdPartyFromResearch(row){
  const sku=normalizeSku(row?.sku||row?.skuKey);if(!sku)throw new Error('Research SKU is invalid.');
  const defaultUpc=normalizeUpc((row?.upcs||[])[0]||''),upcRaw=await promptUser('Enter the UPC for this third-party vendor item.',defaultUpc,'Third-Party Vendor');
  if(upcRaw===null)return false;const upc=normalizeUpc(upcRaw);if(!upc)throw new Error('Enter a valid UPC.');
  const description=await promptUser('Enter the item description.','','Third-Party Vendor');if(description===null)return false;
  const vendorPrice=await promptUser('Enter the current vendor price.','','Third-Party Vendor');if(vendorPrice===null)return false;
  const vendorName=await promptUser('Enter the vendor name if known. Leave blank if not needed.','','Third-Party Vendor');if(vendorName===null)return false;
  const staged=await localRepository.stageThirdPartyItem({sku,upc,description,vendorPrice,vendorName});
  await relationshipService.recordRelationship(sku,upc,'THIRD_PARTY_VENDOR');
  await relationshipService.setSkuIdentityStatus(sku,{catalogStatus:'LOCAL_LIBRARY',source:'THIRD_PARTY_VENDOR'});
  await relationshipService.removeResearch(sku);await relationshipService.removeDeferredAceNetRefresh(sku);
  diag('identity_research_resolved_third_party',{sku,upc,created:Boolean(staged.created),updated:Boolean(staged.updated),vendorNamePresent:Boolean(String(vendorName||'').trim())});
  await messageUser(`SKU ${sku} was saved as a third-party vendor Local Library item.`,'Research Resolved');return true;
 }

 async function resolveResearchAction(sku,action){
  const key=normalizeSku(sku),row=await relationshipService.getResearch(key);if(!row)throw new Error('This research record no longer exists.');
  const selected=String(action||'RECHECK').toUpperCase();
  if(selected==='RECHECK'){
   const out=await recheckResearchSku(key);
   if(out.status==='ADD_TO_LOCAL_LIBRARY'||out.status==='FOUND_IN_LIBRARY')await messageUser(`SKU ${key} was resolved and removed from Items Needing Research.`,'Item Resolved');
   else if(out.status==='DEFERRED')await messageUser(`SKU ${key} is queued for a live AceNet refresh when AceNet Comparison is available.`,'Refresh Deferred');
   else if(out.status==='NOT_FOUND')await messageUser(`SKU ${key} is still not found. It remains in Items Needing Research.`,'Item Not Found');
   else await messageUser(`SKU ${key} could not be resolved. It remains in Items Needing Research.`,'Recheck Incomplete');
  }else if(selected==='EDIT_SKU'){
   const value=await promptUser('Correct the SKU for this research item.',row.sku||row.skuKey||'','Correct SKU');if(value===null)return;
   const next=normalizeSku(value);if(!next)throw new Error('Enter a valid SKU.');
   await relationshipService.updateResearchSku(key,next);diag('identity_research_sku_corrected',{oldSku:key,newSku:next});
  }else if(selected==='EDIT_UPC'){
   const value=await promptUser('Correct the UPC for this research item.',normalizeUpc((row.upcs||[])[0]||''),'Correct UPC');if(value===null)return;
   const next=normalizeUpc(value);if(!next)throw new Error('Enter a valid UPC.');
   await relationshipService.updateResearchUpc(key,next);diag('identity_research_upc_corrected',{sku:key,newUpc:next});
  }else if(selected==='THIRD_PARTY_VENDOR'){
   await createThirdPartyFromResearch(row);
  }else if(selected==='RECALL'){
   await relationshipService.classifyResearch(key,'RECALL');diag('identity_research_classified',{sku:key,classification:'RECALL'});
  }else if(selected==='OLD_DEPRECATED_SUPPLIER'){
   await relationshipService.classifyResearch(key,'OLD_DEPRECATED_SUPPLIER');diag('identity_research_classified',{sku:key,classification:'OLD_DEPRECATED_SUPPLIER'});
  }else if(selected==='UNKNOWN'){
   await relationshipService.classifyResearch(key,'UNKNOWN');diag('identity_research_classified',{sku:key,classification:'UNKNOWN'});
  }else if(selected==='DELETE'){
   if(await confirmUser(`Delete SKU ${key} from Items Needing Research? This removes the active research item; it does not create or preserve a historical identity relationship.`,'Delete Research Item',{okLabel:'Delete'})){
    await relationshipService.discardResearch(key);await relationshipService.removeDeferredAceNetRefresh(key);diag('identity_research_deleted',{sku:key});
   }
  }else throw new Error('Unsupported research action.');
  await refreshWorkQueues();
 }

 function renderResearchRow(row){
  const sku=normalizeSku(row?.sku||row?.skuKey),upcs=(row?.upcs||[]).map(normalizeUpc).filter(Boolean),classification=String(row?.classification||'UNKNOWN').toUpperCase(),reason=String(row?.reason||'UNKNOWN');
  return `<div class="identityConflictRow identityResearchRow"><div><b>SKU ${esc(sku)}</b><small>${upcs.length?`UPC ${upcs.map(esc).join(', ')} · `:''}${esc(classification.replaceAll('_',' '))} · ${esc(reason.replaceAll('_',' '))}</small></div><div class="identityResearchControls"><select class="identityResearchAction" aria-label="Resolve SKU ${esc(sku)}"><option value="RECHECK">Recheck with AceNet</option><option value="EDIT_SKU">Correct SKU</option><option value="EDIT_UPC">Correct UPC</option><option value="THIRD_PARTY_VENDOR">Mark Third-Party Vendor</option><option value="RECALL">Mark Recall</option><option value="OLD_DEPRECATED_SUPPLIER">Mark Old / Deprecated Supplier</option><option value="UNKNOWN">Keep Unknown / Review Later</option><option value="DELETE">Delete</option></select><button type="button" class="secondary identityApplyResearch" data-sku="${esc(sku)}">Apply</button></div></div>`;
 }

 async function refreshWorkQueues(){
  const host=$('identityWorkQueues');if(!host)return;
  try{
   const [add,research,conflicts,deferred]=await Promise.all([localRepository.getUpdateQueue(),relationshipService.getResearchQueue(),relationshipService.getConflictQueue(),relationshipService.getDeferredAceNetRefreshQueue()]),empty='<div class="identityQueueEmpty">None</div>';
   const addMarkup=add.length?`<div class="identityQueueEntries"><button type="button" class="primary identityUpdateLocalLibraryBatch" ${batchRunning?'disabled':''}>${batchRunning?'Updating…':'Update Local Library'} · ${add.length}</button>${add.slice(0,12).map(x=>`<div class="identityConflictRow"><b>SKU ${esc(x.sku||x.skuKey)}</b></div>`).join('')}${add.length>12?`<small>+${add.length-12} more</small>`:''}</div>`:empty;
   const deferredMarkup=deferred.length?`<div class="identityQueueEntries"><button type="button" class="primary identityRefreshPendingData" ${deferredRefreshRunning?'disabled':''}>${deferredRefreshRunning?'Refreshing…':'Refresh Pending Item Data'} · ${deferred.length}</button>${deferred.slice(0,12).map(x=>`<div class="identityConflictRow"><div><b>SKU ${esc(x.sku||x.skuKey)}</b><small>${(x.upcs||[]).length?`UPC ${(x.upcs||[]).map(esc).join(', ')}`:'SKU captured for later live refresh'}</small></div></div>`).join('')}${deferred.length>12?`<small>+${deferred.length-12} more</small>`:''}</div>`:empty;
   const researchSectionMarkup=research.length?`<div class="identityQueueEntries">${research.slice(0,20).map(renderResearchRow).join('')}${research.length>20?`<small>+${research.length-20} more</small>`:''}</div>`:empty;
   const conflictMarkup=conflicts.length?`<div class="identityConflictEntries">${conflicts.slice(0,12).map(x=>{const roles=conflictRelationshipRoles(x),c=x.candidateSkuKeys||[];return `<div class="identityConflictRow"><div><b>UPC ${esc(x.upcKey)}</b><small>${c.map(k=>`${esc(k)}${k===roles.newest?' · newer/scanned':k===roles.oldest?' · existing':''}`).join(' / ')}</small></div><div class="identityConflictActions">${c.map(k=>`<button type="button" class="secondary identityResolveConflict" data-upc="${esc(x.upcKey)}" data-sku="${esc(k)}">Use SKU ${esc(k)} as current</button>`).join('')}<button type="button" class="secondary identityResolveUnknown" data-upc="${esc(x.upcKey)}" data-sku="${esc(c[0]||'')}">Research later</button></div></div>`}).join('')}${conflicts.length>12?`<small>+${conflicts.length-12} more</small>`:''}</div>`:empty;
   host.innerHTML=`<section class="identityQueueCard"><div class="identityQueueHead"><strong>Add to Local Library · ${add.length}</strong><small>AceNet-verified items waiting for durable Local Library persistence.</small></div>${addMarkup}</section><section class="identityQueueCard"><div class="identityQueueHead"><strong>Pending Live Refresh · ${deferred.length}</strong><small>SKUs captured while live AceNet retrieval was unavailable or intentionally disabled. Refresh runs only when AceNet Comparison is enabled.</small></div>${deferredMarkup}</section><section class="identityQueueCard"><div class="identityQueueHead"><strong>Items Needing Research · ${research.length}</strong><small>Correct, classify, convert, revisit, recheck, or delete unresolved items.</small></div>${researchSectionMarkup}</section><section class="identityQueueCard"><div class="identityQueueHead"><strong>SKU Conflicts · ${conflicts.length}</strong><small>A UPC is linked to more than one current SKU. Choose the current SKU.</small></div>${conflictMarkup}</section>`;
   host.querySelectorAll('.identityUpdateLocalLibraryBatch').forEach(b=>b.onclick=()=>runAddToLocalLibraryBatch().catch(e=>{diag('identity_local_library_batch_failed',{message:e?.message||String(e)});alertUser(e?.message||String(e))}));
   host.querySelectorAll('.identityRefreshPendingData').forEach(b=>b.onclick=()=>runDeferredAceNetRefreshBatch().catch(e=>{diag('identity_deferred_refresh_batch_failed',{message:e?.message||String(e)});alertUser(e?.message||String(e))}));
   host.querySelectorAll('.identityApplyResearch').forEach(b=>b.onclick=async()=>{const controls=b.closest('.identityResearchControls'),select=controls?.querySelector('.identityResearchAction');b.disabled=true;try{await resolveResearchAction(b.dataset.sku,select?.value||'RECHECK')}catch(e){diag('identity_research_resolution_failed',{sku:b.dataset.sku,action:select?.value||null,message:e?.message||String(e)});await messageUser(e?.message||String(e),'Research Action Failed')}finally{b.disabled=false}});
   diag('identity_work_queues_rendered',{addToLocalLibrary:add.length,pendingLiveRefresh:deferred.length,needsResearch:research.length,skuConflicts:conflicts.length});
  }catch(e){host.innerHTML='<div class="libraryQueueSummary">Identity work queues unavailable.</div>';diag('identity_work_queues_failed',{message:e?.message||String(e)})}
 }

 function unresolvedOriginForCurrent(){
  const current=getCurrentSession();if(current?.sessionType==='ACE_NEW_ITEMS_MISC')return'ACE New Items MISC.';if(current?.defaultTag==='NIF'||current?.items?.some(x=>(x.tags||[]).includes('NIF')))return'Not on File';return null;
 }

 async function recordUnresolved(identifier,type,origin){
  const value=String(identifier??'').trim();if(!value||!origin)return null;const lists=await workSessionService.list();let list=lists.find(x=>x.sessionType==='UNRESOLVED_REFERENCE');
  if(!list){const now=new Date().toISOString();list={id:newId(),name:'Unresolved',createdAt:now,updatedAt:now,sessionType:'UNRESOLVED_REFERENCE',items:[],captures:[]}}
  const normalizedType=String(type||'UPC').toUpperCase()==='SKU'?'SKU':'UPC',key=`${normalizedType}|${value}|${origin}`.toLowerCase(),existing=(list.items||[]).find(x=>x.unresolvedKey===key);
  if(existing){diag('unresolved_reference_reused',{identifier:value,identifierType:normalizedType,origin,listId:list.id});return existing}
  const item={id:newId(),unresolvedKey:key,identifier:value,identifierType:normalizedType,origin,tags:['Unresolved',`Unresolved — ${origin}`],addedAt:new Date().toISOString()};list.items.push(item);await workSessionService.save(list);diag('unresolved_reference_created',{identifier:value,identifierType:normalizedType,origin,listId:list.id});return item;
 }

 async function addReplacementToTodaysAceNewItems(sku,upc){
  const skuKey=normalizeSku(sku),upcKey=normalizeUpc(upc);if(!skuKey)return null;const dateName=sessionName(),name=`ACE New Items · ${dateName}`,lists=await workSessionService.list();let list=lists.find(x=>x.sessionType==='ACE_NEW_ITEMS_AUTO'&&x.name===name),created=false;
  if(!list){const now=new Date().toISOString();list={id:newId(),name,createdAt:now,updatedAt:now,defaultTag:'NIF',sessionType:'ACE_NEW_ITEMS_AUTO',items:[],captures:[],promptLabelPriceAfterScan:false,autoAddPriceDifference:false};created=true}
  if(!Array.isArray(list.items))list.items=[];const existing=list.items.find(x=>normalizeSku(x.sku)===skuKey&&(!upcKey||normalizeUpc(x.upc||'')===upcKey));if(existing){diag('identity_replacement_ace_new_items_reused',{listId:list.id,sku:skuKey,upc:upcKey||null});return{list,item:existing,created:false,duplicate:true}}
  const master=await normalLookupProvider().lookupItemBySku(skuKey),row=master?.status==='FOUND'?master:null,now=new Date().toISOString(),item={id:newId(),sku:skuKey,upc:upcKey||row?.upc||'',description:row?.description||'',price:row?.price??null,libraryPrice:row?.price??null,aceNetPrice:null,labelPrice:null,priceDifference:null,status:row?'FOUND':'NOT_FOUND',fields:row?.fields||{},tags:['NIF'],primaryPurpose:'NIF',supplementalPurposes:[],addedAt:now,scannedAt:now,identityReplacement:true};list.items.push(item);await workSessionService.save(list);diag('identity_replacement_ace_new_items_added',{listId:list.id,listCreated:created,sku:skuKey,upc:upcKey||null,itemId:item.id});return{list,item,created,duplicate:false};
 }

 async function resolveConflict(upc,preferredSku,action){
  const conflicts=await relationshipService.getConflictQueue(),conflict=conflicts.find(x=>x.upcKey===normalizeUpc(upc));if(!conflict)throw new Error('This SKU conflict is no longer unresolved.');const candidates=conflict.candidateSkuKeys||[];if(!candidates.includes(normalizeSku(preferredSku)))throw new Error('Selected SKU is no longer a conflict candidate.');
  if(action==='UNKNOWN'){await relationshipService.resolveConflict(upc,preferredSku,'UNKNOWN');diag('identity_conflict_left_unknown',{upc:normalizeUpc(upc),candidates});await refreshWorkQueues();return}
  const roles=conflictRelationshipRoles(conflict),preferred=normalizeSku(preferredSku),tag=preferred===roles.newest?'SCANNED_REPLACES_EXISTING':'EXISTING_REPLACES_SCANNED';await relationshipService.resolveConflict(upc,preferred,tag);await addReplacementToTodaysAceNewItems(preferred,upc);diag('identity_conflict_resolved',{upc:normalizeUpc(upc),preferredSku:preferred,resolutionTag:tag,replacedSkus:candidates.filter(x=>x!==preferred),aceNewItems:true});await refreshWorkQueues();
 }

 function bind({on}={}){
  if(typeof on!=='function')throw new Error('Identity Work Controller requires the shared event binder.');
  on('identityWorkQueues','click',async e=>{const btn=e.target.closest?.('button[data-upc][data-sku]');if(!btn)return;btn.disabled=true;try{await resolveConflict(btn.dataset.upc,btn.dataset.sku,btn.classList.contains('identityResolveUnknown')?'UNKNOWN':'RESOLVE')}catch(err){diag('identity_conflict_resolution_failed',{upc:btn.dataset.upc,sku:btn.dataset.sku,message:err?.message||String(err)});alertUser(`SKU conflict could not be resolved: ${err?.message||err}`)}finally{btn.disabled=false}});
 }

 return Object.freeze({bind,refreshWorkQueues,runAddToLocalLibraryBatch,runDeferredAceNetRefreshBatch,recheckResearchSku,resolveResearchAction,unresolvedOriginForCurrent,recordUnresolved,resolveConflict,conflictRelationshipRoles});
} return Object.freeze({create});
})();
window.UPCIdentityWorkController=UPCIdentityWorkController;
