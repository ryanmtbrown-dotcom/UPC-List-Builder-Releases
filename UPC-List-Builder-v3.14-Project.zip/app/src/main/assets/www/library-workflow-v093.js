/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/library-workflow-v093.js
 * Owner: Master Library Workflow
 * Role: Application/domain workflow service
 * Responsibility: Owns Master Library import/export workflow, mapping continuation, progress coordination, and library-facing user operations distinct from the presentation controller.
 * Does not own: Raw database primitives; catalog authority policy; normal lookup; native AceNet session/extraction.
 * Side effects: Coordinates XLSX import/export and repository/service calls; may update UI through injected elements/callbacks.
 * Related code: Presentation/navigation belongs to catalog/master-library-controller.js; persistence belongs to repository owners.
 */
const UPCMasterLibraryWorkflow=(()=>{
 function create({
  elementById,escapeHtml,diagnostic,progress,refreshLibraryStatus,localRepository,masterRepository,
  identifierNormalization,xlsxImporter,combinedMasterExportProvider,identityWorkController,messageUser,alertUser,promptUser,fileDelivery,performanceNow
 }={}){
  if(typeof elementById!=='function'||typeof escapeHtml!=='function'||typeof diagnostic!=='function'||typeof progress!=='function'||typeof refreshLibraryStatus!=='function')throw new Error('Master Library Workflow UI dependencies are incomplete.');
  if(!localRepository||!masterRepository||!identifierNormalization||!xlsxImporter||!identityWorkController||typeof promptUser!=='function'||typeof fileDelivery?.deliverBytes!=='function')throw new Error('Master Library Workflow data dependencies are incomplete.');
  const $=elementById,esc=escapeHtml,diag=diagnostic,UPCLocalRepository=localRepository,UPCMasterRepository=masterRepository,UPCIdentifierNormalization=identifierNormalization,XLSXImporter=xlsxImporter,alert=alertUser;

const F=[['sku','SKU',['ACE SKU','SKU']],['upc','UPC',['UPC/EAN','UPC']],['description','Description',['Description']],['orderMultiple','Order Multiple',['Order Multiple']],['retailUnits','Retail Units',['Retail Units']],['cost','Cost',['Retailer Each Cost','Cost']],['mfg','Manufacturer Number',['MFG #','Manufacturer Number','MFG Number']],['commodity','Commodity Group',['Commodity Group']],['merchClass','Merchandise Class Number',['Merchandise Class Number','Merchant Class','Merchandise Class']],['productGroup','Product Group Number',['Product Group Number']]].map(([key,label,aliases])=>({key,label,aliases}));
let wiz={queue:[],index:0,field:0}, mappingMode=null;
const masterLibraryOperationState=new Map();
function libraryAlaskaStamp(date=new Date()){const parts=new Intl.DateTimeFormat('en-US',{timeZone:'America/Anchorage',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:false,timeZoneName:'short'}).formatToParts(date),get=t=>parts.find(p=>p.type===t)?.value||'';return{date:`${get('year')}-${get('month')}-${get('day')}`,time:`${get('hour')}:${get('minute')}:${get('second')}`,zone:get('timeZoneName')}}
function masterLibraryOperationStart(id,what,expected,technical={}){const now=new Date(),ak=libraryAlaskaStamp(now),started=Math.round(performanceNow()),state={id,what,expected,startedAt:now.toISOString(),startedAlaska:`${ak.date} ${ak.time} ${ak.zone}`,startedPerformanceMs:started};masterLibraryOperationState.set(id,state);diag('master_library_operation_started',{operationId:id,lifecycle:'STARTED',whatWeAreDoing:what,expectedResult:expected,actualResult:'Operation started.',result:'IN_PROGRESS',timing:{startedAtAlaska:state.startedAlaska,durationMs:null},technical});return state}
function masterLibraryOperationObserve(id,what,expected,actual,result='OBSERVED',technical={}){const state=masterLibraryOperationState.get(id),duration=state?Math.max(0,Math.round(performanceNow())-state.startedPerformanceMs):null;diag('master_library_operation_observation',{operationId:id,whatWeAreDoing:what,expectedResult:expected,actualResult:actual,result,timing:{startedAtAlaska:state?.startedAlaska||null,durationMs:duration},technical})}
function masterLibraryOperationFinish(id,actual,result='PASS',technical={}){const state=masterLibraryOperationState.get(id);if(!state)return null;const now=new Date(),ak=libraryAlaskaStamp(now),duration=Math.max(0,Math.round(performanceNow())-state.startedPerformanceMs);masterLibraryOperationState.delete(id);diag('master_library_operation_completed',{operationId:id,lifecycle:'COMPLETED',whatWeAreDoing:state.what,expectedResult:state.expected,actualResult:actual,result,timing:{startedAtAlaska:state.startedAlaska,finishedAtAlaska:`${ak.date} ${ak.time} ${ak.zone}`,durationMs:duration},technical});return duration}
const localMeta=()=>UPCLocalRepository.getMetadata();
const normSku=UPCIdentifierNormalization.normalizeSKU;
function isAddToLibraryItem(item){return item?.primaryPurpose==='Add to Library'||(item?.tags||[]).includes('Add to Library')}
function workflowActive(item){return !['IMPORTED','CLEARED'].includes(item?.libraryWorkflowStatus)}
async function summary(){const [q,locals]=await Promise.all([UPCLocalRepository.getUpdateQueue(),localMeta()]),completed=Array.isArray(locals.records)?locals.records.length:0;const el=$('libraryQueueSummary');if(el)el.textContent=`${q.length} Add to Local Library waiting · ${completed} durable Local Library record(s)`;return{total:q.length,completed,waiting:q.length}}
async function enqueueFromListItem(list,item){if(!list||!item||!isAddToLibraryItem(item)||!workflowActive(item))return;const sku=normSku(item.sku||'');if(!sku)return;await UPCLocalRepository.enqueueSku({sku,source:'LIST_ADD_TO_LIBRARY',queueReason:'LIST_TAGGED_ADD_TO_LIBRARY'});await summary()}
async function exportCombinedMaster(){const combined=combinedMasterExportProvider?.();if(!combined)throw new Error('Combined Master Export module is unavailable.');const out=await combined.exportInteractive({promptUser,fileDelivery});if(!out||out.cancelled)return;if(out.exported)alert(`Exported ${out.name} with ${out.rowCount.toLocaleString()} combined catalog row(s).`)}
async function showMapping(parsed,file){mappingMode={type:'import',parsed,file,payload:parsed.sourcePayload||parsed};const opts=parsed.headers.map((h,i)=>`<option value="${i}">${esc(h)}</option>`).join('');$('upcColumn').innerHTML=opts;$('skuColumn').innerHTML=opts;const ui=Number.isInteger(parsed.suggestedUPCIndex)&&parsed.suggestedUPCIndex>=0?parsed.suggestedUPCIndex:Math.max(0,parsed.headers.findIndex(h=>/upc/i.test(h))),si=Number.isInteger(parsed.suggestedSKUIndex)&&parsed.suggestedSKUIndex>=0?parsed.suggestedSKUIndex:Math.max(0,parsed.headers.findIndex(h=>/\bsku\b/i.test(h)));$('upcColumn').value=String(ui);$('skuColumn').value=String(si);$('mappingArea').classList.remove('hidden')}
async function importFile(file){const operationId=`MASTER_LIBRARY_IMPORT:${Date.now()}:${Math.random().toString(36).slice(2,8)}`;masterLibraryOperationStart(operationId,'Read and validate a Master Library workbook before activating it.','The workbook is parsed without replacing the active library, then the user is shown the detected UPC/SKU mapping for confirmation.',{fileName:file?.name||null,fileSize:file?.size||0});try{progress('Reading XLSX',1,file.name);const parsed=await XLSXImporter.importFile(file,progress);masterLibraryOperationObserve(operationId,'Parse the selected workbook.','The workbook yields a usable header row and searchable records while the existing active generation remains untouched.',`Workbook parsed: valid records=${parsed.validRecords||0}; total rows=${parsed.totalRows||0}; mapping confirmation required.`, 'OBSERVED',{stage:'PARSE',validRecords:parsed.validRecords||0,totalRows:parsed.totalRows||0,headers:Array.isArray(parsed.headers)?parsed.headers.length:0,needsUPCMapping:Boolean(parsed.needsUPCMapping)});parsed.masterLibraryOperationId=operationId;await showMapping(parsed,file);progress('Column mapping required',20,'Confirm the UPC and SKU columns.')}catch(e){masterLibraryOperationFinish(operationId,`Master Library workbook import preparation failed: ${e?.message||String(e)}.`,'FAIL',{stage:'PARSE',errorName:e?.name||null,errorMessage:e?.message||String(e)});progress('Import failed',0,e?.message||String(e));await messageUser?.(`Master Library import failed before activation.\n\n${e?.message||String(e)}`,'Import Failed')}}
async function editMapping(){const meta=await UPCMasterRepository.getMetadata();if(!meta?.generation)return alert('Import a Master Library first.');mappingMode={type:'edit',meta};const opts=(meta.headers||[]).map((h,i)=>`<option value="${i}">${esc(h)}</option>`).join('');$('upcColumn').innerHTML=opts;$('skuColumn').innerHTML=opts;$('upcColumn').value=String(Math.max(0,meta.headers.indexOf(meta.upcHeader)));$('skuColumn').value=String(Math.max(0,meta.headers.indexOf(meta.skuHeader)));$('mappingArea').classList.remove('hidden')}
async function saveMapping(){
 if(!mappingMode)return;
 const ui=Number($('upcColumn').value),si=Number($('skuColumn').value);
 if(ui===si)return alert('UPC and SKU must use different columns.');
 if(mappingMode.type==='edit'){
  const operationId=`MASTER_LIBRARY_REINDEX:${Date.now()}:${Math.random().toString(36).slice(2,8)}`,selectedUpcHeader=mappingMode.meta.headers[ui],selectedSkuHeader=mappingMode.meta.headers[si];
  masterLibraryOperationStart(operationId,'Reindex the active Master Library using the user-confirmed UPC and SKU columns.','The same active library records remain active while their UPC/SKU search keys and mapping metadata are rebuilt from the selected columns.',{mode:'edit',previousGeneration:mappingMode.meta.generation||null,upcHeader:selectedUpcHeader,skuHeader:selectedSkuHeader});
  try{
   diag('master_library_mapping_save_requested',{mode:'edit',upcIndex:ui,skuIndex:si,upcHeader:selectedUpcHeader,skuHeader:selectedSkuHeader});
   const updatedMeta=await UPCMasterRepository.reindexActive(selectedUpcHeader,selectedSkuHeader);
   diag('master_library_mapping_persisted',{mode:'edit',upcHeader:updatedMeta?.upcHeader||null,skuHeader:updatedMeta?.skuHeader||null,generation:updatedMeta?.generation||null});
   masterLibraryOperationFinish(operationId,`Active Master Library mapping updated: UPC=${updatedMeta?.upcHeader||"none"}; SKU=${updatedMeta?.skuHeader||"none"}; generation preserved=${updatedMeta?.generation===mappingMode.meta.generation?"yes":"no"}.`,'PASS',{mode:'edit',generation:updatedMeta?.generation||null,generationPreserved:updatedMeta?.generation===mappingMode.meta.generation,upcHeader:updatedMeta?.upcHeader||null,skuHeader:updatedMeta?.skuHeader||null});
   mappingMode=null;$('mappingArea').classList.add('hidden');await refreshLibraryStatus();return;
  }catch(e){masterLibraryOperationFinish(operationId,`Active Master Library reindex failed: ${e?.message||String(e)}.`,'FAIL',{mode:'edit',errorName:e?.name||null,errorMessage:e?.message||String(e)});throw e}
 }
 let parsed=mappingMode.parsed;
 const operationId=parsed.masterLibraryOperationId||`MASTER_LIBRARY_IMPORT:${Date.now()}:${Math.random().toString(36).slice(2,8)}`;
 if(!masterLibraryOperationState.has(operationId))masterLibraryOperationStart(operationId,'Activate an imported Master Library after the user confirms its UPC and SKU mappings.','A complete official generation is staged first, then metadata points to it and older generations are cleaned up. Local Library remains separate.',{mode:'import',fileName:mappingMode.file?.name||null});
 try{
  if(parsed.needsUPCMapping||parsed.upcIndex!==ui)parsed=await XLSXImporter.continueWithMapping(mappingMode.payload,ui,progress);
  parsed.upcHeader=parsed.headers[ui];parsed.upcIndex=ui;const skuHeader=parsed.headers[si];
  diag('master_library_mapping_save_requested',{mode:'import',upcIndex:ui,skuIndex:si,upcHeader:parsed.upcHeader||null,skuHeader,recordCount:parsed.records?.length||0});
  const previous=(await UPCMasterRepository.getMetadata())?.generation||null,locals=await localMeta();
  progress('Saving library',52,`Home Office ${parsed.validRecords.toLocaleString()} official records`);
  const generation=await UPCMasterRepository.stageGeneration(parsed.records,null,{skuHeader}),meta={key:'library',generation,fileName:mappingMode.file?.name||'library.xlsx',fileSize:mappingMode.file?.size||0,recordCount:parsed.validRecords,officialRecordCount:parsed.validRecords,totalRows:parsed.totalRows,headers:parsed.headers,headerRow:parsed.headerRow||null,upcHeader:parsed.upcHeader,skuHeader,upcIndex:ui,skuIndex:si,importedAt:new Date().toISOString()};
  masterLibraryOperationObserve(operationId,'Stage the official replacement Master Library generation.','Only imported official records become Master Library rows; durable Local Library records remain separate.',`Staged official generation ${generation} with ${parsed.validRecords} records; previous active generation=${previous||"none"}.`,'OBSERVED',{stage:'STAGED_OFFICIAL',previousGeneration:previous,newGeneration:generation,recordCount:parsed.validRecords});
  await UPCMasterRepository.saveMetadata(meta);
  const persistedMeta=await UPCMasterRepository.getMetadata();if(persistedMeta?.generation!==generation)throw new Error('Persisted Master Library generation did not match the staged official generation.');
  await UPCMasterRepository.cleanupGenerations(generation);
  mappingMode=null;$('mappingArea').classList.add('hidden');
  const localCount=Array.isArray(locals.records)?locals.records.length:0;
  progress('Complete',100,`${parsed.validRecords.toLocaleString()} official records · ${localCount} Local Library record(s) remain separate`);
  diag('master_library_official_import_activated',{official:parsed.validRecords,generation,localStored:localCount,localApplied:false});
  masterLibraryOperationFinish(operationId,`Master Library activation completed with official records only; Local Library remained separate; active generation=${generation}.`,'PASS',{mode:'import',previousGeneration:previous,activeGeneration:generation,officialRecordCount:parsed.validRecords||0,localStored:localCount,upcHeader:parsed.upcHeader||null,skuHeader});
  await refreshLibraryStatus();
 }catch(e){masterLibraryOperationFinish(operationId,`Master Library activation failed: ${e?.message||String(e)}.`,'FAIL',{mode:'import',errorName:e?.name||null,errorMessage:e?.message||String(e)});throw e}
}
async function mappingSummary(){const meta=await UPCMasterRepository.getMetadata(),area=$('editMappingArea'),s=$('mappingSummary');if(area&&s){area.classList.toggle('hidden',!meta?.generation);s.textContent=meta?.generation?`UPC: ${meta.upcHeader||'Not configured'} · SKU: ${meta.skuHeader||'Not configured'}`:''}}
function bind(){
 const batch=$('openManualLibraryEntry');if(batch)batch.onclick=()=>identityWorkController.runAddToLocalLibraryBatch().catch(e=>alert(e.message));
 const combined=$('exportCombinedMaster');if(combined)combined.onclick=()=>exportCombinedMaster().catch(e=>alert(e.message));
 $('editLibraryMapping').onclick=()=>editMapping().catch(e=>alert(e.message));
 $('continueImport').onclick=()=>saveMapping().catch(e=>alert(e.message));
 $('libraryFile').onchange=e=>{const f=e.target.files?.[0];if(f)importFile(f).catch(async err=>{diag('master_library_import_unhandled_failure',{message:err?.message||String(err),name:err?.name||null});progress('Import failed',0,err?.message||String(err));await messageUser?.(`Master Library import failed.\n\n${err?.message||String(err)}`,'Import Failed')})};
 summary().catch(()=>{});mappingSummary().catch(()=>{});
}
 return Object.freeze({bind,refreshQueue:summary,enqueueFromListItem,importFile,editMapping,saveMapping,mappingSummary});
 }
 return Object.freeze({create});
})();
window.UPCMasterLibraryWorkflow=UPCMasterLibraryWorkflow;
