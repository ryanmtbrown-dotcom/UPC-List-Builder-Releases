/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/local-identifier-resolver.js
 * Owner: Local Identifier Resolution Domain
 * Role: Read-only resolver
 * Responsibility: Owns deterministic UPC/SKU resolution across Effective Catalog evidence and saved current identifier relationships, including explicit conflict results.
 * Does not own: Persistence mutation; AceNet/network; UI; catalog refresh.
 * Side effects: Reads injected resolver/relationship services only.
 * Related code: Catalog selection belongs to Effective Catalog Resolver; writes belong to relationship/catalog services.
 */
const UPCLocalIdentifierResolver=(()=>{
 const normalizeSKU=UPCIdentifierNormalization.normalizeSKU,normalizeUPC=UPCIdentifierNormalization.normalizeUPC;
 const physicalKey=result=>{
  if(result?.status!=='FOUND')return'';
  if(result.localRecordId!=null)return`LOCAL:${result.localRecordId}`;
  if(result.activeMasterRecordId!=null)return`MASTER:${result.activeMasterRecordId}`;
  if(result.masterRecordId!=null)return`MASTER:${result.masterRecordId}`;
  const sku=normalizeSKU(result?.row?.skuKey);return sku?`SKU:${sku}`:'';
 };
 const sameCatalogIdentity=(a,b)=>{
  const ak=physicalKey(a),bk=physicalKey(b);if(ak&&bk)return ak===bk;
  const as=normalizeSKU(a?.row?.skuKey),bs=normalizeSKU(b?.row?.skuKey);return Boolean(as&&bs&&as===bs);
 };
 async function resolveSKU(sku){
  const skuKey=normalizeSKU(sku);if(!skuKey)return{status:'INVALID',identifierType:'SKU',skuKey:'',sku:null,catalog:null};
  const catalog=await UPCEffectiveCatalogResolver.resolveSKU(skuKey);
  return{status:catalog.status,identifierType:'SKU',skuKey,sku:catalog.status==='FOUND'?normalizeSKU(catalog.row?.skuKey||skuKey):skuKey,catalog};
 }
 async function resolveUPC(upc,{format=null}={}){
  const upcKey=normalizeUPC(upc);if(!upcKey)return{status:'INVALID',identifierType:'UPC',upcKey:'',sku:null,directCatalog:null,relationship:null,catalog:null};
  const [directCatalog,relationship]=await Promise.all([
   UPCEffectiveCatalogResolver.resolveDirectUPC(upcKey,{format}),
   UPCIdentifierRelationshipService.resolveUPC(upcKey)
  ]);
  if(directCatalog.status==='AMBIGUOUS')return{status:'AMBIGUOUS',identifierType:'UPC',upcKey,sku:null,directCatalog,relationship,catalog:directCatalog,reason:'DIRECT_CATALOG_AMBIGUOUS'};
  if(relationship.status==='CONFLICT')return{status:'CONFLICT',identifierType:'UPC',upcKey,sku:null,directCatalog,relationship,catalog:directCatalog.status==='FOUND'?directCatalog:null,reason:'RELATIONSHIP_CONFLICT'};
  if(directCatalog.status==='FOUND'){
   const directSku=normalizeSKU(directCatalog.row?.skuKey);
   if(relationship.status==='UNKNOWN')return{status:'FOUND',identifierType:'UPC',upcKey,sku:directSku||null,directCatalog,relationship,catalog:directCatalog,source:'DIRECT_CATALOG'};
   const relatedSku=normalizeSKU(relationship.sku),relatedCatalog=await UPCEffectiveCatalogResolver.resolveSKU(relatedSku);
   if(relatedCatalog.status==='AMBIGUOUS')return{status:'AMBIGUOUS',identifierType:'UPC',upcKey,sku:relatedSku,directCatalog,relationship,catalog:relatedCatalog,reason:'RELATIONSHIP_SKU_CATALOG_AMBIGUOUS'};
   if(relatedCatalog.status!=='FOUND')return{status:'CONFLICT',identifierType:'UPC',upcKey,sku:null,directCatalog,relationship,catalog:directCatalog,relatedCatalog,reason:'DIRECT_CATALOG_DISAGREES_WITH_MISSING_RELATIONSHIP_SKU'};
   if(!sameCatalogIdentity(directCatalog,relatedCatalog))return{status:'CONFLICT',identifierType:'UPC',upcKey,sku:null,directCatalog,relationship,catalog:directCatalog,relatedCatalog,reason:'DIRECT_CATALOG_DISAGREES_WITH_RELATIONSHIP'};
   return{status:'FOUND',identifierType:'UPC',upcKey,sku:relatedSku||directSku||null,directCatalog,relationship,catalog:directCatalog,relatedCatalog,source:'DIRECT_CATALOG_AND_RELATIONSHIP'};
  }
  if(relationship.status==='KNOWN'){
   const sku=normalizeSKU(relationship.sku),catalog=await UPCEffectiveCatalogResolver.resolveSKU(sku);
   if(catalog.status==='FOUND')return{status:'FOUND',identifierType:'UPC',upcKey,sku,directCatalog,relationship,catalog,source:'RELATIONSHIP'};
   if(catalog.status==='AMBIGUOUS')return{status:'AMBIGUOUS',identifierType:'UPC',upcKey,sku,directCatalog,relationship,catalog,reason:'RELATIONSHIP_SKU_CATALOG_AMBIGUOUS'};
   return{status:'SKU_NOT_FOUND',identifierType:'UPC',upcKey,sku,directCatalog,relationship,catalog,reason:'RELATIONSHIP_SKU_NOT_IN_EFFECTIVE_CATALOG'};
  }
  return{status:'UNKNOWN',identifierType:'UPC',upcKey,sku:null,directCatalog,relationship,catalog:null,reason:'NO_LOCAL_IDENTITY'};
 }
 return Object.freeze({resolveSKU,resolveUPC});
})();
window.UPCLocalIdentifierResolver=UPCLocalIdentifierResolver;
