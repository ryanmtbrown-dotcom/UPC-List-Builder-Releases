/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/local-repository.js
 * Owner: Local Catalog Persistence
 * Role: Repository facade
 * Responsibility: Owns physical Local Library metadata/record access and approved Local persistence primitives.
 * Does not own: Master-vs-Local selection; lookup orchestration; UI; Work Sessions; network.
 * Side effects: Direct UPCDB Local-store/meta calls are permitted as repository adaptation.
 * Related code: Workflow mutation belongs to catalog refresh/maintenance services.
 */
const UPCLocalRepository=(()=>{
 const getMetadata=async()=>await UPCDB.get('meta','localLibraryAdditions')||{key:'localLibraryAdditions',records:[]};
 const saveMetadata=meta=>UPCDB.put('meta',{...(meta||{}),key:'localLibraryAdditions'});
 const getRecords=async()=>{const meta=await getMetadata();return Array.isArray(meta?.records)?meta.records:[]};
 return Object.freeze({
  getMetadata,saveMetadata,
  lookupExactUPC:UPCDB.lookupUniqueLocalExact,
  lookupPrefixUPC:UPCDB.lookupUniqueLocalPrefix,
  lookupSKU:UPCDB.lookupUniqueLocalSKU,
  getRecords,
  getRecordBySku:UPCDB.getLocalLibraryRecordBySku,
  stageAceNetItem:UPCDB.stageLocalLibraryAceNetItem,
  stageThirdPartyItem:UPCDB.stageLocalLibraryThirdPartyItem,
  correctFields:UPCDB.correctLocalLibraryFields,
  clearAceNetFields:UPCDB.clearLocalLibraryAceNetFields,
  setAceNetVerification:UPCDB.setLocalLibraryAceNetVerification,
  updateMasterUpc:UPCDB.updateLocalLibraryMasterUpc,
  findRepairCandidates:UPCDB.findLocalLibraryRepairCandidates,
  enqueueSku:UPCDB.enqueueLibrarySku,
  enqueueUpdate:UPCDB.enqueueLibraryUpdate,
  getUpdateQueue:UPCDB.getLibraryUpdateQueue,
  clearUpdateQueue:UPCDB.clearLibraryUpdateQueue,
  removeUpdateQueueSku:UPCDB.removeLibraryUpdateQueueSku
 });
})();
window.UPCLocalRepository=UPCLocalRepository;
