# Lookup Directory Ownership

OWNS: normal UPC/SKU lookup orchestration, capture of deferred live-refresh work after lookup, lookup-specific price/image services, item-record mapping, manual identifier input, routing, and item presentation.

DOES NOT OWN: raw IndexedDB, AceNet authentication/session implementation, DSD/MISC workspace rules, scanner camera lifecycle, or durable identity policy.

DEPENDENCY RULE: lookup may consume resolver/catalog/AceNet capabilities and the shared Price Authority pure selector; durable writes flow through catalog/relationship owners. Ace price-checking uses Level 2 Retail, never generic Ace Retail fallback.

LIVE PRICE PRESENTATION: item-presentation-controller owns amber pending, neutral verified, and red unavailable display states with no changes to lookup pacing or persistence.
