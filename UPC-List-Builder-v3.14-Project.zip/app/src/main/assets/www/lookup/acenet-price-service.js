/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/lookup/acenet-price-service.js
 * Owner: Lookup / AceNet Price
 * Role: Lookup service
 * Responsibility: Owns strict AceNet price parsing, price request dispatch configuration, and health-aware price request handling.
 * Does not own: Price presentation, native session/extraction, catalog persistence, or general lookup orchestration.
 * Side effects: Calls the injected AceNet broker/bridge capability and emits diagnostics.
 * Related code: Request correlation belongs to acenet-client.js; presentation belongs to Item Presentation Controller.
 */
const UPCAceNetPriceService=(()=>{
 function create({client,normalizeSku,normalizeUpc,normalizeHealthStatus,getRuntimeState,diagnostic,bridgeProvider}={}){
  if(!client||typeof client.configure!=='function'||typeof client.requestPrice!=='function')throw new Error('AceNet Price Service requires the shared AceNet client.');
  if(typeof normalizeSku!=='function'||typeof normalizeUpc!=='function'||typeof normalizeHealthStatus!=='function'||typeof getRuntimeState!=='function')throw new Error('AceNet Price Service dependencies are incomplete.');
  const diag=typeof diagnostic==='function'?diagnostic:()=>{};
  function parseVerifiedPrice(raw){
   if(raw===null||raw===undefined)return null;
   const text=String(raw).trim();if(!text||!/^\$?(?:\d+|\d{1,3}(?:,\d{3})+)\.\d{2}$/.test(text))return null;
   const value=Number(text.replace(/[$,]/g,''));return Number.isFinite(value)&&value>0?value:null;
  }
  client.configure({normalizeSKU:normalizeSku,normalizeUPC:normalizeUpc,parsePrice:parseVerifiedPrice,diag,bridgeProvider});
  function requestPrice(sku,{upcEnrichment=false}={}){
   const expectedSku=normalizeSku(sku),health=normalizeHealthStatus(getRuntimeState()?.healthStatus);
   if(health==='DOWN'||health==='UNAVAILABLE')diag('acenet_live_check_known_unavailable_handoff',{sku:expectedSku,healthStatus:health,upcEnrichment:Boolean(upcEnrichment),handoff:'Native AceNet coordinator admits only an armed one-shot user recovery; otherwise it returns UNAVAILABLE without session establishment.'});
   return client.requestPrice(expectedSku,{upcEnrichment:Boolean(upcEnrichment)});
  }
  return Object.freeze({parseVerifiedPrice,requestPrice});
 }
 return Object.freeze({create});
})();
window.UPCAceNetPriceService=UPCAceNetPriceService;
