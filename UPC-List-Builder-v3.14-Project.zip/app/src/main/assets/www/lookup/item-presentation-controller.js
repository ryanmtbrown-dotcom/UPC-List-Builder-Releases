/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/lookup/item-presentation-controller.js
 * Owner: Lookup Presentation
 * Role: Controller/renderer
 * Responsibility: Owns lookup presentation generations, checking/final preview state, stale-result rejection, price difference/image/duplicate presentation.
 * Does not own: Lookup resolution policy, catalog/identity persistence, AceNet transport, or Work Session state.
 * Side effects: Mutates lookup DOM and invokes injected image/presentation utilities; holds transient presentation state.
 * Related code: Resolution belongs to normal-lookup-controller.js; image mechanics belong to product-image-service.js.
 */
const UPCItemPresentationController=(()=>{
 function create({
  elementById,setText,subsystemOperationStart,subsystemOperationFinish,diagnostic,
  releaseNotFoundSystemPurpose,applyNotFoundSystemPurpose,configureTags,applyDefaultTagSelection,
  syncManualPriceVisibility,productImageService,parseMoney,comparisonEnabled,barcodeProvider,barcodePlanner,locationLookupService
 }={}){
  if(typeof elementById!=='function'||typeof setText!=='function')throw new Error('Item Presentation Controller DOM/state dependencies are incomplete.');
  if(typeof subsystemOperationStart!=='function'||typeof subsystemOperationFinish!=='function'||!productImageService||typeof parseMoney!=='function'||typeof comparisonEnabled!=='function')throw new Error('Item Presentation Controller lifecycle/image dependencies are incomplete.');
  const $=elementById,diag=typeof diagnostic==='function'?diagnostic:()=>{};
  function syncBarcodeButton(value){const button=$('previewBarcodeButton');if(button)button.classList.toggle('hidden',!barcodePlanner?.(value)?.ok)}
  let pending=null,lookupPresentationGeneration=0;
  function getPending(){return pending}
  function setPending(value){pending=value;return pending}

  function getPresentedItem(){return getPending()}
  function updatePriceDifference(){
   const pending=getPending(),lib=UPCPriceAuthority.observedPrice(pending),label=parseMoney($('labelPrice')?.value),box=$('priceDifferenceBox'),out=$('priceDifference');if(!box||!out)return;
   box.classList.remove('warning','match');if(lib==null||label==null){out.textContent='—';return}
   const diff=label-lib;out.textContent=`${diff>=0?'+':'−'}${Math.abs(diff).toFixed(2)}`;box.classList.add(Math.abs(diff)<0.005?'match':'warning');
   if(Math.abs(diff)>=0.005)diag('price_difference_detected',{upc:pending?.upc,libraryPrice:lib,labelPrice:label,difference:diff});
  }
  // AceNet status is presentation-only. A pending request never delays scanning
  // and its state is never written into a session, catalog, or exported workbook.
  function setAceNetVisualState(state){
   const row=$('aceNetPriceRow');if(!row)return;
   row.classList.toggle('aceNetStatus-pending',state==='pending');
   row.classList.toggle('aceNetStatus-unavailable',state==='unavailable');
   row.setAttribute('aria-busy',state==='pending'?'true':'false');
   row.setAttribute('data-price-state',state);
  }
  function syncAceNetPriceVisibility(){const row=$('aceNetPriceRow'),thirdParty=String(getPending()?.recordOrigin||'')==='THIRD_PARTY_VENDOR';if(row)row.classList.toggle('hidden',!comparisonEnabled()&&!thirdParty)}
  function syncExternalPriceSource(item=getPending()){const thirdParty=String(item?.recordOrigin||'')==='THIRD_PARTY_VENDOR';setText('aceNetPriceLabel',thirdParty?'Vendor Price':'AceNet Level 2 Retail');return thirdParty}
  function clearLookupTransientPriceState(upc){
   const previous=String($('labelPrice')?.value??'').trim();if($('labelPrice'))$('labelPrice').value='';$('manualPriceEntry')?.classList.add('hidden');updatePriceDifference();diag('lookup_transient_price_cleared',{upc,hadPreviousLabelPrice:previous!==''});
  }
  function showDuplicateBlockedModal(){const overlay=$('duplicateBlockedOverlay');if(!overlay)return;const ok=$('duplicateBlockedOk');overlay.classList.remove('hidden');setTimeout(()=>ok?.focus(),0)}
  function closeDuplicateBlockedModal(){$('duplicateBlockedOverlay')?.classList.add('hidden')}
  function promptDuplicateItem(existing,{purpose='LIST'}={}){
   // Reuse the established two-answer duplicate prompt without changing ordinary tagging semantics.
   return new Promise(resolve=>{
    const overlay=$('duplicateItemOverlay'),title=overlay.querySelector('.actionDialogHead strong'),
     question=overlay.querySelector('.actionDialog>p'),no=$('duplicateItemNo'),yes=$('duplicateItemYes'),
     original=[title.textContent,question.textContent,no.textContent,yes.textContent];
    if(purpose==='LOCATION'){
     title.textContent='Separate Physical Placement';
     question.textContent='This merchandise already has another scanned or saved physical placement. Is this a genuinely separate stocking location? Choose No for adjacent facings or an accidental repeat.';
     no.textContent='No · Discard Repeat';yes.textContent='Yes · Separate Location';
    }
    $('duplicateItemName').textContent=existing?.description||existing?.upc||'This item';
    $('duplicateItemUpc').textContent=existing?.upc||'';
    overlay.classList.remove('hidden');
    let done=false;const finish=value=>{
     if(done)return;done=true;overlay.classList.add('hidden');no.onclick=null;yes.onclick=null;
     [title.textContent,question.textContent,no.textContent,yes.textContent]=original;
     resolve(value);
    };
    no.onclick=()=>finish(false);yes.onclick=()=>finish(true);
    no.focus();
   });
  }

  function setImageState(state,url=''){
   const frame=$('productImageFrame'),img=$('productImage'),none=$('productImageUnavailable');if(!frame)return;
   frame.classList.toggle('is-empty',state==='empty');img?.classList.toggle('hidden',state!=='image');none?.classList.toggle('hidden',state!=='unavailable');
   const pending=getPending();
   if(img&&state==='image'){img.src=url;img.alt=pending?.description?`Product image for ${pending.description}`:'Product image'}else if(img){img.removeAttribute('src');img.alt=''}
  }

  function clearLocation(){
   $('locationLookupPanel')?.classList.add('hidden');
   setText('locationLookupHeadline','');
  }
  function displayLocationFor(item,generation){
   clearLocation();
   if(!locationLookupService||item?.status==='AMBIGUOUS'||!item?.sku&&!item?.upc)return;
   const expectedSku=item.sku,expectedUpc=item.upc;
   // Independent read, never awaited by pricing, scanner or field-list workflow.
   void Promise.resolve().then(()=>locationLookupService.find({skuKey:expectedSku,upcKey:expectedUpc})).then(facts=>{
    if(!isCurrent(generation)||getPending()?.sku!==expectedSku||getPending()?.upc!==expectedUpc)return;
    const card=$('locationLookupPanel');if(!card)return;
    card.dataset.kind=facts.kind;setText('locationLookupHeadline',facts.headline);
    card.classList.remove('hidden');
   }).catch(error=>{
    if(!isCurrent(generation)||getPending()?.sku!==expectedSku||getPending()?.upc!==expectedUpc)return;
    diag('location_lookup_unavailable',{category:'LOCAL_LOCATION_READ',message:error?.message||'Unavailable'});
    // Location failure must never impede pricing, list mutations or scanner operation.
    const card=$('locationLookupPanel');if(card){card.dataset.kind='UNKNOWN';setText('locationLookupHeadline','Location temporarily unavailable');card.classList.remove('hidden')}
   });
  }
  function resetPreview(){
   lookupPresentationGeneration++;clearLocation();
   $('itemPreview')?.classList.remove('lookupPending');releaseNotFoundSystemPurpose();setPending(null);
   const badge=$('lookupBadge');if(badge){badge.textContent='READY';badge.className='badge ready'}
   setText('previewPrice','—');setAceNetVisualState('idle');setText('aceNetPriceCompare','—');setText('aceNetPriceLabel','AceNet Level 2 Retail');setText('previewSku','—');setText('previewDescription','SCAN OR ENTER A UPC TO LOOK UP AN ITEM');setText('previewUpc','—');syncBarcodeButton(null);setText('previewOrderMultiple','—');setText('previewRetailUnits','—');
   const preview=$('itemPreview');if(preview)preview.classList.add('empty');setImageState('empty');$('priceCompare')?.classList.add('hidden');if($('labelPrice'))$('labelPrice').value='';$('manualPriceEntry')?.classList.add('hidden');
   applyDefaultTagSelection();updatePriceDifference();const add=$('addToList');if(add)add.disabled=true;const missing=$('markMissingLabel');if(missing)missing.disabled=true;
  }

  function beginLookupPresentation(key,mode){
   const generation=++lookupPresentationGeneration;clearLocation();
   const op=`ITEM_PRESENTATION:${generation}`;subsystemOperationStart('ITEM_PRESENTATION',op,`Prepare the result surface for ${mode} ${key}.`,'The surface enters a bounded CHECKING state, clears stale item values, disables Add, and only this generation may later present a result.',{key,mode,generation});
   setPending(null);const badge=$('lookupBadge');if(badge){badge.textContent='CHECKING';badge.className='badge checking'}
   setText('previewPrice','—');setAceNetVisualState('idle');setText('aceNetPriceCompare','—');setText('aceNetPriceLabel','AceNet Level 2 Retail');setText('previewSku','—');setText('previewDescription','CHECKING ITEM…');setText('previewUpc','—');syncBarcodeButton(null);setText('previewOrderMultiple','—');setText('previewRetailUnits','—');
   const preview=$('itemPreview');if(preview){preview.classList.remove('empty');preview.classList.add('lookupPending')}
   setImageState('empty');$('priceCompare')?.classList.add('hidden');if($('labelPrice'))$('labelPrice').value='';$('manualPriceEntry')?.classList.add('hidden');const add=$('addToList');if(add)add.disabled=true;const missing=$('markMissingLabel');if(missing)missing.disabled=true;
   $('status').textContent='Checking Master Library…';diag('lookup_presentation_pending',{key,lookupModeInput:mode,generation});
   subsystemOperationFinish(op,`Presentation generation ${generation} entered CHECKING with stale result fields cleared.`,'PASS',{key,mode,generation,addDisabled:Boolean($('addToList')?.disabled)});return generation;
  }

  function isCurrent(generation){return generation===lookupPresentationGeneration}
  function currentGeneration(){return lookupPresentationGeneration}
  function setLookupPendingStage(generation,text){if(!isCurrent(generation))return false;$('status').textContent=text;return true}
  function finishLookupPresentation(generation){
   const op=`UI_OPERATION:${Date.now()}:${Math.random().toString(36).slice(2,8)}`;subsystemOperationStart('UI_OPERATION_LIFECYCLE',op,`Finish lookup presentation generation ${generation}.`,'Only the currently-owned generation may leave the pending state; stale generations are rejected.',{generation,currentGeneration:lookupPresentationGeneration});
   if(!isCurrent(generation)){subsystemOperationFinish(op,`Generation ${generation} is stale; current generation is ${lookupPresentationGeneration}.`,'INCONCLUSIVE',{generation,currentGeneration:lookupPresentationGeneration,stale:true});return false}
   $('itemPreview')?.classList.remove('lookupPending');subsystemOperationFinish(op,`Generation ${generation} left the pending state.`,'PASS',{generation,currentGeneration:lookupPresentationGeneration,stale:false});return true;
  }

  async function applyProductImage(item){
   const expected=item?.upc,result=await productImageService.lookupProductImage(item),pending=getPending();
   if(!pending||pending.upc!==expected)return;if(!result){setImageState('unavailable');return}
   setImageState('image',result.url);diag('image_rendered',{upc:expected,source:result.source,url:result.url});
  }
  function bind({on}={}){if(typeof on!=='function')throw new Error('Item Presentation Controller requires the shared event binder.');on('duplicateBlockedOk','click',closeDuplicateBlockedModal);on('previewBarcodeButton','click',()=>{const upc=String($('previewUpc')?.textContent||'').trim();if(barcodePlanner?.(upc)?.ok)barcodeProvider?.()?.openBarcode?.(upc)})}
  function setAceNetPresentedPrice(value,requestedState=null){
   const item=getPending(),verified=UPCPriceAuthority.observedAceNetPrice(item),thirdParty=item?.recordOrigin==='THIRD_PARTY_VENDOR';
   const liveDisplay=thirdParty?(UPCPriceAuthority.sourcePrice(item?.fields||{},item?.recordOrigin)??(UPCPriceAuthority.money(item?.libraryPrice??item?.price))) : (verified===null?null:verified.toFixed(2));
   const state=thirdParty?'verified':requestedState||(verified===null?'unavailable':'verified');
   setAceNetVisualState(state);
   setText('aceNetPriceCompare',state==='unavailable'?'Unavailable':liveDisplay===null?'—':'$'+liveDisplay);
   // A verified asynchronous Level 2 result changes the active comparison
   // source, not the independent offline Master/Local Level 2 evidence.
   if(item&&!thirdParty){const current=UPCPriceAuthority.observedPrice(item);setText('previewPrice',current===null?'—':'$'+current.toFixed(2));updatePriceDifference()}
   syncAceNetPriceVisibility();
  }
  function renderPreview(item){
   const locationGeneration=currentGeneration();
   setPending(item);
   const found=item.status==='FOUND',
    needsLocalLibrary=item.status==='NOT_FOUND'||item.needsLocalLibrary===true,
    libraryDisplay=UPCPriceAuthority.sourcePrice(item.fields||{},item.recordOrigin),
    thirdParty=syncExternalPriceSource(item);
   setText('libraryPriceLabel',thirdParty?'Vendor Library Price':'Library Level 2 Retail');
   const badge=$('lookupBadge');
   if(badge){
    badge.textContent=found?'FOUND':item.status==='AMBIGUOUS'?'AMBIGUOUS':'NOT FOUND';
    badge.className='badge '+(found?'found':'notfound');
   }
   const level2=UPCPriceAuthority.observedPrice(item),displayedPrice=level2===null?'—':'$'+level2.toFixed(2);
   setText('previewPrice',displayedPrice);
   setAceNetPresentedPrice(thirdParty?libraryDisplay:item.aceNetPrice,thirdParty?'verified':found&&item.sku&&comparisonEnabled()&&UPCPriceAuthority.observedAceNetPrice(item)===null?'pending':null);
   setText('previewSku',item.sku||'—');
   setText('previewDescription',(item.description||'ITEM NOT PRESENT IN CURRENT LIBRARY').toUpperCase());
   setText('previewUpc',item.upc||'—');syncBarcodeButton(item.upc);
   setText('previewOrderMultiple',item.orderMultiple||'—');
   setText('previewRetailUnits',item.retailUnits||'—');
   const preview=$('itemPreview');
   if(preview)preview.classList.remove('empty');
   setImageState('unavailable');
   $('priceCompare')?.classList.remove('hidden');
   const displayedLibraryPrice=libraryDisplay===null?'—':'$'+Number(libraryDisplay).toFixed(2);
   setText('libraryPriceCompare',displayedLibraryPrice);
   releaseNotFoundSystemPurpose();
   if(needsLocalLibrary)applyNotFoundSystemPurpose();else configureTags();
   updatePriceDifference();
   const add=$('addToList');if(add)add.disabled=false;
   syncManualPriceVisibility();
   syncAceNetPriceVisibility();
   void applyProductImage(item);
   displayLocationFor(item,locationGeneration);
  }
  return Object.freeze({resetPreview,beginLookupPresentation,setLookupPendingStage,finishLookupPresentation,setImageState,setAceNetPresentedPrice,renderPreview,isCurrent,currentGeneration,getPresentedItem,getPending,setPending,updatePriceDifference,syncAceNetPriceVisibility,syncExternalPriceSource,clearLookupTransientPriceState,showDuplicateBlockedModal,closeDuplicateBlockedModal,promptDuplicateItem,bind});
 }
 return Object.freeze({create});
})();
window.UPCItemPresentationController=UPCItemPresentationController;
