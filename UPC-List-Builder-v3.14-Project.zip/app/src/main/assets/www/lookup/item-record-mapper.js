/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/lookup/item-record-mapper.js
 * Owner: Lookup Mapping
 * Role: Pure mapper
 * Responsibility: Owns conversion of resolved Master/Local/catalog rows into the normal lookup presentation model.
 * Does not own: Persistence, lookup decisions, UI mutation, or network.
 * Side effects: None; mapping only.
 * Related code: Field authority remains with catalog domain; rendering belongs to Item Presentation Controller.
 */
const UPCItemRecordMapper=(()=>{
 function create({normalizeUpc}={}){
  if(typeof normalizeUpc!=='function')throw new Error('Item Record Mapper requires UPC normalization.');
  function normalizeMasterLibraryPrice(raw){
   if(raw===null||raw===undefined||String(raw).trim()==='')return null;
   const cleaned=String(raw).trim().replace(/^\$/,'').replace(/,/g,'');
   const n=Number(cleaned);
   if(!Number.isFinite(n)||n<0)return raw;
   return n.toFixed(2);
  }
  function itemFromLibraryRow(row,{lookupMode='UNKNOWN',fallbackSku='',fallbackUpc='',librarySource='MASTER_LIBRARY',activeMasterRecordId=null}={}){
   const f=row?.fields||{},pick=names=>{for(const wanted of names){const k=Object.keys(f).find(x=>x.trim().toLowerCase()===wanted.toLowerCase());if(k&&f[k]!==''&&f[k]!=null)return f[k]}return null};
   const sku=pick(['ACE SKU','SKU'])||row?.skuKey||fallbackSku||'',rawUpc=row?.originalUPC||row?.upcKey||fallbackUpc||'',isLocal=librarySource.startsWith('LOCAL_LIBRARY');
   return{status:'FOUND',upc:normalizeUpc(rawUpc),rawUPC:rawUpc,lookupMode,matches:1,libraryRecordId:isLocal?null:(row?.id??null),activeMasterRecordId:activeMasterRecordId??(!isLocal?(row?.id??null):null),localLibraryRecordId:isLocal?(row?.id??null):null,librarySource,recordOrigin:row?.localOrigin||row?.source||null,sku,description:pick(['Description','Article Description']),price:UPCPriceAuthority.sourcePrice(f,row?.localOrigin||row?.source||null),priceSource:isLocal?'LOCAL_LIBRARY':'MASTER_LIBRARY',orderMultiple:pick(['Order Multiple']),retailUnits:pick(['Retail Units']),fields:f};
  }
  return Object.freeze({itemFromLibraryRow,normalizeMasterLibraryPrice});
 }
 return Object.freeze({create});
})();
window.UPCItemRecordMapper=UPCItemRecordMapper;
