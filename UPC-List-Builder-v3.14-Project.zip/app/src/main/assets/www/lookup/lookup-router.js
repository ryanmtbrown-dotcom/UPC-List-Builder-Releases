/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/lookup/lookup-router.js
 * Owner: Lookup Entry Routing
 * Role: Router
 * Responsibility: Owns selection of ordinary versus ACE MISC lookup workflow from the active Work Session context.
 * Does not own: Lookup policy, identifier validation, persistence, presentation, or network.
 * Side effects: Calls the selected injected lookup owner only.
 * Related code: Normal policy belongs to Normal Lookup Controller; MISC policy belongs to MISC workspace/resolution owners.
 */
const UPCLookupRouter=(()=>{
 function create({getCurrentSession,miscWorkspaceProvider,normalLookupController,miscType='ACE_NEW_ITEMS_MISC'}={}){
  if(typeof getCurrentSession!=='function'||typeof miscWorkspaceProvider!=='function'||!normalLookupController)throw new Error('Lookup Router dependencies are incomplete.');
  async function perform(value,options={}){
   if(getCurrentSession()?.sessionType===miscType)return miscWorkspaceProvider().performLookup(value,options);
   return normalLookupController.performNormalLookup(value,options);
  }
  return Object.freeze({perform});
 }
 return Object.freeze({create});
})();
window.UPCLookupRouter=UPCLookupRouter;
