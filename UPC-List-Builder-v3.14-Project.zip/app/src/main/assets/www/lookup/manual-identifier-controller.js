/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/lookup/manual-identifier-controller.js
 * Owner: Manual Identifier Input
 * Role: Controller
 * Responsibility: Owns manual UPC/SKU mode selection, keypad/input behavior, and handoff of validated manual requests into Lookup Router.
 * Does not own: Lookup resolution policy, scanner camera, persistence, or presentation results.
 * Side effects: Mutates manual-entry DOM and invokes injected lookup routing.
 * Related code: Identifier normalization belongs to identifier-normalization.js; resolution belongs to lookup owners.
 */
const UPCManualIdentifierController=(()=>{
 function create({elementById,queryAll,normalizeUpc,normalizeSku,diagnostic,performLookup}={}){
  if(typeof elementById!=='function'||typeof queryAll!=='function'||typeof normalizeUpc!=='function'||typeof normalizeSku!=='function'||typeof diagnostic!=='function'||typeof performLookup!=='function')throw new Error('Manual Identifier Controller dependencies are incomplete.');
  const $=elementById,diag=diagnostic;let mode='UPC',keypadSession=null;
  function getMode(){return mode}
  function setMode(value){mode=value==='SKU'?'SKU':'UPC';queryAll('[data-lookup-mode]').forEach(b=>b.classList.toggle('active',b.dataset.lookupMode===mode));const input=$('upc'),label=$('manualLookupLabel');if(label)label.textContent=mode;if(input){input.placeholder=mode==='SKU'?'Enter SKU':'Scan or enter UPC';input.inputMode='none';input.readOnly=true}diag('manual_lookup_mode_changed',{mode});return mode}
  function closeKeypad(reason='closed'){const overlay=$('identifierKeypadPrompt');if(overlay)overlay.classList.add('hidden');keypadSession=null;diag('identifier_keypad_closed',{reason})}
  function openKeypad({title='Enter Number',context='',value='',maxLength=14,onAccept}={}){
   const overlay=$('identifierKeypadPrompt'),display=$('identifierKeypadValue'),pad=$('identifierKeypad');if(!overlay||!display||!pad)return;if(!overlay.classList.contains('hidden'))return;
   let raw=String(value??'').replace(/\D/g,'').slice(0,maxLength);keypadSession={title,context,maxLength,onAccept};$('identifierKeypadTitle').textContent=title;$('identifierKeypadContext').textContent=context||'Numeric entry';
   const render=()=>{display.textContent=raw||'—';display.classList.toggle('is-empty',!raw)};render();overlay.classList.remove('hidden');
   pad.onclick=e=>{const key=e.target.closest('[data-identifier-key]')?.dataset.identifierKey;if(!key)return;if(key==='backspace')raw=raw.slice(0,-1);else if(key==='clear')raw='';else if(/^\d$/.test(key)&&raw.length<maxLength)raw+=key;render()};
   $('cancelIdentifierKeypad').onclick=()=>closeKeypad('cancel');$('acceptIdentifierKeypad').onclick=async()=>{if(!raw){display.classList.add('invalid');setTimeout(()=>display.classList.remove('invalid'),350);return}const accept=keypadSession?.onAccept;closeKeypad('accepted');if(accept)await accept(raw)};
   diag('identifier_keypad_opened',{title,context,maxLength});
  }
  function promptForUnknownUpcSku(upc){
   return new Promise(resolve=>{const normalized=normalizeUpc(upc);diag('identity_unknown_upc_sku_prompt_opened',{upc:normalized});
    openKeypad({title:'Item Not Found — Enter SKU',context:`UPC ${normalized}`,value:'',maxLength:14,onAccept:async raw=>{const sku=normalizeSku(raw);diag('identity_unknown_upc_sku_supplied',{upc:normalized,sku});resolve(sku||null)}});
    const cancel=$('cancelIdentifierKeypad');if(cancel)cancel.onclick=()=>{closeKeypad('cancel');diag('identity_unknown_upc_sku_prompt_cancelled',{upc:normalized});resolve(null)};
   });
  }
  function openManualLookupKeypad(){openKeypad({title:`Enter ${mode}`,context:'Manual lookup',value:$('upc')?.value||'',maxLength:14,onAccept:async raw=>{if($('upc'))$('upc').value=raw;await performLookup(raw)}})}
  function bind({on}={}){
   if(typeof on!=='function')throw new Error('Manual Identifier Controller requires the shared event binder.');
   queryAll('[data-lookup-mode]').forEach(b=>b.onclick=()=>setMode(b.dataset.lookupMode));setMode('UPC');
   on('upc','click',openManualLookupKeypad);on('upc','focus',e=>{e.target.blur();openManualLookupKeypad()});on('lookup','click',()=>{if(String($('upc')?.value||'').trim())void performLookup();else openManualLookupKeypad()});
  }
  const keypad=Object.freeze({open:openKeypad,close:closeKeypad});
  return Object.freeze({bind,getMode,setMode,promptForUnknownUpcSku,openManualLookupKeypad,keypad});
 }
 return Object.freeze({create});
})();
window.UPCManualIdentifierController=UPCManualIdentifierController;
