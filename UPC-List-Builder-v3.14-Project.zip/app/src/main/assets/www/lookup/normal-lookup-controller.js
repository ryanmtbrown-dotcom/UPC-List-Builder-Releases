/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/lookup/normal-lookup-controller.js
 * Owner: Normal Product Lookup
 * Role: Workflow controller
 * Responsibility: Owns ordinary UPC/SKU lookup orchestration, local resolution, exact-SKU AceNet continuation, catalog refresh handoff, price/UPC enrichment orchestration, and terminal lookup results.
 * Does not own: Raw persistence, native authentication/extraction, item rendering mechanics, or DSD/MISC workflow.
 * Side effects: Calls injected resolver/AceNet/catalog/presentation services and emits operation diagnostics; durable writes occur only through approved services.
 * Related code: Presentation belongs to item-presentation-controller.js; AceNet request correlation belongs to acenet-client.js.
 */
const UPCNormalLookupController=(()=>{
 function create({
  localIdentifierResolver,
  itemMapper,
  relationshipService,
  catalogRefreshService,
  normalizeSku,
  normalizeUpc,
  requestCatalog,
  requestUpcs,
  priceService,
  comparisonEnabled,
  upcEnrichmentEnabled,
  diagnostic,
  presentationController,
  elementById,
  getManualLookupMode,
  setManualLookupMode,
  promptForUnknownUpcSku,
  applyScannedLabelPricePrompt,
  subsystemOperationStart,
  subsystemOperationFinish,
  lookupOperationStart,
  lookupOperationFinish,
  getCurrentSession
 }={}){
  if(!localIdentifierResolver||!itemMapper||!relationshipService||!catalogRefreshService)throw new Error('Normal Lookup Controller dependencies are incomplete.');
  if(typeof normalizeSku!=='function'||typeof normalizeUpc!=='function'||typeof requestCatalog!=='function'||typeof requestUpcs!=='function'||!priceService||typeof priceService.requestPrice!=='function'||typeof comparisonEnabled!=='function'||typeof upcEnrichmentEnabled!=='function')throw new Error('Normal Lookup Controller normalization/network dependencies are incomplete.');
  if(!presentationController||typeof elementById!=='function'||typeof getManualLookupMode!=='function'||typeof setManualLookupMode!=='function'||typeof promptForUnknownUpcSku!=='function')throw new Error('Normal Lookup Controller presentation/input dependencies are incomplete.');
  if(typeof applyScannedLabelPricePrompt!=='function'||typeof subsystemOperationStart!=='function'||typeof subsystemOperationFinish!=='function'||typeof lookupOperationStart!=='function'||typeof lookupOperationFinish!=='function')throw new Error('Normal Lookup Controller lifecycle dependencies are incomplete.');
  if(typeof getCurrentSession!=='function')throw new Error('Normal Lookup Controller session dependency is incomplete.');
  const UPCLocalIdentifierResolver=localIdentifierResolver,UPCIdentifierRelationshipService=relationshipService,itemPresentationController=presentationController,$=elementById;
  const normalizeSKU=normalizeSku,normalizeUPC=normalizeUpc,requestAceNetCatalog=requestCatalog,requestAceNetUpcs=requestUpcs,aceNetPriceCheckEnabled=comparisonEnabled,aceNetUpcEnrichmentEnabled=upcEnrichmentEnabled,diag=typeof diagnostic==='function'?diagnostic:()=>{};
  // Only Deep Diagnostic receives these additional decision/timing observations.
  // No extra catalog work, network requests, or historical price records are made.
  function deepEvidence(event,details,severity='DEBUG'){
   if(typeof diag.event==='function')diag.event(event,details,{severity,phase:'OBSERVATION',function:'performNormalLookup'});
  }

  async function enrichAceNetUpcsAfterPrice(sku,generation){
   try{
    const result=await requestAceNetUpcs(sku),ordered=[...new Set((result?.upcs||[]).map(normalizeUPC).filter(Boolean))];
    if(result?.status!=='VERIFIED'||normalizeSKU(result?.sku)!==sku||!ordered.length){diag('acenet_upc_enrichment_unavailable',{sku,generation,status:result?.status||'UNAVAILABLE',upcCount:ordered.length});return}
    const reconciled=await catalogRefreshService.reconcileVerifiedUpcSetWithCatalog(sku,ordered,{returnedSku:result.sku,exactSkuVerified:true,source:'ACENET_NORMAL_REFRESH',relationshipSource:'ACENET_NORMAL_ENRICHMENT',persistRelationships:true});
    diag('acenet_upc_enrichment_reconciled',{sku,target:reconciled.target||null,catalogUpdated:Boolean(reconciled.updated),upcCount:ordered.length,relationshipCount:reconciled.applied?.relationships?.upcs?.length||0});
    const pending=itemPresentationController.getPresentedItem();if(itemPresentationController.isCurrent(generation)&&pending&&normalizeSKU(pending.sku)===sku)pending.aceNetEnrichedUpcs=[...ordered];
   }catch(e){diag('acenet_upc_enrichment_persistence_failed',{sku,message:e?.message||String(e),guard:e?.libraryGuard||null})}
  }
  async function enrichPresentedItemWithAceNetPrice(item,generation,lookupId){
   const sku=normalizeSKU(item?.sku);if(!sku||!aceNetPriceCheckEnabled())return;
   const requestStartedAt=performance.now();deepEvidence('deep_acenet_price_request_dispatched',{sku,generation,lookupOperationId:lookupId,masterLevel2Present:UPCPriceAuthority.level2(item.fields||{})!==null,upcEnrichmentEnabled:aceNetUpcEnrichmentEnabled()},'TRACE');
   const upcEnrichment=aceNetUpcEnrichmentEnabled();diag('acenet_background_price_started',{sku,generation,lookupOperationId:lookupId,upcEnrichment,priceReturnsBeforeUpcEnrichment:true});
   let external;try{external=await priceService.requestPrice(sku,{upcEnrichment:false})}catch(error){if(itemPresentationController.isCurrent(generation))itemPresentationController.setAceNetPresentedPrice('', 'unavailable');deepEvidence('deep_acenet_price_request_exception',{sku,generation,elapsedMs:Math.round(performance.now()-requestStartedAt),errorClass:error?.name||'Error'});diag('acenet_background_price_request_failed',{sku,generation,message:error?.message||String(error)});return}
   if(!itemPresentationController.isCurrent(generation)){deepEvidence('deep_acenet_price_superseded',{sku,generation,elapsedMs:Math.round(performance.now()-requestStartedAt),returnedStatus:external?.status||null});diag('acenet_background_price_stale_ignored',{sku,generation,currentGeneration:itemPresentationController.currentGeneration(),status:external?.status||null});return}
   if(external?.status!=='VERIFIED'||!Number.isFinite(external.price)){deepEvidence('deep_acenet_price_fallback_to_master_level2',{sku,generation,elapsedMs:Math.round(performance.now()-requestStartedAt),responseStatus:external?.status||'UNAVAILABLE',masterLevel2Present:UPCPriceAuthority.level2(item.fields||{})!==null});itemPresentationController.setAceNetPresentedPrice('', 'unavailable');if(upcEnrichment)await UPCIdentifierRelationshipService.enqueueDeferredAceNetRefresh({sku,upcs:[item?.upc].filter(Boolean),reason:'ACENET_PRICE_OR_ENRICHMENT_UNAVAILABLE',source:'NORMAL_LOOKUP'});diag('acenet_background_price_unavailable',{sku,generation,status:external?.status||'UNAVAILABLE',upcEnrichment,queuedForRefresh:Boolean(upcEnrichment)});return}
   if(normalizeSKU(external.sku)!==sku){deepEvidence('deep_acenet_price_exact_sku_rejected',{sku,generation,elapsedMs:Math.round(performance.now()-requestStartedAt)});itemPresentationController.setAceNetPresentedPrice('', 'unavailable');diag('acenet_background_price_rejected',{sku,returnedSku:normalizeSKU(external.sku),reason:'SKU_MISMATCH'});return}
   const value=external.price.toFixed(2),pending=itemPresentationController.getPresentedItem();
   if(pending&&normalizeSKU(pending.sku)===sku){pending.aceNetPrice=value;pending.aceNetPriceStatus='VERIFIED';pending.aceNetPriceAuthority=UPCPriceAuthority.VERIFIED_ACENET_SOURCE}
   itemPresentationController.setAceNetPresentedPrice(value);deepEvidence('deep_acenet_verified_level2_applied',{sku,generation,elapsedMs:Math.round(performance.now()-requestStartedAt),source:'LEVEL2_STORE_RETAIL',previousMasterLevel2Present:UPCPriceAuthority.level2(item.fields||{})!==null},'TRACE');diag('acenet_background_price_presented',{sku,generation,status:'VERIFIED',upcEnrichment,upcCount:0,persistedMasterPrice:false,upcEnrichmentDeferred:Boolean(upcEnrichment)});
   if(upcEnrichment)void enrichAceNetUpcsAfterPrice(sku,generation);
  }
  async function refreshLocalLibraryLookupInBackground(item,generation,lookupId){
   const sku=normalizeSKU(item?.sku),localOwned=String(item?.librarySource||'').startsWith('LOCAL_LIBRARY'),thirdParty=String(item?.recordOrigin||'')==='THIRD_PARTY_VENDOR';if(!sku||!localOwned||!aceNetPriceCheckEnabled())return;if(thirdParty){diag('local_library_lookup_refresh_skipped',{sku,generation,reason:'THIRD_PARTY_VENDOR'});return}if(!aceNetUpcEnrichmentEnabled()){void enrichPresentedItemWithAceNetPrice(item,generation,lookupId);diag('local_library_lookup_refresh_skipped',{sku,generation,reason:'UPC_ENRICHMENT_DISABLED',priceOnly:true});return}
   diag('local_library_lookup_refresh_started',{sku,generation,lookupOperationId:lookupId,librarySource:item.librarySource||null,recordOrigin:item.recordOrigin||null});
   let result;try{result=await requestAceNetCatalog(sku)}catch(error){if(itemPresentationController.isCurrent(generation))itemPresentationController.setAceNetPresentedPrice('', 'unavailable');diag('local_library_lookup_refresh_failed',{sku,generation,message:error?.message||String(error)});return}
   if(result.status!=='VERIFIED'||!result.catalog){if(itemPresentationController.isCurrent(generation))itemPresentationController.setAceNetPresentedPrice('', 'unavailable');await UPCIdentifierRelationshipService.enqueueDeferredAceNetRefresh({sku,upcs:[item?.upc].filter(Boolean),reason:'LOCAL_LIBRARY_REFRESH_UNAVAILABLE',source:'NORMAL_LOCAL_LOOKUP'});diag('local_library_lookup_refresh_deferred',{sku,generation,status:result.status,queuedForRefresh:true});return}
   try{
    await catalogRefreshService.persistVerifiedAceNetCatalogToLocalLibrary(sku,{...result.catalog,sku},{source:'NORMAL_LOCAL_LOOKUP_REFRESH',relationshipSource:'ACENET_NORMAL_LOCAL_REFRESH'});
    const fresh=await lookupItemBySku(sku);
    if(!itemPresentationController.isCurrent(generation)){diag('local_library_lookup_refresh_stale_ignored',{sku,generation,currentGeneration:itemPresentationController.currentGeneration()});return}
    const pending=itemPresentationController.getPresentedItem();
    if(fresh.status==='FOUND'&&pending&&normalizeSKU(pending.sku)===sku){const preservedLabel=$('labelPrice')?.value||'';itemPresentationController.renderPreview({...fresh,requestedIdentifierType:item.requestedIdentifierType||null,scannedUpc:item.scannedUpc||item.upc,upc:item.requestedIdentifierType==='UPC'?(item.scannedUpc||item.upc||fresh.upc):fresh.upc});if($('labelPrice'))$('labelPrice').value=preservedLabel;itemPresentationController.updatePriceDifference();itemPresentationController.setAceNetPresentedPrice('', 'unavailable');diag('local_library_lookup_refresh_presented',{sku,generation,librarySource:fresh.librarySource||null,descriptionPresent:Boolean(fresh.description),orderMultiple:fresh.orderMultiple??null,retailUnits:fresh.retailUnits??null})}
   }catch(e){if(itemPresentationController.isCurrent(generation))itemPresentationController.setAceNetPresentedPrice('', 'unavailable');diag('local_library_lookup_refresh_failed',{sku,generation,message:e?.message||String(e)})}
  }

  async function lookupItem(input,{format=null}={}){
   const digits=normalizeUPC(input);
   if(!digits)return{status:'NOT_FOUND',upc:input,lookupMode:'EMPTY',matches:0,sku:null,description:null,price:null,orderMultiple:null,retailUnits:null,fields:{}};
   const resolved=await UPCLocalIdentifierResolver.resolveUPC(digits,{format}),direct=resolved.directCatalog;
   for(const observation of (direct?.observations||[])){
    if(observation.type==='EAN13_TO_UPCA')diag('lookup_ean13_upca_fallback',{input:observation.input,converted:observation.converted,count:observation.count,authority:observation.authority});
    else if(observation.type==='PROMOTED_MASTER_UPC_REDIRECT')diag('lookup_promoted_local_upc_redirect',{upc:observation.upc,sku:observation.sku,masterRecordId:observation.masterRecordId,localRecordId:observation.localRecordId});
   }
   if(resolved.status==='CONFLICT')return{status:'IDENTITY_CONFLICT',upc:digits,rawUPC:digits,lookupMode:'IDENTITY_CONFLICT',matches:resolved.relationship?.candidateSkuKeys?.length||0,sku:null,description:null,price:null,orderMultiple:null,retailUnits:null,fields:{},identityConflictCandidates:resolved.relationship?.candidateSkuKeys||[],identityConflictReason:resolved.reason||null};
   if(resolved.status==='AMBIGUOUS'){const catalog=resolved.catalog||direct;return{status:'AMBIGUOUS',upc:digits,lookupMode:catalog?.lookupMode||'LOCAL_IDENTIFIER_AMBIGUOUS',matches:catalog?.matches||0,sku:resolved.sku||null,description:null,price:null,orderMultiple:null,retailUnits:null,fields:{}}}
   if(resolved.status==='FOUND'){
    const catalog=resolved.catalog,item=itemMapper.itemFromLibraryRow(catalog.row,{lookupMode:catalog.lookupMode,fallbackSku:resolved.sku||normalizeSKU(catalog.row?.skuKey),fallbackUpc:digits,librarySource:catalog.provenance,activeMasterRecordId:catalog.activeMasterRecordId});
    return{...item,scannedUpc:digits,identityResolvedSku:resolved.relationship?.status==='KNOWN'?resolved.sku:null,identityResolutionSource:resolved.source||'DIRECT_CATALOG'};
   }
   if(resolved.status==='SKU_NOT_FOUND')return{status:'NOT_FOUND',upc:digits,rawUPC:digits,lookupMode:'RELATIONSHIP_SKU_NOT_FOUND',matches:0,sku:resolved.sku||null,description:null,price:null,orderMultiple:null,retailUnits:null,fields:{},identityResolvedSku:resolved.sku||null,identityResolutionSource:'RELATIONSHIP'};
   return{status:'NOT_FOUND',upc:digits,rawUPC:digits,lookupMode:'LOCAL_IDENTIFIER_UNKNOWN',matches:0,sku:null,description:null,price:null,orderMultiple:null,retailUnits:null,fields:{},identityResolvedSku:null,identityResolutionSource:'UNKNOWN'};
  }

  async function lookupItemBySku(input){
   const key=normalizeSKU(input);if(!key)return{status:'NOT_FOUND',upc:'',lookupMode:'SKU_EMPTY',matches:0,sku:null,description:null,price:null,orderMultiple:null,retailUnits:null,fields:{}};
   const local=await UPCLocalIdentifierResolver.resolveSKU(key),resolved=local.catalog;
   if(local.status==='AMBIGUOUS')return{status:'AMBIGUOUS',upc:'',lookupMode:resolved.lookupMode,matches:resolved.matches,sku:key,description:null,price:null,orderMultiple:null,retailUnits:null,fields:{}};
   if(local.status==='FOUND')return itemMapper.itemFromLibraryRow(resolved.row,{lookupMode:resolved.lookupMode,fallbackSku:key,librarySource:resolved.provenance,activeMasterRecordId:resolved.activeMasterRecordId});
   return{status:'NOT_FOUND',upc:'',lookupMode:'MASTER_LOCAL_SKU_MISS',matches:0,sku:key,description:null,price:null,orderMultiple:null,retailUnits:null,fields:{}};
  }

  async function resolveMissingSkuThroughAceNet(missing){
   const requestedSku=normalizeSKU(missing?.sku);if(!requestedSku)return{item:missing,authority:null};
   const pendingUpcs=[...new Set([missing?.scannedUpc,missing?.upc,...(Array.isArray(missing?.upcs)?missing.upcs:[])].map(normalizeUPC).filter(Boolean))];
   if(!aceNetPriceCheckEnabled()){
    await UPCIdentifierRelationshipService.enqueueResearch({sku:requestedSku,upcs:pendingUpcs,reason:'ACENET_DEFERRED_AFTER_LIBRARY_MISS',source:'NORMAL_SKU_LOOKUP'});
    await UPCIdentifierRelationshipService.enqueueDeferredAceNetRefresh({sku:requestedSku,upcs:pendingUpcs,reason:'ACENET_DISABLED_AFTER_LIBRARY_MISS',source:'NORMAL_SKU_LOOKUP'});
    diag('acenet_missing_sku_skipped',{sku:requestedSku,reason:'acenet_disabled',queuedForRefresh:true,upcCount:pendingUpcs.length});
    return{item:missing,authority:{source:'ACENET',status:'DEFERRED',libraryUpdated:false,classification:'NEEDS_RESEARCH'}};
   }
   diag('acenet_missing_sku_full_catalog_started',{sku:requestedSku,masterAndLocalMiss:true});
   const external=await requestAceNetCatalog(requestedSku);
   if(external?.status!=='VERIFIED'||!external.catalog){
    if(external?.status==='NOT_FOUND'){
     await UPCIdentifierRelationshipService.setSkuIdentityStatus(requestedSku,{catalogStatus:'ACENET_NOT_FOUND',source:'NORMAL_SKU_LOOKUP'});
     await UPCIdentifierRelationshipService.enqueueResearch({sku:requestedSku,upcs:pendingUpcs,reason:'NOT_IN_MASTER_LOCAL_OR_ACENET',source:'NORMAL_SKU_LOOKUP'});
     await UPCIdentifierRelationshipService.removeDeferredAceNetRefresh(requestedSku);
     diag('acenet_missing_sku_classified_research',{sku:requestedSku,status:'NOT_FOUND',reason:'NOT_IN_MASTER_LOCAL_OR_ACENET'});
    }else{
     await UPCIdentifierRelationshipService.enqueueResearch({sku:requestedSku,upcs:pendingUpcs,reason:'ACENET_CATALOG_UNVERIFIED_AFTER_LIBRARY_MISS',source:'NORMAL_SKU_LOOKUP'});
     await UPCIdentifierRelationshipService.enqueueDeferredAceNetRefresh({sku:requestedSku,upcs:pendingUpcs,reason:'ACENET_CATALOG_UNAVAILABLE',source:'NORMAL_SKU_LOOKUP'});
     diag('acenet_missing_sku_classified_research',{sku:requestedSku,status:external?.status||'UNAVAILABLE',reason:'ACENET_CATALOG_UNVERIFIED_AFTER_LIBRARY_MISS',queuedForRefresh:true});
    }
    return{item:missing,authority:{source:'ACENET',status:external?.status||'UNVERIFIED',libraryUpdated:false,classification:'NEEDS_RESEARCH'}};
   }
   const canonicalSku=normalizeSKU(external.sku);
   if(!canonicalSku||canonicalSku!==requestedSku){
    diag('acenet_missing_sku_blocked',{requestedSku,returnedSku:canonicalSku||null,reason:'sku_mismatch'});
    await UPCIdentifierRelationshipService.enqueueResearch({sku:requestedSku,upcs:pendingUpcs,reason:'ACENET_SKU_MISMATCH',source:'NORMAL_SKU_LOOKUP'});
    return{item:missing,authority:{source:'ACENET',status:'SKU_MISMATCH',libraryUpdated:false,classification:'NEEDS_RESEARCH'}};
   }
   const persisted=await catalogRefreshService.persistVerifiedAceNetCatalogToLocalLibrary(canonicalSku,{...external.catalog,sku:canonicalSku},{source:'NORMAL_SKU_LOOKUP',relationshipSource:'ACENET_NORMAL_FULL_CATALOG'});
   await UPCIdentifierRelationshipService.removeDeferredAceNetRefresh(canonicalSku);
   const item=await lookupItemBySku(canonicalSku);
   if(item.status!=='FOUND')throw new Error(`SKU ${canonicalSku} persisted but could not be retrieved from Master or Local Library.`);
   diag('acenet_missing_sku_resolved_durably',{sku:canonicalSku,librarySource:item.librarySource||null,localPersisted:persisted.status==='COMPLETED',descriptionPresent:Boolean(item.description),upc:item.upc||null});
   return{item:{...item,aceNetCatalogPersisted:true},authority:{source:'ACENET',status:'VERIFIED_LOCAL_LIBRARY',libraryUpdated:persisted.status==='COMPLETED',classification:item.librarySource==='MASTER_LIBRARY'?'MASTER_LIBRARY':'LOCAL_LIBRARY'}};
  }

function fieldObservationEligible(item,generation){
  const session=getCurrentSession();
  return itemPresentationController.isCurrent(generation)&&Boolean(session)&&session.sessionType!=='ACE_NEW_ITEMS_MISC'&&Boolean(item?.upc)&&(item.status==='FOUND'||item.status==='NOT_FOUND');
 }
 async function finalizeFieldObservation(item,generation,source){
  const eligible=fieldObservationEligible(item,generation),button=$('markMissingLabel');
  if(button)button.disabled=!eligible;
  const session=getCurrentSession();
  if(!eligible||session?.promptLabelPriceAfterScan!==true)return;
  diag('label_price_prompt_triggered_for_field_observation',{upc:item.upc,sku:item.sku||null,status:item.status,listId:session.id,source});
  await applyScannedLabelPricePrompt();
 }

async function performNormalLookup(value,options={}){
 let mode=options.forceMode||getManualLookupMode();
 const raw=String(value??$('upc').value??'').trim();
 if(!options.forceMode&&mode==='UPC'&&/^\d{1,10}$/.test(raw)){const requestedMode=mode;setManualLookupMode('SKU');mode='SKU';diag('manual_lookup_mode_auto_corrected',{requestedMode,effectiveMode:mode,inputLength:raw.length,reason:'fewer_than_11_digits'})}
 const key=mode==='SKU'?normalizeSKU(raw):normalizeUPC(raw);if(!key){$('status').textContent=`Enter ${mode==='SKU'?'a SKU':'or scan a UPC'} first.`;return}
 const identifierId=`IDENTIFIER:${Date.now()}:${Math.random().toString(36).slice(2,8)}`;subsystemOperationStart('IDENTIFIER_RESOLUTION',identifierId,'Classify and normalize the identifier used for item lookup.','UPC and SKU resolution remain distinct and ambiguity is never silently selected.',{rawIdentifier:raw,requestedMode:options.forceMode||getManualLookupMode(),effectiveMode:mode,format:options.format||null});subsystemOperationFinish(identifierId,`Identifier classified as ${mode} with normalized key ${key}.`,'PASS',{rawIdentifier:raw,identifierType:mode,normalizedKey:key,format:options.format||null});
 const lookupId=`ITEM_SEARCH:${Date.now()}:${Math.random().toString(36).slice(2,8)}`;
 lookupOperationStart(lookupId,'Resolve a normal item search from the entered or scanned identifier.','Master Library is checked first, durable Local Library second, and AceNet is consulted only after both local authorities miss.',{identifier:key,identifierType:mode,aceNetComparisonEnabled:aceNetPriceCheckEnabled()});
 const generation=itemPresentationController.beginLookupPresentation(key,mode);itemPresentationController.clearLookupTransientPriceState(key);diag('lookup_started',{key,lookupModeInput:mode,generation,lookupOperationId:lookupId});
 const started=performance.now();let result;
 try{result=mode==='SKU'?await lookupItemBySku(key):await lookupItem(key,options)}catch(e){itemPresentationController.finishLookupPresentation(generation);diag('lookup_library_failed',{key,mode,message:e?.message||String(e)});$('status').textContent='Library lookup failed.';lookupOperationFinish(lookupId,'Master/Local Library lookup failed.','FAIL',{identifier:key,identifierType:mode,error:e?.message||String(e)});return}
 const libraryDone=performance.now();
 if(!itemPresentationController.isCurrent(generation)){diag('lookup_presentation_superseded',{key,generation,stage:'library'});lookupOperationFinish(lookupId,'Superseded before presentation.','INCONCLUSIVE',{stage:'library'});return}
 diag('lookup_library_resolved',{key,status:result.status,mode:result.lookupMode,matches:result.matches,sku:result.sku||null,librarySource:result.librarySource||null,recordOrigin:result.recordOrigin||null,ms:Math.round(libraryDone-started)});
 deepEvidence('deep_lookup_catalog_decision',{lookupOperationId:lookupId,generation,identifierType:mode,status:result.status,lookupMode:result.lookupMode,librarySource:result.librarySource||null,recordOrigin:result.recordOrigin||null,masterLevel2Present:UPCPriceAuthority.level2(result.fields||{})!==null,thirdPartyVendor:result.recordOrigin==='THIRD_PARTY_VENDOR',libraryElapsedMs:Math.round(libraryDone-started)},'DEBUG');

 if(mode==='UPC'&&result.status==='IDENTITY_CONFLICT'){
   itemPresentationController.finishLookupPresentation(generation);itemPresentationController.renderPreview({...result,status:'AMBIGUOUS'});if($('addToList'))$('addToList').disabled=true;$('upc').value=key;$('status').textContent='Item has an unresolved SKU conflict. Resolve the SKU conflict before lookup.';
   diag('local_identifier_conflict_blocked_lookup',{upc:key,candidates:result.identityConflictCandidates||[],reason:result.identityConflictReason||null});
   lookupOperationFinish(lookupId,'UPC lookup stopped because local catalog and/or saved relationship evidence conflicts.','INCONCLUSIVE',{identifier:key,identifierType:mode,status:'IDENTITY_CONFLICT',candidates:result.identityConflictCandidates||[],libraryMs:Math.round(libraryDone-started)});return;
 }
 if(mode==='UPC'&&result.status==='NOT_FOUND'){
   const savedSku=normalizeSKU(result.identityResolvedSku),identityStatus=savedSku?'KNOWN':'UNKNOWN';
   diag('local_identifier_resolution_completed',{upc:key,status:identityStatus,sku:savedSku||null,source:result.identityResolutionSource||null});
   let identitySku=savedSku,userSupplied=false,relationshipCommitted=Boolean(savedSku),recovered=null;
   if(!identitySku){identitySku=await promptForUnknownUpcSku(key);if(!identitySku){itemPresentationController.finishLookupPresentation(generation);itemPresentationController.renderPreview({...result,requestedIdentifierType:'UPC',scannedUpc:key});$('upc').value=key;$('status').textContent='Item not found. SKU entry cancelled.';lookupOperationFinish(lookupId,'Unknown UPC lookup cancelled before SKU was supplied.','INCONCLUSIVE',{identifier:key,identifierType:mode,status:'SKU_PROMPT_CANCELLED'});await finalizeFieldObservation(itemPresentationController.getPresentedItem(),generation,'unknown_upc_no_sku');return}userSupplied=true;diag('identity_unknown_upc_sku_provisional',{upc:key,sku:identitySku})}
   itemPresentationController.setLookupPendingStage(generation,userSupplied?'Validating SKU · resolving item…':'Known UPC · resolving saved SKU…');
   let skuResult=await lookupItemBySku(identitySku);
   if(skuResult.status==='FOUND'){
     const authority=String(skuResult.librarySource||'').startsWith('LOCAL_LIBRARY')?'LOCAL_LIBRARY':'MASTER_LIBRARY';
     if(userSupplied){await UPCIdentifierRelationshipService.recordRelationship(identitySku,key,`USER_UNKNOWN_UPC_VALIDATED_${authority}`);relationshipCommitted=true;diag('identity_relationship_committed_after_validation',{upc:key,sku:identitySku,authority})}
     await UPCIdentifierRelationshipService.setSkuIdentityStatus(identitySku,{catalogStatus:authority,source:'NORMAL_LOOKUP'});await UPCIdentifierRelationshipService.removeResearch(identitySku);
   }else if(skuResult.status==='NOT_FOUND'){
     try{recovered=await resolveMissingSkuThroughAceNet({...skuResult,sku:identitySku,scannedUpc:key});skuResult=recovered.item}catch(e){diag('identity_sku_acenet_validation_failed',{upc:key,sku:identitySku,message:e?.message||String(e)})}
     if(skuResult.status==='FOUND'){
       if(userSupplied){
         const verifiedRelationship=await UPCIdentifierRelationshipService.resolveUPC(key),confirmed=verifiedRelationship.status==='KNOWN'&&normalizeSKU(verifiedRelationship.sku)===identitySku;
         relationshipCommitted=confirmed;
         if(confirmed)diag('identity_relationship_confirmed_by_complete_acenet_set',{upc:key,sku:identitySku,authority:'ACENET_LOCAL_LIBRARY'});
         else diag('identity_user_upc_rejected_by_complete_acenet_set',{upc:key,sku:identitySku,relationshipStatus:verifiedRelationship.status,candidates:verifiedRelationship.candidateSkuKeys||[]});
       }
     }else if(recovered?.authority?.status==='NOT_FOUND'){
       await UPCIdentifierRelationshipService.enqueueResearch({sku:identitySku,upcs:[key],reason:'NOT_IN_MASTER_LOCAL_OR_ACENET',source:'NORMAL_LOOKUP'});
     }
   }
   if(!itemPresentationController.isCurrent(generation)){diag('lookup_presentation_superseded',{key,generation,stage:'identity_resolution'});return}
   skuResult.requestedIdentifierType='UPC';skuResult.identityResolvedSku=identitySku;skuResult.scannedUpc=key;skuResult.upc=key;
   itemPresentationController.finishLookupPresentation(generation);itemPresentationController.renderPreview(skuResult);$('upc').value=key;
   if(skuResult.status==='FOUND'){
     const localOwned=String(skuResult.librarySource||'').startsWith('LOCAL_LIBRARY');
     $('status').textContent=localOwned?'Item resolved from Local Library.':'Item resolved from Master Library.';
     const thirdPartyLocal=localOwned&&String(skuResult.recordOrigin||'')==='THIRD_PARTY_VENDOR';
     if(localOwned&&!thirdPartyLocal)void refreshLocalLibraryLookupInBackground(skuResult,generation,lookupId);
     else if(!localOwned&&aceNetPriceCheckEnabled()&&skuResult.sku)void enrichPresentedItemWithAceNetPrice(skuResult,generation,lookupId);
     if(!thirdPartyLocal&&!aceNetPriceCheckEnabled()&&skuResult.sku)void UPCIdentifierRelationshipService.enqueueDeferredAceNetRefresh({sku:skuResult.sku,upcs:[key],reason:'ACENET_DISABLED_AFTER_IDENTITY_RESOLUTION',source:'NORMAL_LOOKUP'}).catch(e=>diag('identity_deferred_refresh_queue_failed',{sku:skuResult.sku,message:e?.message||String(e)}));
   }else if(recovered?.authority?.status==='NOT_FOUND')$('status').textContent='Item is not currently in Master Library, Local Library, or AceNet.';
   else if(recovered?.authority?.status==='DEFERRED')$('status').textContent='Item needs research. SKU saved for a later live AceNet refresh.';
   else $('status').textContent='Item could not be verified in Master Library, Local Library, or AceNet.';
   lookupOperationFinish(lookupId,`UPC identity resolution completed with ${skuResult.status}.`,skuResult.status==='FOUND'?'PASS':'INCONCLUSIVE',{identifier:key,identifierType:mode,status:skuResult.status,sku:identitySku,identitySource:userSupplied?'USER_SUPPLIED':(savedSku?'SAVED_RELATIONSHIP':'UNKNOWN'),relationshipCommitted,librarySource:skuResult.librarySource||null,classification:skuResult.status==='FOUND'?(String(skuResult.librarySource||'').startsWith('LOCAL_LIBRARY')?'LOCAL_LIBRARY':'MASTER_LIBRARY'):'NEEDS_RESEARCH',libraryMs:Math.round(libraryDone-started),totalMs:Math.round(performance.now()-started)});await finalizeFieldObservation(skuResult,generation,'upc_identity_resolution');return;
 }

 if(mode==='SKU'&&result.status==='NOT_FOUND'){
   itemPresentationController.setLookupPendingStage(generation,'SKU not in Master or Local Library · checking AceNet…');
   let recovered=null;try{recovered=await resolveMissingSkuThroughAceNet(result);result=recovered.item}catch(e){diag('acenet_missing_sku_resolution_failed',{sku:result.sku||key,message:e?.message||String(e)})}
   if(!itemPresentationController.isCurrent(generation)){diag('lookup_presentation_superseded',{key,generation,stage:'sku_acenet'});return}
   result.requestedIdentifierType=mode;itemPresentationController.finishLookupPresentation(generation);itemPresentationController.renderPreview(result);
   $('upc').value=result.status==='FOUND'?String(result.sku||key):key;
   $('status').textContent=result.status==='FOUND'?(String(result.librarySource||'').startsWith('LOCAL_LIBRARY')?'SKU found in AceNet and saved to Local Library.':'SKU resolved from library.'):(recovered?.authority?.status==='NOT_FOUND'?'Item is not currently in Master Library, Local Library, or AceNet.':'Item could not be verified in AceNet.');
   lookupOperationFinish(lookupId,`SKU lookup completed with ${result.status}.`,result.status==='FOUND'?'PASS':'INCONCLUSIVE',{identifier:key,identifierType:mode,status:result.status,sku:result.sku||null,librarySource:result.librarySource||null,libraryMs:Math.round(libraryDone-started),totalMs:Math.round(performance.now()-started),missingSkuRecovery:true});await finalizeFieldObservation(result,generation,'sku_recovery');return;
 }

 result.requestedIdentifierType=mode;result.priceSource=result.priceSource||'MASTER_LIBRARY';
 itemPresentationController.finishLookupPresentation(generation);itemPresentationController.renderPreview(result);
 const presented=performance.now(),localOwned=result.status==='FOUND'&&(String(result.librarySource||'').startsWith('LOCAL_LIBRARY'));
 diag('lookup_library_presented_immediately',{key,status:result.status,sku:result.sku||null,generation,librarySource:result.librarySource||null,recordOrigin:result.recordOrigin||null,libraryMs:Math.round(libraryDone-started),totalToPresentationMs:Math.round(presented-started)});
 const thirdPartyLocal=localOwned&&String(result.recordOrigin||'')==='THIRD_PARTY_VENDOR';
 if(result.status==='FOUND'&&localOwned&&!thirdPartyLocal)void refreshLocalLibraryLookupInBackground(result,generation,lookupId);
 else if(result.status==='FOUND'&&!localOwned&&aceNetPriceCheckEnabled()&&result.sku)void enrichPresentedItemWithAceNetPrice(result,generation,lookupId);
 if(result.status==='FOUND'&&!thirdPartyLocal&&!aceNetPriceCheckEnabled()&&result.sku)void UPCIdentifierRelationshipService.enqueueDeferredAceNetRefresh({sku:result.sku,upcs:[result.upc].filter(Boolean),reason:'ACENET_DISABLED_DURING_LOCAL_LOOKUP',source:'NORMAL_LOOKUP'}).catch(e=>diag('identity_deferred_refresh_queue_failed',{sku:result.sku,message:e?.message||String(e)}));
 $('upc').value=mode==='SKU'?(result.status==='FOUND'?String(result.sku||key):key):(result.status==='FOUND'?result.upc:key);
 $('status').textContent=result.status==='AMBIGUOUS'?`Ambiguous ${mode}: ${result.matches} Library records match. No item was selected.`:result.status==='NOT_FOUND'?'Item not found in Master or Local Library.':localOwned?'Item found in Local Library. Refreshing verified AceNet data in background…':aceNetPriceCheckEnabled()?'Item found in Master Library. AceNet price checking in background…':'Item found in Master Library.';
 lookupOperationFinish(lookupId,`Library presentation completed with ${result.status}.`,result.status==='AMBIGUOUS'?'INCONCLUSIVE':'PASS',{identifier:key,identifierType:mode,status:result.status,sku:result.sku||null,upc:result.upc||null,librarySource:result.librarySource||null,libraryPrice:result.price??null,libraryMs:Math.round(libraryDone-started),totalToPresentationMs:Math.round(presented-started),aceNetBackground:result.status==='FOUND'&&aceNetPriceCheckEnabled()});
 await finalizeFieldObservation(result,generation,options.promptLabelPriceOnSkuChange===true?'scanner':mode.toLowerCase());
}


  return Object.freeze({lookupItem,lookupItemBySku,resolveMissingSkuThroughAceNet,performNormalLookup});
 }
 return Object.freeze({create});
})();
window.UPCNormalLookupController=UPCNormalLookupController;
