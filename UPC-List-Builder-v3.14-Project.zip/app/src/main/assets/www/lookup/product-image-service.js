/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/lookup/product-image-service.js
 * Owner: Product Image Lookup
 * Role: Presentation support service
 * Responsibility: Owns image source/cache lookup, validation, native/browser image request mechanics, and stale-image protection for product presentation.
 * Does not own: Product identity, price authority, catalog persistence, or lookup success authority.
 * Side effects: May use injected browser fetch/native image search and bounded local cache; presentation-only evidence.
 * Related code: Rendering belongs to Item Presentation Controller; native search belongs to ProductImageSearch.kt.
 */
const UPCProductImageService=(()=>{
 function create({normalizeUpc,comparisonEnabled,diagnostic,storage,fetchFn,imageCtor,bridgeProvider}={}){
  if(typeof normalizeUpc!=='function'||typeof comparisonEnabled!=='function')throw new Error('Product Image Service normalization and comparison dependencies are required.');
  if(!storage||typeof fetchFn!=='function'||typeof imageCtor!=='function'||typeof bridgeProvider!=='function')throw new Error('Product Image Service platform dependencies are required.');
  const normalizeUPC=normalizeUpc,aceNetPriceCheckEnabled=comparisonEnabled,diag=typeof diagnostic==='function'?diagnostic:()=>{},ImageCtor=imageCtor;
  const IMAGE_CACHE_KEY='upcListBuilder.imageCache.v0.01';
  function loadImageCache(){try{const v=JSON.parse(storage.getItem(IMAGE_CACHE_KEY)||'{}');return v&&typeof v==='object'?v:{}}catch{return{}}}
  function saveImageCache(cache){try{const entries=Object.entries(cache).sort((a,b)=>(b[1]?.at||0)-(a[1]?.at||0)).slice(0,200);storage.setItem(IMAGE_CACHE_KEY,JSON.stringify(Object.fromEntries(entries)))}catch{}}
  function imageUrlFromLibraryFields(item){const fields=item?.fields;if(!fields||typeof fields!=='object')return null;for(const [key,value] of Object.entries(fields)){if(!/image|photo|picture|thumbnail|product.?image/i.test(String(key)))continue;const raw=Array.isArray(value)?value[0]:value,url=String(raw||'').trim();if(/^https:\/\//i.test(url)){diag('image_library_field_candidate',{upc:item?.upc,key,url});return{url,source:`Master Library · ${key}`}}}return null}
  function normalizeImageCandidates(data,source){const out=[];const push=u=>{u=String(u||'').trim();if(/^https:\/\//i.test(u)&&!out.some(x=>x.url===u))out.push({url:u,source})};if(!data)return out;if(source==='BarcodeFinder'){(data.images||data.product?.images||[]).forEach(push);push(data.image);push(data.image_url);push(data.product?.image);push(data.product?.image_url)}else if(source==='Open Products Facts'||source==='Open Food Facts'){push(data?.product?.image_front_url);push(data?.product?.image_url)}return out}
  async function fetchJsonWithTimeout(url,source,ms=3500){const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),ms);try{diag('image_source_requested',{source,url});const r=await fetchFn(url,{signal:controller.signal,headers:{Accept:'application/json'}});if(!r.ok){diag('image_source_result',{source,httpStatus:r.status,found:false});return null}const data=await r.json();return{data,httpStatus:r.status}}catch(e){diag('image_source_failed',{source,name:e?.name,message:e?.message});return null}finally{clearTimeout(timer)}}
  async function imageLoads(url,timeoutMs=3500){return new Promise(resolve=>{const img=new ImageCtor(),timer=setTimeout(()=>{cleanup();resolve(false)},timeoutMs);function cleanup(){clearTimeout(timer);img.onload=null;img.onerror=null}img.onload=()=>{cleanup();resolve(img.naturalWidth>20&&img.naturalHeight>20)};img.onerror=()=>{cleanup();resolve(false)};img.referrerPolicy='no-referrer';img.src=url})}
  const nativeImageRequests=new Map();
  function acceptNativeProductImageResult(raw){let data;try{data=typeof raw==='string'?JSON.parse(raw):raw}catch(e){diag('image_google_native_invalid',{message:e?.message});return}const id=data?.requestId,resolver=nativeImageRequests.get(id);if(!resolver)return;nativeImageRequests.delete(id);resolver(data)}
  function lookupGoogleProductImage(item,timeoutMs=12000){return new Promise(resolve=>{const bridge=bridgeProvider();if(!bridge||typeof bridge.lookupProductImage!=='function'){resolve(null);return}const fields=item?.fields||{},pickField=(names)=>{for(const wanted of names){const k=Object.keys(fields).find(x=>String(x).trim().toLowerCase()===wanted.toLowerCase());if(k&&fields[k]!==''&&fields[k]!=null)return String(fields[k]).trim()}return''},upc=normalizeUPC(item?.upc||item),sku=String(item?.sku||pickField(['ACE SKU','SKU'])).trim(),mfg=pickField(['MFG #','MFG#','MFG #.','MFG NUMBER','MFG NO','MFG NO.','MANUFACTURER #','MANUFACTURER NUMBER','MANUFACTURER PART NUMBER','MFR #','MFR#']),description=String(item?.description||'').trim(),requestId=`img-${Date.now()}-${Math.random().toString(36).slice(2,8)}`,timer=setTimeout(()=>{nativeImageRequests.delete(requestId);diag('image_google_native_timeout',{upc,mfg,description});resolve(null)},timeoutMs);nativeImageRequests.set(requestId,data=>{clearTimeout(timer);diag('image_google_native_result',{upc,mfg,found:!!data?.found,source:data?.source||null,query:data?.query||null,error:data?.error||null});resolve(data?.found&&data?.dataUrl?{url:data.dataUrl,source:data.source||'Native Google Images'}:null)});try{diag('image_google_native_requested',{upc,sku,mfg,description});bridge.lookupProductImage(requestId,upc,sku,mfg,description)}catch(e){clearTimeout(timer);nativeImageRequests.delete(requestId);diag('image_google_native_failed',{upc,message:e?.message});resolve(null)}})}
  async function lookupProductImage(item){
   const code=normalizeUPC(item?.upc||item);if(!code)return null;diag('image_lookup_started',{upc:code});const started=performance.now(),cache=loadImageCache(),cached=cache[code];
   if(item?.status!=='FOUND'){diag('image_lookup_skipped_untrusted_not_found',{upc:code});return null}
   const aceNetMode=aceNetPriceCheckEnabled()&&item?.priceSource==='ACENET',aceNetUrl=aceNetMode?String(item?.aceNetImageUrl||'').trim():'';
   if(aceNetMode&&/^https:\/\//i.test(aceNetUrl)){
    diag('image_acenet_candidate',{upc:code,sku:item?.sku||null,score:item?.aceNetImageScore||0});
    if(await imageLoads(aceNetUrl,1800)){cache[code]={url:aceNetUrl,source:'AceNet Item Details',at:Date.now()};saveImageCache(cache);diag('image_lookup_complete',{upc:code,source:'AceNet Item Details',ms:Math.round(performance.now()-started),found:true,webLookupSkipped:true});return{url:aceNetUrl,source:'AceNet Item Details'}}
    diag('image_acenet_candidate_failed',{upc:code,sku:item?.sku||null});
   }
   const candidates=[];const add=c=>{if(c?.url&&!candidates.some(x=>x.url===c.url))candidates.push(c)};
   add(imageUrlFromLibraryFields(item));
   if(cached?.url&&(!String(cached.source||'').startsWith('AceNet')||aceNetMode)){diag('image_cache_candidate',{upc:code,source:cached.source||null,ageMs:Date.now()-(cached.at||0)});if(await imageLoads(cached.url,900)){diag('image_lookup_complete',{upc:code,source:`Cache · ${cached.source||'previous lookup'}`,ms:Math.round(performance.now()-started),found:true});return{url:cached.url,source:`Cache · ${cached.source||'previous lookup'}`}}delete cache[code];saveImageCache(cache)}
   if(candidates.length){const direct=candidates[0];if(await imageLoads(direct.url,1200)){cache[code]={url:direct.url,source:direct.source,at:Date.now()};saveImageCache(cache);diag('image_lookup_complete',{upc:code,source:direct.source,ms:Math.round(performance.now()-started),found:true});return direct}}
   if(aceNetMode&&!aceNetUrl)diag('image_acenet_unavailable_fallback_web',{upc:code,sku:item?.sku||null});
   const google=await lookupGoogleProductImage(item);if(google){diag('image_lookup_complete',{upc:code,source:google.source,ms:Math.round(performance.now()-started),found:true});return google}
   const sources=[
    {name:'BarcodeFinder',url:`https://api.barcodefinder.info/barcode/${encodeURIComponent(code)}`},
    {name:'BarcodeFinder',url:`https://www.barcodefinder.info/v1/product/${encodeURIComponent(code)}`},
    {name:'Open Products Facts',url:`https://world.openproductsfacts.org/api/v2/product/${encodeURIComponent(code)}.json?fields=code,image_front_url,image_url`},
    {name:'Open Food Facts',url:`https://world.openfoodfacts.org/api/v2/product/${encodeURIComponent(code)}.json?fields=code,image_front_url,image_url`}
   ];
   for(const source of sources){const result=await fetchJsonWithTimeout(source.url,source.name);if(!result)continue;const found=normalizeImageCandidates(result.data,source.name);diag('image_source_result',{source:source.name,httpStatus:result.httpStatus,found:found.length>0,candidateCount:found.length});found.forEach(add);if(found.length&&source.name==='BarcodeFinder')break}
   diag('image_candidate_set',{upc:code,count:candidates.length,sources:[...new Set(candidates.map(x=>x.source))]});
   for(const candidate of candidates){const ok=await imageLoads(candidate.url);diag(ok?'image_candidate_validated':'image_candidate_render_failed',{upc:code,source:candidate.source,url:candidate.url});if(!ok){if(cached?.url===candidate.url){delete cache[code];saveImageCache(cache)}continue}cache[code]={url:candidate.url,source:candidate.source,at:Date.now()};saveImageCache(cache);diag('image_lookup_complete',{upc:code,source:candidate.source,ms:Math.round(performance.now()-started),found:true});return candidate}
   diag('image_lookup_complete',{upc:code,source:null,ms:Math.round(performance.now()-started),found:false});return null;
  }
  return Object.freeze({lookupProductImage,acceptNativeProductImageResult});
 }
 return Object.freeze({create});
})();
window.UPCProductImageService=UPCProductImageService;
