/*
 * OWNERSHIP:
 * File: app/src/main/assets/www/master-repository.js
 * Owner: Official Master Persistence
 * Role: Repository facade
 * Responsibility: Owns physical active Master metadata/record access and approved Master persistence primitives.
 * Does not own: Master-vs-Local selection; UI; Work Sessions; network; catalog refresh policy.
 * Side effects: Direct UPCDB Master-store/meta access is permitted as repository adaptation.
 * Related code: Workflow mutation/composition belongs to catalog services and Combined Master export.
 */
const UPCMasterRepository=(()=>{
 const getMetadata=()=>UPCDB.get('meta','library');
 const saveMetadata=meta=>UPCDB.put('meta',{...(meta||{}),key:'library'});
 return Object.freeze({
  getMetadata,saveMetadata,
  lookupExactUPC:UPCDB.lookupUniqueExact,
  lookupPrefixUPC:UPCDB.lookupUniquePrefix,
  lookupSKU:UPCDB.lookupUniqueSKU,
  getActiveRecords:UPCDB.getActiveLibraryRecords,
  updateMasterUpc:UPCDB.updateActiveLibraryMasterUpc,
  stageGeneration:UPCDB.stageLibrary,
  cleanupGenerations:UPCDB.cleanupLibraries,
  discardGeneration:UPCDB.discardLibraryGeneration,
  reindexActive:UPCDB.reindexActiveLibrary
 });
})();
window.UPCMasterRepository=UPCMasterRepository;
