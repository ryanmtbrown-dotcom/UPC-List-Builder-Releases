/*
 * OWNERSHIP:
 * File: app/src/main/assets/www/migration-repository.js
 * Owner: Application Migration Infrastructure
 * Role: Migration repository/service
 * Responsibility: Owns bounded, idempotent supported migration/retirement markers and the migrations still required by current contracts.
 * Does not own: Ordinary startup business logic; UI; indefinite legacy preservation; unrelated domain writes.
 * Side effects: May read/write specifically authorized legacy/current stores and migration markers; may call Work Session service where required.
 * Related code: Obsolete migrations must be removed when their support requirement is retired; Git history is the archive.
 */
const UPCMigrationRepository=(()=>{
 const PROMOTED_MASTER_SOURCES=new Set(['LOCAL_ADDITION','ACENET_AUTO_ADD']);
 const normSku=value=>UPCIdentifierNormalization.normalizeSKU(value);
 const isAddToLibraryItem=item=>item?.primaryPurpose==='Add to Library'||(item?.tags||[]).includes('Add to Library');
 const workflowActive=item=>!['IMPORTED','CLEARED'].includes(item?.libraryWorkflowStatus);

 const WORK_SESSION_MIGRATION_KEY='migration.workSessions.v279Normalization';
 const LEGACY_WORK_SESSION_STORAGE_KEY='upcFieldLists.v0.01';
 const LEGACY_PRIMARY_PURPOSES=['NIF','Price Change','General Review'];
 const parseLegacyMoney=value=>{if(value==null||value==='')return null;const n=Number(String(value).replace(/[^0-9.-]/g,''));return Number.isFinite(n)?n:null};
 function normalizeLegacyWorkSession(session){
  let changed=false;
  if(session.defaultTag==='Not in File'){session.defaultTag='NIF';changed=true}
  if(!session.sessionType){session.sessionType='LEGACY_LIST';changed=true}
  if(!Array.isArray(session.items)){session.items=[];changed=true}
  if(!Array.isArray(session.captures)){session.captures=[];changed=true}
  if(typeof session.promptLabelPriceAfterScan!=='boolean'){session.promptLabelPriceAfterScan=false;changed=true}
  if(typeof session.autoAddPriceDifference!=='boolean'){session.autoAddPriceDifference=false;changed=true}
  for(const item of session.items){
   if(!Array.isArray(item.tags)){item.tags=[];changed=true}else if(item.tags.includes('Not in File')){item.tags=item.tags.map(tag=>tag==='Not in File'?'NIF':tag);changed=true}
   if(item.libraryPrice===undefined){item.libraryPrice=parseLegacyMoney(item.price);changed=true}
   if(item.labelPrice===undefined){item.labelPrice=null;changed=true}
   if(item.priceDifference===undefined){item.priceDifference=null;changed=true}
   if(!item.primaryPurpose){item.primaryPurpose=LEGACY_PRIMARY_PURPOSES.find(tag=>item.tags.includes(tag))||null;changed=true}
   if(!Array.isArray(item.supplementalPurposes)){item.supplementalPurposes=[];changed=true}
  }
  return changed;
 }
 async function prepareWorkSessions({storage=null,diagnostic=null}={}){
  const diag=typeof diagnostic==='function'?diagnostic:()=>{},existing=await UPCDB.get('meta',WORK_SESSION_MIGRATION_KEY);
  if(existing?.applied){
   const retirement=await retireStage9LegacyState();
   return{...existing,appliedNow:false,retirementAppliedNow:retirement.appliedNow===true};
  }
  let legacyRows=[];
  try{const raw=storage?.getItem?.(LEGACY_WORK_SESSION_STORAGE_KEY);const parsed=raw?JSON.parse(raw):[];if(Array.isArray(parsed))legacyRows=parsed}catch{}
  let legacyImported=0;
  for(const session of legacyRows){if(!session?.id)continue;await UPCWorkSessionService.save(session,{touch:false});legacyImported++}
  if(legacyRows.length)storage?.removeItem?.(LEGACY_WORK_SESSION_STORAGE_KEY);
  const sessions=await UPCWorkSessionService.list();let sessionsUpdated=0;
  for(const session of sessions){if(normalizeLegacyWorkSession(session)){await UPCWorkSessionService.save(session,{touch:false});sessionsUpdated++}}
  const retirement=await retireStage9LegacyState(),result={key:WORK_SESSION_MIGRATION_KEY,applied:true,appliedAt:new Date().toISOString(),legacyImported,sessionsChecked:sessions.length,sessionsUpdated,retirementAppliedNow:retirement.appliedNow===true};
  await UPCDB.put('meta',result);
  diag('legacy_work_sessions_migrated',{legacyImported,sessionsChecked:sessions.length,sessionsUpdated,marker:WORK_SESSION_MIGRATION_KEY});
  diag('list_schema_checked',{count:sessions.length,migrationMarker:WORK_SESSION_MIGRATION_KEY});
  return{...result,appliedNow:true,retirement};
 }

 async function retireStage9LegacyState(){
  const markerKey='migration.stage9.deprecatedRetirement',existing=await UPCDB.get('meta',markerKey);
  if(existing?.applied)return{...existing,appliedNow:false};

  const [pending,lists,masterMeta,activeMaster,localMeta]=await Promise.all([
   UPCDB.get('meta','pendingLibraryAdditions'),
   UPCWorkSessionService.list(),
   UPCDB.get('meta','library'),
   UPCDB.getActiveLibraryRecords(),
   UPCDB.get('meta','localLibraryAdditions')
  ]);

  const queueCandidates=new Map();
  const addCandidate=(sku,source)=>{
   const key=normSku(sku);if(!key)return false;
   const row=queueCandidates.get(key)||{sku:key,sources:new Set()};
   row.sources.add(source);queueCandidates.set(key,row);return true;
  };

  const pendingRows=Array.isArray(pending?.records)?pending.records:[],pendingDiscarded=[];
  for(const row of pendingRows){
   const sku=row?.values?.sku||row?.sku||'';
   if(!addCandidate(sku,'LEGACY_PENDING_ADDITION'))pendingDiscarded.push(row?.id||null);
  }
  let listCandidates=0,listDiscarded=0;
  for(const list of (Array.isArray(lists)?lists:[])){
   for(const item of (Array.isArray(list?.items)?list.items:[])){
    if(!isAddToLibraryItem(item)||!workflowActive(item))continue;
    if(addCandidate(item?.sku,'LEGACY_ADD_TO_LIBRARY_LIST'))listCandidates++;else listDiscarded++;
   }
  }
  for(const {sku,sources} of queueCandidates.values())await UPCDB.enqueueLibrarySku({sku,source:'STAGE9_LEGACY_RETIREMENT',queueReason:'LEGACY_ADD_TO_LIBRARY_RETIREMENT',legacySources:[...sources]});
  if(pending)await UPCDB.remove('meta','pendingLibraryAdditions');

  const promotedRows=(Array.isArray(activeMaster)?activeMaster:[]).filter(row=>PROMOTED_MASTER_SOURCES.has(String(row?.source||'')));
  const officialRows=(Array.isArray(activeMaster)?activeMaster:[]).filter(row=>!PROMOTED_MASTER_SOURCES.has(String(row?.source||'')));
  let promotedRowsRetired=0,newGeneration=masterMeta?.generation||null,masterReindexed=false;
  if(masterMeta?.generation){
   if(promotedRows.length){
    const retired=await UPCDB.deleteActiveLibraryRows(promotedRows.map(row=>row.id),masterMeta.generation);
    if(Number(retired?.deleted||0)!==promotedRows.length)throw new Error('Stage 9 did not retire every promoted Master compatibility row.');
    promotedRowsRetired=promotedRows.length;
   }
   const nextMeta={...masterMeta,generation:masterMeta.generation,recordCount:officialRows.length,officialRecordCount:officialRows.length,stage9MasterNormalizedAt:new Date().toISOString(),stage9PromotedRowsRetiredAt:new Date().toISOString(),stage9PromotedRowsRetiredCount:promotedRowsRetired};
   for(const key of ['localAdditionCount','localSuppressedCount','lastLocalLibraryPushAt','lastLocalLibraryPushAdded','lastLocalLibraryPushRefreshed','lastLocalLibraryPushSkipped','lastLocalLibraryAppliedAt','lastPromotedLocalRestoreAt','lastPromotedLocalRestoreCount'])delete nextMeta[key];
   await UPCDB.put('meta',nextMeta);
   const confirmed=await UPCDB.get('meta','library');if(confirmed?.generation!==masterMeta.generation)throw new Error('Stage 9 Master retirement changed the active official Master generation unexpectedly.');
  }
  const localRows=Array.isArray(localMeta?.records)?localMeta.records:[],cleanedLocal=localRows.map(row=>{
   if(!row||!Object.prototype.hasOwnProperty.call(row,'masterPromotion'))return row;
   const next={...row};delete next.masterPromotion;return next;
  }),localPromotionMetadataRemoved=cleanedLocal.reduce((n,row,i)=>n+(row!==localRows[i]?1:0),0);
  if(localPromotionMetadataRemoved)await UPCDB.put('meta',{...(localMeta||{key:'localLibraryAdditions'}),key:'localLibraryAdditions',records:cleanedLocal,updatedAt:new Date().toISOString()});

  const result={key:markerKey,applied:true,appliedAt:new Date().toISOString(),queuedSkus:queueCandidates.size,pendingRecordsSeen:pendingRows.length,pendingRecordsDiscarded:pendingDiscarded.length,listCandidates,listItemsDiscardedWithoutSku:listDiscarded,promotedRowsRetired,masterReindexed,localPromotionMetadataRemoved,activeGeneration:newGeneration};
  await UPCDB.put('meta',result);
  return{...result,appliedNow:true};
 }
 return Object.freeze({prepareWorkSessions,retireStage9LegacyState});
})();
window.UPCMigrationRepository=UPCMigrationRepository;
