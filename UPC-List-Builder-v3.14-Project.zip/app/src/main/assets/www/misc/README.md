# ACE MISC Directory Ownership

OWNS: ACE MISC draft state, local/Master/AceNet resolution orchestration, verification/export-readiness semantics, saved-session maintenance, runtime resolver registration, snapshot construction, workspace UI, and MISC-specific presentation styles.

DOMAIN AUTHORITY: `../ace-misc.js` retains MISC workbook/domain primitives, required validation semantics, and the exact reusable 33-column ACE MISC row/layout formatter while consuming the ordered ACE MISC header identity from `../catalog/standard-export-schema.js`. Ordinary Field Session export may call only the available-evidence formatter when Force ACE MISC Format is enabled; its optional generic trailing-column capability allows Field Session to append observed `Label Price` for Price Change without duplicating or modifying the canonical ACE MISC 33 fields. The normal MISC workspace and all other forced purposes remain exact 33-column exports. This reuse does not make an ordinary list a MISC Work Session or impose MISC verification rules.

DOES NOT OWN: normal lookup presentation authority, raw IndexedDB, native AceNet authentication/extraction, or unrelated Work Session types.

PERSISTENCE: saved MISC sessions mutate only through Work Session Service; durable catalog writes route through approved catalog/relationship services.
