/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/misc/misc-maintenance-service.js
 * Owner: ACE MISC Maintenance
 * Role: Domain maintenance service
 * Responsibility: Owns bounded repair/update of saved MISC session snapshots through the Work Session boundary.
 * Does not own: Catalog refresh, raw list-store access, UI, AceNet session/extraction, or general migration policy.
 * Side effects: Reads/writes MISC Work Sessions only through injected WorkSessionService.
 * Related code: Catalog repair orchestration belongs to Catalog Maintenance Service.
 */
const UPCMiscMaintenanceService=(()=>{
 function create({workSessionService,draftModel,normalizeSku,normalizeWeight}={}){
  if(!workSessionService||!draftModel||typeof normalizeSku!=='function'||typeof normalizeWeight!=='function')throw new Error('MISC Maintenance Service dependencies are incomplete.');
  async function findSnapshotRepairCandidates(){
   const sessions=await workSessionService.list(),out=new Map();
   for(const session of sessions){
    if(session?.sessionType!=='ACE_NEW_ITEMS_MISC'||!Array.isArray(session.items))continue;
    for(const item of session.items){
     const sku=normalizeSku(item?.sku),snapshot=item?.aceMiscSnapshot;
     if(!sku||!snapshot?.baseRow||snapshot?.source==='MASTER_LIBRARY_PLUS_ACENET_UPCS')continue;
     const row=snapshot.baseRow,reasons=[];
     if(!String(row[3]??'').trim()||/^specs$/i.test(String(row[3]??'').trim()))reasons.push('description');
     if(!normalizeWeight(row[11]))reasons.push('omWeight');
     if(!/^\s*\d+/.test(String(row[23]??'')))reasons.push('commodityGroup');
     if(!/^\s*\d+/.test(String(row[24]??'')))reasons.push('merchandiseClassNumber');
     if(!/^\s*\d+/.test(String(row[25]??'')))reasons.push('productGroupNumber');
     if(!reasons.length)continue;
     const prior=out.get(sku)||{sku,reasons:new Set(),listIds:new Set()};reasons.forEach(reason=>prior.reasons.add(reason));prior.listIds.add(session.id);out.set(sku,prior);
    }
   }
   return [...out.values()].map(entry=>({sku:entry.sku,reasons:[...entry.reasons],listIds:[...entry.listIds]}));
  }
  async function replaceSnapshotsForSku(sku,snapshot){
   const key=normalizeSku(sku),sessions=await workSessionService.list();let listsUpdated=0,itemsUpdated=0;
   for(const session of sessions){
    if(session?.sessionType!=='ACE_NEW_ITEMS_MISC'||!Array.isArray(session.items))continue;
    let changed=false;
    const items=session.items.map(item=>{
     if(normalizeSku(item?.sku)!==key)return item;
     const existing=item?.aceMiscSnapshot;if(existing?.source==='MASTER_LIBRARY_PLUS_ACENET_UPCS')return item;
     const next={...item};if(!draftModel.applySnapshot(next,snapshot))return item;changed=true;itemsUpdated++;return next;
    });
    if(changed){await workSessionService.save({...session,items});listsUpdated++}
   }
   return{listsUpdated,itemsUpdated};
  }
  return Object.freeze({findSnapshotRepairCandidates,replaceSnapshotsForSku});
 }
 return Object.freeze({create});
})();
window.UPCMiscMaintenanceService=UPCMiscMaintenanceService;
