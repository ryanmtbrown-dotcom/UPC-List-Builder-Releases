/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/misc/misc-resolution-service.js
 * Owner: ACE MISC Resolution
 * Role: Domain service
 * Responsibility: Owns MISC Master→Local→AceNet SKU resolution, exact-SKU live refresh, known-record refresh, and verified durable Local persistence handoff.
 * Does not own: MISC UI, raw persistence, native session/extraction, or normal lookup presentation.
 * Side effects: Calls injected resolver/AceNet/catalog services; durable catalog mutation occurs only through Catalog Refresh Service.
 * Related code: Workspace presentation belongs to Misc Workspace Controller; draft state belongs to Misc Draft Model.
 */
const UPCMiscResolutionService=(()=>{
 function create({
  effectiveResolver,localRepository,relationshipService,catalogRefreshService,normalLookupController,itemMapper,
  miscDomain,draftModel,normalizeSku,requestCatalog,diagnostic
 }={}){
  if(!effectiveResolver||!localRepository||!relationshipService||!catalogRefreshService||!normalLookupController||!itemMapper||!miscDomain||!draftModel)throw new Error('MISC Resolution Service dependencies are incomplete.');
  if(typeof normalizeSku!=='function'||typeof requestCatalog!=='function')throw new Error('MISC Resolution Service request dependencies are incomplete.');
  const UPCEffectiveCatalogResolver=effectiveResolver,UPCLocalRepository=localRepository,UPCIdentifierRelationshipService=relationshipService,ACEMisc=miscDomain,itemRecordMapper=itemMapper,catalogRefreshServiceRef=catalogRefreshService,normalizeSKU=normalizeSku,requestAceNetCatalog=requestCatalog,diag=typeof diagnostic==='function'?diagnostic:()=>{};

  async function aceMiscLibraryDraft(key,row,{libraryKind='MASTER',aceNetStatus='UNAVAILABLE'}={}){
   const refs=await UPCIdentifierRelationshipService.getSkuUpcs(key),primary=row?.originalUPC||row?.upcKey||(row?.fields?.['UPC/EAN']||''),upcs=draftModel.storedDraftUpcs(primary,refs);
   if(!upcs.length)throw new Error(`SKU ${key}: the local catalog has no UPC available even for a draft.`);
   const isLocal=String(libraryKind).toUpperCase()==='LOCAL',baseItem=itemRecordMapper.itemFromLibraryRow(row,{lookupMode:isLocal?'LOCAL_SKU_EXACT':'MASTER_SKU_EXACT',fallbackSku:key,librarySource:isLocal?'LOCAL_LIBRARY':'MASTER_LIBRARY'}),snapshot=isLocal?ACEMisc.snapshotFromLocalRecord(row,key,upcs):ACEMisc.snapshotFromMasterRecord(row,key,upcs),verification=aceNetStatus==='NOT_FOUND'?ACEMisc.UPC_VERIFICATION.NEEDS_USER_CONFIRMATION:ACEMisc.UPC_VERIFICATION.PENDING_ACENET,item=draftModel.decorateItem(draftModel.bulkItemFromResolved(baseItem,snapshot),snapshot,verification,aceNetStatus);
   diag('ace_misc_library_draft_created',{sku:key,libraryKind:isLocal?'LOCAL':'MASTER',aceNetStatus,upcCount:upcs.length,verification});
   return{status:'FOUND',item,source:isLocal?'LOCAL_LIBRARY_DRAFT':'MASTER_LIBRARY_DRAFT',upcs,aceNetUsed:true,recordId:row?.id??null,localPersisted:isLocal,upcVerification:verification,aceNetStatus};
  }
  async function aceMiscRefreshLibraryRecord(key,row,{libraryKind='MASTER',relationshipSource='ACENET_MISC'}={}){
   const isLocal=String(libraryKind).toUpperCase()==='LOCAL',target=isLocal?'LOCAL_LIBRARY':'MASTER_LIBRARY';
   diag('ace_misc_full_catalog_started',{sku:key,target,recordId:row?.id??null});
   const result=await requestAceNetCatalog(key,{misc:true});
   if(result?.status==='NOT_FOUND')return aceMiscLibraryDraft(key,row,{libraryKind,aceNetStatus:'NOT_FOUND'});
   if(result?.status==='VERIFIED_NO_UPC_DATA'&&result.catalog){
    const returnedSku=normalizeSKU(result.sku);if(returnedSku!==key)throw new Error(`AceNet returned SKU ${returnedSku||'blank'} instead of requested SKU ${key}.`);
    const refs=await UPCIdentifierRelationshipService.getSkuUpcs(key),primary=row?.originalUPC||row?.upcKey||(row?.fields?.['UPC/EAN']||''),knownUpcs=draftModel.storedDraftUpcs(primary,refs);
    if(!knownUpcs.length)throw new Error(`SKU ${key}: AceNet verified the SKU but exposes no UPC data, and the Library has no UPC available.`);
    const catalog={...result.catalog,sku:key},snapshot=ACEMisc.snapshotFromLibraryAndAceNet(row,key,catalog,{libraryKind:isLocal?'LOCAL':'MASTER',source:isLocal?'LOCAL_LIBRARY_PLUS_ACENET_NO_UPC_DATA':'MASTER_LIBRARY_PLUS_ACENET_NO_UPC_DATA',fallbackUpcs:knownUpcs,upcVerification:ACEMisc.UPC_VERIFICATION.VERIFIED_NO_ACENET_UPC_DATA}),baseItem=itemRecordMapper.itemFromLibraryRow(row,{lookupMode:isLocal?'LOCAL_SKU_ACENET_NO_UPC':'MASTER_SKU_ACENET_NO_UPC',fallbackSku:key,librarySource:isLocal?'LOCAL_LIBRARY':'MASTER_LIBRARY'}),item=draftModel.decorateItem(draftModel.bulkItemFromResolved(baseItem,snapshot),snapshot,ACEMisc.UPC_VERIFICATION.VERIFIED_NO_ACENET_UPC_DATA,'VERIFIED_NO_UPC_DATA',catalog.aceRetailPrice);
    diag('ace_misc_no_upc_data_ready',{sku:key,target,recordId:row?.id??null,upcCount:knownUpcs.length,missingFields:result.missingFields||['masterUpc'],relationshipSetChanged:false,exportReady:true,livePrice:catalog.aceRetailPrice||null});
    return{status:'FOUND',item,source:isLocal?'LOCAL_LIBRARY_ACENET_NO_UPC_DATA':'MASTER_LIBRARY_ACENET_NO_UPC_DATA',upcs:knownUpcs,aceNetUsed:true,recordId:row?.id??null,localPersisted:isLocal,upcVerification:ACEMisc.UPC_VERIFICATION.VERIFIED_NO_ACENET_UPC_DATA,aceNetStatus:'VERIFIED_NO_UPC_DATA'};
   }
   if(result?.status!=='VERIFIED'||!result.catalog)return aceMiscLibraryDraft(key,row,{libraryKind,aceNetStatus:result?.status||'UNAVAILABLE'});
   const returnedSku=normalizeSKU(result.sku);if(returnedSku!==key)throw new Error(`AceNet returned SKU ${returnedSku||'blank'} instead of requested SKU ${key}.`);
   const catalog={...result.catalog,sku:key},applied=await catalogRefreshServiceRef.applyCatalogRefreshPolicyToExistingRecord({sku:key,target,record:row,evidence:catalog,exactSkuVerified:true,source:'ACE_MISC_FULL_REFRESH',relationshipSource,completeUpcSet:true});
   const refreshed=await UPCEffectiveCatalogResolver.inspectSKU(key),freshRow=isLocal?(refreshed.local.count===1?refreshed.local.row:row):(refreshed.master.count===1?refreshed.master.row:row);
   const snapshot=ACEMisc.snapshotFromLibraryAndAceNet(freshRow,key,catalog,{libraryKind:isLocal?'LOCAL':'MASTER',source:isLocal?'LOCAL_LIBRARY_PLUS_LIVE_ACENET':'MASTER_LIBRARY_PLUS_LIVE_ACENET'}),baseItem=itemRecordMapper.itemFromLibraryRow(freshRow,{lookupMode:isLocal?'LOCAL_SKU_ACENET_REFRESH':'MASTER_SKU_ACENET_REFRESH',fallbackSku:key,librarySource:isLocal?'LOCAL_LIBRARY':'MASTER_LIBRARY'}),item=draftModel.decorateItem(draftModel.bulkItemFromResolved(baseItem,snapshot),snapshot,ACEMisc.UPC_VERIFICATION.VERIFIED_COMPLETE,'VERIFIED',catalog.aceRetailPrice);
   diag('ace_misc_full_catalog_ready',{sku:key,target,recordId:freshRow?.id??null,upcCount:snapshot.orderedUpcs.length,storageUpdated:Boolean(applied?.storage?.updated),livePrice:catalog.aceRetailPrice||null});
   return{status:'FOUND',item,source:isLocal?'LOCAL_LIBRARY_LIVE_ACENET':'MASTER_LIBRARY_LIVE_ACENET',upcs:snapshot.orderedUpcs,aceNetUsed:true,recordId:freshRow?.id??null,localPersisted:isLocal,upcVerification:ACEMisc.UPC_VERIFICATION.VERIFIED_COMPLETE,aceNetStatus:'VERIFIED'};
  }
  async function aceMiscFromLocalRecord(key,localRow,{relationshipSource='ACENET_MISC'}={}){return aceMiscRefreshLibraryRecord(key,localRow,{libraryKind:'LOCAL',relationshipSource})}
  async function resolveAceMiscSkuCandidate(sku,{relationshipSource='ACENET_MISC'}={}){
   const key=normalizeSKU(sku);if(!key)throw new Error('A valid SKU is required for ACE MISC lookup.');
   const evidence=await UPCEffectiveCatalogResolver.inspectSKU(key),master=evidence.master,local=evidence.local;
   diag('ace_misc_candidate_library_resolved',{sku:key,masterMatches:master.count,localMatches:local.count,masterRecordId:master.count===1?(master.row?.id??null):null,localRecordId:local.count===1?(local.row?.id??null):null,masterOrigin:master.row?.source||null});
   if(master.count>1)return{status:'AMBIGUOUS',item:await normalLookupController.lookupItemBySku(key),source:'MASTER_LIBRARY_AMBIGUOUS',upcs:[],aceNetUsed:false};
   if(local.count>1)return{status:'AMBIGUOUS',item:{status:'AMBIGUOUS',sku:key,upc:'',lookupMode:'LOCAL_SKU_EXACT',matches:local.count,fields:{}},source:'LOCAL_LIBRARY_AMBIGUOUS',upcs:[],aceNetUsed:false};
   if(master.count===1&&master.row)return aceMiscRefreshLibraryRecord(key,master.row,{libraryKind:'MASTER',relationshipSource});
   if(local.count===1&&local.row)return aceMiscFromLocalRecord(key,local.row,{relationshipSource});
   diag('ace_misc_candidate_acenet_catalog_started',{sku:key,source:'MASTER_LOCAL_MISS'});
   const result=await requestAceNetCatalog(key,{misc:true});
   if(result?.status==='NOT_FOUND')return{status:'NOT_FOUND',item:{status:'NOT_FOUND',sku:key,upc:'',description:'',fields:{}},source:'ACENET_NOT_FOUND',upcs:[],aceNetUsed:true,localPersisted:false,upcVerification:ACEMisc.UPC_VERIFICATION.NEEDS_USER_CONFIRMATION,aceNetStatus:'NOT_FOUND'};
   if(result?.status!=='VERIFIED'||!result.catalog)throw new Error(`AceNet MISC catalog lookup ${result?.status||'failed'}.`);
   if(normalizeSKU(result.sku)!==key)throw new Error(`AceNet returned SKU ${normalizeSKU(result.sku)||'blank'} instead of requested SKU ${key}.`);
   const persisted=await catalogRefreshServiceRef.persistVerifiedAceNetCatalogToLocalLibrary(key,{...result.catalog,sku:key},{source:'ACE_MISC_LOOKUP',relationshipSource});
   if(persisted.status!=='COMPLETED')throw new Error(`AceNet returned SKU ${key}, but durable Local Library persistence did not complete.`);
   const fresh=await UPCLocalRepository.lookupSKU(key);if(fresh.count!==1||!fresh.row)throw new Error(`Local Library SKU ${key} could not be read back after AceNet persistence.`);
   const snapshot=ACEMisc.snapshotFromLibraryAndAceNet(fresh.row,key,result.catalog,{libraryKind:'LOCAL',source:'LOCAL_LIBRARY_FROM_ACENET'}),item=draftModel.decorateItem(draftModel.bulkItemFromResolved(itemRecordMapper.itemFromLibraryRow(fresh.row,{lookupMode:'LOCAL_SKU_ACENET',fallbackSku:key,librarySource:'LOCAL_LIBRARY'}),snapshot),snapshot,ACEMisc.UPC_VERIFICATION.VERIFIED_COMPLETE,'VERIFIED',result.catalog.aceRetailPrice);
   diag('ace_misc_candidate_acenet_ready',{sku:key,upcCount:snapshot.orderedUpcs.length,localRecordId:fresh.row.id??null,localPersisted:true});
   return{status:'FOUND',item,source:'LOCAL_LIBRARY_FROM_ACENET',upcs:snapshot.orderedUpcs,aceNetUsed:true,recordId:fresh.row.id??null,localPersisted:true,upcVerification:ACEMisc.UPC_VERIFICATION.VERIFIED_COMPLETE,aceNetStatus:'VERIFIED'};
  }
  return Object.freeze({resolveSkuCandidate:resolveAceMiscSkuCandidate,aceMiscLibraryDraft,aceMiscRefreshLibraryRecord,aceMiscFromLocalRecord});
 }
 return Object.freeze({create});
})();
window.UPCMiscResolutionService=UPCMiscResolutionService;
