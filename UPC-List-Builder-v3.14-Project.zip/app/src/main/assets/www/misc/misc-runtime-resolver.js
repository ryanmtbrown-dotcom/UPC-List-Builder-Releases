/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/misc/misc-runtime-resolver.js
 * Owner: ACE MISC Runtime Boundary
 * Role: Runtime adapter
 * Responsibility: Owns runtime registration/discovery of the current MISC resolution capability at the composition seam.
 * Does not own: Resolution policy, persistence, UI, or AceNet behavior.
 * Side effects: Registers/reads the approved runtime resolver capability only.
 * Related code: Resolution implementation belongs to misc-resolution-service.js.
 */
const UPCMiscRuntimeResolver=(()=>{
 function create({windowRef,documentRef,releaseProvider,diagnostic,resolutionService}={}){
  if(!windowRef||!documentRef||typeof releaseProvider!=='function'||typeof diagnostic!=='function'||!resolutionService)throw new Error('MISC Runtime Resolver dependencies are incomplete.');
  const exported=Object.freeze({resolveSkuCandidate:resolutionService.resolveSkuCandidate});windowRef.UPCAceMiscResolver=exported;
  diagnostic('ace_misc_runtime_resolver_exported',{release:releaseProvider(),resolverOwnerType:typeof windowRef.UPCAceMiscResolver,resolverFunctionType:typeof windowRef.UPCAceMiscResolver?.resolveSkuCandidate});
  function requireResolver(context='ACE_MISC'){
   const fn=windowRef.UPCAceMiscResolver?.resolveSkuCandidate;if(typeof fn==='function')return fn;
   const evidence={context,release:releaseProvider(),indexBuildId:documentRef.querySelector('meta[name="build-id"]')?.content||null,resolverOwnerType:typeof windowRef.UPCAceMiscResolver,resolverFunctionType:typeof windowRef.UPCAceMiscResolver?.resolveSkuCandidate,scriptSources:[...documentRef.scripts].map(x=>x.src||'[inline]')};
   diagnostic('ace_misc_runtime_resolver_missing',evidence);throw new Error('ACE MISC resolver is unavailable in the active runtime.');
  }
  return Object.freeze({exported,requireResolver});
 }
 return Object.freeze({create});
})();
window.UPCMiscRuntimeResolver=UPCMiscRuntimeResolver;
