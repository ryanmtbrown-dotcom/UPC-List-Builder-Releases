/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/misc/misc-snapshot-service.js
 * Owner: ACE MISC Snapshot Domain
 * Role: Pure/domain service
 * Responsibility: Owns canonical MISC snapshot construction from verified catalog/relationship evidence.
 * Does not own: Persistence, UI, network, verification policy, or Work Session orchestration.
 * Side effects: Reads injected relationship/domain data and returns snapshots; no direct writes.
 * Related code: Draft application belongs to Misc Draft Model; saved-session updates belong to Work Session/MISC maintenance owners.
 */
const UPCMiscSnapshotService=(()=>{
 function create({relationshipService,miscDomain,normalizeUpc}={}){
  if(!relationshipService||!miscDomain||typeof normalizeUpc!=='function')throw new Error('MISC Snapshot Service dependencies are incomplete.');
  async function correctedSnapshotForLocalRow(sku,row){
   const refs=await relationshipService.getSkuUpcs(sku),master=refs.filter(x=>x.isMaster).map(x=>x.upcKey),alternates=refs.filter(x=>!x.isMaster).map(x=>x.upcKey),fallback=normalizeUpc(row?.originalUPC||row?.upcKey||''),ordered=[...new Set([...master,fallback,...alternates].filter(Boolean))];
   if(!ordered.length)throw new Error('No UPC relationships are available for this Local Library record.');
   return miscDomain.snapshotFromLocalRecord(row,sku,ordered);
  }
  return Object.freeze({correctedSnapshotForLocalRow});
 }
 return Object.freeze({create});
})();
window.UPCMiscSnapshotService=UPCMiscSnapshotService;
