/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/misc/misc-verification-service.js
 * Owner: ACE MISC Verification
 * Role: Domain/workflow service
 * Responsibility: Owns MISC UPC completeness, retry/user-confirmation flow, canonical export-readiness checks, and verified retry persistence through Work Sessions.
 * Does not own: Raw persistence, UI layout, normal lookup, or native AceNet session/extraction.
 * Side effects: Calls injected resolver/prompt/WorkSession boundaries and persists only verified MISC session results.
 * Related code: Draft semantics belong to Misc Draft Model; UI action state belongs to Misc Workspace Controller.
 */
const UPCMiscVerificationService=(()=>{
 function create({draftModel,miscDomain,normalizeSku,normalizeUpc,resolveProvider,promptUser,messageUser,workSessionService,getCurrentSession,setCurrentSession,diagnostic}={}){
  if(!draftModel||!miscDomain||typeof normalizeSku!=='function'||typeof normalizeUpc!=='function'||typeof resolveProvider!=='function')throw new Error('MISC Verification Service resolution dependencies are incomplete.');
  if(typeof promptUser!=='function'||typeof messageUser!=='function'||!workSessionService||typeof getCurrentSession!=='function'||typeof setCurrentSession!=='function')throw new Error('MISC Verification Service persistence/UI dependencies are incomplete.');
  const ACEMisc=miscDomain,normalizeSKU=normalizeSku,normalizeUPC=normalizeUpc,diag=typeof diagnostic==='function'?diagnostic:()=>{};
  let retryRunning=false;
  function isRetryRunning(){return retryRunning}
  async function confirmAceMiscKnownUpcs(item){
   if(!item)return false;
   const sku=normalizeSKU(item.sku),snapshot=item.aceMiscSnapshot,existing=[...new Set((snapshot?.orderedUpcs||[]).map(normalizeUPC).filter(Boolean))];
   const answer=await promptUser(`AceNet reported SKU ${sku} was not found.\n\nEnter every additional UPC you know belongs to this item, separated by spaces or commas. If the UPCs already shown are the complete set, leave this box blank and choose OK. Choose Cancel if you cannot confirm the complete UPC set yet.\n\nCurrently known: ${existing.join(', ')||'none'}`,'','ACE MISC UPC Verification');
   if(answer===null)return false;
   const raw=String(answer||'').trim(),entered=[...new Set((raw.match(/\d{6,14}/g)||[]).map(normalizeUPC).filter(Boolean))];
   if(raw&&!entered.length){await messageUser('No valid 6–14 digit UPC was entered. UPC verification remains unresolved.','ACE MISC UPC Verification');return false}
   const all=[...new Set([...existing,...entered])];
   if(!all.length){await messageUser('There is no UPC available to confirm for this item.','ACE MISC UPC Verification');return false}
   draftModel.applyUserConfirmedUpcs(item,all);diag('ace_misc_user_confirmed_upc_set',{sku,upcCount:all.length,aceNetStatus:'NOT_FOUND',identityPersistence:false});return true;
  }
  async function verifyAceMiscExistingItem(item,{promptNotFound=false,relationshipSource='ACENET_MISC_RETRY'}={}){
   const sku=normalizeSKU(item?.sku);if(!sku)return{status:'INVALID_SKU',complete:false};
   if(draftModel.exportReady(item))return{status:'ALREADY_COMPLETE',complete:true};
   let resolution;
   try{resolution=await resolveProvider('ACE_MISC_VERIFY_EXISTING')(sku,{relationshipSource})}
   catch(e){item.aceMiscUpcVerification=ACEMisc.UPC_VERIFICATION.PENDING_ACENET;item.aceMiscAceNetStatus='ERROR';diag('ace_misc_verification_retry_failed',{sku,message:e?.message||String(e)});return{status:'ERROR',complete:false,message:e?.message||String(e)}}
   if(resolution?.status==='FOUND'&&resolution.item){draftModel.applyResolutionToExistingItem(item,resolution);if(draftModel.exportReady(item))return{status:'VERIFIED',complete:true}}
   if(resolution?.status==='NOT_FOUND'||draftModel.verificationState(item)===ACEMisc.UPC_VERIFICATION.NEEDS_USER_CONFIRMATION){item.aceMiscUpcVerification=ACEMisc.UPC_VERIFICATION.NEEDS_USER_CONFIRMATION;item.aceMiscAceNetStatus='NOT_FOUND';if(promptNotFound&&await confirmAceMiscKnownUpcs(item))return{status:'USER_CONFIRMED',complete:true};return{status:'NEEDS_USER_CONFIRMATION',complete:false}}
   return{status:resolution?.aceNetStatus||'PENDING_ACENET',complete:false};
  }
  async function retryPendingAceMiscVerification(list,{promptNotFound=false}={}){
   if(retryRunning||list?.sessionType!=='ACE_NEW_ITEMS_MISC')return{checked:0,completed:0,pending:0};
   const pendingItems=(list.items||[]).filter(item=>!draftModel.exportReady(item));if(!pendingItems.length)return{checked:0,completed:0,pending:0};
   retryRunning=true;let checked=0,completed=0;
   try{
    for(const item of pendingItems){const result=await verifyAceMiscExistingItem(item,{promptNotFound,relationshipSource:'ACENET_MISC_PENDING_RETRY'});checked++;if(result.complete)completed++}
    await workSessionService.save(list);if(getCurrentSession()?.id===list.id)setCurrentSession(list);
    const remaining=(list.items||[]).filter(item=>!draftModel.exportReady(item)).length;
    diag('ace_misc_pending_verification_retry_complete',{listId:list.id,checked,completed,pending:remaining,promptNotFound});return{checked,completed,pending:remaining};
   }finally{retryRunning=false}
  }
  async function ensureAceMiscExportReady(list){
   let pendingItems=(list?.items||[]).filter(item=>!draftModel.exportReady(item));if(!pendingItems.length)return true;
   await retryPendingAceMiscVerification(list,{promptNotFound:true});
   pendingItems=(list?.items||[]).filter(item=>!draftModel.exportReady(item));if(!pendingItems.length)return true;
   const skus=pendingItems.map(x=>normalizeSKU(x.sku)).filter(Boolean);
   throw new Error(`Complete UPC verification is still required for ${pendingItems.length} item${pendingItems.length===1?'':'s'}: SKU ${skus.join(', ')}. Reconnect AceNet or confirm the known UPC set for items AceNet reports as not found.`);
  }
  return Object.freeze({isRetryRunning,confirmAceMiscKnownUpcs,verifyAceMiscExistingItem,retryPendingAceMiscVerification,ensureAceMiscExportReady});
 }
 return Object.freeze({create});
})();
window.UPCMiscVerificationService=UPCMiscVerificationService;
