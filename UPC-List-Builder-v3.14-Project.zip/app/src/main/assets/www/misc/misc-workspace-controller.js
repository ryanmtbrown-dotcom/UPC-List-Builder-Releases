/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/misc/misc-workspace-controller.js
 * Owner: ACE MISC Workspace
 * Role: Controller/orchestrator
 * Responsibility: Owns manual/bulk MISC UI workflow, lookup presentation coordination, daily list reuse, verification actions, progress/results, MISC export dispatch, and active MISC session mutation.
 * Does not own: Raw persistence, catalog field authority, native AceNet extraction/session repair, or normal lookup policy.
 * Side effects: Mutates MISC DOM and active Work Session through injected services; invokes resolution/verification/export domain owners.
 * Related code: Resolution/verification/draft semantics remain in their focused misc/ services.
 */
const UPCMiscWorkspaceController=(()=>{
 function create({
  elementById,escapeHtml,getCurrentSession,setCurrentSession,getManualLookupMode,setManualLookupMode,
  normalizeSku,normalizeUpc,presentationController,clearLookupTransientPriceState,normalLookupController,
  resolveProvider,verificationService,draftModel,miscDomain,workSessionService,newId,sessionName,fileDelivery,
  refreshSavedLists,messageUser,diagnostic,getAceNetRuntimeState,normalizeAceNetHealthStatus,performanceNow,parseMoney,primaryPurposeTags=[]
 }={}){
  if(typeof elementById!=='function'||typeof getCurrentSession!=='function'||typeof setCurrentSession!=='function')throw new Error('MISC Workspace Controller state/view dependencies are incomplete.');
  if(typeof normalizeSku!=='function'||typeof normalizeUpc!=='function'||!presentationController||!normalLookupController||typeof resolveProvider!=='function')throw new Error('MISC Workspace Controller lookup dependencies are incomplete.');
  if(!verificationService||!draftModel||!miscDomain||!workSessionService||typeof newId!=='function'||typeof sessionName!=='function'||typeof parseMoney!=='function'||typeof fileDelivery?.deliverBytes!=='function')throw new Error('MISC Workspace Controller workflow dependencies are incomplete.');
  const $=elementById,esc=escapeHtml,normalizeSKU=normalizeSku,normalizeUPC=normalizeUpc,ACEMisc=miscDomain,diag=typeof diagnostic==='function'?diagnostic:()=>{},nowMs=typeof performanceNow==='function'?performanceNow:()=>Date.now();
  let bulkRunning=false,upcSearchRunning=false;

  async function performAceMiscLookup(value,options={}){
   let mode=options.forceMode||getManualLookupMode();
   const raw=String(value??$('upc').value??'').trim();
   if(!options.forceMode&&mode==='UPC'&&/^\d{1,10}$/.test(raw)){const requestedMode=mode;setManualLookupMode('SKU');mode='SKU';diag('manual_lookup_mode_auto_corrected',{requestedMode,effectiveMode:mode,inputLength:raw.length,reason:'fewer_than_11_digits',workflow:'ACE_NEW_ITEMS_MISC'})}
   const key=mode==='SKU'?normalizeSKU(raw):normalizeUPC(raw);if(!key){$('status').textContent=`Enter ${mode==='SKU'?'a SKU':'or scan a UPC'} first.`;return}
   const lookupId=`ACE_MISC_LOOKUP:${Date.now()}:${Math.random().toString(36).slice(2,8)}`,span=diag.start?.({operationId:lookupId,function:'performAceMiscLookup',purpose:'Resolve an ACE MISC item through local catalog authority and AceNet only when required.',expected:'A single resolved item, explicit ambiguity/not-found result, or explicit failure is produced without silent fallback.',inputSummary:{identifier:key,identifierType:mode,format:options.format||null}}),presentationGeneration=presentationController.beginLookupPresentation(key,mode);
   clearLookupTransientPriceState(key);diag('ace_misc_lookup_started',{operationId:lookupId,spanId:span?.spanId,lookupId,key,identifierType:mode,format:options.format||null,masterFirst:true,localSecond:true,aceNetAfterLocalMiss:true,localLibraryWriteAllowed:true});
   const started=nowMs();let result,resolution=null;
   try{
    if(mode==='SKU'){resolution=await resolveProvider('ACE_MISC_MANUAL')(key,{relationshipSource:'ACENET_MISC_MANUAL'});result=resolution.item}
    else{
     result=await normalLookupController.lookupItem(key,options);diag('ace_misc_lookup_library_resolved',{lookupId,key,identifierType:mode,status:result.status,lookupMode:result.lookupMode,matches:result.matches,sku:result.sku||null,identityResolutionSource:result.identityResolutionSource||null,ms:Math.round(nowMs()-started)});
     if(result.status==='FOUND'&&result.sku){resolution=await resolveProvider('ACE_MISC_MANUAL_UPC')(result.sku,{relationshipSource:'ACENET_MISC_MANUAL'});result=resolution.item}
     else if(result.status==='NOT_FOUND'&&result.identityResolvedSku){resolution=await resolveProvider('ACE_MISC_MANUAL_UPC_RELATIONSHIP')(result.identityResolvedSku,{relationshipSource:'ACENET_MISC_MANUAL'});result=resolution.item}
    }
   }catch(e){presentationController.finishLookupPresentation(presentationGeneration);diag('ace_misc_lookup_failed',{operationId:lookupId,spanId:span?.spanId,lookupId,key,identifierType:mode,message:e?.message||String(e),ms:Math.round(nowMs()-started),localLibraryWriteAttempted:true});diag.error?.(span,e,{event:'ace_misc_lookup_span_failed',actual:'ACE MISC lookup failed before a usable terminal result.'});$('status').textContent=`ACE MISC lookup failed: ${e?.message||e}`;return}
   if(!presentationController.isCurrent(presentationGeneration)){diag('ace_misc_lookup_superseded',{operationId:lookupId,spanId:span?.spanId,lookupId,key});diag.success?.(span,{event:'ace_misc_lookup_span_superseded',actual:'Lookup result was superseded by a newer presentation generation.',result:'INCONCLUSIVE'});return}
   if(resolution?.upcVerification===ACEMisc.UPC_VERIFICATION.NEEDS_USER_CONFIRMATION&&result?.status==='FOUND'){await verificationService.confirmAceMiscKnownUpcs(result);resolution.upcVerification=draftModel.verificationState(result)}
   if(result.status==='IDENTITY_CONFLICT'){presentationController.finishLookupPresentation(presentationGeneration);presentationController.renderPreview({...result,status:'AMBIGUOUS'});if($('addToList'))$('addToList').disabled=true;$('upc').value=key;$('status').textContent='Item has an unresolved SKU conflict. Resolve the SKU conflict before ACE MISC lookup.';diag('ace_misc_identity_conflict_blocked_lookup',{operationId:lookupId,spanId:span?.spanId,lookupId,key,candidates:result.identityConflictCandidates||[]});diag.success?.(span,{event:'ace_misc_lookup_span_blocked',actual:'Lookup stopped at an explicit identity conflict.',result:'INCONCLUSIVE',details:{candidateCount:result.identityConflictCandidates?.length||0}});return}
   result.requestedIdentifierType=mode;presentationController.finishLookupPresentation(presentationGeneration);presentationController.renderPreview(result);
   const elapsed=Math.round(nowMs()-started),source=resolution?.source||'MASTER_LIBRARY_ONLY';diag('ace_misc_lookup_complete',{operationId:lookupId,spanId:span?.spanId,lookupId,key,identifierType:mode,status:result.status,lookupMode:result.lookupMode,matches:result.matches,sku:result.sku||null,upc:result.upc||null,source,aceNetUsed:Boolean(resolution?.aceNetUsed),upcCount:resolution?.upcs?.length||0,localPersisted:Boolean(resolution?.localPersisted),ms:elapsed});diag.success?.(span,{event:'ace_misc_lookup_span_completed',actual:`ACE MISC lookup completed with ${result.status}.`,result:result.status==='FOUND'?'PASS':'INCONCLUSIVE',details:{status:result.status,sku:result.sku||null,source,aceNetUsed:Boolean(resolution?.aceNetUsed),elapsedMs:elapsed}});
   $('upc').value=mode==='SKU'?(result.status==='FOUND'?String(result.sku||key):key):(result.status==='FOUND'?result.upc:key);
   if(result.status==='AMBIGUOUS')$('status').textContent=`Ambiguous ${mode}: ${result.matches} Master Library records match. No item was selected.`;
   else if(result.status==='NOT_FOUND')$('status').textContent='Item is not currently in Master Library, Local Library, or AceNet.';
   else if(draftModel.verificationState(result)===ACEMisc.UPC_VERIFICATION.VERIFIED_NO_ACENET_UPC_DATA)$('status').textContent='AceNet verified the SKU but provides no UPC selector data. Using the known Library UPC set for ACE MISC export.';
   else if(draftModel.verificationState(result)===ACEMisc.UPC_VERIFICATION.PENDING_ACENET)$('status').textContent='Item loaded from the local catalog. AceNet verification is pending; this item cannot be exported until its complete UPC set is verified.';
   else if(draftModel.verificationState(result)===ACEMisc.UPC_VERIFICATION.NEEDS_USER_CONFIRMATION)$('status').textContent='AceNet reported this SKU was not found. Confirm all known UPCs before exporting this item.';
   else if(draftModel.verificationState(result)===ACEMisc.UPC_VERIFICATION.USER_CONFIRMED_COMPLETE)$('status').textContent='AceNet reported this SKU was not found. The complete known UPC set was confirmed by the user.';
   else if(source.startsWith('LOCAL_LIBRARY'))$('status').textContent=source==='LOCAL_LIBRARY_FROM_ACENET'?'Item found in AceNet, saved to Local Library, and prepared for ACE MISC.':'Item refreshed from AceNet and prepared for ACE MISC.';
   else $('status').textContent='Item refreshed from AceNet and prepared for ACE MISC.';
  }

  function syncAceMiscBulkPreview(){const skus=draftModel.parseBulkSkus($('aceMiscBulkSkus')?.value||''),el=$('aceMiscBulkPreview');if(el)el.textContent=`${skus.length} unique SKU${skus.length===1?'':'s'}`;return skus}
  async function getOrCreateTodaysAceMiscList(){
   const name=`ACE New Items MISC. · ${sessionName()}`,lists=await workSessionService.list(),matches=lists.filter(x=>x?.sessionType==='ACE_NEW_ITEMS_MISC'&&x?.name===name).sort((a,b)=>String(b.updatedAt||'').localeCompare(String(a.updatedAt||'')));
   let list=matches[0],created=false;if(!list){const stamp=new Date().toISOString();list={id:newId(),name,createdAt:stamp,updatedAt:stamp,defaultTag:null,sessionType:'ACE_NEW_ITEMS_MISC',items:[],captures:[],promptLabelPriceAfterScan:false,autoAddPriceDifference:false};await workSessionService.create(list);created=true}
   if(!Array.isArray(list.items))list.items=[];if(matches.length>1)diag('ace_misc_bulk_multiple_daily_lists',{name,count:matches.length,selectedListId:list.id});return{list,created};
  }
  async function processAceMiscBulkSku(list,sku){
   const key=normalizeSKU(sku),existing=(list.items||[]).find(x=>normalizeSKU(x?.sku)===key);if(existing)return{sku:key,status:'SKIPPED_EXISTING',source:existing.aceMiscBulkSource||'EXISTING_LIST'};
   const resolved=await resolveProvider('ACE_MISC_BULK')(key,{relationshipSource:'ACENET_MISC_BULK'});if(resolved.status==='AMBIGUOUS')throw new Error('Master Library contains more than one record for this SKU.');
   const item=resolved.item,source=resolved.source,upcs=resolved.upcs||[];list.items.push(item);await workSessionService.save(list);if(getCurrentSession()?.id===list.id)setCurrentSession(list);return{sku:key,status:'ADDED',source,upcCount:upcs.length,itemId:item.id};
  }
  function renderAceMiscBulkResults(results){const host=$('aceMiscBulkResults');if(!host)return;host.classList.toggle('hidden',!results.length);host.innerHTML=results.map(r=>`<div class="aceMiscBulkResultRow"><strong>SKU ${esc(r.sku)}</strong><span>${esc(r.status==='ADDED'?`Added · ${String(r.source||'').startsWith('LOCAL_LIBRARY')?'Local Library':'Master Library'} · ${r.upcCount||0} UPC${r.upcCount===1?'':'s'}`:r.status==='SKIPPED_EXISTING'?'Already on today\'s list':`Failed · ${r.message||r.status}`)}</span></div>`).join('')}
  async function runAceMiscBulkImport(){
   if(bulkRunning)return;const skus=syncAceMiscBulkPreview();if(!skus.length){await messageUser('Paste at least one numeric Ace SKU first.','ACE MISC Bulk Import');return}
   const span=diag.start?.({function:'runAceMiscBulkImport',purpose:'Resolve and add a batch of ACE MISC SKUs.',expected:'Each SKU reaches ADDED, SKIPPED_EXISTING, or FAILED with aggregate totals persisted and presented.',inputSummary:{total:skus.length}});
   const state=getAceNetRuntimeState?.()||{},serviceHealth=normalizeAceNetHealthStatus?.(state.healthStatus);diag('ace_misc_bulk_resolution_authority',{operationId:span?.operationId,spanId:span?.spanId,healthStatus:serviceHealth,authenticated:state.authenticated===true,total:skus.length,policy:'MASTER_THEN_LOCAL_THEN_ACENET_IF_NEEDED'});
   const btn=$('aceMiscBulkRun'),box=$('aceMiscBulkProgressBox'),bar=$('aceMiscBulkProgress'),stage=$('aceMiscBulkStage'),detail=$('aceMiscBulkDetail');bulkRunning=true;if(btn)btn.disabled=true;if(box)box.classList.remove('hidden');
   const {list,created}=await getOrCreateTodaysAceMiscList(),results=[];diag('ace_misc_bulk_started',{listId:list.id,listName:list.name,listCreated:created,total:skus.length});
   try{
    for(let i=0;i<skus.length;i++){const sku=skus[i];if(stage)stage.textContent=`Processing ${i+1} of ${skus.length}`;if(detail)detail.textContent=`SKU ${sku}`;if(bar)bar.value=Math.round((i/skus.length)*100);try{results.push(await processAceMiscBulkSku(list,sku))}catch(e){results.push({sku,status:'FAILED',message:e?.message||String(e)});diag('ace_misc_bulk_item_failed',{listId:list.id,sku,index:i,total:skus.length,message:e?.message||String(e)})}renderAceMiscBulkResults(results)}
    if(bar)bar.value=100;const added=results.filter(x=>x.status==='ADDED').length,skipped=results.filter(x=>x.status==='SKIPPED_EXISTING').length,failed=results.filter(x=>x.status==='FAILED').length;if(stage)stage.textContent='Complete';if(detail)detail.textContent=`${added} added · ${skipped} skipped · ${failed} failed`;await refreshSavedLists();diag('ace_misc_bulk_complete',{operationId:span?.operationId,spanId:span?.spanId,listId:list.id,total:skus.length,added,skipped,failed,listCreated:created});diag.success?.(span,{event:'ace_misc_bulk_span_completed',actual:`Bulk import completed: ${added} added, ${skipped} skipped, ${failed} failed.`,result:failed?'INCONCLUSIVE':'PASS',details:{listId:list.id,total:skus.length,added,skipped,failed}});
   }catch(e){diag.error?.(span,e,{event:'ace_misc_bulk_span_failed',actual:'ACE MISC bulk import aborted unexpectedly.'});throw e}finally{bulkRunning=false;if(btn)btn.disabled=false}
  }
  function aceMiscSetUpcSearchBusy(busy,message=''){upcSearchRunning=Boolean(busy);const btn=$('aceMiscSearchUpcs'),exp=$('exportPackage'),view=$('viewItems'),status=$('aceMiscUpcSearchStatus');if(btn){btn.disabled=upcSearchRunning;btn.textContent=upcSearchRunning?'Searching AceNet…':'Search for Additional UPCs'}if(exp)exp.disabled=upcSearchRunning;if(view)view.disabled=upcSearchRunning;if(status){status.textContent=message;status.classList.toggle('hidden',!message)}}
  async function aceMiscSearchAdditionalUpcs(){
   const current=getCurrentSession();if(verificationService.isRetryRunning()||current?.sessionType!=='ACE_NEW_ITEMS_MISC')return;
   const pendingCount=(current.items||[]).filter(item=>!draftModel.verificationComplete(item)).length;if(!pendingCount){aceMiscSetUpcSearchBusy(false,'All ACE MISC items already have complete UPC verification.');return}
   aceMiscSetUpcSearchBusy(true,`Verifying ${pendingCount} ACE MISC item${pendingCount===1?'':'s'} with AceNet…`);
   try{const result=await verificationService.retryPendingAceMiscVerification(current,{promptNotFound:true});aceMiscSetUpcSearchBusy(false,`Checked ${result.checked} pending item${result.checked===1?'':'s'} · ${result.completed} completed · ${result.pending} still pending.`);if(result.pending)await messageUser(`${result.pending} ACE MISC item${result.pending===1?'':'s'} still require complete UPC verification before export.`,'ACE MISC UPC Verification')}
   catch(e){aceMiscSetUpcSearchBusy(false,`Verification failed: ${e?.message||e}`);diag('ace_misc_additional_upcs_failed',{listId:current.id,message:e?.message||String(e),result:'FAILED'});await messageUser(`ACE MISC verification failed: ${e?.message||e}`,'ACE MISC UPC Verification')}
  }
  async function exportCurrent(){
   const current=getCurrentSession(),span=diag.start?.({function:'exportCurrent',purpose:'Verify and export the current ACE MISC work session.',expected:'All items satisfy UPC verification requirements and a compatible export is generated.',inputSummary:{listId:current?.id||null,itemCount:current?.items?.length||0}});
   try{await verificationService.ensureAceMiscExportReady(current);const payload=await ACEMisc.exportList(current),out={name:payload.name,rowCount:payload.rowCount};fileDelivery.deliverBytes(payload.bytes,payload.name,payload.mime);diag('ace_misc_export_requested',{operationId:span?.operationId,spanId:span?.spanId,...out});diag.success?.(span,{event:'ace_misc_export_span_completed',actual:'ACE MISC export was generated and handed to the platform export path.',details:out});$('status').textContent=`Exported ${out.name}`;return out}
   catch(e){diag('ace_misc_export_failed',{operationId:span?.operationId,spanId:span?.spanId,message:e?.message||String(e)});diag.error?.(span,e,{event:'ace_misc_export_span_failed',actual:'ACE MISC export was blocked or failed.'});await messageUser(`ACE MISC. export blocked: ${e?.message||e}`,'ACE MISC Export');return null}
  }
  function findDuplicate(item){
   const current=getCurrentSession();if(current?.sessionType!=='ACE_NEW_ITEMS_MISC'||!item)return null;
   const sku=normalizeSKU(item.sku),upc=normalizeUPC(item.upc||'');
   return current.items.find(x=>(sku&&normalizeSKU(x.sku)===sku)||(upc&&normalizeUPC(x.upc||'')===upc))||null;
  }
  async function syncCurrentSnapshot(sku,snapshot){
   const current=getCurrentSession();if(current?.sessionType!=='ACE_NEW_ITEMS_MISC'||!Array.isArray(current.items))return false;let changed=false;
   current.items=current.items.map(item=>{if(normalizeSKU(item?.sku)!==normalizeSKU(sku)||item?.aceMiscSnapshot?.source==='MASTER_LIBRARY_PLUS_ACENET_UPCS')return item;const next={...item};if(!draftModel.applySnapshot(next,snapshot))return item;changed=true;return next});
   if(changed)await workSessionService.save(current);return changed;
  }
  async function addPendingItem(pending,{labelPrice=''}={}){
   const current=getCurrentSession();if(current?.sessionType!=='ACE_NEW_ITEMS_MISC'||!pending)throw new Error('ACE MISC item add requires an active MISC session.');
   const duplicate=findDuplicate(pending);if(duplicate)return{status:'DUPLICATE',duplicate};
   const stamp=new Date().toISOString(),libraryPrice=parseMoney(pending.price),aceNetPrice=parseMoney(pending.aceNetPrice),label=String(labelPrice??'').trim(),parsedLabel=label===''?null:parseMoney(label);
   const item={...pending,id:newId(),addedAt:stamp,scannedAt:stamp,tags:[],primaryPurpose:null,supplementalPurposes:[],libraryPrice,aceNetPrice,labelPrice:parsedLabel,priceDifference:(libraryPrice!=null&&parsedLabel!=null)?Math.round((parsedLabel-libraryPrice)*100)/100:null};
   current.items.push(item);await workSessionService.save(current);setCurrentSession(current);diag('ace_misc_item_added',{listId:current.id,itemId:item.id,sku:item.sku||null,upc:item.upc||null,count:current.items.length});return{status:'ADDED',item,count:current.items.length};
  }
  async function editItemField(index,key,raw){
   const current=getCurrentSession(),item=current?.items?.[index];if(current?.sessionType!=='ACE_NEW_ITEMS_MISC'||!item)throw new Error('ACE MISC item edit requires an active MISC item.');
   const before=key==='duplicateItem'?((item.tags||[]).includes('Duplicate Item')?'Yes':'No'):key==='primaryPurpose'?(item.primaryPurpose||''):(item[key]??'');
   if(key==='primaryPurpose'){const allowed=Array.isArray(primaryPurposeTags)?primaryPurposeTags:[];item.primaryPurpose=allowed.includes(raw)?raw:null;item.tags=(item.tags||[]).filter(tag=>!allowed.includes(tag));if(item.primaryPurpose)item.tags.unshift(item.primaryPurpose)}
   else if(key==='duplicateItem'){item.tags=(item.tags||[]).filter(tag=>tag!=='Duplicate Item');if(String(raw)==='Yes')item.tags.push('Duplicate Item')}
   else if(!draftModel.applyUserEdit(item,key,raw))throw new Error(`ACE MISC field ${key} is not editable through the canonical draft.`);
   await workSessionService.save(current);setCurrentSession(current);const after=key==='duplicateItem'?((item.tags||[]).includes('Duplicate Item')?'Yes':'No'):key==='primaryPurpose'?(item.primaryPurpose||''):(item[key]??'');diag('ace_misc_item_edited',{listId:current.id,index,itemId:item.id,sku:item.sku||null,field:key,before,after});return{item,before,after};
  }
  async function removeItem(index){
   const current=getCurrentSession();if(current?.sessionType!=='ACE_NEW_ITEMS_MISC'||index<0||index>=current.items.length)throw new Error('ACE MISC item removal requires an active MISC item.');
   const [removed]=current.items.splice(index,1);await workSessionService.save(current);setCurrentSession(current);diag('ace_misc_item_removed',{listId:current.id,index,itemId:removed?.id||null,sku:removed?.sku||null,upc:removed?.upc||null,count:current.items.length});return removed;
  }
  function bind({on}={}){if(typeof on!=='function')throw new Error('MISC Workspace Controller requires the shared event binder.');on('aceMiscBulkSkus','input',syncAceMiscBulkPreview);on('aceMiscBulkRun','click',runAceMiscBulkImport);on('aceMiscSearchUpcs','click',aceMiscSearchAdditionalUpcs);syncAceMiscBulkPreview()}
  return Object.freeze({performLookup:performAceMiscLookup,bind,exportCurrent,findDuplicate,addPendingItem,editItemField,removeItem,syncCurrentSnapshot,syncBulkPreview:syncAceMiscBulkPreview,searchAdditionalUpcs:aceMiscSearchAdditionalUpcs});
 }
 return Object.freeze({create});
})();
window.UPCMiscWorkspaceController=UPCMiscWorkspaceController;
