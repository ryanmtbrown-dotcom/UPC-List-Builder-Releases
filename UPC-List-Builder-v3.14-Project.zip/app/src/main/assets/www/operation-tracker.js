/*
 * OWNERSHIP:
 * File: app/src/main/assets/www/operation-tracker.js
 * Owner: Shared Operation Lifecycle
 * Role: Pure in-memory state utility
 * Responsibility: Owns generic start/observe/finish timing state used by diagnostics operation adapters.
 * Does not own: Domain event names; persistence; business success decisions; UI.
 * Side effects: In-memory maps and timing only; no durable or platform side effects.
 * Related code: Diagnostic semantics belong to diagnostics/diagnostic-operation-service.js.
 */
const UPCOperationTracker=(()=>{
 function create(options={}){
  const states=new Map(),now=typeof options.now==='function'?options.now:()=>Math.round(performance.now()),reuseActive=options.reuseActive===true,retainCompleted=options.retainCompleted===true;
  function currentMs(){const value=Number(now());return Number.isFinite(value)?value:0}
  function start(id,metadata={}){
   const existing=states.get(id);
   if(reuseActive&&existing&&!existing.completed)return{state:existing,reused:true};
   const state={id,...metadata,startedMs:currentMs(),completed:false};
   states.set(id,state);return{state,reused:false};
  }
  function observe(id){
   const state=states.get(id)||null;
   return{state,durationMs:state?Math.max(0,currentMs()-state.startedMs):null};
  }
  function finish(id){
   const state=states.get(id);
   if(!state)return{state:null,durationMs:null,missing:true,duplicate:false};
   if(state.completed)return{state,durationMs:Math.max(0,(state.finishedMs??state.startedMs)-state.startedMs),missing:false,duplicate:true};
   state.completed=true;state.finishedMs=currentMs();
   const durationMs=Math.max(0,state.finishedMs-state.startedMs);
   if(!retainCompleted)states.delete(id);
   return{state,durationMs,missing:false,duplicate:false};
  }
  function peek(id){return states.get(id)||null}
  return Object.freeze({start,observe,finish,peek});
 }
 return Object.freeze({create});
})();
window.UPCOperationTracker=UPCOperationTracker;
