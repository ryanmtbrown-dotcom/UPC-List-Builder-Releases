# Web Platform Directory Ownership

OWNS: web/native callback registration, browser/PWA installation lifecycle, standard application file-delivery adaptation, and small platform policy adapters.

STANDARD FILE DELIVERY: `file-export-delivery-service.js` is the sole web owner for ordinary application export delivery. Domain/application export owners prepare validated bytes or text plus filename/MIME metadata; this adapter selects the existing `AndroidNative.exportFile` capability or the browser Blob-download fallback.

DOES NOT OWN: Android implementation, business lookup/catalog rules, persistence, domain export composition, diagnostic-specific export semantics, or domain UI.

BOUNDARY RULE: all global native callbacks register through the single bridge-registration surface; AceNet startup/health callbacks route to the focused AceNet Startup Service rather than ad-hoc globals or DOM events; browser-only service-worker/install behavior stays isolated from Android update/install authority; ordinary feature exporters must not implement their own native/browser download primitive.
