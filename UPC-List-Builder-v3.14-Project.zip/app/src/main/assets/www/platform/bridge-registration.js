/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/platform/bridge-registration.js
 * Owner: Web/Native Bridge Registration
 * Role: Platform adapter
 * Responsibility: Owns one-time registration of native-to-web callback families and dispatch to their focused web consumers.
 * Does not own: Native implementation, business processing, persistence, or creation of parallel callback globals.
 * Side effects: Assigns the approved global callback entry points once during composition.
 * Related code: MainActivity owns AndroidNative interface composition; callback consumers remain their domain owners.
 */
const UPCBridgeRegistration=(()=>{
 function register({
  windowRef,aceNetClient,productImageService,scannerController,aceNetDiagnosticService,aceNetStartupService,
  startupOrchestrator,updateStatusService,diagnosticExportService
 }={}){
  if(!windowRef||!aceNetClient||!productImageService||!scannerController||!aceNetDiagnosticService||!aceNetStartupService||!startupOrchestrator||!updateStatusService||!diagnosticExportService)throw new Error('Bridge Registration dependencies are incomplete.');
  const routes={
   UPCNativeAceNetPriceResult:raw=>aceNetClient.acceptPriceResult(raw),
   UPCNativeAceNetCatalogResult:raw=>aceNetClient.acceptCatalogResult(raw),
   UPCNativeAceNetUpcResult:raw=>aceNetClient.acceptUpcsResult(raw),
   UPCNativeProductImageResult:raw=>productImageService.acceptNativeProductImageResult(raw),
   UPCNativeScannerResult:payload=>scannerController.acceptNativeResult(payload),
   UPCNativeScannerCancelled:()=>scannerController.acceptNativeCancelled(),
   UPCNativeAceNetDiagnostic:raw=>aceNetDiagnosticService.accept(raw),
   UPCNativeAceNetStartupStatus:raw=>aceNetStartupService.acceptNativeStartupStatus(raw),
   UPCNativeAceNetHealthStatus:raw=>aceNetStartupService.acceptNativeHealthStatus(raw),
   UPCNativeUpdateLifecycle:raw=>startupOrchestrator.acceptUpdateLifecycle(raw),
   UPCNativeUpdateStatus:message=>updateStatusService.acceptNativeStatus(message),
   UPCNativeDiagnosticExportStatus:message=>diagnosticExportService.acceptNativeExportStatus(message),
   UPCNativeDiagnosticExportTransferEvent:payload=>diagnosticExportService.acceptNativeExportTransferEvent(payload)
  };
  for(const [name,handler] of Object.entries(routes))windowRef[name]=handler;
  return Object.freeze({names:Object.freeze(Object.keys(routes)),unregister(){for(const name of Object.keys(routes))if(windowRef[name]===routes[name])delete windowRef[name]}});
 }
 return Object.freeze({register});
})();
window.UPCBridgeRegistration=UPCBridgeRegistration;
