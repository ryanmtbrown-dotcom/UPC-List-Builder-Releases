/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/platform/file-export-delivery-service.js
 * Owner: Web File Export Delivery
 * Role: Platform adapter
 * Responsibility: Owns ordinary application file delivery through AndroidNative.exportFile or the browser download fallback.
 * Does not own: Domain export composition, filenames/content semantics, diagnostic-specific export, or native filesystem implementation.
 * Side effects: May call the injected native export bridge or create/click/revoke a temporary browser Blob URL.
 * Related code: Domain export owners prepare bytes; NativeFileExportService owns Android file writing; diagnostic export remains specialized.
 */
const UPCFileExportDeliveryService=(()=>{
 function create({bridgeProvider,documentRef,urlApi,blobCtor,base64Encoder,setTimeoutFn,textEncoder}={}){
  if(typeof bridgeProvider!=='function'||!documentRef||!urlApi||typeof blobCtor!=='function'||typeof base64Encoder!=='function'||!textEncoder||typeof textEncoder.encode!=='function')throw new Error('File Export Delivery Service dependencies are incomplete.');
  const delay=typeof setTimeoutFn==='function'?setTimeoutFn:setTimeout;
  function bytesToBase64(bytes){
   const payload=bytes instanceof Uint8Array?bytes:new Uint8Array(bytes||[]);let binary='';
   for(let i=0;i<payload.length;i+=0x8000)binary+=String.fromCharCode(...payload.subarray(i,i+0x8000));
   return base64Encoder(binary);
  }
  function deliverBytes(bytes,filename,mime='application/octet-stream'){
   const payload=bytes instanceof Uint8Array?bytes:new Uint8Array(bytes||[]),name=String(filename||'').trim();
   if(!name)throw new Error('Export filename is required.');
   const bridge=bridgeProvider();
   if(bridge?.exportFile){bridge.exportFile(bytesToBase64(payload),name,mime);return{platform:'native',filename:name,byteCount:payload.length}}
   const blob=new blobCtor([payload],{type:mime}),a=documentRef.createElement('a'),url=urlApi.createObjectURL(blob);
   a.href=url;a.download=name;documentRef.body.appendChild(a);a.click();a.remove();delay(()=>urlApi.revokeObjectURL(url),1500);
   return{platform:'browser',filename:name,byteCount:payload.length};
  }
  function deliverText(text,filename,mime='text/plain'){return deliverBytes(textEncoder.encode(String(text??'')),filename,mime)}
  return Object.freeze({deliverBytes,deliverText});
 }
 return Object.freeze({create});
})();
window.UPCFileExportDeliveryService=UPCFileExportDeliveryService;
