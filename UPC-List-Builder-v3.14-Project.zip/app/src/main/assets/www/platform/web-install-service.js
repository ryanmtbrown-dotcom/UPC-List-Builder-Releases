/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/platform/web-install-service.js
 * Owner: Browser/PWA Platform
 * Role: Lifecycle service
 * Responsibility: Owns browser-only service-worker registration/update checks and install-prompt/app-installed lifecycle.
 * Does not own: Android updater/install flow, application business state, release publication, or persistence.
 * Side effects: Registers browser service worker/listeners and an update interval; owns those browser hooks.
 * Related code: service-worker.js owns cache handling; Android update behavior belongs to AppUpdateService.
 */
const UPCWebInstallService=(()=>{
 function create({elementById,windowRef,navigatorRef,diagnostic,nativeBridgeProvider,setIntervalFn}={}){
  if(typeof elementById!=='function'||!windowRef||!navigatorRef||typeof diagnostic!=='function'||typeof nativeBridgeProvider!=='function')throw new Error('Web Install Service dependencies are incomplete.');
  const $=elementById,diag=diagnostic,repeat=typeof setIntervalFn==='function'?setIntervalFn:setInterval;let installPrompt=null;
  function bindInstallPrompt(){
   windowRef.addEventListener('beforeinstallprompt',e=>{e.preventDefault();installPrompt=e;$('installApp')?.classList.remove('hidden');diag('install_prompt_available')});
   const install=$('installApp');if(install)install.onclick=async()=>{if(!installPrompt)return;installPrompt.prompt();diag('install_prompt_result',await installPrompt.userChoice);installPrompt=null;install.classList.add('hidden')};
   windowRef.addEventListener('appinstalled',()=>diag('app_installed'));
  }
  function registerServiceWorker(){
   try{
    if(nativeBridgeProvider()||!('serviceWorker'in navigatorRef)||!navigatorRef.serviceWorker)return false;
    if(typeof navigatorRef.serviceWorker.addEventListener==='function')navigatorRef.serviceWorker.addEventListener('controllerchange',()=>diag('service_worker_controller_changed',{reloadSuppressed:true}));
    windowRef.addEventListener('load',async()=>{try{
     const reg=await navigatorRef.serviceWorker.register('/service-worker.js',{updateViaCache:'none'});await reg.update();if(reg.waiting)reg.waiting.postMessage({type:'SKIP_WAITING'});
     reg.addEventListener?.('updatefound',()=>{const worker=reg.installing;if(worker)worker.addEventListener?.('statechange',()=>{if(worker.state==='installed'&&navigatorRef.serviceWorker.controller){diag('service_worker_update_installed',{activation:'next-safe-launch'});worker.postMessage({type:'SKIP_WAITING'})}})});
     repeat(()=>reg.update().catch(()=>{}),15*60*1000);
    }catch(e){diag('service_worker_error',{name:e?.name,message:e?.message,stack:e?.stack})}});
    return true;
   }catch(e){diag('service_worker_setup_error',{name:e?.name,message:e?.message,stack:e?.stack});return false}
  }
  function start(){bindInstallPrompt();registerServiceWorker()}
  return Object.freeze({start,bindInstallPrompt,registerServiceWorker});
 }
 return Object.freeze({create});
})();
window.UPCWebInstallService=UPCWebInstallService;
