# Pricing Directory Ownership

OWNS: shared pure pricing/value primitives and authoritative Level 2 Retail source selection for Ace merchandise, independent of a feature workflow.

DOES NOT OWN: AceNet price retrieval, price authority selection, presentation, persistence, or catalog refresh.

RULE: keep this directory side-effect free.
