/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/pricing/money-value.js
 * Owner: Shared Pricing Primitive
 * Role: Pure value utility
 * Responsibility: Owns small canonical money parsing/formatting/value helpers shared across features.
 * Does not own: Price authority, retrieval, persistence, UI, or currency policy beyond its explicit primitive contract.
 * Side effects: None; pure value operations.
 * Related code: Feature pricing policy stays with lookup/catalog/domain owners.
 */
const UPCMoneyValue=Object.freeze({
 parse(value){if(value==null||value==='')return null;const parsed=Number(String(value).replace(/[^0-9.-]/g,''));return Number.isFinite(parsed)?parsed:null}
});
window.UPCMoneyValue=UPCMoneyValue;
