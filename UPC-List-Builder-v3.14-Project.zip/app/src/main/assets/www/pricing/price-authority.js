/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/pricing/price-authority.js
 * Owner: Price Authority
 * Role: Pure pricing-source selector
 * Responsibility: Selects authoritative Level 2 Retail for Ace merchandise, preserving independent Ace Retail and user label values.
 * Does not own: Persistence, native extraction, catalog mutation, Work Session membership, or presentation.
 * Side effects: None.
 * Related code: Lookup mapping, saved-list rendering, and Field Session export consume the same selector.
 */
const UPCPriceAuthority=(()=>{
 const value=(fields,header)=>{const key=Object.keys(fields||{}).find(k=>k.trim().toLowerCase()===header.toLowerCase());return key===undefined?null:fields[key]};
 const money=raw=>{if(raw===null||raw===undefined||String(raw).trim()==='')return null;const text=String(raw).trim().replace(/[$,]/g,'');if(!/^(?:\d+)(?:\.\d{1,2})?$/.test(text))return null;const n=Number(text);return Number.isFinite(n)&&n>=0?n.toFixed(2):null};
 function level2(fields){return money(value(fields,'Level 2 Retail Price'))}
 function sourcePrice(fields,recordOrigin){return recordOrigin==='THIRD_PARTY_VENDOR'?money(value(fields,'Ace Retail Price')??value(fields,'Retailer Each Price')??value(fields,'Price')):level2(fields)}
 const VERIFIED_ACENET_SOURCE='LEVEL2_STORE_RETAIL';
 function observedAceNetPrice(item){
  if(item?.aceNetPriceAuthority!==VERIFIED_ACENET_SOURCE)return null;
  const verified=money(item.aceNetPrice);
  return verified===null?null:Number(verified);
 }
 function observedPrice(item){
  if(!item)return null;
  // Current, exact-SKU AceNet Store Retail (Level 2) wins over the older
  // offline Master/ACE_DERIVED snapshot, but never over independent vendor authority.
  if(item.recordOrigin!=='THIRD_PARTY_VENDOR'){
   const live=observedAceNetPrice(item);
   if(live!==null)return live;
  }
  const direct=sourcePrice(item.fields||{},item.recordOrigin);
  if(direct!==null)return Number(direct);
  // Historical Ace-derived observations may have saved Ace Retail as libraryPrice.
  // Do not reinterpret it as Level 2 when verified evidence is unavailable.
  if(item.recordOrigin==='THIRD_PARTY_VENDOR')return money(item.libraryPrice??item.price)===null?null:Number(money(item.libraryPrice??item.price));
  return null;
 }
 return Object.freeze({level2,sourcePrice,observedPrice,observedAceNetPrice,VERIFIED_ACENET_SOURCE,money});
})();
window.UPCPriceAuthority=UPCPriceAuthority;
