# Scanner Web Directory Ownership

OWNS: scanner web UI lifecycle and routing accepted scan results to the correct workspace/lookup entry point.

DOES NOT OWN: native camera implementation, UPC lookup policy, DSD business rules, or catalog persistence.

BOUNDARY: native scanner output is normalized/accepted here, then handed to Scanner Workspace Router for workflow selection.
