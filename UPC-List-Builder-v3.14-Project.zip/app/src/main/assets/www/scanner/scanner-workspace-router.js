/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/scanner/scanner-workspace-router.js
 * Owner: Scanner Workflow Routing
 * Role: Router
 * Responsibility: Owns routing an accepted normalized scan into DSD or ordinary lookup/manual workflow according to active workspace.
 * Does not own: Camera lifecycle, identifier normalization rules, lookup policy, persistence, or presentation.
 * Side effects: Invokes injected DSD/manual/lookup entry points only.
 * Related code: Scanner acquisition belongs to Scanner Controller/Activity; lookup behavior belongs to target owner.
 */
const UPCScannerWorkspaceRouter=(()=>{
 function create({normalizeUpc,navigationProvider,getCurrentSession,dsdType,dsdWorkspaceProvider,manualIdentifierController,elementById,lookupRouter,locationWorkProvider=null,explorerProvider=null}={}){
  if(typeof normalizeUpc!=='function'||typeof navigationProvider!=='function'||typeof getCurrentSession!=='function'||typeof dsdWorkspaceProvider!=='function')throw new Error('Scanner Workspace Router state dependencies are incomplete.');
  if(!manualIdentifierController||typeof elementById!=='function'||!lookupRouter)throw new Error('Scanner Workspace Router workflow dependencies are incomplete.');
  const $=elementById;
  async function accept({upc,displayValue=upc,format=null,promptLabelPriceOnSkuChange=true}={}){
   const normalized=normalizeUpc(upc);if(!normalized)return;
   // Explicit active location work consumes genuine accepted scans only.
   if(locationWorkProvider?.()?.active?.())return locationWorkProvider().onAcceptedScan({upc:normalized,format});
   if(explorerProvider?.()?.active?.())return explorerProvider().onAcceptedScan({upc:normalized,format});
   if(navigationProvider().currentScreen()==='dsdScreen'&&getCurrentSession()?.sessionType===dsdType){dsdWorkspaceProvider().acceptScannedUpc(normalized);return}
   manualIdentifierController.setMode('UPC');const input=$('upc');if(input)input.value=displayValue||normalized;
   return lookupRouter.perform(displayValue||normalized,{forceMode:'UPC',format,promptLabelPriceOnSkuChange});
  }
  return Object.freeze({accept});
 }
 return Object.freeze({create});
})();
window.UPCScannerWorkspaceRouter=UPCScannerWorkspaceRouter;
