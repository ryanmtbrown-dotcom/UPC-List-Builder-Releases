# Store Locations — Builds 1 and 2

**Authority:** One current accepted physical arrangement per modular; independent current Ace source records and bounded last-known factual associations.

**Build 1 owners:** `location-policy.js` (identity/position and compact location rules), `location-repository.js` (seven existing IndexedDB location stores), `location-lookup-service.js`, `location-maintenance-controller.js`, and planogram import modules. `db.js` alone owns the raw schema, and `data-backup.js` owns the full atomic backup and restore.

**Build 2 proposed owners:** `location-work-policy.js` (pure scoped comparisons), `location-work-service.js` (recovery/approval), `location-work-controller.js` (guided employee UI) `location-work.css` (theme-scoped presentation), and `location-work-feature.js` (feature assembly, injected by the application shell). Existing `meta` storage carries one recoverable transient draft, not a competing store. The existing `scanner-workspace-router.js` invokes the work controller only for an accepted barcode scan while physical work is explicitly active.

**Provenance:** The official source report remains untouched by physical builder/audit. Employee observations are separate from source coordinates, and an item may be in the store without being part of Ace's original source membership. Unfinished audits do not produce missing-item findings. Removed store-added placements retain bounded last-known physical association.

**Out of scope:** Passive observations during ordinary scanning, cloud synchronization, label condition inventory, separate Research system, historical scanner activity log, and planogram PDF parsing by the phone.

**Release status:** v3.09 is a Build 2 candidate. It is not approved for production release. Current v3.08 remains the installed reference/rollback until full verification and user authorization.

## v3.10 Explorer
`location-explorer-policy.js` owns pure evidence-scoped sequences and proposed small-scope edits. `location-explorer-service.js` reads current indexed location + offline catalog evidence. `location-explorer-edit-service.js` invokes existing atomic guarded acceptance, not a competing store. `location-explorer-controller.js` and `location-explorer.css` own the employee view, and `location-explorer-feature.js` assembles dependencies. The existing physical layout draft workflow is reused for scans with no known location; no passive scan ledger, direct Ace source rewrite, or new IndexedDB store is permitted.
