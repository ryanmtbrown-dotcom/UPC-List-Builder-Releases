/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/store-locations/location-explorer-edit-service.js
 * Owner: Store Locations / Explorer Correction Service
 * Role: Domain transaction coordinator
 * Responsibility: Prepare, confirm and atomically commit narrowly scoped physical placement corrections with revision/secondary guards.
 * Does not own: Raw IndexedDB, product catalog writes, Ace source interpretation, UI or scanner events.
 * Side effects: Calls existing location-repository atomic accept and explicit source-member exclusion only when requested.
 * Related code: location-explorer-policy.js, location-repository.js, location-explorer-controller.js.
 */
const UPCLocationExplorerEditService=(()=>{
 'use strict';
 function create({repository,policy,workPolicy,idFactory}={}){
  if(!repository||!policy||!workPolicy||typeof idFactory!=='function')throw Error('Explorer editing dependencies missing');
  async function snapshot(modularId){
   const [baseline,sources]=await Promise.all([repository.listPlacements(modularId),repository.listSourcesForModular(modularId)]);
   return{modularId,baseline,fingerprint:workPolicy.fingerprint(baseline),signature:repository.sourceSignature(sources)};
  }
  async function prepare(modularId,action,args={}){
   const modular=await repository.getModular(modularId);if(!modular||modular.active===false)throw Error('Inactive display cannot be edited');
   const before=await snapshot(modularId);
   const proposal=policy.propose({baseline:before.baseline,modular,action,idFactory,...args});
   if(!proposal.changed.length&&!proposal.removed.length)throw Error('No position change to save');
   return{...before,...proposal,action};
  }
  async function commit(prepared,approvedSecondaryIds=[]){
   const approved=new Set(approvedSecondaryIds);
   const placements=prepared.placements.map(p=>{
    if(!prepared.requiresSecondary.some(x=>x.id===p.id))return p;
    if(!approved.has(p.id))throw Error('Separate stocked location needs confirmation for its exact new position');
    return{...p,approvedException:{placementId:p.id,skuKey:p.skuKey||null,physicalSectionId:p.physicalSectionId??null,
     rowOrdinal:p.rowOrdinal??null,observedOrder:p.observedOrder??null,confirmedAt:Date.now()}};
   });
   const result=await repository.approvePhysicalLayout({modularId:prepared.modularId,items:placements,
    expectedFingerprint:prepared.fingerprint,expectedSourceSignature:prepared.signature});
   return{...result,focusId:prepared.focusId,undo:{modularId:prepared.modularId,baseline:placements,
    fingerprint:workPolicy.fingerprint(placements),signature:prepared.signature,placements:prepared.baseline}};
  }
  async function undo(record){
   if(!record)throw Error('Nothing to undo');
   const result=await repository.approvePhysicalLayout({modularId:record.modularId,items:record.placements,
    expectedFingerprint:record.fingerprint,expectedSourceSignature:record.signature});
   return result;
  }
  return Object.freeze({snapshot,prepare,commit,undo});
 }
 return Object.freeze({create});
})();
