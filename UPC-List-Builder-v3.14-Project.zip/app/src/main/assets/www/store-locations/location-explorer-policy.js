/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/store-locations/location-explorer-policy.js
 * Owner: Store Locations / Explorer Ordering and Correction Policy
 * Role: Pure domain policy
 * Responsibility: Deterministic evidence-scoped traversal and localized physical correction proposals.
 * Does not own: IndexedDB, Ace catalog, source PDF interpretation, DOM, scanner or Work Sessions.
 * Side effects: None.
 * Related code: location-explorer-service.js, location-explorer-edit-service.js, STORE_LOCATION_CONTRACT.md.
 */
const UPCLocationExplorerPolicy=(()=>{
 'use strict';
 const key=p=>p?.skuKey?'SKU:'+p.skuKey:p?.upcKey?'UPC:'+p.upcKey:null;
 const same=(a,b)=>key(a)!=null&&key(a)===key(b)||!!a?.upcKey&&a.upcKey===b?.upcKey;
 const num=(x)=>{const n=Number(x);return Number.isFinite(n)&&n>=0?n:1e9};
 const sectionIndex=(p,modular)=>{const i=(modular.physicalSectionIds||[]).map(String).indexOf(String(p.physicalSectionId));return i>=0?i:1e9};
 const physicalSort=(modular)=>(a,b)=>sectionIndex(a,modular)-sectionIndex(b,modular)||num(a.rowOrdinal)-num(b.rowOrdinal)||num(a.observedOrder)-num(b.observedOrder)||num(a.columnOrdinal)-num(b.columnOrdinal)||String(a.id).localeCompare(String(b.id));
 const segment=(p)=>{const m=String(p.sourceSegment??'').match(/(\d+)$/);return m?Number(m[1]):1e9};
 const sourceSort=(a,b)=>segment(a)-segment(b)||num(a.sourceRow)-num(b.sourceRow)||num(a.sourceColumn)-num(b.sourceColumn)||String(a.id).localeCompare(String(b.id));
 const sourceEntries=(member,source)=>(member.positions?.length?member.positions:[{}]).map((p,i)=>({id:'source-member:'+source.id+':'+(member.skuKey||member.upcKey)+':'+i,modularId:source.modularId,skuKey:member.skuKey||null,upcKey:member.upcKey||null,sourceSegment:p.sourceSegment??null,sourceRow:p.sourceRow??null,sourceColumn:p.sourceColumn??null,fixtureType:p.fixtureType||'UNKNOWN',sourceName:source.name||source.planogramId,sourceOnly:true,ambiguousPosition:p.sourceRow==null||p.sourceColumn==null}));
 function ordered({modular,placements=[],source=null,sourceMembers=[],mode='STORE'}={}){
  if(mode==='STORE')return placements.filter(x=>x.physicalEvidence===true).sort(physicalSort(modular));
  if(!source)return [];
  return sourceMembers.filter(m=>m.notPlaced!==true).flatMap(m=>sourceEntries(m,source)).sort(sourceSort);
 }
 const position=p=>p?.sourceOnly?('Ace'+(p.sourceSegment?' · Source segment '+p.sourceSegment:'')+(p.sourceRow?' · Source row '+p.sourceRow:'')+(p.sourceColumn?' · Source col '+p.sourceColumn:'')+(p.ambiguousPosition?' · Order not verified':'')):
  (p?.physicalSectionId?'SEC '+p.physicalSectionId:'Custom fixture')+' · '+(p?.fixtureType==='SHELF'?'Shelf ':'Row ')+(p?.rowOrdinal??'not recorded')+(p?.observedOrder?' · Order '+p.observedOrder:'')+(p?.facings?' · '+p.facings+' facings':'');
 const isExactPosition=(p)=>p?.physicalEvidence===true&&Number.isInteger(p.rowOrdinal)&&Number.isInteger(p.observedOrder);
 const MAX=500;
 function propose({baseline=[],modular,action,targetId,anchorId=null,identity=null,section=null,row=null,facings=null,idFactory}={}){
  const all=baseline.map(p=>({...p})),target=all.find(p=>p.id===targetId),anchor=all.find(p=>p.id===anchorId);
  if(!modular||!['INSERT_BEFORE','INSERT_AFTER','MOVE_BEFORE','MOVE_AFTER','MOVE_TO','FACINGS','REMOVE','CONFIRM_POSITION'].includes(action))throw Error('Unsupported physical correction');
  if(action!=='INSERT_BEFORE'&&action!=='INSERT_AFTER'&&!target)throw Error('Placement is no longer in this display');
  const insertion=action.startsWith('INSERT_'),relative=insertion||action==='MOVE_BEFORE'||action==='MOVE_AFTER';
  if(relative&&!(anchor||target))throw Error('Select an existing neighboring placement');
  const marker=anchor||target;
  if(relative&&!marker.physicalEvidence)throw Error('Confirm a physical position before inserting a neighbor');
  if(insertion&&(!identity?.skuKey&&!identity?.upcKey))throw Error('Enter a valid SKU or UPC');
  if(insertion&&typeof idFactory!=='function')throw Error('A new placement identity is required');
  const location=relative?{section:marker.physicalSectionId,row:marker.rowOrdinal}:
   {section:section==null?target.physicalSectionId:section,row:row==null?target.rowOrdinal:row};
  if(!['FACINGS','REMOVE'].includes(action)){
   if(location.section!=null&&!(modular.physicalSectionIds||[]).map(String).includes(String(location.section)))throw Error('Choose a real section assigned to this display');
   if(!Number.isInteger(Number(location.row))||Number(location.row)<1||Number(location.row)>MAX)throw Error('Choose a row or shelf from 1 to 500');
  }
  const changedIds=new Set(),id=target?.id||null;let focus=id;
  if(action==='FACINGS'){
   if(!Number.isInteger(Number(facings))||Number(facings)<1||Number(facings)>MAX)throw Error('Facings must be between 1 and 500');
   target.facings=Number(facings);changedIds.add(target.id);
  }else if(action==='REMOVE'){
   all.splice(all.findIndex(x=>x.id===id),1);changedIds.add(id);focus=null;
   const sameRow=all.filter(p=>p.physicalEvidence===true&&p.physicalSectionId===target.physicalSectionId&&p.rowOrdinal===target.rowOrdinal).sort(physicalSort(modular));
   for(let i=0;i<sameRow.length;i++){
    const p=sameRow[i];if(p.observedOrder===i+1)continue;
    p.observedOrder=i+1;changedIds.add(p.id);
    if(p.role==='SECONDARY')p.approvedException=null;
   }
  }else{
   let item;
   if(insertion){item={id:'explorer:'+idFactory(),modularId:modular.id,skuKey:identity.skuKey||null,upcKey:identity.upcKey||null,origin:'USER_EDIT',role:identity.role||'HOME',physicalEvidence:true,fixtureType:marker.fixtureType||'PEG',facings:1,storeAdded:identity.storeAdded===true,approvedException:null};focus=item.id}
   else {item=target;all.splice(all.indexOf(item),1)}
   item={...item,origin:'USER_EDIT',physicalEvidence:true,physicalSectionId:location.section==null?null:String(location.section),rowOrdinal:Number(location.row),fixtureType:relative?(marker.fixtureType||item.fixtureType):item.fixtureType||'PEG',sourceSegment:null,sourceRow:null,sourceColumn:null,columnOrdinal:null,approvedException:item.approvedException??null};
   // Only the origin and destination rows are renumbered; all other rows are untouched.
   const group=p=>String(p.physicalSectionId??'')+'|'+String(p.rowOrdinal);
   const originGroup=target?group(target):null,chosenGroup=group(item);
   const peers=all.filter(p=>group(p)===chosenGroup&&p.physicalEvidence).sort(physicalSort(modular));
   const reference=relative?(anchor||target):null;
   let at=reference?peers.findIndex(p=>p.id===reference.id):peers.length;
   if(at<0)at=peers.length;
   if(action==='INSERT_AFTER'||action==='MOVE_AFTER')at++;
   peers.splice(at,0,item);
   const affected=[...peers];
   if(originGroup&&originGroup!==chosenGroup)affected.push(...all.filter(p=>group(p)===originGroup&&p.physicalEvidence).sort(physicalSort(modular)));
   const groups=new Set();for(const p of affected)groups.add(group(p));
   for(const g of groups){const members=g===chosenGroup?peers:affected.filter(p=>group(p)===g).sort(physicalSort(modular));
    if(members.length>MAX)throw Error('Row contains more than 500 merchandise positions');
    members.forEach((p,i)=>{const previous=baseline.find(o=>o.id===p.id),original=all.find(o=>o.id===p.id);
     const updated={...p,observedOrder:i+1};
     if(previous&&previous.role==='SECONDARY'&&(previous.observedOrder!==updated.observedOrder||previous.rowOrdinal!==updated.rowOrdinal||previous.physicalSectionId!==updated.physicalSectionId))updated.approvedException=null;
     if(original)Object.assign(original,updated);else if(p.id===item.id)item=updated;
     if(!previous||JSON.stringify(previous)!==JSON.stringify(updated))changedIds.add(updated.id);
    });
   }
   if(insertion||!all.some(p=>p.id===item.id))all.push(item);
   if(action==='CONFIRM_POSITION'&&target)changedIds.add(target.id);
  }
  const beforeById=new Map(baseline.map(p=>[p.id,p]));
  const changed=all.filter(p=>!beforeById.has(p.id)||JSON.stringify(p)!==JSON.stringify(beforeById.get(p.id)));
  const requiresSecondary=changed.filter(p=>p.role==='SECONDARY'&&(!p.approvedException||p.approvedException.placementId!==p.id||p.approvedException.rowOrdinal!==p.rowOrdinal||p.approvedException.observedOrder!==p.observedOrder||p.approvedException.physicalSectionId!==p.physicalSectionId));
  return{placements:all,changed,removed:baseline.filter(p=>!all.some(n=>n.id===p.id)),requiresSecondary,focusId:focus,summary:action.replace(/_/g,' ').toLowerCase(),changedIds:[...changedIds]};
 }
 return Object.freeze({key,same,ordered,position,isExactPosition,physicalSort,sourceSort,propose});
})();
