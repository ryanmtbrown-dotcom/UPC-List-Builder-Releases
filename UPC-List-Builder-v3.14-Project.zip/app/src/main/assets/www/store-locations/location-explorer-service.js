/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/store-locations/location-explorer-service.js
 * Owner: Store Locations / Explorer Read Service
 * Role: Read-only domain service
 * Responsibility: Resolve item-to-display choices, current source/physical sequences, offline catalog details and factual location labels.
 * Does not own: Persistence writes, barcode acquisition, DOM, AceNet network activity, Work Sessions, PDF parsing.
 * Side effects: Read-only calls to existing repository and effective catalog resolver.
 * Related code: location-explorer-policy.js, location-repository.js, effective-catalog-resolver.js.
 */
const UPCLocationExplorerService=(()=>{
 'use strict';
 function create({repository,catalog,policy,itemMapper}={}){
  if(!repository||!catalog||!policy)throw Error('Explorer read dependencies missing');
  async function resolveIdentity(raw,type='AUTO',format=null){
   const value=String(raw||'').trim();if(!value)throw Error('Scan or enter a SKU or UPC');
   if(!['AUTO','UPC','SKU'].includes(type))throw Error('Choose Auto, UPC or SKU');
   const look=async kind=>{try{return kind==='SKU'?await catalog.resolveSKU(value):await catalog.resolveDirectUPC(value,{format})}catch{return null}};
   let result,kind=type;
   if(type==='AUTO'){
    const [sku,upc]=await Promise.all([look('SKU'),look('UPC')]);
    if(sku?.status==='AMBIGUOUS'||upc?.status==='AMBIGUOUS')throw Error('More than one product matches. Choose UPC or SKU explicitly.');
    if(sku?.status==='FOUND'&&upc?.status==='FOUND'&&String(sku.row?.skuKey||sku.row?.sku||'')!==String(upc.row?.skuKey||upc.row?.sku||''))throw Error('Identifier matches two different products. Select UPC or SKU.');
    kind=upc?.status==='FOUND'?'UPC':sku?.status==='FOUND'?'SKU':null;
    if(!kind)throw Error('Auto could not confirm this identifier. Choose UPC or SKU and try again.');
    result=kind==='UPC'?upc:sku;
   }else result=await look(kind);
   if(result?.status==='AMBIGUOUS')throw Error('Ambiguous catalog identifier. Review the catalog before continuing.');
   const row=result?.status==='FOUND'?result.row:null,f=row?.fields||{};
   const sku=row?.skuKey||row?.sku||f['ACE SKU']||null,upc=row?.originalUPC||row?.upcKey||row?.upc||f.UPC||null;
   return{skuKey:kind==='SKU'?value:(sku==null?null:String(sku)),upcKey:kind==='UPC'?value:(upc==null?null:String(upc)),status:result?.status||'UNAVAILABLE',requestedKind:kind};
  }
  async function candidates(identity){
   const facts=identity.skuKey?await repository.bySku(identity.skuKey):await repository.byUpc(identity.upcKey);
   const matches=[],ids=new Set();
   for(const p of facts.placements||[]){if(!policy.same(p,identity)||ids.has(p.modularId))continue;ids.add(p.modularId);matches.push(p.modularId)}
   for(const member of facts.sourceMembers||[]){if(member.notPlaced===true||!policy.same(member,identity))continue;
    const source=await repository.getSource(member.sourceId);
    if(source?.current===true&&source.modularId&&!ids.has(source.modularId)){ids.add(source.modularId);matches.push(source.modularId)}
   }
   const out=[];
   for(const id of matches){const m=await repository.getModular(id);if(!m||m.active===false)continue;
    const area=await repository.getArea(m.areaId);if(!area||area.active===false)continue;
    out.push({modularId:id,name:m.name,area:area.name||('Aisle '+area.aisle),physical:!!(facts.placements||[]).find(p=>p.modularId===id&&p.physicalEvidence===true&&policy.same(p,identity))});
   }
   return out.sort((a,b)=>Number(b.physical)-Number(a.physical)||a.name.localeCompare(b.name));
  }
  async function display(modularId,preferredMode=null){
   const modular=await repository.getModular(modularId);if(!modular||modular.active===false)throw Error('This display is no longer active');
   const area=await repository.getArea(modular.areaId);if(!area||area.active===false)throw Error('This display area is inactive');
   const [placements,sources]=await Promise.all([repository.listPlacements(modularId),repository.listSourcesForModular(modularId)]);
   const current=sources.filter(s=>s.current===true);if(current.length>1)throw Error('Multiple official sources require review before browsing');
   const source=current[0]||null,sourceMembers=source?await repository.listSourceMembers(source.id):[];
   const store=policy.ordered({modular,placements,mode:'STORE'}),ace=policy.ordered({modular,source,sourceMembers,mode:'ACE'});
   const mode=preferredMode==='ACE'&&ace.length?'ACE':preferredMode==='STORE'&&store.length?'STORE':store.length?'STORE':'ACE';
   return{modular,area,source,sourceMembers,placements,store,ace,mode,items:mode==='STORE'?store:ace};
  }
  async function details(item){
   const found=item?.skuKey?await catalog.resolveSKU(item.skuKey).catch(()=>null):item?.upcKey?await catalog.resolveDirectUPC(item.upcKey).catch(()=>null):null;
   const row=found?.status==='FOUND'?found.row:null,f=row?.fields||{};
   const product=row&&itemMapper?itemMapper.itemFromLibraryRow(row,{fallbackSku:item.skuKey||'',fallbackUpc:item.upcKey||'',librarySource:found.provenance||'MASTER_LIBRARY'}):null;
   return{description:String(product?.description||row?.description||row?.itemDescription||f.Description||f.description||row?.name||'Description unavailable offline'),
    sku:String(product?.sku||item?.skuKey||row?.skuKey||'—'),upc:String(product?.upc||item?.upcKey||row?.upc||f.UPC||'—'),
    retail:product?.price??null,orderMultiple:product?.orderMultiple??row?.orderMultiple??f['Order Multiple']??null,
    retailUnits:product?.retailUnits??row?.retailUnits??f['Retail Units']??null,catalogFound:!!row,product};
  }
  return Object.freeze({resolveIdentity,candidates,display,details});
 }
 return Object.freeze({create});
})();
