/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/store-locations/location-lookup-service.js
 * Owner: Store Locations / indexed read-only product location facts.
 * Role: Compose accepted layout, current official source and last-known association for lookup.
 * Responsibility: Provide honest offline location evidence without touching price/catalog authority.
 * Does not own: Mutation, UI generations, scanner events, network or Work Session rows.
 * Side effects: Read-only IndexedDB requests through UPCLocationRepository.
 * Related code: lookup/item-presentation-controller.js, location-policy.js, location-repository.js.
 */
const UPCLocationLookupService=(()=>{
'use strict';
function create({repository,policy}={}){
 if(!repository||!policy)throw Error('Location lookup dependencies missing');
 async function find({skuKey,upcKey}={}){
  const key=String(skuKey||'').trim(),upc=String(upcKey||'').trim();
  const facts=key?await repository.bySku(key):upc?await repository.byUpc(upc):{placements:[],sourceMembers:[],history:[]};
  const excluded=new Set((facts.sourceMembers||[]).filter(x=>x.notPlaced===true).map(x=>x.skuKey));
  const placements=[];
  // Resolve only SKUs actually found by indexed lookup; no full store scan per barcode.
  for(const place of (facts.placements||[]).slice(0,16)){
   if(place.skuKey&&key&&place.skuKey!==key)continue;
   if(place.origin==='ACE_IMPORT'&&excluded.has(place.skuKey))continue;
   const modular=await repository.getModular(place.modularId);
   if(!modular||modular.active===false)continue;
   const area=await repository.getArea(modular.areaId||modular.area?.id);
   if(!area||area.active===false)continue;
   const enriched={...place,areaName:area.kind==='AISLE'?'Aisle '+(area.aisle||area.id):area.name,
    modularName:modular.name,assignedSections:modular.physicalSectionIds||[]};
   if(area.kind==='AISLE')enriched.aisle=area.aisle||area.id;
   if(place.origin==='ACE_IMPORT'&&!place.physicalEvidence&&place.sourceSegment!=null){
    const members=(facts.sourceMembers||[]).filter(x=>x.skuKey===place.skuKey);
    for(const member of members){
     const src=await repository.getSource(member.sourceId);
     if(!src?.current||src.modularId!==place.modularId)continue;
     const segments=Array.isArray(src.sourceSegments)?src.sourceSegments:[];
     const seg=segments.find(z=>z.id===place.sourceSegment);
     if(seg&&segments.length===enriched.assignedSections.length&&seg.ordinal>=1&&seg.ordinal<=segments.length)
      enriched.resolvedSection=enriched.assignedSections[seg.ordinal-1];
     else if(seg)enriched.unmappedSourceSegment=seg.ordinal;
     else enriched.unmappedSourceSegment=String(place.sourceSegment).replace(/^SOURCE-/,'');
     break;
    }
   }
   placements.push(enriched);
  }
  placements.sort((a,b)=>(a.physicalEvidence===true?0:1)-(b.physicalEvidence===true?0:1)||(a.role==='HOME'?0:1)-(b.role==='HOME'?0:1));
  if(placements.length){
   const primary=placements[0];
   const expanded=policy.formatExpandedLocation({current:primary});
   return{kind:'CURRENT',headline:policy.formatCompactLocation({current:primary}),
    details:expanded,otherLocations:placements.slice(1).map(x=>policy.formatCompactLocation({current:x})),
    sourceDerived:primary.origin==='ACE_IMPORT'&&!primary.physicalEvidence,
    skuKey:key,modularId:primary.modularId};
  }
  for(const member of facts.sourceMembers||[]){
   const source=await repository.getSource(member.sourceId);
   if(!source||source.current!==true||!source.modularId)continue;
   const modular=await repository.getModular(source.modularId);
   if(!modular||modular.active===false)continue;
   const area=await repository.getArea(modular.areaId||modular.area?.id);
   if(!area||area.active===false)continue;
   if(member.notPlaced===true){
    return{kind:'EXPECTED_NOT_PLACED',headline:'No current location',details:'Previous Ace: '+(source.name||source.planogramId),otherLocations:[],skuKey:key,modularId:source.modularId};
   }
   const pos=member.positions?.[0]||{};
   const expected={skuKey:member.skuKey,modularId:source.modularId,origin:'ACE_IMPORT',role:'HOME',
    physicalEvidence:false,fixtureType:pos.fixtureType||'UNKNOWN',sourceSegment:pos.sourceSegment,
    sourceRow:pos.sourceRow,sourceColumn:pos.sourceColumn,fixtureZone:pos.fixtureZone,
    areaName:area.kind==='AISLE'?'Aisle '+(area.aisle||area.id):area.name,
    aisle:area.kind==='AISLE'?(area.aisle||area.id):null,
    modularName:modular.name,assignedSections:modular.physicalSectionIds||[]};
   const sourceSegments=Array.isArray(source.sourceSegments)?source.sourceSegments:[];
   const segment=sourceSegments.find(x=>x.id===pos.sourceSegment);
   if(segment&&sourceSegments.length===expected.assignedSections.length&&segment.ordinal>=1&&segment.ordinal<=expected.assignedSections.length){
    expected.resolvedSection=expected.assignedSections[segment.ordinal-1];
   } else if(segment){expected.unmappedSourceSegment=segment.ordinal;}
   else if(pos.sourceSegment!=null){expected.unmappedSourceSegment=String(pos.sourceSegment).replace(/^SOURCE-/,'');}

   return{kind:'CURRENT',headline:policy.formatCompactLocation({current:expected}),details:'',
    otherLocations:[],sourceDerived:true,skuKey:key,modularId:source.modularId};
  }
  const historic=(facts.history||[]).filter(x=>['LAST_KNOWN_ACE','LAST_KNOWN_STORE_ADDED'].includes(x.kind));
  if(historic.length){
   historic.sort((a,b)=>(Number(b.updatedAt)||0)-(Number(a.updatedAt)||0));
   const first=historic[0],extras=historic.slice(1).map(x=>x.kind==='LAST_KNOWN_ACE'?'Earlier Ace planogram: '+(x.sourceName||x.sourceId||'Unknown'):'Earlier store-added display: '+(x.areaName||x.areaId||'Unknown'));
   return{kind:'HISTORICAL',headline:'No current location',
    details:first.kind==='LAST_KNOWN_ACE'?'Last known Ace planogram: '+(first.sourceName||first.sourceId||'Unknown')
     :'Last known store-added layout: '+(first.areaName||first.areaId||'Unknown'),
    otherLocations:extras,sourceDerived:false,skuKey:key,modularId:first.modularId||null};
  }
  return{kind:'UNKNOWN',headline:'No location',details:'',otherLocations:[],sourceDerived:false,skuKey:key,modularId:null};
 }
 return Object.freeze({find});
}
return Object.freeze({create});
})();
