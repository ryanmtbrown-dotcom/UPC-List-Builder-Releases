/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/store-locations/location-work-feature.js
 * Owner: Store Locations / Build 2 / Physical Work Feature Assembly
 * Role: Dependency adapter
 * Responsibility: Composes the existing repository, catalog read adapter, draft service, and UI controller through explicit injection.
 * Does not own: Official Ace PDF interpretation, Master or Local product identity, pricing, passive ordinary scanner capture, or a separate Research repository.
 * Side effects: Instantiates feature owners without persistent writes at construction.
 * Related code: application/application-shell.js, location-work-controller.js, location-work-service.js
 */
const UPCLocationWorkFeature=(()=>{
'use strict';
function create({repository,db,policy,catalogResolver,elementById,documentRef,startScanner,normalizeUPC,normalizeSKU,
 promptDuplicate,confirmUser,relationshipService,idFactory}={}){
 if(!catalogResolver||!repository||!db||!policy||!idFactory)throw Error('Physical feature dependencies unavailable');
 const service=UPCLocationWorkService.create({repository,db,idFactory});
 const resolveUPC=async(upc,format)=>{
  const facts=await repository.byUpc(upc);
  const keys=[...new Set([...(facts.placements||[]),...(facts.sourceMembers||[])].map(x=>x.skuKey).filter(Boolean))];
  if(keys.length===1)return{skuKey:keys[0]};
  const result=await catalogResolver.resolveDirectUPC(upc,{format});
  return{skuKey:result.status==='FOUND'?(result.row?.skuKey||null):null};
 };
 return UPCLocationWorkController.create({repository,service,policy,elementById,documentRef,startScanner,normalizeUPC,
  normalizeSKU,promptDuplicate,confirmUser,relationshipService,resolveUPC});
}
return Object.freeze({create});
})();