/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/store-locations/location-work-policy.js
 * Owner: Store Locations / Build 2 / Physical Observation & Audit Policy
 * Role: Pure domain rules
 * Responsibility: Compares accepted layouts, explicit observations, and current corporate membership without false missing claims.
 * Does not own: Official Ace PDF interpretation, Master or Local product identity, pricing, passive ordinary scanner capture, or a separate Research repository.
 * Side effects: None.
 * Related code: location-work-service.js, location-policy.js, STORE_LOCATION_CONTRACT.md
 */
const UPCLocationWorkPolicy=(()=>{
 'use strict';
 const key=p=>p?.skuKey?'SKU:'+p.skuKey:p?.upcKey?'UPC:'+p.upcKey:null;
 const stable=x=>{if(Array.isArray(x))return x.map(stable);if(x&&typeof x==='object')return Object.fromEntries(Object.keys(x).sort().map(k=>[k,stable(x[k])]));return x};
 const fingerprint=rows=>JSON.stringify((rows||[]).map(stable).sort((a,b)=>String(a.id).localeCompare(String(b.id))));
 const scoped=(p,sections,completeSpan)=>sections.includes(String(p.physicalSectionId))||(completeSpan&&p.physicalSectionId==null);
 const samePosition=(a,b)=>String(a.physicalSectionId??'')===String(b.physicalSectionId??'')&&
   String(a.rowOrdinal??'')===String(b.rowOrdinal??'')&&String(a.fixtureType??'')===String(b.fixtureType??'')&&
   (a.observedOrder==null||b.observedOrder==null||a.observedOrder===b.observedOrder);
 const matches=(a,b)=>!!key(a)&&key(a)===key(b)||!!a?.upcKey&&!!b?.upcKey&&a.upcKey===b.upcKey;
 function requiresSecondaryApproval(p){
  if(p?.role!=='SECONDARY')return false;
  const a=p.approvedException;
  return !(a&&a.placementId===p.id&&a.skuKey===(p.skuKey||null)&&
   String(a.physicalSectionId??'')===String(p.physicalSectionId??'')&&
   a.rowOrdinal===p.rowOrdinal&&a.observedOrder===p.observedOrder);
 }
 // An already accepted active HOME in another display is a genuine second stocking location, not a new HOME.
 // Imported corporate source hints and inactive/retired displays are not physical stocking evidence.
 function needsSeparateLocationConfirmation({identity,observations=[],baseline=[],otherPlacements=[],activeModularIds=[],modularId}={}){
  if(observations.some(p=>matches(p,identity)))return true;
  if(baseline.some(p=>matches(p,identity)))return false;
  const active=new Set(activeModularIds);
  return otherPlacements.some(p=>p.physicalEvidence===true&&p.modularId!==modularId&&active.has(p.modularId)&&matches(p,identity));
 }
 const makePlacement=(o,sourceMembers)=>({
  id:o.id,modularId:o.modularId,skuKey:o.skuKey||null,upcKey:o.upcKey||null,
  origin:o.origin==='USER_EDIT'?'USER_EDIT':'USER_SCAN',role:o.role||'HOME',
  physicalEvidence:true,physicalSectionId:o.physicalSectionId??null,
  rowOrdinal:o.rowOrdinal??null,columnOrdinal:null,observedOrder:o.observedOrder??null,
  fixtureType:o.fixtureType||'UNKNOWN',facings:o.facings||1,
  storeAdded:!sourceMembers.some(m=>m.skuKey&&m.skuKey===o.skuKey||m.upcKey&&m.upcKey===o.upcKey),
  approvedException:o.approvedException||null
 });
 function changes({baseline=[],observed=[],sourceMembers=[],sections=[],allSections=[]}={}){
  const completeSpan=allSections.length===0||allSections.every(x=>sections.includes(String(x)));
  const relevant=baseline.filter(p=>scoped(p,sections,completeSpan));
  const paired=new Set(),out=[];
  for(const o of observed){
   // Match an existing product across the whole modular, even when its corporate source has no physical section.
   // Partial scope limits removals, not reassignment of a genuinely observed existing item.
   const candidates=baseline.filter(p=>!paired.has(p.id)&&matches(p,o)&&
    (o.role!=='SECONDARY'||p.role==='SECONDARY'));
   const previous=candidates.find(p=>samePosition(p,o))||candidates[0];
   const next=makePlacement(o,sourceMembers);
   if(previous){paired.add(previous.id);const type=samePosition(previous,next)&&previous.origin!=='ACE_IMPORT'&&Number(previous.facings||1)===Number(next.facings||1)?'UNCHANGED':'MOVE';
    const fresh=next.role==='SECONDARY'&&next.approvedException?.placementId===o.id
     ?{...next.approvedException,placementId:previous.id}:null;
    out.push({id:'chg:'+o.id,type,before:previous,after:{...next,id:previous.id,role:previous.role,
     approvedException:fresh||previous.approvedException||null}});
   }else out.push({id:'chg:'+o.id,type:'ADD',before:null,after:next});
  }
  for(const p of relevant)if(!paired.has(p.id))out.push({id:'remove:'+p.id,type:'REMOVE',before:p,after:null});
  return out;
 }
 function audit({baseline=[],observed=[],sourceMembers=[],sections=[],completeSections=[],allSections=[]}={}){
  const done=new Set(completeSections.map(String)),fixtureScope=sections.length===0&&allSections.length===0,
   fixtureDone=fixtureScope&&done.has('FIXTURE'),
   isDone=p=>p.physicalSectionId!=null?done.has(String(p.physicalSectionId)):(fixtureScope&&fixtureDone);
  const known=new Set(),found=[],wrong=[],added=[],duplicates=[],notObserved=[],notVerified=[];
  const byKey=new Map();
  for(const o of observed){
   const k=key(o);if(!k)continue;
   const peers=byKey.get(k)||[];
   if(peers.some(p=>!samePosition(p,o)))duplicates.push({kind:'POSSIBLE_SEPARATE_DUPLICATE',observation:o,others:peers});
   peers.push(o);byKey.set(k,peers);
   const options=baseline.filter(p=>matches(p,o));
   const current=options.find(p=>samePosition(p,o))||options[0];
   const inSource=sourceMembers.some(m=>matches(m,o));
   if(!inSource)added.push({kind:'STORE_ADDED',observation:o,accepted:!!current});
   if(current){
    known.add(current.id);
    if(current.physicalSectionId!=null&&o.physicalSectionId!=null&&String(current.physicalSectionId)!==String(o.physicalSectionId)){
     wrong.push({kind:'WRONG_SECTION',observation:o,current});
    }else found.push({kind:'FOUND_AS_EXPECTED',observation:o,current});
   }
  }
  for(const p of baseline){
   if(known.has(p.id))continue;
   if(isDone(p))notObserved.push({kind:'NOT_OBSERVED',current:p});
   else notVerified.push({kind:'NOT_VERIFIED',current:p});
  }
  const acceptedKeys=new Set(baseline.map(key));
  const unplaced=sourceMembers.filter(m=>!acceptedKeys.has(key(m))&&m.notPlaced!==true);
  return{foundAsExpected:found,storeAdded:added,expectedAceUnplaced:unplaced.map(m=>({kind:'ACE_EXPECTED_UNPLACED',member:m})),
   notObserved,wrongSection:wrong,possibleSeparateDuplicate:duplicates,notVerified,
   completeSections:[...done],partial:fixtureScope?!fixtureDone:!sections.every(s=>done.has(String(s)))};
 }
 function composeAcceptance({baseline,proposals,approvedIds,mode}){
  const accepted=new Set(approvedIds||[]),all=new Map((baseline||[]).map(p=>[p.id,p]));
  const types={ADD:0,MOVE:0,REMOVE:0};
  for(const p of proposals||[]){
   if(!accepted.has(p.id)||p.type==='UNCHANGED')continue;
   if(!['ADD','MOVE','REMOVE'].includes(p.type))throw Error('Unknown correction');
   if(p.type==='REMOVE'&&mode==='AUDIT')throw Error('Audit cannot silently remove accepted merchandise');
   if(p.before&&!all.has(p.before.id))throw Error('Stale placement correction');
   if(p.type==='REMOVE')all.delete(p.before.id);
   else all.set(p.after.id,p.after);
   types[p.type]++;
  }
  return{placements:[...all.values()],counts:types};
 }
 return Object.freeze({key,fingerprint,samePosition,matches,changes,audit,composeAcceptance,makePlacement,requiresSecondaryApproval,needsSeparateLocationConfirmation});
})();