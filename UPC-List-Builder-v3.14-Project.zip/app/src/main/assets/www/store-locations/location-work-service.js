/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/store-locations/location-work-service.js
 * Owner: Store Locations / Build 2 / Physical Work Draft Lifecycle
 * Role: Domain service
 * Responsibility: Persists recoverable working observations and mediates explicit atomic physical-layout approval.
 * Does not own: Official Ace PDF interpretation, Master or Local product identity, pricing, passive ordinary scanner capture, or a separate Research repository.
 * Side effects: Writes the existing meta draft through the injected database adapter and invokes approved location repository writes.
 * Related code: location-work-policy.js, location-repository.js, location-work-controller.js
 */
const UPCLocationWorkService=(()=>{
'use strict';
const KEY='storeLocationWorkV1';
function create({repository,db,idFactory,now=()=>Date.now()}={}){
 if(!repository||!db||typeof idFactory!=='function')throw Error('Location work dependencies required');
 const id=()=>String(idFactory());
 async function resume(){const r=await db.get('meta',KEY),w=r?.workspace||null;
  if(w&&(!['LAYOUT','AUDIT'].includes(w.mode)||!w.modularId||!Array.isArray(w.baseline)||!Array.isArray(w.observations)))
   throw Error('Incompatible saved draft; no existing record has been overwritten');
  return w;
 }
 async function save(work){if(!work?.modularId||!['LAYOUT','AUDIT'].includes(work.mode))throw Error('Invalid work draft');
  const next={...work,updatedAt:now()};await db.put('meta',{key:KEY,workspace:next});return next;
 }
 async function clear(){await db.put('meta',{key:KEY,workspace:null})}
 async function start({modularId,mode,sections,fixtureType='PEG'}={}){
  if(!['LAYOUT','AUDIT'].includes(mode))throw Error('Choose Build Layout or Audit');
  const modular=await repository.getModular(modularId);
  if(!modular||modular.active===false)throw Error('Choose an active saved display');
  const possible=(modular.physicalSectionIds||[]).map(String),selected=[...new Set((sections||possible).map(String))];
  if(possible.length&&(!selected.length||selected.some(x=>!possible.includes(x))))throw Error('Select real display sections');
  if(!['PEG','SHELF','SPCFIX','OTHER','UNKNOWN'].includes(fixtureType))throw Error('Invalid fixture');
  const [baseline,sources]=await Promise.all([repository.listPlacements(modularId),repository.listSourcesForModular(modularId)]);
  const current=sources.filter(s=>s.current===true);
  if(current.length>1)throw Error('Conflicting corporate assignments need review');
  const sourceMembers=current.length?await repository.listSourceMembers(current[0].id):[];
  return save({id:id(),mode,modularId,modularName:modular.name,areaId:modular.areaId,
   allSections:possible,sections:selected,fixtureType,sectionIndex:0,rowOrdinal:1,
   baseline,baselineFingerprint:UPCLocationWorkPolicy.fingerprint(baseline),
   sourceSignature:repository.sourceSignature(sources),sourceMembers,
   observations:[],completeSections:[],createdAt:now()});
 }
 async function record(work,{skuKey=null,upcKey=null,origin='USER_SCAN',secondary=false}={}){
  if(!skuKey&&!upcKey)throw Error('Enter a SKU or accepted UPC');
  if(!['USER_SCAN','USER_EDIT'].includes(origin))throw Error('Unknown observation origin');
  const section=work.sections[work.sectionIndex]||null,
   order=1+work.observations.filter(o=>o.physicalSectionId===section&&o.rowOrdinal===work.rowOrdinal).length;
  const o={id:'observation:'+id(),modularId:work.modularId,skuKey,upcKey,origin,
   physicalEvidence:true,role:secondary?'SECONDARY':'HOME',physicalSectionId:section,fixtureType:work.fixtureType,
   rowOrdinal:work.rowOrdinal,columnOrdinal:null,observedOrder:order,facings:1,recordedAt:now()};
  if(secondary)o.approvedException={placementId:o.id,skuKey:skuKey||null,physicalSectionId:section,rowOrdinal:o.rowOrdinal,observedOrder:order,confirmedAt:now()};
  return save({...work,observations:[...work.observations,o]});
 }
 async function changeFacing(work,observationId,delta){
  if(![-1,1].includes(delta))throw Error('Invalid facing increment');
  return save({...work,observations:work.observations.map(o=>o.id===observationId?{...o,facings:Math.max(1,Math.min(500,o.facings+delta))}:o)});
 }
 async function changeFixture(work,type){
  if(!['PEG','SHELF','SPCFIX','OTHER','UNKNOWN'].includes(type))throw Error('Unknown fixture type');
  return save({...work,fixtureType:type,rowOrdinal:1});
 }
 async function advance(work,type){
  if(type==='SECTION'){
   if(work.sectionIndex>=work.sections.length-1)throw Error('This is the last selected section. Choose a new display or finish this work.');
   return save({...work,sectionIndex:work.sectionIndex+1,rowOrdinal:1});
  }
  if(type==='SHELF')return save({...work,rowOrdinal:Math.min(500,work.rowOrdinal+1),fixtureType:'SHELF'});
  if(type==='ROW')return save({...work,rowOrdinal:Math.min(500,work.rowOrdinal+1)});
  throw Error('Invalid position advance');
 }
 async function reorder(work,observationId,direction){
  const a=[...work.observations],i=a.findIndex(o=>o.id===observationId),j=i+direction;
  if(![-1,1].includes(direction)||i<0||j<0||j>=a.length)return work;
  if(a[i].physicalSectionId!==a[j].physicalSectionId||a[i].rowOrdinal!==a[j].rowOrdinal)return work;
  [a[i],a[j]]=[a[j],a[i]];
  const count=new Map();
  const fixed=a.map(o=>{const group=String(o.physicalSectionId)+'|'+o.rowOrdinal;
   const order=(count.get(group)||0)+1;count.set(group,order);
   return {...o,observedOrder:order,approvedException:o.role==='SECONDARY'&&order!==o.observedOrder?null:o.approvedException};});
  return save({...work,observations:fixed});
 }
 async function move(work,observationId,{section,row,confirmSecondary=false}={}){
  // Custom fixtures have no numbered sections: editing a shelf/row must retain physicalSectionId=null.
  const target=work.sections.length?String(section):null;
  if((work.sections.length&&!work.sections.includes(target))||(!work.sections.length&&section!=null&&section!=='')||
   !Number.isInteger(row)||row<1||row>500)throw Error('Invalid target section/row');
  return save({...work,observations:work.observations.map(o=>{if(o.id!==observationId)return o;
   const next={...o,physicalSectionId:target,rowOrdinal:row,
    observedOrder:1+work.observations.filter(p=>p.id!==o.id&&p.physicalSectionId===target&&p.rowOrdinal===row).length};
   if(next.role==='SECONDARY')next.approvedException=confirmSecondary?{placementId:next.id,skuKey:next.skuKey||null,physicalSectionId:target,rowOrdinal:row,observedOrder:next.observedOrder,confirmedAt:now()}:null;
   return next})});
 }
 async function removeObservation(work,observationId){return save({...work,observations:work.observations.filter(o=>o.id!==observationId)})}
 async function markSectionComplete(work,section,complete){
  if(work.mode!=='AUDIT'||!(work.sections.includes(String(section))||(String(section)==='FIXTURE'&&work.sections.length===0)))throw Error('Audit section not in scope');
  const s=new Set(work.completeSections);complete?s.add(String(section)):s.delete(String(section));
  return save({...work,completeSections:[...s]});
 }
 function review(work){
  const a={baseline:work.baseline,observed:work.observations,sourceMembers:work.sourceMembers,
   sections:work.sections,allSections:work.allSections};
  return{proposals:UPCLocationWorkPolicy.changes(a).filter(p=>!work.seedOnly||p.type!=='REMOVE'),
   findings:UPCLocationWorkPolicy.audit({...a,completeSections:work.completeSections})};
 }
 async function approve(work,approvedIds,secondaryApprovals=[]){
  const proposed=review(work).proposals;
  const authorized=new Set(secondaryApprovals);
  for(const correction of proposed){
   if(!(approvedIds||[]).includes(correction.id)||!correction.after||
      !UPCLocationWorkPolicy.requiresSecondaryApproval(correction.after))continue;
   if(!authorized.has(correction.id))throw Error('This secondary placement moved. Confirm this specific physical location using the existing Yes/No duplicate review.');
   const p=correction.after;
   correction.after={...p,approvedException:{placementId:p.id,skuKey:p.skuKey||null,
    physicalSectionId:p.physicalSectionId??null,rowOrdinal:p.rowOrdinal??null,
    observedOrder:p.observedOrder??null,confirmedAt:now()}};
  }
  const composed=UPCLocationWorkPolicy.composeAcceptance({baseline:work.baseline,proposals:proposed,approvedIds,mode:work.mode});
  if(!Object.values(composed.counts).some(Boolean))throw Error('Select at least one correction to approve');
  const result=await repository.approvePhysicalLayout({modularId:work.modularId,items:composed.placements,
   expectedFingerprint:work.baselineFingerprint,expectedSourceSignature:work.sourceSignature});
  await clear();return{...result,...composed.counts};
 }
 return Object.freeze({start,save,resume,clear,record,changeFacing,changeFixture,advance,reorder,move,removeObservation,markSectionComplete,review,approve});
}
return Object.freeze({KEY,create});
})();