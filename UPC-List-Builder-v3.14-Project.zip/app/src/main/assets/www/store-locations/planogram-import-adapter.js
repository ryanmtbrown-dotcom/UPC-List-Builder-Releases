/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/store-locations/planogram-import-adapter.js
 * Owner: Store Locations / paired ChatGPT planogram device transfer.
 * Role: HTTPS client scoped to authenticated planogram batches.
 * Responsibility: Use the already-paired native encrypted device connection, never a second token store.
 * Does not own: DSD invoice workflow, OAuth sign-in, database mutation, PDF content or UI.
 * Side effects: Bounded HTTPS requests on explicit planogram actions.
 * Related code: ChatGPTConnectionVault.kt, dsd/dsd-chatgpt-import.js, planogram-import-controller.js.
 */
const UPCPlanogramImportAdapter=(()=>{
'use strict';
function create({nativeBridgeProvider=()=>window.AndroidNative,fetchFn=fetch}={}){
 function connected(){
  try{const text=nativeBridgeProvider()?.getChatGPTConnection?.();const x=JSON.parse(text||'null');
   if(x&&typeof x.token==='string'&&/^[A-Za-z0-9_-]{43}$/.test(x.token)&&typeof x.url==='string'){
    const origin=new URL(x.url);
    if(origin.protocol==='https:'&&origin.origin===x.url&&!origin.username&&!origin.password)return x;
   }
  }catch(_){}
  return null;
 }
 async function request(path,{method='GET'}={}){
  const connection=connected();if(!connection)throw Error('Connect the device through the existing ChatGPT DSD pairing settings first.');
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),15000);
  try{const response=await fetchFn(connection.url+path,{method,cache:'no-store',signal:controller.signal,
   headers:{Authorization:'Bearer '+connection.token,'Content-Type':'application/json'}});
   const json=await response.json().catch(()=>({}));if(!response.ok)throw Error(json.error||('Planogram service HTTP '+response.status));return json;
  }finally{clearTimeout(timer)}
 }
 const segment=id=>{if(typeof id!=='string'||!/^[a-f\d-]{36}$/i.test(id))throw Error('Invalid batch identifier');return id};
 return Object.freeze({connected,list:()=>request('/api/v1/planograms'),get:id=>request('/api/v1/planograms/'+segment(id)),
  ack:id=>request('/api/v1/planograms/'+segment(id)+'/ack',{method:'POST'}),reject:id=>request('/api/v1/planograms/'+segment(id),{method:'DELETE'})});
}
return Object.freeze({create});
})();
