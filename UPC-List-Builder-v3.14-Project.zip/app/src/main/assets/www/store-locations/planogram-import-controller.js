/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/store-locations/planogram-import-controller.js
 * Owner: Store Locations / official planogram staged-import review UI.
 * Role: Present pending AI-extracted reports, local acceptance, official assignment.
 * Responsibility: User-approved import and post-commit receipt acknowledgment.
 * Does not own: PDF parsing, DSD invoice import, raw persistence, scanner or pricing.
 * Side effects: DOM and explicit delegated device requests / IndexedDB repository methods.
 * Related code: planogram-import-service.js, planogram-import-adapter.js, location-repository.js.
 */
const UPCPlanogramImportController=(()=>{
'use strict';
function create({repository,adapter,service,elementById,documentRef=document,confirmUser}={}){
 if(!repository||!adapter||!service||typeof elementById!=='function')throw Error('Planogram import dependencies missing');
 const $=elementById,doc=documentRef;
 let batches=[],current=null,validated=null,sources=[],modulars=[];
 const message=(s,level='info')=>{const node=$('planogramImportStatus');if(node){node.textContent=s;node.dataset.kind=level}};
 const option=(label,value)=>{const o=doc.createElement('option');o.textContent=label;o.value=value;return o};
 function renderBatchChoices(){const select=$('planogramBatchSelect'),before=select.value;select.replaceChildren(option('Choose a pending planogram…',''));
  for(const b of batches)select.append(option((b.sourceName||b.planogramId)+' · '+(b.sourceReportRows||0)+' source rows',b.batchId));
  select.value=batches.some(b=>b.batchId===before)?before:'';
 }
 async function check(){current=null;validated=null;$('planogramImportReview').classList.add('hidden');
  try{message('Checking paired ChatGPT planogram queue…');const response=await adapter.list();
   batches=Array.isArray(response.batches)?response.batches:[];
   renderBatchChoices();message(batches.length?batches.length+' planogram import(s) awaiting review.':'No pending planograms. Import a PDF through the ChatGPT @UPC plugin first.');
  }catch(e){message('Planogram check unavailable: '+e.message,'error')}
 }
 async function review(){const id=$('planogramBatchSelect').value;
  if(!batches.some(x=>x.batchId===id))return message('Select a pending planogram.','error');
  try{message('Checking source rows, exceptions and payload integrity…');const payload=await adapter.get(id);
   validated=await service.verify(payload);current=payload;
   const {source,reconciliation:r}=payload;
   $('planogramReviewName').textContent=source.name+' · '+source.planogramId;
   $('planogramReviewFacts').textContent=source.nominalWidthFt+' ft · '+source.nominalFourFootSections+' × 4-ft bays · '+r.sourceReportRows+' source rows · '+r.distinctMerchandiseSkus+' different SKUs · '+r.excludedNonMerchandiseRows+' fixtures/signs excluded · '+r.unresolvedRows+' unresolved · '+r.unrepresentedRows+' unrepresented';
   $('planogramReviewProvenance').textContent='Width: '+source.widthEvidence+' · '+source.sourceIdentityEvidence;
   const existing=sources.find(x=>x.current&&x.planogramId===source.planogramId);
   if(existing)message('Updated Ace report for '+source.name+' detected. Confirm replacement before saving; your store corrections remain.');
   $('planogramReviewExceptions').textContent=validated.hasUnresolved?'Some source rows are unresolved or missing. Resolve omissions before accepting this as a complete planogram.':'Every source report row is accounted for.';
   $('planogramAccept').disabled=payload.manifest.status!=='COMPLETE'||r.unrepresentedRows>0;
   $('planogramImportReview').classList.remove('hidden');
   message('Report validated. Review source counts before saving locally.');
  }catch(e){current=null;validated=null;$('planogramImportReview').classList.add('hidden');message('Source validation failed: '+e.message,'error')}
 }
 async function accept(){if(!current||!validated)return message('Review a validated source first.','error');
  const batchId=current.batchId;
  if(current.manifest.status!=='COMPLETE'||current.reconciliation.unrepresentedRows)return message('Incomplete Product Report cannot be accepted.','error');
  if(validated.hasUnresolved&&typeof confirmUser==='function'&&!await confirmUser(
   'Some source positions or SKUs remain unresolved. Import only verified Ace source members while keeping all unresolved rows noted in the source?','Review unresolved source',{okLabel:'Import verified members'}))return;
  if(validated.hasUnresolved&&typeof confirmUser!=='function')return message('Import confirmation unavailable. Source not accepted.','error');
  const prior=sources.find(x=>x.current&&x.planogramId===current.source.planogramId);
  if(prior&&(typeof confirmUser!=='function'||!await confirmUser('Re-import '+current.source.name+' ('+current.source.nominalWidthFt+' ft / '+current.source.nominalFourFootSections+' bays)? Update the official coordinates while preserving Aisle/Sections, employee-approved positions and items marked not placed.','Replace existing planogram',{okLabel:'Replace planogram'})))return;
  try{
   const result=await repository.acceptSource({replaceSourceId:prior?.id||null,source:{id:'source-'+batchId,planogramId:current.source.planogramId,
    name:current.source.name,commodityCode:current.source.commodityCode,sourceIdentityEvidence:current.source.sourceIdentityEvidence,
    nominalWidthFt:current.source.nominalWidthFt,nominalFourFootSections:current.source.nominalFourFootSections,widthEvidence:current.source.widthEvidence,sourceSegments:current.sourceSegments,
    sourceReportRows:current.reconciliation.sourceReportRows,excludedRows:current.reconciliation.excludedNonMerchandiseRows,
    unresolvedRows:current.reconciliation.unresolvedRows,digest:validated.digest},
    items:service.stageSource(current),batchId});
   message(result.replayed?'Already saved on this device. Retrying receipt…':result.replaced?'Planogram refreshed; store assignments and approved corrections preserved.':'Saved official source locally. Assign it to a display below.');
   try{await adapter.ack(batchId);message(result.replaced?'Re-import complete. Existing display assignment retained.':'Planogram saved. Assign it to a physical modular below.');}
   catch(e){message('Saved locally. Server receipt pending; tap Check and import again to retry safely. '+e.message,'warning')}
   await refreshSources();
  }catch(e){message('Local import failed; nothing was acknowledged: '+e.message,'error')}
 }
 function updateAssignmentComparison(){
  const source=sources.find(x=>x.id===$('planogramSourceAssignSelect').value);
  const target=modulars.find(x=>x.id===$('planogramModularAssignSelect').value);
  const node=$('planogramAssignmentComparison');if(!node)return;
  if(!source){node.textContent='Select a saved Ace planogram to see its intended length.';return;}
  const official=source.nominalFourFootSections;
  let label=source.nominalWidthFt!=null?'Ace source: '+source.nominalWidthFt+' ft · '+official+' × 4-ft bays.':'Ace source footage unavailable; re-import through the plugin.';
  if(target){const actual=target.physicalSectionIds?.length||0;
   label+=' Your display: '+(target.physicalSectionIds?.length?'S'+target.physicalSectionIds.join('–')+' · ':'')+(actual?actual*4+' ft · '+actual+' bays.':'Custom fixture.');
   if(Number.isInteger(official)&&actual)label+=actual<official?' Condensed layout.':actual>official?' Expanded layout.':' Matching length.';
  }
  node.textContent=label;
 }
 async function refreshSources(){
  try{[sources,modulars]=await Promise.all([repository.listSources(),repository.listModulars()]);
   const s=$('planogramSourceAssignSelect'),m=$('planogramModularAssignSelect'),prior=s.value,previousModular=m.value;
   s.replaceChildren(option('Select imported planogram…',''));m.replaceChildren(option('Select store modular…',''));
   for(const src of sources.filter(x=>x.current))s.append(option((src.name||src.planogramId)+' · '+(src.nominalWidthFt!=null?src.nominalWidthFt+' ft · '+src.nominalFourFootSections+' bays':'Width not yet provided')+(src.modularId?' · assigned':' · unassigned'),src.id));
   for(const mod of modulars.filter(x=>x.active))m.append(option(mod.name+' · '+(mod.physicalSectionIds?.length?'SEC '+mod.physicalSectionIds.join(', '):mod.fixtureId||'Custom display'),mod.id));
   s.value=sources.some(x=>x.id===prior)?prior:'';m.value=modulars.some(x=>x.id===previousModular)?previousModular:'';updateAssignmentComparison();
  }catch(e){message('Local planogram library unavailable: '+e.message,'error')}
 }
 async function assign(){const sourceId=$('planogramSourceAssignSelect').value,modularId=$('planogramModularAssignSelect').value;
  if(!sourceId||!modularId)return message('Choose both the official planogram and physical modular.','error');
  const currentPlan=sources.find(x=>x.id===sourceId),target=modulars.find(m=>m.id===modularId),previous=sources.find(x=>x.id!==sourceId&&x.current&&x.modularId===modularId);
  if(!currentPlan||!target)return message('Selected planogram or modular no longer exists.','error');
  if(previous){
   if(typeof confirmUser!=='function')return message('Replacement needs confirmation. No change made.','error');
   if(!await confirmUser('Replace the current official '+(previous.name||previous.planogramId)+' reference for '+target.name+' with '+(currentPlan.name||currentPlan.planogramId)+'? Existing store placements and old per-item references will be retained.','Replace official source',{okLabel:'Replace source'}))return;
  }
  try{const result=await repository.assignSource({sourceId,modularId,replaceSourceId:previous?.id||null,seedIfEmpty:true});
   message('Assigned '+target.name+'. '+result.seeded+' products available at Ace planogram positions.');
   await refreshSources();
  }catch(e){message('Planogram assignment rejected: '+e.message,'error')}
 }
 async function deleteCurrent(){const id=$('planogramSourceAssignSelect').value,source=sources.find(x=>x.id===id);
  if(!source)return message('Select a current planogram.','error');
  if(typeof confirmUser!=='function'||!await confirmUser('Delete current official reference '+(source.name||source.planogramId)+'? Saved physical placements and factual last-known product references remain.','Delete official reference',{okLabel:'Delete reference'}))return;
  try{await repository.removeSource(id);message('Current official reference deleted; physical layout retained.');await refreshSources()}catch(e){message(e.message,'error')}
 }
 async function correctOne(restore=false){
  const sourceId=$('planogramSourceAssignSelect').value,skuKey=$('planogramPlacementSku').value.trim();
  const source=sources.find(x=>x.id===sourceId&&x.current&&x.modularId);
  if(!source||!skuKey)return message('Select an assigned current planogram and enter its exact Ace SKU.','error');
  if(!restore){
   if(typeof confirmUser!=='function'||!await confirmUser('Mark SKU '+skuKey+' as not located in the current store layout for '+(source.name||source.planogramId)+'? The official Ace source and last-known reference remain available.','Remove current placement',{okLabel:'Mark not placed'}))return;
  }
  try{
   const result=restore?await repository.restoreSourceMember({sourceId,skuKey}):await repository.markSourceMemberNotPlaced({sourceId,skuKey});
   message(restore?'Restored Ace planogram location for '+skuKey+'.':'Marked '+skuKey+' as not in the current layout. Original Ace planogram membership retained.');
   $('planogramPlacementSku').value='';
  }catch(e){message('Placement not changed: '+e.message,'error')}
 }
 function bind(){
  $('planogramSourceAssignSelect').addEventListener('change',updateAssignmentComparison);
  $('planogramModularAssignSelect').addEventListener('change',updateAssignmentComparison);
  $('planogramCheck').addEventListener('click',()=>{void check()});
  $('planogramReview').addEventListener('click',()=>{void review()});
  $('planogramAccept').addEventListener('click',()=>{void accept()});
  $('planogramAssign').addEventListener('click',()=>{void assign()});
  $('planogramDelete').addEventListener('click',()=>{void deleteCurrent()});
  $('planogramMarkNotPlaced').addEventListener('click',()=>{void correctOne(false)});
  $('planogramRestoreItem').addEventListener('click',()=>{void correctOne(true)});
  void refreshSources();
 }
 return Object.freeze({bind,check,review,accept,refreshSources});
}
return Object.freeze({create});
})();
