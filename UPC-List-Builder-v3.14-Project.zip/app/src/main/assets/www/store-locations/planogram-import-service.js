/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/store-locations/planogram-import-service.js
 * Owner: Store Locations / device-side AI source validation and import mapping.
 * Role: Strict independent structured-data checks and cryptographic payload verification.
 * Responsibility: Reject incomplete, mutated or ambiguous source facts before local persistence.
 * Does not own: PDF parsing, merchandise pricing, identities, network, app DOM or IndexedDB.
 * Side effects: WebCrypto SHA-256 only (immutable validated input).
 * Related code: PLANOGRAM_IMPORT_CONTRACT.md, planogram-import-adapter.js, location-repository.js.
 */
const UPCPlanogramImportService=(()=>{
'use strict';
const own=(v,k)=>Object.prototype.hasOwnProperty.call(v,k);
const fields=(o,names,required=[])=>{
 if(!o||typeof o!=='object'||Array.isArray(o))throw Error('Invalid source object');
 for(const name of Object.keys(o))if(!names.includes(name))throw Error('Unsupported planogram field '+name);
 for(const name of required)if(!own(o,name))throw Error('Required planogram field '+name+' absent');
 return o;
};
const count=(o,k)=>{const n=o[k];if(!Number.isSafeInteger(n)||n<0||n>3500)throw Error('Invalid '+k);return n};
const validText=(value,max=320,optional=false)=>{
 if(optional&&(value==null||value===''))return null;
 if(typeof value!=='string'||!value.trim()||value.length>max||/[\u0000-\u001f\u007f]/.test(value))throw Error('Invalid source text');
 return value.trim();
};
const checkDigit=s=>{if(!/^\d{8}$|^\d{12,14}$/.test(s)||/^0+$/.test(s))return false;
 let n=0;for(let i=s.length-2,j=0;i>=0;i--,j++)n+=Number(s[i])*(j%2===0?3:1);
 return (10-n%10)%10===Number(s.at(-1));};
function validate(data){
 fields(data,['batchId','state','schemaVersion','source','sourceSegments','placements','reconciliation','exclusions','unresolved','manifest'],['batchId','state','schemaVersion','source','sourceSegments','placements','reconciliation','exclusions','unresolved','manifest']);
 if(data.state!=='pending'||data.schemaVersion!=='PLANOGRAM_IMPORT_V1')throw Error('Batch is not a pending supported planogram');
 validText(data.batchId,80);const s=fields(data.source,['planogramId','name','commodityCode','commodityGroup','liveDate','nominalWidthFt','nominalFourFootSections','widthEvidence','sourceFilename','sourceIdentityEvidence'],['planogramId','name','sourceIdentityEvidence','nominalWidthFt','nominalFourFootSections','widthEvidence']);
 validText(s.planogramId,100);validText(s.name,180);validText(s.sourceIdentityEvidence,550);
 if(s.liveDate!=null&&!/^\d{4}-\d{2}-\d{2}$/.test(s.liveDate))throw Error('Planogram source date unsupported');
 if(!Number.isFinite(s.nominalWidthFt)||s.nominalWidthFt<=0||s.nominalWidthFt>200||!Number.isSafeInteger(s.nominalFourFootSections)||s.nominalFourFootSections!==Math.ceil(s.nominalWidthFt/4)||s.nominalFourFootSections>50)throw Error('Invalid source length and four-foot section count');
 validText(s.widthEvidence,550);
 const segments=data.sourceSegments,rows=data.placements;
 if(!Array.isArray(segments)||segments.length>80||!Array.isArray(rows)||rows.length>3500)throw Error('Planogram lists too large');
 const knownSegments=new Set();for(const x of segments){fields(x,['id','ordinal','fixtureType','description'],['id','ordinal']);let id=validText(x.id,70);if(knownSegments.has(id))throw Error('Duplicate source section');knownSegments.add(id)}
 const ids=new Set();let merchandise=0,excluded=0,unresolved=0;const merchandiseSkus=new Set(),sourceRows=[];
 for(const row of rows){fields(row,['sourceRowId','sku','upcOrGtin','description','sourceSegment','fixtureType','reportRow','reportColumn','fixtureLabel','fixtureZone','facings','sourcePage','membershipDisposition'],['sourceRowId','membershipDisposition']);
  const id=validText(row.sourceRowId,80);if(ids.has(id))throw Error('Duplicate source row');ids.add(id);
  if(row.sourceSegment!=null&&!knownSegments.has(row.sourceSegment))throw Error('Unknown source segment');
  if(row.upcOrGtin!=null&&!checkDigit(row.upcOrGtin))throw Error('Source GTIN check failed');
  if(row.fixtureZone!=null&&!['LFT','CL','CTR','CR','RGT'].includes(row.fixtureZone))throw Error('Source fixture zone unsupported');
  if(!['PEG','SHELF','SPCFIX','OTHER','UNKNOWN'].includes(row.fixtureType))throw Error('Invalid fixture');
  if(row.membershipDisposition==='MERCHANDISE'){
   let sku=validText(row.sku,80);if(row.fixtureType==='PEG'&&(row.reportRow==null||row.reportColumn==null))throw Error('Missing official peg ROW/COL');merchandise++;merchandiseSkus.add(sku);sourceRows.push(row);
  }else if(row.membershipDisposition==='NON_MERCHANDISE')excluded++;
  else if(row.membershipDisposition==='UNRESOLVED')unresolved++;
  else throw Error('Invalid source membership');
 }
 const r=fields(data.reconciliation,['sourceReportRows','submittedRowRecords','merchandiseRows','excludedNonMerchandiseRows','unresolvedRows','distinctMerchandiseSkus','unrepresentedRows'],['sourceReportRows','submittedRowRecords','merchandiseRows','excludedNonMerchandiseRows','unresolvedRows','distinctMerchandiseSkus','unrepresentedRows']);
 for(const k of Object.keys(r))count(r,k);
 if(r.sourceReportRows!==rows.length+r.unrepresentedRows||r.submittedRowRecords!==rows.length||r.merchandiseRows!==merchandise||r.excludedNonMerchandiseRows!==excluded||r.unresolvedRows!==unresolved||r.distinctMerchandiseSkus!==merchandiseSkus.size)throw Error('Planogram source counts do not reconcile');
 for(const [list,k] of [[data.exclusions,'NON_MERCHANDISE'],[data.unresolved,'UNRESOLVED']]){
  if(!Array.isArray(list)||list.length!==rows.filter(row=>row.membershipDisposition===k).length)throw Error('Exception count differs');
  const seen=new Set();for(const x of list){fields(x,['sourceRowId','reason','sourcePage','evidence'],['sourceRowId','reason']);let id=validText(x.sourceRowId,80);validText(x.reason,320);
   if(seen.has(id)||!rows.some(row=>row.sourceRowId===id&&row.membershipDisposition===k))throw Error('Unreconciled exception row');seen.add(id)}
 }
 const m=fields(data.manifest,['submissionId','expectedChunks','sourceDigest','status'],['submissionId','expectedChunks','sourceDigest','status']);
 if(!Number.isSafeInteger(m.expectedChunks)||m.expectedChunks<1||m.expectedChunks>64||!String(m.submissionId).trim()||m.submissionId.length>80||!['COMPLETE','INCOMPLETE'].includes(m.status))throw Error('Manifest invalid');
 if(m.status==='COMPLETE'&&r.unrepresentedRows!==0)throw Error('Incomplete source report');
 if(typeof m.sourceDigest!=='string'||!/^[a-f0-9]{64}$/.test(m.sourceDigest))throw Error('Missing verified source digest');
 return{sourceRows,source:r,distinctMerchandiseSkus:merchandiseSkus.size,hasUnresolved:unresolved>0||r.unrepresentedRows>0};
}
function canonical(data){
 const x={schemaVersion:data.schemaVersion,source:data.source,sourceSegments:data.sourceSegments,placements:data.placements,reconciliation:data.reconciliation,exclusions:data.exclusions,unresolved:data.unresolved,manifest:data.manifest};
 // Canonical JSON field order comes from the normalized server validator. Ensure
 // digest and transport chunk count never become part of source identity.
 const y=JSON.parse(JSON.stringify(x));y.manifest.sourceDigest=null;y.manifest.expectedChunks=1;
 return JSON.stringify(y);
}
async function verify(data){const result=validate(data);
 if(!globalThis.crypto?.subtle)throw Error('Secure WebCrypto unavailable: refuse import');
 const digest=await globalThis.crypto.subtle.digest('SHA-256',new TextEncoder().encode(canonical(data)));
 const hex=[...new Uint8Array(digest)].map(x=>x.toString(16).padStart(2,'0')).join('');
 if(hex!==data.manifest.sourceDigest)throw Error('Planogram payload digest mismatch');
 return {...result,digest:hex};
}
function stageSource(data){
 // This creates only official-source records, not any invented physical location.
 const skus=new Map();for(const r of data.placements.filter(p=>p.membershipDisposition==='MERCHANDISE')){
  const existing=skus.get(r.sku)||{skuKey:r.sku,upcKey:r.upcOrGtin??null,sourceRowIds:[],positions:[]};
  existing.sourceRowIds.push(r.sourceRowId);
  existing.positions.push({sourceSegment:r.sourceSegment,sourceRow:r.reportRow,sourceColumn:r.reportColumn,fixtureType:r.fixtureType,fixtureZone:r.fixtureZone??null,sourcePage:r.sourcePage});
  if(!existing.upcKey&&r.upcOrGtin)existing.upcKey=r.upcOrGtin;
  skus.set(r.sku,existing);
 }
 return [...skus.values()];
}
return Object.freeze({validate,verify,stageSource,canonical});
})();
