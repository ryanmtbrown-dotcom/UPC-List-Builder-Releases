# Work Sessions Directory Ownership

OWNS: Work Session persistence facade, workflow service, saved-session controller, and list-item interaction.

DOES NOT OWN: DSD/MISC domain rules, catalog persistence, raw IndexedDB mechanics beyond the dedicated repository, or native platform behavior.

STATE RULE: WorkSessionService is the workflow-facing mutation boundary; WorkSessionRepository alone adapts the physical `lists` store. The View Planogram list-type choice is a session-only routing exception: start the existing Explorer without creating a saved list or writing to `lists`.
