/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/work-sessions/list-item-controller.js
 * Owner: Work Session Item Interaction
 * Role: Controller
 * Responsibility: Owns shared list-item add/edit/remove interaction and presentation across supported Work Session types, delegating domain-specific behavior where required.
 * Does not own: Physical list persistence, DSD/MISC domain rules, catalog mutation, or lookup policy.
 * Side effects: Mutates list/item DOM and calls injected Work Session/domain controllers.
 * Related code: Session persistence belongs to WorkSessionService; DSD/MISC special rules remain with those domains.
 */
const UPCListItemController=(()=>{
 function create({
  elementById,queryAll,getCurrent,getPending,fieldSessionController,miscWorkspaceProvider,
  itemPresentationController,identifierKeypadProvider,primaryPurposeTags,parseMoney,escapeHtml,
  aceNetPriceCheckEnabled,diagnostic,messageUser,miscType='ACE_NEW_ITEMS_MISC'
 }={}){
  if(typeof elementById!=='function'||typeof queryAll!=='function'||typeof getCurrent!=='function'||typeof getPending!=='function')throw new Error('List Item Controller view/state dependencies are incomplete.');
  if(!fieldSessionController||typeof miscWorkspaceProvider!=='function'||!itemPresentationController||typeof diagnostic!=='function')throw new Error('List Item Controller workflow dependencies are incomplete.');
  const $=elementById,diag=diagnostic,esc=escapeHtml,primaryTags=Array.isArray(primaryPurposeTags)?primaryPurposeTags:[];
  const editableFields=[['description','Description','text'],['sku','SKU','text'],['upc','UPC','numeric'],['libraryPrice','Library Price','money'],['labelPrice','Label Price','money'],['orderMultiple','Order Multiple','numeric'],['retailUnits','Retail Units','numeric'],['primaryPurpose','Primary Purpose','purpose'],['duplicateItem','Duplicate Item Tag','duplicate'],['missingLabel','Missing Label','duplicate']];
  let editItemIndex=-1;

  async function addPending(options={}){
   const current=getCurrent(),pending=getPending();
   if(current?.sessionType===miscType){
    if(!pending?.upc){diag('add_to_list_blocked',{reason:'no_pending_item'});return}
    try{const added=await miscWorkspaceProvider().addPendingItem(pending,{labelPrice:$('labelPrice')?.value||''});if(added.status==='DUPLICATE'){diag('duplicate_add_blocked',{listId:current.id,sku:pending.sku||null,upc:pending.upc||null,existingItemId:added.duplicate?.id||null});itemPresentationController.showDuplicateBlockedModal();return added}$('itemCount').textContent=String(added.count);$('status').textContent='Added to list';$('addToList').disabled=true;renderList();return added}
    catch(e){diag('ace_misc_item_add_failed',{sku:pending.sku||null,upc:pending.upc||null,message:e?.message||String(e)});await messageUser(`Could not add ACE MISC item: ${e?.message||e}`,'ACE MISC Add Failed');return null}
   }
   return fieldSessionController.addPending(options);
  }
  function openItemEditor(index){const current=getCurrent();if(!current||!current.items[index])return;editItemIndex=index;const sel=$('editItemField');sel.innerHTML=editableFields.map(([k,l])=>`<option value="${esc(k)}">${esc(l)}</option>`).join('');$('editItemStepChoose').classList.remove('hidden');$('editItemStepValue').classList.add('hidden');$('editItemTitle').textContent=current.items[index].description||current.items[index].upc||'List item';$('editItemOverlay').classList.remove('hidden');diag('item_edit_opened',{index,upc:current.items[index].upc})}
  function closeItemEditor(){$('editItemOverlay')?.classList.add('hidden');editItemIndex=-1}
  function showEditValueStep(){
   const item=getCurrent()?.items?.[editItemIndex],key=$('editItemField')?.value;if(!item||!key)return;const meta=editableFields.find(x=>x[0]===key),old=fieldSessionController.editFieldCurrentValue(item,key),input=$('editItemValue'),select=$('editItemSelectValue');
   $('editItemOldValue').textContent=old||'—';$('editItemFieldName').textContent=meta?.[1]||key;input.classList.add('hidden');select.classList.add('hidden');
   if(meta?.[2]==='purpose'){select.innerHTML=primaryTags.map(v=>`<option value="${esc(v)}"${v===old?' selected':''}>${esc(v)}</option>`).join('');select.classList.remove('hidden')}
   else if(meta?.[2]==='duplicate'){select.innerHTML=`<option value="Yes"${old==='Yes'?' selected':''}>Yes</option><option value="No"${old==='No'?' selected':''}>No</option>`;select.classList.remove('hidden')}
   else if(key==='sku'||key==='upc'){input.value=old;input.inputMode='none';input.readOnly=true;input.classList.remove('hidden');setTimeout(()=>identifierKeypadProvider()?.open?.({title:`Enter ${meta?.[1]||key}`,context:'Edit list item',value:old,maxLength:14,onAccept:async raw=>{input.value=raw;await saveItemEdit()}}),30)}
   else{input.readOnly=false;input.value=old;input.inputMode=meta?.[2]==='money'?'decimal':meta?.[2]==='numeric'?'numeric':'text';input.classList.remove('hidden');setTimeout(()=>input.focus(),50)}
   $('editItemStepChoose').classList.add('hidden');$('editItemStepValue').classList.remove('hidden');
  }
  async function saveItemEdit(){
   const current=getCurrent(),item=current?.items?.[editItemIndex],key=$('editItemField')?.value;if(!item||!key)return;const meta=editableFields.find(x=>x[0]===key),raw=(meta?.[2]==='purpose'||meta?.[2]==='duplicate')?$('editItemSelectValue').value:$('editItemValue').value.trim();
   try{
    if(current.sessionType===miscType)await miscWorkspaceProvider().editItemField(editItemIndex,key,raw);else await fieldSessionController.editItemField(editItemIndex,key,raw);
    renderList();$('editItemStepValue').classList.add('hidden');$('editItemStepChoose').classList.remove('hidden');
   }catch(e){diag(current.sessionType===miscType?'ace_misc_item_edit_failed':'item_edit_failed',{index:editItemIndex,field:key,message:e?.message||String(e)});await messageUser(e?.message||String(e),current.sessionType===miscType?'ACE MISC Edit Failed':'Item Edit Failed')}
  }
  function requestRemoveListItem(index){const item=getCurrent()?.items?.[index];if(!item)return;$('deleteItemName').textContent=item.description||item.upc||'this item';$('confirmDeleteItem').dataset.index=String(index);$('deleteItemOverlay').classList.remove('hidden')}
  async function removeListItem(index){
   const current=getCurrent();if(!current||index<0||index>=current.items.length)return;
   try{const removed=current.sessionType===miscType?await miscWorkspaceProvider().removeItem(index):await fieldSessionController.removeItem(index);$('itemCount').textContent=String(current.items.length);$('deleteItemOverlay')?.classList.add('hidden');renderList();if(current.sessionType===miscType)diag('item_removed',{upc:removed?.upc,index,listId:current.id,workspace:'ACE_NEW_ITEMS_MISC'});return removed}
   catch(e){diag(current.sessionType===miscType?'ace_misc_item_remove_failed':'item_remove_failed',{index,message:e?.message||String(e)});await messageUser(e?.message||String(e),current.sessionType===miscType?'ACE MISC Delete Failed':'Delete Failed');return null}
  }
  function renderList(){
   const current=getCurrent();if(!current)return;$('listViewName').textContent=current.name;
   $('rows').innerHTML=current.items.length?current.items.map((x,i)=>{const lib=UPCPriceAuthority.observedPrice(x),lab=parseMoney(x.labelPrice),diff=(lib!=null&&lab!=null)?lab-lib:null,thirdParty=x.recordOrigin==='THIRD_PARTY_VENDOR',externalPrice=thirdParty?parseMoney(x.aceNetPrice):UPCPriceAuthority.observedAceNetPrice(x);return `<article class="record recordRow"><div class="recordMain"><strong>${esc(x.description||x.upc)}</strong><small>${esc(x.sku?`SKU ${x.sku} · `:'')}${esc(x.upc)} · ${esc(x.lookupStatus==='NOT_FOUND'?'Not Found':'Found')}</small><div class="recordPriceLine"><span>Library <b>${lib==null?'—':'$'+lib.toFixed(2)}</b></span>${aceNetPriceCheckEnabled()?`<span>${thirdParty?'Vendor':'AceNet'} <b>${externalPrice==null?'—':'$'+externalPrice.toFixed(2)}</b></span>`:''}<span>Label <b>${lab==null?'—':'$'+lab.toFixed(2)}</b></span>${diff==null?'':`<span class="${Math.abs(diff)<.005?'match':'difference'}">Δ <b>${diff>=0?'+':'−'}$${Math.abs(diff).toFixed(2)}</b></span>`}</div>${(x.tags||[]).length?`<span class="recordTags">${x.tags.map(t=>`<b class="${(x.supplementalPurposes||[]).includes(t)||t==='Duplicate Item'?'supplemental':''}">${esc(t)}</b>`).join('')}</span>`:''}</div><div class="recordActions"><button type="button" class="editItem" data-edit="${i}" aria-label="Edit ${esc(x.description||x.upc)}" title="Edit"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 17.25V20h2.75L17.81 8.94l-2.75-2.75L4 17.25ZM19.71 7.04a1 1 0 0 0 0-1.41l-1.34-1.34a1 1 0 0 0-1.41 0l-1.05 1.05 2.75 2.75 1.05-1.05Z"/></svg></button><button type="button" class="deleteItem" data-remove="${i}" aria-label="Delete ${esc(x.description||x.upc)}" title="Delete"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 3h8l1 2h4v2H3V5h4l1-2Zm-2 6h12l-1 12H7L6 9Zm3 2v7h2v-7H9Zm4 0v7h2v-7h-2Z"/></svg></button></div></article>`}).join(''):'<div class="record emptyRecord"><small>No items added yet.</small></div>';
   queryAll('[data-edit]').forEach(b=>b.onclick=()=>openItemEditor(Number(b.dataset.edit)));queryAll('[data-remove]').forEach(b=>b.onclick=()=>requestRemoveListItem(Number(b.dataset.remove)));
  }
  function bind({on,showScreen,goBack}={}){
   if(typeof on!=='function')throw new Error('List Item Controller requires the shared event binder.');
   on('addToList','click',()=>void addPending());on('markMissingLabel','click',()=>void fieldSessionController.addPending({missingLabel:true}));const view=$('viewItems');if(view)view.onclick=()=>{renderList();showScreen('listScreen','Current List')};const back=$('listBack');if(back)back.onclick=()=>goBack('screen_back');
   const close=$('closeEditItem');if(close)close.onclick=closeItemEditor;const next=$('editItemNext');if(next)next.onclick=showEditValueStep;const editBack=$('editItemBack');if(editBack)editBack.onclick=()=>{$('editItemStepValue').classList.add('hidden');$('editItemStepChoose').classList.remove('hidden')};
   const save=$('editItemSave');if(save)save.onclick=()=>void saveItemEdit();const done=$('editItemDone');if(done)done.onclick=closeItemEditor;const cancel=$('cancelDeleteItem');if(cancel)cancel.onclick=()=>$('deleteItemOverlay').classList.add('hidden');const confirm=$('confirmDeleteItem');if(confirm)confirm.onclick=()=>void removeListItem(Number(confirm.dataset.index));
  }
  return Object.freeze({bind,addPending,renderList,openItemEditor,closeItemEditor,showEditValueStep,saveItemEdit,removeListItem,requestRemoveListItem});
 }
 return Object.freeze({create});
})();
window.UPCListItemController=UPCListItemController;
