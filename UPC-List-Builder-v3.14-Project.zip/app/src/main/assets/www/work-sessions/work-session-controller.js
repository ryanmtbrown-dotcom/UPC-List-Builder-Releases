/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/work-sessions/work-session-controller.js
 * Owner: Work Session UI/Workflow
 * Role: Controller
 * Responsibility: Owns active/saved Work Session creation/open/delete/summary UI, current-session identity, and coordination of session-level navigation/persistence.
 * Does not own: Raw lists-store access, feature-specific item rules, catalog persistence, or native platform behavior.
 * Side effects: Mutates session UI/current in-memory session and persists through WorkSessionService.
 * Related code: Physical persistence belongs to work-session-repository.js; domain controllers own their session payload semantics.
 */
const UPCWorkSessionController=(()=>{
 function create({
  elementById,service,fieldTags,newId,sessionName,escapeHtml,dsdListName,
  dsdType='ACE_NEW_DSD_ITEMS',miscType='ACE_NEW_ITEMS_MISC',fieldType='FIELD_SESSION',explorerType='VIEW_PLANOGRAM',
  dsdWorkspaceProvider,explorerProvider,presentationProvider,settingsProvider,onSessionChanged,
  diagnostic,startOperation,finishOperation,showScreen,goBack,confirmUser,alertUser
 }={}){
  if(typeof elementById!=='function'||!service)throw new Error('Work Session Controller state dependencies are incomplete.');
  if(typeof newId!=='function'||typeof sessionName!=='function'||typeof escapeHtml!=='function')throw new Error('Work Session Controller utility dependencies are incomplete.');
  if(typeof diagnostic!=='function'||typeof startOperation!=='function'||typeof finishOperation!=='function')throw new Error('Work Session Controller diagnostic dependencies are incomplete.');
  if(typeof showScreen!=='function'||typeof goBack!=='function'||typeof confirmUser!=='function'||typeof alertUser!=='function')throw new Error('Work Session Controller interaction dependencies are incomplete.');
  const $=elementById,diag=diagnostic,tags=Array.isArray(fieldTags)?fieldTags:[];
  let current=null,savedListCache=[];
  function getCurrent(){return current}
  function setCurrent(value){current=value;return current}

  async function saveCurrent(){
   const current=getCurrent();if(!current)return;await service.save(current);
  }
  function saveCurrentSafe(){saveCurrent().catch(e=>diag('list_save_failed',{name:e?.name,message:e?.message,stack:e?.stack}))}
  function syncNewListTypeUI(){
   const type=$('newListType')?.value,misc=type===miscType,dsd=type===dsdType,explorer=type===fieldType&&$('defaultPurpose')?.value===explorerType,special=misc||dsd;
   $('defaultPurpose')?.classList.toggle('hidden',special);$('defaultPurposeLabel')?.classList.toggle('hidden',special);$('defaultPurposeHelp')?.classList.toggle('hidden',special||explorer);
   $('aceMiscHelp')?.classList.toggle('hidden',!misc);$('aceDsdHelp')?.classList.toggle('hidden',!dsd);$('planogramSessionHelp')?.classList.toggle('hidden',!explorer);
   const intro=$('newSessionIntro');if(intro)intro.textContent=explorer?'Browse official Ace planograms or physical store layouts. Viewing does not create a list.':'The session is named automatically from today’s Alaska date. Start the field session. Tags are selected per item before adding it.';if($('nextName'))$('nextName').textContent=explorer?'Start Viewing':'Start Session';
  }
  function syncActiveListTypeUI(){
   onSessionChanged?.();const misc=getCurrent()?.sessionType===miscType;$('tagPanel')?.classList.toggle('hidden',misc);$('listSettings')?.classList.toggle('hidden',misc);$('aceMiscSearchUpcs')?.classList.toggle('hidden',!misc);
   if(!misc){const st=$('aceMiscUpcSearchStatus');if(st){st.textContent='';st.classList.add('hidden')}}
  }
  async function refreshSummary(){
   const lists=await service.list(),el=$('savedListSummary');if(el)el.textContent=lists.length?`${lists.length} saved list${lists.length===1?'':'s'}`:'No saved lists yet';return lists.length;
  }
  async function startNamedList(){
   if($('newListType')?.value===dsdType){dsdWorkspaceProvider()?.startNew?.();return}
   if($('newListType')?.value===fieldType&&$('defaultPurpose')?.value===explorerType){
    try{const explorer=explorerProvider?.();if(typeof explorer?.open!=='function')throw Error('Planogram Explorer is unavailable');
     await explorer.open();diag('planogram_explorer_session_started',{createdList:false});return null;
    }catch(e){diag('planogram_explorer_session_failed',{name:e?.name,message:e?.message});alertUser('The Planogram Explorer could not open. Please try again.');return null}
   }
   const listOp=`LIST_MANAGEMENT:${Date.now()}:${Math.random().toString(36).slice(2,8)}`;startOperation('LIST_MANAGEMENT',listOp,'Create and persist a new working list.','A uniquely identified list is written to IndexedDB before it becomes the active builder list.',{});
   const listType=$('newListType')?.value===miscType?miscType:fieldType,baseName=sessionName(),name=listType===miscType?`ACE New Items MISC. · ${baseName}`:baseName,now=new Date().toISOString();
   const selectedDefault=listType===miscType?null:(tags.includes($('defaultPurpose')?.value)?$('defaultPurpose').value:'Price Change'),priceChangeDefaults=listType===fieldType&&selectedDefault==='Price Change';
   const current={id:newId(),name,createdAt:now,updatedAt:now,defaultTag:selectedDefault,sessionType:listType,items:[],captures:[],promptLabelPriceAfterScan:priceChangeDefaults,autoAddPriceDifference:priceChangeDefaults};
   setCurrent(current);
   try{
    await service.create(current);$('activeListName').textContent=name;$('itemCount').textContent='0';$('upc').value='';$('status').textContent='';
    presentationProvider()?.resetPreview?.();settingsProvider()?.syncManualPriceVisibility?.();syncActiveListTypeUI();
    diag('list_created',{id:current.id,name,defaultTag:current.defaultTag,promptLabelPriceAfterScan:current.promptLabelPriceAfterScan,autoAddPriceDifference:current.autoAddPriceDifference});finishOperation(listOp,`Created list ${name} with 0 items.`,'PASS',{listId:current.id,name,sessionType:current.sessionType,itemCount:0,defaultTag:current.defaultTag,promptLabelPriceAfterScan:current.promptLabelPriceAfterScan,autoAddPriceDifference:current.autoAddPriceDifference});
    showScreen('builder',name);await refreshSummary();return current;
   }catch(e){
    setCurrent(null);finishOperation(listOp,`List creation failed: ${e?.message||e}.`,'FAIL',{name:e?.name||null,message:e?.message||String(e)});diag('list_create_failed',{name:e?.name,message:e?.message,stack:e?.stack});alertUser('The list could not be created. Please try again.');return null;
   }
  }
  async function openListById(id){
   try{
    const list=await service.open(id);if(!list){diag('list_open_failed',{id,reason:'not_found'});return null}
    if(!Array.isArray(list.items))list.items=[];if(typeof list.promptLabelPriceAfterScan!=='boolean')list.promptLabelPriceAfterScan=false;if(typeof list.autoAddPriceDifference!=='boolean')list.autoAddPriceDifference=false;
    if(!tags.includes(list.defaultTag))list.defaultTag='Price Change';setCurrent(list);
    $('activeListName').textContent=list.name||'Untitled List';$('itemCount').textContent=String(list.items.length);$('upc').value='';$('status').textContent='';
    presentationProvider()?.resetPreview?.();settingsProvider()?.syncManualPriceVisibility?.();syncActiveListTypeUI();diag('list_opened',{id:list.id,name:list.name,count:list.items.length});
    if(list.sessionType===dsdType){dsdWorkspaceProvider()?.openExisting?.();return list}
    showScreen('builder',list.name||'Build List');return list;
   }catch(e){diag('list_open_failed',{id,name:e?.name,message:e?.message,stack:e?.stack});return null}
  }
  function formatAlaskaCreated(value){
   const date=value?new Date(value):null;if(!date||Number.isNaN(date.getTime()))return 'Creation time unavailable';
   return new Intl.DateTimeFormat('en-US',{timeZone:'America/Anchorage',month:'short',day:'numeric',year:'numeric',hour:'numeric',minute:'2-digit',timeZoneName:'short'}).format(date);
  }
  function savedListPurpose(x){if(x?.sessionType===miscType)return 'ACE New Items MISC.';if(x?.sessionType===dsdType)return 'ACE New DSD Items';const purpose=String(x?.defaultTag||'').trim();return purpose||'Field Session'}
  function displayName(x){return x?.sessionType===dsdType&&typeof dsdListName==='function'?dsdListName(x.dsdInvoice):savedListPurpose(x)}
  function savedListMarkup(x){
   const count=Array.isArray(x.items)?x.items.length:0,purpose=savedListPurpose(x),dsd=x.sessionType===dsdType,created=formatAlaskaCreated(x.createdAt||x.updatedAt),esc=escapeHtml;
   const name=displayName(x),details=dsd?name.replace(/^ACE New DSD Items(?: · )?/,'')||'Invoice details needed':created;
   return `<article class="savedListCard${dsd?' savedListDsd':''}" data-list-id="${esc(x.id)}"><button type="button" class="savedListOpen" data-open="${esc(x.id)}" aria-label="Open ${esc(dsd?name:purpose+' list created '+created)}"><span class="savedListDoc" aria-hidden="true">▤</span><span class="savedListCopy"><strong>${esc(purpose)}</strong><span class="savedListCreated">${esc(details)}</span><span class="savedListCount">▥&nbsp; ${count} item${count===1?'':'s'}</span></span><span class="savedListChevron" aria-hidden="true">›</span></button><button type="button" class="savedListDelete" data-delete="${esc(x.id)}" data-name="${esc(name)}" aria-label="Delete ${esc(purpose)} list"><svg class="trashIcon" viewBox="0 0 24 24" aria-hidden="true"><path d="M8 3h8l1 2h4v2H3V5h4l1-2Zm-2 6h12l-1 12H7L6 9Zm3 2v7h2v-7H9Zm4 0v7h2v-7h-2Z" fill="currentColor"/></svg></button></article>`;
  }
  function renderSavedLists(filter=''){
   const q=String(filter||'').trim().toLocaleLowerCase(),lists=q?savedListCache.filter(x=>`${displayName(x)} ${x.name||''} ${x.sessionType===dsdType?'':formatAlaskaCreated(x.createdAt||x.updatedAt)}`.toLocaleLowerCase().includes(q)):savedListCache;
   $('savedLists').innerHTML=lists.length?lists.map(savedListMarkup).join(''):`<div class="savedListsEmpty"><strong>${savedListCache.length?'No matching lists':'No saved lists yet'}</strong><span>${savedListCache.length?'Try a different search.':'Create a list and it will appear here automatically.'}</span></div>`;
  }
  async function openLists(){
   const listOp=`LIST_PERSISTENCE:${Date.now()}:${Math.random().toString(36).slice(2,8)}`;startOperation('LIST_PERSISTENCE',listOp,'Load saved lists from persistent application storage.','All persisted lists are read from IndexedDB and presented newest-first without mutating their contents.',{});
   savedListCache=(await service.list()).sort((a,b)=>String(b.createdAt||b.updatedAt||'').localeCompare(String(a.createdAt||a.updatedAt||'')));$('listSearch').value='';renderSavedLists();
   diag('open_list_screen_loaded',{count:savedListCache.length});finishOperation(listOp,`Loaded ${savedListCache.length} saved list(s) from IndexedDB.`,'PASS',{count:savedListCache.length});showScreen('openScreen','Open List');
  }
  async function deleteSavedList(id,name){
   if(!id)return false;const ok=await confirmUser(`Delete “${name||'this list'}”?\n\nThis permanently deletes the saved list and its items.`,'Delete Saved List',{okLabel:'Delete'});
   if(!ok){diag('list_delete_cancelled',{id});return false}
   try{
    await service.remove(id);if(getCurrent()?.id===id)setCurrent(null);savedListCache=savedListCache.filter(x=>x.id!==id);renderSavedLists($('listSearch').value);await refreshSummary();diag('list_deleted',{id,name});return true;
   }catch(e){diag('list_delete_failed',{id,name:e?.name,message:e?.message});alertUser('The list could not be deleted. Please try again.');return false}
  }
  function beginNewSession(){
   const date=$('newSessionDate');if(date)date.textContent=sessionName();if($('defaultPurpose'))$('defaultPurpose').value='Price Change';if($('newListType'))$('newListType').value=fieldType;syncNewListTypeUI();showScreen('nameScreen','New Session');
  }
  function bind({on}={}){
   if(typeof on!=='function')throw new Error('Work Session Controller requires the shared event binder.');
   on('savedLists','click',e=>{const del=e.target.closest('[data-delete]');if(del){void deleteSavedList(del.dataset.delete,del.dataset.name);return}const card=e.target.closest('[data-open]');if(card)void openListById(card.dataset.open)});
   on('listSearch','input',e=>renderSavedLists(e.target.value));
   const open=$('openList');if(open)open.onclick=()=>void openLists();
   const back=$('openBack');if(back)back.onclick=()=>goBack('screen_back');
      const build=$('buildList');if(build)build.onclick=beginNewSession;
   const cancel=$('cancelName');if(cancel)cancel.onclick=()=>goBack('screen_back');
   on('newListType','change',syncNewListTypeUI);on('defaultPurpose','change',syncNewListTypeUI);
   const next=$('nextName');if(next)next.onclick=()=>void startNamedList();
  }
  return Object.freeze({bind,getCurrent,setCurrent,saveCurrent,saveCurrentSafe,syncNewListTypeUI,syncActiveListTypeUI,refreshSummary,startNamedList,openListById,renderSavedLists,openLists,deleteSavedList,beginNewSession});
 }
 return Object.freeze({create});
})();
window.UPCWorkSessionController=UPCWorkSessionController;
