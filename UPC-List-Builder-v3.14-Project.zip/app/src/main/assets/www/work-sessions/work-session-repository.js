/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/work-sessions/work-session-repository.js
 * Owner: Work Session Persistence
 * Role: Repository adapter
 * Responsibility: Owns physical CRUD adaptation for the IndexedDB `lists` store.
 * Does not own: Session workflow rules, UI, migrations, DSD/MISC semantics, or catalog persistence.
 * Side effects: Direct UPCDB list-store CRUD only.
 * Related code: All workflow callers use WorkSessionService rather than direct UPCDB list access.
 */
const UPCWorkSessionRepository=(()=>{
 const STORE='lists';
 const list=()=>UPCDB.all(STORE);
 const get=id=>UPCDB.get(STORE,id);
 const put=session=>UPCDB.put(STORE,session);
 const remove=id=>UPCDB.remove(STORE,id);
 return Object.freeze({list,get,put,remove});
})();
window.UPCWorkSessionRepository=UPCWorkSessionRepository;
