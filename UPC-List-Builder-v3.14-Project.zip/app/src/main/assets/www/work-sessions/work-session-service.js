/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/work-sessions/work-session-service.js
 * Owner: Work Session Domain Boundary
 * Role: Workflow-facing service
 * Responsibility: Owns normalized Work Session CRUD semantics exposed to controllers/domains over the repository adapter.
 * Does not own: UI, raw IndexedDB, feature-specific DSD/MISC rules, or migration policy.
 * Side effects: Reads/writes sessions through WorkSessionRepository only.
 * Related code: Physical storage belongs to work-session-repository.js; migrations belong to migration-repository.js.
 */
const UPCWorkSessionService=(()=>{
 const nowIso=()=>new Date().toISOString();
 const requireSession=session=>{
  if(!session||typeof session!=='object')throw new TypeError('Work session must be an object.');
  if(!String(session.id||'').trim())throw new Error('Work session requires an id.');
  return session;
 };
 async function list(){return UPCWorkSessionRepository.list()}
 async function open(id){const key=String(id??'').trim();return key?UPCWorkSessionRepository.get(key):null}
 async function create(session){
  requireSession(session);
  const now=nowIso();
  if(!session.createdAt)session.createdAt=now;
  if(!session.updatedAt)session.updatedAt=session.createdAt||now;
  await UPCWorkSessionRepository.put(session);
  return session;
 }
 async function save(session,{touch=true}={}){
  requireSession(session);
  if(touch)session.updatedAt=nowIso();
  await UPCWorkSessionRepository.put(session);
  return session;
 }
 async function remove(id){
  const key=String(id??'').trim();
  if(!key)return false;
  await UPCWorkSessionRepository.remove(key);
  return true;
 }
 return Object.freeze({list,open,create,save,remove});
})();
window.UPCWorkSessionService=UPCWorkSessionService;
