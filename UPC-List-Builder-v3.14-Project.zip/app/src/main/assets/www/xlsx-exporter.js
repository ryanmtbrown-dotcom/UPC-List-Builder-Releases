/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/xlsx-exporter.js
 * Owner: Shared XLSX Infrastructure
 * Role: Workbook writer
 * Responsibility: Owns generic XLSX workbook construction/serialization used by domain export owners.
 * Does not own: Domain row semantics; filenames; native/browser delivery; persistence.
 * Side effects: Builds workbook bytes in memory; no domain persistence.
 * Related code: Domain-specific export composition remains with DSD/MISC/Field/Combined Master owners.
 */
const XLSXExporter=(()=>{
 const MIME='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
 const esc=v=>String(v??'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
 const col=n=>{let s='';for(n++;n;n=Math.floor((n-1)/26))s=String.fromCharCode(65+(n-1)%26)+s;return s};
 const dateSerial=v=>{const d=new Date(v);return Number.isFinite(d.getTime())?d.getTime()/86400000+25569:null};
 const width=(header,values,maxWidth=42)=>Math.max(10,Math.min(maxWidth,Math.max(String(header).length,...values.map(v=>String(v??'').length))+2));
 async function build(headers,rows,options={}){
  if(typeof JSZip==='undefined')throw new Error('XLSX export engine unavailable.');
  const textCols=new Set(options.textColumns||[]),currencyCols=new Set(options.currencyColumns||[]),dateCols=new Set(options.dateColumns||[]),headerFillCols=new Set(options.headerFillColumns||[]),stripeRows=options.stripeRows===true,stripeLastColumn=Number.isInteger(options.stripeLastColumn)?options.stripeLastColumn:headers.length-1,maxColumnWidth=Number(options.maxColumnWidth)||42;
  const zip=new JSZip();
  zip.file('[Content_Types].xml',`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>`);
  zip.file('_rels/.rels',`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>`);
  zip.file('xl/workbook.xml',`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="${esc(options.sheetName||'UPC List')}" sheetId="1" r:id="rId1"/></sheets></workbook>`);
  zip.file('xl/_rels/workbook.xml.rels',`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>`);
  zip.file('xl/styles.xml',`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><numFmts count="2"><numFmt numFmtId="164" formatCode="$#,##0.00"/><numFmt numFmtId="165" formatCode="mm/dd/yyyy hh:mm"/></numFmts><fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><name val="Calibri"/></font></fonts><fills count="5"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FFFFFF00"/><bgColor indexed="64"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFE7E6E6"/><bgColor indexed="64"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFFFFFFF"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="1"><border/></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="8"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="4" borderId="0" xfId="0" applyFont="1" applyFill="1"/><xf numFmtId="164" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/><xf numFmtId="165" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/><xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1"/><xf numFmtId="0" fontId="0" fillId="3" borderId="0" xfId="0" applyFill="1"/><xf numFmtId="164" fontId="0" fillId="3" borderId="0" xfId="0" applyNumberFormat="1" applyFill="1"/><xf numFmtId="165" fontId="0" fillId="3" borderId="0" xfId="0" applyNumberFormat="1" applyFill="1"/></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>`);
  const cell=(v,c,r,header=false)=>{
   const ref=`${col(c)}${r}`;if(header)return `<c r="${ref}" t="inlineStr" s="${headerFillCols.has(c)?4:1}"><is><t>${esc(v)}</t></is></c>`;
   const gray=stripeRows&&r%2===1&&c<=stripeLastColumn;
   if(v===null||v===undefined||v==='')return `<c r="${ref}"${gray?' s="5"':''}/>`;
   if(dateCols.has(c)){const n=dateSerial(v);if(n!==null)return `<c r="${ref}" s="${gray?7:3}"><v>${n}</v></c>`}
   if(!textCols.has(c)&&Number.isFinite(Number(v)))return `<c r="${ref}"${currencyCols.has(c)?` s="${gray?6:2}"`:(gray?' s="5"':'')}><v>${Number(v)}</v></c>`;
   return `<c r="${ref}" t="inlineStr"${gray?' s="5"':''}><is><t xml:space="preserve">${esc(v)}</t></is></c>`;
  };
  const cols=headers.map((h,c)=>`<col min="${c+1}" max="${c+1}" width="${width(h,rows.map(r=>r[c]),maxColumnWidth)}" customWidth="1"/>`).join('');
  const body=[`<row r="1">${headers.map((h,c)=>cell(h,c,1,true)).join('')}</row>`,...rows.map((row,i)=>`<row r="${i+2}">${headers.map((_,c)=>cell(row[c],c,i+2)).join('')}</row>`)].join('');
  const last=`${col(Math.max(0,headers.length-1))}${rows.length+1}`;
  zip.file('xl/worksheets/sheet1.xml',`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><dimension ref="A1:${last}"/><sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><cols>${cols}</cols><sheetData>${body}</sheetData><autoFilter ref="A1:${last}"/></worksheet>`);
  return zip.generateAsync({type:'uint8array',compression:'DEFLATE',compressionOptions:{level:6}});
 }
 return{build,MIME};
})();
