/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/xlsx-importer.js
 * Owner: Shared XLSX Infrastructure
 * Role: Workbook parser
 * Responsibility: Owns generic XLSX cell/row parsing and explicit mapping continuation mechanics.
 * Does not own: Domain validation; catalog policy; persistence; UI workflow ownership.
 * Side effects: Parses uploaded workbook bytes/rows; no durable writes.
 * Related code: Domain import decisions remain with the calling workflow/domain owner.
 */
const XLSXImporter=(()=>{
 const cleanText=v=>String(v??'').replace(/[\u0000-\u001F\u007F\u00A0\u2000-\u200D\u2028\u2029\u202F\u205F\u2060\u3000\uFEFF]/g,' ').replace(/\s+/g,' ').trim();
 const headerKey=v=>cleanText(v).toLowerCase().replace(/[^a-z0-9]+/g,'');
 const normalizeUPC=UPCIdentifierNormalization.normalizeUPCUnicodeCompatible;
 function colIndex(ref){let n=0;for(const ch of (ref.match(/[A-Z]+/i)||[''])[0].toUpperCase())n=n*26+ch.charCodeAt(0)-64;return n-1}
 function cellValue(c,shared){const type=c.getAttribute('t'),v=c.getElementsByTagName('v')[0]?.textContent??'',inline=c.getElementsByTagName('is')[0];if(type==='s')return shared[Number(v)]??'';if(type==='inlineStr')return Array.from(inline?.getElementsByTagName('t')||[]).map(x=>x.textContent||'').join('');return v}
 function rowArray(row,shared){const out=[];for(const c of row.getElementsByTagName('c'))out[colIndex(c.getAttribute('r')||'A')]=cleanText(cellValue(c,shared));return out}
 async function importFile(file,progress){
  progress('Reading XLSX',2,`Opening ${file.name}`);
  const zip=await JSZip.loadAsync(file);
  const shared=[];
  const ss=zip.file('xl/sharedStrings.xml');
  if(ss){progress('Reading workbook',7,'Loading shared strings');const doc=new DOMParser().parseFromString(await ss.async('text'),'application/xml');for(const si of doc.getElementsByTagName('si'))shared.push(Array.from(si.getElementsByTagName('t')).map(x=>x.textContent||'').join(''))}
  let sheetPath='xl/worksheets/sheet1.xml';
  const wb=zip.file('xl/workbook.xml'),rels=zip.file('xl/_rels/workbook.xml.rels');
  if(wb&&rels){const wdoc=new DOMParser().parseFromString(await wb.async('text'),'application/xml'),first=wdoc.getElementsByTagName('sheet')[0],rid=first?.getAttribute('r:id')||first?.getAttributeNS('http://schemas.openxmlformats.org/officeDocument/2006/relationships','id');const rdoc=new DOMParser().parseFromString(await rels.async('text'),'application/xml');const rel=Array.from(rdoc.getElementsByTagName('Relationship')).find(x=>x.getAttribute('Id')===rid);if(rel){let t=rel.getAttribute('Target');sheetPath=t.startsWith('/')?t.slice(1):'xl/'+t.replace(/^\.\//,'')}}
  const sf=zip.file(sheetPath);if(!sf)throw new Error('Could not locate the first worksheet.');
  progress('Reading worksheet',12,'Parsing worksheet rows');
  const xml=await sf.async('text'),doc=new DOMParser().parseFromString(xml,'application/xml');
  const rows=Array.from(doc.getElementsByTagName('row'));if(!rows.length)throw new Error('Worksheet contains no rows.');
  const readRow=row=>rowArray(row,shared);
  // Header discovery: prefer an exact normalized UPC header; otherwise score dense, textual rows.
  const scanN=Math.min(rows.length,200),candidates=[];
  for(let i=0;i<scanN;i++){const vals=readRow(rows[i]),keys=vals.map(headerKey),non=vals.filter(Boolean);const upc=keys.findIndex(k=>k==='upc');const score=(upc>=0?10000:0)+non.length*10+non.filter(x=>/[A-Za-z]/.test(x)).length*4;candidates.push({i,vals,keys,upc,score})}
  let header=candidates.filter(x=>x.upc>=0).sort((a,b)=>b.score-a.score)[0]||candidates.sort((a,b)=>b.score-a.score)[0];
  if(!header||header.vals.filter(Boolean).length<2)throw new Error('Could not identify a usable header row.');
  const headers=header.vals.map((v,i)=>cleanText(v)||`Column ${i+1}`);
  let upcIndex=header.upc;
  const skuIndex=headers.findIndex(h=>['sku','ace sku','item sku','item number'].includes(String(h).trim().toLowerCase()));
  progress('Detecting columns',18,`Header row ${header.i+1} detected`);
  // If no exact UPC, return discovered headers for explicit mapping instead of guessing identifier semantics.
  if(upcIndex<0)return{needsUPCMapping:true,needsIdentifierMapping:true,headers,headerRow:header.i+1,rows,shared,sheetPath,sourceXML:xml,suggestedUPCIndex:-1,suggestedSKUIndex:skuIndex};
  const built=await build(rows,header.i,headers,upcIndex,readRow,progress);built.needsIdentifierMapping=true;built.suggestedUPCIndex=upcIndex;built.suggestedSKUIndex=skuIndex;built.sourcePayload={headers,headerRow:header.i+1,rows,shared,sheetPath,sourceXML:xml};return built;
 }
 async function build(rows,headerIdx,headers,upcIndex,readRow,progress){
   const records=[],total=Math.max(0,rows.length-headerIdx-1);
   for(let i=headerIdx+1;i<rows.length;i++){const vals=readRow(rows[i]);if(!vals.some(Boolean))continue;const original=vals[upcIndex]??'',upcKey=normalizeUPC(original);if(!upcKey)continue;const fields={};headers.forEach((h,j)=>fields[h]=vals[j]??'');records.push({upcKey,originalUPC:original,fields});if((i-headerIdx)%5000===0){progress('Preparing records',18+Math.round(((i-headerIdx)/Math.max(total,1))*32),`${(i-headerIdx).toLocaleString()} / ${total.toLocaleString()} rows`);await new Promise(r=>setTimeout(r,0))}}
   return{needsUPCMapping:false,headers,records,totalRows:total,validRecords:records.length,headerRow:headerIdx+1,upcIndex,upcHeader:headers[upcIndex]||'UPC'};
 }
 async function continueWithMapping(payload,upcIndex,progress){
   const doc=new DOMParser().parseFromString(payload.sourceXML,'application/xml'),rows=Array.from(doc.getElementsByTagName('row')),readRow=row=>rowArray(row,payload.shared);
   return build(rows,payload.headerRow-1,payload.headers,upcIndex,readRow,progress)
 }
 return{importFile,continueWithMapping,normalizeUPC,cleanText};
})();
