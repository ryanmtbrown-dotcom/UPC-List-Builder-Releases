/**
 * OWNERSHIP:
 * File: app/src/main/java/com/rmtb/upclistbuilder/AceNetProductionCoordinator.kt
 * Owner: Native AceNet Production
 * Role: Coordinator/state machine
 * Responsibility: Owns the interdependent native AceNet production/session request state machine: transient auth/readiness WebViews, session repair, retained-worker dispatch/recovery, and result coordination.
 * Does not own: Updater, file export, scanner, product-image search, persistent worker extraction internals, or diagnostic persistence.
 * Side effects: Creates/controls transient WebViews, invokes session/retrieval/incident services, emits bridge callbacks/diagnostics, and owns bounded recovery timers.
 * Related code: Credential/session persistence belongs to AceNetSessionManager; worker lifecycle belongs to AceNetRetrievalService; extraction belongs to PersistentAceNetWorker.
 */
package com.rmtb.upclistbuilder

import android.text.InputType
import android.widget.LinearLayout
import android.widget.EditText
import android.app.AlertDialog
import android.content.Context
import android.net.Uri
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Looper
import android.os.Message
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebResourceError
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject
import org.json.JSONArray

/**
 * Owns the cohesive native AceNet production/session state machine.
 *
 * Authentication/readiness, transient session-establishment WebViews, retained-worker dispatch
 * and recovery, request incident handling, and AceNet lifecycle reactions share one state machine.
 * AndroidNative registration, app updates, scanner, generic export, product images, and durable
 * diagnostic-journal storage remain outside this owner.
 *
 * ARCHITECTURE SIZE EXCEPTION: Stage 13 re-reviewed this owner below the hard 2,300-line ceiling.
 * AceNetSessionManager, AceNetRetrievalService, PersistentAceNetWorker,
 * AceNetProductionIncidentController, and AceNetRuntimeClassifier already isolate independent
 * state/behavior seams. The remaining authentication/readiness/request-recovery coordination
 * shares mutable lifecycle state; splitting it without a new independent state boundary would
 * create duplicate authority or callback races. Further extraction requires a proven independent
 * state, lifecycle, input/output, and error-recovery owner.
 */
class AceNetProductionCoordinator(
    private val activity: MainActivity,
    private val mainWebViewProvider: () -> WebView?,
    private val nativeDiagnosticJournal: NativeDiagnosticJournal
) {
    private var aceNetTestView: WebView? = null
    private var aceNetPersistentRetailerTemplate: String
        get() = aceNetSessionManager.retailerTemplate
        set(value) { aceNetSessionManager.retailerTemplate = value }
    private val aceNetWarmupSku = "50177"
    private var aceNetStartupRetailerBootstrapPending = false
    private var aceNetResultView: WebView? = null
    private var aceNetRetailerFallbackAttempted = false
    private var aceNetRequestId: String? = null
    private var aceNetRequestKind: String = "TEST"
    private data class PendingAceNetProductionRequest(val requestId:String,val sku:String,val mode:String)
    private var aceNetPendingProductionRequest: PendingAceNetProductionRequest? = null
    private val productionIncident = AceNetProductionIncidentController()
    private var aceNetSessionRepairOnly: Boolean = false
    private var aceNetSku: String = ""
    private var aceNetUser: String = ""
    private var aceNetPassword: String = ""
    private var aceNetPhase: String = "IDLE"
    private var aceNetAuthDeadlineMs: Long = 0L
    private var aceNetResultStartedMs: Long = 0L
    private var aceNetIframeFirstSeenMs: Long = 0L
    private var aceNetRetailerPromotionMs: Long = 0L
    private var aceNetLoginInspectionAttempts: Int = 0
    private var aceNetHomeInspectionAttempts: Int = 0
    private var aceNetStartedMs: Long = 0L
    private var aceNetHomeReadyMs: Long = 0L
    private var aceNetSearchInvokedMs: Long = 0L
    private var aceNetResolvedMs: Long = 0L
    private var aceNetProductImageUrl: String = ""
    private var aceNetProductImageScore: Int = 0
    private var aceNetProductImageWidth: Int = 0
    private var aceNetProductImageHeight: Int = 0
    private var aceNetLastHost: String = ""
    private var aceNetSessionAuthenticated: Boolean
        get() = aceNetSessionManager.authenticated
        set(value) { aceNetSessionManager.authenticated = value }
    private val aceNetResultHandler = android.os.Handler(android.os.Looper.getMainLooper())
    // Independent of WebView/result-handler cleanup: retries cannot cancel this cold-start ceiling.
    private val aceNetStartupReadinessHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private var aceNetStartupReadinessComplete = false
    private val aceNetStartupReadinessRunnable = Runnable {
        if (aceNetStartupOnly && !aceNetStartupResolved && !aceNetStartupReadinessComplete && aceNetRequestKind=="STARTUP_WARMUP") {
            aceNetNativeDiagnostic("startup_session_absolute_deadline_reached",JSONObject()
                .put("budgetMs",AceNetTimingPolicy.STARTUP_SESSION_READINESS_MS)
                .put("phase",aceNetPhase).put("retailerRetryAttempted",aceNetRetailerBootstrapRetryAttempted)
                .put("globalServerDownEvidence",false))
            completeAceNetStartupUnavailable("startup_session_absolute_deadline","AceNet could not establish the item session within 25 seconds. Library-only operation is available.")
        }
    }
    private fun beginAceNetStartupReadinessDeadline() {
        aceNetStartupReadinessComplete=false
        aceNetStartupReadinessHandler.removeCallbacks(aceNetStartupReadinessRunnable)
        aceNetStartupReadinessHandler.postDelayed(aceNetStartupReadinessRunnable,AceNetTimingPolicy.STARTUP_SESSION_READINESS_MS)
        aceNetNativeDiagnostic("startup_session_absolute_deadline_armed",JSONObject()
            .put("budgetMs",AceNetTimingPolicy.STARTUP_SESSION_READINESS_MS))
    }
    private fun releaseAceNetStartupReadinessDeadline() {
        aceNetStartupReadinessComplete=true
        aceNetStartupReadinessHandler.removeCallbacks(aceNetStartupReadinessRunnable)
    }
    private val aceNetStartupRetailerDeadlineRunnable = Runnable {
        if(aceNetStartupOnly && aceNetRequestKind=="STARTUP_WARMUP" && aceNetStartupRetailerBootstrapPending && aceNetPhase=="RETAILER_SSO"){
            aceNetNativeDiagnostic("startup_retailer_sso_deadline_reached",JSONObject()
                .put("elapsedMs",(System.currentTimeMillis()-aceNetStartedMs).coerceAtLeast(0L))
                .put("deadlineMs",AceNetTimingPolicy.STARTUP_SESSION_READINESS_MS)
                .put("authenticationPreserved",aceNetSessionAuthenticated).put("globalServerDownEvidence",false))
            aceNetStartupRetailerBootstrapPending=false
            completeAceNetStartupUnavailable("startup_retailer_sso_deadline","AceNet is signed in, but retailer sign-on did not complete within the startup session-readiness window. Library-only pricing is active.")
        }
    }
    private var aceNetSearchActionAttempted: Boolean = false
    private var aceNetStartupOnly: Boolean = false
    private var aceNetStartupResolved: Boolean = false
    private var aceNetStartupPromptShown: Boolean = false
    private var aceNetStartupRequestId: String? = null
    private var aceNetHealthStatus: String? = null
    private var aceNetUserRecoveryRetryArmed: Boolean = false
    // Diagnostic provenance only. This records raw native evidence so a later health decision
    // can prove what callback supplied it; it does not itself change AceNet behavior.
    private var aceNetLastFailureEvidence: JSONObject? = null
    private var aceNetOuterPageEverReachedThreshold: Boolean = false
    private var aceNetOuterPageMaxBodyTextLength: Int = 0
    private var aceNetHomeHtmlCapturedForSession: Boolean = false
    private val aceNetSessionHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private val aceNetExtendIntervalMs = 55L * 60L * 1000L
    private var aceNetLastAuthenticatedMs: Long
        get() = aceNetSessionManager.lastAuthenticatedMs
        set(value) { aceNetSessionManager.lastAuthenticatedMs = value }
    private var aceNetLastExtendedMs: Long
        get() = aceNetSessionManager.lastExtendedMs
        set(value) { aceNetSessionManager.lastExtendedMs = value }
    private var aceNetLastSuccessfulLookupMs: Long
        get() = aceNetSessionManager.lastSuccessfulLookupMs
        set(value) { aceNetSessionManager.lastSuccessfulLookupMs = value }
    private var aceNetSessionEstablishedMs: Long
        get() = aceNetSessionManager.sessionEstablishedMs
        set(value) { aceNetSessionManager.sessionEstablishedMs = value }
    private var aceNetHomeVerifiedMs: Long
        get() = aceNetSessionManager.homeVerifiedMs
        set(value) { aceNetSessionManager.homeVerifiedMs = value }
    private var aceNetRetailerVerifiedMs: Long
        get() = aceNetSessionManager.retailerVerifiedMs
        set(value) { aceNetSessionManager.retailerVerifiedMs = value }
    private var aceNetSessionGeneration: Long
        get() = aceNetSessionManager.sessionGeneration
        set(value) { aceNetSessionManager.sessionGeneration = value }
    private var aceNetSessionRefreshRequired: Boolean
        get() = aceNetSessionManager.sessionRefreshRequired
        set(value) { aceNetSessionManager.sessionRefreshRequired = value }
    private var aceNetFreshSessionResetInProgress: Boolean = false
    private var aceNetInitialStartupBegun: Boolean = false
    private var aceNetRecoveryAttempted: Boolean = false
    private var aceNetRecoveryInProgress: Boolean = false
    private var aceNetExpectedFreshLogin: Boolean = false
    private var aceNetAuthenticationNetworkRetryAttempted: Boolean = false
    private var aceNetRetailerBootstrapRetryAttempted: Boolean = false
    private var aceNetAppForeground: Boolean = false
    private var aceNetIntentionalExit: Boolean = false
    private var aceNetStartupBackgroundedDuringCheck: Boolean = false
    private var aceNetBackgroundedAtMs: Long = 0L
    private var aceNetAuthenticatedUserPresent: Boolean
        get() = aceNetSessionManager.authenticatedUserPresent
        set(value) { aceNetSessionManager.authenticatedUserPresent = value }
    private var aceNetAuthenticatedStorePresent: Boolean
        get() = aceNetSessionManager.authenticatedStorePresent
        set(value) { aceNetSessionManager.authenticatedStorePresent = value }
    private val aceNetExtendRunnable = Runnable { markAceNetSessionRefreshIfDue("active_use_timer") }

    private lateinit var aceNetRetrievalService: AceNetRetrievalService
    private lateinit var aceNetSessionManager: AceNetSessionManager
    private val webView: WebView get() = requireNotNull(mainWebViewProvider()) { "Main WebView unavailable" }

    init {
        aceNetSessionManager = AceNetSessionManager(activity, diagnostic = { event, payload -> aceNetNativeDiagnostic(event, payload) })
        aceNetRetrievalService = AceNetRetrievalService(
            activity,
            { event, payload -> aceNetNativeDiagnostic(event, payload) },
            { requestId, mode, result -> handlePersistentAceNetResult(requestId, mode, result) }
        )
        restoreAceNetSessionHistory()
    }

    /** Narrow bridge exposed only to transient AceNet WebViews. */
    inner class AceNetResultBridge(private val owner: WebView) {
        @JavascriptInterface fun observedResult(json: String) { activity.runOnUiThread { handleAceNetObservedResult(json, owner) } }
        @JavascriptInterface fun deliveryError(message: String) { activity.runOnUiThread {
            aceNetNativeDiagnostic("retailer_result_delivery_error", JSONObject().put("message", message.take(240)))
        } }
    }

    fun recordDiagnostic(event: String, payload: JSONObject = JSONObject()) = aceNetNativeDiagnostic(event, payload)
    fun networkConnectivityState(): String = currentNetworkConnectivityState().toString()
    fun beginStartup() { recordStartupNetworkPreflight(); beginAceNetStartupAuthentication() }
    fun test(requestId: String, userId: String, password: String, sku: String) { aceNetStartupOnly=false; aceNetRequestKind="TEST"; startAceNetTest(requestId,userId,password,sku) }
    fun cancelTest() = finishAceNetTest(false,"CANCELLED","AceNet test cancelled.",null)
    fun cancelStartupWarmup() = cancelAceNetStartupWarmupForSplashTimeout()
    fun hasCredentials(): Boolean = hasSavedAceNetCredentials()
    fun savedCredentialsJson(): String = loadAceNetCredentialsEncrypted()?.let { JSONObject().put("user",it.first).put("password",it.second).toString() } ?: "{}"
    fun saveCredentials(userId: String,password: String): Boolean = saveAceNetCredentialsEncrypted(userId,password)
    fun deleteCredentials(): Boolean = deleteAceNetCredentialsEncrypted()
    fun testSaved(requestId: String, sku: String) {
        aceNetStartupOnly=false;aceNetRequestKind="TEST"
        val c=loadAceNetCredentialsEncrypted()
        if(c==null){aceNetRequestId=requestId;aceNetSku=sku.trim();finishAceNetTest(false,"NO_SAVED_CREDENTIALS","No saved AceNet credentials are available.",null)}
        else startAceNetTest(requestId,c.first,c.second,sku)
    }
    fun setUserRecoveryRetryArmed(armed:Boolean) {
        aceNetUserRecoveryRetryArmed=armed
        aceNetNativeDiagnostic("user_recovery_retry_arm_changed",JSONObject()
            .put("armed",armed).put("healthStatus",aceNetHealthStatus)
            .put("startupResolved",aceNetStartupResolved)
            .put("policy","ONE_SHOT_NEXT_PRODUCTION_REQUEST_WHILE_KNOWN_UNAVAILABLE"))
    }
    fun lookupPrice(requestId:String,sku:String)=startProductionAceNetLookup(requestId,sku,"PRODUCTION_PRICE")
    fun lookupPriceWithUpcs(requestId:String,sku:String)=startProductionAceNetLookup(requestId,sku,"PRODUCTION_PRICE_UPCS")
    fun lookupUpcs(requestId:String,sku:String)=startProductionAceNetLookup(requestId,sku,"PRODUCTION_UPCS")
    fun lookupCatalog(requestId:String,sku:String)=startDeferredAceNetCatalogLookup(requestId,sku,"PRODUCTION_CATALOG")
    fun lookupMiscCatalog(requestId:String,sku:String)=startDeferredAceNetCatalogLookup(requestId,sku,"PRODUCTION_MISC_CATALOG")
    fun lookupRepairCatalog(requestId:String,sku:String)=startDeferredAceNetCatalogLookup(requestId,sku,"PRODUCTION_REPAIR_CATALOG")
    fun loginStatus(): String = JSONObject()
        .put("authenticated",aceNetSessionAuthenticated).put("startupResolved",aceNetStartupResolved)
        .put("phase",aceNetPhase).put("healthStatus",aceNetHealthStatus)
        .put("userPresent",aceNetAuthenticatedUserPresent).put("storePresent",aceNetAuthenticatedStorePresent)
        .put("lastAuthenticatedMs",aceNetLastAuthenticatedMs).put("lastExtendedMs",aceNetLastExtendedMs)
        .put("lastSuccessfulLookupMs",aceNetLastSuccessfulLookupMs).put("recoveryInProgress",aceNetRecoveryInProgress)
        .put("hasCredentials",hasSavedAceNetCredentials()).toString()
    fun onStart() {
        val awayMs=if(aceNetBackgroundedAtMs>0L) System.currentTimeMillis()-aceNetBackgroundedAtMs else 0L
        aceNetNativeDiagnostic("application_foregrounded",JSONObject().put("backgroundDurationMs",awayMs).put("startupContinuedInBackground",aceNetStartupBackgroundedDuringCheck))
        if(!aceNetStartupBackgroundedDuringCheck && aceNetInitialStartupBegun && aceNetStartupResolved && hasSavedAceNetCredentials()){
            val workerReady=aceNetRetrievalService.isReady();val fresh=aceNetSessionReusable()
            if(!workerReady || !fresh)webView.postDelayed({ restartPersistentAceNetWarmup("application_foregrounded",forceFreshSession=!fresh) },250L)
        }
    }
    fun onResume(){aceNetAppForeground=true;if(aceNetSessionAuthenticated)scheduleAceNetSessionExtension();reconcileBackgroundedStartupAfterForeground()}
    fun onPause(){aceNetAppForeground=false;aceNetSessionHandler.removeCallbacks(aceNetExtendRunnable)}
    private fun reconcileBackgroundedStartupAfterForeground(){
        if(!aceNetAppForeground || !aceNetStartupBackgroundedDuringCheck)return
        if(!aceNetStartupResolved){aceNetNativeDiagnostic("backgrounded_startup_still_running_after_foreground",JSONObject().put("policy","CONTINUE_EXISTING_REQUEST"));return}
        aceNetStartupBackgroundedDuringCheck=false;aceNetBackgroundedAtMs=0L
        if(aceNetHealthStatus=="ONLINE" || aceNetHealthStatus=="DOWN" || !hasSavedAceNetCredentials()){aceNetNativeDiagnostic("backgrounded_startup_terminal_retained",JSONObject().put("healthStatus",aceNetHealthStatus));return}
        aceNetRequestId=null;aceNetHealthStatus="CHECKING";notifyAceNetHealthState("backgrounded_startup_foreground_revalidation");aceNetNativeDiagnostic("backgrounded_startup_foreground_revalidation_started",JSONObject().put("policy","ONE_FOREGROUND_REVALIDATION").put("priorResult","NON_ONLINE"))
        webView.postDelayed({restartPersistentAceNetWarmup("backgrounded_startup_foreground_revalidation",forceFreshSession=!aceNetSessionReusable())},250L)
    }
    fun onStop() {
        aceNetBackgroundedAtMs=System.currentTimeMillis()
        val interruptedRequestId=aceNetRequestId;val interruptedKind=aceNetRequestKind;val interruptedPhase=aceNetPhase
        val interruptedStartup=aceNetStartupOnly && !aceNetStartupResolved
        val persistentWorkerBusy=aceNetRetrievalService.isBusy();val persistentWorkerReady=aceNetRetrievalService.isReady()
        aceNetNativeDiagnostic("application_backgrounded",JSONObject().put("requestInFlight",interruptedRequestId!=null || persistentWorkerBusy).put("requestKind",if(persistentWorkerBusy)"PERSISTENT_WORKER" else interruptedKind).put("phase",interruptedPhase).put("startupContinues",interruptedStartup).put("persistentWorkerReady",persistentWorkerReady).put("persistentWorkerBusy",persistentWorkerBusy))
        if(interruptedStartup){
            aceNetStartupBackgroundedDuringCheck=true
            aceNetNativeDiagnostic("startup_request_retained_for_background",JSONObject().put("requestId",interruptedRequestId).put("priorPhase",interruptedPhase).put("healthDecision","NONE").put("downDeclared",false).put("policy","CONTINUE_IN_BACKGROUND_REVALIDATE_FAILURE_ON_FOREGROUND"))
        }else if(interruptedRequestId!=null){
            aceNetNativeDiagnostic("active_request_interrupted_for_background",JSONObject().put("requestId",interruptedRequestId).put("requestKind",interruptedKind).put("priorPhase",interruptedPhase).put("healthDecision","NONE").put("downDeclared",false))
            aceNetCallback(false,"INTERRUPTED","AceNet request was interrupted when the app moved to the background.",null);destroyAceNetTestView(clearRequest=true)
        }else if(persistentWorkerBusy){
            aceNetRetrievalService.destroy("active_persistent_lookup_interrupted_for_background")
            aceNetNativeDiagnostic("active_request_interrupted_for_background",JSONObject().put("requestId",JSONObject.NULL).put("requestKind","PERSISTENT_WORKER").put("priorPhase","PERSISTENT_RETAILER").put("healthDecision","NONE").put("downDeclared",false))
        }else if(persistentWorkerReady)aceNetNativeDiagnostic("persistent_worker_retained_for_background",JSONObject().put("ready",true).put("busy",false).put("healthDecision","NONE").put("downDeclared",false))
    }
    fun handleBackPressed():Boolean{
        if(aceNetIntentionalExit || !aceNetSessionAuthenticated)return false
        aceNetIntentionalExit=true;aceNetNativeDiagnostic("intentional_app_exit",JSONObject().put("logoutAttempted",true))
        performAceNetNativeLogout("intentional_app_exit"){activity.runOnUiThread{activity.finish()}};return true
    }
    fun destroy(){releaseAceNetStartupReadinessDeadline();aceNetAppForeground=false;aceNetSessionHandler.removeCallbacks(aceNetExtendRunnable);aceNetUser="";aceNetPassword="";aceNetRetrievalService.destroy("activity_destroyed");destroyAceNetTestView(true)}
    private fun hasSavedAceNetCredentials(): Boolean = aceNetSessionManager.hasSavedCredentials()
    private fun saveAceNetCredentialsEncrypted(userId: String, password: String): Boolean =
        aceNetSessionManager.saveCredentials(userId, password)
    private fun loadAceNetCredentialsEncrypted(): Pair<String,String>? = aceNetSessionManager.loadCredentials()
    private fun deleteAceNetCredentialsEncrypted(): Boolean = aceNetSessionManager.deleteCredentials()

    private fun aceNetCallback(found: Boolean, status: String, message: String, price: String?, catalog: JSONObject? = null) {
        val requestId = aceNetRequestId ?: return
        val payload = JSONObject()
            .put("requestId", requestId)
            .put("found", found)
            .put("status", status)
            .put("message", message)
            .put("sku", aceNetSku)
        if (!price.isNullOrBlank()) payload.put("price", price)
        if (catalog != null) payload.put("catalog", catalog)
        if (aceNetProductImageUrl.isNotBlank()) {
            payload.put("imageUrl",aceNetProductImageUrl)
                .put("imageScore",aceNetProductImageScore)
                .put("imageWidth",aceNetProductImageWidth)
                .put("imageHeight",aceNetProductImageHeight)
        }
        if (mainWebViewProvider() != null) {
            val callback = when(aceNetRequestKind) { "PRODUCTION_PRICE","PRODUCTION_PRICE_UPCS" -> "UPCNativeAceNetPriceResult"; "PRODUCTION_UPCS" -> "UPCNativeAceNetUpcResult"; "PRODUCTION_CATALOG","PRODUCTION_MISC_CATALOG","PRODUCTION_REPAIR_CATALOG" -> "UPCNativeAceNetCatalogResult"; else -> "UPCNativeAceNetTestResult" }
            webView.evaluateJavascript(
                "window.$callback && window.$callback(${JSONObject.quote(payload.toString())});",
                null
            )
        }
    }

    private fun aceNetStatus(status: String, message: String) {
        val requestId = aceNetRequestId ?: return
        val payload = JSONObject().put("requestId", requestId).put("status", status).put("message", message).put("sku", aceNetSku)
        if (mainWebViewProvider() != null) webView.evaluateJavascript(
            "window.UPCNativeAceNetTestStatus && window.UPCNativeAceNetTestStatus(${JSONObject.quote(payload.toString())});",
            null
        )
    }

    private fun aceNetNativeDiagnostic(event: String, fields: JSONObject = JSONObject()) {
        val payload = JSONObject()
            .put("event", event)
            .put("phase", aceNetPhase)
            .put("elapsedMs", if (aceNetStartedMs > 0) System.currentTimeMillis()-aceNetStartedMs else 0)
            .put("host", aceNetLastHost)
            .put("credentialStorePresent", hasSavedAceNetCredentials())
            .put("sessionAuthenticated",aceNetSessionAuthenticated)
            .put("userPresent",aceNetAuthenticatedUserPresent)
            .put("storePresent",aceNetAuthenticatedStorePresent)
            .put("lastAuthenticatedMs",aceNetLastAuthenticatedMs)
            .put("lastExtendedMs",aceNetLastExtendedMs)
            .put("lastSuccessfulLookupMs",aceNetLastSuccessfulLookupMs)
            .put("recoveryAttempted",aceNetRecoveryAttempted)
            .put("recoveryInProgress",aceNetRecoveryInProgress)
        val keys=fields.keys()
        while(keys.hasNext()){ val k=keys.next(); payload.put(k,fields.opt(k)) }
        nativeDiagnosticJournal.record(event, payload)
        val mirrorToBrowser = event in setOf(
            "application_backgrounded","startup_request_retained_for_background","active_request_interrupted_for_background",
            "application_foregrounded","backgrounded_startup_still_running_after_foreground","backgrounded_startup_terminal_retained",
            "backgrounded_startup_foreground_revalidation_started","backgrounded_startup_health_publication_deferred","backgrounded_startup_terminal_deferred",
            "login_submission","authenticated_home_ready","startup_authentication_verified_before_canary","startup_canary_health_evidence","health_state","result_watchdog_fired",
            "startup_acenet_warmup_started","startup_acenet_warmup_complete","lookup_timing_summary","persistent_worker_result",
            "persistent_worker_fast_path_failed","session_recovery_started","session_reauthentication_started"
        ) || event.contains("error",true) || event.contains("failed",true) || event.contains("timeout",true)
        if (mirrorToBrowser && mainWebViewProvider() != null) webView.evaluateJavascript(
            "window.UPCNativeAceNetDiagnostic && window.UPCNativeAceNetDiagnostic(${JSONObject.quote(payload.toString())});", null
        )
    }

    private fun notifyAceNetStartupState(status: String, message: String, progress: Int? = null, phase: String? = null) {
        if (mainWebViewProvider() != null) {
            val payload=JSONObject()
                .put("status",status).put("message",message)
                .put("authenticated",aceNetSessionAuthenticated)
                .put("healthStatus",aceNetHealthStatus)
                .put("startupResolved",aceNetStartupResolved)
                .put("hasCredentials",hasSavedAceNetCredentials())
            progress?.let { payload.put("progress",it) }
            phase?.let { payload.put("startupPhase",it) }
            webView.evaluateJavascript(
                "window.UPCNativeAceNetStartupStatus && window.UPCNativeAceNetStartupStatus(${JSONObject.quote(payload.toString())});", null
            )
        }
    }
    private fun notifyAceNetHealthState(reason: String) {
        if(aceNetStartupOnly && aceNetStartupBackgroundedDuringCheck && !aceNetAppForeground && aceNetHealthStatus!="ONLINE" && aceNetHealthStatus!="DOWN"){
            aceNetNativeDiagnostic("backgrounded_startup_health_publication_deferred",JSONObject().put("status",aceNetHealthStatus).put("reason",reason).put("policy","FOREGROUND_REVALIDATION_REQUIRED"));return
        }
        if (mainWebViewProvider() != null) webView.evaluateJavascript(
            "window.UPCNativeAceNetHealthStatus && window.UPCNativeAceNetHealthStatus(${JSONObject.quote(JSONObject()
                .put("status",aceNetHealthStatus)
                .put("reason",reason)
                .put("authenticated",aceNetSessionAuthenticated).toString())});", null
        )
        val healthDiagnostic=JSONObject()
            .put("status",aceNetHealthStatus)
            .put("reason",reason)
            .put("decisionSourceFunction","notifyAceNetHealthState")
            .put("decisionObservedVsInferred", if (aceNetLastFailureEvidence != null) "OBSERVED_RAW_EVIDENCE_AVAILABLE" else "NO_RAW_FAILURE_ATTACHED")
        aceNetLastFailureEvidence?.let { healthDiagnostic.put("causalEvidence", JSONObject(it.toString())) }
        aceNetNativeDiagnostic("health_state",healthDiagnostic)
    }

    private fun registerAceNetHealthyResponse(reason: String) {
        aceNetHealthStatus="ONLINE"
        notifyAceNetHealthState(reason)
    }

    private fun recordAceNetSessionTimestamp(key:String, value:Long=System.currentTimeMillis()) =
        aceNetSessionManager.recordTimestamp(key,value)

    private fun restoreAceNetSessionHistory() {
        aceNetNativeDiagnostic("session_history_loaded", aceNetSessionManager.restoreHistory())
    }

    private fun sessionReuseBasisMs():Long=aceNetSessionManager.reuseBasisMs()

    private fun aceNetSessionReusable():Boolean = aceNetSessionManager.isReusable(aceNetExtendIntervalMs)

    private fun resetAceNetSessionHistoryForGeneration(reason:String) {
        aceNetNativeDiagnostic("session_generation_reset", aceNetSessionManager.resetHistoryForGeneration(reason))
    }

    private fun aceNetCookieNameArray(url:String):JSONArray {
        val raw=try{CookieManager.getInstance().getCookie(url).orEmpty()}catch(_:Exception){""}
        val out=JSONArray()
        raw.split(';').mapNotNull { part ->
            val name=part.substringBefore('=').trim()
            name.takeIf { it.isNotBlank() }
        }.distinct().sorted().forEach { out.put(it) }
        return out
    }

    private fun recordAceNetCookieState(event:String, reason:String) {
        val ace=aceNetCookieNameArray("https://acenet.aceservices.com/")
        val sts=aceNetCookieNameArray("https://sts.aceservices.com/")
        val retailer=aceNetCookieNameArray("https://retailer.aceservices.com/")
        aceNetNativeDiagnostic(event,JSONObject()
            .put("reason",reason)
            .put("sessionGeneration",aceNetSessionGeneration)
            .put("aceNetCookieNames",ace).put("aceNetCookieCount",ace.length())
            .put("stsCookieNames",sts).put("stsCookieCount",sts.length())
            .put("retailerCookieNames",retailer).put("retailerCookieCount",retailer.length())
            .put("valuesRedacted",true))
    }

    private fun resetAceNetWebSession(reason:String, done:()->Unit) {
        if(aceNetFreshSessionResetInProgress){
            aceNetNativeDiagnostic("session_reset_already_in_progress",JSONObject().put("reason",reason))
            return
        }
        aceNetFreshSessionResetInProgress=true
        recordAceNetCookieState("session_cookie_state_before_reset",reason)
        aceNetSessionHandler.removeCallbacks(aceNetExtendRunnable)
        aceNetRetrievalService.destroy("session_reset_$reason")
        aceNetPersistentRetailerTemplate=""
        aceNetSessionAuthenticated=false;aceNetAuthenticatedUserPresent=false;aceNetAuthenticatedStorePresent=false
        aceNetHomeHtmlCapturedForSession=false
        destroyAceNetTestView(clearRequest=false)
        resetAceNetSessionHistoryForGeneration(reason)
        var completed=false
        fun finishReset(cookieCallbackObserved:Boolean){
            if(completed)return
            completed=true
            aceNetSessionHandler.removeCallbacksAndMessages(null)
            try{CookieManager.getInstance().flush()}catch(_:Exception){}
            aceNetFreshSessionResetInProgress=false
            recordAceNetCookieState("session_cookie_state_after_reset",reason)
            aceNetNativeDiagnostic("fresh_web_session_ready",JSONObject()
                .put("reason",reason).put("sessionGeneration",aceNetSessionGeneration)
                .put("cookieCallbackObserved",cookieCallbackObserved))
            done()
        }
        try{
            CookieManager.getInstance().removeAllCookies { finishReset(true) }
            aceNetSessionHandler.postDelayed({finishReset(false)},3_000L)
        }catch(e:Exception){
            aceNetNativeDiagnostic("session_cookie_reset_failed",JSONObject().put("reason",reason).put("errorType",e.javaClass.simpleName))
            finishReset(false)
        }
    }

    private fun startFreshAceNetSession(requestId:String,user:String,password:String,sku:String,reason:String,preserveRecoveryState:Boolean=false){
        aceNetExpectedFreshLogin=true
        aceNetNativeDiagnostic("fresh_session_start_requested",JSONObject()
            .put("reason",reason).put("skuLength",sku.length).put("priorGeneration",aceNetSessionGeneration))
        val originatedDuringStartup=aceNetStartupOnly
        resetAceNetWebSession(reason){
            if(originatedDuringStartup && (!aceNetStartupOnly || aceNetStartupResolved)){
                aceNetNativeDiagnostic("late_startup_session_reset_ignored",JSONObject().put("reason",reason))
                return@resetAceNetWebSession
            }
            if(aceNetStartupOnly)notifyAceNetStartupState("CHECKING","Signing into a fresh AceNet session…",62,"AUTHENTICATION")
            startAceNetTest(requestId,user,password,sku,preserveRecoveryState=preserveRecoveryState)
        }
    }

    private fun retryAceNetStartupAuthenticationNetworkFailure(reason:String):Boolean {
        if(!aceNetStartupOnly || aceNetSessionAuthenticated || aceNetAuthenticationNetworkRetryAttempted || aceNetFreshSessionResetInProgress)return false
        val requestId=aceNetRequestId.orEmpty()
        val sku=aceNetSku.trim()
        val credentials=loadAceNetCredentialsEncrypted()?:return false
        if(requestId.isBlank()||sku.isBlank())return false
        aceNetAuthenticationNetworkRetryAttempted=true
        aceNetNativeDiagnostic("startup_authentication_network_retry_started",JSONObject()
            .put("reason",reason).put("sessionGeneration",aceNetSessionGeneration)
            .put("attempt",1).put("maxAttempts",1))
        notifyAceNetStartupState("CHECKING","Retrying AceNet sign-in after a network interruption…",60,"AUTH_NETWORK_RETRY")
        startFreshAceNetSession(requestId,credentials.first,credentials.second,sku,"auth_network_retry_$reason",preserveRecoveryState=true)
        return true
    }

    private fun retryAceNetStartupRetailerBootstrap(view:WebView?, reason:String):Boolean {
        val v=view?:return false
        if(!aceNetStartupOnly || !aceNetSessionAuthenticated || !aceNetAuthenticatedUserPresent || !aceNetAuthenticatedStorePresent || aceNetRetailerBootstrapRetryAttempted)return false
        if(v!==aceNetTestView || aceNetRequestId==null)return false
        aceNetRetailerBootstrapRetryAttempted=true
        aceNetResultHandler.removeCallbacks(aceNetStartupRetailerDeadlineRunnable)
        aceNetStartupRetailerBootstrapPending=false
        aceNetPersistentRetailerTemplate=""
        aceNetNativeDiagnostic("startup_retailer_bootstrap_retry_started",JSONObject()
            .put("reason",reason).put("sessionGeneration",aceNetSessionGeneration)
            .put("attempt",1).put("maxAttempts",1).put("authenticationPreserved",true))
        notifyAceNetStartupState("CHECKING","Retrying AceNet item-session handoff…",68,"RETAILER_RETRY")
        aceNetPhase="AUTHENTICATED"
        loadAceNetDirectItem(v)
        return true
    }

    private fun scheduleAceNetSessionExtension() {
        aceNetSessionHandler.removeCallbacks(aceNetExtendRunnable)
        if(!aceNetAppForeground || !aceNetSessionAuthenticated || aceNetRecoveryInProgress || aceNetSessionRefreshRequired)return
        val basis=sessionReuseBasisMs()
        if(basis<=0L){aceNetSessionRefreshRequired=true;return}
        val age=(System.currentTimeMillis()-basis).coerceAtLeast(0L)
        val delay=(aceNetExtendIntervalMs-age).coerceAtLeast(1_000L)
        aceNetSessionHandler.postDelayed(aceNetExtendRunnable,delay)
        aceNetNativeDiagnostic("session_refresh_scheduled",JSONObject()
            .put("delayMs",delay).put("basisAgeMs",age).put("sessionGeneration",aceNetSessionGeneration))
    }

    private fun markAceNetSessionRefreshIfDue(reason:String) {
        aceNetSessionHandler.removeCallbacks(aceNetExtendRunnable)
        if(!aceNetAppForeground || !aceNetSessionAuthenticated || aceNetRecoveryInProgress)return
        val basis=sessionReuseBasisMs()
        val age=if(basis>0L)System.currentTimeMillis()-basis else Long.MAX_VALUE
        if(age<aceNetExtendIntervalMs){scheduleAceNetSessionExtension();return}
        if(aceNetRetrievalService.isBusy()){
            aceNetNativeDiagnostic("session_refresh_deferred",JSONObject().put("reason","active_lookup").put("sessionAgeMs",age))
            aceNetSessionHandler.postDelayed(aceNetExtendRunnable,60_000L)
            return
        }
        aceNetSessionRefreshRequired=true
        aceNetRetrievalService.destroy("session_refresh_due")
        aceNetPersistentRetailerTemplate=""
        aceNetNativeDiagnostic("session_refresh_required",JSONObject()
            .put("reason",reason).put("sessionAgeMs",age).put("sessionGeneration",aceNetSessionGeneration)
            .put("networkRequestStarted",false))
    }

    private fun performAceNetNativeLogout(reason:String, done:()->Unit) {
        aceNetSessionHandler.removeCallbacks(aceNetExtendRunnable)
        aceNetNativeDiagnostic("logout_started",JSONObject().put("reason",reason))
        aceNetSessionAuthenticated=false;aceNetAuthenticatedUserPresent=false;aceNetAuthenticatedStorePresent=false
        aceNetHomeHtmlCapturedForSession=false
        val logoutView=WebView(activity)
        logoutView.settings.javaScriptEnabled=true;logoutView.settings.domStorageEnabled=true
        CookieManager.getInstance().setAcceptCookie(true);CookieManager.getInstance().setAcceptThirdPartyCookies(logoutView,true)
        var stage=0;var finished=false
        fun complete(result:String){
            if(finished)return;finished=true
            aceNetSessionHandler.removeCallbacksAndMessages(null)
            try{logoutView.stopLoading();logoutView.loadUrl("about:blank");logoutView.clearHistory();logoutView.destroy()}catch(_:Exception){}
            recordAceNetSessionTimestamp("lastLogoutMs")
            aceNetNativeDiagnostic("logout_completed",JSONObject().put("reason",reason).put("result",result))
            done()
        }
        logoutView.webViewClient=object:WebViewClient(){
            override fun onPageFinished(view:WebView?,url:String?){
                super.onPageFinished(view,url)
                aceNetNavigationDiagnostic("logout_navigation",view,url,JSONObject().put("stage",stage))
                if(stage==0){
                    stage=1
                    logoutView.loadUrl("https://acenet.aceservices.com/FedAuth/Logout")
                }else if(stage==1) complete("native_two_site_logout")
            }
        }
        aceNetSessionHandler.postDelayed({complete("timeout_after_logout_attempt")},8_000L)
        logoutView.loadUrl("https://retailer.aceservices.com/FedAuth/Logout")
    }

    private fun recoverAceNetSessionAndRetry(reason:String) {
        if(aceNetRecoveryAttempted || aceNetRecoveryInProgress){
            aceNetNativeDiagnostic("session_recovery_stopped",JSONObject().put("reason",reason).put("alreadyAttempted",aceNetRecoveryAttempted))
            finishAceNetTest(false,"AUTH_FAILED","AceNet authentication could not be restored automatically.",null)
            return
        }
        val requestId=aceNetRequestId.orEmpty();val sku=aceNetSku
        val credentials=loadAceNetCredentialsEncrypted()
        if(requestId.isBlank()||sku.isBlank()||credentials==null){
            finishAceNetTest(false,"AUTH_FAILED","AceNet authentication expired and saved credentials were unavailable for automatic recovery.",null);return
        }
        aceNetRecoveryAttempted=true;aceNetRecoveryInProgress=true
        aceNetNativeDiagnostic("session_recovery_started",JSONObject().put("reason",reason).put("skuLength",sku.length))
        if(aceNetStartupOnly)notifyAceNetStartupState("CHECKING","Restoring AceNet session…",58,"SESSION_RECOVERY")
        destroyAceNetTestView(clearRequest=false)
        aceNetRecoveryInProgress=false
        aceNetNativeDiagnostic("session_reauthentication_started",JSONObject().put("reason",reason).put("freshSessionReset",true))
        startFreshAceNetSession(requestId,credentials.first,credentials.second,sku,"automatic_recovery_$reason",preserveRecoveryState=true)
    }

    private fun ensurePersistentAceNetWorker() {
        aceNetRetrievalService.ensureWorker()
    }

    private fun startAceNetStartupPersistentVerification(template:String, attempt:Int=1) {
        if(!aceNetStartupOnly || aceNetStartupResolved) return
        val boundedAttempt=attempt.coerceIn(1,3)
        notifyAceNetStartupState("CHECKING","Verifying AceNet item service (attempt $boundedAttempt of 3)…",72 + (boundedAttempt*6),"PERSISTENT_VERIFY_$boundedAttempt")
        aceNetNativeDiagnostic("startup_persistent_worker_attempt_started",JSONObject()
            .put("attempt",boundedAttempt).put("maxAttempts",3).put("warmupSku",aceNetWarmupSku)
            .put("timeoutAuthority","PersistentAceNetWorker").put("retailerTemplatePresent",template.isNotBlank()))
        val started=aceNetRetrievalService.prime(template,aceNetWarmupSku){ primeResult ->
            if(!aceNetStartupOnly || aceNetStartupResolved) {
                aceNetNativeDiagnostic("startup_persistent_worker_prime_result_ignored",JSONObject()
                    .put("attempt",boundedAttempt).put("reason","startup_already_resolved_or_invalidated"))
            } else {
                val primeStatus=primeResult.optString("status",primeResult.optString("outcome","UNKNOWN")).uppercase()
                val primeSku=primeResult.optString("sku").trim()
                val primePrice=primeResult.optString("price").trim()
                val ready=primeStatus=="FOUND" && primeSku==aceNetWarmupSku && primePrice.isNotBlank() && aceNetRetrievalService.isReady()
                val httpStatus=primeResult.optInt("httpStatus",0);val retryableTimeout=primeStatus=="TIMEOUT"||primeStatus=="SKU_TIMEOUT";val retryableTransport=AceNetRuntimeClassifier.isTransientTransportFailure(primeResult)
                aceNetNativeDiagnostic("startup_persistent_worker_prime_complete",JSONObject()
                    .put("attempt",boundedAttempt).put("maxAttempts",3).put("warmupSku",aceNetWarmupSku)
                    .put("status",primeStatus).put("returnedSku",primeSku).put("hasPrice",primePrice.isNotBlank())
                    .put("persistentWorkerReady",ready).put("retryableTimeout",retryableTimeout).put("retryableTransport",retryableTransport)
                    .put("httpStatus",httpStatus).put("timeoutAuthority","PersistentAceNetWorker"))
                when {
                    ready -> {
                        aceNetLastSuccessfulLookupMs=System.currentTimeMillis()
                        recordAceNetSessionTimestamp("lastSuccessfulLookupMs",aceNetLastSuccessfulLookupMs)
                        aceNetHealthStatus="ONLINE"
                        notifyAceNetHealthState("startup_persistent_worker_verified")
                        scheduleAceNetSessionExtension()
                        completeAceNetStartupAuthentication(true,"SIGNED_IN","AceNet is signed in, verified ONLINE, and the retained retailer worker is ready.")
                    }
                    primeStatus=="INTERRUPTED" && !aceNetAppForeground -> {
                        aceNetNativeDiagnostic("startup_persistent_worker_interruption_deferred_to_lifecycle",JSONObject()
                            .put("attempt",boundedAttempt).put("healthDecision","NONE"))
                    }
                    (retryableTimeout&&boundedAttempt<3)||(retryableTransport&&boundedAttempt<2) -> {
                        aceNetNativeDiagnostic(if(retryableTransport)"startup_persistent_worker_transport_retry" else "startup_persistent_worker_timeout_retry",JSONObject().put("attempt",boundedAttempt).put("nextAttempt",boundedAttempt+1).put("maxAttempts",if(retryableTransport)2 else 3))
                        startAceNetStartupPersistentVerification(template,boundedAttempt+1)
                    }
                    else -> {
                        if(httpStatus==500 || httpStatus==502 || httpStatus==503 || httpStatus==504) aceNetHealthStatus="DOWN"
                        else aceNetHealthStatus="UNAVAILABLE"
                        val reason=if(retryableTimeout) "startup_persistent_worker_three_timeouts" else "startup_persistent_worker_terminal_error"
                        notifyAceNetHealthState(reason)
                        aceNetNativeDiagnostic("startup_persistent_worker_terminal_service_state",JSONObject()
                            .put("attemptsUsed",boundedAttempt).put("maxAttempts",3).put("status",primeStatus)
                            .put("healthStatus",aceNetHealthStatus).put("httpStatus",httpStatus)
                            .put("allAttemptsTimedOut",retryableTimeout && boundedAttempt==3)
                            .put("globalServerDownEvidence",aceNetHealthStatus=="DOWN"))
                        completeAceNetStartupAuthentication(true,"SIGNED_IN",
                            if(aceNetHealthStatus=="DOWN") "AceNet is signed in, but the item service returned an observed server error. Library-only pricing is active."
                            else "AceNet is signed in, but the item service is unavailable for this workflow. Library-only pricing is active.")
                    }
                }
            }
        }
        if(!started && aceNetStartupOnly && !aceNetStartupResolved) {
            aceNetHealthStatus="UNAVAILABLE"
            notifyAceNetHealthState("startup_persistent_worker_not_started")
            aceNetNativeDiagnostic("startup_persistent_worker_prime_not_started",JSONObject()
                .put("attempt",boundedAttempt).put("warmupSku",aceNetWarmupSku)
                .put("retailerTemplatePresent",template.isNotBlank()).put("healthStatus",aceNetHealthStatus))
            completeAceNetStartupAuthentication(true,"SIGNED_IN","AceNet is signed in, but the retained retailer verification could not start. Library-only pricing is active.")
        }
    }

    private fun deliverAceNetProductionFailure(requestId:String, sku:String, mode:String, status:String, message:String) {
        val payload=JSONObject().put("requestId",requestId).put("found",false).put("status",status).put("message",message).put("sku",sku)
        val callback=when(mode){"PRODUCTION_UPCS"->"UPCNativeAceNetUpcResult";"PRODUCTION_CATALOG","PRODUCTION_MISC_CATALOG","PRODUCTION_REPAIR_CATALOG"->"UPCNativeAceNetCatalogResult";else->"UPCNativeAceNetPriceResult"}
        if(mainWebViewProvider() != null)webView.evaluateJavascript("window.$callback && window.$callback(${JSONObject.quote(payload.toString())});",null)
    }

    private fun clearAceNetProductionIncident(requestId:String?=null) {
        productionIncident.clear(requestId)
    }

    private fun ensureAceNetProductionIncident(requestId:String, sku:String, mode:String) {
        val started=productionIncident.ensure(requestId) {
            finishAceNetProductionOperationallyUnavailable(requestId,sku,mode,"INCIDENT_TIMEOUT",
                "AceNet could not restore usable item retrieval within the bounded recovery incident.")
        }
        if(!started)return
        aceNetNativeDiagnostic("production_incident_started",JSONObject()
            .put("requestId",requestId).put("mode",mode).put("requestedSku",sku)
            .put("budgetMs",productionIncident.incidentBudgetMs)
            .put("derivation","12s item OR 5s malformed + 5s soft; 25s hard recovery; 12s final item; bounded by 50s"))
    }

    private fun finishAceNetProductionOperationallyUnavailable(requestId:String,sku:String,mode:String,status:String,message:String) {
        if(productionIncident.belongsToOther(requestId))return
        val elapsed=productionIncident.elapsedMs()
        clearAceNetProductionIncident(requestId)
        aceNetPendingProductionRequest=null
        aceNetSessionRepairOnly=false
        aceNetHealthStatus="UNAVAILABLE"
        notifyAceNetHealthState("production_recovery_exhausted")
        aceNetNativeDiagnostic("production_incident_terminal_unavailable",JSONObject()
            .put("requestId",requestId).put("mode",mode).put("requestedSku",sku)
            .put("status",status).put("elapsedMs",elapsed)
            .put("comparisonSuppressed",true).put("upcEnrichmentSuppressed",true))
        aceNetRetrievalService.destroy("production_incident_unavailable")
        destroyAceNetTestView(clearRequest=true)
        deliverAceNetProductionFailure(requestId,sku,mode,"UNAVAILABLE",message)
    }

    private fun finishAceNetProductionServerDown(requestId:String,sku:String,mode:String,httpStatus:Int,message:String) {
        if(productionIncident.belongsToOther(requestId))return
        clearAceNetProductionIncident(requestId)
        aceNetPendingProductionRequest=null
        aceNetSessionRepairOnly=false
        aceNetHealthStatus="DOWN"
        notifyAceNetHealthState("production_http_${httpStatus}")
        aceNetNativeDiagnostic("production_incident_server_down",JSONObject()
            .put("requestId",requestId).put("mode",mode).put("requestedSku",sku)
            .put("httpStatus",httpStatus).put("comparisonSuppressed",true).put("upcEnrichmentSuppressed",true))
        aceNetRetrievalService.destroy("production_server_down")
        destroyAceNetTestView(clearRequest=true)
        deliverAceNetProductionFailure(requestId,sku,mode,"SERVICE_DOWN",message)
    }

    private fun beginAceNetProductionSoftRepair(requestId:String,sku:String,mode:String,reason:String) {
        ensureAceNetProductionIncident(requestId,sku,mode)
        if(productionIncident.hardRepairAttempted){
            finishAceNetProductionOperationallyUnavailable(requestId,sku,mode,"RECOVERY_EXHAUSTED","AceNet item retrieval failed again after full session recovery.")
            return
        }
        if(productionIncident.softRepairAttempted){
            beginAceNetProductionHardRepair(requestId,sku,mode,"soft_already_attempted_$reason")
            return
        }
        if(!aceNetSessionAuthenticated || aceNetPersistentRetailerTemplate.isBlank()){
            beginAceNetProductionHardRepair(requestId,sku,mode,"soft_unavailable_$reason")
            return
        }
        productionIncident.markSoftRepairAttempted()
        aceNetPendingProductionRequest=PendingAceNetProductionRequest(requestId,sku,mode)
        aceNetRetrievalService.destroy("soft_repair_$reason")
        val template=aceNetPersistentRetailerTemplate
        aceNetNativeDiagnostic("production_soft_repair_started",JSONObject()
            .put("requestId",requestId).put("mode",mode).put("requestedSku",sku)
            .put("reason",reason).put("canaryTimeoutMs",productionIncident.softCanaryMs)
            .put("freshLogin",false).put("cookiesCleared",false))
        val started=aceNetRetrievalService.prime(template,aceNetWarmupSku,productionIncident.softCanaryMs){ result ->
            if(!productionIncident.isActive(requestId))return@prime
            val status=result.optString("status",result.optString("outcome","UNKNOWN")).uppercase()
            val returned=result.optString("sku").trim()
            val ready=status=="FOUND" && returned==aceNetWarmupSku && result.optString("price").isNotBlank() && aceNetRetrievalService.isReady()
            aceNetNativeDiagnostic("production_soft_repair_complete",JSONObject()
                .put("requestId",requestId).put("status",status).put("ready",ready)
                .put("returnedSku",returned).put("freshLogin",false))
            if(ready){
                aceNetPendingProductionRequest=null
                registerAceNetHealthyResponse("production_soft_repair_worker_ready")
                val dispatched=aceNetRetrievalService.search(requestId,mode,sku)
                aceNetNativeDiagnostic("production_soft_repair_redispatched",JSONObject()
                    .put("requestId",requestId).put("mode",mode).put("requestedSku",sku).put("dispatched",dispatched))
                if(!dispatched)beginAceNetProductionHardRepair(requestId,sku,mode,"soft_redispatch_failed")
                return@prime
            }
            val http=result.optInt("httpStatus",0)
            when {
                http in listOf(500,502,503,504) -> finishAceNetProductionServerDown(requestId,sku,mode,http,"AceNet item service returned HTTP $http during recovery.")
                AceNetRuntimeClassifier.isDeviceConnectivityFailure(result) -> finishAceNetProductionOperationallyUnavailable(requestId,sku,mode,"NETWORK_UNAVAILABLE","The device network could not reach AceNet; the authenticated session was not deliberately reset.")
                AceNetRuntimeClassifier.isTransientTransportFailure(result) -> finishAceNetProductionOperationallyUnavailable(requestId,sku,mode,"TRANSIENT_TRANSPORT_UNAVAILABLE","AceNet returned a transient transport failure during the retained-session canary; no full sign-in reset was attempted.")
                else -> beginAceNetProductionHardRepair(requestId,sku,mode,"soft_failed_$status")
            }
        }
        if(!started)beginAceNetProductionHardRepair(requestId,sku,mode,"soft_canary_not_started")
    }

    private fun beginAceNetProductionHardRepair(requestId:String,sku:String,mode:String,reason:String) {
        ensureAceNetProductionIncident(requestId,sku,mode)
        if(productionIncident.hardRepairAttempted){
            finishAceNetProductionOperationallyUnavailable(requestId,sku,mode,"RECOVERY_EXHAUSTED","AceNet item retrieval remained unavailable after the one allowed full session recovery.")
            return
        }
        productionIncident.markHardRepairAttempted(requestId) {
            finishAceNetProductionOperationallyUnavailable(requestId,sku,mode,"HARD_RECOVERY_TIMEOUT","AceNet full session recovery exceeded its bounded 25-second recovery window.")
        }
        aceNetNativeDiagnostic("production_hard_repair_selected",JSONObject()
            .put("requestId",requestId).put("mode",mode).put("requestedSku",sku)
            .put("reason",reason).put("budgetMs",productionIncident.hardRecoveryBudgetMs))
        beginAceNetProductionSessionRepair(requestId,sku,mode,reason)
    }


    private fun clearAceNetProductionSessionRepair() {
        aceNetSessionRepairOnly=false
        aceNetPendingProductionRequest=null
    }

    private fun failAceNetProductionSessionRepair(status:String,message:String) {
        val pending=aceNetPendingProductionRequest
        clearAceNetProductionSessionRepair()
        destroyAceNetTestView(clearRequest=true)
        if(pending!=null){
            if(aceNetHealthStatus=="DOWN")finishAceNetProductionServerDown(pending.requestId,pending.sku,pending.mode,0,message)
            else finishAceNetProductionOperationallyUnavailable(pending.requestId,pending.sku,pending.mode,status,message)
        }
    }

    private fun beginAceNetProductionSessionRepair(requestId:String, sku:String, mode:String, reason:String) {
        val cleanSku=sku.trim()
        val credentials=loadAceNetCredentialsEncrypted()
        if(credentials==null){
            deliverAceNetProductionFailure(requestId,cleanSku,mode,"NO_SAVED_CREDENTIALS","AceNet session repair requires saved credentials.")
            return
        }
        aceNetPendingProductionRequest=PendingAceNetProductionRequest(requestId,cleanSku,mode)
        aceNetSessionRepairOnly=true
        aceNetStartupOnly=false
        aceNetRequestKind="SESSION_REPAIR"
        val internalRequestId="session-repair-${System.currentTimeMillis()}"
        aceNetNativeDiagnostic("production_session_repair_started",JSONObject()
            .put("productionRequestId",requestId).put("mode",mode).put("requestedSku",cleanSku)
            .put("reason",reason).put("warmupSku",aceNetWarmupSku).put("itemExtractionOwner","PersistentAceNetWorker"))
        startFreshAceNetSession(internalRequestId,credentials.first,credentials.second,aceNetWarmupSku,"production_repair_$reason")
    }

    private fun completeAceNetProductionSessionRepair(template:String, templateValid:Boolean) {
        val pending=aceNetPendingProductionRequest
        if(pending==null){
            clearAceNetProductionSessionRepair()
            destroyAceNetTestView(clearRequest=true)
            return
        }
        destroyAceNetTestView(clearRequest=true)
        if(!templateValid){
            failAceNetProductionSessionRepair("SESSION_UNAVAILABLE","AceNet retailer session could not be prepared for item retrieval.")
            return
        }
        val remaining=productionIncident.remainingHardRecoveryMs()
        if(remaining<750L){
            failAceNetProductionSessionRepair("HARD_RECOVERY_TIMEOUT","AceNet full session recovery exhausted its bounded recovery window before worker verification.")
            return
        }
        val canaryTimeout=minOf(productionIncident.softCanaryMs,remaining)
        val started=aceNetRetrievalService.prime(template,aceNetWarmupSku,canaryTimeout){ result ->
            if(!productionIncident.isActive(pending.requestId))return@prime
            val status=result.optString("status",result.optString("outcome","UNKNOWN")).uppercase()
            val returnedSku=result.optString("sku").trim()
            val hasPrice=result.optString("price").isNotBlank()
            val ready=status=="FOUND" && returnedSku==aceNetWarmupSku && hasPrice && aceNetRetrievalService.isReady()
            aceNetNativeDiagnostic("production_session_repair_prime_complete",JSONObject()
                .put("status",status).put("returnedSku",returnedSku).put("ready",ready)
                .put("productionRequestId",pending.requestId).put("productionMode",pending.mode)
                .put("canaryTimeoutMs",canaryTimeout).put("hardRecoveryDeadlineMs",productionIncident.hardRecoveryDeadlineMs)
                .put("itemExtractionOwner","PersistentAceNetWorker"))
            if(!ready){
                val http=result.optInt("httpStatus",0)
                if(http in listOf(500,502,503,504))finishAceNetProductionServerDown(pending.requestId,pending.sku,pending.mode,http,"AceNet item service returned HTTP $http after full session recovery.")
                else failAceNetProductionSessionRepair(status.ifBlank{"UNAVAILABLE"},"AceNet session was rebuilt, but the retained item worker could not be verified.")
                return@prime
            }
            aceNetSessionManager.markSuccessfulLookup()
            registerAceNetHealthyResponse("production_session_repair_worker_ready")
            productionIncident.clearHardRecoveryDeadline()
            clearAceNetProductionSessionRepair()
            val dispatched=aceNetRetrievalService.search(pending.requestId,pending.mode,pending.sku)
            aceNetNativeDiagnostic("production_session_repair_redispatched",JSONObject()
                .put("requestId",pending.requestId).put("mode",pending.mode).put("requestedSku",pending.sku)
                .put("dispatched",dispatched).put("finalAttempt",true).put("itemExtractionOwner","PersistentAceNetWorker"))
            if(!dispatched)finishAceNetProductionOperationallyUnavailable(pending.requestId,pending.sku,pending.mode,"FINAL_REDISPATCH_FAILED","AceNet item worker could not accept the final request after full session recovery.")
        }
        if(!started)failAceNetProductionSessionRepair("UNAVAILABLE","AceNet retained item worker could not be primed after session repair.")
    }

    private fun completeAceNetBridgeTestThroughWorker(template:String, templateValid:Boolean) {
        val requestId=aceNetRequestId.orEmpty()
        val requestedSku=aceNetSku.trim()
        destroyAceNetTestView(clearRequest=true)
        if(requestId.isBlank() || requestedSku.isBlank() || !templateValid){
            val payload=JSONObject().put("requestId",requestId).put("found",false).put("status","SESSION_UNAVAILABLE")
                .put("message","AceNet retailer session could not be prepared for the test lookup.").put("sku",requestedSku)
            if(mainWebViewProvider() != null)webView.evaluateJavascript("window.UPCNativeAceNetTestResult && window.UPCNativeAceNetTestResult(${JSONObject.quote(payload.toString())});",null)
            return
        }
        val started=aceNetRetrievalService.prime(template,requestedSku){ result ->
            val status=result.optString("status",result.optString("outcome","UNKNOWN")).uppercase()
            val returnedSku=result.optString("sku").trim()
            val price=result.optString("price").trim()
            val found=status=="FOUND" && returnedSku==requestedSku && price.isNotBlank()
            if(found){
                aceNetSessionManager.markSuccessfulLookup()
                aceNetHealthStatus="ONLINE"
                notifyAceNetHealthState("bridge_test_worker_verified")
            }
            val payload=JSONObject().put("requestId",requestId).put("found",found)
                .put("status",if(found)"FOUND" else status.ifBlank{"UNAVAILABLE"})
                .put("message",if(found)"AceNet returned the exact SKU retail price through the retained item worker." else "AceNet retained item worker did not verify the requested SKU.")
                .put("sku",if(returnedSku.isBlank())requestedSku else returnedSku)
            if(price.isNotBlank())payload.put("price",price)
            aceNetNativeDiagnostic("bridge_test_worker_complete",JSONObject()
                .put("requestId",requestId).put("requestedSku",requestedSku).put("returnedSku",returnedSku)
                .put("status",status).put("found",found).put("itemExtractionOwner","PersistentAceNetWorker"))
            if(mainWebViewProvider() != null)webView.evaluateJavascript("window.UPCNativeAceNetTestResult && window.UPCNativeAceNetTestResult(${JSONObject.quote(payload.toString())});",null)
        }
        if(!started){
            val payload=JSONObject().put("requestId",requestId).put("found",false).put("status","UNAVAILABLE")
                .put("message","AceNet retained item worker could not start the test lookup.").put("sku",requestedSku)
            if(mainWebViewProvider() != null)webView.evaluateJavascript("window.UPCNativeAceNetTestResult && window.UPCNativeAceNetTestResult(${JSONObject.quote(payload.toString())});",null)
        }
    }

    private fun startProductionAceNetLookup(requestId:String, sku:String, mode:String) {
        aceNetStartupOnly=false
        aceNetRequestKind=mode
        val cleanSku=sku.trim()
        if(requestId.isBlank()||cleanSku.isBlank())return
        if(aceNetStartupResolved && (aceNetHealthStatus=="UNAVAILABLE" || aceNetHealthStatus=="DOWN")){
            if(!aceNetUserRecoveryRetryArmed){
                deliverAceNetProductionFailure(requestId,cleanSku,mode,"UNAVAILABLE","AceNet is operationally unavailable for this running session; library-only operation is active.")
                aceNetNativeDiagnostic("production_acenet_skipped_known_unavailable",JSONObject()
                    .put("requestId",requestId).put("mode",mode).put("requestedSku",cleanSku)
                    .put("healthStatus",aceNetHealthStatus).put("startupResolved",true)
                    .put("userRecoveryRetryArmed",false))
                return
            }
            aceNetUserRecoveryRetryArmed=false
            ensureAceNetProductionIncident(requestId,cleanSku,mode)
            aceNetNativeDiagnostic("production_acenet_user_recovery_retry_consumed",JSONObject()
                .put("requestId",requestId).put("mode",mode).put("requestedSku",cleanSku)
                .put("healthStatus",aceNetHealthStatus).put("startupResolved",true)
                .put("userRecoveryRetryArmedAfterConsume",false)
                .put("recoveryAction","HARD_FRESH_SESSION_REPAIR"))
            beginAceNetProductionHardRepair(requestId,cleanSku,mode,"user_requested_after_known_unavailable")
            return
        }
        ensureAceNetProductionIncident(requestId,cleanSku,mode)
        if(aceNetSessionAuthenticated && !aceNetSessionReusable()){
            val credentials=loadAceNetCredentialsEncrypted()
            aceNetNativeDiagnostic("production_session_refresh_required",JSONObject()
                .put("requestId",requestId).put("mode",mode).put("requestedSku",cleanSku)
                .put("sessionGeneration",aceNetSessionGeneration).put("freshSessionReset",credentials!=null))
            if(credentials==null)finishAceNetProductionOperationallyUnavailable(requestId,cleanSku,mode,"NO_SAVED_CREDENTIALS","AceNet session renewal requires saved credentials.")
            else beginAceNetProductionHardRepair(requestId,cleanSku,mode,"session_stale")
            return
        }
        ensurePersistentAceNetWorker()
        if(aceNetRetrievalService.search(requestId,mode,cleanSku)){
            aceNetNativeDiagnostic("persistent_worker_fast_path_selected",JSONObject().put("requestId",requestId).put("mode",mode).put("requestedSku",cleanSku))
            return
        }
        if(aceNetRetrievalService.isBusy()){
            aceNetNativeDiagnostic("persistent_worker_busy_terminal",JSONObject().put("requestId",requestId).put("mode",mode).put("requestedSku",cleanSku))
            deliverAceNetProductionFailure(requestId,cleanSku,mode,"BUSY","AceNet is already completing another item request.")
            clearAceNetProductionIncident(requestId)
            return
        }
        aceNetNativeDiagnostic("persistent_worker_recovery_selected",JSONObject()
            .put("requestId",requestId).put("mode",mode).put("requestedSku",cleanSku)
            .put("workerReady",aceNetRetrievalService.isReady()).put("sessionAuthenticated",aceNetSessionAuthenticated)
            .put("transientItemExtraction",false))
        if(aceNetSessionAuthenticated && aceNetPersistentRetailerTemplate.isNotBlank())beginAceNetProductionSoftRepair(requestId,cleanSku,mode,"worker_not_ready")
        else beginAceNetProductionHardRepair(requestId,cleanSku,mode,"worker_not_ready_no_session")
    }

    private fun startDeferredAceNetCatalogLookup(requestId:String, sku:String, mode:String="PRODUCTION_CATALOG") {
        val cleanSku=sku.trim()
        val allowedMode=mode=="PRODUCTION_CATALOG" || mode=="PRODUCTION_MISC_CATALOG" || mode=="PRODUCTION_REPAIR_CATALOG"
        if(!allowedMode || requestId.isBlank() || cleanSku.isBlank()){
            deliverAceNetProductionFailure(requestId,cleanSku,mode,"INVALID_REQUEST","AceNet catalog request was invalid.")
            return
        }
        aceNetNativeDiagnostic("deferred_catalog_lookup_delegated",JSONObject().put("requestId",requestId).put("sku",cleanSku).put("mode",mode).put("sharedRecoveryOwner",true))
        startProductionAceNetLookup(requestId,cleanSku,mode)
    }

    private fun handlePersistentAceNetResult(requestId:String, mode:String, result:JSONObject) {
        val status=result.optString("status",result.optString("outcome","UNKNOWN")).uppercase()
        val requestedSku=result.optString("requestedSku").ifBlank{aceNetPendingProductionRequest?.takeIf{it.requestId==requestId}?.sku.orEmpty()}
        val returnedSku=result.optString("sku")
        val exact=requestedSku.isNotBlank() && requestedSku==returnedSku
        val skuEvidence=result.optBoolean("skuEvidence",false)
        if(!productionIncident.isActive(requestId)){
            aceNetNativeDiagnostic("persistent_worker_result_outside_active_incident",JSONObject()
                .put("requestId",requestId).put("mode",mode).put("status",status)
                .put("activeIncidentRequestId",productionIncident.activeRequestId).put("ignored",true))
            return
        }
        if(status=="INTERRUPTED"){
            aceNetNativeDiagnostic("persistent_worker_interrupted_terminal",JSONObject()
                .put("requestId",requestId).put("mode",mode).put("requestedSku",requestedSku)
                .put("foreground",aceNetAppForeground).put("recoveryStarted",false))
            deliverAceNetProductionFailure(requestId,requestedSku,mode,"INTERRUPTED",
                if(aceNetAppForeground)"AceNet lookup was interrupted by a worker lifecycle change." else "AceNet lookup was interrupted when the app moved to the background.")
            clearAceNetProductionIncident(requestId)
            return
        }
        if(status=="FOUND" && exact){
            val verifiedAt=System.currentTimeMillis()
            aceNetSessionManager.markRetailerVerified(verifiedAt)
            scheduleAceNetSessionExtension()
            registerAceNetHealthyResponse("persistent_worker_verified_lookup")
            val payload=JSONObject().put("requestId",requestId).put("found",true).put("status","FOUND").put("message",when(mode){"PRODUCTION_UPCS"->"AceNet returned the exact SKU and UPC selector values.";"PRODUCTION_CATALOG"->"AceNet returned the exact SKU deferred catalog fields.";"PRODUCTION_MISC_CATALOG"->"AceNet returned the exact SKU ACE MISC catalog fields and UPC selector values.";"PRODUCTION_REPAIR_CATALOG"->"AceNet returned the exact SKU repair catalog fields.";"PRODUCTION_PRICE_UPCS"->"AceNet returned the exact SKU retail price and UPC selector values.";else->"AceNet returned the exact SKU retail price."}).put("sku",requestedSku)
            when(mode){
                "PRODUCTION_PRICE" -> payload.put("price",result.optString("price"))
                "PRODUCTION_PRICE_UPCS" -> payload.put("price",result.optString("price")).put("catalog",JSONObject().put("sku",requestedSku).put("allUpcs",result.optJSONArray("upcs")?:JSONArray()))
                "PRODUCTION_CATALOG","PRODUCTION_MISC_CATALOG","PRODUCTION_REPAIR_CATALOG" -> payload.put("catalog",result.optJSONObject("catalog")?:JSONObject())
                else -> payload.put("catalog",JSONObject().put("sku",requestedSku).put("allUpcs",result.optJSONArray("upcs")?:JSONArray()))
            }
            val callback=when(mode){"PRODUCTION_UPCS"->"UPCNativeAceNetUpcResult";"PRODUCTION_CATALOG","PRODUCTION_MISC_CATALOG","PRODUCTION_REPAIR_CATALOG"->"UPCNativeAceNetCatalogResult";else->"UPCNativeAceNetPriceResult"}
            if(mainWebViewProvider() != null)webView.evaluateJavascript("window.$callback && window.$callback(${JSONObject.quote(payload.toString())});",null)
            clearAceNetProductionIncident(requestId)
            return
        }
        if(status=="FOUND_NO_UPC_DATA" && exact && mode in setOf("PRODUCTION_CATALOG","PRODUCTION_MISC_CATALOG","PRODUCTION_REPAIR_CATALOG")){
            val verifiedAt=System.currentTimeMillis()
            aceNetSessionManager.markRetailerVerified(verifiedAt)
            scheduleAceNetSessionExtension()
            registerAceNetHealthyResponse("persistent_worker_verified_no_upc_data")
            val missing=result.optJSONArray("missingFields")?:JSONArray().put("masterUpc")
            val payload=JSONObject().put("requestId",requestId).put("found",true).put("status","FOUND_NO_UPC_DATA")
                .put("message","AceNet verified the exact SKU and item fields, but the item page exposes no usable UPC selector data.")
                .put("sku",requestedSku).put("catalog",result.optJSONObject("catalog")?:JSONObject()).put("missingFields",missing)
            aceNetNativeDiagnostic("persistent_worker_no_upc_data_terminal",JSONObject()
                .put("requestId",requestId).put("mode",mode).put("requestedSku",requestedSku)
                .put("missingFields",missing).put("classificationBasis",result.optString("classificationBasis","EXACT_SKU_STABLE_NO_UPC_SELECTOR")))
            if(mainWebViewProvider() != null)webView.evaluateJavascript("window.UPCNativeAceNetCatalogResult && window.UPCNativeAceNetCatalogResult(${JSONObject.quote(payload.toString())});",null)
            clearAceNetProductionIncident(requestId)
            return
        }
        if(mode=="PRODUCTION_REPAIR_CATALOG" && status=="FOUND_PARTIAL" && exact){
            val verifiedAt=System.currentTimeMillis()
            aceNetSessionManager.markRetailerVerified(verifiedAt)
            scheduleAceNetSessionExtension()
            registerAceNetHealthyResponse("persistent_worker_verified_partial_catalog")
            val missing=result.optJSONArray("missingFields")?:JSONArray()
            val payload=JSONObject().put("requestId",requestId).put("found",true).put("status","FOUND_PARTIAL")
                .put("message","AceNet verified the exact SKU and returned the available authoritative repair fields.")
                .put("sku",requestedSku).put("catalog",result.optJSONObject("catalog")?:JSONObject()).put("missingFields",missing)
            aceNetNativeDiagnostic("repair_catalog_partial_verified",JSONObject()
                .put("requestId",requestId).put("requestedSku",requestedSku).put("missingFields",missing)
                .put("sessionGeneration",aceNetSessionGeneration))
            if(mainWebViewProvider() != null)webView.evaluateJavascript("window.UPCNativeAceNetCatalogResult && window.UPCNativeAceNetCatalogResult(${JSONObject.quote(payload.toString())});",null)
            clearAceNetProductionIncident(requestId)
            return
        }
        if(status=="NOT_FOUND"){
            registerAceNetHealthyResponse("persistent_worker_conclusive_not_found")
            aceNetNativeDiagnostic("persistent_worker_not_found_terminal",JSONObject()
                .put("requestId",requestId).put("mode",mode).put("requestedSku",requestedSku))
            deliverAceNetProductionFailure(requestId,requestedSku,mode,"NOT_FOUND","AceNet reported that this SKU was not found.")
            clearAceNetProductionIncident(requestId)
            return
        }
        val httpStatus=result.optInt("httpStatus",0)
        if(status=="HTTP_ERROR"){
            when {
                httpStatus in listOf(500,502,503,504) -> finishAceNetProductionServerDown(requestId,requestedSku,mode,httpStatus,"AceNet item service returned HTTP $httpStatus.")
                httpStatus==401 || httpStatus==403 -> beginAceNetProductionHardRepair(requestId,requestedSku,mode,"http_auth_$httpStatus")
                httpStatus==404 -> finishAceNetProductionOperationallyUnavailable(requestId,requestedSku,mode,"HTTP_404","AceNet returned HTTP 404 for the item service. Library-only operation is active for this running session.")
                else -> {
                    deliverAceNetProductionFailure(requestId,requestedSku,mode,"HTTP_ERROR","AceNet returned HTTP $httpStatus for this item request.")
                    clearAceNetProductionIncident(requestId)
                }
            }
            return
        }
        if(status=="AUTH_REQUIRED" || status=="AUTH_FAILED"){
            beginAceNetProductionHardRepair(requestId,requestedSku,mode,"authentication_required")
            return
        }
        if(status=="TIMEOUT" && skuEvidence){
            // Exact item-page evidence was seen; a requested field simply failed to complete.
            // Do not destroy a healthy authenticated session for field-level incompleteness.
            registerAceNetHealthyResponse("persistent_worker_field_level_incomplete")
            aceNetNativeDiagnostic("persistent_worker_field_incomplete_terminal",JSONObject()
                .put("requestId",requestId).put("mode",mode).put("requestedSku",requestedSku)
                .put("skuEvidence",true).put("sessionRecoveryStarted",false))
            deliverAceNetProductionFailure(requestId,requestedSku,mode,"TIMEOUT","AceNet loaded the item page, but the requested field set did not complete within 12 seconds.")
            clearAceNetProductionIncident(requestId)
            return
        }
        if(status=="NETWORK_ERROR" && AceNetRuntimeClassifier.isDeviceConnectivityFailure(result)){
            finishAceNetProductionOperationallyUnavailable(requestId,requestedSku,mode,"NETWORK_UNAVAILABLE","The device network could not reach AceNet. The authenticated session was not deliberately reset.")
            return
        }
        if((status=="TIMEOUT"||status=="SKU_TIMEOUT")&&productionIncident.softRepairAttempted&&!productionIncident.hardRepairAttempted){registerAceNetHealthyResponse("production_soft_canary_verified_item_timeout");aceNetNativeDiagnostic("persistent_worker_timeout_after_verified_canary",JSONObject().put("requestId",requestId).put("mode",mode).put("requestedSku",requestedSku).put("hardRepairStarted",false));deliverAceNetProductionFailure(requestId,requestedSku,mode,"TIMEOUT","AceNet verified the session with a known item, but this SKU still did not resolve within the bounded item retry.");clearAceNetProductionIncident(requestId);return}
        if(status=="NETWORK_ERROR"&&productionIncident.softRepairAttempted&&!productionIncident.hardRepairAttempted&&AceNetRuntimeClassifier.isTransientTransportFailure(result)){registerAceNetHealthyResponse("production_soft_canary_verified_transient_item_failure");aceNetNativeDiagnostic("persistent_worker_transient_network_after_verified_canary",JSONObject().put("requestId",requestId).put("mode",mode).put("requestedSku",requestedSku).put("hardRepairStarted",false));deliverAceNetProductionFailure(requestId,requestedSku,mode,"NETWORK_ERROR","AceNet verified the session, but this item request hit a repeated transient transport failure.");clearAceNetProductionIncident(requestId);return}
        if(productionIncident.hardRepairAttempted){finishAceNetProductionOperationallyUnavailable(requestId,requestedSku,mode,status.ifBlank{"UNAVAILABLE"},"AceNet item retrieval failed on the final attempt after full session recovery.");return}
        when(status){
            "MALFORMED_PAGE","NETWORK_ERROR","SKU_MISMATCH","UNEXPECTED_HOST","TIMEOUT","SKU_TIMEOUT" -> beginAceNetProductionSoftRepair(requestId,requestedSku,mode,"worker_$status")
            else -> {
                aceNetNativeDiagnostic("persistent_worker_unclassified_failure",JSONObject()
                    .put("requestId",requestId).put("mode",mode).put("status",status)
                    .put("requestedSku",requestedSku).put("softRepairAttempted",productionIncident.softRepairAttempted)
                    .put("hardRepairAttempted",productionIncident.hardRepairAttempted))
                if(productionIncident.softRepairAttempted)beginAceNetProductionHardRepair(requestId,requestedSku,mode,"worker_$status")
                else beginAceNetProductionSoftRepair(requestId,requestedSku,mode,"worker_$status")
            }
        }
    }

    private fun cancelAceNetStartupWarmupForSplashTimeout() {
        // Startup UI deadlines must never destroy authenticated AceNet bootstrap/search work.
        // Native authentication and worker timers own cancellation.
        aceNetNativeDiagnostic("startup_ui_timeout_non_destructive",JSONObject()
            .put("requestId",aceNetRequestId ?: JSONObject.NULL)
            .put("requestKind",aceNetRequestKind).put("phase",aceNetPhase)
            .put("authenticatedPreserved",aceNetSessionAuthenticated)
            .put("workerDestroyed",false))
    }

    private fun currentNetworkConnectivityState(): JSONObject {
        val started = System.currentTimeMillis()
        return try {
            val manager = activity.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val network = manager.activeNetwork
            val capabilities = network?.let { manager.getNetworkCapabilities(it) }
            val activeNetworkPresent = network != null
            val internetCapability = capabilities?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
            val validated = capabilities?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) == true
            val captivePortal = capabilities?.hasCapability(NetworkCapabilities.NET_CAPABILITY_CAPTIVE_PORTAL) == true
            val transportWifi = capabilities?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
            val transportCellular = capabilities?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true
            val transportEthernet = capabilities?.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) == true
            val classification = when {
                !activeNetworkPresent -> "NO_ACTIVE_NETWORK"
                !internetCapability -> "NO_INTERNET_CAPABILITY"
                captivePortal -> "CAPTIVE_PORTAL"
                !validated -> "NOT_VALIDATED"
                else -> "VALIDATED_INTERNET"
            }
            JSONObject()
                .put("source", "Android ConnectivityManager/NetworkCapabilities")
                .put("activeNetworkPresent", activeNetworkPresent)
                .put("internetCapability", internetCapability)
                .put("validated", validated)
                .put("captivePortal", captivePortal)
                .put("transportWifi", transportWifi)
                .put("transportCellular", transportCellular)
                .put("transportEthernet", transportEthernet)
                .put("classification", classification)
                .put("internetReachability", when {
                    validated -> "AVAILABLE"
                    !activeNetworkPresent || !internetCapability || captivePortal -> "UNAVAILABLE"
                    else -> "UNKNOWN"
                })
                .put("elapsedMs", System.currentTimeMillis() - started)
        } catch (e: Exception) {
            JSONObject()
                .put("source", "Android ConnectivityManager/NetworkCapabilities")
                .put("classification", "CHECK_FAILED")
                .put("internetReachability", "UNKNOWN")
                .put("errorClass", e.javaClass.name)
                .put("errorMessage", e.message ?: "")
                .put("elapsedMs", System.currentTimeMillis() - started)
        }
    }
    private fun recordStartupNetworkPreflight() {
        val network=currentNetworkConnectivityState()
        aceNetNativeDiagnostic("startup_network_preflight",JSONObject(network.toString())
            .put("diagnosticOnly",true).put("gatesAceNetStartup",false))
        notifyAceNetStartupState("CHECKING","Checking network and AceNet session…",48,"NETWORK")
    }
    private fun beginAceNetStartupAuthentication() {
        if (aceNetStartupResolved || aceNetStartupPromptShown || aceNetRequestId != null || aceNetFreshSessionResetInProgress) return
        aceNetInitialStartupBegun=true
        aceNetStartupResolved=false
        aceNetHealthStatus="CHECKING"
        val credentials=loadAceNetCredentialsEncrypted()
        if(credentials==null){
            notifyAceNetHealthState("startup_credentials_required")
            notifyAceNetStartupState("CHECKING","AceNet credentials are required before startup can determine service availability.",52,"CREDENTIALS")
            aceNetNativeDiagnostic("startup_acenet_credentials_required",JSONObject().put("credentialsSaved",false).put("startupHeld",true).put("networkProbeRun",true))
            showAceNetStartupCredentialPrompt()
        }else{
            aceNetStartupResolved=false
            aceNetStartupOnly=true
            aceNetRequestKind="STARTUP_WARMUP"
            aceNetRecoveryAttempted=false
            aceNetRecoveryInProgress=false
            aceNetAuthenticationNetworkRetryAttempted=false
            aceNetRetailerBootstrapRetryAttempted=false
            aceNetExpectedFreshLogin=true
            beginAceNetStartupReadinessDeadline()
            val requestId="startup-warmup-${System.currentTimeMillis()}"
            aceNetNativeDiagnostic("startup_acenet_warmup_started",JSONObject()
                .put("credentialsSaved",true).put("warmupSku",aceNetWarmupSku).put("background",true)
                .put("reason","cold_app_start").put("freshSessionRequired",true))
            notifyAceNetStartupState("CHECKING","Starting a fresh AceNet session…",55,"SESSION")
            startFreshAceNetSession(requestId,credentials.first,credentials.second,aceNetWarmupSku,"cold_app_start")
        }
    }

    private fun showAceNetStartupCredentialPrompt() {
        if (aceNetStartupPromptShown || activity.isFinishing) return
        aceNetStartupPromptShown = true
        val layout = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            val pad=(20*activity.resources.displayMetrics.density).toInt()
            setPadding(pad,pad/2,pad,pad/2)
        }
        val user = EditText(activity).apply {
            hint="AceNet User ID"; inputType=InputType.TYPE_CLASS_TEXT
            setSingleLine(true)
        }
        val password = EditText(activity).apply {
            hint="AceNet Password"
            inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setSingleLine(true)
        }
        layout.addView(user); layout.addView(password)
        val dialog=AlertDialog.Builder(activity)
            .setTitle("AceNet Sign-In")
            .setMessage("Enter your AceNet credentials once. They will be encrypted in Android private storage and used to restore your AceNet session at startup.")
            .setView(layout)
            .setCancelable(false)
            .setPositiveButton("Save & Continue",null)
            .setNegativeButton("Continue Offline") { _,_ ->
                aceNetStartupPromptShown=false
                aceNetHealthStatus="UNAVAILABLE"
                notifyAceNetHealthState("startup_user_offline")
                completeAceNetStartupAuthentication(false,"OFFLINE","AceNet sign-in skipped. Library-only operation remains available.")
            }.create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val u=user.text?.toString()?.trim().orEmpty()
                val p=password.text?.toString().orEmpty()
                if(u.isBlank()||p.isBlank()){ if(u.isBlank())user.error="Required";if(p.isBlank())password.error="Required";return@setOnClickListener }
                if(!saveAceNetCredentialsEncrypted(u,p)){ password.error="Credentials could not be encrypted";return@setOnClickListener }
                aceNetStartupPromptShown=false;dialog.dismiss()
                aceNetStartupResolved=false;aceNetHealthStatus="UNKNOWN"
                notifyAceNetStartupState("CHECKING","Credentials saved. Preparing AceNet for the first item lookup…")
                aceNetNativeDiagnostic("startup_credentials_saved_warmup_started",JSONObject().put("warmupSku",aceNetWarmupSku))
                restartPersistentAceNetWarmup("credentials_saved")
            }
        }
        dialog.show()
    }
    private fun completeAceNetStartupAuthentication(authenticated: Boolean, status: String, message: String) {
        releaseAceNetStartupReadinessDeadline()
        if(aceNetStartupBackgroundedDuringCheck && !aceNetAppForeground && aceNetHealthStatus!="ONLINE" && aceNetHealthStatus!="DOWN"){
            aceNetStartupResolved=true;aceNetStartupOnly=false;aceNetStartupRequestId=null;aceNetRequestId=null;aceNetSessionAuthenticated=authenticated;aceNetUser="";aceNetPassword="";destroyAceNetTestView()
            aceNetNativeDiagnostic("backgrounded_startup_terminal_deferred",JSONObject().put("status",status).put("healthStatus",aceNetHealthStatus).put("policy","FOREGROUND_REVALIDATION_REQUIRED"));return
        }
        if (aceNetHealthStatus!="ONLINE" && aceNetHealthStatus!="DOWN" && aceNetHealthStatus!="UNAVAILABLE") {
            val previousHealthStatus=aceNetHealthStatus
            aceNetNativeDiagnostic("startup_terminal_health_invariant_repair", JSONObject()
                .put("whatWeAreDoing", "Prevent a non-conclusive service state from surviving terminal AceNet startup.")
                .put("expectedResult", "Terminal startup health is ONLINE, UNAVAILABLE, or DOWN.")
                .put("actualResult", "Terminal completion was requested with a non-conclusive health state; converting it to operationally UNAVAILABLE.")
                .put("requestedStartupStatus", status)
                .put("previousHealthStatus", previousHealthStatus)
                .put("terminalHealthStatus", "UNAVAILABLE"))
            aceNetHealthStatus="UNAVAILABLE"
            notifyAceNetHealthState("startup_terminal_invariant_repair")
        }
        aceNetSessionAuthenticated=authenticated
        if(authenticated){
            scheduleAceNetSessionExtension()
            aceNetNativeDiagnostic("startup_authentication_verified",JSONObject()
                .put("status",status).put("healthStatus",aceNetHealthStatus)
                .put("userPresent",aceNetAuthenticatedUserPresent).put("storePresent",aceNetAuthenticatedStorePresent)
                .put("lastAuthenticatedMs",aceNetLastAuthenticatedMs)
                .put("sessionEstablishedMs",aceNetSessionEstablishedMs)
                .put("homeVerifiedMs",aceNetHomeVerifiedMs)
                .put("retailerVerifiedMs",aceNetRetailerVerifiedMs)
                .put("sessionGeneration",aceNetSessionGeneration))
        }else{
            aceNetNativeDiagnostic("startup_authentication_unverified",JSONObject()
                .put("status",status).put("healthStatus",aceNetHealthStatus)
                .put("userPresent",aceNetAuthenticatedUserPresent).put("storePresent",aceNetAuthenticatedStorePresent))
        }
        aceNetStartupResolved=true
        aceNetStartupOnly=false
        aceNetStartupRequestId=null
        aceNetUser="";aceNetPassword=""
        notifyAceNetStartupState(status,message)
        destroyAceNetTestView()
        reconcileBackgroundedStartupAfterForeground()
    }
    private fun completeAceNetStartupUnavailable(reason:String, message:String) {
        // Operational UNAVAILABLE means the app cannot rely on AceNet for this startup/workflow.
        // It does not claim a global server outage unless authoritative HTTP 500/502/503/504 evidence set DOWN.
        if (aceNetHealthStatus != "DOWN") aceNetHealthStatus="UNAVAILABLE"
        val authenticated=aceNetSessionAuthenticated && aceNetAuthenticatedUserPresent && aceNetAuthenticatedStorePresent
        notifyAceNetHealthState(reason)
        aceNetNativeDiagnostic("startup_item_service_unavailable",JSONObject()
            .put("reason",reason).put("authenticated",authenticated).put("healthStatus",aceNetHealthStatus)
            .put("terminal",true).put("checkingActive",false)
            .put("globalServerDownEvidence",aceNetHealthStatus=="DOWN"))
        completeAceNetStartupAuthentication(authenticated,if(authenticated)"SIGNED_IN" else "UNAVAILABLE",message)
    }
    private fun aceNetViewRole(view: WebView?): String = when(view) {
        aceNetTestView -> "opener"
        aceNetResultView -> "popup"
        else -> "unknown"
    }

    private fun aceNetNavigationDiagnostic(event:String, view:WebView?, url:String?, extra:JSONObject=JSONObject()) {
        extra.put("viewRole",aceNetViewRole(view))
            .put("url",AceNetRuntimeClassifier.safeUrl(url.orEmpty()))
            .put("urlForensics",AceNetRuntimeClassifier.urlForensics(url))
            .put("phase",aceNetPhase)
            .put("currentUrl",AceNetRuntimeClassifier.safeUrl(view?.url.orEmpty()))
            .put("currentUrlForensics",AceNetRuntimeClassifier.urlForensics(view?.url))
            .put("originalUrl",AceNetRuntimeClassifier.safeUrl(view?.originalUrl.orEmpty()))
            .put("originalUrlForensics",AceNetRuntimeClassifier.urlForensics(view?.originalUrl))
            .put("title",(view?.title ?: "").take(160))
        aceNetNativeDiagnostic(event,extra)
    }

    private fun captureAceNetRenderedPageDiagnostic(view:WebView, event:String, reason:String) {
        val js="""
          (function(){
            try{
              function redactUrl(raw){
                try{
                  var u=new URL(raw,document.baseURI||location.href);
                  u.searchParams.forEach(function(_,k){u.searchParams.set(k,'[redacted]');});
                  u.hash='';
                  return u.href;
                }catch(_){return raw||'';}
              }
              var root=document.documentElement ? document.documentElement.cloneNode(true) : null;
              if(root){
                root.querySelectorAll('input,textarea').forEach(function(el){
                  if(el.hasAttribute('value'))el.setAttribute('value','[redacted]');
                  if('value' in el)try{el.value='[redacted]';}catch(_){}
                  el.textContent='';
                });
                root.querySelectorAll('select').forEach(function(el){
                  [].slice.call(el.options||[]).forEach(function(o){o.removeAttribute('selected');});
                });
                root.querySelectorAll('[href]').forEach(function(el){el.setAttribute('href',redactUrl(el.getAttribute('href')||''));});
                root.querySelectorAll('[src]').forEach(function(el){el.setAttribute('src',redactUrl(el.getAttribute('src')||''));});
                root.querySelectorAll('form[action]').forEach(function(el){el.setAttribute('action',redactUrl(el.getAttribute('action')||''));});
              }
              var candidates=[].slice.call(document.querySelectorAll('a,button,[role="button"]')).map(function(el){
                var text=(el.innerText||el.textContent||'').trim().replace(/\s+/g,' ').slice(0,240);
                var href=el.href||el.getAttribute&&el.getAttribute('href')||'';
                var onclick=el.getAttribute&&el.getAttribute('onclick')||'';
                return {tag:(el.tagName||'').toLowerCase(),id:(el.id||'').slice(0,120),className:(el.className||'').toString().slice(0,180),
                  text:text,href:redactUrl(href).slice(0,1000),onclick:String(onclick||'').slice(0,1000)};
              }).filter(function(x){return /(log\s*out|logout|sign\s*out|profile|account|user|store)/i.test((x.text+' '+x.id+' '+x.className+' '+x.href+' '+x.onclick));}).slice(0,100);
              var forms=[].slice.call(document.forms||[]).map(function(f){
                return {id:(f.id||'').slice(0,120),name:(f.name||'').slice(0,120),method:(f.method||'').slice(0,20),
                  action:redactUrl(f.action||'').slice(0,1000),
                  inputs:[].slice.call(f.querySelectorAll('input,button')).slice(0,80).map(function(i){
                    return {tag:(i.tagName||'').toLowerCase(),type:(i.type||'').slice(0,40),id:(i.id||'').slice(0,120),name:(i.name||'').slice(0,120)};
                  })};
              }).slice(0,40);
              var html=root ? root.outerHTML : '';
              html=html.replace(/([?&](?:token|access_token|id_token|code|state|SAMLRequest|SAMLResponse|RelayState|wresult|wctx|csrf|xsrf)=)[^&"'<>\s]*/gi,'$1[redacted]');
              return JSON.stringify({url:redactUrl(location.href||''),title:document.title||'',readyState:document.readyState||'',
                html:html,htmlLength:html.length,candidateControls:candidates,forms:forms});
            }catch(e){return JSON.stringify({captureError:String(e&&e.message||e)});}
          })();
        """.trimIndent()
        view.evaluateJavascript(js){ raw ->
            try{
                var decoded=raw?:""
                if(decoded.startsWith("\""))decoded=org.json.JSONTokener(decoded).nextValue() as? String?:decoded
                val captured=JSONObject(decoded)
                aceNetNativeDiagnostic(event,JSONObject()
                    .put("reason",reason)
                    .put("url",AceNetRuntimeClassifier.safeUrl(captured.optString("url")))
                    .put("urlForensics",AceNetRuntimeClassifier.urlForensics(captured.optString("url")))
                    .put("title",captured.optString("title").take(240))
                    .put("readyState",captured.optString("readyState"))
                    .put("htmlLength",captured.optInt("htmlLength",0))
                    .put("candidateControls",captured.optJSONArray("candidateControls"))
                    .put("forms",captured.optJSONArray("forms"))
                    .put("sanitizedHtml",captured.optString("html"))
                    .put("captureError",captured.optString("captureError")))
            }catch(e:Exception){
                aceNetNativeDiagnostic("${event}_failed",JSONObject().put("reason",reason).put("errorType",e.javaClass.simpleName))
            }
        }
    }

    private fun startAceNetTest(requestId: String, userId: String, password: String, sku: String, preserveRecoveryState: Boolean = false) {
        aceNetLastFailureEvidence=null
        if(aceNetStartupOnly || aceNetSessionRepairOnly) aceNetStartupRetailerBootstrapPending=false
        if(!preserveRecoveryState){ aceNetRecoveryAttempted=false;aceNetRecoveryInProgress=false }
        if (requestId.isBlank() || userId.isBlank() || password.isBlank() || sku.isBlank()) {
            aceNetRequestId=requestId; aceNetSku=sku.trim()
            finishAceNetTest(false,"INVALID_INPUT",if(aceNetStartupOnly)"User ID and password are required." else "User ID, password, and SKU are required.",null); return
        }
        // Production and startup searches always use a fresh transient WebView.
        // The authenticated CookieManager session may persist; a warmed search page/WebView may not.
        destroyAceNetTestView()
        aceNetRequestId=requestId; aceNetSku=sku.trim(); aceNetUser=userId; aceNetPassword=password
        aceNetRetailerFallbackAttempted=false
        aceNetPhase="OPENING"; aceNetStartedMs=System.currentTimeMillis()
        aceNetHomeReadyMs=0L;aceNetSearchInvokedMs=0L;aceNetResolvedMs=0L;aceNetProductImageUrl="";aceNetProductImageScore=0;aceNetProductImageWidth=0;aceNetProductImageHeight=0
        aceNetIframeFirstSeenMs=0L;aceNetRetailerPromotionMs=0L
        aceNetOuterPageEverReachedThreshold=false;aceNetOuterPageMaxBodyTextLength=0
        val defaultAuthDeadline=aceNetStartedMs+(if(aceNetStartupOnly)AceNetTimingPolicy.STARTUP_SESSION_READINESS_MS else 60_000L)
        aceNetAuthDeadlineMs=if(aceNetSessionRepairOnly && productionIncident.hardRecoveryDeadlineMs>aceNetStartedMs) minOf(defaultAuthDeadline,productionIncident.hardRecoveryDeadlineMs) else defaultAuthDeadline
        aceNetLoginInspectionAttempts=0; aceNetHomeInspectionAttempts=0
        aceNetSearchActionAttempted = false
        aceNetStatus("STARTING","Opening AceNet sign-in…")
        aceNetNativeDiagnostic("test_started",JSONObject().put("skuLength",aceNetSku.length))

        val testView=WebView(activity); aceNetTestView=testView
        testView.addJavascriptInterface(AceNetResultBridge(testView), "AceNetResultBridge")
        testView.settings.javaScriptEnabled=true
        testView.settings.domStorageEnabled=true
        testView.settings.javaScriptCanOpenWindowsAutomatically=true
        testView.settings.setSupportMultipleWindows(true)
        testView.settings.allowFileAccess=false
        testView.settings.allowContentAccess=false
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(testView,true)
        testView.webChromeClient=object:WebChromeClient(){
            override fun onCreateWindow(view:WebView?,isDialog:Boolean,isUserGesture:Boolean,resultMsg:Message?):Boolean{
                aceNetNavigationDiagnostic("popup_requested",view,view?.url,JSONObject()
                    .put("isDialog",isDialog).put("isUserGesture",isUserGesture)
                    .put("messageWhat",resultMsg?.what ?: -1))
                val popup=WebView(activity)
                aceNetResultView?.destroy()
                aceNetResultView=popup
                popup.addJavascriptInterface(AceNetResultBridge(popup), "AceNetResultBridge")
                popup.settings.javaScriptEnabled=true
                popup.settings.domStorageEnabled=true
                popup.settings.javaScriptCanOpenWindowsAutomatically=true
                popup.settings.setSupportMultipleWindows(true)
                CookieManager.getInstance().setAcceptCookie(true)
                CookieManager.getInstance().setAcceptThirdPartyCookies(popup,true)
                popup.webViewClient=object:WebViewClient(){
                    override fun shouldOverrideUrlLoading(v:WebView?,request:WebResourceRequest?):Boolean{
                        aceNetNavigationDiagnostic("popup_navigation",v,request?.url?.toString(),JSONObject()
                            .put("method",request?.method.orEmpty()).put("isMainFrame",request?.isForMainFrame==true)
                            .put("isRedirect",request?.isRedirect==true)
                            .put("hasGesture",request?.hasGesture()==true))
                        return false
                    }
                    override fun onPageStarted(v:WebView?,url:String?,favicon:android.graphics.Bitmap?){
                        super.onPageStarted(v,url,favicon)
                        aceNetLastHost=Uri.parse(url.orEmpty()).host.orEmpty()
                        aceNetNavigationDiagnostic("popup_page_started",v,url)
                    }
                    override fun onPageFinished(v:WebView?,url:String?){
                        super.onPageFinished(v,url)
                        val child=v?:return
                        aceNetLastHost=Uri.parse(url.orEmpty()).host.orEmpty()
                        aceNetNavigationDiagnostic("popup_page_finished",child,url)
                        if(AceNetRuntimeClassifier.shouldCaptureAuthPage(url,child.title)){
                            captureAceNetRenderedPageDiagnostic(child,"authentication_page_html_snapshot","popup_page_finished")
                        }
                        aceNetPhase="RESULT"
                        if(aceNetResultStartedMs==0L)aceNetResultStartedMs=System.currentTimeMillis()
                        aceNetStatus("WAITING_FOR_RESULT","AceNet result window loaded. Inspecting ${AceNetRuntimeClassifier.safeUrl(url.orEmpty())}…")
                        inspectAceNetResult(child)
                    }
                    override fun onReceivedError(v:WebView?,request:WebResourceRequest?,error:WebResourceError?){
                        super.onReceivedError(v,request,error)
                        if(request?.isForMainFrame != true) return
                        aceNetNativeDiagnostic("popup_resource_error",JSONObject()
                            .put("url",AceNetRuntimeClassifier.safeUrl(request?.url?.toString().orEmpty()))
                            .put("mainFrame",request?.isForMainFrame==true)
                            .put("code",error?.errorCode)
                            .put("description",error?.description?.toString().orEmpty()))
                    }
                    override fun onReceivedHttpError(v:WebView?,request:WebResourceRequest?,response:WebResourceResponse?){
                        super.onReceivedHttpError(v,request,response)
                        if(request?.isForMainFrame != true) return
                        aceNetNativeDiagnostic("popup_http_error",JSONObject()
                            .put("url",AceNetRuntimeClassifier.safeUrl(request?.url?.toString().orEmpty()))
                            .put("mainFrame",request?.isForMainFrame==true)
                            .put("statusCode",response?.statusCode ?: 0)
                            .put("reason",response?.reasonPhrase.orEmpty()))
                    }
                }
                popup.webChromeClient=this
                val transport=resultMsg?.obj as? WebView.WebViewTransport ?: return false
                transport.webView=popup
                resultMsg.sendToTarget()
                return true
            }
            override fun onCloseWindow(window:WebView?){
                aceNetNativeDiagnostic("popup_closed")
                if(window===aceNetResultView){aceNetResultView=null}
                window?.destroy()
            }
        }
        testView.webViewClient=object:WebViewClient(){
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val u=request?.url?.toString().orEmpty()
                aceNetNavigationDiagnostic("main_frame_navigation",view,u,JSONObject()
                    .put("method",request?.method.orEmpty())
                    .put("isMainFrame",request?.isForMainFrame==true)
                    .put("isRedirect",request?.isRedirect==true)
                    .put("hasGesture",request?.hasGesture()==true))
                return false
            }
            override fun onPageStarted(view:WebView?,url:String?,favicon:android.graphics.Bitmap?){
                super.onPageStarted(view,url,favicon)
                val v=view?:return
                val current=url.orEmpty()
                aceNetLastHost=Uri.parse(current).host.orEmpty()
                aceNetNavigationDiagnostic("page_started",v,current)
            }
            override fun onPageFinished(view:WebView?,url:String?){
                super.onPageFinished(view,url)
                val v=view?:return
                val current=url.orEmpty(); aceNetLastHost=Uri.parse(current).host.orEmpty()
                aceNetNavigationDiagnostic("page_finished",v,current)
                val currentUri=try{Uri.parse(current)}catch(_:Exception){null}
                val currentHost=currentUri?.host.orEmpty().lowercase()
                val currentPath=currentUri?.path.orEmpty()
                when {
                    AceNetRuntimeClassifier.isItemResultUrl(current) -> {
                        val testFlow=!aceNetStartupOnly && !aceNetSessionRepairOnly && aceNetRequestKind=="TEST"
                        val readinessHandoff=((aceNetStartupOnly && aceNetRequestKind=="STARTUP_WARMUP") || aceNetSessionRepairOnly || testFlow) && aceNetStartupRetailerBootstrapPending && currentHost=="retailer.aceservices.com"
                        if(readinessHandoff){
                            val productionRepair=aceNetSessionRepairOnly
                            val bridgeTest=testFlow
                            aceNetStartupRetailerBootstrapPending=false
                            val template=aceNetPersistentRetailerTemplate
                            val templateUri=try{Uri.parse(template)}catch(_:Exception){null}
                            val templateExpectedSku=if(bridgeTest)aceNetSku.trim() else aceNetWarmupSku
                            val templateValid=templateUri?.host.orEmpty().equals("retailer.aceservices.com",true)
                                && templateUri?.path.orEmpty().contains("/itemdetailv2/itemdetail/",true)
                                && templateUri?.getQueryParameter("sku").orEmpty().equals(templateExpectedSku,true)
                            if(templateValid){
                                if(!productionRepair && !bridgeTest)releaseAceNetStartupReadinessDeadline()
                                aceNetSessionManager.markRetailerSessionReady()
                                recordAceNetCookieState("session_cookie_state_at_retailer_ready","retailer_session_ready")
                            }
                            aceNetNativeDiagnostic(if(productionRepair)"production_session_repair_retailer_ready" else "startup_retailer_session_ready",JSONObject()
                                .put("warmupSku",aceNetWarmupSku).put("host",currentHost)
                                .put("sessionGeneration",aceNetSessionGeneration).put("retailerVerifiedMs",aceNetRetailerVerifiedMs)
                                .put("currentUrlHasQuery",!currentUri?.query.isNullOrBlank())
                                .put("preservedTemplateHasQuery",!templateUri?.query.isNullOrBlank())
                                .put("preservedTemplateValid",templateValid)
                                .put("transientRetailerExtractionSkipped",true).put("handoffToPersistentWorker",templateValid)
                                .put("readinessFlow",when{productionRepair->"PRODUCTION_REPAIR";bridgeTest->"BRIDGE_TEST";else->"STARTUP"}))
                            if(productionRepair){
                                completeAceNetProductionSessionRepair(template,templateValid)
                            }else if(bridgeTest){
                                completeAceNetBridgeTestThroughWorker(template,templateValid)
                            }else{
                                notifyAceNetStartupState("CHECKING","AceNet item session established. Starting persistent verification…",71,"RETAILER_SESSION_READY")
                                destroyAceNetTestView(clearRequest=true)
                                ensurePersistentAceNetWorker()
                                if(!templateValid){
                                    aceNetHealthStatus="UNAVAILABLE"
                                    notifyAceNetHealthState("startup_preserved_retailer_template_invalid")
                                    aceNetNativeDiagnostic("startup_preserved_retailer_template_invalid",JSONObject()
                                        .put("retrievalServiceReady",aceNetRetrievalService.isReady()).put("templatePresent",template.isNotBlank())
                                        .put("templateHasQuery",!templateUri?.query.isNullOrBlank()))
                                    completeAceNetStartupAuthentication(true,"SIGNED_IN","AceNet is signed in, but the retailer verification template was unavailable. Library-only pricing is active.")
                                }else{
                                    startAceNetStartupPersistentVerification(template,1)
                                }
                            }
                            return
                        }
                        aceNetPhase="RESULT"
                        if(aceNetResultStartedMs==0L) aceNetResultStartedMs=System.currentTimeMillis()
                        aceNetStatus("WAITING_FOR_RESULT",if(aceNetRequestKind=="PRODUCTION_UPCS") "AceNet item page loaded. Waiting for UPC selector data…" else "AceNet item page loaded. Waiting for retail-price data…")
                        aceNetNativeDiagnostic("result_page_ready_for_inspection",JSONObject()
                            .put("requestKind",aceNetRequestKind)
                            .put("host",currentHost)
                            .put("retailerContinuation",currentHost=="retailer.aceservices.com"))
                        inspectAceNetResult(v)
                    }
                    AceNetRuntimeClassifier.isLogoutPage(current,v.title) -> {
                        val wasStartup=aceNetStartupOnly
                        val wasRepair=aceNetSessionRepairOnly
                        aceNetSessionAuthenticated=false;aceNetAuthenticatedUserPresent=false;aceNetAuthenticatedStorePresent=false
                        aceNetHomeHtmlCapturedForSession=false
                        aceNetNativeDiagnostic("logout_page_detected",JSONObject()
                            .put("url",AceNetRuntimeClassifier.safeUrl(current)).put("title",v.title.orEmpty().take(160))
                            .put("path",currentPath).put("startup",wasStartup).put("productionRepair",wasRepair)
                            .put("classification","AUTHENTICATION_SESSION_LOST"))
                        when {
                            wasStartup && retryAceNetStartupAuthenticationNetworkFailure("logout_page") -> return
                            wasStartup -> {
                                aceNetHealthStatus="UNAVAILABLE"
                                notifyAceNetHealthState("startup_logout_page_after_retry")
                                completeAceNetStartupAuthentication(false,"UNAVAILABLE","AceNet returned a logout page while establishing the startup session. Library-only operation is active.")
                            }
                            wasRepair -> failAceNetProductionSessionRepair("AUTH_FAILED","AceNet returned a logout page while restoring the session.")
                            aceNetRequestKind.startsWith("PRODUCTION") -> recoverAceNetSessionAndRetry("logout_page")
                            else -> finishAceNetTest(false,"AUTH_FAILED","AceNet returned a logout page and the current session is no longer authenticated.",null)
                        }
                    }
                    currentHost == "acenet.aceservices.com" -> {
                        if(aceNetPhase!="VERIFYING_HOME")aceNetHomeInspectionAttempts=0
                        aceNetPhase="VERIFYING_HOME"
                        aceNetStatus("VERIFYING_SESSION","AceNet host reached. Verifying authenticated search controls…")
                        inspectAceNetHome(v,current)
                    }
                    currentHost == "sts.aceservices.com" -> {
                        aceNetHomeHtmlCapturedForSession=false
                        captureAceNetRenderedPageDiagnostic(v,"authentication_page_html_snapshot","main_frame_sts_redirect")
                        recordAceNetCookieState("session_cookie_state_at_sts","sts_page_finished")
                        if(((aceNetStartupOnly && aceNetRequestKind=="STARTUP_WARMUP") || aceNetSessionRepairOnly || (!aceNetStartupOnly && !aceNetSessionRepairOnly && aceNetRequestKind=="TEST")) && aceNetStartupRetailerBootstrapPending){
                            aceNetPhase="RETAILER_SSO"
                            aceNetStatus("ESTABLISHING_RETAILER_SESSION","AceNet retailer sign-on is completing…")
                            inspectAceNetRetailerSso(v,current)
                        }else{
                            val wasAuthenticated=aceNetSessionAuthenticated
                            if (wasAuthenticated) {
                                aceNetSessionAuthenticated=false
                                aceNetNativeDiagnostic("session_expired",JSONObject().put("reason","redirected_to_login"))
                            }
                            if(aceNetUser.isBlank() || aceNetPassword.isBlank()) {
                                loadAceNetCredentialsEncrypted()?.let { aceNetUser=it.first; aceNetPassword=it.second }
                            }
                            aceNetNativeDiagnostic("sts_login_route_selected",JSONObject()
                                .put("startup",aceNetStartupOnly)
                                .put("expectedFreshLogin",aceNetExpectedFreshLogin)
                                .put("wasAuthenticated",wasAuthenticated)
                                .put("recoveryConsumed",false)
                                .put("sessionGeneration",aceNetSessionGeneration))
                            aceNetExpectedFreshLogin=false
                            aceNetPhase="LOGIN";aceNetLoginInspectionAttempts=0
                            aceNetStatus("AUTHENTICATING","AceNet sign-in page loaded. Waiting for login controls…")
                            inspectAceNetLogin(v,current)
                        }
                    }
                    else -> {
                        if(AceNetRuntimeClassifier.shouldCaptureAuthPage(current,v.title)){
                            captureAceNetRenderedPageDiagnostic(v,"authentication_page_html_snapshot","main_frame_unexpected_auth_destination")
                        }
                        aceNetPhase="REDIRECTING"
                        aceNetStatus("REDIRECTING","AceNet authentication is redirecting…")
                    }
                }
            }
            override fun onReceivedError(view:WebView?,request:WebResourceRequest?,error:WebResourceError?){
                super.onReceivedError(view,request,error)
                if(request?.isForMainFrame != true) return
                val evidence=JSONObject()
                    .put("sourceClass","MainActivity.AceNetWebViewClient")
                    .put("sourceCallback","WebViewClient.onReceivedError")
                    .put("sourceFunction","startAceNetTest.onReceivedError")
                    .put("evidenceKind","WEBVIEW_RESOURCE_ERROR")
                    .put("observedVsInferred","OBSERVED")
                    .put("rawHttpStatus",JSONObject.NULL)
                    .put("url",AceNetRuntimeClassifier.safeUrl(request?.url?.toString().orEmpty()))
                    .put("host",request?.url?.host.orEmpty())
                    .put("mainFrame",request?.isForMainFrame==true)
                    .put("webViewErrorCode",error?.errorCode)
                    .put("rawDescription",error?.description?.toString().orEmpty())
                    .put("phase",aceNetPhase)
                    .put("requestKind",aceNetRequestKind)
                if(request?.isForMainFrame==true) aceNetLastFailureEvidence=JSONObject(evidence.toString())
                aceNetNativeDiagnostic("resource_error",evidence)
                if(request?.isForMainFrame==true){
                    val reason=error?.description?.toString()?:"AceNet page failed to load."
                    if(aceNetStartupOnly && !aceNetSessionAuthenticated && retryAceNetStartupAuthenticationNetworkFailure(reason))return
                    if(aceNetStartupOnly && aceNetSessionAuthenticated && retryAceNetStartupRetailerBootstrap(view,reason))return
                    finishAceNetTest(false,"NETWORK_ERROR",reason,null)
                }
            }
            override fun onReceivedHttpError(view:WebView?,request:WebResourceRequest?,response:WebResourceResponse?){
                super.onReceivedHttpError(view,request,response)
                if(request?.isForMainFrame != true) return
                val evidence=JSONObject()
                    .put("sourceClass","MainActivity.AceNetWebViewClient")
                    .put("sourceCallback","WebViewClient.onReceivedHttpError")
                    .put("sourceFunction","startAceNetTest.onReceivedHttpError")
                    .put("evidenceKind","HTTP_ERROR_RESPONSE")
                    .put("observedVsInferred","OBSERVED")
                    .put("url",AceNetRuntimeClassifier.safeUrl(request?.url?.toString().orEmpty()))
                    .put("host",request?.url?.host.orEmpty())
                    .put("mainFrame",request?.isForMainFrame==true)
                    .put("rawHttpStatus",response?.statusCode ?: 0)
                    .put("rawReasonPhrase",response?.reasonPhrase.orEmpty())
                    .put("phase",aceNetPhase)
                    .put("requestKind",aceNetRequestKind)
                if(request?.isForMainFrame==true) aceNetLastFailureEvidence=JSONObject(evidence.toString())
                aceNetNativeDiagnostic("http_error",evidence)
                if(request?.isForMainFrame==true){
                    val statusCode=response?.statusCode ?: 0
                    when(statusCode){
                        500,502,503,504 -> {
                            val terminalEvidence=JSONObject(evidence.toString())
                                .put("classification","OBSERVED_SERVER_UNAVAILABLE")
                                .put("operationalImpact","ACENET_ITEM_SERVICE_DOWN")
                                .put("globalServerDownEvidence",true)
                                .put("inferred",false)
                            aceNetLastFailureEvidence=JSONObject(terminalEvidence.toString())
                            aceNetHealthStatus="DOWN"
                            // A server 5xx proves service unavailability, not authentication loss.
                            notifyAceNetHealthState("http_${statusCode}_main_frame")
                            aceNetNativeDiagnostic("service_health_terminal",terminalEvidence)
                            if(aceNetStartupOnly){
                                completeAceNetStartupAuthentication(false,"UNAVAILABLE","AceNet service returned HTTP $statusCode ${response?.reasonPhrase.orEmpty()}. Library-only operation remains available.")
                            }else{
                                finishAceNetTest(false,"SERVICE_DOWN","AceNet returned HTTP $statusCode ${response?.reasonPhrase.orEmpty()} and cannot provide item data for this request.",null)
                            }
                        }
                        401 -> {
                            aceNetSessionAuthenticated=false;aceNetAuthenticatedUserPresent=false;aceNetAuthenticatedStorePresent=false
                            aceNetNativeDiagnostic("http_authentication_required",JSONObject(evidence.toString()).put("classification","AUTHENTICATION_REQUIRED"))
                            if(!aceNetStartupOnly && aceNetRequestKind.startsWith("PRODUCTION")) recoverAceNetSessionAndRetry("http_401_main_frame")
                            else finishAceNetTest(false,"AUTH_FAILED","AceNet returned HTTP 401 and the current session is not authenticated.",null)
                        }
                        403 -> {
                            aceNetNativeDiagnostic("http_access_denied",JSONObject(evidence.toString()).put("classification","ACCESS_DENIED"))
                            finishAceNetTest(false,"ACCESS_DENIED","AceNet returned HTTP 403 Access Denied.",null)
                        }
                        404 -> {
                            aceNetNativeDiagnostic("http_resource_not_found",JSONObject(evidence.toString()).put("classification","RESOURCE_NOT_FOUND").put("globalServerDownEvidence",false))
                            if(aceNetStartupOnly && aceNetSessionAuthenticated && retryAceNetStartupRetailerBootstrap(view,"http_404"))return
                            finishAceNetTest(false,"RESOURCE_NOT_FOUND","AceNet returned HTTP 404 for the required page. This request cannot retrieve item data.",null)
                        }
                        in 400..499 -> {
                            aceNetNativeDiagnostic("http_client_error",JSONObject(evidence.toString()).put("classification","HTTP_CLIENT_ERROR").put("globalServerDownEvidence",false))
                            finishAceNetTest(false,"HTTP_CLIENT_ERROR","AceNet returned HTTP $statusCode ${response?.reasonPhrase.orEmpty()}.",null)
                        }
                    }
                }
            }
        }
        if (aceNetSessionAuthenticated) aceNetNativeDiagnostic("session_cookie_reused_fresh_view",JSONObject().put("reason","fresh_lookup_webview"))
        if (aceNetStartupOnly && aceNetSessionAuthenticated) {
            aceNetNativeDiagnostic("startup_session_reused",JSONObject().put("itemCanaryRun",true).put("warmupSku",aceNetWarmupSku))
            aceNetNativeDiagnostic("startup_warmup_item_lookup_started",JSONObject().put("warmupSku",aceNetWarmupSku).put("source","retained_session"))
            loadAceNetDirectItem(testView)
        } else if (aceNetSessionRepairOnly && aceNetSessionAuthenticated) {
            aceNetNativeDiagnostic("production_session_repair_authenticated_session_ready",JSONObject()
                .put("warmupSku",aceNetWarmupSku).put("transientItemExtraction",false))
            loadAceNetDirectItem(testView)
        } else {
            testView.loadUrl("https://acenet.aceservices.com/")
        }
    }

    private fun loadAceNetDirectItem(view: WebView) {
        if (aceNetRequestId == null || view !== aceNetTestView) return
        aceNetPhase = "RESULT"
        aceNetResultStartedMs = System.currentTimeMillis()
        aceNetOuterPageEverReachedThreshold = false
        aceNetOuterPageMaxBodyTextLength = 0
        val directUrl = "https://acenet.aceservices.com/item-detail-direct-sku?SKU=${Uri.encode(aceNetSku.trim())}"
        aceNetNativeDiagnostic("production_direct_item_navigation", JSONObject()
            .put("requestKind", aceNetRequestKind)
            .put("requestedSku", aceNetSku.trim())
            .put("reason", "skip_home_search_round_trip"))
        aceNetStatus("LOOKING_UP_SKU", "Opening AceNet Item Details for SKU $aceNetSku…")
        aceNetNativeDiagnostic("direct_item_navigation_issued",JSONObject().put("requestedSku",aceNetSku.trim()).put("requestKind",aceNetRequestKind))
        view.loadUrl(directUrl)
    }

    private fun performAceNetSearch(view: WebView) {
        if (aceNetRequestId == null || view !== aceNetTestView || aceNetSearchActionAttempted) return
        aceNetSearchActionAttempted = true
        aceNetPhase = "SEARCHING"
        aceNetStatus("LOOKING_UP_SKU", "Authenticated. Using AceNet's Product search for SKU $aceNetSku…")
        val js = """
          (function(){
            try{
              var el=document.getElementById('tbxSearchBox');
              var type=document.getElementById('ddlSearchType');
              var searchFn=(typeof window.SearchBtnClick==='function')?window.SearchBtnClick:null;
              if(!el)return JSON.stringify({ok:false,reason:'TBX_SEARCH_BOX_NOT_FOUND',hasSearchFunction:!!searchFn});
              if(type){
                type.value='Product';
                type.dispatchEvent(new Event('change',{bubbles:true}));
              }
              el.focus();
              el.value=${JSONObject.quote(aceNetSku)};
              el.dispatchEvent(new Event('input',{bubbles:true}));
              el.dispatchEvent(new Event('change',{bubbles:true}));
              var snapshot={
                input:(el.outerHTML||'').slice(0,4000),
                parent:(el.parentElement&&el.parentElement.outerHTML||'').slice(0,12000),
                searchType:type?{id:type.id||'',value:type.value||'',html:(type.outerHTML||'').slice(0,4000)}:null,
                hasSearchFunction:!!searchFn
              };
              if(!searchFn)return JSON.stringify({ok:false,reason:'SEARCH_BTN_CLICK_FUNCTION_NOT_FOUND',snapshot:snapshot});
              searchFn();
              return JSON.stringify({ok:true,method:'SearchBtnClick()',href:location.href,title:(document.title||'').slice(0,120),snapshot:snapshot});
            }catch(e){
              return JSON.stringify({ok:false,reason:'SEARCH_FUNCTION_EXCEPTION',error:String(e&&e.message||e)});
            }
          })();
        """.trimIndent()
        view.evaluateJavascript(js) { raw ->
            try {
                var decoded=raw?:""
                if(decoded.startsWith("\"")) decoded=org.json.JSONTokener(decoded).nextValue() as? String ?: decoded
                val state=JSONObject(decoded)
                if(aceNetSearchInvokedMs==0L)aceNetSearchInvokedMs=System.currentTimeMillis()
                aceNetNativeDiagnostic("search_function_invoked", state)
                aceNetNativeDiagnostic("search_dom_snapshot", state.optJSONObject("snapshot") ?: JSONObject())
                if (!state.optBoolean("ok")) {
                    aceNetSearchActionAttempted=false
                    finishAceNetTest(false,"SEARCH_CONTROL_NOT_FOUND","AceNet loaded, but its exact Product search function could not be invoked.",null)
                } else {
                    aceNetPhase="RESULT"
                    aceNetResultStartedMs=System.currentTimeMillis()
                    aceNetOuterPageEverReachedThreshold=false;aceNetOuterPageMaxBodyTextLength=0
                    aceNetStatus("WAITING_FOR_RESULT","AceNet SearchBtnClick() invoked. Waiting for item navigation…")
                }
            } catch (e:Exception) {
                aceNetSearchActionAttempted=false
                aceNetNativeDiagnostic("search_ui_parse_error",JSONObject().put("errorType",e.javaClass.simpleName))
                finishAceNetTest(false,"SEARCH_CONTROL_ERROR","AceNet's exact search action could not be interpreted.",null)
            }
        }
    }


    private fun inspectAceNetHome(view:WebView,currentUrl:String){
        if(aceNetRequestId==null || aceNetTestView!==view || aceNetPhase!="VERIFYING_HOME")return
        aceNetHomeInspectionAttempts++
        val js="""
          (function(){
            try{
              var input=document.getElementById('tbxSearchBox');
              var type=document.getElementById('ddlSearchType');
              var searchFn=(typeof window.SearchBtnClick==='function');
              var store=document.querySelector('[data-storenumber]');
               var body=(document.body&&document.body.innerText)||'';
               var userPresent=/\bHi,\s*[^!\n]{1,120}!/i.test(body)||!!document.querySelector('[class*="profile" i],[id*="profile" i],[class*="user" i],[id*="user" i]');
               var storePresent=!!(store&&String(store.getAttribute('data-storenumber')||'').trim());
               function cleanText(v){return String(v||'').replace(/\s+/g,' ').trim().slice(0,120);}
               function safeHref(el){try{var h=el&&el.href?new URL(el.href,location.href):null;return h?(h.origin+h.pathname):'';}catch(_){return '';}}
               function summary(el){
                 var r=null;try{r=el.getBoundingClientRect();}catch(_){}
                 return {
                   tag:String(el.tagName||'').toLowerCase(),
                   id:String(el.id||'').slice(0,120),
                   className:String(el.className||'').slice(0,200),
                   role:String(el.getAttribute&&el.getAttribute('role')||'').slice(0,80),
                   ariaLabel:String(el.getAttribute&&el.getAttribute('aria-label')||'').slice(0,160),
                   title:String(el.getAttribute&&el.getAttribute('title')||'').slice(0,160),
                   text:cleanText(el.innerText||el.textContent),
                   href:safeHref(el),
                   onclick:String(el.getAttribute&&el.getAttribute('onclick')||'').slice(0,220),
                   rect:r?{x:Math.round(r.x),y:Math.round(r.y),w:Math.round(r.width),h:Math.round(r.height)}:null
                 };
               }
               var candidates=[],topRight=[];
               var controls=[].slice.call(document.querySelectorAll('a,button,[role="button"],[onclick],input[type="button"],input[type="submit"],li,span,div'));
               var kw=/profile|account|user|session|sign\s*out|logout|log\s*out|menu|settings|preference/i;
               controls.forEach(function(el){
                 if(candidates.length<40){
                   var hay=[el.id,el.className,el.getAttribute&&el.getAttribute('aria-label'),el.getAttribute&&el.getAttribute('title'),el.getAttribute&&el.getAttribute('onclick'),el.innerText||el.textContent].join(' ');
                   if(kw.test(String(hay||'')))candidates.push(summary(el));
                 }
                 if(topRight.length<20){
                   try{
                     var r=el.getBoundingClientRect();
                     if(r.width>0&&r.height>0&&r.top>=0&&r.top<Math.min(window.innerHeight*0.35,320)&&r.left>window.innerWidth*0.55)topRight.push(summary(el));
                   }catch(_){}
                 }
               });
               var localKeys=[],sessionKeys=[];
               try{for(var i=0;i<localStorage.length&&i<80;i++)localKeys.push(String(localStorage.key(i)||''));}catch(_){}
               try{for(var j=0;j<sessionStorage.length&&j<80;j++)sessionKeys.push(String(sessionStorage.key(j)||''));}catch(_){}
               return JSON.stringify({readyState:document.readyState||'',hasSearchInput:!!input,hasSearchType:!!type,hasSearchFunction:searchFn,
                 userPresent:userPresent,storePresent:storePresent,title:(document.title||'').slice(0,120),
                 sessionSurface:{candidateControls:candidates,topRightControls:topRight,localStorageKeys:localKeys.sort(),sessionStorageKeys:sessionKeys.sort(),storageValuesRedacted:true}});
            }catch(e){return JSON.stringify({error:String(e&&e.message||e)});}
          })();
        """.trimIndent()
        view.evaluateJavascript(js){raw->
            if(aceNetPhase!="VERIFYING_HOME"||aceNetTestView!==view)return@evaluateJavascript
            try{
                var decoded=raw?:""
                if(decoded.startsWith("\""))decoded=org.json.JSONTokener(decoded).nextValue() as? String?:decoded
                val state=JSONObject(decoded)
                val ready=state.optBoolean("hasSearchInput") && state.optBoolean("hasSearchFunction") && state.optBoolean("userPresent") && state.optBoolean("storePresent")
                aceNetNativeDiagnostic("home_dom_inspection",JSONObject()
                    .put("attempt",aceNetHomeInspectionAttempts).put("url",AceNetRuntimeClassifier.safeUrl(currentUrl))
                    .put("readyState",state.optString("readyState")).put("title",state.optString("title"))
                    .put("hasSearchInput",state.optBoolean("hasSearchInput")).put("hasSearchType",state.optBoolean("hasSearchType"))
                    .put("hasSearchFunction",state.optBoolean("hasSearchFunction"))
                     .put("userPresent",state.optBoolean("userPresent")).put("storePresent",state.optBoolean("storePresent")))
                if(ready){
                    aceNetNativeDiagnostic("home_session_surface_inspection",JSONObject()
                        .put("url",AceNetRuntimeClassifier.safeUrl(currentUrl))
                        .put("sessionGeneration",aceNetSessionGeneration)
                        .put("surface",state.optJSONObject("sessionSurface")?:JSONObject())
                        .put("passiveOnly",true)
                        .put("controlsClicked",false))
                    recordAceNetCookieState("session_cookie_state_at_home","home_verified")
                    val homeReadyAt=System.currentTimeMillis()
                    if(aceNetHomeReadyMs==0L)aceNetHomeReadyMs=homeReadyAt
                    aceNetSessionManager.markHomeVerified(
                        state.optBoolean("userPresent"),
                        state.optBoolean("storePresent"),
                        homeReadyAt
                    )
                    if(aceNetStartupOnly){
                        aceNetNativeDiagnostic("startup_authentication_verified",JSONObject()
                            .put("url",AceNetRuntimeClassifier.safeUrl(currentUrl)).put("attempt",aceNetHomeInspectionAttempts)
                            .put("userPresent",aceNetAuthenticatedUserPresent).put("storePresent",aceNetAuthenticatedStorePresent)
                            .put("itemCanaryRun",false).put("sessionGeneration",aceNetSessionGeneration)
                            .put("sessionEstablishedMs",aceNetSessionEstablishedMs).put("homeVerifiedMs",aceNetHomeVerifiedMs))
                        notifyAceNetStartupState("CHECKING","AceNet signed in. Preparing item verification…",66,"AUTHENTICATED")
                    }else{
                        aceNetNativeDiagnostic("authenticated_home_ready",JSONObject()
                            .put("url",AceNetRuntimeClassifier.safeUrl(currentUrl)).put("attempt",aceNetHomeInspectionAttempts)
                            .put("userPresent",aceNetAuthenticatedUserPresent).put("storePresent",aceNetAuthenticatedStorePresent)
                            .put("lastAuthenticatedMs",aceNetLastAuthenticatedMs).put("sessionGeneration",aceNetSessionGeneration))
                        scheduleAceNetSessionExtension()
                    }
                    aceNetPhase="AUTHENTICATED"; aceNetUser="";aceNetPassword=""
                    if(aceNetStartupOnly){
                        aceNetNativeDiagnostic("startup_warmup_item_lookup_started",JSONObject().put("warmupSku",aceNetWarmupSku).put("source","authenticated_home"))
                        loadAceNetDirectItem(view)
                    }else if(aceNetSessionRepairOnly){
                        aceNetNativeDiagnostic("production_session_repair_home_ready",JSONObject()
                            .put("warmupSku",aceNetWarmupSku).put("transientItemExtraction",false))
                        loadAceNetDirectItem(view)
                    }else if(aceNetRequestKind.startsWith("PRODUCTION")){
                        aceNetNativeDiagnostic("transient_production_retrieval_forbidden",JSONObject().put("requestKind",aceNetRequestKind))
                        finishAceNetTest(false,"ARCHITECTURE_GUARD","Production item retrieval must use PersistentAceNetWorker.",null)
                    }else performAceNetSearch(view)
                }else if(aceNetHomeInspectionAttempts<25 && System.currentTimeMillis()<aceNetAuthDeadlineMs){
                    view.postDelayed({inspectAceNetHome(view,currentUrl)},300L)
                }else{
                    aceNetSessionAuthenticated=false
                    finishAceNetTest(false,"SEARCH_HOME_TIMEOUT","AceNet host loaded, but authenticated Product search controls did not become ready.",null)
                }
            }catch(e:Exception){
                aceNetNativeDiagnostic("home_dom_parse_error",JSONObject().put("errorType",e.javaClass.simpleName))
                finishAceNetTest(false,"SEARCH_HOME_INSPECTION_ERROR","AceNet home page could not be verified.",null)
            }
        }
    }

    private fun inspectAceNetRetailerSso(view:WebView,currentUrl:String){
        val startupFlow=aceNetStartupOnly && aceNetRequestKind=="STARTUP_WARMUP"
        val repairFlow=aceNetSessionRepairOnly
        val testFlow=!aceNetStartupOnly && !aceNetSessionRepairOnly && aceNetRequestKind=="TEST"
        if(aceNetRequestId==null || aceNetTestView!==view || (!startupFlow && !repairFlow && !testFlow) || !aceNetStartupRetailerBootstrapPending)return
        val flow=when{repairFlow->"PRODUCTION_REPAIR";testFlow->"BRIDGE_TEST";else->"STARTUP"}
        val js="""
          (function(){
            try{
              var user=document.getElementById('userNameInput');
              var pass=document.getElementById('passwordInput');
              var button=document.querySelector('button[onclick*="Login.submitLoginRequest"]')||document.querySelector('button.login-Btn');
              var saml=document.querySelector('form[action*="retailer.aceservices.com/saml/sp/profile/post/acs"] input[name="SAMLResponse"]');
              var samlForm=saml&&saml.form;
              return JSON.stringify({
                readyState:document.readyState||'',
                title:(document.title||'').slice(0,120),
                hasLoginControls:!!(user&&pass&&(button||(window.Login&&typeof Login.submitLoginRequest==='function'))),
                hasRetailerSamlResponse:!!saml,
                retailerSamlAction:samlForm?(samlForm.action||''):'',
                bodyText:((document.body&&document.body.innerText)||'').trim().replace(/\s+/g,' ').slice(0,500)
              });
            }catch(e){return JSON.stringify({error:String(e&&e.message||e)});}
          })();
        """.trimIndent()
        view.evaluateJavascript(js){raw->
            val stillStartup=aceNetStartupOnly && aceNetRequestKind=="STARTUP_WARMUP"
            val stillRepair=aceNetSessionRepairOnly
            val stillTest=!aceNetStartupOnly && !aceNetSessionRepairOnly && aceNetRequestKind=="TEST"
            if(aceNetTestView!==view || (!stillStartup && !stillRepair && !stillTest) || !aceNetStartupRetailerBootstrapPending)return@evaluateJavascript
            try{
                var decoded=raw?:""
                if(decoded.startsWith("\""))decoded=org.json.JSONTokener(decoded).nextValue() as? String?:decoded
                val state=JSONObject(decoded)
                val title=state.optString("title")
                val hasLoginControls=state.optBoolean("hasLoginControls")
                val hasSamlResponse=state.optBoolean("hasRetailerSamlResponse")
                val uri=try{Uri.parse(currentUrl)}catch(_:Exception){null}
                val queryNames=try{uri?.queryParameterNames ?: emptySet()}catch(_:Exception){emptySet<String>()}
                val isSamlRequest=queryNames.any{it.equals("SAMLRequest",true)}
                val isPassiveRetailerSignIn=queryNames.any{it.equals("wtrealm",true)} && currentUrl.contains("retailer.aceservices.com",true)
                aceNetNativeDiagnostic("retailer_sso_inspection",JSONObject()
                    .put("readinessFlow",flow).put("readyState",state.optString("readyState")).put("title",title)
                    .put("hasLoginControls",hasLoginControls).put("hasRetailerSamlResponse",hasSamlResponse)
                    .put("isSamlRequest",isSamlRequest).put("isPassiveRetailerSignIn",isPassiveRetailerSignIn)
                    .put("sessionAuthenticated",aceNetSessionAuthenticated).put("authenticationPreserved",true))
                when{
                    hasSamlResponse || isSamlRequest || (isPassiveRetailerSignIn && !hasLoginControls && !title.equals("Error",true)) -> {
                        aceNetPhase="RETAILER_SSO"
                        aceNetNativeDiagnostic("retailer_sso_transit",JSONObject()
                            .put("readinessFlow",flow).put("hasRetailerSamlResponse",hasSamlResponse)
                            .put("authenticationPreserved",true).put("waitingFor","retailer_itemdetail_return"))
                        if(stillStartup){
                            val remaining=(aceNetAuthDeadlineMs-System.currentTimeMillis()).coerceAtLeast(1L)
                            aceNetResultHandler.removeCallbacks(aceNetStartupRetailerDeadlineRunnable)
                            aceNetResultHandler.postDelayed(aceNetStartupRetailerDeadlineRunnable,remaining)
                            aceNetNativeDiagnostic("startup_retailer_sso_deadline_scheduled",JSONObject()
                                .put("remainingMs",remaining).put("deadlineMs",AceNetTimingPolicy.STARTUP_SESSION_READINESS_MS)
                                .put("authenticationPreserved",true).put("globalServerDownEvidence",false))
                            notifyAceNetStartupState("CHECKING","Completing AceNet retailer sign-on…",70,"RETAILER_SSO")
                        }
                    }
                    hasLoginControls -> {
                        aceNetStartupRetailerBootstrapPending=false
                        aceNetSessionAuthenticated=false
                        aceNetNativeDiagnostic("retailer_sso_login_required",JSONObject()
                            .put("readinessFlow",flow).put("authenticationInvalidated",true)
                            .put("action","existing_one_time_recovery"))
                        recoverAceNetSessionAndRetry("${flow.lowercase()}_retailer_sso_login_required")
                    }
                    title.equals("Error",true) -> {
                        aceNetStartupRetailerBootstrapPending=false
                        aceNetNativeDiagnostic("retailer_sso_error",JSONObject()
                            .put("readinessFlow",flow).put("authenticationPreserved",aceNetSessionAuthenticated)
                            .put("serviceHealthAuthority","UNAVAILABLE"))
                        if(stillRepair)failAceNetProductionSessionRepair("SESSION_UNAVAILABLE","AceNet retailer item session could not be established.")
                        else if(stillTest)finishAceNetTest(false,"SESSION_UNAVAILABLE","AceNet retailer item session could not be established.",null)
                        else completeAceNetStartupUnavailable("startup_retailer_sso_error","AceNet is signed in, but the retailer item session could not be established.")
                    }
                    else -> {
                        aceNetStartupRetailerBootstrapPending=false
                        aceNetNativeDiagnostic("retailer_sso_unrecognized",JSONObject()
                            .put("readinessFlow",flow).put("authenticationPreserved",aceNetSessionAuthenticated)
                            .put("serviceHealthAuthority","UNAVAILABLE"))
                        if(stillRepair)failAceNetProductionSessionRepair("SESSION_UNAVAILABLE","AceNet retailer sign-on returned an unrecognized page.")
                        else if(stillTest)finishAceNetTest(false,"SESSION_UNAVAILABLE","AceNet retailer sign-on returned an unrecognized page.",null)
                        else completeAceNetStartupUnavailable("startup_retailer_sso_unrecognized","AceNet is signed in, but retailer sign-on returned an unrecognized page.")
                    }
                }
            }catch(e:Exception){
                aceNetStartupRetailerBootstrapPending=false
                aceNetNativeDiagnostic("retailer_sso_inspection_error",JSONObject()
                    .put("readinessFlow",flow).put("errorType",e.javaClass.simpleName)
                    .put("authenticationPreserved",aceNetSessionAuthenticated))
                if(aceNetSessionRepairOnly)failAceNetProductionSessionRepair("SESSION_UNAVAILABLE","AceNet retailer item session could not be verified.")
                else if(!aceNetStartupOnly && aceNetRequestKind=="TEST")finishAceNetTest(false,"SESSION_UNAVAILABLE","AceNet retailer item session could not be verified.",null)
                else completeAceNetStartupUnavailable("startup_retailer_sso_inspection_error","AceNet is signed in, but the retailer item session could not be verified.")
            }
        }
    }

    private fun inspectAceNetLogin(view:WebView,currentUrl:String){
        if(aceNetRequestId==null || aceNetTestView!==view || aceNetPhase!="LOGIN")return
        aceNetLoginInspectionAttempts++
        val js="""
          (function(){
            var u=document.getElementById('userNameInput');
            var p=document.getElementById('passwordInput');
            var b=document.querySelector('button[onclick*="Login.submitLoginRequest"]')||document.querySelector('button.login-Btn');
            return JSON.stringify({ready:document.readyState,title:(document.title||'').slice(0,120),
              hasUser:!!u,hasPassword:!!p,hasButton:!!b,hasLoginObject:!!(window.Login&&typeof Login.submitLoginRequest==='function')});
          })();
        """.trimIndent()
        view.evaluateJavascript(js){raw->
            if(aceNetPhase!="LOGIN"||aceNetTestView!==view)return@evaluateJavascript
            try{
                var decoded=raw?:""
                if(decoded.startsWith("\""))decoded=org.json.JSONTokener(decoded).nextValue() as? String?:decoded
                val state=JSONObject(decoded)
                aceNetNativeDiagnostic("login_dom_inspection",JSONObject()
                    .put("attempt",aceNetLoginInspectionAttempts).put("url",AceNetRuntimeClassifier.safeUrl(currentUrl))
                    .put("readyState",state.optString("ready")).put("title",state.optString("title"))
                    .put("hasUser",state.optBoolean("hasUser")).put("hasPassword",state.optBoolean("hasPassword"))
                    .put("hasButton",state.optBoolean("hasButton")).put("hasLoginObject",state.optBoolean("hasLoginObject")))
                if(state.optBoolean("hasUser")&&state.optBoolean("hasPassword")&&(state.optBoolean("hasButton")||state.optBoolean("hasLoginObject"))){
                    submitAceNetLogin(view)
                }else if(aceNetLoginInspectionAttempts<25 && System.currentTimeMillis()<aceNetAuthDeadlineMs){
                    view.postDelayed({inspectAceNetLogin(view,currentUrl)},300L)
                }else{
                    finishAceNetTest(false,"LOGIN_CONTROLS_TIMEOUT","AceNet sign-in page loaded, but the expected login controls did not become available.",null)
                }
            }catch(e:Exception){
                aceNetNativeDiagnostic("login_dom_parse_error",JSONObject().put("errorType",e.javaClass.simpleName))
                finishAceNetTest(false,"LOGIN_INSPECTION_ERROR","AceNet login page could not be inspected.",null)
            }
        }
    }

    private fun submitAceNetLogin(view:WebView){
        aceNetPhase="SUBMITTING_LOGIN"
        val js="""
          (function(){
            var u=document.getElementById('userNameInput'),p=document.getElementById('passwordInput');
            if(!u||!p)return JSON.stringify({ok:false,reason:'FIELDS_MISSING'});
            u.focus();u.value=${JSONObject.quote(aceNetUser)};
            u.dispatchEvent(new Event('input',{bubbles:true}));u.dispatchEvent(new Event('change',{bubbles:true}));
            p.focus();p.value=${JSONObject.quote(aceNetPassword)};
            p.dispatchEvent(new Event('input',{bubbles:true}));p.dispatchEvent(new Event('change',{bubbles:true}));
            var b=document.querySelector('button[onclick*="Login.submitLoginRequest"]')||document.querySelector('button.login-Btn');
            if(b){b.click();return JSON.stringify({ok:true,method:'button_click'});}
            if(window.Login&&typeof Login.submitLoginRequest==='function'){Login.submitLoginRequest();return JSON.stringify({ok:true,method:'login_function'});}
            return JSON.stringify({ok:false,reason:'ACTION_MISSING'});
          })();
        """.trimIndent()
        view.evaluateJavascript(js){raw->
            val ok=raw?.contains("\\\"ok\\\":true")==true || raw?.contains("\"ok\":true")==true
            aceNetNativeDiagnostic("login_submission",JSONObject().put("accepted",ok).put("method",if(raw?.contains("button_click")==true)"button_click" else if(raw?.contains("login_function")==true)"login_function" else "unknown"))
            aceNetUser="";aceNetPassword=""
            if(ok){aceNetPhase="WAITING_FOR_ACENET";aceNetStatus("SIGN_IN_SUBMITTED","AceNet sign-in submitted. Waiting for authentication redirect…")}
            else finishAceNetTest(false,"LOGIN_SUBMIT_FAILED","AceNet login controls were found, but the sign-in action could not be submitted.",null)
        }
    }

    private fun inspectAceNetResult(view: WebView) {
        if (aceNetPhase != "RESULT" || aceNetRequestId == null || (view !== aceNetTestView && view !== aceNetResultView)) return
        val current=view.url.orEmpty()
        val uri=try{Uri.parse(current)}catch(_:Exception){null}
        val host=uri?.host.orEmpty().lowercase()
        if(host!="acenet.aceservices.com"){
            if(host=="retailer.aceservices.com"){
                aceNetNativeDiagnostic("transient_retailer_item_page_no_extraction",JSONObject()
                    .put("requestKind",aceNetRequestKind).put("requestedSku",aceNetSku.trim())
                    .put("itemExtractionOwner","PersistentAceNetWorker"))
            }
            return
        }
        val wrapper="""
          (function(){
            if(window.__upcWrapperObserver){try{window.__upcWrapperObserver.disconnect()}catch(_){}}
            var sent=false;
            function publish(){
              if(sent)return;
              var body=(document.body&&document.body.innerText)||'';
              var login=!!(document.getElementById('userNameInput')||document.getElementById('passwordInput'));
              var noItem=/\b(no (item|product|record)|item not found|sku not found|no results found)\b/i.test(body);
              var f=document.getElementById('iframeItemDetail'),u=f?(f.src||f.getAttribute('src')||''):'';
              if(!login&&!noItem&&!u)return false;
              sent=true;if(window.__upcWrapperObserver)window.__upcWrapperObserver.disconnect();
              try{AceNetResultBridge.observedResult(JSON.stringify({requestId:${JSONObject.quote(aceNetRequestId ?: "")},mode:'WRAPPER',frameUrl:u,login:login,noItem:noItem}));}
              catch(e){window.__upcAceDeliveryError=String(e&&e.message||e);}
              return true;
            }
            if(!publish()){
              window.__upcWrapperObserver=new MutationObserver(publish);
              window.__upcWrapperObserver.observe(document.documentElement||document,{subtree:true,childList:true,attributes:true});
            }
            return 'WRAPPER_OBSERVER_INSTALLED';
          })();
        """.trimIndent()
        view.evaluateJavascript(wrapper){
            aceNetNativeDiagnostic("wrapper_observer_installed",JSONObject()
                .put("requestedSku",aceNetSku).put("itemExtractionOwner","PersistentAceNetWorker"))
        }
    }



    private fun handleAceNetObservedResult(json:String, sourceView:WebView){
        val result=try{JSONObject(json)}catch(_:Exception){return}
        val active=aceNetRequestId ?: return
        if(result.optString("requestId")!=active){
            aceNetNativeDiagnostic("stale_observer_result_ignored",JSONObject().put("requestId",result.optString("requestId")))
            return
        }
        if(result.optString("mode")!="WRAPPER"){
            aceNetNativeDiagnostic("transient_item_evidence_ignored",JSONObject()
                .put("requestId",active).put("mode",result.optString("mode"))
                .put("itemExtractionOwner","PersistentAceNetWorker"))
            return
        }
        if(result.optBoolean("login")){
            aceNetSessionAuthenticated=false
            recoverAceNetSessionAndRetry("wrapper_login_controls")
            return
        }
        if(result.optBoolean("noItem")){
            finishAceNetTest(false,"NOT_FOUND","AceNet reported that the session-bootstrap SKU was not found.",null)
            return
        }
        val frameUrl=result.optString("frameUrl").trim()
        val frameUri=try{Uri.parse(frameUrl)}catch(_:Exception){null}
        val retailer=frameUri?.host.orEmpty().equals("retailer.aceservices.com",true)
            && frameUri?.path.orEmpty().contains("/itemdetailv2/itemdetail/",true)
        val frameSku=frameUri?.getQueryParameter("sku").orEmpty().trim()
        if(!retailer){
            finishAceNetTest(false,"INVALID_RETAILER_TARGET","AceNet wrapper did not provide the expected retailer ItemDetail destination.",null)
            return
        }
        if(frameSku.isNotBlank()&&!frameSku.equals(aceNetSku.trim(),true)){
            finishAceNetTest(false,"SKU_MISMATCH","AceNet wrapper targeted SKU $frameSku instead of ${aceNetSku.trim()}.",null)
            return
        }
        val now=System.currentTimeMillis()
        if(aceNetIframeFirstSeenMs==0L)aceNetIframeFirstSeenMs=now
        aceNetRetailerPromotionMs=now
        aceNetNativeDiagnostic("wrapper_retailer_target_resolved",JSONObject()
            .put("requestedSku",aceNetSku).put("targetSku",frameSku)
            .put("host","retailer.aceservices.com").put("itemExtractionOwner","PersistentAceNetWorker"))
        aceNetPersistentRetailerTemplate=frameUrl
        val readinessFlow=(aceNetStartupOnly && aceNetRequestKind=="STARTUP_WARMUP") || aceNetSessionRepairOnly || (!aceNetStartupOnly && aceNetRequestKind=="TEST")
        if(!readinessFlow){
            aceNetNativeDiagnostic("transient_item_retrieval_forbidden",JSONObject().put("requestKind",aceNetRequestKind))
            finishAceNetTest(false,"ARCHITECTURE_GUARD","Transient AceNet view may establish session readiness but may not retrieve item evidence.",null)
            return
        }
        aceNetStartupRetailerBootstrapPending=true
        val repair=aceNetSessionRepairOnly
        val bridgeTest=!aceNetStartupOnly && !repair && aceNetRequestKind=="TEST"
        aceNetNativeDiagnostic(when{repair->"production_session_repair_template_ready";bridgeTest->"bridge_test_template_ready";else->"startup_bootstrap_template_ready"},JSONObject()
            .put("warmupSku",aceNetWarmupSku).put("targetSku",frameSku).put("retailerTemplatePresent",true)
            .put("transientRetailerExtractionSkipped",true).put("retailerSessionBootstrapRequired",true)
            .put("readinessFlow",when{repair->"PRODUCTION_REPAIR";bridgeTest->"BRIDGE_TEST";else->"STARTUP"}))
        if(!repair && !bridgeTest)notifyAceNetStartupState("CHECKING","Establishing AceNet item session…",69,"RETAILER_SESSION")
        sourceView.loadUrl(frameUrl)
    }

    private fun finishAceNetTest(found: Boolean, status: String, message: String, price: String?, catalog: JSONObject? = null) {
        aceNetUser = ""
        aceNetPassword = ""
        if(aceNetSessionRepairOnly){
            aceNetNativeDiagnostic("production_session_repair_failed",JSONObject()
                .put("status",status).put("message",message).put("transientItemEvidenceAccepted",false))
            failAceNetProductionSessionRepair(status,message)
            return
        }
        if (aceNetStartupOnly) {
            if(status=="AUTH_FAILED" || status=="NO_SAVED_CREDENTIALS" || status=="LOGIN_CONTROLS_TIMEOUT" || status=="LOGIN_INSPECTION_ERROR" || (status=="NETWORK_ERROR" && !aceNetSessionAuthenticated)){
                aceNetHealthStatus="UNAVAILABLE"; aceNetSessionAuthenticated=false
                completeAceNetStartupAuthentication(false,"UNAVAILABLE",
                    if(status=="NETWORK_ERROR") "AceNet sign-in could not be verified after the bounded network retry. Library-only operation remains available."
                    else "AceNet sign-in was not confirmed. Library-only operation remains available.")
            }else completeAceNetStartupUnavailable("startup_${status.lowercase()}","AceNet sign-in succeeded, but item-session verification remained unavailable after the bounded retailer retry. Library-only operation remains active.")
            aceNetRequestId=null
            return
        }
        aceNetResolvedMs=System.currentTimeMillis()
        if(found && status=="FOUND"){
            val verifiedAt=aceNetResolvedMs
            aceNetRetailerVerifiedMs=verifiedAt
            aceNetLastSuccessfulLookupMs=verifiedAt
            aceNetSessionRefreshRequired=false
            recordAceNetSessionTimestamp("retailerVerifiedMs",aceNetRetailerVerifiedMs)
            recordAceNetSessionTimestamp("lastSuccessfulLookupMs",aceNetLastSuccessfulLookupMs)
            scheduleAceNetSessionExtension()
            aceNetNativeDiagnostic("retailer_session_verified_by_lookup",JSONObject()
                .put("requestKind",aceNetRequestKind).put("sessionGeneration",aceNetSessionGeneration)
                .put("retailerVerifiedMs",aceNetRetailerVerifiedMs))
        }
        aceNetNativeDiagnostic("lookup_timing_summary",JSONObject()
            .put("status",status).put("found",found)
            .put("homeReadyMs",if(aceNetHomeReadyMs>0L)aceNetHomeReadyMs-aceNetStartedMs else -1L)
            .put("searchInvokedMs",if(aceNetSearchInvokedMs>0L)aceNetSearchInvokedMs-aceNetStartedMs else -1L)
            .put("searchToResolvedMs",if(aceNetSearchInvokedMs>0L)aceNetResolvedMs-aceNetSearchInvokedMs else -1L)
            .put("resultPhaseMs",if(aceNetResultStartedMs>0L)aceNetResolvedMs-aceNetResultStartedMs else -1L)
            .put("iframeFirstSeenMs",if(aceNetIframeFirstSeenMs>0L)aceNetIframeFirstSeenMs-aceNetResultStartedMs else -1L)
            .put("retailerPromotionMs",if(aceNetRetailerPromotionMs>0L)aceNetRetailerPromotionMs-aceNetResultStartedMs else -1L)
            .put("totalNativeMs",aceNetResolvedMs-aceNetStartedMs)
)
        aceNetCallback(found, status, message, price, catalog)
        destroyAceNetTestView(clearRequest = true)
    }

    private fun destroyAceNetTestView(clearRequest: Boolean = false) {
        aceNetResultHandler.removeCallbacksAndMessages(null)
        aceNetTestView?.apply {
            stopLoading()
            loadUrl("about:blank")
            clearHistory()
            removeAllViews()
            destroy()
        }
        aceNetTestView = null
        aceNetResultView?.apply {
            stopLoading()
            loadUrl("about:blank")
            clearHistory()
            removeAllViews()
            destroy()
        }
        aceNetResultView = null
        aceNetPhase = "IDLE"
        aceNetResultStartedMs = 0L
        if (clearRequest) aceNetRequestId = null
    }

    private fun restartPersistentAceNetWarmup(reason:String, forceFreshSession:Boolean=false) {
        if(aceNetRequestId!=null || aceNetFreshSessionResetInProgress || !hasSavedAceNetCredentials())return
        val c=loadAceNetCredentialsEncrypted()?:return
        aceNetStartupResolved=false;aceNetStartupOnly=true;aceNetRequestKind="STARTUP_WARMUP";aceNetStartupRetailerBootstrapPending=false
        beginAceNetStartupReadinessDeadline()
        val fresh=forceFreshSession || !aceNetSessionReusable()
        val requestId="startup-warmup-${System.currentTimeMillis()}"
        aceNetNativeDiagnostic("startup_acenet_warmup_started",JSONObject()
            .put("credentialsSaved",true).put("warmupSku",aceNetWarmupSku).put("background",true)
            .put("reason",reason).put("freshSessionRequired",fresh).put("sessionGeneration",aceNetSessionGeneration))
        if(fresh)startFreshAceNetSession(requestId,c.first,c.second,aceNetWarmupSku,"warmup_$reason")
        else startAceNetTest(requestId,c.first,c.second,aceNetWarmupSku)
    }


}
