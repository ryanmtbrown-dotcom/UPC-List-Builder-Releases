/**
 * OWNERSHIP:
 * File: app/src/main/java/com/rmtb/upclistbuilder/AceNetProductionIncidentController.kt
 * Owner: Native AceNet Incident Timing
 * Role: Focused state controller
 * Responsibility: Owns bounded incident timing, active incident identity, soft-repair/hard-repair attempt flags, and hard-recovery deadline state.
 * Does not own: Authentication/session truth, WebView navigation, worker dispatch, service-health classification, or result delivery.
 * Side effects: Owns incident timers/handler state only.
 * Related code: Production decisions remain with AceNetProductionCoordinator; budgets come from AceNetTimingPolicy.
 */
package com.rmtb.upclistbuilder

import android.os.Handler
import android.os.Looper

/**
 * Owns timing and escalation state for one bounded production AceNet recovery incident.
 *
 * It deliberately does not own authentication, session truth, WebViews, worker dispatch, health
 * classification, or result delivery. Those decisions stay in AceNetProductionCoordinator.
 */
class AceNetProductionIncidentController(
    val incidentBudgetMs: Long = AceNetTimingPolicy.PRODUCTION_INCIDENT_MS,
    val softCanaryMs: Long = AceNetTimingPolicy.SOFT_CANARY_MS,
    val hardRecoveryBudgetMs: Long = AceNetTimingPolicy.HARD_RECOVERY_MS,
    private val handler: Handler = Handler(Looper.getMainLooper()),
    private val clock: () -> Long = { System.currentTimeMillis() }
) {
    var activeRequestId: String = ""
        private set
    private var startedMs: Long = 0L
    var softRepairAttempted: Boolean = false
        private set
    var hardRepairAttempted: Boolean = false
        private set
    var hardRecoveryDeadlineMs: Long = 0L
        private set

    fun ensure(requestId: String, onTimeout: () -> Unit): Boolean {
        if (activeRequestId == requestId && startedMs > 0L) return false
        clear()
        activeRequestId = requestId
        startedMs = clock()
        handler.postDelayed({
            if (activeRequestId == requestId) onTimeout()
        }, incidentBudgetMs)
        return true
    }

    fun clear(requestId: String? = null): Boolean {
        if (requestId != null && activeRequestId.isNotBlank() && activeRequestId != requestId) return false
        handler.removeCallbacksAndMessages(null)
        activeRequestId = ""
        startedMs = 0L
        softRepairAttempted = false
        hardRepairAttempted = false
        hardRecoveryDeadlineMs = 0L
        return true
    }

    fun isActive(requestId: String): Boolean = activeRequestId == requestId

    fun belongsToOther(requestId: String): Boolean =
        activeRequestId.isNotBlank() && activeRequestId != requestId

    fun elapsedMs(): Long = if (startedMs > 0L) clock() - startedMs else 0L

    fun markSoftRepairAttempted() {
        softRepairAttempted = true
    }

    fun markHardRepairAttempted(requestId: String, onTimeout: () -> Unit) {
        hardRepairAttempted = true
        hardRecoveryDeadlineMs = clock() + hardRecoveryBudgetMs
        handler.postDelayed({
            if (activeRequestId == requestId && hardRecoveryDeadlineMs > 0L && clock() >= hardRecoveryDeadlineMs) {
                onTimeout()
            }
        }, hardRecoveryBudgetMs)
    }

    fun remainingHardRecoveryMs(): Long =
        (hardRecoveryDeadlineMs - clock()).coerceAtLeast(0L)

    fun clearHardRecoveryDeadline() {
        hardRecoveryDeadlineMs = 0L
    }
}
