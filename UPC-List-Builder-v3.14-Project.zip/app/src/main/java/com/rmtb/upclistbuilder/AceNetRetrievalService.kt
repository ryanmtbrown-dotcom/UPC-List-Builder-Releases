/**
 * OWNERSHIP:
 * File: app/src/main/java/com/rmtb/upclistbuilder/AceNetRetrievalService.kt
 * Owner: Native AceNet Retrieval Boundary
 * Role: Lifecycle/dispatch service
 * Responsibility: Owns construction, lifecycle, readiness, and dispatch of the single retained PersistentAceNetWorker.
 * Does not own: Session credential storage, page extraction selectors, coordinator recovery policy, or WebView UI.
 * Side effects: Creates/owns the retained worker and forwards typed production requests.
 * Related code: Extraction internals belong solely to PersistentAceNetWorker; session authority belongs to AceNetSessionManager.
 */
package com.rmtb.upclistbuilder

import org.json.JSONObject

/**
 * Thin lifecycle/dispatch coordinator around the one authoritative item-page engine.
 *
 * This service owns retained-worker lifecycle and dispatch only. It intentionally contains no
 * navigation URL construction, DOM inspection, exact-SKU proof, price/UPC parsing, or catalog
 * extraction. Those remain exclusively in PersistentAceNetWorker.
 */
class AceNetRetrievalService(
    private val activity: MainActivity,
    private val emit: (String, JSONObject) -> Unit,
    private val complete: (requestId: String, mode: String, result: JSONObject) -> Unit
) {
    private var worker: PersistentAceNetWorker? = null

    fun currentWorker(): PersistentAceNetWorker? = worker
    fun isReady(): Boolean = worker?.isReady() == true
    fun isBusy(): Boolean = worker?.isBusy() == true

    fun ensureWorker(): PersistentAceNetWorker {
        val existing = worker
        if (existing != null) return existing
        return PersistentAceNetWorker(activity, emit, complete).also { worker = it }
    }

    fun search(requestId: String, mode: String, sku: String): Boolean =
        worker?.takeIf { it.isReady() }?.search(requestId, mode, sku) == true

    fun prime(template: String, sku: String, timeoutMs: Long = AceNetTimingPolicy.ITEM_ATTEMPT_MS, callback: (JSONObject) -> Unit): Boolean =
        ensureWorker().prime(template, sku, timeoutMs, callback)

    fun destroy(reason: String) {
        worker?.destroy(reason)
        worker = null
    }
}
