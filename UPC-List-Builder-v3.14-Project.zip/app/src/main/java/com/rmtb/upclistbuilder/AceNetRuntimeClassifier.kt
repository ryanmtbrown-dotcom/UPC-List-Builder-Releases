/**
 * OWNERSHIP:
 * File: app/src/main/java/com/rmtb/upclistbuilder/AceNetRuntimeClassifier.kt
 * Owner: Native AceNet Classification
 * Role: Pure/support classifier
 * Responsibility: Owns stateless URL/page/error classification and safe forensic URL shaping used by AceNet runtime coordination.
 * Does not own: Mutable session/request state, WebView lifecycle, retries, persistence, or result delivery.
 * Side effects: None beyond pure classification/redaction.
 * Related code: Mutable production state remains with AceNetProductionCoordinator.
 */
package com.rmtb.upclistbuilder

import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject

/**
 * Stateless AceNet runtime classification and redaction helpers.
 *
 * This owner contains no session, request, WebView, worker, or persistence state. It classifies
 * URLs/network failures and produces bounded redacted URL evidence for the coordinator.
 */
object AceNetRuntimeClassifier {
    fun safeUrl(url: String): String {
        return try {
            val uri = Uri.parse(url)
            val host = uri.host.orEmpty()
            val path = uri.path.orEmpty()
            if (host.equals("sts.aceservices.com", true)) "$host$path?[redacted]"
            else if (host.equals("acenet.aceservices.com", true)) "$host$path"
            else if (host.isNotBlank()) "$host$path" else "[unknown]"
        } catch (_: Exception) {
            "[unparseable]"
        }
    }

    fun urlForensics(url: String?): JSONObject {
        val raw = url.orEmpty()
        return try {
            val uri = Uri.parse(raw)
            val queryNames = JSONArray()
            try {
                uri.queryParameterNames.sorted().forEach { queryNames.put(it.take(120)) }
            } catch (_: Exception) {
            }
            JSONObject()
                .put("safeUrl", safeUrl(raw))
                .put("scheme", uri.scheme.orEmpty().take(24))
                .put("host", uri.host.orEmpty().take(160))
                .put("path", uri.path.orEmpty().take(500))
                .put("queryParameterNames", queryNames)
                .put("hasQuery", !uri.query.isNullOrBlank())
                .put("hasFragment", !uri.fragment.isNullOrBlank())
        } catch (_: Exception) {
            JSONObject().put("safeUrl", "[unparseable]")
        }
    }

    fun shouldCaptureAuthPage(url: String?, title: String?): Boolean {
        val uri = try { Uri.parse(url.orEmpty()) } catch (_: Exception) { null }
        val host = uri?.host.orEmpty().lowercase()
        val path = uri?.path.orEmpty().lowercase()
        val normalizedTitle = title.orEmpty().lowercase()
        if (host == "sts.aceservices.com") return true
        if (host.isNotBlank() &&
            host != "acenet.aceservices.com" &&
            host != "retailer.aceservices.com" &&
            host != "cdn.aceservices.com"
        ) return true
        return listOf("login", "signin", "sign-in", "auth", "adfs", "saml")
            .any { path.contains(it) || normalizedTitle.contains(it) }
    }

    fun isLogoutPage(url: String?, title: String?): Boolean {
        val uri = try { Uri.parse(url.orEmpty()) } catch (_: Exception) { null }
        val host = uri?.host.orEmpty().lowercase()
        val path = uri?.path.orEmpty().lowercase()
        val pageTitle = title.orEmpty().lowercase()
        if (host != "acenet.aceservices.com" &&
            host != "sts.aceservices.com" &&
            host != "retailer.aceservices.com"
        ) return false
        return path == "/vdesk/hangup.php3" ||
            path.contains("/fedauth/logout") ||
            pageTitle.contains("big-ip logout") ||
            pageTitle == "logout"
    }

    fun isItemResultUrl(url: String): Boolean {
        val uri = try { Uri.parse(url) } catch (_: Exception) { null }
        val host = uri?.host.orEmpty().lowercase()
        val path = uri?.path.orEmpty().lowercase()
        return (host == "acenet.aceservices.com" && path.contains("item-detail-direct-sku")) ||
            (host == "retailer.aceservices.com" && path.contains("/itemdetailv2/itemdetail/"))
    }

    fun isTransientTransportFailure(result: JSONObject): Boolean {
        val description=(result.optString("errorDescription")+" "+result.optString("message")).uppercase()
        return listOf("ERR_EMPTY_RESPONSE","ERR_CONNECTION_RESET","ERR_CONNECTION_CLOSED","ERR_CONNECTION_ABORTED","ERR_TIMED_OUT").any { description.contains(it) }
    }

    fun isDeviceConnectivityFailure(result: JSONObject): Boolean {
        val description = (result.optString("errorDescription") + " " + result.optString("message")).uppercase()
        return listOf(
            "ERR_INTERNET_DISCONNECTED",
            "ERR_NAME_NOT_RESOLVED",
            "ERR_NETWORK_CHANGED",
            "ERR_ADDRESS_UNREACHABLE",
            "ERR_NETWORK_ACCESS_DENIED"
        ).any { description.contains(it) }
    }
}
