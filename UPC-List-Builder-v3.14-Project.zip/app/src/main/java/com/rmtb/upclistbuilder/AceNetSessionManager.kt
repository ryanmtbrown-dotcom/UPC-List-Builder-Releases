/**
 * OWNERSHIP:
 * File: app/src/main/java/com/rmtb/upclistbuilder/AceNetSessionManager.kt
 * Owner: Native AceNet Session
 * Role: Session/credential service
 * Responsibility: Owns encrypted AceNet credential persistence and authoritative authenticated/session-readiness state.
 * Does not own: WebView navigation, item extraction, production request recovery, diagnostics retention, or UI.
 * Side effects: Reads/writes encrypted credential/session state and approved cookie/session evidence; no production item extraction.
 * Related code: Production coordination belongs to AceNetProductionCoordinator; worker lifecycle belongs to AceNetRetrievalService.
 */
package com.rmtb.upclistbuilder

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONObject
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Current owner for AceNet credentials and persisted session/readiness state.
 *
 * This class deliberately does not navigate AceNet or extract item data. MainActivity may still
 * host authentication WebViews through the coordinator, while item-page retrieval remains owned by
 * PersistentAceNetWorker / AceNetRetrievalService.
 */
class AceNetSessionManager(
    context: Context,
    private val diagnostic: (String, JSONObject) -> Unit,
    private val now: () -> Long = { System.currentTimeMillis() }
) {
    private val appContext = context.applicationContext
    private val sessionPrefs = appContext.getSharedPreferences("acenet_session_state", Context.MODE_PRIVATE)
    private val credentialPrefs = appContext.getSharedPreferences("acenet_secure_credentials", Context.MODE_PRIVATE)
    private val credentialAlias = "upc_list_builder_acenet_credentials_v1"

    var authenticated: Boolean = false
    var authenticatedUserPresent: Boolean = false
    var authenticatedStorePresent: Boolean = false
    var sessionRefreshRequired: Boolean = false
    var retailerTemplate: String = ""

    var lastAuthenticatedMs: Long = 0L
    var lastExtendedMs: Long = 0L
    var lastSuccessfulLookupMs: Long = 0L
    var sessionEstablishedMs: Long = 0L
    var homeVerifiedMs: Long = 0L
    var retailerVerifiedMs: Long = 0L
    var lastSessionResetMs: Long = 0L
    var sessionGeneration: Long = 0L

    fun restoreHistory(): JSONObject {
        sessionEstablishedMs = sessionPrefs.getLong("sessionEstablishedMs", 0L)
        homeVerifiedMs = sessionPrefs.getLong("homeVerifiedMs", 0L)
        retailerVerifiedMs = sessionPrefs.getLong("retailerVerifiedMs", 0L)
        lastAuthenticatedMs = sessionPrefs.getLong("lastAuthenticatedMs", 0L)
        lastExtendedMs = sessionPrefs.getLong("lastExtendedMs", 0L)
        lastSuccessfulLookupMs = sessionPrefs.getLong("lastSuccessfulLookupMs", 0L)
        lastSessionResetMs = sessionPrefs.getLong("lastSessionResetMs", 0L)
        sessionGeneration = sessionPrefs.getLong("sessionGeneration", 0L)
        val timestamp = now()
        fun age(value: Long) = if (value > 0L) (timestamp - value).coerceAtLeast(0L) else -1L
        return JSONObject()
            .put("sessionGeneration", sessionGeneration)
            .put("sessionEstablishedAgeMs", age(sessionEstablishedMs))
            .put("homeVerifiedAgeMs", age(homeVerifiedMs))
            .put("retailerVerifiedAgeMs", age(retailerVerifiedMs))
            .put("lastSuccessfulLookupAgeMs", age(lastSuccessfulLookupMs))
            .put("lastSessionResetAgeMs", age(lastSessionResetMs))
    }

    fun recordTimestamp(key: String, value: Long = now()) {
        sessionPrefs.edit().putLong(key, value).apply()
    }

    fun reuseBasisMs(): Long = maxOf(sessionEstablishedMs, retailerVerifiedMs, lastSuccessfulLookupMs, lastExtendedMs)

    fun isReusable(maxAgeMs: Long): Boolean {
        if (!authenticated || sessionRefreshRequired || sessionEstablishedMs <= 0L || retailerVerifiedMs <= 0L) return false
        val basis = reuseBasisMs()
        return basis > 0L && now() - basis < maxAgeMs
    }

    fun resetHistoryForGeneration(reason: String): JSONObject {
        val timestamp = now()
        sessionGeneration += 1L
        sessionEstablishedMs = 0L
        homeVerifiedMs = 0L
        retailerVerifiedMs = 0L
        lastAuthenticatedMs = 0L
        lastExtendedMs = 0L
        lastSuccessfulLookupMs = 0L
        lastSessionResetMs = timestamp
        sessionRefreshRequired = false
        retailerTemplate = ""
        sessionPrefs.edit()
            .putLong("sessionGeneration", sessionGeneration)
            .putLong("sessionEstablishedMs", 0L)
            .putLong("homeVerifiedMs", 0L)
            .putLong("retailerVerifiedMs", 0L)
            .putLong("lastAuthenticatedMs", 0L)
            .putLong("lastExtendedMs", 0L)
            .putLong("lastSuccessfulLookupMs", 0L)
            .putLong("lastSessionResetMs", timestamp)
            .apply()
        return JSONObject()
            .put("reason", reason)
            .put("sessionGeneration", sessionGeneration)
            .put("encryptedCredentialsPreserved", true)
    }

    fun markHomeVerified(userPresent: Boolean, storePresent: Boolean, verifiedAt: Long = now()) {
        authenticated = true
        authenticatedUserPresent = userPresent
        authenticatedStorePresent = storePresent
        if (sessionEstablishedMs <= 0L) {
            sessionEstablishedMs = verifiedAt
            recordTimestamp("sessionEstablishedMs", sessionEstablishedMs)
        }
        homeVerifiedMs = verifiedAt
        lastAuthenticatedMs = verifiedAt
        recordTimestamp("homeVerifiedMs", homeVerifiedMs)
        recordTimestamp("lastAuthenticatedMs", lastAuthenticatedMs)
        sessionRefreshRequired = false
    }

    fun markRetailerSessionReady(verifiedAt: Long = now()) {
        retailerVerifiedMs = verifiedAt
        recordTimestamp("retailerVerifiedMs", retailerVerifiedMs)
        sessionRefreshRequired = false
    }

    fun markRetailerVerified(verifiedAt: Long = now()) {
        retailerVerifiedMs = verifiedAt
        lastSuccessfulLookupMs = verifiedAt
        recordTimestamp("retailerVerifiedMs", retailerVerifiedMs)
        recordTimestamp("lastSuccessfulLookupMs", lastSuccessfulLookupMs)
        sessionRefreshRequired = false
    }

    fun markSuccessfulLookup(verifiedAt: Long = now()) {
        lastSuccessfulLookupMs = verifiedAt
        recordTimestamp("lastSuccessfulLookupMs", lastSuccessfulLookupMs)
        sessionRefreshRequired = false
    }

    fun clearAuthentication() {
        authenticated = false
        authenticatedUserPresent = false
        authenticatedStorePresent = false
    }

    fun hasSavedCredentials(): Boolean =
        credentialPrefs.contains("payload") && credentialPrefs.contains("iv")

    fun saveCredentials(userId: String, password: String): Boolean {
        if (userId.isBlank() || password.isBlank()) return false
        return try {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
            val payload = JSONObject().put("user", userId).put("password", password).toString().toByteArray(Charsets.UTF_8)
            val encrypted = cipher.doFinal(payload)
            credentialPrefs.edit()
                .putString("payload", Base64.encodeToString(encrypted, Base64.NO_WRAP))
                .putString("iv", Base64.encodeToString(cipher.iv, Base64.NO_WRAP))
                .apply()
            true
        } catch (error: Exception) {
            diagnostic("acenet_credentials_save_failed", JSONObject().put("errorType", error.javaClass.simpleName))
            false
        }
    }

    fun loadCredentials(): Pair<String, String>? {
        return try {
            val payload = credentialPrefs.getString("payload", null) ?: return null
            val iv = credentialPrefs.getString("iv", null) ?: return null
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), GCMParameterSpec(128, Base64.decode(iv, Base64.NO_WRAP)))
            val clear = String(cipher.doFinal(Base64.decode(payload, Base64.NO_WRAP)), Charsets.UTF_8)
            val obj = JSONObject(clear)
            val user = obj.optString("user")
            val password = obj.optString("password")
            if (user.isBlank() || password.isBlank()) null else Pair(user, password)
        } catch (error: Exception) {
            diagnostic("acenet_credentials_load_failed", JSONObject().put("errorType", error.javaClass.simpleName))
            null
        }
    }

    fun deleteCredentials(): Boolean {
        return try {
            credentialPrefs.edit().clear().apply()
            val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
            if (store.containsAlias(credentialAlias)) store.deleteEntry(credentialAlias)
            true
        } catch (error: Exception) {
            diagnostic("acenet_credentials_delete_failed", JSONObject().put("errorType", error.javaClass.simpleName))
            false
        }
    }

    private fun getOrCreateKey(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getKey(credentialAlias, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(
                credentialAlias,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            ).setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .build()
        )
        return generator.generateKey()
    }
}
