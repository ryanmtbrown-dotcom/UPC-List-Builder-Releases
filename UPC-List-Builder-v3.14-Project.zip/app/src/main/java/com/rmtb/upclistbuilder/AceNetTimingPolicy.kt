/**
 * OWNERSHIP:
 * File: app/src/main/java/com/rmtb/upclistbuilder/AceNetTimingPolicy.kt
 * Owner: Native AceNet Timing Policy
 * Role: Pure policy/constants
 * Responsibility: Owns shared bounded timing budgets for AceNet startup, extraction, incident, and recovery operations.
 * Does not own: Timers, handlers, retries, session state, extraction, or UI.
 * Side effects: None; constants/policy only.
 * Related code: Owners creating timers consume these budgets and own timer lifecycle.
 */
package com.rmtb.upclistbuilder

/**
 * One native timing policy for production AceNet item retrieval and recovery.
 *
 * The 50-second incident ceiling is derived from the permitted stages rather than chosen
 * independently: an ambiguous item may consume 12s, a malformed item may instead enter a
 * 5s soft-canary path, one full recovery owns at most 25s, and exactly one final item
 * attempt owns at most 12s. The JavaScript broker is allowed 2s beyond native ownership
 * solely for callback delivery/bridge cleanup.
 */
object AceNetTimingPolicy {
    const val STARTUP_SESSION_READINESS_MS = 25_000L
    const val STRUCTURE_INSPECTION_MS = 3_000L
    const val MALFORMED_CONFIRM_MS = 5_000L
    const val ITEM_ATTEMPT_MS = 12_000L
    const val SOFT_CANARY_MS = 5_000L
    const val HARD_RECOVERY_MS = 25_000L
    const val PRODUCTION_INCIDENT_MS = 50_000L
    const val BROKER_OWNERSHIP_MS = 52_000L
}
