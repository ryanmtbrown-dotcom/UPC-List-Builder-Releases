/**
 * OWNERSHIP:
 * File: app/src/main/java/com/rmtb/upclistbuilder/ChatGPTConnectionVault.kt
 * Owner: Optional ChatGPT MCP Native Connection
 * Role: Dedicated encrypted device-credential owner.
 * Responsibility: Encrypt and retrieve one paired-device token and exact HTTPS MCP origin.
 * Does not own: AceNet credentials, invoice content, authentication flow, network calls, or DSD imports.
 * Side effects: Android Keystore AES/GCM and private SharedPreferences only.
 * Related code: MainActivity.NativeBridge delegates to this vault; DSD app pairing stays in dsd/dsd-chatgpt-import.js.
 */
package com.rmtb.upclistbuilder

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONObject
import java.net.URI
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

class ChatGPTConnectionVault(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("chatgpt_mcp_connection_v1", Context.MODE_PRIVATE)
    private val keyAlias = "upc_list_builder_chatgpt_mcp_device_v1"

    fun save(url: String, token: String): Boolean {
        if (!validEndpoint(url) || !Regex("^[A-Za-z0-9_-]{43}$").matches(token)) return false
        return try {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, key())
            val bytes = JSONObject().put("url", url).put("token", token).toString().toByteArray(Charsets.UTF_8)
            prefs.edit()
                .putString("data", Base64.encodeToString(cipher.doFinal(bytes), Base64.NO_WRAP))
                .putString("iv", Base64.encodeToString(cipher.iv, Base64.NO_WRAP))
                .commit()
        } catch (_: Exception) { false }
    }

    fun read(): String {
        return try {
            val encrypted = prefs.getString("data", null) ?: return "{}"
            val iv = prefs.getString("iv", null) ?: return "{}"
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, Base64.decode(iv, Base64.NO_WRAP)))
            val obj = JSONObject(String(cipher.doFinal(Base64.decode(encrypted, Base64.NO_WRAP)), Charsets.UTF_8))
            if (!validEndpoint(obj.optString("url")) || !Regex("^[A-Za-z0-9_-]{43}$").matches(obj.optString("token"))) "{}"
            else obj.toString()
        } catch (_: Exception) { "{}" }
    }

    fun clear(): Boolean = try {
        prefs.edit().clear().commit() &&
            run {
                val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
                if (ks.containsAlias(keyAlias)) ks.deleteEntry(keyAlias)
                true
            }
    } catch (_: Exception) { false }

    private fun validEndpoint(url: String): Boolean = try {
        val uri = URI(url)
        uri.scheme == "https" && !uri.host.isNullOrBlank() && uri.userInfo == null &&
            uri.rawQuery == null && uri.rawFragment == null && uri.path.orEmpty().trimEnd('/') == ""
    } catch (_: Exception) { false }

    private fun key(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getKey(keyAlias, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(KeyGenParameterSpec.Builder(keyAlias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .build())
        return generator.generateKey()
    }
}
