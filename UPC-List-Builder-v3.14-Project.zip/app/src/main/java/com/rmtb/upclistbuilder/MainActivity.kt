/**
 * OWNERSHIP:
 * File: app/src/main/java/com/rmtb/upclistbuilder/MainActivity.kt
 * Owner: Android Application Composition
 * Role: Activity/composition root
 * Responsibility: Owns Android lifecycle, WebView host/configuration, single AndroidNative interface composition, focused native-owner construction, and top-level platform callbacks.
 * Does not own: AceNet production state-machine internals, item extraction, updater mechanics, export mechanics, scanner logic, product-image search logic, or diagnostic formatting.
 * Side effects: Creates/destroys activity/WebView resources, registers the AndroidNative interface, and delegates platform operations to focused owners.
 * Related code: New platform behavior belongs to a focused native owner; MainActivity remains lifecycle/composition only.
 */
package com.rmtb.upclistbuilder

import android.text.InputType
import android.widget.LinearLayout
import android.widget.EditText
import android.app.AlertDialog
import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.os.Looper
import android.os.Message
import android.os.Environment
import android.provider.Settings
import android.content.Context
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebResourceError
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.activity.enableEdgeToEdge
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.view.ViewCompat
import androidx.core.view.updateLayoutParams
import androidx.core.view.WindowInsetsCompat
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.Executors
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicBoolean
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView
    private var launchAfterPermission = false
    private var pendingFileCallback: ValueCallback<Array<Uri>>? = null
    private lateinit var appUpdateService: AppUpdateService
    private lateinit var nativeFileExportService: NativeFileExportService
    private lateinit var nativeDiagnosticJournal: NativeDiagnosticJournal
    private lateinit var aceNetCoordinator: AceNetProductionCoordinator
    private lateinit var chatGPTConnectionVault: ChatGPTConnectionVault


    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted && launchAfterPermission) launchScanner() else notifyCancelled()
        launchAfterPermission = false
    }
    private val scannerLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) {
            val upc = result.data?.getStringExtra("upc") ?: return@registerForActivityResult
            val payload = JSONObject().put("upc", upc).put("torchUsed", result.data?.getBooleanExtra("torchUsed", false) ?: false)
            result.data?.getStringExtra("scannerDiagnostics")?.let { raw -> try { payload.put("scannerDiagnostics", JSONObject(raw)) } catch (_: Exception) {} }
            webView.evaluateJavascript("window.UPCNativeScannerResult && window.UPCNativeScannerResult(${JSONObject.quote(payload.toString())});", null)
        } else if (result.resultCode == RESULT_FIRST_USER) {
            val capture = result.data?.getStringExtra("nifCapture") ?: return@registerForActivityResult
            webView.evaluateJavascript("window.UPCNativeNifCapture && window.UPCNativeNifCapture(${JSONObject.quote(capture)});", null)
        } else notifyCancelled()
    }
    private val fileChooserLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val callback = pendingFileCallback ?: return@registerForActivityResult
        pendingFileCallback = null
        val uris = if (result.resultCode == RESULT_OK) WebChromeClient.FileChooserParams.parseResult(result.resultCode, result.data) else null
        callback.onReceiveValue(uris)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        nativeDiagnosticJournal = NativeDiagnosticJournal(this)
        chatGPTConnectionVault = ChatGPTConnectionVault(this)
        appUpdateService = AppUpdateService(
            activity = this,
            onStatus = { message -> runOnUiThread {
                if (::webView.isInitialized) webView.evaluateJavascript(
                    "window.UPCNativeUpdateStatus && window.UPCNativeUpdateStatus(" + JSONObject.quote(message) + ");",
                    null
                )
            } },
            onLifecycle = { state, message, candidate -> notifyStartupUpdateLifecycle(state, message, candidate) }
        )
        nativeFileExportService = NativeFileExportService(
            activity = this,
            onExportStatus = { message -> runOnUiThread {
                if (::webView.isInitialized) webView.evaluateJavascript(
                    "window.UPCNativeExportStatus && window.UPCNativeExportStatus(" + JSONObject.quote(message) + ");",
                    null
                )
            } },
            onDiagnosticExportStatus = { message -> runOnUiThread {
                if (::webView.isInitialized) webView.evaluateJavascript(
                    "window.UPCNativeDiagnosticExportStatus && window.UPCNativeDiagnosticExportStatus(" + JSONObject.quote(message) + ");",
                    null
                )
            } },
            onDiagnosticTransferEvent = { payload -> runOnUiThread {
                if (!isDestroyed && ::webView.isInitialized) webView.evaluateJavascript(
                    "window.UPCNativeDiagnosticExportTransferEvent && window.UPCNativeDiagnosticExportTransferEvent(" + JSONObject.quote(payload) + ");",
                    null
                )
            } }
        )
        enableEdgeToEdge()
        val loader = WebViewAssetLoader.Builder().addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this)).build()
        val root = FrameLayout(this)
        webView = WebView(this)
        root.addView(webView, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        setContentView(root)
        // Android 15+ enforces edge-to-edge. Keep the entire WebView viewport physically
        // inside the tappable system-bar safe area so app content can never sit under
        // Samsung/Android navigation controls. Margins are intentional here: unlike
        // CSS/env padding they reduce the WebView's measured viewport itself.
        ViewCompat.setOnApplyWindowInsetsListener(root) { _, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            webView.updateLayoutParams<FrameLayout.LayoutParams> {
                leftMargin = bars.left
                topMargin = bars.top
                rightMargin = bars.right
                bottomMargin = bars.bottom
            }
            WindowInsetsCompat.CONSUMED
        }
        ViewCompat.requestApplyInsets(root)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.cacheMode = android.webkit.WebSettings.LOAD_NO_CACHE
        webView.settings.textZoom = 100
        webView.settings.allowFileAccess = false
        webView.settings.allowContentAccess = false
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(webView: WebView?, filePathCallback: ValueCallback<Array<Uri>>?, fileChooserParams: FileChooserParams?): Boolean {
                if (filePathCallback == null || fileChooserParams == null) return false
                pendingFileCallback?.onReceiveValue(null)
                pendingFileCallback = filePathCallback
                return try {
                    val intent = fileChooserParams.createIntent().apply {
                        type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                        addCategory(Intent.CATEGORY_OPENABLE)
                    }
                    fileChooserLauncher.launch(intent); true
                } catch (_: Exception) {
                    pendingFileCallback = null; filePathCallback.onReceiveValue(null); false
                }
            }
        }
        webView.webViewClient = object : WebViewClient() {
            // The full AndroidNative bridge is exposed only to the packaged application page.
            // Any external navigation leaves this privileged WebView and requires a user gesture.
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val uri = request?.url ?: return true
                if (!request.isForMainFrame) return true // never load foreign frames alongside AndroidNative
                val trusted = uri.scheme == "https" &&
                    uri.host == "appassets.androidplatform.net" && uri.path == "/assets/www/index.html"
                if (trusted) return false
                if (request.hasGesture() && (uri.scheme == "https" || uri.scheme == "http")) {
                    try { startActivity(Intent(Intent.ACTION_VIEW, uri)) } catch (_: Exception) { }
                }
                return true
            }
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                view?.evaluateJavascript(
                    """
                    (function(){
                      try{
                        const required=window.UPCAppRuntimeCapabilities||{};
                        const missing=window.UPCAppRuntimeCapabilities
                          ? Object.entries(required).filter(([,v])=>v!=='function').map(([k])=>k)
                          : ['runtimeCapabilityRegistry'];
                        const payload={
                          pageUrl:String(location.href||''),
                          release:window.UPC_RELEASE_INFO||null,
                          indexBuildId:document.querySelector('meta[name="build-id"]')?.content||null,
                          scriptSources:[...document.scripts].map(x=>x.src||'[inline]'),
                          resolverOwnerType:typeof window.UPCAceMiscResolver,
                          resolverFunctionType:typeof window.UPCAceMiscResolver?.resolveSkuCandidate,
                          runtimeReady:window.UPCAppRuntimeReady===true,
                          requiredFunctions:required,
                          missingRequiredFunctions:missing
                        };
                        window.AndroidNative?.reportRuntimeProbe(JSON.stringify(payload));
                      }catch(e){
                        window.AndroidNative?.reportRuntimeProbe(JSON.stringify({probeError:String(e&&e.message||e)}));
                      }
                    })();
                    """.trimIndent(),
                    null
                )
                // Startup sequencing is owned by the application runtime. The web layer first
                // resolves update/migration/local-data prerequisites, then explicitly releases
                // native AceNet startup. Do not start either updater or AceNet in parallel here.
            }
            override fun shouldInterceptRequest(view: WebView?, request: android.webkit.WebResourceRequest?) = request?.url?.let(loader::shouldInterceptRequest)
        }
        aceNetCoordinator = AceNetProductionCoordinator(
            activity = this,
            mainWebViewProvider = { if (::webView.isInitialized) webView else null },
            nativeDiagnosticJournal = nativeDiagnosticJournal
        )
        webView.addJavascriptInterface(NativeBridge(), "AndroidNative")
        webView.loadUrl("https://appassets.androidplatform.net/assets/www/index.html?v=${BuildConfig.UPC_BUILD_ID.removePrefix("v")}")
    }

    inner class NativeBridge {
        @JavascriptInterface fun openScanner() { runOnUiThread { ensureCameraAndLaunch() } }
        @JavascriptInterface fun platform() = "android-native-camerax"
        @JavascriptInterface fun reportRuntimeProbe(json: String) { runOnUiThread {
            val payload = try { JSONObject(json) } catch (_: Exception) { JSONObject().put("probeParseError", true).put("rawLength", json.length) }
            val packageVersion = try { packageManager.getPackageInfo(packageName, 0).versionName ?: "unknown" } catch (_: Exception) { "unknown" }
            payload.put("packageVersion", packageVersion)
                .put("nativeBuildExpected", BuildConfig.UPC_BUILD_ID)
                .put("webViewCacheMode", webView.settings.cacheMode)
            aceNetCoordinator.recordDiagnostic("app_runtime_asset_probe", payload)
        } }
        @JavascriptInterface fun getNativeDiagnosticJournal(): String = nativeDiagnosticJournal.read().toString()
        @JavascriptInterface fun getNetworkConnectivityState(): String = aceNetCoordinator.networkConnectivityState()
        @JavascriptInterface fun getAceNetProductionBrokerTimeoutMs(): Long = AceNetTimingPolicy.BROKER_OWNERSHIP_MS
        @JavascriptInterface fun beginStartupUpdateCheck(currentVersion: String) { appUpdateService.beginStartupCheck(currentVersion) }
        @JavascriptInterface fun beginAceNetStartup() { runOnUiThread { aceNetCoordinator.beginStartup() } }
        @JavascriptInterface fun checkForUpdate(currentVersion: String) { appUpdateService.checkForUpdate(currentVersion) }
        @JavascriptInterface fun beginDiagnosticExport(id: String, filename: String) { nativeFileExportService.beginDiagnosticExport(id, filename) }
        @JavascriptInterface fun appendDiagnosticExportChunk(id: String, chunk: String) { nativeFileExportService.appendDiagnosticExportChunk(id, chunk) }
        @JavascriptInterface fun finishDiagnosticExport(id: String) { nativeFileExportService.finishDiagnosticExport(id) }
        @JavascriptInterface fun abortDiagnosticExport(id: String) { nativeFileExportService.abortDiagnosticExport(id) }
        @JavascriptInterface fun exportFile(base64: String, filename: String, mimeType: String) { nativeFileExportService.exportFile(base64, filename, mimeType) }
        @JavascriptInterface fun lookupProductImage(requestId: String, upc: String, sku: String, mfg: String, description: String) { lookupProductImageNative(requestId, upc, sku, mfg, description) }
        @JavascriptInterface fun showKeyboard() { runOnUiThread { showWebKeyboard() } }
        @JavascriptInterface fun testAceNet(requestId: String, userId: String, password: String, sku: String) { runOnUiThread { aceNetCoordinator.test(requestId, userId, password, sku) } }
        @JavascriptInterface fun cancelAceNetTest() { runOnUiThread { aceNetCoordinator.cancelTest() } }
        @JavascriptInterface fun cancelAceNetStartupWarmup() { runOnUiThread { aceNetCoordinator.cancelStartupWarmup() } }
        @JavascriptInterface fun hasAceNetCredentials(): Boolean = aceNetCoordinator.hasCredentials()
        @JavascriptInterface fun getAceNetSavedCredentials(): String = aceNetCoordinator.savedCredentialsJson()
        @JavascriptInterface fun saveAceNetCredentials(userId: String, password: String): Boolean = aceNetCoordinator.saveCredentials(userId, password)
        @JavascriptInterface fun deleteAceNetCredentials(): Boolean = aceNetCoordinator.deleteCredentials()
        @JavascriptInterface fun saveChatGPTConnection(url: String, token: String): Boolean = chatGPTConnectionVault.save(url, token)
        @JavascriptInterface fun getChatGPTConnection(): String = chatGPTConnectionVault.read()
        @JavascriptInterface fun deleteChatGPTConnection(): Boolean = chatGPTConnectionVault.clear()
        @JavascriptInterface fun testAceNetSaved(requestId: String, sku: String) { runOnUiThread { aceNetCoordinator.testSaved(requestId, sku) } }
        @JavascriptInterface fun setAceNetUserRecoveryRetryArmed(armed: Boolean) { runOnUiThread { aceNetCoordinator.setUserRecoveryRetryArmed(armed) } }
        @JavascriptInterface fun lookupAceNetPrice(requestId: String, sku: String) { runOnUiThread { aceNetCoordinator.lookupPrice(requestId, sku) } }
        @JavascriptInterface fun lookupAceNetPriceWithUpcs(requestId: String, sku: String) { runOnUiThread { aceNetCoordinator.lookupPriceWithUpcs(requestId, sku) } }
        @JavascriptInterface fun lookupAceNetUpcs(requestId: String, sku: String) { runOnUiThread { aceNetCoordinator.lookupUpcs(requestId, sku) } }
        @JavascriptInterface fun lookupAceNetCatalog(requestId: String, sku: String) { runOnUiThread { aceNetCoordinator.lookupCatalog(requestId, sku) } }
        @JavascriptInterface fun lookupAceNetMiscCatalog(requestId: String, sku: String) { runOnUiThread { aceNetCoordinator.lookupMiscCatalog(requestId, sku) } }
        @JavascriptInterface fun lookupAceNetRepairCatalog(requestId: String, sku: String) { runOnUiThread { aceNetCoordinator.lookupRepairCatalog(requestId, sku) } }
        @JavascriptInterface fun getAceNetLoginStatus(): String = aceNetCoordinator.loginStatus()
    }


    private fun showWebKeyboard() {
        if (!::webView.isInitialized) return
        webView.requestFocusFromTouch()
        webView.postDelayed({
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
            imm?.showSoftInput(webView, InputMethodManager.SHOW_IMPLICIT)
        }, 120L)
    }

    private fun lookupProductImageNative(requestId: String, upc: String, sku: String, mfg: String, description: String) = thread(name = "product-image-lookup") {
        val payload = JSONObject().put("requestId", requestId).put("upc", upc)
        try {
            val result = ProductImageSearch.lookup(upc, sku, mfg, description)
            if (result == null) {
                payload.put("found", false)
            } else {
                payload.put("found", true)
                    .put("dataUrl", result.dataUrl)
                    .put("source", result.source)
                    .put("query", result.query)
            }
        } catch (e: Exception) {
            payload.put("found", false).put("error", e.message ?: e.javaClass.simpleName)
        }
        runOnUiThread {
            if (::webView.isInitialized) {
                webView.evaluateJavascript("window.UPCNativeProductImageResult && window.UPCNativeProductImageResult(${JSONObject.quote(payload.toString())});", null)
            }
        }
    }

    private fun notifyStartupUpdateLifecycle(state:String, message:String, candidate:String?=null) = runOnUiThread {
        if(!::webView.isInitialized)return@runOnUiThread
        val payload=JSONObject().put("state",state).put("message",message)
        candidate?.let{payload.put("candidateVersion",it)}
        webView.evaluateJavascript(
            "window.UPCNativeUpdateLifecycle && window.UPCNativeUpdateLifecycle(${JSONObject.quote(payload.toString())});",null)
        aceNetCoordinator.recordDiagnostic("startup_update_lifecycle",JSONObject(payload.toString()))
    }

    private fun ensureCameraAndLaunch() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) launchScanner()
        else { launchAfterPermission = true; permissionLauncher.launch(Manifest.permission.CAMERA) }
    }
    private fun launchScanner() {
        scannerLauncher.launch(Intent(this, ScannerActivity::class.java))
    }
    private fun notifyCancelled() { webView.evaluateJavascript("window.UPCNativeScannerCancelled && window.UPCNativeScannerCancelled();", null) }
    override fun onStart() {
        super.onStart()
        aceNetCoordinator.onStart()
    }

    override fun onResume() {
        super.onResume()
        appUpdateService.onResume()
        aceNetCoordinator.onResume()
    }

    override fun onPause() {
        aceNetCoordinator.onPause()
        super.onPause()
    }

    override fun onStop() {
        aceNetCoordinator.onStop()
        super.onStop()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (!aceNetCoordinator.handleBackPressed()) super.onBackPressed()
    }

    override fun onDestroy() {
        pendingFileCallback?.onReceiveValue(null)
        pendingFileCallback = null
        aceNetCoordinator.destroy()
        nativeFileExportService.dispose()
        webView.removeJavascriptInterface("AndroidNative")
        webView.destroy()
        super.onDestroy()
    }

}
