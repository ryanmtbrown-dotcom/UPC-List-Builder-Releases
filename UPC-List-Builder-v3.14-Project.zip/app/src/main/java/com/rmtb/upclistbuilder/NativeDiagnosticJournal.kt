/**
 * OWNERSHIP:
 * File: app/src/main/java/com/rmtb/upclistbuilder/NativeDiagnosticJournal.kt
 * Owner: Native Diagnostics Persistence
 * Role: Safety-journal service
 * Responsibility: Owns native diagnostic queueing, internal-file persistence, legacy migration, and bounded retention that survives WebView failure.
 * Does not own: Diagnostic schema/redaction, business/session decisions, recovery policy, or web diagnostic retention.
 * Side effects: Owns a background executor/queue and internal diagnostic file; SharedPreferences is migration-source only.
 * Related code: Canonical native record shape belongs to NativeDiagnosticRecordFormatter; web journal belongs to diagnostics/diagnostic-journal.js.
 */
package com.rmtb.upclistbuilder

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

/**
 * Native safety-journal queue, durable file storage, legacy migration, and bounded retention.
 *
 * It records evidence only; NativeDiagnosticRecordFormatter owns canonical event shape/redaction.
 */
class NativeDiagnosticJournal(private val context: Context) {
    private val queue = ConcurrentLinkedQueue<Pair<String, JSONObject>>()
    private val drainScheduled = AtomicBoolean(false)
    private val executor = Executors.newSingleThreadExecutor()
    private val sequence = AtomicLong(0)
    private val formatter = NativeDiagnosticRecordFormatter(context, sequence)
    private val journalFile = File(context.filesDir, "upc-native-diagnostics-v2.json")
    private val legacyPrefs = context.getSharedPreferences("upc_native_diagnostics", Context.MODE_PRIVATE)
    private val legacyStorageKey = "events_v1"
    private val maxRows = 4000
    private val maxBytes = 4_000_000

    fun read(): JSONArray = synchronized(this) {
        migrateLegacyIfNeeded()
        readFileRows()
    }

    fun record(event: String, payload: JSONObject) {
        queue.add(Pair(event, JSONObject(payload.toString())))
        scheduleDrain()
    }

    private fun scheduleDrain() {
        if (!drainScheduled.compareAndSet(false, true)) return
        executor.execute {
            try {
                val batch = mutableListOf<Pair<String, JSONObject>>()
                while (true) batch.add(queue.poll() ?: break)
                if (batch.isNotEmpty()) synchronized(this) {
                    migrateLegacyIfNeeded()
                    val rows = readFileRows()
                    for ((event, payload) in batch) rows.put(formatter.canonicalRow(event, payload))
                    writeBounded(rows)
                }
            } catch (e: Exception) {
                android.util.Log.e("UPC-NATIVE-DIAG", "native diagnostic persistence failure", e)
            } finally {
                drainScheduled.set(false)
                if (queue.isNotEmpty()) scheduleDrain()
            }
        }
    }

    private fun readFileRows(): JSONArray = try {
        if (!journalFile.exists()) JSONArray() else JSONArray(journalFile.readText(Charsets.UTF_8))
    } catch (_: Exception) {
        JSONArray()
    }

    private fun migrateLegacyIfNeeded() {
        if (journalFile.exists()) return
        val raw = legacyPrefs.getString(legacyStorageKey, null) ?: return
        try {
            val legacy = JSONArray(raw)
            val migrated = JSONArray()
            for (i in 0 until legacy.length()) {
                val row = legacy.optJSONObject(i) ?: continue
                val event = row.optString("event", "legacy_native_event")
                val payload = row.optJSONObject("payload") ?: JSONObject()
                migrated.put(formatter.canonicalRow(event, payload).put("legacyImported", true))
            }
            writeBounded(migrated)
            legacyPrefs.edit().remove(legacyStorageKey).apply()
        } catch (_: Exception) {
            legacyPrefs.edit().remove(legacyStorageKey).apply()
        }
    }

    private fun writeBounded(source: JSONArray) {
        val rows = mutableListOf<JSONObject>()
        for (i in 0 until source.length()) source.optJSONObject(i)?.let { rows.add(it) }
        var dropped = 0
        fun totalBytes(): Int = rows.sumOf { it.toString().length } + 2
        while (rows.size > maxRows || totalBytes() > maxBytes) {
            val nonError = rows.indexOfFirst {
                !setOf("ERROR", "FATAL").contains(it.optString("severity").uppercase())
            }
            rows.removeAt(if (nonError >= 0) nonError else 0)
            dropped++
        }
        if (dropped > 0) {
            rows.add(
                formatter.canonicalRow(
                    "diagnostic_retention_truncated",
                    JSONObject()
                        .put("domain", "DIAGNOSTICS")
                        .put("module", "native/NativeDiagnosticJournal")
                        .put("sourceFunction", "writeBounded")
                        .put("actual", "Dropped $dropped oldest native safety-journal events.")
                        .put("droppedRows", dropped)
                        .put("maxRows", maxRows)
                        .put("maxBytes", maxBytes)
                )
            )
        }
        journalFile.writeText(JSONArray(rows).toString(), Charsets.UTF_8)
    }
}
