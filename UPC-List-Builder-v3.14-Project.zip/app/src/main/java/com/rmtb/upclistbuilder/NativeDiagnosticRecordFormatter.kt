/**
 * OWNERSHIP:
 * File: app/src/main/java/com/rmtb/upclistbuilder/NativeDiagnosticRecordFormatter.kt
 * Owner: Native Diagnostics Schema
 * Role: Formatter/sanitizer
 * Responsibility: Owns canonical native diagnostic record formatting, severity/phase shaping, correlation fields, and sensitive-value redaction.
 * Does not own: Queueing, persistence, retention, business/session decisions, or recovery.
 * Side effects: Pure formatting plus installed-version/time metadata reads; no journal persistence.
 * Related code: Retention belongs to NativeDiagnosticJournal; web schema alignment belongs to diagnostics/diagnostic-service.js.
 */
package com.rmtb.upclistbuilder

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.atomic.AtomicLong

class NativeDiagnosticRecordFormatter(private val context: Context, private val sequence: AtomicLong) {
    fun canonicalRow(event: String, payload: JSONObject): JSONObject {
        val now = System.currentTimeMillis()
        val safePayload = sanitize(payload) as? JSONObject ?: JSONObject()
        val operationId = safePayload.optString("operationId")
            .ifBlank { safePayload.optString("lookupId") }
            .ifBlank { safePayload.optString("requestId") }
            .ifBlank { null }
        val sourceFunction = safePayload.optString("function")
            .ifBlank { safePayload.optString("sourceFunction") }
            .ifBlank { safePayload.optString("decisionSourceFunction") }
            .ifBlank { null }

        return JSONObject()
            .put("schemaVersion", 2)
            .put("sequence", sequence.incrementAndGet())
            .put("timestamp", utcStamp(now))
            .put("timestampEpochMs", now)
            .put("alaskaDate", alaskaStamp(now, "yyyy-MM-dd"))
            .put("alaskaTime", alaskaStamp(now, "HH:mm:ss.SSS"))
            .put("alaskaZone", alaskaStamp(now, "z"))
            .put("severity", severityFor(event))
            .put("sourceJournal", "ANDROID_NATIVE")
            .put("appVersion", installedAppVersion())
            .put("operationId", operationId)
            .put("spanId", safePayload.optString("spanId").ifBlank { null })
            .put("parentSpanId", safePayload.optString("parentSpanId").ifBlank { null })
            .put("domain", safePayload.optString("domain").ifBlank {
                if (event.contains("acenet", true)) "ACENET" else "ANDROID"
            })
            .put("module", safePayload.optString("module").ifBlank { "native/AceNetProductionCoordinator" })
            .put("function", sourceFunction)
            .put("event", event)
            .put("phase", phaseFor(event))
            .put("purpose", safePayload.optString("purpose").ifBlank { null })
            .put("expected", safePayload.optString("expected").ifBlank { null })
            .put("actual", safePayload.optString("actual").ifBlank { null })
            .put("result", safePayload.optString("result").ifBlank {
                safePayload.optString("status").ifBlank { null }
            })
            .put("durationMs", safePayload.optLong("elapsedMs").takeIf { safePayload.has("elapsedMs") })
            .put("details", safePayload)
    }

    private fun utcStamp(epochMs: Long): String =
        SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }.format(Date(epochMs))

    private fun alaskaStamp(epochMs: Long, pattern: String): String =
        SimpleDateFormat(pattern, Locale.US).apply {
            timeZone = TimeZone.getTimeZone("America/Anchorage")
        }.format(Date(epochMs))

    private fun installedAppVersion(): String = try {
        context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "unknown"
    } catch (_: Exception) {
        "unknown"
    }

    private fun severityFor(event: String): String {
        val value = event.lowercase()
        return when {
            value.contains("fatal") -> "FATAL"
            value.contains("error") || value.contains("failed") ||
                value.contains("failure") || value.contains("exception") -> "ERROR"
            value.contains("timeout") || value.contains("degraded") ||
                value.contains("unavailable") || value.contains("blocked") -> "WARN"
            else -> "INFO"
        }
    }

    private fun phaseFor(event: String): String {
        val value = event.lowercase()
        return when {
            value.contains("started") || value.contains("begin") -> "START"
            value.contains("completed") || value.contains("complete") ||
                value.contains("success") || value.contains("ready") -> "SUCCESS"
            value.contains("error") || value.contains("failed") ||
                value.contains("failure") || value.contains("exception") -> "ERROR"
            value.contains("timeout") || value.contains("degraded") ||
                value.contains("unavailable") -> "WARN"
            else -> "EVENT"
        }
    }

    private fun sensitiveKey(key: String): Boolean =
        Regex(
            "password|passwd|authorization|bearer|secret|credential(value)?|" +
                "cookie(value|header)?|token(value)?|saml|assertion",
            RegexOption.IGNORE_CASE
        ).containsMatchIn(key)

    private fun sanitize(value: Any?, depth: Int = 0): Any? {
        if (value == null || value == JSONObject.NULL) return JSONObject.NULL
        if (depth >= 5) return "[max-depth]"
        return when (value) {
            is JSONObject -> {
                val out = JSONObject()
                val keys = value.keys().asSequence().toList().take(120)
                for (key in keys) {
                    out.put(
                        key,
                        if (sensitiveKey(key)) "[redacted]" else sanitize(value.opt(key), depth + 1)
                    )
                }
                if (value.length() > keys.size) out.put("__truncatedKeys", value.length() - keys.size)
                out
            }
            is JSONArray -> {
                val out = JSONArray()
                val count = minOf(value.length(), 100)
                for (i in 0 until count) out.put(sanitize(value.opt(i), depth + 1))
                if (value.length() > count) out.put("[+${value.length() - count} more]")
                out
            }
            is String -> {
                val redacted = Regex(
                    "([?&](?:token|auth|code|saml|assertion|password|session)=)[^&#\\s]+",
                    RegexOption.IGNORE_CASE
                ).replace(value) { match -> match.groupValues[1] + "[redacted]" }
                if (redacted.length > 12_000) redacted.take(12_000) + "…[truncated]" else redacted
            }
            else -> value
        }
    }
}
