/**
 * OWNERSHIP:
 * File: app/src/main/java/com/rmtb/upclistbuilder/NativeDownloadsWriter.kt
 * Owner: Android Downloads Infrastructure
 * Role: Platform primitive
 * Responsibility: Owns the shared Android Q+ MediaStore Downloads write mechanism.
 * Does not own: Domain export validation, filenames beyond supplied request, update installation, or pre-Q policy.
 * Side effects: Writes supplied bytes to Android MediaStore/Downloads.
 * Related code: Callers such as NativeFileExportService/AppUpdateService own their domain operation and diagnostics.
 */
package com.rmtb.upclistbuilder

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.annotation.RequiresApi

object NativeDownloadsWriter {
    @RequiresApi(Build.VERSION_CODES.Q)
    fun write(context: Context, bytes: ByteArray, filename: String, mimeType: String) {
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, filename)
            put(MediaStore.Downloads.MIME_TYPE, mimeType)
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val resolver = context.contentResolver
        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("Downloads destination unavailable")
        resolver.openOutputStream(uri)?.use { it.write(bytes) }
            ?: throw IllegalStateException("Could not open Downloads output")
        values.clear()
        values.put(MediaStore.Downloads.IS_PENDING, 0)
        resolver.update(uri, values, null, null)
    }
}

/**
 * Incremental, rollback-capable Downloads destination for large diagnostic evidence.
 * Callers own a single background worker; no stream operation belongs on the UI thread.
 */
class PendingDiagnosticDownload(private val context: Context, filename: String, jsonEntryName: String? = null) : java.io.Closeable {
    private val resolver = context.contentResolver
    private val uri: android.net.Uri?
    private val pendingFile: java.io.File?
    private val completedFile: java.io.File?
    private val stream: java.io.OutputStream
    private val zipStream: java.util.zip.ZipOutputStream?
    private var closed = false
    private var published = false

    init {
        if (jsonEntryName != null) require(!jsonEntryName.contains('/') && !jsonEntryName.contains('\\') && jsonEntryName.endsWith(".json")) {
            "Invalid diagnostic ZIP entry name"
        }
        val rawStream: java.io.OutputStream
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, filename)
                put(MediaStore.Downloads.MIME_TYPE, if (jsonEntryName == null) "application/json" else "application/zip")
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val destination = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Downloads destination unavailable")
            uri = destination
            pendingFile = null
            completedFile = null
            rawStream = try {
                resolver.openOutputStream(destination)
                    ?: throw IllegalStateException("Could not open diagnostic download")
            } catch (error: Exception) {
                resolver.delete(destination, null, null)
                throw error
            }
        } else {
            val directory = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: context.filesDir
            val target = java.io.File(directory, filename)
            val temporary = java.io.File(directory, "$filename.partial")
            if (temporary.exists() && !temporary.delete()) throw IllegalStateException("Cannot replace previous partial diagnostic")
            uri = null
            pendingFile = temporary
            completedFile = target
            rawStream = java.io.FileOutputStream(temporary)
        }
        // ZIP compression is incremental: no additional JSON copy and no whole-file buffer.
        // A failed ZIP start closes and deletes the pending destination immediately.
        if (jsonEntryName == null) {
            zipStream = null
            stream = rawStream
        } else {
            try {
                val compressed = java.util.zip.ZipOutputStream(rawStream)
                compressed.putNextEntry(java.util.zip.ZipEntry(jsonEntryName))
                zipStream = compressed
                stream = compressed
            } catch (error: Exception) {
                try { rawStream.close() } catch (_: Exception) {}
                if (uri != null) resolver.delete(uri, null, null) else pendingFile?.delete()
                throw error
            }
        }
    }

    fun append(bytes: ByteArray) {
        check(!closed) { "Diagnostic destination is already closed" }
        stream.write(bytes)
    }

    fun publish() {
        check(!closed) { "Diagnostic destination is already closed" }
        zipStream?.closeEntry()
        stream.close() // ZipOutputStream.close writes the ZIP central directory.
        closed = true
        if (uri != null) {
            val values = ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }
            if (resolver.update(uri, values, null, null) <= 0) throw IllegalStateException("Failed to finalize diagnostic download")
        } else {
            val temp = pendingFile ?: throw IllegalStateException("Missing temporary diagnostic")
            val target = completedFile ?: throw IllegalStateException("Missing diagnostic destination")
            if (!temp.renameTo(target)) throw IllegalStateException("Unable to finalize diagnostic file")
        }
        published = true
    }

    override fun close() {
        if (!closed) {
            closed = true
            try { stream.close() } catch (_: Exception) { /* cleanup must continue */ }
        }
        if (!published) {
            if (uri != null) resolver.delete(uri, null, null)
            else pendingFile?.delete()
        }
    }
}
