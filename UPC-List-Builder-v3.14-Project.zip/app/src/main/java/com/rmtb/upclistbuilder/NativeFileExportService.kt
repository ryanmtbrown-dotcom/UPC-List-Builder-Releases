/**
 * OWNERSHIP:
 * File: app/src/main/java/com/rmtb/upclistbuilder/NativeFileExportService.kt
 * Owner: Native File Export
 * Role: Platform service
 * Responsibility: Owns browser/WebView-requested file export decoding, platform-compatible Downloads writing, status callbacks, and pre-Q fallback handling.
 * Does not own: Domain row/workbook composition, update APK installation, scanner/image behavior, or business validation.
 * Side effects: Writes approved exported bytes through NativeDownloadsWriter/platform APIs and emits export status.
 * Related code: Web/domain export owners prepare bytes/filenames; Downloads primitive belongs to NativeDownloadsWriter.
 */
package com.rmtb.upclistbuilder

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.RejectedExecutionException

/**
 * Owns native file/diagnostic export mechanics and download notifications.
 * JavaScript callback presentation is injected so the service does not own WebView state.
 */
class NativeFileExportService(
    private val activity: AppCompatActivity,
    private val onExportStatus: (String) -> Unit,
    private val onDiagnosticExportStatus: (String) -> Unit,
    private val onDiagnosticTransferEvent: (String) -> Unit
) {
    fun exportFile(base64: String, requestedName: String, mimeType: String) = activity.runOnUiThread {
        val safeName = requestedName.replace(Regex("""[^A-Za-z0-9._ -]"""), "_").take(120)
        try {
            downloadNotification(2201, "UPC List Builder", "Saving $safeName…", true)
            val bytes = android.util.Base64.decode(base64, android.util.Base64.DEFAULT)
            NativeDownloadsWriter.write(activity, bytes, safeName, mimeType)
            downloadNotification(2201, "Download complete", safeName, false)
            onExportStatus("Saved to Downloads · $safeName")
        } catch (e: Exception) {
            onExportStatus("Export failed · ${e.message ?: e.javaClass.simpleName}")
        }
    }

    // The only diagnostic writer lives on this worker. JavaScript sends the next
    // small piece only after acknowledging the preceding write; the queue cannot
    // retain another full diagnostic copy or block the Android main thread.
    private val diagnosticWorker = Executors.newSingleThreadExecutor()
    private data class DiagnosticTransfer(val id: String, val destination: PendingDiagnosticDownload,
                                         var written: Long = 0, var lastActivityMs: Long = System.currentTimeMillis())
    private var diagnosticTransfer: DiagnosticTransfer? = null // worker thread only
    private val maxDiagnosticBytes = 256L * 1024L * 1024L
    private val maxDiagnosticChunkChars = 65536

    private fun reportTransfer(id: String, phase: String, message: String = "") {
        val payload = org.json.JSONObject().put("id", id).put("phase", phase).put("message", message)
        onDiagnosticTransferEvent(payload.toString())
    }

    private fun transferAction(id: String, action: () -> Unit) {
        if (!Regex("^[A-Za-z0-9_-]{1,90}$").matches(id)) return
        try { diagnosticWorker.execute {
            try { action() } catch (e: Exception) {
                val old = diagnosticTransfer
                if (old?.id == id) { diagnosticTransfer = null; try { old.destination.close() } catch (_: Exception) {} }
                reportTransfer(id, "error", e.message ?: e.javaClass.simpleName)
                onDiagnosticExportStatus("Diagnostic export failed · ${e.message ?: e.javaClass.simpleName}")
            }
        } } catch (_: RejectedExecutionException) { /* Activity disposed; no callback is safe */ }
    }
    fun beginDiagnosticExport(id: String, requestedName: String) = transferAction(id) {
        val old = diagnosticTransfer
        if (old != null) {
            // An abandoned transfer cannot hold Downloads hostage indefinitely.
            if (System.currentTimeMillis() - old.lastActivityMs < 90_000L) {
                reportTransfer(id, "error", "A diagnostic export is already in progress")
                return@transferAction
            }
            diagnosticTransfer = null
            old.destination.close()
        }
        val safe = requestedName.replace(Regex("[^A-Za-z0-9._-]"), "_").take(120)
            .ifBlank { "UPC_List_Builder_Diagnostic.json" }
        val entryName = if (safe.endsWith(".zip")) safe.removeSuffix(".zip") + ".json" else null
        diagnosticTransfer = DiagnosticTransfer(id, PendingDiagnosticDownload(activity.applicationContext, safe, entryName))
        reportTransfer(id, "ready")
    }
    fun appendDiagnosticExportChunk(id: String, chunk: String) = transferAction(id) {
        val active = diagnosticTransfer
        if (active == null || active.id != id) { reportTransfer(id, "error", "No matching diagnostic export"); return@transferAction }
        if (chunk.isEmpty() || chunk.length > maxDiagnosticChunkChars) throw IllegalArgumentException("Invalid diagnostic chunk size")
        val bytes = chunk.toByteArray(Charsets.UTF_8)
        if (active.written + bytes.size > maxDiagnosticBytes) throw IllegalStateException("Diagnostic export exceeds safety limit")
        active.destination.append(bytes)
        active.written += bytes.size
        active.lastActivityMs = System.currentTimeMillis()
        reportTransfer(id, "chunk")
    }

    fun finishDiagnosticExport(id: String) = transferAction(id) {
        val active = diagnosticTransfer
        if (active == null || active.id != id) { reportTransfer(id, "error", "No matching diagnostic export"); return@transferAction }
        active.destination.publish()
        diagnosticTransfer = null
        reportTransfer(id, "saved")
        onDiagnosticExportStatus("Saved to Downloads · Diagnostic export complete")
    }
    fun abortDiagnosticExport(id: String) = transferAction(id) {
        val active = diagnosticTransfer
        if (active?.id == id) { diagnosticTransfer = null; active.destination.close() }
        reportTransfer(id, "aborted")
    }

    fun dispose() {
        try { diagnosticWorker.execute {
            val active = diagnosticTransfer
            diagnosticTransfer = null
            if (active != null) try { active.destination.close() } catch (_: Exception) {}
        } } catch (_: RejectedExecutionException) { /* already disposed */ }
        diagnosticWorker.shutdown()
    }

    private fun ensureDownloadNotifications() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = activity.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(NotificationChannel("downloads", "Downloads", NotificationManager.IMPORTANCE_LOW))
        }
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(activity, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            activity.requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 904)
        }
    }

    private fun downloadNotification(id: Int, title: String, text: String, ongoing: Boolean) {
        ensureDownloadNotifications()
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(activity, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val notification = androidx.core.app.NotificationCompat.Builder(activity, "downloads")
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle(title)
            .setContentText(text)
            .setOngoing(ongoing)
            .setAutoCancel(!ongoing)
            .setOnlyAlertOnce(true)
            .build()
        (activity.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(id, notification)
    }
}
