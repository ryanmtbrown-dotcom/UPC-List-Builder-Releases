/**
 * OWNERSHIP:
 * File: app/src/main/java/com/rmtb/upclistbuilder/PersistentAceNetWorker.kt
 * Owner: Native AceNet Extraction
 * Role: Retained extraction worker
 * Responsibility: Owns the sole production retailer item-page navigation/extraction engine for price, UPC, catalog, MISC, and repair capabilities with exact-SKU evidence.
 * Does not own: Credential persistence, session-repair policy, coordinator state, updater/export/scanner/image behavior, or catalog persistence.
 * Side effects: Owns its retained WebView/listeners/timers while alive, performs retailer navigation/extraction, and returns typed evidence.
 * Related code: Construction/lifecycle belongs solely to AceNetRetrievalService; session recovery belongs to AceNetProductionCoordinator.
 */
package com.rmtb.upclistbuilder

import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.ConsoleMessage
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject

/**
 * PROVISIONAL v2.21 production fast path.
 * One retained retailer WebView, one request at a time, exact-SKU evidence required.
 * Authentication/recovery remains owned by MainActivity's established AceNet pipeline.
 */
class PersistentAceNetWorker(
    private val activity: MainActivity,
    private val emit: (String, JSONObject) -> Unit,
    private val complete: (requestId: String, mode: String, result: JSONObject) -> Unit
) {
    private val handler = Handler(Looper.getMainLooper())
    private var view: WebView? = null
    private var retailerTemplate: String? = null
    private var activeRequestId = ""
    private var activeMode = ""
    private var activeSku = ""
    private var startedMs = 0L
    private var terminal = true
    private var primed = false
    private var primeCallback: ((JSONObject) -> Unit)? = null
    private var catalogForensicsCaptured = false
    private var skuEvidenceObserved = false
    private var repairCatalogSnapshot: JSONObject? = null
    private var repairCatalogMissingFields: JSONArray? = null
    private var structuralSuspicionAtThreeSeconds = false
    private var healthyEmptyItemAtThreeSeconds = false
    private var exactSkuNoUpcAtThreeSeconds = false
    private var catalogSnapshot: JSONObject? = null
    private var catalogMissingFields: JSONArray? = null
    private var activeTimeoutMs = AceNetTimingPolicy.ITEM_ATTEMPT_MS

    fun seed(template: String): Boolean {
        if (!validRetailerUrl(template)) return false
        retailerTemplate = template
        primed = false
        emit("persistent_worker_seeded", JSONObject().put("host", "retailer.aceservices.com").put("ready", false))
        return true
    }

    fun prime(template: String, sku: String, timeoutMs: Long = AceNetTimingPolicy.ITEM_ATTEMPT_MS, callback: (JSONObject) -> Unit): Boolean {
        if (isBusy() || !seed(template) || sku.isBlank()) return false
        primeCallback = callback
        return startSearch("__startup_prime__${System.currentTimeMillis()}", "PRODUCTION_PRICE", sku, requirePrimed=false, timeoutOverrideMs=timeoutMs)
    }

    fun isReady(): Boolean = primed && !retailerTemplate.isNullOrBlank()
    fun isBusy(): Boolean = !terminal

    fun search(requestId: String, mode: String, sku: String): Boolean = startSearch(requestId,mode,sku,requirePrimed=true)

    private fun startSearch(requestId: String, mode: String, sku: String, requirePrimed: Boolean, timeoutOverrideMs: Long? = null): Boolean {
        if ((requirePrimed && !isReady()) || retailerTemplate.isNullOrBlank() || isBusy() || requestId.isBlank() || sku.isBlank()) return false
        val direct = directRetailerUrl(retailerTemplate, sku) ?: return false
        activeRequestId = requestId
        activeMode = mode
        activeSku = sku.trim()
        startedMs = System.currentTimeMillis()
        terminal = false
        skuEvidenceObserved = false
        repairCatalogSnapshot = null
        repairCatalogMissingFields = null
        catalogSnapshot = null
        catalogMissingFields = null
        structuralSuspicionAtThreeSeconds = false
        healthyEmptyItemAtThreeSeconds = false
        exactSkuNoUpcAtThreeSeconds = false
        val v = view ?: createView().also { view = it }
        emitWorkerDiagnostic("persistent_worker_search_started",v,direct,JSONObject()
            .put("requestId",requestId).put("mode",mode).put("requestedSku",activeSku)
            .put("navigationTargetForensics",safeUrlForensics(direct)))
        v.loadUrl(direct)
        val timeoutMs = (timeoutOverrideMs ?: AceNetTimingPolicy.ITEM_ATTEMPT_MS).coerceIn(1_000L,AceNetTimingPolicy.ITEM_ATTEMPT_MS)
        activeTimeoutMs=timeoutMs
        handler.postDelayed({
            if(!terminal && activeRequestId==requestId) probeWorkerStructure(v,"three_second",false)
        },AceNetTimingPolicy.STRUCTURE_INSPECTION_MS)
        handler.postDelayed({
            if(!terminal && activeRequestId==requestId) probeWorkerStructure(v,"five_second",true)
        },AceNetTimingPolicy.MALFORMED_CONFIRM_MS)
        if(mode=="PRODUCTION_PRICE" || mode=="PRODUCTION_PRICE_UPCS"){
            val forensicDelay=(timeoutMs-750L).coerceAtLeast(1_000L)
            handler.postDelayed({
                if(!terminal && activeRequestId==requestId) captureWorkerPageForensics(v,"pre_terminal_deadline")
            },forensicDelay)
        }
        handler.postDelayed({
            if (!terminal && activeRequestId == requestId) {
                emitWorkerDiagnostic("persistent_worker_terminal_deadline_fired",v,v.url,JSONObject()
                    .put("timeoutMs",timeoutMs).put("skuEvidence",skuEvidenceObserved))
                if(mode=="PRODUCTION_REPAIR_CATALOG" && skuEvidenceObserved && repairCatalogSnapshot!=null){
                    finish(JSONObject()
                        .put("outcome","FOUND_PARTIAL").put("status","FOUND_PARTIAL").put("sku",activeSku)
                        .put("catalog",JSONObject(repairCatalogSnapshot!!.toString()))
                        .put("missingFields",repairCatalogMissingFields?:JSONArray()))
                } else {
                    finish(JSONObject().put("outcome","TIMEOUT").put("status","TIMEOUT"))
                }
            }
        }, timeoutMs)
        return true
    }

    fun destroy(reason: String) {
        handler.removeCallbacksAndMessages(null)
        if (!terminal && activeRequestId.isNotBlank()) {
            val id=activeRequestId; val mode=activeMode
            val interrupted=JSONObject().put("outcome","INTERRUPTED").put("status","INTERRUPTED").put("reason",reason).put("requestedSku",activeSku)
            val prime=primeCallback
            val isPrime=id.startsWith("__startup_prime__")
            resetActive()
            if(isPrime){ primeCallback=null; prime?.invoke(interrupted) } else complete(id, mode, interrupted)
        }
        try { view?.stopLoading(); view?.destroy() } catch (_: Exception) {}
        view = null
        retailerTemplate = null
        primed = false
        primeCallback = null
        catalogForensicsCaptured = false
        emit("persistent_worker_destroyed", JSONObject().put("reason",reason))
    }

    private inner class Bridge {
        @JavascriptInterface fun skuObserved(sku: String) { activity.runOnUiThread {
            if(!terminal && sku.isNotBlank()){
                skuEvidenceObserved=true
                emitWorkerDiagnostic("persistent_worker_sku_observed",view,view?.url,JSONObject()
                    .put("returnedSku",sku.trim()).put("skuMatches",sku.trim()==activeSku))
            }
        } }
        @JavascriptInterface fun diagnostic(json: String) { activity.runOnUiThread {
            if(terminal) return@runOnUiThread
            val obj=try { JSONObject(json) } catch (_: Exception) {
                emitWorkerDiagnostic("persistent_worker_dom_diagnostic_parse_failed",view,view?.url,JSONObject().put("jsonLength",json.length))
                return@runOnUiThread
            }
            obj.put("requestId",activeRequestId).put("mode",activeMode).put("requestedSku",activeSku)
                .put("totalMs",System.currentTimeMillis()-startedMs).put("persistentWorker",true)
            emit("persistent_worker_dom_state",obj)
        } }
        @JavascriptInterface fun result(json: String) { activity.runOnUiThread {
            if (terminal) return@runOnUiThread
            val obj=try { JSONObject(json) } catch (_: Exception) { return@runOnUiThread }
            finish(obj)
        } }
        @JavascriptInterface fun progress(json: String) { activity.runOnUiThread {
            if (terminal || (activeMode != "PRODUCTION_CATALOG" && activeMode != "PRODUCTION_MISC_CATALOG" && activeMode != "PRODUCTION_REPAIR_CATALOG")) return@runOnUiThread
            val obj=try { JSONObject(json) } catch (_: Exception) { return@runOnUiThread }
            emit("persistent_worker_catalog_progress", obj.put("requestId",activeRequestId).put("requestedSku",activeSku).put("totalMs",System.currentTimeMillis()-startedMs).put("persistentWorker",true))
        } }
        @JavascriptInterface fun catalogSnapshot(json: String) { activity.runOnUiThread {
            if (terminal || (activeMode != "PRODUCTION_CATALOG" && activeMode != "PRODUCTION_MISC_CATALOG" && activeMode != "PRODUCTION_REPAIR_CATALOG")) return@runOnUiThread
            val obj=try { JSONObject(json) } catch (_: Exception) { return@runOnUiThread }
            val catalog=obj.optJSONObject("catalog") ?: return@runOnUiThread
            catalogSnapshot=JSONObject(catalog.toString())
            catalogMissingFields=obj.optJSONArray("missingFields")?.let { JSONArray(it.toString()) } ?: JSONArray()
            if(activeMode=="PRODUCTION_REPAIR_CATALOG"){
                repairCatalogSnapshot=JSONObject(catalog.toString())
                repairCatalogMissingFields=catalogMissingFields?.let { JSONArray(it.toString()) } ?: JSONArray()
            }
        } }
        @JavascriptInterface fun shouldCaptureForensics(): Boolean = !catalogForensicsCaptured
        @JavascriptInterface fun forensics(json: String) { activity.runOnUiThread {
            if (terminal || (activeMode != "PRODUCTION_CATALOG" && activeMode != "PRODUCTION_MISC_CATALOG" && activeMode != "PRODUCTION_REPAIR_CATALOG") || catalogForensicsCaptured) return@runOnUiThread
            val obj=try { JSONObject(json) } catch (_: Exception) { return@runOnUiThread }
            catalogForensicsCaptured=true
            emit("persistent_worker_catalog_forensics", obj.put("requestId",activeRequestId).put("requestedSku",activeSku).put("totalMs",System.currentTimeMillis()-startedMs).put("persistentWorker",true))
        } }
    }

    private fun safeUrlForensics(raw:String?):JSONObject = try {
        val uri=Uri.parse(raw.orEmpty())
        val names=JSONArray()
        try { uri.queryParameterNames.sorted().forEach { names.put(it.take(120)) } } catch (_:Exception) {}
        JSONObject()
            .put("scheme",uri.scheme.orEmpty().take(24))
            .put("host",uri.host.orEmpty().take(160))
            .put("path",uri.path.orEmpty().take(600))
            .put("queryParameterNames",names)
            .put("hasQuery",!uri.query.isNullOrBlank())
            .put("hasFragment",!uri.fragment.isNullOrBlank())
    } catch (_:Exception) { JSONObject().put("safeUrl","[unparseable]") }

    private fun retailerCookieNames():JSONArray {
        val names=JSONArray()
        try {
            CookieManager.getInstance().getCookie("https://retailer.aceservices.com").orEmpty()
                .split(';').mapNotNull { raw ->
                    raw.substringBefore('=').trim().takeIf { it.isNotBlank() }
                }.distinct().sorted().forEach { names.put(it.take(160)) }
        } catch (_:Exception) {}
        return names
    }

    private fun emitWorkerDiagnostic(event:String,v:WebView?=view,url:String?=v?.url,extra:JSONObject=JSONObject()){
        val cookies=retailerCookieNames()
        val payload=JSONObject()
            .put("requestId",activeRequestId).put("mode",activeMode).put("requestedSku",activeSku)
            .put("workerElapsedMs",if(startedMs>0)System.currentTimeMillis()-startedMs else 0L)
            .put("workerUrlForensics",safeUrlForensics(url))
            .put("workerCurrentUrlForensics",safeUrlForensics(v?.url))
            .put("workerOriginalUrlForensics",safeUrlForensics(v?.originalUrl))
            .put("workerTitle",(v?.title ?: "").take(240))
            .put("retailerCookieNames",cookies).put("retailerCookieCount",cookies.length())
            .put("cookieValuesRedacted",true)
        val keys=extra.keys()
        while(keys.hasNext()){val k=keys.next();payload.put(k,extra.opt(k))}
        emit(event,payload)
    }

    private fun probeWorkerStructure(v:WebView,checkpoint:String,allowTerminal:Boolean){
        val requestId=activeRequestId
        if(terminal||requestId.isBlank())return
        val js="""
          (function(){
            try{
              var sku=document.getElementById('ctl00_ctl00_contentMainPlaceHolder_MainContent_headerSkuDataBar_lblSkuNr');
              var upc=document.getElementById('ctl00_ctl00_contentMainPlaceHolder_MainContent_mainItemData_lvAceItemDetails_ctrl0_ddlUPC');
              var price=document.getElementById('lblHeaderSellingDataStoreRetail');
              var description=document.getElementById('ctl00_ctl00_contentMainPlaceHolder_MainContent_headerSkuDataBar_lblLongDescr');
              var body=String(document.body&&document.body.innerText||'');
              var url=String(location.href||''),title=String(document.title||'');
              return JSON.stringify({readyState:String(document.readyState||''),url:url,title:title,bodyTextLength:body.length,
                skuElementPresent:!!sku,returnedSku:sku?String(sku.textContent||'').trim():'',
                upcElementPresent:!!upc,priceElementPresent:!!price,descriptionElementPresent:!!description,
                iframeCount:document.querySelectorAll('iframe').length,scriptCount:(document.scripts||[]).length,
                chromiumError:url.indexOf('chrome-error://chromewebdata/')===0||title==='Webpage not available'||/net::ERR_/i.test(body)});
            }catch(e){return JSON.stringify({probeError:String(e&&e.message||e)});}
          })();
        """.trimIndent()
        v.evaluateJavascript(js){raw->
            if(terminal||activeRequestId!=requestId)return@evaluateJavascript
            try{
                var decoded=raw?:""
                if(decoded.startsWith("\""))decoded=org.json.JSONTokener(decoded).nextValue() as? String?:decoded
                val state=JSONObject(decoded)
                val chromiumError=state.optBoolean("chromiumError")
                val returnedSku=state.optString("returnedSku").trim()
                val exactSku=returnedSku==activeSku && activeSku.isNotBlank()
                val anyItemStructure=state.optBoolean("skuElementPresent")||state.optBoolean("upcElementPresent")||
                    state.optBoolean("priceElementPresent")||state.optBoolean("descriptionElementPresent")||
                    state.optInt("iframeCount",0)>0
                val smallBody=state.optInt("bodyTextLength",0)<1000
                val complete=state.optString("readyState").equals("complete",true)
                val expectedDetailPage=try{
                    val uri=Uri.parse(state.optString("url"))
                    uri.host.orEmpty().equals("retailer.aceservices.com",true) &&
                        uri.path.orEmpty().contains("/ItemDetailV2/ItemDetail/ItemDetailRedesign.aspx",true)
                }catch(_:Exception){false}
                val healthyItemShell=complete && expectedDetailPage && !chromiumError &&
                    state.optBoolean("skuElementPresent") &&
                    state.optBoolean("priceElementPresent") &&
                    state.optBoolean("descriptionElementPresent") &&
                    state.optInt("iframeCount",0)>0 &&
                    state.optInt("scriptCount",0)>0
                val healthyEmptyItem=healthyItemShell && returnedSku.isBlank() && !skuEvidenceObserved
                val exactSkuNoUpc=healthyItemShell && exactSku && !state.optBoolean("upcElementPresent")
                val suspicious=!exactSku && complete && !anyItemStructure && smallBody
                val missing=catalogMissingFields
                val onlyMasterUpcMissing=missing!=null && missing.length()==1 && missing.optString(0)=="masterUpc"
                emitWorkerDiagnostic("persistent_worker_structure_probe",v,v.url,JSONObject(state.toString())
                    .put("checkpoint",checkpoint).put("suspicious",suspicious)
                    .put("healthyItemShell",healthyItemShell)
                    .put("healthyEmptyItem",healthyEmptyItem)
                    .put("exactSkuNoUpc",exactSkuNoUpc)
                    .put("onlyMasterUpcMissing",onlyMasterUpcMissing)
                    .put("priorThreeSecondSuspicion",structuralSuspicionAtThreeSeconds)
                    .put("priorHealthyEmptyItem",healthyEmptyItemAtThreeSeconds)
                    .put("priorExactSkuNoUpc",exactSkuNoUpcAtThreeSeconds))
                if(chromiumError){
                    finish(JSONObject().put("outcome","NETWORK_ERROR").put("status","NETWORK_ERROR")
                        .put("failureClass","CHROMIUM_ERROR_PAGE").put("structuralEvidence",state))
                }else if(checkpoint=="three_second"){
                    structuralSuspicionAtThreeSeconds=suspicious
                    healthyEmptyItemAtThreeSeconds=healthyEmptyItem
                    exactSkuNoUpcAtThreeSeconds=exactSkuNoUpc
                }else if(allowTerminal && healthyEmptyItemAtThreeSeconds && healthyEmptyItem && !skuEvidenceObserved){
                    captureWorkerPageForensics(v,"healthy_empty_item_detail_not_found")
                    emitWorkerDiagnostic("persistent_worker_not_found_classified",v,v.url,JSONObject(state.toString())
                        .put("classificationBasis","HEALTHY_EMPTY_ITEM_DETAIL_STABLE")
                        .put("firstCheckpoint","three_second").put("confirmationCheckpoint",checkpoint)
                        .put("networkFailureEvidence",false))
                    finish(JSONObject().put("outcome","NOT_FOUND").put("status","NOT_FOUND").put("sku","")
                        .put("classificationBasis","HEALTHY_EMPTY_ITEM_DETAIL_STABLE").put("structuralEvidence",state))
                }else if(allowTerminal && exactSkuNoUpcAtThreeSeconds && exactSkuNoUpc && onlyMasterUpcMissing && catalogSnapshot!=null){
                    captureWorkerPageForensics(v,"exact_sku_no_upc_data")
                    emitWorkerDiagnostic("persistent_worker_no_upc_data_classified",v,v.url,JSONObject(state.toString())
                        .put("classificationBasis","EXACT_SKU_STABLE_NO_UPC_SELECTOR")
                        .put("firstCheckpoint","three_second").put("confirmationCheckpoint",checkpoint)
                        .put("missingFields",catalogMissingFields?:JSONArray()))
                    finish(JSONObject().put("outcome","FOUND_NO_UPC_DATA").put("status","FOUND_NO_UPC_DATA").put("sku",activeSku)
                        .put("catalog",JSONObject(catalogSnapshot!!.toString()))
                        .put("missingFields",catalogMissingFields?.let { JSONArray(it.toString()) } ?: JSONArray())
                        .put("classificationBasis","EXACT_SKU_STABLE_NO_UPC_SELECTOR"))
                }else if(allowTerminal && structuralSuspicionAtThreeSeconds && suspicious && !skuEvidenceObserved){
                    captureWorkerPageForensics(v,"malformed_page_confirmed")
                    finish(JSONObject().put("outcome","MALFORMED_PAGE").put("status","MALFORMED_PAGE")
                        .put("failureClass","STRUCTURALLY_INVALID_ITEM_PAGE").put("structuralEvidence",state))
                }
            }catch(e:Exception){
                emitWorkerDiagnostic("persistent_worker_structure_probe_failed",v,v.url,JSONObject()
                    .put("checkpoint",checkpoint).put("errorType",e.javaClass.simpleName))
            }
        }
    }

    private fun captureWorkerPageForensics(v:WebView,reason:String){
        val requestId=activeRequestId
        if(terminal || requestId.isBlank())return
        val forensicJs="""
          (function(){
            try{
              function clean(x){return String(x==null?'':x).replace(/\s+/g,' ').trim();}
              function safeUrl(raw){
                try{var u=new URL(raw||'',document.baseURI||location.href);u.searchParams.forEach(function(_,k){u.searchParams.set(k,'[redacted]')});u.hash='';return u.href;}
                catch(_){return String(raw||'').slice(0,1000);}
              }
              function redact(raw){
                return String(raw||'')
                  .replace(/((?:password|samlresponse|samlrequest|relaystate|wresult|wctx|token|authorization|access_token|id_token|csrf|xsrf)\s*[:=]\s*)(["'])[^"']*\2/ig,'$1$2[redacted]$2')
                  .replace(/([?&](?:password|SAMLResponse|SAMLRequest|RelayState|wresult|wctx|token|access_token|id_token|code|state|csrf|xsrf)=)[^&"'<>\s]*/gi,'$1[redacted]')
                  .replace(/\$\s*[0-9]+(?:,[0-9]{3})*(?:\.[0-9]{2})?/g,'$[redacted-price]');
              }
              var skuId='ctl00_ctl00_contentMainPlaceHolder_MainContent_headerSkuDataBar_lblSkuNr';
              var priceIds=['divStrL1L2','lblHeaderSellingDataStoreRetail','ctl00_ctl00_contentMainPlaceHolder_MainContent_sellingData_lblRetailPrice','lblRetailPrice'];
              var skuNode=document.getElementById(skuId),returnedSku=skuNode?clean(skuNode.textContent):'';
              var priceNodes=priceIds.map(function(id){return document.getElementById(id)}).filter(Boolean);
              var dynamic=[].slice.call(document.querySelectorAll('[id*=RetailPrice]')).filter(function(n){return priceNodes.indexOf(n)<0;});
              priceNodes=priceNodes.concat(dynamic);
              var storePriceNode=document.getElementById('lblHeaderSellingDataStoreRetail');
              var pricePresent=!!storePriceNode&&/\d/.test(clean(storePriceNode.getAttribute&&storePriceNode.getAttribute('data-storeretail')||storePriceNode.textContent));
              var root=document.documentElement?document.documentElement.cloneNode(true):null;
              if(root){
                [].slice.call(root.querySelectorAll('input,textarea')).forEach(function(el){if(el.hasAttribute('value'))el.setAttribute('value','[redacted]');try{el.value='[redacted]'}catch(_){};});
                [].slice.call(root.querySelectorAll('select')).forEach(function(el){[].slice.call(el.options||[]).forEach(function(o){o.removeAttribute('selected')});});
                priceIds.forEach(function(id){var n=root.querySelector('#'+id);if(n){n.textContent='[redacted-price]';['data-retail','data-storeretail','value'].forEach(function(a){if(n.hasAttribute(a))n.setAttribute(a,'[redacted-price]')});}});
                [].slice.call(root.querySelectorAll('[id*=RetailPrice]')).forEach(function(n){n.textContent='[redacted-price]';});
                [].slice.call(root.querySelectorAll('[href]')).forEach(function(el){el.setAttribute('href',safeUrl(el.getAttribute('href')||''));});
                [].slice.call(root.querySelectorAll('[src]')).forEach(function(el){el.setAttribute('src',safeUrl(el.getAttribute('src')||''));});
                [].slice.call(root.querySelectorAll('form[action]')).forEach(function(el){el.setAttribute('action',safeUrl(el.getAttribute('action')||''));});
              }
              var fullHtml=root?redact(root.outerHTML):'',htmlTruncated=fullHtml.length>40000;
              var scripts=[].slice.call(document.scripts||[]).slice(0,24).map(function(sc){
                return{src:safeUrl(sc.src||'').slice(0,1200),type:String(sc.type||'').slice(0,100),inline:sc.src?'':redact(sc.textContent||'').slice(0,2500)};
              });
              var forms=[].slice.call(document.forms||[]).slice(0,20).map(function(f){
                return{method:String(f.method||'').slice(0,20),action:safeUrl(f.action||'').slice(0,1200),
                  inputs:[].slice.call(f.querySelectorAll('input,button,select,textarea')).slice(0,60).map(function(i){
                    return{tag:String(i.tagName||'').toLowerCase(),type:String(i.type||'').slice(0,50),id:String(i.id||'').slice(0,160),name:String(i.name||'').slice(0,160)};
                  })};
              });
              var iframes=[].slice.call(document.querySelectorAll('iframe')).slice(0,20).map(function(f){
                var o={id:String(f.id||'').slice(0,160),name:String(f.name||'').slice(0,160),src:safeUrl(f.src||'').slice(0,1200),readable:false};
                try{var d=f.contentDocument||f.contentWindow&&f.contentWindow.document;if(d&&d.documentElement){o.readable=true;o.title=String(d.title||'').slice(0,240);o.readyState=String(d.readyState||'');o.bodyTextLength=String(d.body&&d.body.innerText||'').length;}}catch(e){o.readError=String(e&&e.message||e).slice(0,300);}
                return o;
              });
              return JSON.stringify({
                url:safeUrl(location.href||''),title:String(document.title||'').slice(0,240),readyState:String(document.readyState||''),
                bodyTextLength:String(document.body&&document.body.innerText||'').length,htmlLength:fullHtml.length,
                sanitizedHtml:fullHtml.slice(0,40000),htmlTruncated:htmlTruncated,
                skuElementPresent:!!skuNode,returnedSku:returnedSku,skuMatches:returnedSku===${JSONObject.quote(activeSku)},
                priceElementCount:priceNodes.length,pricePresent:pricePresent,
                scriptCount:(document.scripts||[]).length,scripts:scripts,forms:forms,iframes:iframes
              });
            }catch(e){return JSON.stringify({captureError:String(e&&e.message||e).slice(0,500)});}
          })();
        """.trimIndent()
        v.evaluateJavascript(forensicJs){raw->
            if(terminal || activeRequestId!=requestId)return@evaluateJavascript
            try{
                var decoded=raw?:""
                if(decoded.startsWith("\""))decoded=org.json.JSONTokener(decoded).nextValue() as? String?:decoded
                val captured=JSONObject(decoded)
                emitWorkerDiagnostic("persistent_worker_page_forensics",v,v.url,captured
                    .put("reason",reason).put("valuesRedacted",true))
            }catch(e:Exception){
                emitWorkerDiagnostic("persistent_worker_page_forensics_failed",v,v.url,JSONObject()
                    .put("reason",reason).put("errorType",e.javaClass.simpleName))
            }
        }
    }

    private fun createView(): WebView = WebView(activity).apply {
        settings.javaScriptEnabled=true
        settings.domStorageEnabled=true
        settings.allowFileAccess=false
        settings.allowContentAccess=false
        addJavascriptInterface(Bridge(), "PersistentAceNetBridge")
        webChromeClient=object:WebChromeClient(){
            override fun onConsoleMessage(message:ConsoleMessage?):Boolean{
                if(!terminal && message!=null && (message.messageLevel()==ConsoleMessage.MessageLevel.ERROR || message.messageLevel()==ConsoleMessage.MessageLevel.WARNING)){
                    emitWorkerDiagnostic("persistent_worker_console_message",this@apply,this@apply.url,JSONObject()
                        .put("level",message.messageLevel().name).put("message",message.message().take(1000))
                        .put("lineNumber",message.lineNumber()).put("sourceForensics",safeUrlForensics(message.sourceId())))
                }
                return super.onConsoleMessage(message)
            }
        }
        webViewClient=object:WebViewClient(){
            override fun shouldOverrideUrlLoading(v:WebView?,request:WebResourceRequest?):Boolean{
                if(!terminal && request?.isForMainFrame==true){
                    emitWorkerDiagnostic("persistent_worker_main_frame_navigation",v,request.url?.toString(),JSONObject()
                        .put("method",request.method.orEmpty()).put("isRedirect",request.isRedirect)
                        .put("hasGesture",request.hasGesture()))
                }
                return false
            }
            override fun onPageStarted(v:WebView?,url:String?,favicon:android.graphics.Bitmap?){
                super.onPageStarted(v,url,favicon)
                if(!terminal)emitWorkerDiagnostic("persistent_worker_page_started",v,url)
            }
            override fun onPageFinished(v:WebView,url:String?){
                super.onPageFinished(v,url)
                if(terminal)return
                emitWorkerDiagnostic("persistent_worker_page_finished",v,url)
                val current=url.orEmpty()
                if(current.startsWith("chrome-error://chromewebdata/",true) || v.title.orEmpty().equals("Webpage not available",true)){
                    captureWorkerPageForensics(v,"chromium_error_page")
                    finish(JSONObject().put("outcome","NETWORK_ERROR").put("status","NETWORK_ERROR").put("failureClass","CHROMIUM_ERROR_PAGE"))
                    return
                }
                val host=try{Uri.parse(current).host.orEmpty().lowercase()}catch(_:Exception){""}
                when(host){
                    "retailer.aceservices.com" -> {
                        captureWorkerPageForensics(v,"page_finished_before_inspection")
                        inspect(v)
                    }
                    "sts.aceservices.com" -> finish(JSONObject().put("outcome","AUTH_REQUIRED").put("status","AUTH_REQUIRED"))
                    else -> if(host.isNotBlank()) finish(JSONObject().put("outcome","UNEXPECTED_HOST").put("status","UNEXPECTED_HOST").put("host",host))
                }
            }
            override fun onReceivedError(v:WebView?, request:WebResourceRequest?, error:WebResourceError?){
                super.onReceivedError(v,request,error)
                if(terminal || request?.isForMainFrame != true)return
                emitWorkerDiagnostic("persistent_worker_main_frame_network_error",v,request.url?.toString(),JSONObject()
                    .put("errorCode",error?.errorCode ?: 0).put("errorDescription",error?.description?.toString().orEmpty().take(600)))
                finish(JSONObject()
                    .put("outcome","NETWORK_ERROR").put("status","NETWORK_ERROR")
                    .put("failureClass","MAIN_FRAME_NETWORK_ERROR")
                    .put("errorCode",error?.errorCode ?: 0)
                    .put("errorDescription",error?.description?.toString().orEmpty()))
            }
            override fun onReceivedHttpError(v:WebView?, request:WebResourceRequest?, response:WebResourceResponse?){
                super.onReceivedHttpError(v,request,response)
                if(terminal || request?.isForMainFrame != true)return
                val code=response?.statusCode ?: 0;val reason=response?.reasonPhrase.orEmpty();val requestId=activeRequestId
                emitWorkerDiagnostic("persistent_worker_main_frame_http_error",v,request.url?.toString(),JSONObject()
                    .put("httpStatus",code).put("httpReason",reason.take(300)))
                if(code==404 && v!=null){
                    emitWorkerDiagnostic("persistent_worker_404_observation_window_started",v,request.url?.toString(),JSONObject()
                        .put("windowMs",1_500).put("purpose","Allow rendered item-not-found evidence to classify before abnormal HTTP fallback."))
                    v.postDelayed({if(!terminal && activeRequestId==requestId)captureWorkerPageForensics(v,"main_frame_http_404_observation")},500L)
                    v.postDelayed({
                        if(!terminal && activeRequestId==requestId)finish(JSONObject().put("outcome","HTTP_ERROR").put("status","HTTP_ERROR")
                            .put("failureClass","MAIN_FRAME_HTTP_404_UNCLASSIFIED").put("httpStatus",code).put("httpReason",reason))
                    },1_500L);return
                }
                finish(JSONObject().put("outcome","HTTP_ERROR").put("status","HTTP_ERROR")
                    .put("failureClass","MAIN_FRAME_HTTP_ERROR").put("httpStatus",code).put("httpReason",reason))
            }
        }
    }

    private fun inspect(v:WebView){
        val inspectedRequestId=activeRequestId
        emitWorkerDiagnostic("persistent_worker_inspection_started",v,v.url,JSONObject()
            .put("documentReadyStateRequested",true).put("skuEvidenceAtStart",skuEvidenceObserved))
        if(activeMode=="PRODUCTION_PRICE" || activeMode=="PRODUCTION_PRICE_UPCS"){
            val diagnosticMs=(activeTimeoutMs-750L).coerceAtMost(5_500L).coerceAtLeast(1_000L)
            handler.postDelayed({
                if(!terminal && activeRequestId==inspectedRequestId && !skuEvidenceObserved){
                    emitWorkerDiagnostic("persistent_worker_sku_evidence_still_pending",v,v.url,JSONObject()
                        .put("diagnosticAtMs",diagnosticMs).put("skuEvidence",false)
                        .put("terminal",false).put("hardDeadlineMs",activeTimeoutMs))
                    captureWorkerPageForensics(v,"sku_evidence_still_pending")
                }
            },diagnosticMs)
        }
        val expected=JSONObject.quote(activeSku)
        val mode=JSONObject.quote(activeMode)
        val js="""
          (function(){
            if(window.__persistentAceObservers){window.__persistentAceObservers.forEach(function(o){try{o.disconnect()}catch(_){}})}
            window.__persistentAceObservers=[];
            var sent=false,lastDiagnosticSignature='';
            function diagnostic(stage){
              try{
                var skuNode=document.getElementById('ctl00_ctl00_contentMainPlaceHolder_MainContent_headerSkuDataBar_lblSkuNr');
                var returnedSku=skuNode?String(skuNode.textContent||'').trim():'';
                var selectorNames=[];
                if(document.getElementById('divStrL1L2'))selectorNames.push('divStrL1L2');
                if(document.getElementById('lblHeaderSellingDataStoreRetail'))selectorNames.push('lblHeaderSellingDataStoreRetail');
                if(document.getElementById('ctl00_ctl00_contentMainPlaceHolder_MainContent_sellingData_lblRetailPrice'))selectorNames.push('sellingData_lblRetailPrice');
                if(document.getElementById('lblRetailPrice'))selectorNames.push('lblRetailPrice');
                if(document.querySelector('[id*=RetailPrice]'))selectorNames.push('id*=RetailPrice');
                var pricePresent=!!price();
                var bodyTextLength=String(document.body&&document.body.innerText||'').length;
                var signature=[stage,document.readyState,!!skuNode,returnedSku,pricePresent,selectorNames.join(','),bodyTextLength,(document.scripts||[]).length,document.querySelectorAll('iframe').length].join('|');
                if(signature===lastDiagnosticSignature)return;lastDiagnosticSignature=signature;
                PersistentAceNetBridge.diagnostic(JSON.stringify({stage:stage,readyState:String(document.readyState||''),bodyTextLength:bodyTextLength,
                  skuElementPresent:!!skuNode,returnedSku:returnedSku,skuMatches:returnedSku===$expected,
                  priceSelectorFamiliesPresent:selectorNames,pricePresent:pricePresent,
                  scriptCount:(document.scripts||[]).length,iframeCount:document.querySelectorAll('iframe').length}));
              }catch(e){try{PersistentAceNetBridge.diagnostic(JSON.stringify({stage:'DIAGNOSTIC_ERROR',error:String(e&&e.message||e).slice(0,500)}))}catch(_){}}
            }
            function disconnectObservers(){(window.__persistentAceObservers||[]).forEach(function(o){try{o.disconnect()}catch(_){}});window.__persistentAceObservers=[];}
            function deliver(o){if(sent)return;sent=true;disconnectObservers();try{PersistentAceNetBridge.result(JSON.stringify(o))}catch(_){}}
            function parsePrice(raw){
              raw=String(raw||'').trim();var m=raw.match(/[$]\s*([0-9]+(?:,[0-9]{3})*\.[0-9]{2})/)||raw.match(/\b([0-9]+(?:,[0-9]{3})*\.[0-9]{2})\b/);return m?m[1].replace(/,/g,''):'';
            }
            function price(){
              // Store Retail is the shelf/Level 2 comparison authority; do not
              // fall back to Ace/L1 price widgets when it is missing.
              var store=document.getElementById('lblHeaderSellingDataStoreRetail');
              return store?parsePrice(store.getAttribute('data-storeretail')||store.textContent):'';
            }
            function acePrice(){
              // This independent source is retained only for the Ace Retail
              // catalog/export field, never for normal price comparisons.
              var ace=document.getElementById('divStrL1L2');
              return ace?parsePrice(ace.getAttribute('data-retail')||ace.textContent):'';
            }
            function read(){
              if(sent)return;
              var pageBody=String(document.body&&document.body.innerText||'');
              if(/\b(item not found|sku not found|no results found|no item found|no product found)\b/i.test(pageBody)){
                diagnostic('ITEM_NOT_FOUND');
                deliver({status:'NOT_FOUND',outcome:'NOT_FOUND',sku:''});
                return;
              }
              var e=document.getElementById('ctl00_ctl00_contentMainPlaceHolder_MainContent_headerSkuDataBar_lblSkuNr');
              var s=e?String(e.textContent||'').trim():'';
              if(!s){diagnostic('WAITING_FOR_SKU');return;}
              try{PersistentAceNetBridge.skuObserved(s)}catch(_){}
              if(s!==$expected){deliver({status:'SKU_MISMATCH',outcome:'SKU_MISMATCH',sku:s});return;}
              if($mode==='PRODUCTION_PRICE'){var p=price();if(!p){diagnostic('WAITING_FOR_PRICE');return;}diagnostic('PRICE_READY');deliver({status:'FOUND',outcome:'FOUND',sku:s,price:p});return;}
              var q=document.getElementById('ctl00_ctl00_contentMainPlaceHolder_MainContent_mainItemData_lvAceItemDetails_ctrl0_ddlUPC');
              var seen={},a=q&&q.options?[].slice.call(q.options).map(function(o){return String(o.value||o.textContent||'').replace(/\D/g,'');}).filter(function(x){if(!/^\d{6,14}$/.test(x)||seen[x])return false;seen[x]=1;return true;}):[];
              if($mode==='PRODUCTION_PRICE_UPCS'){var pp=price();if(!pp||!a.length)return;deliver({status:'FOUND',outcome:'FOUND',sku:s,price:pp,upcs:a});return;}
              if($mode==='PRODUCTION_UPCS'){if(!a.length)return;deliver({status:'FOUND',outcome:'FOUND',sku:s,upcs:a});return;}
              if($mode!=='PRODUCTION_CATALOG'&&$mode!=='PRODUCTION_MISC_CATALOG'&&$mode!=='PRODUCTION_REPAIR_CATALOG')return;
              function clean(x){return String(x==null?'':x).replace(/\s+/g,' ').trim();}
              var state=window.__persistentAceCatalogState||{catalog:{sku:s,allUpcs:[]},lastMissing:''};window.__persistentAceCatalogState=state;
              function nodeValue(n){if(!n)return '';if(n.tagName==='SELECT'&&n.options){var sel=n.options[n.selectedIndex>=0?n.selectedIndex:0];return clean(sel&&(sel.value||sel.textContent));}return clean(n.value||n.getAttribute&&n.getAttribute('data-value')||n.textContent);}
              function readableDocuments(){
                var out=[document],seen=[document],cursor=0;
                while(cursor<out.length){var parent=out[cursor++],frames=[].slice.call(parent.querySelectorAll('iframe'));frames.forEach(function(f){try{var d=f.contentDocument||f.contentWindow&&f.contentWindow.document;if(d&&d.documentElement&&seen.indexOf(d)<0){seen.push(d);out.push(d);}}catch(_){}});}
                return out;
              }
              function observeReadableDocuments(){
                readableDocuments().forEach(function(doc){if(!doc.documentElement||doc.__persistentAceCatalogObserved)return;doc.__persistentAceCatalogObserved=true;var observer=new MutationObserver(function(){read();observeReadableDocuments();});observer.observe(doc.documentElement,{subtree:true,childList:true,characterData:true,attributes:true});window.__persistentAceObservers.push(observer);});
              }
              observeReadableDocuments();
              function byId(parts){var docs=readableDocuments();for(var d=0;d<docs.length;d++){var nodes=[].slice.call(docs[d].querySelectorAll('[id]'));for(var i=0;i<parts.length;i++){var re=new RegExp(parts[i],'i'),n=nodes.find(function(x){return re.test(x.id||'')&&nodeValue(x);});if(n)return nodeValue(n);}}return '';}
              function byLabel(labels){
                var docs=readableDocuments();
                for(var d=0;d<docs.length;d++){var doc=docs[d],nodes=[].slice.call(doc.querySelectorAll('label,th,td,dt,span,div'));
                  for(var i=0;i<labels.length;i++){
                    var want=labels[i].toLowerCase(),lab=nodes.find(function(n){var t=clean(n.textContent).replace(/[:：]\s*$/,'').toLowerCase();return t===want;});if(!lab)continue;
                    var targetId=lab.getAttribute&&lab.getAttribute('for');if(targetId){var target=doc.getElementById(targetId);if(nodeValue(target))return nodeValue(target);}
                    var root=lab.closest&&lab.closest('tr');if(root){var cells=[].slice.call(root.querySelectorAll('td,th,input,select,textarea,dd,span')).filter(function(n){return n!==lab&&nodeValue(n)&&clean(n.textContent).replace(/[:：]\s*$/,'').toLowerCase()!==want;});if(cells.length)return nodeValue(cells[cells.length-1]);}
                    var next=lab.nextElementSibling;if(nodeValue(next))return nodeValue(next);
                    var parent=lab.parentElement;if(parent){var siblings=[].slice.call(parent.children||[]),idx=siblings.indexOf(lab);for(var j=idx+1;j<siblings.length;j++)if(nodeValue(siblings[j]))return nodeValue(siblings[j]);}
                  }
                }return '';
              }
              function redactSecrets(raw){
                return String(raw||'')
                  .replace(/(<input[^>]+(?:password|saml|token|auth)[^>]+value=)(["'])[^"']*\2/ig,'$1$2[redacted]$2')
                  .replace(/((?:password|samlresponse|token|authorization)\s*[:=]\s*)(["'])[^"']*\2/ig,'$1$2[redacted]$2');
              }
              function captureDocument(doc,label){
                var scripts=[].slice.call(doc.scripts||[]).map(function(sc){return{src:sc.src||'',type:sc.type||'',inline:sc.src?'':redactSecrets(sc.textContent||'')};});
                var elements=[].slice.call(doc.querySelectorAll('[id],[name],[data-value],label,th,td,dt')).map(function(n){return{tag:(n.tagName||'').toLowerCase(),id:n.id||'',name:n.name||'',for:n.getAttribute&&n.getAttribute('for')||'',dataValue:n.getAttribute&&n.getAttribute('data-value')||'',text:clean(n.textContent).slice(0,500)};});
                return{label:label,url:String(doc.location&&doc.location.href||''),title:String(doc.title||''),readyState:String(doc.readyState||''),html:redactSecrets(doc.documentElement&&doc.documentElement.outerHTML||''),scripts:scripts,elements:elements};
              }
              function captureForensics(missing){
                try{if(!PersistentAceNetBridge.shouldCaptureForensics())return;var docs=[captureDocument(document,'main')],frames=[].slice.call(document.querySelectorAll('iframe')).map(function(f,idx){var base={index:idx,src:f.src||'',id:f.id||'',name:f.name||'',readable:false};try{var d=f.contentDocument||f.contentWindow&&f.contentWindow.document;if(d&&d.documentElement){base.readable=true;base.document=captureDocument(d,'iframe-'+idx);}}catch(e){base.readError=String(e&&e.message||e);}return base;});PersistentAceNetBridge.forensics(JSON.stringify({status:'INCOMPLETE',missingFields:missing,document:docs[0],iframes:frames}));}catch(e){try{PersistentAceNetBridge.forensics(JSON.stringify({status:'FORENSICS_ERROR',missingFields:missing,error:String(e&&e.message||e)}))}catch(_){}}
              }
              function exact(id){return nodeValue(document.getElementById(id));}
              function present(v){v=clean(v);return v!==''&&v!=='-';}
              function numeric(v){return /\d/.test(clean(v));}
              function code(v){return /^\s*\d+/.test(clean(v));}
              function remember(k,v,valid){v=clean(v);if((valid||present)(v))state.catalog[k]=v;}
              remember('aceRetailPrice',acePrice(),numeric);
              remember('level2RetailPrice',price(),numeric);
              remember('description',exact('ctl00_ctl00_contentMainPlaceHolder_MainContent_headerSkuDataBar_lblLongDescr'),present);
              remember('retailerEachCost',exact('spnEachCost'),numeric);
              remember('manufacturerNumber',exact('ctl00_ctl00_contentMainPlaceHolder_MainContent_headerSkuDataBar_lblMfgNr'),present);
              remember('orderMultiple',exact('spnEachOM'),numeric);
              remember('omWeight',exact('spnEachWeight'),numeric);
              remember('commodityGroup',exact('ctl00_ctl00_contentMainPlaceHolder_MainContent_headerSkuDataBar_lblComGrpBcrumb'),code);
              remember('merchandiseClassNumber',exact('ctl00_ctl00_contentMainPlaceHolder_MainContent_headerSkuDataBar_lblMerchClsBcrumb'),code);
              remember('productGroupNumber',exact('ctl00_ctl00_contentMainPlaceHolder_MainContent_headerSkuDataBar_lblProdGrpBcrumb'),code);
              a.forEach(function(x){if(state.catalog.allUpcs.indexOf(x)<0)state.catalog.allUpcs.push(x);});
              if(state.catalog.allUpcs.length)state.catalog.masterUpc=state.catalog.allUpcs[0];
              var required=['aceRetailPrice','description','retailerEachCost','manufacturerNumber','orderMultiple','commodityGroup','merchandiseClassNumber','productGroupNumber','masterUpc'];if($mode==='PRODUCTION_MISC_CATALOG'||$mode==='PRODUCTION_REPAIR_CATALOG')required.push('omWeight');
              var validators={aceRetailPrice:numeric,description:present,retailerEachCost:numeric,manufacturerNumber:present,orderMultiple:numeric,omWeight:numeric,commodityGroup:code,merchandiseClassNumber:code,productGroupNumber:code,masterUpc:function(v){return /^\d{6,14}$/.test(clean(v));}};
              var missing=required.filter(function(k){var fn=validators[k]||present;return !fn(state.catalog[k]);}),signature=missing.join(',');
              if(signature!==state.lastMissing){state.lastMissing=signature;try{PersistentAceNetBridge.progress(JSON.stringify({status:'LOADING',foundFields:required.filter(function(k){return missing.indexOf(k)<0;}),missingFields:missing,upcCount:state.catalog.allUpcs.length}))}catch(_){}}
              try{PersistentAceNetBridge.catalogSnapshot(JSON.stringify({catalog:state.catalog,missingFields:missing}))}catch(_){}
              if(missing.length){captureForensics(missing);return;}
              deliver({status:'FOUND',outcome:'FOUND',sku:s,catalog:state.catalog});
            }
            if($mode!=='PRODUCTION_CATALOG'&&$mode!=='PRODUCTION_MISC_CATALOG'&&$mode!=='PRODUCTION_REPAIR_CATALOG'){var rootObserver=new MutationObserver(read);rootObserver.observe(document.documentElement,{subtree:true,childList:true,characterData:true,attributes:true});window.__persistentAceObservers.push(rootObserver);diagnostic('OBSERVER_INSTALLED');}
            diagnostic('SCRIPT_ENTERED');
            read();
          })();
        """.trimIndent()
        v.evaluateJavascript(js){ _ ->
            if(!terminal && activeRequestId==inspectedRequestId){
                emitWorkerDiagnostic("persistent_worker_inspection_script_callback",v,v.url,JSONObject()
                    .put("callbackReceived",true).put("skuEvidence",skuEvidenceObserved))
            }
        }
    }

    private fun finish(result:JSONObject){
        if(terminal)return
        terminal=true;handler.removeCallbacksAndMessages(null)
        val id=activeRequestId;val mode=activeMode;val sku=activeSku
        result.put("requestedSku",sku).put("skuEvidence",skuEvidenceObserved).put("totalMs",System.currentTimeMillis()-startedMs).put("persistentWorker",true)
        emit("persistent_worker_result",JSONObject(result.toString()).put("requestId",id).put("mode",mode))
        val prime=primeCallback
        val isPrime=id.startsWith("__startup_prime__")
        if(isPrime){
            val exact=result.optString("status",result.optString("outcome","UNKNOWN"))=="FOUND" && result.optString("sku")==sku && result.optString("price").isNotBlank()
            primed=exact
            primeCallback=null
            emit("persistent_worker_prime_result",JSONObject(result.toString()).put("ready",primed))
        }
        resetActive()
        if(isPrime) prime?.invoke(result) else complete(id,mode,result)
    }

    private fun resetActive(){terminal=true;activeRequestId="";activeMode="";activeSku="";startedMs=0L;skuEvidenceObserved=false;repairCatalogSnapshot=null;repairCatalogMissingFields=null;catalogSnapshot=null;catalogMissingFields=null;structuralSuspicionAtThreeSeconds=false;healthyEmptyItemAtThreeSeconds=false;exactSkuNoUpcAtThreeSeconds=false;activeTimeoutMs=AceNetTimingPolicy.ITEM_ATTEMPT_MS}

    private fun validRetailerUrl(raw:String?):Boolean=try{val u=Uri.parse(raw.orEmpty());u.host.orEmpty().equals("retailer.aceservices.com",true)&&u.path.orEmpty().contains("/itemdetailv2/itemdetail/",true)&&u.queryParameterNames.any{it.equals("sku",true)}}catch(_:Exception){false}
    private fun directRetailerUrl(template:String?,sku:String):String?{
        if(!validRetailerUrl(template))return null
        val u=Uri.parse(template);val b=u.buildUpon().clearQuery()
        u.queryParameterNames.forEach{name->u.getQueryParameters(name).forEach{value->b.appendQueryParameter(name,if(name.equals("sku",true))sku else value)}}
        return b.build().toString()
    }
}
