/**
 * OWNERSHIP:
 * File: app/src/main/java/com/rmtb/upclistbuilder/ProductImageSearch.kt
 * Owner: Native Product Image Search
 * Role: Platform/network service
 * Responsibility: Owns native product-image search/download candidate discovery and response delivery for presentation support.
 * Does not own: Product identity, catalog/price authority, normal lookup success, or image rendering.
 * Side effects: Performs approved image/network operations and returns presentation-only results.
 * Related code: Web cache/presentation support belongs to lookup/product-image-service.js.
 */
package com.rmtb.upclistbuilder

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.util.concurrent.ExecutorCompletionService
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Native, no-key product-image search with isolated provider fallbacks.
 * Public search surfaces can change independently; keeping each adapter isolated
 * prevents one provider change from disabling product images entirely.
 */
object ProductImageSearch {
    data class Result(val dataUrl: String, val source: String, val query: String)
    private data class Candidate(val url: String, val referer: String)

    private const val UA = "Mozilla/5.0 (Linux; Android 16; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151 Mobile Safari/537.36"
    private const val GOOGLE_SIMPLE_UA = "Nokia6630/1.0 (3.45.113) Profile/MIDP-2.0 Configuration/CLDC-1.1"
    private const val MAX_TEXT = 2_500_000
    private const val MAX_IMAGE = 3_500_000
    private const val MAX_EDGE = 900

    private val memoryCache = object : LinkedHashMap<String, Result>(72, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Result>?): Boolean = size > 64
    }

    fun lookup(upc: String, sku: String, mfg: String, description: String): Result? {
        val key = listOf(upc, sku, mfg, description).joinToString("|") { it.trim().lowercase() }
        synchronized(memoryCache) { memoryCache[key]?.let { return it } }
        val queries = buildQueries(upc, sku, mfg, description)
        if (queries.isEmpty()) return null

        // Fast path: race the two strongest providers instead of waiting for all providers eagerly.
        // Only the first two high-information query variants are attempted during interactive lookup.
        for (query in queries.take(2)) {
            raceStage(query, 3_200L, listOf(
                "Native Google Images" to { google(query) },
                "Native Bing Images" to { bing(query) }
            ))?.let { result ->
                synchronized(memoryCache) { memoryCache[key] = result }
                return result
            }
        }

        // Second-stage fallbacks are also raced, and only for the strongest query.
        raceStage(queries.first(), 3_500L, listOf(
            "Native DuckDuckGo Images" to { duckDuckGo(queries.first()) },
            "Native Yandex Images" to { yandex(queries.first()) }
        ))?.let { result ->
            synchronized(memoryCache) { memoryCache[key] = result }
            return result
        }
        return null
    }

    private fun raceStage(query: String, budgetMs: Long, providers: List<Pair<String, () -> List<Candidate>>>): Result? {
        val executor = Executors.newFixedThreadPool(providers.size.coerceAtLeast(1))
        val completion = ExecutorCompletionService<Pair<String, List<Candidate>>>(executor)
        val futures = providers.map { (name, fn) -> completion.submit(java.util.concurrent.Callable { name to runCatching { fn() }.getOrDefault(emptyList()) }) }
        val deadline = System.nanoTime() + TimeUnit.MILLISECONDS.toNanos(budgetMs)
        try {
            repeat(providers.size) {
                val remaining = deadline - System.nanoTime()
                if (remaining <= 0) return null
                val finished = completion.poll(remaining, TimeUnit.NANOSECONDS) ?: return null
                val (name, candidates) = runCatching { finished.get() }.getOrNull() ?: return@repeat
                if (candidates.isEmpty()) return@repeat
                val downloadBudget = TimeUnit.NANOSECONDS.toMillis((deadline - System.nanoTime()).coerceAtLeast(0)).coerceAtLeast(250L)
                raceCandidateDownloads(name, query, candidates.take(6), downloadBudget)?.let { return it }
            }
            return null
        } finally {
            futures.forEach { it.cancel(true) }
            executor.shutdownNow()
        }
    }

    private fun raceCandidateDownloads(source: String, query: String, candidates: List<Candidate>, budgetMs: Long): Result? {
        if (candidates.isEmpty() || budgetMs <= 0) return null
        val poolSize = minOf(4, candidates.size)
        val executor = Executors.newFixedThreadPool(poolSize)
        val completion = ExecutorCompletionService<String?>(executor)
        val futures = candidates.map { candidate -> completion.submit(java.util.concurrent.Callable<String?> { downloadAndNormalize(candidate.url, candidate.referer) }) }
        val deadline = System.nanoTime() + TimeUnit.MILLISECONDS.toNanos(budgetMs)
        try {
            repeat(candidates.size) {
                val remaining = deadline - System.nanoTime()
                if (remaining <= 0) return null
                val finished = completion.poll(remaining, TimeUnit.NANOSECONDS) ?: return null
                runCatching { finished.get() }.getOrNull()?.let { return Result(it, source, query) }
            }
            return null
        } finally {
            futures.forEach { it.cancel(true) }
            executor.shutdownNow()
        }
    }

    internal fun buildQueries(upc: String, sku: String, mfg: String, description: String): List<String> {
        val u=upc.trim(); val s=sku.trim(); val m=mfg.trim(); val d=description.trim().replace(Regex("\\s+")," ").take(180)
        if (listOf(u,s,m,d).all { it.isBlank() }) return emptyList()
        return linkedSetOf<String>().apply {
            if(u.isNotBlank()&&m.isNotBlank()&&d.isNotBlank()) add("\"$u\" \"$m\" $d")
            if(u.isNotBlank()&&s.isNotBlank()&&d.isNotBlank()) add("\"$u\" \"$s\" $d")
            if(m.isNotBlank()&&d.isNotBlank()) add("\"$m\" $d")
            if(u.isNotBlank()&&d.isNotBlank()) add("\"$u\" $d")
            if(s.isNotBlank()&&d.isNotBlank()) add("\"$s\" $d")
            if(d.isNotBlank()) add(d)
            if(u.isNotBlank()) add("\"$u\"")
        }.toList()
    }

    private fun google(query: String): List<Candidate> {
        val q=enc(query); val out=linkedSetOf<String>()
        // Simplified mobile surface first: far less dependent on Google's desktop JS payload.
        val simple=fetchText("https://www.google.com/search?tbm=isch&safe=active&hl=en&q=$q", GOOGLE_SIMPLE_UA)
        if(simple!=null) out += extractGoogle(simple)
        val modern=fetchText("https://www.google.com/search?udm=2&safe=active&hl=en&q=$q", UA)
        if(modern!=null) out += extractGoogle(modern)
        return out.map { Candidate(it,"https://www.google.com/") }
    }

    private fun bing(query: String): List<Candidate> {
        val html=fetchText("https://www.bing.com/images/search?q=${enc(query)}&form=HDRSC3&first=1",UA)?:return emptyList()
        val out=linkedSetOf<String>()
        // Bing stores original/thumbnail URLs in JSON metadata on result anchors.
        Regex("""m=\"([^\"]+)\"""").findAll(html).forEach { hit ->
            val raw=htmlDecode(hit.groupValues[1])
            runCatching { JSONObject(raw) }.getOrNull()?.let { j ->
                listOf("murl","turl").forEach { key -> j.optString(key).takeIf { it.startsWith("http") }?.let(out::add) }
            }
        }
        Regex("""(?:murl|turl)[\\\"':=]+(https?[^\\\"'&<> ]+)""",RegexOption.IGNORE_CASE).findAll(html).forEach { out += cleanUrl(htmlDecode(it.groupValues[1])) }
        return out.map { Candidate(it,"https://www.bing.com/") }
    }

    private fun duckDuckGo(query: String): List<Candidate> {
        val landing=fetchText("https://duckduckgo.com/?q=${enc(query)}&iax=images&ia=images",UA)?:return emptyList()
        val token = listOf(
            Regex("""vqd=['\"]([^'\"]+)"""),
            Regex("""vqd=([0-9-]+)&""")
        ).firstNotNullOfOrNull { it.find(landing)?.groupValues?.getOrNull(1) } ?: return emptyList()
        val json=fetchText("https://duckduckgo.com/i.js?l=us-en&o=json&q=${enc(query)}&vqd=${enc(token)}&f=,,,,,&p=1",UA,mapOf("Referer" to "https://duckduckgo.com/"))?:return emptyList()
        val root=runCatching { JSONObject(json) }.getOrNull()?:return emptyList()
        val arr=root.optJSONArray("results")?:return emptyList(); val out=linkedSetOf<String>()
        for(i in 0 until arr.length()) arr.optJSONObject(i)?.let { j -> listOf("image","thumbnail").forEach { k -> j.optString(k).takeIf { it.startsWith("http") }?.let(out::add) } }
        return out.map { Candidate(it,"https://duckduckgo.com/") }
    }

    private fun yandex(query: String): List<Candidate> {
        val html=fetchText("https://yandex.com/images/search?text=${enc(query)}",UA)?:return emptyList(); val out=linkedSetOf<String>()
        // Yandex exposes image metadata as JSON in serp-item data attributes / response payloads.
        Regex("""data-bem=\"([^\"]+)\"""").findAll(html).forEach { hit ->
            val raw=htmlDecode(hit.groupValues[1])
            Regex("""\"(?:origin|url|preview|thumb)[^\"]*\"\s*:\s*\"(https?:\\?/\\?/[^\"]+)\"""",RegexOption.IGNORE_CASE).findAll(raw).forEach { m -> out += cleanUrl(m.groupValues[1].replace("\\/","/")) }
        }
        Regex("""https?:\\?/\\?/[^\"'<> ]+?\\.(?:jpg|jpeg|png|webp)(?:\\?[^\"'<> ]*)?""",RegexOption.IGNORE_CASE).findAll(html).forEach { out += cleanUrl(it.value.replace("\\/","/")) }
        return out.map { Candidate(it,"https://yandex.com/") }
    }

    internal fun extractGoogle(raw: String): List<String> {
        val html=htmlDecode(raw.replace("\\u003d","=").replace("\\u0026","&").replace("\\u002f","/").replace("\\/","/")); val out=linkedSetOf<String>()
        Regex("""https://encrypted-tbn[0-9]*\\.gstatic\\.com/images\\?[^\"'< >\\s\\]+""").findAll(html).forEach { out += cleanUrl(it.value) }
        Regex("""(?:imgurl|mediaurl)=([^&\"'<>\\s]+)""",RegexOption.IGNORE_CASE).findAll(html).forEach { h -> runCatching { URLDecoder.decode(h.groupValues[1],"UTF-8") }.getOrNull()?.takeIf { it.startsWith("http") }?.let(out::add) }
        Regex("""https://[^\"'<>\\s\\]+?\\.(?:jpg|jpeg|png|webp)(?:\\?[^\"'<>\\s\\]*)?""",RegexOption.IGNORE_CASE).findAll(html).forEach { out += cleanUrl(it.value) }
        return out.filterNot { it.contains("googlelogo", ignoreCase = true)||it.contains("favicon", ignoreCase = true)||it.contains("generate_204", ignoreCase = true) }
    }

    private fun enc(s:String)=URLEncoder.encode(s,StandardCharsets.UTF_8.name())
    private fun htmlDecode(s:String)=s.replace("&quot;","\"").replace("&amp;","&").replace("&#39;","'").replace("&lt;","<").replace("&gt;",">")
    private fun cleanUrl(s:String)=s.trim().trimEnd('\\',',',']','}',')').replace("&amp;","&")

    private fun fetchText(url:String, userAgent:String, headers:Map<String,String> = emptyMap()):String?=runCatching {
        val c=(URL(url).openConnection() as HttpURLConnection).apply { connectTimeout=2_500;readTimeout=3_200;instanceFollowRedirects=true;setRequestProperty("User-Agent",userAgent);setRequestProperty("Accept","text/html,application/json,*/*;q=0.8");setRequestProperty("Accept-Language","en-US,en;q=0.9");headers.forEach{(k,v)->setRequestProperty(k,v)} }
        try { if(c.responseCode !in 200..299)return@runCatching null;val out=ByteArrayOutputStream();val b=ByteArray(16384);c.inputStream.use{input->while(out.size()<MAX_TEXT){val n=input.read(b,0,minOf(b.size,MAX_TEXT-out.size()));if(n<0)break;out.write(b,0,n)}};String(out.toByteArray(),StandardCharsets.UTF_8) } finally { c.disconnect() }
    }.getOrNull()

    private fun downloadAndNormalize(url:String, referer:String):String?=runCatching {
        val c=(URL(url).openConnection() as HttpURLConnection).apply { connectTimeout=2_500;readTimeout=3_200;instanceFollowRedirects=true;setRequestProperty("User-Agent",UA);setRequestProperty("Accept","image/avif,image/webp,image/apng,image/*,*/*;q=0.8");setRequestProperty("Referer",referer) }
        try { if(c.responseCode !in 200..299)return@runCatching null;val type=c.contentType.orEmpty().lowercase();if(type.isNotBlank()&&!type.startsWith("image/"))return@runCatching null;val out=ByteArrayOutputStream();val b=ByteArray(16384);c.inputStream.use{input->while(out.size()<=MAX_IMAGE){val n=input.read(b,0,minOf(b.size,MAX_IMAGE+1-out.size()));if(n<0)break;out.write(b,0,n)}};if(out.size()>MAX_IMAGE)return@runCatching null;val decoded=BitmapFactory.decodeByteArray(out.toByteArray(),0,out.size())?:return@runCatching null;if(decoded.width<60||decoded.height<60){decoded.recycle();return@runCatching null};val edge=maxOf(decoded.width,decoded.height);val bitmap=if(edge>MAX_EDGE){val scale=MAX_EDGE.toFloat()/edge;Bitmap.createScaledBitmap(decoded,(decoded.width*scale).toInt().coerceAtLeast(1),(decoded.height*scale).toInt().coerceAtLeast(1),true)}else decoded;val jpeg=ByteArrayOutputStream();val ok=bitmap.compress(Bitmap.CompressFormat.JPEG,84,jpeg);if(bitmap!==decoded)bitmap.recycle();decoded.recycle();if(!ok||jpeg.size()<500)return@runCatching null;"data:image/jpeg;base64,"+Base64.encodeToString(jpeg.toByteArray(),Base64.NO_WRAP) } finally { c.disconnect() }
    }.getOrNull()
}
