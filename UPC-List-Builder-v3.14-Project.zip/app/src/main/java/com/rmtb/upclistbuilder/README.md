# Native Android Package Ownership

OWNS: Android lifecycle/WebView hosting, the single `AndroidNative` bridge composition, AceNet session/retrieval/extraction, scanner camera UI, native file/download APIs, diagnostics safety persistence, product-image search, and update/install behavior.

DEPENDENCY DIRECTION:
- `MainActivity` composes focused native owners.
- AceNet coordinator consumes Session Manager, Retrieval Service, incident state, classifiers, and worker capabilities; it must not absorb updater/export/scanner/image-search responsibilities.
- Retrieval Service alone constructs/owns the retained PersistentAceNetWorker.
- PersistentAceNetWorker alone owns production item-page extraction.
- native diagnostics observe behavior; they do not determine business/session truth.

DOES NOT OWN: web domain rules, Work Session persistence, Master/Local catalog policy, DSD/MISC workbook rules, or browser/PWA lifecycle.

LIFECYCLE: every WebView, worker, callback, camera resource, timer, and executor must have one documented creator/owner and bounded release behavior.

OPTIONAL CHATGPT TOKEN: `ChatGPTConnectionVault.kt` owns encrypted ChatGPT device pairing independent of `AceNetSessionManager`, with a separate Keystore key and SharedPreferences entry. `MainActivity.NativeBridge` exposes only bounded save/read/delete composition, no MCP networking or invoice parsing.

DIAGNOSTIC EXPORT: `NativeFileExportService` owns a bounded acknowledgment-driven writer on a single background executor; `PendingDiagnosticDownload` owns atomic pending MediaStore/file finalization and rollback. Native callbacks route through MainActivity without moving writing to its main thread.

DIAGNOSTIC ZIP: `PendingDiagnosticDownload` compresses each acknowledged UTF-8 JSON chunk into one ZIP entry on the existing background worker, then closes the archive before atomically publishing. Failed/aborted ZIPs remain pending and are removed; the prior `.json` path is accepted for legacy callers.
