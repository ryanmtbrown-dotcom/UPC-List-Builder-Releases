/**
 * OWNERSHIP:
 * File: app/src/main/java/com/rmtb/upclistbuilder/ScannerActivity.kt
 * Owner: Native Scanner
 * Role: Activity/camera controller
 * Responsibility: Owns Android camera/scanner lifecycle, barcode detection, user scanner interaction, and delivery of accepted scan results.
 * Does not own: Web lookup routing, catalog persistence, DSD/MISC policy, or general application navigation.
 * Side effects: Owns camera/activity/listener lifecycle and returns scanner results to the web/application boundary.
 * Related code: Web scanner UI/routing belongs to scanner/scanner-controller.js and scanner-workspace-router.js.
 */
package com.rmtb.upclistbuilder

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Rect
import android.os.Bundle
import android.util.Base64
import java.io.ByteArrayOutputStream
import java.time.Instant
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max
import kotlin.math.min

/** Native CameraX barcode scanner with manual NIF image capture. Hardware capture stays native. */
class ScannerActivity : AppCompatActivity() {
    private lateinit var preview: PreviewView
    private lateinit var overlay: ScannerOverlayView
    private lateinit var status: TextView
    private lateinit var flash: Button
    private var camera: Camera? = null
    private var capture: ImageCapture? = null
    private val executor = Executors.newSingleThreadExecutor()
    private val busy = AtomicBoolean(false)
    private var stableUpc: String? = null
    private var stableCount = 0
    private var candidateFirstSeenMs = 0L
    private var candidateBox: Rect? = null
    private var candidateImageWidth = 0
    private var candidateImageHeight = 0
    private var scanStartedMs = 0L
    private var darkCount = 0
    private var torchUsed = false
    private var flashMode = 0 // 0 auto, 1 on, 2 off
    private var autoTorchLatched = false

    private val barcodeScanner by lazy {
        BarcodeScanning.getClient(
            BarcodeScannerOptions.Builder().setBarcodeFormats(
                Barcode.FORMAT_UPC_A, Barcode.FORMAT_UPC_E,
                Barcode.FORMAT_EAN_13, Barcode.FORMAT_EAN_8
            ).build()
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        scanStartedMs = System.currentTimeMillis()
        startCamera()
    }

    private fun buildUi() {
        val root = FrameLayout(this)
        preview = PreviewView(this).apply { scaleType = PreviewView.ScaleType.FILL_CENTER }
        root.addView(preview, FrameLayout.LayoutParams(-1, -1))
        overlay = ScannerOverlayView(this)
        root.addView(overlay, FrameLayout.LayoutParams(-1, -1))
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; setPadding(24, 24, 24, 24)
            setBackgroundColor(0xB8000000.toInt()); gravity = Gravity.CENTER_VERTICAL
        }
        status = TextView(this).apply { text = "Starting native camera…"; setTextColor(Color.WHITE); textSize = 15f }
        top.addView(status, LinearLayout.LayoutParams(0, -2, 1f))
        flash = Button(this).apply { text = "Flash: Auto"; setOnClickListener { flashMode = (flashMode + 1) % 3; updateFlash() } }
        top.addView(flash)
        top.addView(Button(this).apply { text = "Capture NIF"; setOnClickListener { captureNifPhoto() } })
        top.addView(Button(this).apply { text = "Close"; setOnClickListener { finish() } })
        root.addView(top, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))
        setContentView(root)
        ViewCompat.setOnApplyWindowInsetsListener(root) { _, ins ->
            val bars = ins.getInsets(WindowInsetsCompat.Type.systemBars())
            top.setPadding(24, 24 + bars.top, 24, 24)
            ins
        }
        ViewCompat.requestApplyInsets(root)
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val p = Preview.Builder().build().also { it.setSurfaceProvider(preview.surfaceProvider) }
            capture = ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY).build()
            try {
                provider.unbindAll()
                val analysis = ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
                analysis.setAnalyzer(executor) { analyze(it) }
                camera = provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, p, capture, analysis)
                runOnUiThread { status.text = "Scanning…"; updateFlash() }
            } catch (e: Exception) { runOnUiThread { status.text = "Camera error: ${e.message}" } }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun updateFlash() {
        val has = camera?.cameraInfo?.hasFlashUnit() == true
        flash.isEnabled = has
        flash.text = if (!has) "Flash unavailable" else when (flashMode) { 1 -> "Flash: On"; 2 -> "Flash: Off"; else -> "Flash: Auto" }
        if (has) {
            if (flashMode == 0 && darkCount >= 6) autoTorchLatched = true
            val on = flashMode == 1 || (flashMode == 0 && autoTorchLatched)
            camera?.cameraControl?.enableTorch(on)
            if (on) torchUsed = true
        }
    }

    @androidx.annotation.OptIn(ExperimentalGetImage::class)
    private fun analyze(proxy: ImageProxy) {
        val media = proxy.image ?: run { proxy.close(); return }
        sampleDark(proxy)
        barcodeScanner.process(InputImage.fromMediaImage(media, proxy.imageInfo.rotationDegrees)).addOnSuccessListener { codes ->
            val hit = codes.firstOrNull {
                val raw = it.rawValue ?: return@firstOrNull false
                ScannerPureLogic.isSupportedUpc(raw)
            }
            val value = hit?.rawValue?.let(ScannerPureLogic::normalizeUpc)
            if (value != null) {
                val now = System.currentTimeMillis()
                if (stableUpc == value) {
                    stableCount++
                } else {
                    stableUpc = value
                    stableCount = 1
                    candidateFirstSeenMs = now
                    candidateBox = hit.boundingBox
                    val rotated = proxy.imageInfo.rotationDegrees % 180 != 0
                    candidateImageWidth = if (rotated) proxy.height else proxy.width
                    candidateImageHeight = if (rotated) proxy.width else proxy.height
                }
                val overlayRotated = proxy.imageInfo.rotationDegrees % 180 != 0
                val overlayW = if (overlayRotated) proxy.height else proxy.width
                val overlayH = if (overlayRotated) proxy.width else proxy.height
                runOnUiThread { overlay.setDetectedBarcode(hit.boundingBox, overlayW, overlayH); overlay.locked = true; status.text = if (stableCount >= 2) "UPC confirmed" else "UPC found · confirming…" }
                // Preserve the old PWA's fast live-analysis behavior, but reject one-frame
                // false decodes. Two matching observations inside a short burst are enough.
                if (stableCount >= 2 && now - candidateFirstSeenMs <= 700L && !busy.getAndSet(true)) {
                    finishResult(value, null, JSONObject().put("mode","native-barcode-only-v1").put("barcodeConfirmations",stableCount).toString())
                } else if (now - candidateFirstSeenMs > 700L) {
                    stableCount = 1
                    candidateFirstSeenMs = now
                    candidateBox = hit.boundingBox
                    val rotated = proxy.imageInfo.rotationDegrees % 180 != 0
                    candidateImageWidth = if (rotated) proxy.height else proxy.width
                    candidateImageHeight = if (rotated) proxy.width else proxy.height
                }
            } else if (System.currentTimeMillis() - candidateFirstSeenMs > 700L) {
                stableCount = 0
                stableUpc = null
                candidateBox = null
                candidateImageWidth = 0
                candidateImageHeight = 0
                runOnUiThread { overlay.setDetectedBarcode(null, 0, 0); overlay.locked = false }
            }
        }.addOnFailureListener { error ->
            runOnUiThread { status.text = "Scanning… · ${error.javaClass.simpleName}" }
        }.addOnCompleteListener { proxy.close() }
    }

    private fun captureNifPhoto() {
        if (busy.getAndSet(true)) return
        status.text = "Capturing NIF label…"
        val file = File(cacheDir, "nif-${System.currentTimeMillis()}.jpg")
        capture?.takePicture(ImageCapture.OutputFileOptions.Builder(file).build(), executor, object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                try {
                    val bmp = BitmapFactory.decodeFile(file.absolutePath) ?: throw IllegalStateException("Could not decode capture")
                    val maxSide = 1600; val scale = min(1.0, maxSide.toDouble() / max(bmp.width, bmp.height).toDouble())
                    val out = if (scale < 1.0) Bitmap.createScaledBitmap(bmp, (bmp.width*scale).toInt(), (bmp.height*scale).toInt(), true) else bmp
                    val bytes = ByteArrayOutputStream(); out.compress(Bitmap.CompressFormat.JPEG, 82, bytes)
                    val payload = JSONObject().put("jpegBase64", Base64.encodeToString(bytes.toByteArray(), Base64.NO_WRAP)).put("capturedAt", Instant.now().toString())
                    file.delete(); runOnUiThread { setResult(RESULT_FIRST_USER, Intent().putExtra("nifCapture", payload.toString())); finish() }
                } catch (e: Exception) { file.delete(); busy.set(false); runOnUiThread { status.text = "Capture failed · ${e.javaClass.simpleName}" } }
            }
            override fun onError(e: ImageCaptureException) { file.delete(); busy.set(false); runOnUiThread { status.text = "Capture failed · ${e.javaClass.simpleName}" } }
        }) ?: run { busy.set(false); status.text = "Camera capture is not ready" }
    }

    private fun sampleDark(proxy: ImageProxy) {
        val b = proxy.planes[0].buffer; val n = b.remaining(); if (n < 100) return
        var sum = 0L; var count = 0; val step = max(1, n / 256); var i = 0
        while (i < n) { sum += (b.get(i).toInt() and 0xff); count++; i += step }
        val mean = sum.toDouble() / count
        if (mean < 55) darkCount++ else if (mean > 85) darkCount = 0
        runOnUiThread { if (flashMode == 0) updateFlash() }
    }

    private fun finishResult(upc: String, price: Double?, diagnostics: String? = null) {
        runOnUiThread { setResult(RESULT_OK, Intent().putExtra("upc", upc).putExtra("torchUsed", torchUsed).apply {
            if (price != null) putExtra("price", price)
            if (diagnostics != null) putExtra("scannerDiagnostics", diagnostics)
        }); finish() }
    }

    override fun onDestroy() {
        autoTorchLatched = false
        camera?.cameraControl?.enableTorch(false)
        barcodeScanner.close(); executor.shutdownNow(); super.onDestroy()
    }
}
