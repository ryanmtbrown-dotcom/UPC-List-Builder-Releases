/**
 * OWNERSHIP:
 * File: app/src/main/java/com/rmtb/upclistbuilder/ScannerOverlayView.kt
 * Owner: Native Scanner Presentation
 * Role: Custom view/renderer
 * Responsibility: Owns scanner overlay drawing and visual framing only.
 * Does not own: Camera lifecycle, barcode detection logic, result routing, persistence, or lookup.
 * Side effects: Canvas/view rendering only.
 * Related code: Scanner lifecycle belongs to ScannerActivity; pure geometry belongs to ScannerPureLogic where applicable.
 */
package com.rmtb.upclistbuilder

import android.content.Context
import android.graphics.*
import android.view.View

class ScannerOverlayView(context: Context) : View(context) {
    private val white = Paint(Paint.ANTI_ALIAS_FLAG).apply { color=Color.WHITE; style=Paint.Style.STROKE; strokeWidth=4f }
    private val green = Paint(Paint.ANTI_ALIAS_FLAG).apply { color=Color.rgb(46,210,130); style=Paint.Style.STROKE; strokeWidth=5f }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { color=Color.WHITE; textSize=28f; typeface=Typeface.DEFAULT_BOLD }
    var locked=false; set(v){field=v;invalidate()}
    private var barcode: Rect? = null
    private var sourceWidth = 0
    private var sourceHeight = 0

    fun setDetectedBarcode(box: Rect?, imageWidth: Int, imageHeight: Int) {
        barcode = box?.let(::Rect); sourceWidth=imageWidth; sourceHeight=imageHeight; invalidate()
    }

    private fun sourceToView(r: Rect): RectF {
        if(sourceWidth<=0||sourceHeight<=0)return RectF()
        // PreviewView FILL_CENTER uses a center crop. Apply the same transform so the
        // detected barcode tracks the camera content instead of a fixed screen box.
        val scale=maxOf(width.toFloat()/sourceWidth,height.toFloat()/sourceHeight)
        val drawnW=sourceWidth*scale; val drawnH=sourceHeight*scale
        val ox=(width-drawnW)/2f; val oy=(height-drawnH)/2f
        return RectF(ox+r.left*scale,oy+r.top*scale,ox+r.right*scale,oy+r.bottom*scale)
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val p=if(locked)green else white
        val b=barcode
        if(b!=null&&sourceWidth>0&&sourceHeight>0){
            val br=sourceToView(b)
            c.drawRoundRect(br,12f,12f,p)
            c.drawText("BARCODE",br.left+12,br.bottom+34,text)
            return
        }
        val w=width.toFloat(); val h=height.toFloat()
        val left=w*.08f; val right=w*.92f; val top=h*.42f; val bottom=h*.58f
        c.drawRoundRect(left,top,right,bottom,24f,24f,p)
        c.drawText("CENTER UPC BARCODE",left+24,bottom+42,text)
    }

}
