/**
 * OWNERSHIP:
 * File: app/src/main/java/com/rmtb/upclistbuilder/ScannerPureLogic.kt
 * Owner: Native Scanner Logic
 * Role: Pure utility
 * Responsibility: Owns scanner calculations/transformations that do not require Android lifecycle or rendering state.
 * Does not own: Camera resources, UI rendering, callbacks, persistence, or lookup.
 * Side effects: None; pure calculations only.
 * Related code: Platform lifecycle belongs to ScannerActivity; overlay rendering belongs to ScannerOverlayView.
 */
package com.rmtb.upclistbuilder

object ScannerPureLogic {
    fun normalizeUpc(raw: String): String = raw.filter { it.isDigit() }

    fun isSupportedUpc(raw: String): Boolean {
        val n = normalizeUpc(raw)
        if (n.length !in setOf(8, 11, 12, 13)) return false
        return when (n.length) {
            8 -> eanChecksumValid(n)
            12 -> upcAChecksumValid(n)
            13 -> eanChecksumValid(n)
            11 -> true
            else -> false
        }
    }

    private fun upcAChecksumValid(n: String): Boolean {
        if (n.length != 12) return false
        val d = n.map { it - '0' }
        val sum = (0 until 11).sumOf { i -> d[i] * if (i % 2 == 0) 3 else 1 }
        return ((10 - sum % 10) % 10) == d[11]
    }

    private fun eanChecksumValid(n: String): Boolean {
        if (n.length !in setOf(8, 13)) return false
        val d = n.map { it - '0' }
        val body = d.dropLast(1)
        val sum = body.reversed().mapIndexed { i, v -> v * if (i % 2 == 0) 3 else 1 }.sum()
        return ((10 - sum % 10) % 10) == d.last()
    }
}
