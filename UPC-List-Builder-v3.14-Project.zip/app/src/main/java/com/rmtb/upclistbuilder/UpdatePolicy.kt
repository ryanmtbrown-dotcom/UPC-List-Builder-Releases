/**
 * OWNERSHIP:
 * File: app/src/main/java/com/rmtb/upclistbuilder/UpdatePolicy.kt
 * Owner: Application Update Policy
 * Role: Pure policy
 * Responsibility: Owns deterministic update-version/eligibility/decision rules consumed by the native update service.
 * Does not own: Network/download/install mechanics, release metadata publication, UI, or persistence.
 * Side effects: None; policy evaluation only.
 * Related code: Mechanics belong to AppUpdateService; web status presentation belongs to application/update-status-service.js.
 */
package com.rmtb.upclistbuilder

import org.json.JSONObject

data class UpdateManifest(val version: String, val apkUrl: String, val sha256: String, val size: Long)

object UpdatePolicy {
    fun isNewerVersion(candidate: String, current: String): Boolean {
        val a = candidate.removePrefix("v").split('.').map { it.toIntOrNull() ?: 0 }
        val b = current.removePrefix("v").split('.').map { it.toIntOrNull() ?: 0 }
        for (i in 0 until maxOf(a.size, b.size)) {
            val av = a.getOrElse(i) { 0 }
            val bv = b.getOrElse(i) { 0 }
            if (av != bv) return av > bv
        }
        return false
    }

    fun parseManifest(body: String): UpdateManifest {
        val json = JSONObject(body)
        val version = json.optString("version").removePrefix("v")
        val apkUrl = json.optString("apk_url")
        val sha256 = json.optString("sha256").lowercase()
        val size = json.optLong("size", -1L)
        require(version.matches(Regex("\\d+(?:\\.\\d+)+"))) { "Update manifest did not include a valid version" }
        require(apkUrl.startsWith("https://")) { "Update manifest did not include a secure APK URL" }
        require(sha256.matches(Regex("[0-9a-f]{64}"))) { "Update manifest checksum is invalid" }
        require(size > 0) { "Update manifest size is invalid" }
        return UpdateManifest(version, apkUrl, sha256, size)
    }
}
