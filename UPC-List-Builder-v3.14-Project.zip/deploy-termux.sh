#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
REPO='ryanmtbrown-dotcom/UPC-List-Builder'
WORKFLOW='build-apk.yml'
EXPECTED="$HOME/upc-list-builder-android"
NETWORK_ATTEMPTS=5
NETWORK_TIMEOUT=30
TERMUX_TMP_ROOT="${TMPDIR:-$PREFIX/tmp}"
mkdir -p "$TERMUX_TMP_ROOT"
ORIGIN_SHA_FILE="$(mktemp "$TERMUX_TMP_ROOT/upc-origin-main.XXXXXX")"
trap 'rm -f "$ORIGIN_SHA_FILE"' EXIT

retry_network() {
  local label="$1"; shift
  local attempt status delay
  for attempt in $(seq 1 "$NETWORK_ATTEMPTS"); do
    echo "$label: attempt $attempt/$NETWORK_ATTEMPTS" >&2
    set +e
    timeout "${NETWORK_TIMEOUT}s" "$@"
    status=$?
    set -e
    if [[ $status -eq 0 ]]; then return 0; fi
    if [[ $attempt -lt $NETWORK_ATTEMPTS ]]; then
      delay=$((attempt * 3))
      echo "$label failed (status $status). Retrying in ${delay}s..." >&2
      sleep "$delay"
    fi
  done
  echo "DEPLOYMENT BLOCKER: $label failed after $NETWORK_ATTEMPTS bounded attempts." >&2
  echo 'The local release commit is preserved. Re-run the SAME deploy command after connectivity returns; do not reinstall the ZIP.' >&2
  return 1
}

gh_retry() { local label="$1"; shift; retry_network "$label" gh "$@"; }

ROOT="$(git rev-parse --show-toplevel 2>/dev/null || true)"
[[ "$ROOT" == "$EXPECTED" ]] || { echo "DEPLOYMENT BLOCKER: run only from the existing $EXPECTED repository." >&2; exit 1; }
cd "$ROOT"
[[ -d .git ]] || { echo 'DEPLOYMENT BLOCKER: .git is missing.' >&2; exit 1; }
REMOTE="$(git remote get-url origin)"
[[ "$REMOTE" == *'ryanmtbrown-dotcom/UPC-List-Builder'* ]] || { echo "DEPLOYMENT BLOCKER: unexpected origin: $REMOTE" >&2; exit 1; }
BRANCH="$(git branch --show-current)"
[[ "$BRANCH" == 'main' ]] || { echo "DEPLOYMENT BLOCKER: expected main branch, found $BRANCH" >&2; exit 1; }
MODE="release"
if [[ "${1:-}" == "--rebuild-head" ]]; then MODE="rebuild-head"; shift; fi
MESSAGE="${1:-UPC List Builder release}"

echo '=== 1/6 VERIFY COMPLETE PROJECT ==='
bash verify-project.sh
echo '=== 2/6 GIT DIFF CHECK ==='
git diff --check
echo '=== 3/6 PREPARE EXACT HEAD ==='
git add -A
if [[ "$MODE" == "release" ]]; then
  if git diff --cached --quiet; then
    # Recovery path: a prior run may already have created the release commit but failed before push.
    HEAD_SHA="$(git rev-parse HEAD)"
    if retry_network 'Check whether current HEAD is already on origin/main' git ls-remote --exit-code origin "refs/heads/main" >"$ORIGIN_SHA_FILE" 2>/dev/null; then
      ORIGIN_SHA="$(awk '{print $1}' "$ORIGIN_SHA_FILE")"
      if [[ "$ORIGIN_SHA" == "$HEAD_SHA" ]]; then
        echo "Release changes are already committed and pushed at $HEAD_SHA; continuing exact-SHA build discovery."
        EVENT='push'
      else
        echo "No uncommitted release changes; current HEAD $HEAD_SHA is not on origin/main $ORIGIN_SHA." >&2
        echo 'This is a preserved commit from an interrupted deployment. Resuming with that exact commit.' >&2
        echo '=== 4/6 PUSH PRESERVED RELEASE COMMIT ==='
        retry_network 'Push preserved release commit' git push origin main
        EVENT='push'
      fi
    else
      echo 'Unable to determine origin/main after bounded network checks.' >&2
      exit 1
    fi
  else
    git commit -m "$MESSAGE"
    HEAD_SHA="$(git rev-parse HEAD)"
    echo "Release commit: $HEAD_SHA"
    echo '=== 4/6 PUSH MAIN ==='
    retry_network 'Push release commit' git push origin main
    EVENT='push'
  fi
else
  if ! git diff --cached --quiet; then
    echo 'DEPLOYMENT BLOCKER: --rebuild-head requires a clean tracked release state.' >&2; exit 1
  fi
  HEAD_SHA="$(git rev-parse HEAD)"
  echo "Diagnostic rebuild HEAD: $HEAD_SHA"
  echo '=== 4/6 VERIFY HEAD IS ALREADY ON origin/main ==='
  retry_network 'Fetch origin/main' git fetch origin main
  ORIGIN_SHA="$(git rev-parse origin/main)"
  [[ "$ORIGIN_SHA" == "$HEAD_SHA" ]] || { echo "DEPLOYMENT BLOCKER: local HEAD $HEAD_SHA does not equal origin/main $ORIGIN_SHA" >&2; exit 1; }
  BEFORE_RUN="$(gh_retry 'Read current workflow run' run list --repo "$REPO" --workflow "$WORKFLOW" --branch main --limit 1 --json databaseId --jq '.[0].databaseId // 0')"
  echo "Dispatching workflow for existing HEAD $HEAD_SHA"
  gh_retry 'Dispatch rebuild workflow' workflow run "$WORKFLOW" --repo "$REPO" --ref main
  EVENT='workflow_dispatch'
fi

HEAD_SHA="${HEAD_SHA:-$(git rev-parse HEAD)}"
retry_network 'Confirm origin/main exact SHA' git ls-remote origin refs/heads/main >"$ORIGIN_SHA_FILE"
ORIGIN_SHA="$(awk '{print $1}' "$ORIGIN_SHA_FILE")"
[[ "$ORIGIN_SHA" == "$HEAD_SHA" ]] || { echo "DEPLOYMENT BLOCKER: origin/main $ORIGIN_SHA does not match HEAD $HEAD_SHA" >&2; exit 1; }

echo '=== 5/6 FIND EXACT BUILD ==='
RUN_ID=''
for attempt in $(seq 1 30); do
  echo "GitHub registration check $attempt/30 for $HEAD_SHA ($EVENT)"
  echo "Current GitHub Actions runs:"
  set +e
  timeout "${NETWORK_TIMEOUT}s" gh run list --repo "$REPO" --workflow "$WORKFLOW" --branch main --limit 10 || true
  set +e
  if [[ "$MODE" == "release" ]]; then
    RUN_ID="$(timeout "${NETWORK_TIMEOUT}s" gh run list --repo "$REPO" --workflow "$WORKFLOW" --branch main --event push --limit 30 --json databaseId,headSha --jq ".[] | select(.headSha==\"$HEAD_SHA\") | .databaseId" 2>/dev/null | head -n1)"
  else
    RUN_ID="$(timeout "${NETWORK_TIMEOUT}s" gh run list --repo "$REPO" --workflow "$WORKFLOW" --branch main --event workflow_dispatch --limit 30 --json databaseId,headSha --jq ".[] | select(.headSha==\"$HEAD_SHA\" and .databaseId > $BEFORE_RUN) | .databaseId" 2>/dev/null | head -n1)"
  fi
  status=$?
  set -e
  [[ -n "$RUN_ID" ]] && break
  [[ $status -ne 0 ]] && echo "GitHub registration query temporarily failed (status $status); continuing bounded discovery." >&2
  sleep 2
done
[[ -n "$RUN_ID" ]] || { echo "DEPLOYMENT BLOCKER: GitHub did not register the exact $EVENT build for $HEAD_SHA within the bounded discovery window." >&2; exit 1; }
echo "Exact build: $RUN_ID · commit $HEAD_SHA"

echo '=== 6/6 WATCH EXACT BUILD LIVE ==='
while true; do
  set +e
  gh run watch "$RUN_ID" --repo "$REPO" --exit-status
  WATCH_STATUS=$?
  set -e
  [[ $WATCH_STATUS -eq 0 ]] && break
  echo "Live watch exited with status $WATCH_STATUS. Checking authoritative run state before declaring failure..." >&2
  set +e
  RUN_STATE="$(timeout "${NETWORK_TIMEOUT}s" gh run view "$RUN_ID" --repo "$REPO" --json status,conclusion --jq '.status+"|"+(.conclusion//"")' 2>/dev/null)"
  STATE_STATUS=$?
  set -e
  if [[ $STATE_STATUS -ne 0 || -z "$RUN_STATE" ]]; then
    echo 'GitHub status check was unreachable; waiting 5 seconds and reattaching to the same exact run.' >&2
    sleep 5
    continue
  fi
  case "$RUN_STATE" in
    completed\|success) break ;;
    completed\|*)
      LOG="/storage/emulated/0/Download/UPC_List_Builder_FAILED_BUILD_${RUN_ID}.log"
      echo "BUILD FAILED ($RUN_STATE). Preserving complete failed log at $LOG"
      set +e
      retry_network "Preserve failed build log" gh run view "$RUN_ID" --repo "$REPO" --log-failed | tee "$LOG"
      LOG_STATUS=${PIPESTATUS[0]}
      set -e
      [[ $LOG_STATUS -eq 0 ]] || echo "WARNING: build failure is authoritative, but failed-log retrieval exhausted bounded network retries. Retry the same deployment command to retrieve the exact run log." >&2
      exit 1
      ;;
    *) echo "Exact run is still $RUN_STATE; reattaching in 5 seconds." >&2; sleep 5 ;;
  esac
done

echo "DEPLOYMENT PASS: exact GitHub build $RUN_ID succeeded for $HEAD_SHA"
