#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
ZIP="${1:-}"
EXPECTED="$HOME/upc-list-builder-android"
[[ -n "$ZIP" ]] || { echo "Usage: bash ./install-release-termux.sh /absolute/path/release.zip" >&2; exit 2; }
[[ -f "$ZIP" ]] || { echo "INSTALL BLOCKER: release ZIP not found: $ZIP" >&2; exit 1; }
cd "$EXPECTED"
[[ -d .git ]] || { echo "INSTALL BLOCKER: expected Git repository at $EXPECTED" >&2; exit 1; }
REMOTE="$(git remote get-url origin)"
[[ "$REMOTE" == *'ryanmtbrown-dotcom/UPC-List-Builder'* ]] || { echo "INSTALL BLOCKER: unexpected origin: $REMOTE" >&2; exit 1; }
BRANCH="$(git branch --show-current)"
[[ "$BRANCH" == 'main' ]] || { echo "INSTALL BLOCKER: expected main branch, found $BRANCH" >&2; exit 1; }

echo '=== CLEAN OLD PROJECT TREE (PRESERVE .git) ==='
find . -mindepth 1 -maxdepth 1 ! -name '.git' -exec rm -rf -- {} +
echo '=== EXTRACT RELEASE ==='
unzip -oq "$ZIP" -d "$EXPECTED"
chmod +x verify-project.sh deploy-termux.sh package-release.sh install-release-termux.sh
echo '=== VERIFY INSTALLED RELEASE ==='
bash ./verify-project.sh
echo 'RELEASE INSTALL PASS'
