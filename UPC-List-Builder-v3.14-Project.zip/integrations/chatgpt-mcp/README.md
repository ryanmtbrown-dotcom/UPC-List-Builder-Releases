# Optional ChatGPT → ACE New DSD Items bridge

**Status:** The Cloudflare service has completed real ChatGPT OAuth, pairing, and invoice staging tests. The redesigned Android/importer and conditional WWD/PO rules remain under draft PR #77; the live Worker must not be assumed to contain unverified branch changes. Public Android updater publication is still gated.

## Ownership and trust boundaries

- This directory owns the external MCP HTTP transport, OAuth verification, one-time pairing, and durable per-user staging queue.
- `dsd/dsd-chatgpt-import.js` owns user-controlled pairing, pending listing, Import into DSD and Reject Pending. It creates no separate invoice/item review fields; `dsd/dsd-workspace-controller.js` owns the only editable DSD list.
- `ace-dsd.js` and `dsd/dsd-workspace-controller.js` continue to own DSD validation, pricing, SKU generation, persistence handoff, and export. No MCP tool writes the Android IndexedDB store directly.
- `ChatGPTConnectionVault.kt` encrypts the per-installation device token with a different Android Keystore alias from AceNet. Browser/PWA mode keeps the token in memory only. No ChatGPT password, OpenAI API key, OAuth access token, or server credential belongs in the APK, JavaScript, source repository, or localStorage.

An invoice PDF stays in the user's ChatGPT workflow. The server receives **structured product fields only**, not uploaded PDFs. The model's extraction is untrusted; every item remains reviewable and DSD validation is authoritative. Missing costs, retail, departments, and UPCs must not be made up. For optional Cloudflare invoice quantity evidence, `orderedQuantity` is NOT DSD `orderMultiple`: absent order multiples normalize to 1 and `caseCost` must be the verified single-unit cost. `eachCost` and `lineTotal` can be provided for reconciliation, with an ambiguous cost basis rejected. A missing item department inherits the invoice department, a populated serial number forces 46, and recognizably ammunition-like items default to 46 unless another item department is supplied for review. One invoice may mix 46, 72, and other departments. Zero-dollar promotional displays are excluded from staged items, not from the source invoice or reconciliation report. UPC research must verify the exact product variant (model, size, color), not merely a broad listing or manufacturer number. Pricing algorithms and manual override stay unchanged.

## Recommended no-cost hosting: Cloudflare Workers + D1

The recommended deployment for this project is now the Cloudflare Workers free-tier implementation under [`cloudflare/`](cloudflare/README.md). It uses a free `workers.dev` HTTPS address, Cloudflare D1 for separate user invoice batches, Workers KV for OAuth tokens, and GitHub OAuth sign-in.

**Use the Cloudflare walkthrough first.** The older Node/SQLite server described below is an alternative implementation, not a prerequisite or a deployed public service. Both implementations preserve the same mobile pairing and pending-import API contract. Neither is deployed merely because the source exists in GitHub.

## Alternative Node service — not required for Cloudflare

## Provision a real service (host/operator)

1. Provision a durable HTTPS Node 24 host with a persistent, private data volume mounted at `/data`. Use a reverse proxy that preserves the original `Host` header; enable rate limiting and TLS. Do not expose the raw HTTP container publicly.
2. Configure an existing OAuth 2.1 identity provider (for example Auth0), with authorization-code PKCE, HTTPS discovery metadata and JWKS, dynamic client registration or a static client recognized by ChatGPT, and the scope `dsd:write`. Configure the resource/audience to equal your exact public `https://your-domain/mcp` URL. Each user must authenticate independently to the provider; **MCP does not log users in using their ChatGPT password**.
3. Populate environment variables from the example file in your host's private secret/config mechanism (not source). Required: `MCP_PUBLIC_URL`, `OAUTH_ISSUER`, `OAUTH_JWKS_URL`. Set `MCP_DB_PATH` to durable storage. Set `MCP_ALLOWED_ORIGINS` only for additional trusted browser/PWA origins; `https://appassets.androidplatform.net` is included for the native packaged app.
4. In this directory run `npm install`, `npm test`, and `npm start`. For containers, build the Dockerfile and mount the durable volume. Verify `GET /health` and `GET /.well-known/oauth-protected-resource` over HTTPS. No production login/hosting secrets should be logged.
5. In ChatGPT on the web, add the custom MCP server URL `https://your-domain/mcp` as a plugin; select OAuth and complete its authorization. Register the exact ChatGPT redirect URI shown in the plugin setup UI with your identity provider. Plugin availability may vary by plan/workspace. ChatGPT is the MCP client, not the provider of our device identity.
6. In ChatGPT, call `create_dsd_pairing_code`. In **UPC List Builder → ACE New DSD Items → ChatGPT Invoice Import**, opt in, enter the server **origin** (`https://your-domain`, no path), paste the 24-character code, and choose **Pair This Device**. Codes expire in ten minutes and can be used once.
7. Ask ChatGPT to extract a PDF supplier invoice, explicitly identify uncertainties, and use `submit_dsd_import`. On the device choose **Check Pending Imports** and **Import into DSD** or **Reject Pending**. Import creates a normal editable DSD Work Session. The pending receipt is acknowledged only after the local save succeeds; use the existing DSD Edit Invoice, Edit Item, Delete and Export controls for corrections.

Users connect with their own OAuth identity and distinct per-installation tokens. The service keys pending batches by authenticated `sub`; it cannot select another user's items. A device can be revoked through **Disconnect & Revoke**. Merely disabling the optional feature suppresses network operations and keeps saved DSD sessions.

## Safety and operations

- The service enforces issuer, audience, expiry, JWT signature, and `dsd:write` scope on MCP requests using remote JWKS; every device API call uses an independently random, hashed bearer token. Never enable no-auth MCP write tools in production.
- Pairing codes have 144 random bits, are hashed at rest, expire after 10 minutes, are one-use, and the server applies an IP rate bound. Deploy an additional network-edge rate limiter; in-process limits are not cluster-wide.
- Service is intentionally single-instance SQLite/WAL. Do not deploy multiple replicas against an independent filesystem copy. Back up and encrypt the volume. Restrict DB access to the service account. Built-in lazy expiry removes pending batches after 90 days, acknowledged imports after 30 days and device pairings after 180 days; retention runs during ordinary operations, so an idle server does not purge until it is accessed. Define a privacy policy, backups and a deletion procedure before opening to additional users.
- All transport endpoints return no-store headers. No invoice is automatically added to a Work Session merely by staging; the user explicitly chooses Import into DSD. Remote acknowledgement is idempotent; local saved sessions retain the batch ID so a failed ack cannot create duplicate local imports.
- Always inspect invoice unit semantics (case vs each), products that lack an authentic UPC, and pricing. Do not confuse supplier item numbers with manufacturer numbers. Use the application's existing manual pricing rules; never put a blank extracted cost into the `$0` default.
- Invoice interpretation policy in the Cloudflare `src/validate.mjs` owner: identify source-labeled manufacturers and document numbers; WWD alone may be primary, but WWD is secondary when a distinct primary manufacturer is known. DSD number priority is confirmed primary manufacturer invoice; otherwise primary manufacturer purchase order formatted `PO` + numeric ID; otherwise explicit `00000` placeholder. A buyer PO or WWD secondary number must not substitute. Ask only when conflicting/ambiguous evidence requires a decision. The full PDF never enters the Cloudflare queue.

- No extra OpenAI API call is made by this MCP service. ChatGPT capabilities/allowance, OAuth-provider hosting, and server costs are separate.
- A live Cloudflare Worker and ChatGPT plugin successfully authenticated, paired with v2.97 Android, and received real test invoice batches. The replacement interface, pending-batch rejection, primary invoice/PO fallback, and deployment of this draft revision still require exact-head verification and new physical-device tests.

## MCP tools

- `create_dsd_pairing_code` — authenticated: returns a short-lived code for one's own device.
- `submit_dsd_import` — authenticated: stages structured invoice rows, validates limits, returns a batch ID, does **not** edit the mobile DB.
- `get_dsd_import_status` — authenticated: reads one own batch's pending/imported status.

No arbitrary query, file access, exports, admin access, or database mutation tools are exposed.
