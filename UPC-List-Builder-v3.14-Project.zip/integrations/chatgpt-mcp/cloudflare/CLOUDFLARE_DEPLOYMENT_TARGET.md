# Cloudflare development deployment target

This branch is the Cloudflare Workers-only deployment source for the optional ChatGPT → ACE New DSD Items staging server.

- Root directory: `/integrations/chatgpt-mcp/cloudflare`
- Worker: `upc-dsd-chatgpt`
- Free HTTPS target: `https://upc-dsd-chatgpt.ryan-m-t-brown.workers.dev`
- Production UPC List Builder Android source branch: **not this branch**. The Android public updater remains `main`-only.
- OAuth runtime secrets have to be configured in Cloudflare after a Worker deployment. Never store client secrets, passwords, or bearer tokens here.
- Until end-to-end authentication, mobile device pairing, and invoice import checks succeed, this is an unverified integration preview and should not be offered to end users.

This source-only file exists to identify the intended branch/root and trigger a fresh GitHub push for Cloudflare Builds following correction of the branch and root directory settings.
