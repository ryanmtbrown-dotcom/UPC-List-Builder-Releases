# DSD invoice review and approval contract

Status: implemented candidate; deployment and hosted-client verification are separate requirements.

## Owners

- `tools.mjs`: MCP schemas, descriptions, visibility, server initialization instructions and composition.
- `review-policy.mjs`: pure invoice normalization, department suggestions and research-report validation.
- `review-store.mjs`: durable account-bound reviews, rendered callbacks, immutable approval choices, expiration and receipt recovery.
- `review-ui.mjs`: item/source presentation, department/markup choices, uncertainty acknowledgment and the Approve & send interaction.
- `workflow-errors.mjs`: safe, model-readable blocked-step feedback.
- `queue.mjs`: pending batches, payload idempotency, pairing and device delivery. Android remains final pricing, validation, SKU and export authority.

## Required flow

1. Investigate exact item identity and variant with available research tools. Do not claim inaccessible pages were inspected. Record every retained merchandise item exactly once in `researchEvidence`: zero-based indexes in merchandise order after excluding free display rows, query, product name, status, source URLs and notes. Group variants only when the notes and sources support those exact variants. Suggestions are recommendations requiring review, never silent assignments.
2. Call `review_dsd_import`. It normalizes source facts, validates complete evidence coverage, and creates a review owned by the authenticated GitHub account. Reviews expire after 30 minutes. Research reports are limited to 64 KiB. Unknown facts remain blank. Research data never becomes Android merchandise fields.
3. The registered MCP Apps component initializes the host bridge, renders items, UPCs, manufacturer numbers, normalized costs/order multiples, individual pricing overrides, source links, suggestions and warnings, then calls app-only `record_dsd_review_rendered`. The component approval proof is in result `_meta`, hidden from model content, stored only as a hash, bound to account and review, and is not an OAuth credential.
4. The user chooses invoice/item departments and invoice default markup/pricing method. Unresolved/unavailable research and blank departments require separate explicit acknowledgments. A serial number keeps department 46. Correcting identity, quantity/cost, UPC or other product facts requires a new review.
5. Only the component Approve & send action calls app-only `submit_dsd_import` with review ID, proof and allowed choices. Raw invoice submissions and completion flags do not satisfy the gate. The server verifies account, proof, expiry, rendered callback, research uncertainty acknowledgment and selections before the queue receives anything. The first approval locks the choices. Same-choice retries return the same queue batch; different choices cannot reuse that approval.
6. Normalized pending data reaches the existing Android DSD editor through its existing paired-device API. A server submission receipt means pending, not imported or exported.

## Recovery and trust limits

- Recoverable business failures return MCP `isError: true`, plain-language `content` and structured `code`, `missingSteps`, `nextTool`, `retrySameRequest` and `submitted`. The model must repair the named steps and must not claim success without a batch receipt.
- If a queue write or receipt confirmation is uncertain, `submitted` is null. Approved choices remain locked and exact retries safely resume payload-idempotent staging. Neither server nor UI falsely says nothing was submitted in this case. UI requests time out after 15 seconds instead of spinning indefinitely.
- The recorded research is explicitly **assistant-reported**. Requiring names, queries and URLs cannot independently prove that external search happened or that a page supports a claim. This deployment does not add a search provider or claim server-owned search execution. Independent research proof requires a separately configured server-owned lookup/search integration.
- A rendered callback proves a component-origin protocol event under a compatible host, not that a person read every item. The approval button is the normal host-mediated interaction; `_meta` and app-only visibility do not replace OAuth/account authorization and are not cryptographic proof of human attention. An authenticated custom client controlling its own account can emulate the component protocol.
- A non-UI host can inspect the model-visible review but cannot stage an invoice using completion booleans. It must use a compatible review client. The server cannot reject ordinary chat text or require a tool invocation when the assistant makes no request.
- Hosted UI compatibility, CSP and mobile layout require a live client test. DOM/bridge tests and a Worker build do not establish hosted rendering, production deployment or physical Android behavior.

## Deployment

1. Verify the candidate's Cloudflare tests, syntax checks, Worker dry-run build and maintained project checks. Preserve the current production OAuth fixes when promoting the candidate.
2. Apply `migrations/0002_review_gate.sql` to the existing D1 database before activating the Worker. This creates only the new review table and index; it does not modify existing batches/devices or Android storage. Missing review storage fails closed with `REVIEW_STORAGE_UNAVAILABLE`.
3. Deploy the tested Worker source through the existing Cloudflare deployment branch/configuration. This does not publish an Android APK or updater change.
4. Read back `/health`: candidate code identifies `workflowVersion: "2.0.0"` and `reviewRequired: true`; a basic status response alone is insufficient to identify the candidate. Health alone does not prove D1 migration, OAuth or hosted UI.
5. Verify the connected plugin discovers `review_dsd_import` and its v2 HTML resource. The model-facing workflow uses pairing, review and status tools; rendered callback and submission are app-only. Perform a live review, explicit approval, pending delivery and device import test before declaring end-to-end completion. Refresh/reinstall discovery through the controls actually available in the client; do not assume a Refresh button exists.
6. Full Android PR #79 publication remains separate and must follow `DEPLOYMENT_CONTRACT.md`, exact-head CI and physical-device requirements. Do not move the public updater merely to deploy this server gate.
