CREATE TABLE IF NOT EXISTS dsd_pairings (
  code_hash TEXT PRIMARY KEY,
  owner TEXT NOT NULL,
  expires INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS dsd_devices (
  token_hash TEXT PRIMARY KEY,
  owner TEXT NOT NULL,
  created INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS dsd_batches (
  id TEXT PRIMARY KEY,
  owner TEXT NOT NULL,
  digest TEXT NOT NULL,
  payload TEXT NOT NULL,
  state TEXT NOT NULL CHECK(state IN ('pending','imported')),
  created INTEGER NOT NULL,
  updated INTEGER NOT NULL,
  UNIQUE(owner,digest)
);
CREATE INDEX IF NOT EXISTS dsd_batches_owner_state ON dsd_batches(owner,state,created);
CREATE INDEX IF NOT EXISTS dsd_pairings_expires ON dsd_pairings(expires);
