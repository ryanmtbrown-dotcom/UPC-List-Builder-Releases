-- Independent AI planogram import staging. Existing DSD invoices/tokens are untouched.
CREATE TABLE IF NOT EXISTS planogram_sessions (
 id TEXT PRIMARY KEY,
 owner TEXT NOT NULL,
 header TEXT NOT NULL,
 created INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS planogram_sessions_owner ON planogram_sessions(owner,created);
CREATE TABLE IF NOT EXISTS planogram_chunks (
 session_id TEXT NOT NULL,
 owner TEXT NOT NULL,
 chunk_index INTEGER NOT NULL,
 digest TEXT NOT NULL,
 payload TEXT NOT NULL,
 created INTEGER NOT NULL,
 PRIMARY KEY(session_id,chunk_index)
);
CREATE TABLE IF NOT EXISTS planogram_batches (
 id TEXT PRIMARY KEY,
 owner TEXT NOT NULL,
 digest TEXT NOT NULL,
 payload TEXT NOT NULL,
 state TEXT NOT NULL CHECK (state IN ('pending','imported')),
 created INTEGER NOT NULL,
 updated INTEGER NOT NULL,
 UNIQUE(owner,digest)
);
CREATE INDEX IF NOT EXISTS planogram_batches_owner_state ON planogram_batches(owner,state,created);
