CREATE TABLE IF NOT EXISTS dsd_reviews (
 id TEXT PRIMARY KEY,
 owner TEXT NOT NULL,
 proof_hash TEXT NOT NULL,
 payload TEXT NOT NULL,
 state TEXT NOT NULL CHECK(state IN ('review','processing','submitted')),
 expires INTEGER NOT NULL,
 rendered_at INTEGER,
 decision_digest TEXT,
 approved_choices TEXT,
 receipt TEXT
);
CREATE INDEX IF NOT EXISTS dsd_reviews_owner_expires ON dsd_reviews(owner,expires);
