/**
 * OWNERSHIP: Cloudflare OAuth consent and GitHub upstream sign-in.
 * Does not own: MCP tools, per-user invoice data, device tokens, or ChatGPT passwords.
 * Side effects: Worker OAuth KV helpers and GitHub OAuth HTTPS calls only.
 * User identity is the immutable GitHub numeric account ID; no GitHub access token is persisted.
 */
const escape=s=>String(s??'').replace(/[&<>"']/g,c=>'&#'+c.charCodeAt(0)+';');
function consentPage(details,handle){
 const scopes=details.scope.map(scope=>'<label><input type="checkbox" name="scope" value="'+escape(scope)+'" checked> '+escape(scope)+'</label>').join('');
 return '<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width">'
  +'<title>Connect UPC List Builder</title><style>body{font:16px system-ui;max-width:620px;margin:40px auto;padding:16px;line-height:1.5}button{margin:12px;padding:12px 20px}label{display:block;margin:12px}small{color:#555}</style>'
  +'<h1>Connect UPC List Builder</h1><p>Allow <strong>'+escape(details.clientName)+'</strong> to stage structured supplier invoices or Ace planograms for review in your own UPC List Builder, limited to permissions checked below?</p>'
  +'<p>Requested by: '+(details.clientDomain?escape(details.clientDomain):'an unverified client identity')
  +'. Authentication results return to <strong>'+escape(details.redirectHost)+'</strong>.</p>'
  +(details.redirectIsLoopback?'<p><strong>This redirects to a program on your computer.</strong></p>':'')
  +'<p>Permission:</p><form method="POST" action="/authorize"><input type="hidden" name="handle" value="'+escape(handle)+'">'
  +scopes+'<p><button type="submit" name="decision" value="approve">Continue with GitHub</button><button type="submit" name="decision" value="deny">Cancel</button></p></form>'
  +'<small>GitHub only confirms which account you own. UPC List Builder cannot read your GitHub repositories or ChatGPT password.</small>';
}
function response(text,status=400,headers={}){
 return new Response(text,{status,headers:{'Content-Type':'text/plain; charset=utf-8','Cache-Control':'no-store',...headers}});
}
async function fromGitHub(request,env,approved){
 const {state,headers}=await env.OAUTH_PROVIDER.beginUpstream(approved.request,{headers:approved.headers});
 const github=new URL('https://github.com/login/oauth/authorize');
 github.searchParams.set('client_id',env.GITHUB_CLIENT_ID);
 github.searchParams.set('redirect_uri',new URL('/callback',request.url).href);
 github.searchParams.set('scope','read:user');
 github.searchParams.set('state',state);
 headers.set('Location',github.href);
 return new Response(null,{status:302,headers});
}
/**
 * Translate only known Cloudflare OAuth error descriptions into fixed diagnostic
 * codes. OAuth states, binding cookies, authorization codes and upstream error
 * messages must never be logged or reflected to the browser.
 */
function safeOAuthFailure(error,stage){
 if(error?.name!=='AuthorizationError')return 'server-error';
 // Distinguish public, fixed failure categories without exposing browser cookies,
 // transaction handles, OAuth request details, or provider error descriptions.
 if(stage==='consent-approval'){
  switch(error.description){
   case 'Missing transaction handle': return 'missing-consent-handle';
   case 'This authorization was not started in this browser; start again': return 'missing-consent-cookie';
   case 'This authorization belongs to a different browser session; start again': return 'consent-cookie-mismatch';
   case 'This authorization expired or was already used; start again': return 'consent-expired-or-used';
   case 'Approved scopes must be ones this server supports': return 'unsupported-consent-scope';
   default: return 'oauth-request';
  }
 }
 if(stage!=='upstream-callback')return 'oauth-request';
 switch(error.description){
  case 'Missing state parameter': return 'missing-state';
  case 'This authorization was not started in this browser; start again': return 'missing-browser-cookie';
  case 'This authorization belongs to a different browser session; start again': return 'cookie-mismatch';
  case 'This authorization expired or was already used; start again': return 'expired-or-reused-state';
  default: return 'oauth-request';
 }
}
export async function authRoute(request,env){
 const path=new URL(request.url).pathname;
 const oauth=env.OAUTH_PROVIDER;
 if(!env.GITHUB_CLIENT_ID||!env.GITHUB_CLIENT_SECRET)return response('GitHub OAuth app is not configured.',503);
 let stage='authorization-route';
 try{
  if(path==='/authorize'&&request.method==='GET'){
   stage='consent-page';
   const parsed=await oauth.parseAuthRequest(request),details=await oauth.describeConsent(parsed);
   const consent=await oauth.beginConsent(parsed);
   consent.headers.set('Content-Type','text/html; charset=utf-8');
   return new Response(consentPage(details,consent.handle),{headers:consent.headers});
  }
  if(path==='/authorize'&&request.method==='POST'){
   stage='consent-approval';
   const form=await request.formData(),handle=String(form.get('handle')||'');
   if(form.get('decision')!=='approve'){
    const denied=await oauth.denyConsent(request,handle);
    return new Response(null,{status:302,headers:denied.headers});
   }
   const approved=await oauth.approveConsent(request,handle,{scope:form.getAll('scope').map(String)});
   if(!approved.request.scope.some(s=>s==='dsd:write'||s==='planogram:write'))return response('A staging permission was not granted.');
   stage='github-redirect';
   return await fromGitHub(request,env,approved);
  }
  if(path==='/callback'&&request.method==='GET'){
   stage='upstream-callback';
   const result=await oauth.finishUpstream(request),params=new URL(request.url).searchParams;
   if(params.has('error'))return response('GitHub sign-in was cancelled; start again from ChatGPT.');
   const code=params.get('code')||'';
   if(!code)return response('GitHub sign-in did not return a code.');
   stage='github-token-exchange';
   const tokenResponse=await fetch('https://github.com/login/oauth/access_token',{
    method:'POST',headers:{'Accept':'application/json','Content-Type':'application/json','User-Agent':'UPC-List-Builder-MCP'},
    body:JSON.stringify({client_id:env.GITHUB_CLIENT_ID,client_secret:env.GITHUB_CLIENT_SECRET,code,
      redirect_uri:new URL('/callback',request.url).href})
   });
   if(!tokenResponse.ok)return response('GitHub token request failed.',502);
   const token=await tokenResponse.json();
   if(!token.access_token)return response('GitHub authorization was not completed.',401);
   stage='github-identity-lookup';
   const userResponse=await fetch('https://api.github.com/user',{
    headers:{'Authorization':'Bearer '+token.access_token,'Accept':'application/vnd.github+json','User-Agent':'UPC-List-Builder-MCP'}
   });
   if(!userResponse.ok)return response('GitHub account verification failed.',502);
   const user=await userResponse.json();
   if(!Number.isSafeInteger(user.id)||user.id<=0)return response('GitHub returned an invalid account identifier.',502);
   const subject='github:'+user.id;
   stage='chatgpt-authorization';
   const completed=await oauth.completeAuthorization({
    request:result.request,userId:String(user.id),metadata:{label:String(user.login||'GitHub user')},
    scope:result.request.scope,props:{subject}
   });
   result.headers.set('Location',completed.redirectTo);
   return new Response(null,{status:302,headers:result.headers});
  }
  return response('Not found.',404);
 }catch(error){
  if(error?.redirectTo)return Response.redirect(error.redirectTo,302);
  // Report only a fixed stage and coarse category. Never log errors, URLs, cookies,
  // request data, OAuth codes or tokens: upstream messages may contain secrets.
  const category=safeOAuthFailure(error,stage);
  console.error('dsd.oauth.authorization_failed', {stage,category});
  return response('Authorization failed at '+stage+' ('+category+'). Restart the connection from ChatGPT.',400);
 }
}
