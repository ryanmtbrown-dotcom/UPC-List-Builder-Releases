/**
 * OWNERSHIP: Hosted Cloudflare Workers MCP tool transport, OAuth boundary and authenticated device API.
 * Does not own: DSD pricing, UPC identity rules, Android Keystore, local IndexedDB or GitHub credential persistence.
 * Side effects: OAuth-protected MCP requests and D1 queue calls through focused owners.
 */
import OAuthProvider from '@cloudflare/workers-oauth-provider';
import { createMcpHandler } from 'agents/mcp/server';
import { createQueue } from './queue.mjs';
import { createPlanogramQueue } from './planogram-queue.mjs';
import { makeMcp } from './tools.mjs';
import { authRoute } from './auth.mjs';

const json=(value,status=200,headers={})=>new Response(JSON.stringify(value),
 {status,headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff',...headers}});
const mcpApi={
 fetch(request,env,ctx){
  const subject=ctx.props?.subject;
  const permissions=Array.isArray(ctx.auth?.scope)?ctx.auth.scope:typeof ctx.auth?.scope==='string'?ctx.auth.scope.split(/\s+/):[];
  if(typeof subject!=='string'||!/^github:\d+$/.test(subject)||!permissions.some(s=>s==='dsd:write'||s==='planogram:write'))
   return json({error:'Forbidden'},403);
  const handler=createMcpHandler(()=>makeMcp(env,subject,permissions),{
   responseMode:'json',corsOptions:false
  });
  return handler(request,env,ctx);
 }
};
async function payloadJson(request){
 if(Number(request.headers.get('content-length')||0)>262144)throw Error('Payload too large.');
 const reader=request.body?.getReader();if(!reader)return{};
 const fragments=[];let bytes=0;
 while(true){
  const {done,value}=await reader.read();if(done)break;
  bytes+=value.byteLength;
  if(bytes>262144){await reader.cancel();throw Error('Payload too large.');}
  fragments.push(value);
 }
 const joined=new Uint8Array(bytes);let index=0;
 for(const x of fragments){joined.set(x,index);index+=x.byteLength;}
 return JSON.parse(new TextDecoder().decode(joined));
}
function cors(request,env){
 const origin=request.headers.get('Origin');
 const extras=String(env.ALLOWED_BROWSER_ORIGINS||'').split(',').map(s=>s.trim()).filter(Boolean);
 const allowed=new Set(['https://appassets.androidplatform.net',...extras]);
 if(origin&&!allowed.has(origin))return{allowed:false,headers:{}};
 return{allowed:true,headers:origin?{'Access-Control-Allow-Origin':origin,
  'Access-Control-Allow-Methods':'GET,POST,DELETE,OPTIONS',
  'Access-Control-Allow-Headers':'Content-Type,Authorization','Vary':'Origin'}:{}};
}
async function device(request,env){
 const policy=cors(request,env);
 if(!policy.allowed)return json({error:'Origin not allowed'},403);
 const path=new URL(request.url).pathname;
 if(request.method==='OPTIONS')return new Response(null,{status:204,headers:{...policy.headers,'Cache-Control':'no-store'}});
 const queue=createQueue(env.DB);
 const send=(value,status=200)=>json(value,status,policy.headers);
 try{
  if(path==='/api/v1/device/claim'&&request.method==='POST'){
   const body=await payloadJson(request);
   const result=await queue.claim(body.code);
   return result?send(result):send({error:'Pairing code is invalid, expired or already claimed'},400);
  }
  const authorization=request.headers.get('Authorization')||'';
  const token=authorization.startsWith('Bearer ')?authorization.slice(7):'';
  const owner=await queue.deviceOwner(token);
  if(!owner)return send({error:'This installation is not connected'},401);
  if(path==='/api/v1/device'&&request.method==='DELETE'){
   await queue.revoke(token);return send({disconnected:true});
  }
  if(path==='/api/v1/planograms'&&request.method==='GET')
   return send({batches:await createPlanogramQueue(env.DB).list(owner)});
  const planogramMatch=path.match(/^\/api\/v1\/planograms\/([0-9a-f-]{36})(\/ack)?$/i);
  if(planogramMatch){
   const pq=createPlanogramQueue(env.DB);
   if(request.method==='GET'&&!planogramMatch[2]){
    const batch=await pq.get(owner,planogramMatch[1]);
    return batch?send(batch):send({error:'Batch not found'},404);
   }
   if(request.method==='POST'&&planogramMatch[2]){
    const ack=await pq.acknowledge(owner,planogramMatch[1]);
    return ack?send({imported:true}):send({error:'Batch not found'},404);
   }
   if(request.method==='DELETE'&&!planogramMatch[2]){
    const rejected=await pq.reject(owner,planogramMatch[1]);
    return rejected?send({rejected:true}):send({error:'Pending batch not found'},404);
   }
  }
  if(path==='/api/v1/batches'&&request.method==='GET')
   return send({batches:await queue.list(owner)});
  const match=path.match(/^\/api\/v1\/batches\/([0-9a-f-]{36})(\/ack)?$/i);
  if(match){
   if(request.method==='GET'&&!match[2]){
    const batch=await queue.get(owner,match[1]);
    return batch?send(batch):send({error:'Batch not found'},404);
   }
   if(request.method==='POST'&&match[2]){
    const done=await queue.acknowledge(owner,match[1]);
    return done?send({imported:true}):send({error:'Batch not found'},404);
   }
   if(request.method==='DELETE'&&!match[2]){
    const removed=await queue.reject(owner,match[1]);
    return removed?send({rejected:true}):send({error:'Pending batch not found'},404);
   }
  }
  return send({error:'Not found'},404);
 }catch(e){return send({error:e?.message==='Payload too large.'?'Payload too large.':'Invalid request or unavailable storage'},400);}
}
const defaultHandler={
 async fetch(request,env){
  const path=new URL(request.url).pathname;
  if(path==='/health'&&request.method==='GET')return json({status:'ok',workflowVersion:'2.0.0',reviewRequired:true});
  if(path.startsWith('/api/v1/'))return device(request,env);
  if(path==='/authorize'||path==='/callback')return authRoute(request,env);
  return json({error:'Not found'},404);
 }
};
export default new OAuthProvider({
 apiRoute:'/mcp',apiHandler:mcpApi,defaultHandler,
 authorizeEndpoint:'/authorize',tokenEndpoint:'/oauth/token',
 clientRegistrationEndpoint:'/register',
 scopesSupported:['dsd:write','planogram:write','offline_access'],requiredScopes:['dsd:write'],
 resourceMetadata:{
  resource:'https://upc-dsd-chatgpt.ryan-m-t-brown.workers.dev/mcp',
  authorization_servers:['https://upc-dsd-chatgpt.ryan-m-t-brown.workers.dev']
 },
 clientIdMetadataDocumentEnabled:true
});
