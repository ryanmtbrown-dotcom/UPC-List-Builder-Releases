/**
 * OWNERSHIP: Strict, versioned AI-interpreted planogram data validation.
 * Does not own: PDF parsing, source inference, DSD pricing, persistence, or UI.
 * Side effects: None; source JSON remains untrusted until accepted by the user.
 */
export const PLANOGRAM_SCHEMA='PLANOGRAM_IMPORT_V1';
export const MAX_SOURCE_ROWS=3500, MAX_CHUNK_ROWS=100, MAX_CHUNKS=64;
const types=new Set(['PEG','SHELF','SPCFIX','OTHER','UNKNOWN']);
const states=new Set(['MERCHANDISE','NON_MERCHANDISE','UNRESOLVED']);
function obj(x,label,allowed,required=[]){
 if(!x||Array.isArray(x)||typeof x!=='object')throw Error(label+' must be an object');
 for(const k of Object.keys(x))if(!allowed.includes(k))throw Error(label+' has unsupported field '+k);
 for(const k of required)if(!Object.hasOwn(x,k))throw Error(label+' requires '+k);
 return x;
}
function str(x,label,max=240,{optional=false}={}){
 if((x===null||x===undefined||x==='')&&optional)return null;
 if(typeof x!=='string'||x.length>max||!x.trim()||/[\u0000-\u001f\u007f]/.test(x))throw Error(label+' is invalid');
 return x.trim();
}
function num(x,label,max,zero=true){if(!Number.isSafeInteger(x)||x<Number(!zero)||x>max)throw Error(label+' invalid');return x}
function arr(x,label,max){if(!Array.isArray(x)||x.length>max)throw Error(label+' invalid');return x}
function one(x,label,choices){if(!choices.has(x))throw Error(label+' invalid');return x}
export function sourceHeader(input){
 const x=obj(input,'source',['planogramId','name','commodityCode','commodityGroup','liveDate','nominalWidthFt','nominalFourFootSections','widthEvidence','sourceFilename','sourceIdentityEvidence'],['planogramId','name','sourceIdentityEvidence','nominalWidthFt','nominalFourFootSections','widthEvidence']);
 const s={planogramId:str(x.planogramId,'source ID',100),name:str(x.name,'source name',180),
  commodityCode:str(x.commodityCode,'commodity code',100,{optional:true}),
  commodityGroup:str(x.commodityGroup,'commodity group',180,{optional:true}),
  liveDate:str(x.liveDate,'printed live date',45,{optional:true}),
  nominalWidthFt:x.nominalWidthFt,nominalFourFootSections:x.nominalFourFootSections,
  widthEvidence:str(x.widthEvidence,'source width evidence',550),
  sourceFilename:str(x.sourceFilename,'source filename',200,{optional:true}),
  sourceIdentityEvidence:str(x.sourceIdentityEvidence,'source identity evidence',550)};
 if(!Number.isFinite(s.nominalWidthFt)||s.nominalWidthFt<=0||s.nominalWidthFt>200)throw Error('Nominal width invalid');
 if(!Number.isSafeInteger(s.nominalFourFootSections)||s.nominalFourFootSections<1||s.nominalFourFootSections>50||s.nominalFourFootSections!==Math.ceil(s.nominalWidthFt/4))throw Error('AI-declared four-foot section count does not match supported source width');
 if(s.liveDate&&!/^\d{4}-\d{2}-\d{2}$/.test(s.liveDate))throw Error('Date must be source-supported ISO date');
 return s;
}
function segments(input){
 const list=arr(input,'source segments',80);const seen=new Set();
 return list.map((v,i)=>{obj(v,'segment',['id','ordinal','fixtureType','description'],['id','ordinal']);
 const id=str(v.id,'segment ID',70);if(seen.has(id))throw Error('Duplicate source segment');seen.add(id);
 return{id,ordinal:num(v.ordinal,'segment ordinal',1000,false),
  fixtureType:v.fixtureType==null?null:one(v.fixtureType,'segment fixture type',types),
  description:str(v.description,'segment description',240,{optional:true})};
 });
}
export function placementRow(v){
 obj(v,'source row',['sourceRowId','sku','upcOrGtin','description','sourceSegment','fixtureType','reportRow','reportColumn','fixtureLabel','fixtureZone','facings','sourcePage','membershipDisposition'],['sourceRowId','membershipDisposition']);
 const p={sourceRowId:str(v.sourceRowId,'source row ID',80),sku:str(v.sku,'SKU',80,{optional:true}),
 upcOrGtin:str(v.upcOrGtin,'GTIN',30,{optional:true}),description:str(v.description,'description',300,{optional:true}),
 sourceSegment:str(v.sourceSegment,'source segment',80,{optional:true}),
 fixtureType:v.fixtureType==null?'UNKNOWN':one(v.fixtureType,'fixture type',types),
 reportRow:v.reportRow==null?null:str(String(v.reportRow),'reported row',70),
 reportColumn:v.reportColumn==null?null:str(String(v.reportColumn),'reported column',70),
 fixtureLabel:str(v.fixtureLabel,'source fixture',120,{optional:true}),
  fixtureZone:v.fixtureZone==null?null:one(v.fixtureZone,'fixture zone',new Set(['LFT','CL','CTR','CR','RGT'])),
 facings:v.facings==null?null:num(v.facings,'source facings',200,false),
 sourcePage:v.sourcePage==null?null:num(v.sourcePage,'source page',10000,false),
 membershipDisposition:one(v.membershipDisposition,'membership disposition',states)};
 if(p.upcOrGtin){
  if(!/^\d{8}$|^\d{12,14}$/.test(p.upcOrGtin))throw Error('GTIN unsupported; preserve only 8/12/13/14-digit identifiers');
  if(/^0+$/.test(p.upcOrGtin))throw Error('GTIN all-zero placeholder is invalid');
  let sum=0;for(let i=p.upcOrGtin.length-2,j=0;i>=0;i--,j++)sum+=Number(p.upcOrGtin[i])*(j%2===0?3:1);
  if((10-sum%10)%10!==Number(p.upcOrGtin.at(-1)))throw Error('GTIN failed checksum');
 }
 if(p.membershipDisposition==='MERCHANDISE'&&!p.sku)throw Error('Merchandise without verified SKU must be unresolved');
 if(p.membershipDisposition==='MERCHANDISE'&&p.fixtureType==='PEG'&&(!p.reportRow||!p.reportColumn))throw Error('Peg merchandise must retain Product Report ROW and COL; classify uncertain row as UNRESOLVED');
 return p;
}
function exceptions(input,label){
 return arr(input,label,MAX_SOURCE_ROWS).map(e=>{obj(e,label+' entry',['sourceRowId','reason','sourcePage','evidence'],['sourceRowId','reason']);return{
 sourceRowId:str(e.sourceRowId,label+' row',80),reason:str(e.reason,label+' reason',320),
 sourcePage:e.sourcePage==null?null:num(e.sourcePage,label+' page',10000,false),
 evidence:str(e.evidence,label+' source evidence',350,{optional:true})};});
}
function counts(input){
 obj(input,'reconciliation',['sourceReportRows','submittedRowRecords','merchandiseRows','excludedNonMerchandiseRows','unresolvedRows','distinctMerchandiseSkus','unrepresentedRows'],['sourceReportRows','submittedRowRecords','merchandiseRows','excludedNonMerchandiseRows','unresolvedRows','distinctMerchandiseSkus','unrepresentedRows']);
 return Object.fromEntries(Object.entries(input).map(([k,v])=>[k,num(v,'reconciliation '+k,MAX_SOURCE_ROWS)]));
}
function manifest(input){
 obj(input,'manifest',['submissionId','expectedChunks','sourceDigest','status'],['submissionId','expectedChunks','status']);
 return{submissionId:str(input.submissionId,'submission ID',80),expectedChunks:num(input.expectedChunks,'expected chunks',MAX_CHUNKS,false),
 sourceDigest:str(input.sourceDigest,'content digest',64,{optional:true}),status:one(input.status,'import status',new Set(['COMPLETE','INCOMPLETE']))};
}
export function validatePlanogram(input,{maxRows=MAX_SOURCE_ROWS}={}){
 obj(input,'planogram',['schemaVersion','source','sourceSegments','placements','reconciliation','exclusions','unresolved','manifest'],['schemaVersion','source','sourceSegments','placements','reconciliation','exclusions','unresolved','manifest']);
 if(input.schemaVersion!==PLANOGRAM_SCHEMA)throw Error('Unsupported planogram schema');
 const source=sourceHeader(input.source),sourceSegments=segments(input.sourceSegments),
  placements=arr(input.placements,'placements',Math.min(maxRows,MAX_SOURCE_ROWS)).map(placementRow),
  reconciliation=counts(input.reconciliation),exclusions=exceptions(input.exclusions,'exclusions'),
  unresolved=exceptions(input.unresolved,'unresolved'),metadata=manifest(input.manifest);
 const ids=new Set(),sids=new Set(sourceSegments.map(x=>x.id));
 for(const p of placements){
  if(ids.has(p.sourceRowId))throw Error('Repeated sourceRowId '+p.sourceRowId);
  ids.add(p.sourceRowId);
  if(p.sourceSegment&&!sids.has(p.sourceSegment))throw Error('Placement uses unknown source segment');
 }
 const filtered=kind=>placements.filter(p=>p.membershipDisposition===kind);
 const merchandise=filtered('MERCHANDISE'),excluded=filtered('NON_MERCHANDISE'),pending=filtered('UNRESOLVED');
 const check=(actual,expected,name)=>{if(actual!==expected)throw Error('Source row reconciliation mismatch: '+name)};
 check(placements.length,reconciliation.submittedRowRecords,'submittedRowRecords');
 check(merchandise.length,reconciliation.merchandiseRows,'merchandiseRows');
 check(excluded.length,reconciliation.excludedNonMerchandiseRows,'excludedNonMerchandiseRows');
 check(pending.length,reconciliation.unresolvedRows,'unresolvedRows');
 check(new Set(merchandise.map(x=>x.sku)).size,reconciliation.distinctMerchandiseSkus,'distinctMerchandiseSkus');
 check(reconciliation.submittedRowRecords+reconciliation.unrepresentedRows,reconciliation.sourceReportRows,'sourceReportRows');
 check(exclusions.length,excluded.length,'exclusions');check(unresolved.length,pending.length,'unresolved');
 for(const [list,k] of [[exclusions,'NON_MERCHANDISE'],[unresolved,'UNRESOLVED']]){
  const seen=new Set();for(const x of list){if(seen.has(x.sourceRowId)||!placements.some(p=>p.sourceRowId===x.sourceRowId&&p.membershipDisposition===k))throw Error('Exception row not accounted for or duplicate');seen.add(x.sourceRowId)}
 }
 if(metadata.status==='COMPLETE'&&reconciliation.unrepresentedRows!==0)throw Error('Source report missing rows; cannot mark complete');
 const result={schemaVersion:PLANOGRAM_SCHEMA,source,sourceSegments,placements,reconciliation,exclusions,unresolved,manifest:metadata};
 if(JSON.stringify(result).length>800000)throw Error('Planogram exceeds maximum validated size');
 return result;
}
// Stable source bytes, excluding transport-only digest and chunk count.
export function canonicalSourcePayload(x){
 const value=JSON.parse(JSON.stringify(x));
 if(value.manifest){value.manifest.sourceDigest=null;value.manifest.expectedChunks=1;}
 return JSON.stringify(value);
}
export async function digestSource(x){
 const bytes=new TextEncoder().encode(canonicalSourcePayload(x));
 const sha=await crypto.subtle.digest('SHA-256',bytes);
 return [...new Uint8Array(sha)].map(x=>x.toString(16).padStart(2,'0')).join('');
}
export async function verifySourceDigest(x){const digest=await digestSource(x);if(x.manifest.sourceDigest&&x.manifest.sourceDigest!==digest)throw Error('Source digest mismatch');return digest}
export function validateChunkRows(rows){const checked=arr(rows,'chunk rows',MAX_CHUNK_ROWS).map(placementRow),seen=new Set();for(const row of checked){if(seen.has(row.sourceRowId))throw Error('Duplicate source row in chunk');seen.add(row.sourceRowId)}return checked}
export function validatePlanogramHeader(input){
 obj(input,'planogram header',['schemaVersion','source','sourceSegments','reconciliation','exclusions','unresolved','manifest'],['schemaVersion','source','sourceSegments','reconciliation','exclusions','unresolved','manifest']);
 if(input.schemaVersion!==PLANOGRAM_SCHEMA)throw Error('Unsupported planogram schema');
 const header={schemaVersion:PLANOGRAM_SCHEMA,source:sourceHeader(input.source),sourceSegments:segments(input.sourceSegments),reconciliation:counts(input.reconciliation),exclusions:exceptions(input.exclusions,'exclusions'),unresolved:exceptions(input.unresolved,'unresolved'),manifest:manifest(input.manifest)};
 if(header.manifest.expectedChunks<2)throw Error('Use submit_planogram_import for single chunk');
 if(JSON.stringify(header).length>50000)throw Error('Header too large');
 return header;
}
