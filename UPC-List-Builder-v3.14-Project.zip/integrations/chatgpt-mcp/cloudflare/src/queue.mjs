/**
 * OWNERSHIP: Per-user Cloudflare D1 pending invoice staging and paired-device tokens.
 * Does not own: OAuth sign-in/consent, DSD rules/pricing, mobile IndexedDB or presentation.
 * Side effects: D1 SQL only; all random bearer material is hashed before persistence.
 */
import { validateBatch } from './validate.mjs';
import { requireMissingDepartmentAcknowledgment } from './review-policy.mjs';
const now=()=>Date.now();
const DAY=86_400_000;
const textEncoder=new TextEncoder();
async function sha(s){
 const d=await crypto.subtle.digest('SHA-256',textEncoder.encode(s));
 return Array.from(new Uint8Array(d),b=>b.toString(16).padStart(2,'0')).join('');
}
const random=length=>{
 const bytes=new Uint8Array(length);crypto.getRandomValues(bytes);
 const base=btoa(String.fromCharCode(...bytes));
 return base.replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
};
function ownerId(subject){
 if(typeof subject!=='string'||!/^github:\d{1,20}$/.test(subject))throw Error('Invalid authenticated identity.');
 return subject;
}
export function createQueue(db){
 if(!db||typeof db.prepare!=='function')throw Error('D1 database is not bound.');
 async function prune(){
  const t=now();
  await db.batch([
   db.prepare('DELETE FROM dsd_pairings WHERE expires < ?').bind(t),
   db.prepare("DELETE FROM dsd_batches WHERE state='imported' AND updated < ?").bind(t-30*DAY),
   db.prepare("DELETE FROM dsd_batches WHERE state='pending' AND created < ?").bind(t-90*DAY),
   db.prepare('DELETE FROM dsd_devices WHERE created < ?').bind(t-180*DAY)
  ]);
 }
 async function createPairing(owner){
  ownerId(owner);await prune();
  const code=random(18);
  await db.prepare('INSERT INTO dsd_pairings(code_hash,owner,expires) VALUES (?,?,?)')
   .bind(await sha(code),owner,now()+600_000).run();
  return{code,expiresInSeconds:600};
 }
 async function claim(code){
  if(typeof code!=='string'||!/^[A-Za-z0-9_-]{24}$/.test(code))return null;
  const matched=await db.prepare('DELETE FROM dsd_pairings WHERE code_hash=? AND expires>? RETURNING owner')
   .bind(await sha(code),now()).first();
  if(!matched?.owner)return null;
  const token=random(32);
  await db.prepare('INSERT INTO dsd_devices(token_hash,owner,created) VALUES (?,?,?)')
   .bind(await sha(token),matched.owner,now()).run();
  return{token};
 }
 async function deviceOwner(token){
  if(typeof token!=='string'||!/^[A-Za-z0-9_-]{43}$/.test(token))return null;
  const record=await db.prepare('SELECT owner FROM dsd_devices WHERE token_hash=? AND created>?')
   .bind(await sha(token),now()-180*DAY).first();
  return record?.owner||null;
 }
 async function revoke(token){
  if(!await deviceOwner(token))return false;
  const row=await db.prepare('DELETE FROM dsd_devices WHERE token_hash=?').bind(await sha(token)).run();
  return row.meta?.changes===1;
 }
 async function submit(owner,input){
  ownerId(owner);
  const payload=validateBatch(input);
  requireMissingDepartmentAcknowledgment(input,payload);
  const encoded=JSON.stringify(payload),digest=await sha(encoded);
  const id=crypto.randomUUID(),t=now();
  await db.prepare("INSERT OR IGNORE INTO dsd_batches(id,owner,digest,payload,state,created,updated) VALUES (?,?,?,?,?,?,?)")
   .bind(id,owner,digest,encoded,'pending',t,t).run();
  const record=await db.prepare('SELECT id,state FROM dsd_batches WHERE owner=? AND digest=?')
   .bind(owner,digest).first();
  return{id:record.id,state:record.state,itemCount:payload.items.length,warnings:payload.warnings};
 }
 async function list(owner){
  ownerId(owner);
  const result=await db.prepare("SELECT id,created,state,payload FROM dsd_batches WHERE owner=? AND state='pending' ORDER BY created ASC LIMIT 50")
   .bind(owner).all();
  return(result.results||[]).map(row=>{
   const parsed=JSON.parse(row.payload);
   return{id:row.id,created:row.created,state:row.state,manufacturer:parsed.invoice.primaryVendor,
    invoiceNumber:parsed.invoice.invoiceNumber,itemCount:parsed.items.length};
  });
 }
 async function get(owner,id){
  ownerId(owner);if(typeof id!=='string')return null;
  const record=await db.prepare('SELECT id,state,payload FROM dsd_batches WHERE id=? AND owner=?')
   .bind(id,owner).first();
  return record?{id:record.id,state:record.state,...JSON.parse(record.payload)}:null;
 }
 async function status(owner,id){
  ownerId(owner);
  return await db.prepare('SELECT id,state,updated FROM dsd_batches WHERE id=? AND owner=?').bind(id,owner).first();
 }
 async function acknowledge(owner,id){
  ownerId(owner);
  const done=await db.prepare("UPDATE dsd_batches SET state='imported',updated=? WHERE id=? AND owner=? AND state='pending'")
   .bind(now(),id,owner).run();
  return done.meta?.changes===1||(await status(owner,id))?.state==='imported';
 }
 async function reject(owner,id){
  ownerId(owner);
  if(typeof id!=='string'||!/^[0-9a-f-]{36}$/i.test(id))return false;
  const removed=await db.prepare("DELETE FROM dsd_batches WHERE id=? AND owner=? AND state='pending'")
   .bind(id,owner).run();
  return removed.meta?.changes===1;
 }
 return Object.freeze({createPairing,claim,deviceOwner,revoke,submit,list,get,status,acknowledge,reject});
}
