/**
 * OWNERSHIP: Pure DSD invoice preflight and review presentation policy.
 * Does not own: OAuth, durable queue, Android SKU/pricing or UI DOM.
 * Side effects: none. The Android DSD domain remains export authority.
 */
import { validateBatch } from './validate.mjs';
import { WorkflowError } from './workflow-errors.mjs';

// Mirrored from the Android Myers department registry; permanent parity tests
// prevent changes to either list from silently diverging.
export const DEPARTMENTS=Object.freeze([
 ['46','Firearms'],['55','Cleaning Supplies'],['56','Paint and Paint Supplies'],
 ['57','Hand Tools and Tool Accessories'],['58','Power Tools'],
 ['59','Flashlights and Lighting Supplies'],['60','Electrical Supplies'],
 ['61','Plumbing Supplies and Fixtures'],['62','Heating and Cooling Supplies'],
 ['63','Hardware'],['64','Fasteners'],['67','Building Materials and Products'],
 ['68','Appliances and Home Entertainment'],['69','Housewares and Gifts'],
 ['70','Lawn Garden / Farm Supplies'],['71','Outdoor Equipment and Power Tools'],
 ['72','Sporting Goods'],['73','Automotive'],['74','Outdoor Living and Furniture'],
 ['75','Stationary Supplies / Office Equipment'],['77','Notions and Miscellaneous'],
 ['170','Major Department - Ace']
]);
const validDepartment=value=>DEPARTMENTS.some(([code])=>code===String(value||'').trim());
const text=value=>String(value??'').trim();

// Evidence is an assistant report, not proof of independent search execution.
// Require coverage and expose unavailable/unresolved results for user review.
export function validateResearch(evidence,itemCount){
 const fail=message=>{throw new WorkflowError('RESEARCH_REQUIRED',message,['product_research','record_sources_or_uncertainty']);};
 if(!Array.isArray(evidence)||!evidence.length||evidence.length>200)
  fail('Record product research for every retained merchandise item before creating its review.');
 if(new TextEncoder().encode(JSON.stringify(evidence)).byteLength>65536)
  fail('Keep research evidence below 64 KiB; summarize source findings without copying whole pages.');
 const covered=new Set();
 const result=evidence.map(entry=>{
  if(!entry||!Array.isArray(entry.itemIndexes)||!entry.itemIndexes.length||
   entry.itemIndexes.length>200||!['identified','unresolved','unavailable'].includes(entry.status)||
   typeof entry.query!=='string'||!entry.query.trim()||entry.query.length>500||
   typeof entry.productName!=='string'||entry.productName.length>400||
   typeof entry.notes!=='string'||!entry.notes.trim()||entry.notes.length>1000||
   !Array.isArray(entry.sources)||entry.sources.length>5)
   fail('Each research entry needs item indexes, query, product name, status, source URLs and notes explaining matches or uncertainty.');
  for(const index of entry.itemIndexes){
   if(!Number.isInteger(index)||index<0||index>=itemCount||covered.has(index))
    fail('Research indexes must cover each retained merchandise item exactly once, in review order.');
   covered.add(index);
  }
  const sources=entry.sources.map(value=>{
   try{const url=new URL(value);if(url.protocol!=='https:'||url.username||url.password||value.length>2000)throw Error();return url.href;}
   catch{fail('Research sources must be HTTPS URLs without embedded credentials.');}
  });
  if(entry.status==='identified'&&(!entry.productName.trim()||!sources.length))
   fail('An identified product requires its name and accessible supporting source URLs. Otherwise report unresolved or unavailable.');
  if(entry.suggestedDepartment&&!validDepartment(entry.suggestedDepartment))
   fail('A research department suggestion must be a valid Myers department.');
  return {itemIndexes:[...entry.itemIndexes],query:entry.query.trim(),productName:entry.productName.trim(),
   status:entry.status,sources,notes:entry.notes.trim(),suggestedDepartment:entry.suggestedDepartment||'',
   provenance:'assistant_reported'};
 });
 if(covered.size!==itemCount)fail('Some retained merchandise items have no recorded product research.');
 return result;
}

export function preferredManufacturerName(value){
 const original=text(value);
 const stripped=original.replace(/(?:[,.\s]+(?:INCORPORATED|INC|L\.L\.C\.|LLC|CORPORATION|CORP\.?|CO\.?))+\.?$/i,'').trim();
 // Explicit established common names, not a general "remove all words" rule.
 if(/^PRADCO(?:\s+OUTDOOR\s+BRANDS)?$/i.test(stripped))return 'PRADCO';
 if(/^WORLDWIDE\s+DISTRIBUTORS?$/i.test(stripped))return 'WWD';
 return stripped||original;
}
function productSuggestion(item){
 // Conservative product phrases; ambiguous abbreviations never infer a dept.
 const t=(text(item.description)+' '+text(item.mfg)).toLowerCase();
 const table=[
  ['72',/\b(fishing lure|spinnerbait|fishing tackle|fishing rod|fish hook|casting spoon|fishing reel|tackle box)\b/],
  ['70',/\b(potting soil|fertilizer|grass seed|garden hose|weed killer)\b/],
  ['56',/\b(paint brush|paint roller|spray paint|latex paint|paint thinner)\b/],
  ['55',/\b(cleaning detergent|household cleaner|dish soap|floor cleaner)\b/],
  ['57',/\b(hand saw|adjustable wrench|pliers|screwdriver|socket wrench)\b/],
  ['59',/\b(flashlight|headlamp|lantern)\b/],
  ['60',/\b(extension cord|light switch|electrical outlet)\b/],
  ['61',/\b(pipe fitting|toilet repair|faucet|plumbing valve)\b/],
  ['73',/\b(windshield wiper|motor oil|automotive battery|car wax)\b/]
 ];
 const found=table.filter(([,pattern])=>pattern.test(t));
 return found.length===1?{department:found[0][0],basis:'Recognizable product description',confidence:'high'}:null;
}
function itemGaps(item,effectiveDept){
 const issues=[];
 if(!validDepartment(effectiveDept))issues.push('department');
 if(!/^\d{6,}$/.test(text(item.upc)))issues.push('UPC');
 if(!text(item.description))issues.push('description');
 if(!Number.isFinite(Number(item.orderMultiple))||Number(item.orderMultiple)<=0)issues.push('order multiple');
 if(text(item.caseCost)===''||!Number.isFinite(Number(item.caseCost)))issues.push('cost');
 if(text(item.retail)===''&&(
  text(item.retailMethod).toUpperCase()!=='MARKUP'||
  text(item.markup)===''||!Number.isFinite(Number(item.markup))||
  Number(item.markup)<0))issues.push('retail or markup');
 return issues;
}
export function prepareReview(input){
 const prepared={...input,invoice:{...input.invoice,
  primaryVendor:preferredManufacturerName(input.invoice?.primaryVendor),
  secondaryVendor:preferredManufacturerName(input.invoice?.secondaryVendor)}};
 const normalized=validateBatch(prepared);
 const invoice={...normalized.invoice,
  primaryVendor:preferredManufacturerName(normalized.invoice.primaryVendor),
  secondaryVendor:preferredManufacturerName(normalized.invoice.secondaryVendor)};
 const batch={
  ...input,
  invoice:{...input.invoice,...invoice},
  items:normalized.items.map((item,index)=>({
   ...input.items[index],...item
  }))
 };
 // A removed free display may change positions. Preserve normalized line items
 // as authoritative and avoid falsely reattaching source rows by array index.
 batch.items=normalized.items.map(item=>({...item}));
 const items=normalized.items.map((item,index)=>{
  const effective=item.department||invoice.department;
  const suggested=!validDepartment(effective)?productSuggestion(item):null;
  const gaps=itemGaps(item,effective);
  return {index,upc:item.upc,description:item.description,
   department:item.department||'',effectiveDepartment:validDepartment(effective)?effective:'',
   suggestedDepartment:suggested?.department||'',
   suggestionBasis:suggested?.basis||'',
   confidence:suggested?.confidence||'',
   gaps};
 });
 return {batch,invoice,items,itemCount:items.length,
  missingDepartmentCount:items.filter(x=>x.gaps.includes('department')).length,
  suggestedCount:items.filter(x=>x.suggestedDepartment).length,
  needsReviewCount:items.filter(x=>x.gaps.length).length,
  departments:DEPARTMENTS,
  sourceFilename:normalized.sourceFilename,
  warnings:normalized.warnings,
  kind:'dsd-invoice-review'};
}
export function requireMissingDepartmentAcknowledgment(input,normalized=validateBatch(input)){
 const defaultDept=normalized.invoice.department;
 if(normalized.items.some(item=>!validDepartment(item.department||defaultDept))&&
    input.missingDepartmentsAcknowledged!==true)
  throw Error('Department missing. Choose an invoice/item department or explicitly approve importing without departments.');
}
