/**
 * OWNERSHIP: Account-bound, expiring D1 invoice review and UI approval receipts.
 * Does not own: product research execution, pricing, OAuth or Android persistence.
 * Side effects: D1 review SQL and the injected staging queue after UI approval.
 */
import {prepareReview,requireMissingDepartmentAcknowledgment,validateResearch,DEPARTMENTS} from './review-policy.mjs';
import {WorkflowError} from './workflow-errors.mjs';
const encode=new TextEncoder();
const hash=async value=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',encode.encode(value))),x=>x.toString(16).padStart(2,'0')).join('');
const ownerId=owner=>{if(!/^github:\d{1,20}$/.test(owner||''))throw new WorkflowError('AUTH_REQUIRED','An authenticated account is required.',['authenticate'],'reconnect_plugin');};
const blocked=(code,message,steps)=>new WorkflowError(code,message,steps);
export function createReviewStore(db,queue) {
 async function create(owner,input) {
  ownerId(owner);
  let review;
  try{review=prepareReview(input);}catch(error){throw blocked('INVOICE_VALIDATION_FAILED',error.message,['validate_invoice_facts']);}
  review.research=validateResearch(input.researchEvidence,review.batch.items.length);
  delete review.batch.researchEvidence;
  for(const evidence of review.research)for(const index of evidence.itemIndexes){
   const item=review.items[index];
   if(!item.effectiveDepartment&&evidence.status==='identified'&&evidence.suggestedDepartment){
    item.suggestedDepartment=evidence.suggestedDepartment;
    item.suggestionBasis='Research report: '+evidence.productName;
    item.confidence='user_review_required';
   }
  }
  review.suggestedCount=review.items.filter(x=>x.suggestedDepartment).length;
  const id=crypto.randomUUID(),proof=crypto.randomUUID()+crypto.randomUUID(),expires=Date.now()+30*60_000;
  // Fail closed when the deployment's review migration has not been applied.
  try {
   await db.prepare('DELETE FROM dsd_reviews WHERE expires < ?').bind(Date.now()).run();
   await db.prepare('INSERT INTO dsd_reviews(id,owner,proof_hash,payload,state,expires) VALUES (?,?,?,?,?,?)')
    .bind(id,owner,await hash(proof),JSON.stringify(review),'review',expires).run();
  } catch {throw blocked('REVIEW_STORAGE_UNAVAILABLE','The review service is not ready. An operator must apply the review migration; do not bypass review.',['deploy_review_storage']);}
  return {...review,reviewId:id,expiresAt:expires,workflowVersion:'2.0.0',
   checklist:{researchEvidenceRecorded:true,uiRendered:false,approvalRecorded:false,submitted:false},
   // Proof is returned only in tool-result _meta for the UI, never model content.
   approvalProof:proof};
 }
 async function getReview(owner,input){
  ownerId(owner);
  if(!input?.reviewId||!input?.approvalProof)
   throw blocked('REVIEW_REQUIRED','Submission requires the invoice review screen and its Approve & send action. A department/markup answer alone is not approval.',['product_research','show_item_review','user_approval']);
  let row;
  try {row=await db.prepare('SELECT * FROM dsd_reviews WHERE id=? AND owner=? AND proof_hash=? AND expires>?')
   .bind(input.reviewId,owner,await hash(input.approvalProof),Date.now()).first();}
  catch {throw blocked('REVIEW_STORAGE_UNAVAILABLE','The review service is unavailable. Do not stage the invoice.',['deploy_review_storage']);}
  if(!row)throw blocked('REVIEW_EXPIRED_OR_INVALID','This review has expired or is unavailable to this account. Generate a fresh review.',['show_item_review','user_approval']);
  return row;
 }
 async function rendered(owner,input){
  const row=await getReview(owner,input);
  if(row.rendered_at)return {reviewId:input.reviewId,uiRendered:true,approvalRecorded:row.state!=='review',
   submitted:row.state==='submitted',approvedChoices:row.approved_choices?JSON.parse(row.approved_choices):null,
   receipt:row.receipt?JSON.parse(row.receipt):null};
  await db.prepare("UPDATE dsd_reviews SET rendered_at=? WHERE id=? AND owner=? AND state='review'")
   .bind(Date.now(),input.reviewId,owner).run();
  return {reviewId:input.reviewId,uiRendered:true,submitted:false};
 }
 async function submit(owner,input) {
  const row=await getReview(owner,input);
  if(!row.rendered_at)throw blocked('UI_REVIEW_REQUIRED','The item review screen has not confirmed loading. Present the review and wait for approval through its Approve & send button.',['show_item_review','user_approval']);
  if(Object.keys(input).some(key=>!['reviewId','approvalProof','decisions'].includes(key)))
   throw blocked('REVIEW_CHANGED','Do not send replacement invoice facts or completion flags. Approve the stored review or regenerate it.',['show_updated_item_review','user_approval']);
  const review=JSON.parse(row.payload),batch=structuredClone(review.batch),decisions=input.decisions||{};
  if(Object.keys(decisions).some(key=>!['invoice','itemDepartments','missingDepartmentsAcknowledged','unresolvedResearchAcknowledged'].includes(key)))
   throw blocked('REVIEW_CHANGED','Unknown review choices were supplied. Regenerate the review.',['show_updated_item_review']);
  for(const key of Object.keys(decisions.invoice||{})) {
   if(!['department','defaultMarkup','defaultRetailMethod'].includes(key))
    throw blocked('REVIEW_CHANGED','Invoice identity or product facts changed. Regenerate the item review.',['show_updated_item_review','user_approval']);
   batch.invoice[key]=decisions.invoice[key];
  }
  if(decisions.itemDepartments) {
   if(decisions.itemDepartments.length!==batch.items.length)
    throw blocked('REVIEW_CHANGED','The reviewed item count changed. Regenerate the review.',['show_updated_item_review']);
   decisions.itemDepartments.forEach((department,index)=>{batch.items[index].department=department;});
  }
  if([batch.invoice.department,...batch.items.map(x=>x.department)].some(value=>
   String(value??'').trim()&&!DEPARTMENTS.some(([code])=>code===String(value).trim())))
   throw blocked('DEPARTMENT_REVIEW_REQUIRED','Choose a listed Myers department or leave it blank for explicit acknowledgment.',['department_selection_or_acknowledgment']);
  const markup=String(batch.invoice.defaultMarkup??'').trim();
  if(markup&&(!Number.isFinite(Number(markup))||Number(markup)<0))
   throw blocked('MARKUP_REVIEW_REQUIRED','Requested markup must be a nonnegative number or blank.',['review_markup']);
  batch.missingDepartmentsAcknowledged=decisions.missingDepartmentsAcknowledged===true;
  const unresolved=review.research.filter(x=>x.status!=='identified');
  if(unresolved.length&&decisions.unresolvedResearchAcknowledged!==true)
   throw blocked('RESEARCH_REVIEW_REQUIRED','Research did not identify every product. Show the recorded attempts and uncertainties, then obtain the user\'s acknowledgment.',['review_unresolved_research','user_acknowledgment']);
  try {requireMissingDepartmentAcknowledgment(batch);}catch {
   throw blocked('DEPARTMENT_REVIEW_REQUIRED','Some merchandise has no valid department. Choose departments in the review or explicitly approve the blanks.',['department_selection_or_acknowledgment']);
  }
  // Facts remain immutable; only the review's declared department/markup choices
  // may change. Re-normalize before claiming its one-use approval proof.
  let normalized;
  try{normalized=prepareReview(batch).batch;}catch(error){throw blocked('INVOICE_VALIDATION_FAILED',error.message,['validate_invoice_facts']);}
  const digest=await hash(JSON.stringify(normalized));
  if(row.state==='submitted') {
   if(row.decision_digest!==digest)throw blocked('REVIEW_ALREADY_USED','This review already submitted different choices. Generate a new review.',['show_updated_item_review','user_approval']);
   return JSON.parse(row.receipt);
  }
  const claimed=await db.prepare("UPDATE dsd_reviews SET state='processing',decision_digest=?,approved_choices=? WHERE id=? AND owner=? AND state='review' AND expires>? RETURNING id")
   .bind(digest,JSON.stringify(decisions),input.reviewId,owner,Date.now()).first();
  if(!claimed){
   const current=await getReview(owner,input);
   if(current.decision_digest!==digest)throw blocked('REVIEW_ALREADY_USED','This review already approved different choices. Generate a new review.',['show_updated_item_review','user_approval']);
   if(current.state==='submitted')return JSON.parse(current.receipt);
   // Exact-choice retries resume the queue's owner+payload idempotent write.
  }
  try {
   const receipt=await queue.submit(owner,{...normalized,missingDepartmentsAcknowledged:batch.missingDepartmentsAcknowledged});
   await db.prepare("UPDATE dsd_reviews SET state='submitted',receipt=? WHERE id=? AND owner=? AND state='processing'")
    .bind(JSON.stringify(receipt),input.reviewId,owner).run();
   return receipt;
  } catch {
   const error=blocked('SUBMISSION_UNCONFIRMED','The submission receipt could not be confirmed. Retry the exact approved choices; do not create another invoice or claim success.',['confirm_submission_receipt']);
   error.submitted=null;error.retrySameRequest=true;error.nextTool='submit_dsd_import';
   throw error;
  }
 }
 return Object.freeze({create,rendered,submit});
}
