/**
 * OWNERSHIP: MCP tool schema declarations and per-request server registration.
 * Does not own: OAuth transport, device API, D1 storage implementation, pricing or Android behavior.
 * Side effects: Tool callbacks only when invoked; construction/discovery is side-effect free.
 */
import { McpServer } from '@modelcontextprotocol/server';
import * as z from 'zod/v4';
import { createQueue } from './queue.mjs';
import { createPlanogramQueue } from './planogram-queue.mjs';
import { createReviewStore } from './review-store.mjs';
import { workflowFailure } from './workflow-errors.mjs';
import { REVIEW_UI_HTML } from './review-ui.mjs';

const field=z.union([z.string(),z.number()]).optional();
const invoiceSchema=z.object({primaryVendor:z.string(),secondaryVendor:field,invoiceNumber:z.string(),
 department:field,defaultRetailMethod:field,defaultMarkup:field}).strict();
// Invoice quantity/cost evidence is normalized to DSD fields by validateBatch.
const itemSchema=z.object({upc:field,department:field,description:field,mfg:field,serialNumber:field,
 orderMultiple:field,caseCost:field,orderedQuantity:field,eachCost:field,lineTotal:field,
 retailMethod:field,retail:field,markup:field}).strict();
const invoiceIdentifierSchema=z.object({value:z.union([z.string(),z.number()]),sourceLabel:z.string(),
 issuer:z.enum(['primary','secondary','buyer','unknown']),kind:z.enum(['invoice','purchase_order','reference','other'])}).strict();
const researchSchema=z.object({itemIndexes:z.array(z.number().int().min(0)).min(1).max(200),
 query:z.string().min(1).max(500),productName:z.string().max(400),
 status:z.enum(['identified','unresolved','unavailable']),sources:z.array(z.string().max(2000)).max(5),
 notes:z.string().min(1).max(1000),suggestedDepartment:field}).strict();
const batchSchema=z.object({researchEvidence:z.array(researchSchema).max(200).optional(),missingDepartmentsAcknowledged:z.boolean().optional(),sourceFilename:z.string().optional(),invoice:invoiceSchema,
 manufacturerClarification:z.enum(['single','split']).optional(),
 invoiceNumberSource:z.enum(['primary','unknown']).optional(),
 secondaryInvoiceNumbers:z.array(z.union([z.string(),z.number()])).max(10).optional(),
 invoiceIdentifiers:z.array(invoiceIdentifierSchema).max(20).optional(),
 items:z.array(itemSchema).min(1).max(200),warnings:z.array(z.string()).max(50).optional()}).strict();
const securitySchemes=[{type:'oauth2',scopes:['dsd:write']}];
export function makeMcp(env,subject,approvedScopes=['dsd:write']){
 const queue=createQueue(env.DB);
 const planograms=createPlanogramQueue(env.DB);
 const authorize=scope=>{if(!approvedScopes.includes(scope))throw Error('Additional '+scope+' authorization required. Reconnect to approve the planogram permission.');};
 const safe=action=>async input=>{try{return answer(await action(input));}catch(e){return{isError:true,content:[{type:'text',text:String(e.message||'Invalid planogram payload.').slice(0,300)}]}}};
 const planogramSecurity=[{type:'oauth2',scopes:['planogram:write']}];
 const reviews=createReviewStore(env.DB,queue);
 const server=new McpServer({name:'UPC List Builder ACE New DSD Imports',version:'2.0.0'},
  {instructions:'For supplier invoice imports: investigate exact products and variants using available web search, record source URLs or honest unavailable/unresolved results, then call review_dsd_import to show the items and suggested departments before asking for choices. Department and markup answers are review choices, not submission approval. Submission requires the review component Approve & send action. Never invent a UI-render or approval claim. When a tool returns isError, read missingSteps and nextTool, repair the workflow, and never claim submission without a batch receipt.'});
 const answer=value=>({content:[{type:'text',text:JSON.stringify(value)}],structuredContent:value});
 server.registerTool('create_dsd_pairing_code',{
  title:'Pair UPC List Builder',description:'Generate a one-time code valid for ten minutes. Enter the code in your own UPC List Builder Android app; do not share it with others.',
  inputSchema:z.object({}).strict(),securitySchemes
 },async()=>{authorize('dsd:write');return answer(await queue.createPairing(subject));});
 const reviewUri='ui://upc-list-builder/dsd-review-v2.html';
 server.registerResource('dsd-review-ui',reviewUri,{},async()=>({
  contents:[{uri:reviewUri,mimeType:'text/html;profile=mcp-app',
   text:REVIEW_UI_HTML,_meta:{ui:{prefersBorder:true,
    csp:{connectDomains:[],resourceDomains:[]}}}}]
 }));
 server.registerTool('review_dsd_import',{
  title:'Review ACE New DSD invoice',
  description:'Use this for every supplier invoice import after researching its exact products and variants. Record researchEvidence for every retained merchandise item (zero-based indexes after excluding free displays), with query, sources, notes and honest identified/unresolved/unavailable status. Do not fabricate searches or accessible sources. Show this item review and suggested Myers departments BEFORE asking the user for department/markup choices. Supplying a department or markup does not bypass review. If facts change, generate a fresh review. Only the review UI can approve and submit.' + ' Extraction contract: ' + "Stage merchandise from supplier invoices for the existing editable ACE New DSD Items list (pending batch only). Do not submit without user authorization. DSD orderMultiple is not invoice quantity. Unless user explicitly supplies an order multiple, set orderMultiple=1 and caseCost to ONE unit's cost. Supply orderedQuantity, eachCost and/or lineTotal when present; reconcile unit cost × quantity against line total and never divide an already-unit cost. With lineTotal and orderedQuantity, divide to compute each cost. If source cost basis is ambiguous, clarify; never guess. When user explicitly specifies an order multiple, preserve it and use the matching cost for that many units. Exclude free $0 promotional display/merchandising fixture items; report exclusions in warnings. Do not exclude other $0 merchandise merely because cost is zero. Individual item departments are optional and inherit invoice default. Missing departments require explicit missingDepartmentsAcknowledged=true before submission; use review_dsd_import to obtain approval. Explicit item department supersedes default. Any serial number forces department 46. Recognizable ammunition defaults to 46 if no explicit item department; flag conflicting explicit department for review. Mixed-department 46/72/other invoices are valid. Investigate UPCs thoroughly: search by manufacturer number then by exact brand, model, product name, variant, color and size without requiring manufacturer-number match. Inspect exact matching retail product pages, alternate listings, structured metadata and UPC/GTIN/EAN fields, including Amazon/Walmart if accessible. Repeat a query if the retailer broadens or strips its keywords. The UPC must belong to the exact variant, never merely a similar product. Check length/check digit; cite accessible source or report missing evidence. Do not fabricate UPCs or claim to have scraped inaccessible sources. Interpret manufacturer/invoice source labels. Primary and secondary manufacturers are independent fields; multiword names are valid. Prefer short, recognizable manufacturer names and confirm only genuinely ambiguous identities. Use review_dsd_import first. WWD alone may be primary; with another primary manufacturer WWD is secondary. Supply invoiceIdentifiers with value, verbatim sourceLabel, issuer and kind. DSD invoice priority: verified primary manufacturer invoice > primary manufacturer PO with numeric PO prefix > explicit 00000 temporary placeholder with warning. Never substitute buyer/secondary PO or WWD secondary invoice. A PO is not an additional invoice. Clarify ambiguous competing primary invoice or PO evidence. Keep unverified UPC, cost, department and retail blank.",
  inputSchema:batchSchema,securitySchemes,
  _meta:{ui:{resourceUri:reviewUri},'openai/outputTemplate':reviewUri}
 },async input=>{
  try{
   authorize('dsd:write');
   const {approvalProof,...value}=await reviews.create(subject,input);
   return {content:[{type:'text',text:'Item review prepared: '+value.itemCount+
    ' items. Present the review component and wait for approval there. A prepared review does not prove that the UI rendered. No invoice was submitted.'}],
    structuredContent:value,_meta:{approvalProof}};
  }catch(e){return workflowFailure(e)}
 });
 const approvalSchema=z.object({reviewId:z.string().uuid().optional(),approvalProof:z.string().min(40).max(100).optional()}).passthrough();
 const appOnly={ui:{visibility:['app']},'openai/visibility':'private','openai/widgetAccessible':true};
 server.registerTool('record_dsd_review_rendered',{
  title:'Confirm item review loaded',description:'UI-only callback after the stored item review and research evidence render. This is not human approval.',
  inputSchema:approvalSchema,securitySchemes,_meta:appOnly
 },async input=>{try{authorize('dsd:write');return answer(await reviews.rendered(subject,input))}catch(e){return workflowFailure(e)}});
 server.registerTool('submit_dsd_import',{
  title:'Stage approved ACE New DSD invoice',
  description:'UI-only: stage the stored invoice after rendering and explicit Approve & send. Requires the account-bound review proof. Completion booleans and replacement invoice facts are not accepted. Exact approved retries are idempotent.',
  inputSchema:approvalSchema.extend({decisions:z.object({invoice:z.object({department:field,defaultMarkup:field,defaultRetailMethod:field}).passthrough().optional(),
   itemDepartments:z.array(z.union([z.string(),z.number()])).max(200).optional(),missingDepartmentsAcknowledged:z.boolean().optional(),
   unresolvedResearchAcknowledged:z.boolean().optional()}).passthrough().optional()}),securitySchemes,_meta:appOnly
 },async input=>{
  try{authorize('dsd:write');return answer(await reviews.submit(subject,input));}
  catch(e){return workflowFailure(e)}
 });
 const name=z.string().min(1).max(320);
 const count=z.number().int().min(0).max(3500);
 const fixture=z.enum(['PEG','SHELF','SPCFIX','OTHER','UNKNOWN']);
 const disposition=z.enum(['MERCHANDISE','NON_MERCHANDISE','UNRESOLVED']);
 const nullable=(schema)=>schema.nullable().optional();
 const sourceSchema=z.object({planogramId:name,name,commodityCode:nullable(name),commodityGroup:nullable(name),liveDate:nullable(name),nominalWidthFt:z.number().positive().max(200),nominalFourFootSections:z.number().int().min(1).max(50),widthEvidence:name,sourceFilename:nullable(name),sourceIdentityEvidence:name}).strict();
 const segmentSchema=z.object({id:name,ordinal:z.number().int().min(1),fixtureType:nullable(fixture),description:nullable(name)}).strict();
 const rowSchema=z.object({sourceRowId:name,sku:nullable(name),upcOrGtin:nullable(name),description:nullable(name),sourceSegment:nullable(name),fixtureType:fixture.optional(),reportRow:nullable(z.union([z.string(),z.number()])),reportColumn:nullable(z.union([z.string(),z.number()])),fixtureLabel:nullable(name),fixtureZone:nullable(z.enum(['LFT','CL','CTR','CR','RGT'])),facings:nullable(z.number().int().min(1)),sourcePage:nullable(z.number().int().min(1)),membershipDisposition:disposition}).strict();
 const exceptionSchema=z.object({sourceRowId:name,reason:name,sourcePage:nullable(z.number().int().min(1)),evidence:nullable(name)}).strict();
 const reconciliationSchema=z.object({sourceReportRows:count,submittedRowRecords:count,merchandiseRows:count,excludedNonMerchandiseRows:count,unresolvedRows:count,distinctMerchandiseSkus:count,unrepresentedRows:count}).strict();
 const manifestSchema=z.object({submissionId:name,expectedChunks:z.number().int().min(1).max(64),sourceDigest:nullable(z.string().max(64)),status:z.enum(['COMPLETE','INCOMPLETE'])}).strict();
 const headerSchema=z.object({schemaVersion:z.literal('PLANOGRAM_IMPORT_V1'),source:sourceSchema,sourceSegments:z.array(segmentSchema).max(80),reconciliation:reconciliationSchema,exclusions:z.array(exceptionSchema).max(3500),unresolved:z.array(exceptionSchema).max(3500),manifest:manifestSchema}).strict();
 const packetSchema=headerSchema.extend({placements:z.array(rowSchema).max(3500)}).strict();
 const importerNotes='Supply an AI-extracted ACE planogram, NOT a supplier invoice. Determine nominalWidthFt, nominalFourFootSections and widthEvidence directly from source planogram header/table (sections = four-foot units; half bays remain explicitly supported by evidence). Extract the Product Report table for each SKU and preserve original sourceSegment, reportRow, reportColumn, and fixtureType including PEG hook row/column. For PEG merchandise, ROW and COL must be present; if source does not support them classify that row UNRESOLVED, NEVER invent. For specialty fixtures extract fixtureZone only if source supports exact LFT,CL,CTR,CR,RGT positions, otherwise use original ROW/COL if available. The app shows the best available official location immediately without requiring a store audit.  Supply all Product Report source placement rows with sourceRowId. Classify fixtures/signs and nonmerchandise as NON_MERCHANDISE with reason; unresolved as UNRESOLVED with reason. sourceReportRows = submittedRowRecords + unrepresentedRows, count all three dispositions, distinct SKUs once despite multiple rows. Never invent UPC, SKU, source coordinates, physical aisle/sections, discontinued/clearance status or owner. No PDF/image bytes. Only source evidence, not a physical audit. Do not submit until the user authorizes import.';
 server.registerTool('submit_planogram_import',{
  title:'Stage Ace planogram',description:'Stage a complete AI-interpreted ACE planogram for device review. '+importerNotes+' For large plans use begin, append chunks, finalize.',
  inputSchema:packetSchema,securitySchemes:planogramSecurity
 },safe(async input=>{authorize('planogram:write');return await planograms.store(subject,input)}));
 server.registerTool('begin_planogram_import',{
  title:'Begin a large planogram',description:'Start a bounded staged import for more than 100 rows. '+importerNotes+' Chunks stay invisible to the device until finalized.',
  inputSchema:headerSchema,securitySchemes:planogramSecurity
 },safe(async input=>{authorize('planogram:write');return await planograms.begin(subject,input)}));
 server.registerTool('append_planogram_chunk',{
  title:'Append planogram rows',description:'Supply numbered complete Product Report rows to an open staged planogram. Retry the same chunk only with identical bytes.',
  inputSchema:z.object({sessionId:z.string().uuid(),index:z.number().int().min(0).max(63),rows:z.array(rowSchema).max(100)}).strict(),securitySchemes:planogramSecurity
 },safe(async input=>{authorize('planogram:write');return await planograms.append(subject,input.sessionId,input.index,input.rows)}));
 server.registerTool('finalize_planogram_import',{
  title:'Finalize staged planogram',description:'Reconcile every source row and publish only a fully received, validated planogram to your paired device for local review.',
  inputSchema:z.object({sessionId:z.string().uuid()}).strict(),securitySchemes:planogramSecurity
 },safe(async input=>{authorize('planogram:write');return await planograms.finalize(subject,input.sessionId)}));
 server.registerTool('get_planogram_import_status',{
  title:'Check planogram import status',description:'Check whether your own planogram batch is pending or has been imported and acknowledged locally.',
  inputSchema:z.object({batchId:z.string().uuid()}).strict(),securitySchemes:planogramSecurity
 },safe(async input=>{authorize('planogram:write');return await planograms.status(subject,input.batchId)||{status:'not_found'}}));
 server.registerTool('get_dsd_import_status',{
  title:'Check pending import status',description:'Check whether one of your own DSD batches has been imported locally and acknowledged by the UPC List Builder app.',
  inputSchema:z.object({batchId:z.string().uuid()}).strict(),securitySchemes
 },async({batchId})=>{authorize('dsd:write');return answer(await queue.status(subject,batchId)||{status:'not_found'});});
 return server;
}
