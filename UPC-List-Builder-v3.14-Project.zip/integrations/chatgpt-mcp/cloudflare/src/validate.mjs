/**
 * OWNERSHIP: Portable schema normalization for untrusted ChatGPT DSD invoice batches.
 * Does not own: DSD pricing, SKU generation, local app persistence, authentication.
 * Side effects: none.
 */
const clean=(value,max=240)=>{
 if(value===undefined||value===null)return '';
 if(typeof value!=='string'&&typeof value!=='number')throw Error('Invalid invoice field type.');
 const s=String(value).trim();
 if(s.length>max)throw Error('Invoice field exceeds maximum length.');
 return s;
};
// Invoice-title/filename interpretation belongs to the plugin, never to Android.
// Do not split naturally multiword brand names without a user-confirmed decision.
const hasWwdMarker=filename=>/(^|[^A-Za-z0-9])WWD(?=$|[^A-Za-z0-9])/i.test(filename);
function interpretedManufacturer(invoice,sourceFilename,clarification,input){
 const wwd=v=>String(v||'').trim().toUpperCase()==='WWD';
 const sourceEvidence=Array.isArray(input.invoiceIdentifiers)&&input.invoiceIdentifiers.some(
  x=>x&&typeof x==='object'&&hasWwdMarker(String(x.sourceLabel||'')));
 const observed=hasWwdMarker(sourceFilename)||sourceEvidence;
 let primary=invoice.primaryVendor,secondary=invoice.secondaryVendor;
 // Manufacturer order is relative: WWD alone is primary. With another named
 // manufacturer WWD belongs in the second position.
 if(wwd(primary)&&secondary&&!wwd(secondary)){
  invoice.primaryVendor=secondary;
  invoice.secondaryVendor='WWD';
 }else if(wwd(primary)&&wwd(secondary)){
  throw Error('WWD cannot fill both manufacturer fields. Confirm the actual manufacturer identities.');
 }else if(primary&&!wwd(primary)&&observed){
  if(secondary&&!wwd(secondary))
   throw Error('WWD and another Second Manufacturer were identified. Ask the user to resolve these identities before submission.');
  invoice.secondaryVendor='WWD';
 }else if(!primary&&observed&&!secondary){
  invoice.primaryVendor='WWD';
 }
 primary=invoice.primaryVendor;
 secondary=invoice.secondaryVendor;
 // Primary and secondary names are already separate fields. Word count is not
 // evidence of multiple manufacturers; preserve multiword legal brand identities.
 // Retain legacy clarification input for compatibility but never split on whitespace.
 if(!primary)
  throw Error('Primary manufacturer is not established. Ask before submitting.');
}
// Evidence-driven invoice-number policy. The plugin supplies observed labels,
// document issuers and types. A unique labeled primary invoice can be selected
// automatically; ambiguous or conflicting issuer evidence is never guessed.
const equivalentNumber=(a,b)=>{
 const norm=s=>String(s??'').trim().replace(/[\s-]/g,'');
 const x=norm(a),y=norm(b);
 return x===y||(x!==''&&y!==''&&/^\d+$/.test(x)&&/^\d+$/.test(y)&&
  x.replace(/^0+(?=\d)/,'')===y.replace(/^0+(?=\d)/,''));
};
function verifyPrimaryInvoiceNumber(input,filename,invoice,warnings){
 const references=input.secondaryInvoiceNumbers??[];
 if(!Array.isArray(references)||references.length>10)
  throw Error('Secondary invoice references must be an array of at most ten values.');
 const otherNumbers=references.map(n=>clean(n,200)).filter(Boolean);
 const filenameWwd=filename.match(/(?:^|[^A-Za-z0-9])WWD[\s_-]+(\d[\d-]*)/i)?.[1]||'';
 const original=invoice.invoiceNumber;
 const primaryIsWwd=invoice.primaryVendor.trim().toUpperCase()==='WWD';
 const entries=input.invoiceIdentifiers??[];
 if(!Array.isArray(entries)||entries.length>20)
  throw Error('Invoice identifiers must be a list of at most 20 observed numbers.');
 const identifiers=entries.map((entry,i)=>{
  if(!entry||typeof entry!=='object'||Array.isArray(entry))
   throw Error('Invalid invoice identifier '+(i+1)+'.');
  const value=clean(entry.value,200),sourceLabel=clean(entry.sourceLabel,160),
   issuer=clean(entry.issuer,24),kind=clean(entry.kind,24);
  if(!value||!sourceLabel||!['primary','secondary','buyer','unknown'].includes(issuer)||
   !['invoice','purchase_order','reference','other'].includes(kind))
   throw Error('Invoice identifier '+(i+1)+' needs a number, its actual document label, issuer and kind.');
  const wwd=hasWwdMarker(sourceLabel);
  return{value,sourceLabel,issuer,kind,wwd};
 });
 const isPrimary=entry=>entry.issuer==='primary'&&(!entry.wwd||primaryIsWwd);
 const wwdSecondary=entry=>entry.wwd&&!primaryIsWwd;
 const primaryInvoices=identifiers.filter(x=>x.kind==='invoice'&&isPrimary(x)&&!wwdSecondary(x));
 const primaryPurchaseOrders=identifiers.filter(x=>x.kind==='purchase_order'&&isPrimary(x)&&!wwdSecondary(x));
 const uniqueNumbers=entries=>{
  const out=[];
  for(const x of entries)if(!out.some(y=>equivalentNumber(y.value,x.value)))out.push(x);
  return out;
 };
 const first=uniqueNumbers(primaryInvoices);
 if(first.length>1)
  throw Error('Multiple distinct primary-manufacturer invoice numbers were found. Ask which primary invoice applies before submitting.');
 const allInvoices=uniqueNumbers(identifiers.filter(x=>x.kind==='invoice'));
 // Only one invoice source on the document? If it belongs to the sole
 // manufacturer, it is the primary invoice even when its header says WWD.
 // A WWD invoice is never selected over a different primary manufacturer.
 if(!first.length&&allInvoices.length===1){
  const lone=allInvoices[0];
  if((lone.wwd&&primaryIsWwd)||(!lone.wwd&&
      (lone.issuer==='primary'||(lone.issuer==='unknown'&&!invoice.secondaryVendor))))
   first.push(lone);
 }
 const competingUnknown=identifiers.filter(x=>x.kind==='invoice'&&x.issuer==='unknown'&&
  !wwdSecondary(x)&&!first.some(y=>equivalentNumber(y.value,x.value)));
 if(competingUnknown.length)
  throw Error('An invoice number has an unknown issuer and might belong to the primary manufacturer. Ask which manufacturer issued it before submitting.');
 for(const x of identifiers.filter(x=>wwdSecondary(x)||x.issuer==='secondary'||x.issuer==='buyer'||
   x.kind==='reference'||x.kind==='other'))
  otherNumbers.push(x.value);
 if(filenameWwd&&!primaryIsWwd)otherNumbers.push(filenameWwd);
 let chosen='',reason='';
 if(first.length){
  chosen=first[0].value;
  reason='primary invoice "'+first[0].sourceLabel+'"';
 }else if(primaryIsWwd&&filenameWwd&&!allInvoices.length){
  chosen=filenameWwd;
  reason='sole WWD invoice in source filename';
 }else if(!allInvoices.length&&original&&original!=='00000'&&
   !otherNumbers.some(x=>equivalentNumber(x,original))&&input.invoiceNumberSource==='primary'){
  chosen=original;
  reason='explicitly identified primary invoice';
 }else if(!identifiers.length&&original&&original!=='00000'&&
   !otherNumbers.some(x=>equivalentNumber(x,original))&&
   !(filenameWwd&&!primaryIsWwd&&equivalentNumber(filenameWwd,original))){
  chosen=original;
  reason='only supplied invoice number';
 }
 if(chosen&&otherNumbers.some(x=>equivalentNumber(x,chosen))){
  // A WWD invoice can be primary when WWD is the only manufacturer.
  if(!(primaryIsWwd&&
    (equivalentNumber(filenameWwd,chosen)||identifiers.some(x=>x.wwd&&equivalentNumber(x.value,chosen)))))
   throw Error('A proposed primary invoice number conflicts with a secondary invoice or buyer reference. Ask for clarification.');
 }
 if(!chosen){
  const orders=uniqueNumbers(primaryPurchaseOrders);
  if(orders.length>1)
   throw Error('Multiple primary-manufacturer purchase order numbers were found. Ask which one applies.');
  if(orders.length){
   const match=orders[0].value.match(/^(?:P\.?\s*O\.?[\s#-]*)?(\d[\d\s-]*)$/i);
   if(!match)throw Error('Primary purchase order does not contain a clear numeric identifier. Ask before staging.');
   chosen='PO'+match[1].replace(/[\s-]/g,'');
   reason='primary manufacturer purchase order "'+orders[0].sourceLabel+'"';
  }else{
   chosen='00000';
   reason='no primary manufacturer invoice or purchase order available';
  }
 }
 invoice.invoiceNumber=chosen;
 if(original&&original!==chosen)
  warnings.push('Invoice number corrected from '+original+' to '+chosen+' using '+reason+'.');
 if(chosen==='00000')
  warnings.push('Primary invoice and primary purchase order are unavailable. 00000 is a placeholder; replace it when a valid primary document number is known.');
 else if(chosen.startsWith('PO'))
  warnings.push('Primary invoice unavailable. Using purchase-order identifier '+chosen+' until the primary invoice is received.');
 else
  warnings.push('Using '+reason+' as the DSD invoice number: '+chosen+'.');
}

// Extracted quantities and prices are untrusted hints; only canonical DSD fields
// reach Android. The existing app owns pricing and SKU generation.
const moneyValue=(raw,label)=>{
 const value=clean(raw,120);
 if(!value)return null;
 if(!/^\$?(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d{1,4})?$/.test(value))
  throw Error(label+' must be a valid nonnegative monetary amount.');
 const amount=Number(value.replace(/[$,]/g,''));
 if(!Number.isFinite(amount)||amount<0)throw Error(label+' must be a nonnegative monetary amount.');
 return amount;
};
const quantityValue=(raw,label)=>{
 const value=clean(raw,120);
 if(!value)return null;
 const number=Number(value);
 if(!Number.isSafeInteger(number)||number<=0)throw Error(label+' must be a positive whole number.');
 return number;
};
const priceString=amount=>Number(amount.toFixed(4)).toString();
const roughlyEqual=(a,b)=>Math.abs(a-b)<=0.011;
const isDisplayDescription=description=>/\bdisplay\b/i.test(description)&&
 !/\b(?:lcd|led|oled|digital|touchscreen|screen|monitor)\s+display\b/i.test(description);
const isAmmunitionDescription=description=>{
 const value=description.toLowerCase().replace(/\s+/g,' ');
 // A case/can/bag of ammunition is not itself live ammunition.
 if(/\b(?:ammo|ammunition)\s+(?:box|can|bag|case|pouch|holder|storage|organizer)\b/.test(value))return false;
 if(/\b(?:ammunition|ammo|shotshells?|rimfire|centerfire|hollow[- ]point|full[- ]metal[- ]jacket)\b/.test(value))return true;
 if(/\b(?:rifle|pistol|shotgun|handgun)\s+(?:cartridges?|rounds?|shells?)\b/.test(value))return true;
 if(/\b(?:primers?\s+(?:(?:small|large)\s+)?(?:rifle|pistol)|(?:rifle|pistol)\s+primers?|smokeless\s+(?:gun\s+)?powder)\b/.test(value))return true;
 const caliber=/(?:\b(?:9\s?mm|10\s?mm|5\.56(?:\s?mm|\s?nato)?|7\.62(?:\s?mm|\s?nato)?|\.?22\s?lr|\.?223\s?rem|\.?308\s?win|\.?380\s?acp|\.?45\s?acp|\.?40\s?s&w|\.?357\s?mag|\.?300\s?win\s?mag|12\s?(?:ga|gauge)|20\s?(?:ga|gauge))\b)/.test(value);
 const ammoDetails=/\b(?:rds?|rounds?|rnds?|fmj|jhp|hollow|grain|gr|ball|shot|shells?|cartridges?)\b|\b\d{1,4}\s*(?:rd|rds|rnd|rnds|gr|grain)\b/.test(value);
 return caliber&&ammoDetails;
};
/**
 * Normalize invoice facts to the app's existing caseCost/orderMultiple contract.
 * orderedQuantity, eachCost and lineTotal are extraction hints, not Android fields.
 * Blank item departments inherit invoice default in the app; costs never guessed.
 */
function normalizeItems(rawItems,warnings){
 const items=[];
 for(const [index,raw] of rawItems.entries()){
  if(!raw||typeof raw!=='object'||Array.isArray(raw))throw Error('Invalid item '+(index+1));
  const item=Object.fromEntries(['upc','department','description','mfg','serialNumber','orderMultiple','caseCost','retailMethod','retail','markup']
   .map(k=>[k,clean(raw[k],k==='description'?400:120)]));
  const label='Item '+(index+1),qty=quantityValue(raw.orderedQuantity,label+' ordered quantity');
  const each=moneyValue(raw.eachCost,label+' each cost');
  const total=moneyValue(raw.lineTotal,label+' line total');
  const cost=moneyValue(item.caseCost,label+' case cost');
  const order=quantityValue(item.orderMultiple,label+' order multiple')??1;
  const displayCost=total??each??cost;
  if(isDisplayDescription(item.description)&&displayCost===0&&
     [total,each,cost].every(value=>value===null||value===0)){
   warnings.push(label+' excluded: zero-cost display ('+item.description+').');
   continue;
  }
  if(each!==null&&total!==null){
   if(qty===null)throw Error(label+' supplies both each cost and line total but no ordered quantity.');
   if(!roughlyEqual(each*qty,total))throw Error(label+' each cost does not reconcile with quantity and line total.');
  }
  let derivedEach=each;
  if(derivedEach===null&&total!==null){
   if(qty===null)throw Error(label+' line total requires an ordered quantity to compute each cost.');
   derivedEach=total/qty;
  }
  if(derivedEach!==null){
   const canonical=derivedEach*order;
   if(cost!==null&&!roughlyEqual(cost,canonical)&&!(qty!==null&&roughlyEqual(cost,total??derivedEach*qty)))
    throw Error(label+' case cost conflicts with verified each cost. Review source units.');
   item.caseCost=priceString(canonical);
   if(Math.abs(canonical-Number(item.caseCost))>0.00001)
    warnings.push(label+' cost was rounded to four decimal places after dividing the invoice line total.');
  }else if(cost!==null&&qty!==null&&qty>1&&clean(raw.orderMultiple)===''){
   throw Error(label+' has multiple units ordered and an ambiguous caseCost. Supply eachCost or lineTotal.');
  }
  item.orderMultiple=String(order);
  if(item.serialNumber){
   if(item.department&&item.department!=='46')warnings.push(label+' department changed to 46 because a serial number is present.');
   item.department='46';
  }else if(isAmmunitionDescription(item.description)){
   if(!item.department)item.department='46';
   else if(item.department!=='46')warnings.push(label+' resembles ammunition but specifies department '+item.department+'; verify classification.');
  }
  items.push(item);
 }
 if(!items.length)throw Error('Invoice contains no merchandise items after excluding zero-cost displays.');
 return items;
}

export function validateBatch(input){
 if(!input||typeof input!=='object'||Array.isArray(input))throw Error('Invoice payload is required.');
 const inv=input.invoice;
 if(!inv||typeof inv!=='object'||Array.isArray(inv))throw Error('Invoice metadata is required.');
 if(!Array.isArray(input.items)||input.items.length===0||input.items.length>200)throw Error('Invoice must have 1–200 items.');
 const invoice=Object.fromEntries(['primaryVendor','secondaryVendor','invoiceNumber','department','defaultRetailMethod','defaultMarkup']
  .map(k=>[k,clean(inv[k],200)]));
 // The filename/evidence may identify WWD as the sole manufacturer; decide below.
 if(input.warnings!==undefined&&!Array.isArray(input.warnings))throw Error('Warnings must be an array.');
 const warnings=(input.warnings||[]).slice(0,50).map(x=>clean(x,500));
 const items=normalizeItems(input.items,warnings);
 if(warnings.length>50)warnings.length=50;
 const sourceFilename=clean(input.sourceFilename,200);
 const interpretation=clean(input.manufacturerClarification,16).toLowerCase();
 interpretedManufacturer(invoice,sourceFilename,interpretation,input);
 verifyPrimaryInvoiceNumber(input,sourceFilename,invoice,warnings);
 if(!invoice.invoiceNumber)throw Error('A primary invoice, purchase order, or 00000 placeholder is required.');
 return{sourceFilename,invoice,items,warnings};
}
