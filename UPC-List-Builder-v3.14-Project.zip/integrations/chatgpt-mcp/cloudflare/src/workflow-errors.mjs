/**
 * OWNERSHIP: Model-readable DSD workflow rejection and recovery messages.
 * Does not own: approval, research execution, authentication or storage.
 * Side effects: none; never exposes credentials, SQL or stack traces.
 */
export class WorkflowError extends Error {
 constructor(code,message,missingSteps=[],nextTool='review_dsd_import') {
  super(message);this.code=code;this.missingSteps=missingSteps;this.nextTool=nextTool;
 }
}
export function workflowFailure(error) {
 const known=error instanceof WorkflowError;
 const value={status:'blocked',code:known?error.code:'INVOICE_VALIDATION_FAILED',
  message:known?error.message:'Invoice validation failed. Review the supplied invoice facts before retrying.',
  missingSteps:known?error.missingSteps:['validate_invoice_facts'],
  nextTool:known?error.nextTool:'review_dsd_import',retrySameRequest:known&&error.retrySameRequest===true,
  submitted:known&&error.submitted===null?null:false};
 return {isError:true,structuredContent:value,content:[{type:'text',text:
  value.code+': '+value.message+' Skipped or incomplete steps: '+value.missingSteps.join(', ')+
  '. Next: '+value.nextTool+'. '+(value.submitted===null?
  'Submission status is unconfirmed. Retry only the exact approved request; do not claim success.':
  'This request did not submit an invoice. Complete the missing steps before retrying; do not claim success.')}]};
}
