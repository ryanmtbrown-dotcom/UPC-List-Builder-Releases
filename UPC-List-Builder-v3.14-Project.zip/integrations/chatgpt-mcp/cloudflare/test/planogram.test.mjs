import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync} from 'node:fs';
import {validatePlanogram,verifySourceDigest,validatePlanogramHeader} from '../src/planogram-validate.mjs';
import {createPlanogramQueue} from '../src/planogram-queue.mjs';
const fixture=()=>({
 schemaVersion:'PLANOGRAM_IMPORT_V1',
 source:{planogramId:'S1TAPE04',name:'Tape',sourceIdentityEvidence:'Official Product Report page 10',nominalWidthFt:8,nominalFourFootSections:2,widthEvidence:'Cover page TAPE 8FT'},
 sourceSegments:[{id:'SOURCE-1',ordinal:1,fixtureType:'PEG'}],
 placements:[
  {sourceRowId:'report:1',sku:'12704',upcOrGtin:'036000291452',sourceSegment:'SOURCE-1',fixtureType:'PEG',reportRow:'2',reportColumn:'3',membershipDisposition:'MERCHANDISE'},
  {sourceRowId:'report:2',sku:'12704',sourceSegment:'SOURCE-1',fixtureType:'PEG',reportRow:'3',reportColumn:'4',membershipDisposition:'MERCHANDISE'},
  {sourceRowId:'report:3',sku:null,description:'Promotional sign',sourceSegment:'SOURCE-1',fixtureType:'OTHER',membershipDisposition:'NON_MERCHANDISE'}],
 reconciliation:{sourceReportRows:3,submittedRowRecords:3,merchandiseRows:2,excludedNonMerchandiseRows:1,unresolvedRows:0,distinctMerchandiseSkus:1,unrepresentedRows:0},
 exclusions:[{sourceRowId:'report:3',reason:'Non-merchandise fixture signage'}],unresolved:[],
 manifest:{submissionId:'test-source-1',expectedChunks:1,sourceDigest:null,status:'COMPLETE'}
});
const clone=x=>structuredClone(x);
function harness(){
 const sql=new DatabaseSync(':memory:');
 sql.exec(readFileSync(new URL('../migrations/0002_planogram_queue.sql',import.meta.url),'utf8'));
 const binding={prepare(statement){let params=[];const op={bind(...x){params=x;return op},async run(){let res=sql.prepare(statement).run(...params);return{meta:{changes:res.changes}}},async first(){return sql.prepare(statement).get(...params)||null},async all(){return{results:sql.prepare(statement).all(...params)}}};return op},
 async batch(commands){sql.exec('BEGIN');try{let o=[];for(let c of commands)o.push(await c.run());sql.exec('COMMIT');return o}catch(e){sql.exec('ROLLBACK');throw e}}};
 return{sql,queue:createPlanogramQueue(binding)};
}
test('AI planogram input is exact and fully reconciled',async()=>{
 const p=validatePlanogram(fixture());assert.equal(p.reconciliation.distinctMerchandiseSkus,1);assert.equal(p.source.nominalFourFootSections,2);
 assert.equal((await verifySourceDigest(p)).length,64);
 const f=x=>validatePlanogram(x);
 let q=clone(p);delete q.source.nominalWidthFt;assert.throws(()=>f(q),/nominalWidthFt/);
 q=clone(p);q.source.nominalFourFootSections=3;assert.throws(()=>f(q),/four-foot section/);
 q=clone(p);delete q.placements[0].reportColumn;assert.throws(()=>f(q),/ROW and COL/);
 q=clone(p);q.placements[0].fixtureZone='ABOVE';assert.throws(()=>f(q),/fixture zone/);
 q=clone(p);q.placements[2].membershipDisposition='MERCHANDISE';assert.throws(()=>f(q),/without verified SKU/);
 q=clone(p);q.placements[1].sourceRowId='report:1';assert.throws(()=>f(q),/Repeated sourceRowId/);
 q=clone(p);q.placements[0].upcOrGtin='036000291450';assert.throws(()=>f(q),/checksum/);
 q=clone(p);q.placements[0].physicalSection='5';assert.throws(()=>f(q),/unsupported field/);
 q=clone(p);q.reconciliation.distinctMerchandiseSkus=2;assert.throws(()=>f(q),/distinctMerchandiseSkus/);
 q=clone(p);q.reconciliation.unrepresentedRows=1;q.reconciliation.sourceReportRows=4;assert.throws(()=>f(q),/cannot mark complete/);
 q=clone(p);q.exclusions=[];assert.throws(()=>f(q),/exclusions/);
 q=clone(p);q.manifest.sourceDigest='0'.repeat(64);await assert.rejects(()=>verifySourceDigest(f(q)),/digest mismatch/);
});
test('staging private per owner, idempotent, no PDF and no partial chunk visibility',async()=>{
 const {sql,queue}=harness();try{
  const a=await queue.store('github:111',fixture());
  const b=await queue.store('github:111',fixture());assert.equal(a.batchId,b.batchId);
  assert.equal((await queue.list('github:222')).length,0);
  assert.equal(await queue.get('github:222',a.batchId),null);
  assert.equal(await queue.acknowledge('github:222',a.batchId),false);
  assert.equal((await queue.get('github:111',a.batchId)).placements.length,3);
  assert.equal(await queue.acknowledge('github:111',a.batchId),true);
  assert.equal(await queue.acknowledge('github:111',a.batchId),true);
  assert.equal((await queue.list('github:111')).length,0);
  const c=await queue.store('github:222',fixture());assert.notEqual(c.batchId,a.batchId);
 }finally{sql.close()}
});
test('large planogram chunks stay private until complete, reject divergent retries',async()=>{
 const {sql,queue}=harness();try{
  let input=fixture(),header={...input,manifest:{...input.manifest,expectedChunks:2}};delete header.placements;
  assert.equal(validatePlanogramHeader(header).manifest.expectedChunks,2);
  const session=await queue.begin('github:111',header);const rows=input.placements;
  await queue.append('github:111',session.sessionId,0,[rows[0]]);
  assert.equal((await queue.list('github:111')).length,0);
  await assert.rejects(()=>queue.finalize('github:111',session.sessionId),/chunks missing/);
  await assert.rejects(()=>queue.append('github:222',session.sessionId,1,rows.slice(1)),/unavailable/);
  await assert.rejects(()=>queue.append('github:111',session.sessionId,0,[rows[1]]),/replay differs/);
  await queue.append('github:111',session.sessionId,1,rows.slice(1));
  const batch=await queue.finalize('github:111',session.sessionId);
  assert.equal(batch.sourceRowCount,3);assert.equal((await queue.list('github:111')).length,1);
  assert.equal((await queue.get('github:111',batch.batchId)).placements.length,3);
  await assert.rejects(()=>queue.finalize('github:111',session.sessionId),/unavailable/);
 }finally{sql.close()}
});
