/**
 * OWNERSHIP: Optional ChatGPT MCP HTTP transport, OAuth resource authentication and device API.
 * Does not own: DSD workbook rules, application settings, Android secrets, or upstream invoices.
 * Side effects: authenticated HTTPS-facing requests and durable queue calls only.
 * Deploy behind HTTPS; never place OAuth secrets in client JavaScript or this source tree.
 */
import { createServer } from 'node:http';
import { Readable } from 'node:stream';
import { createRemoteJWKSet, jwtVerify } from 'jose';
import { createMcpHandler, McpServer } from '@modelcontextprotocol/server';
import * as z from 'zod/v4';
import { createStore } from './store.mjs';

const publicUrl = new URL(process.env.MCP_PUBLIC_URL || '');
const issuer = process.env.OAUTH_ISSUER;
const jwksUrl = process.env.OAUTH_JWKS_URL;
if (publicUrl.protocol !== 'https:' || publicUrl.pathname !== '/mcp' || !issuer || !jwksUrl)
  throw Error('Configure MCP_PUBLIC_URL=https://hostname/mcp, OAUTH_ISSUER and OAUTH_JWKS_URL.');
if (new URL(jwksUrl).protocol !== 'https:' || new URL(issuer).protocol !== 'https:')
  throw Error('OAuth issuer and JWKS must use HTTPS.');
const verifyKeys = createRemoteJWKSet(new URL(jwksUrl), { timeoutDuration: 3000, cooldownDuration: 10000 });
const store = createStore(process.env.MCP_DB_PATH || './data/chatgpt-imports.sqlite');
const allowedOrigins = new Set(['https://appassets.androidplatform.net',
  ...(process.env.MCP_ALLOWED_ORIGINS || '').split(',').map(x=>x.trim()).filter(Boolean)]);
const secureResponseHeaders = { 'Cache-Control':'no-store', 'X-Content-Type-Options':'nosniff' };
const pairingThrottle = new Map();
const maxBody = 256 * 1024;
const field = z.union([z.string(),z.number()]).optional();
const item = z.object({
  upc:field, department:field, description:field, mfg:field, serialNumber:field,
  orderMultiple:field, caseCost:field, retailMethod:field, retail:field, markup:field
}).strict();
const invoice = z.object({
  primaryVendor:z.string(), secondaryVendor:field, invoiceNumber:z.string(),
  department:field, defaultRetailMethod:field, defaultMarkup:field
}).strict();
const batch = z.object({ sourceFilename:z.string().optional(), invoice,
  items:z.array(item).min(1).max(200), warnings:z.array(z.string()).max(50).optional() }).strict();
const oauthScheme = [{ type: 'oauth2', scopes: ['dsd:write'] }];

const mcp = createMcpHandler(({ authInfo }) => {
  const subject = authInfo?.clientId;
  const server = new McpServer({ name: 'UPC List Builder DSD Imports', version: '1.0.0' });
  const result = object => ({content:[{type:'text',text:JSON.stringify(object)}],structuredContent:object});
  server.registerTool('create_dsd_pairing_code', {
    title: 'Connect UPC List Builder', description: 'Generate a one-time code to enter in UPC List Builder on your own device. Never share the code with another person.',
    inputSchema:z.object({}).strict(), securitySchemes:oauthScheme
  },async () => result(store.createPairing(subject)));
  server.registerTool('submit_dsd_import', {
    title: 'Stage ACE New DSD invoice', description: 'Stage extracted supplier PDF product data for review in UPC List Builder. Do not guess absent UPCs, manufacturer numbers, departments, costs, case units, or retail; use empty strings. Case cost is for the entire order multiple. This does NOT save or export products in the phone app.',
    inputSchema:batch, securitySchemes:oauthScheme
  },async args => {
    try{return result(store.submit(subject,args));}
    catch(e){return {isError:true,content:[{type:'text',text:e.message}]};}
  });
  server.registerTool('get_dsd_import_status', {
    title:'Check DSD import receipt', description:'Check whether your own pending batch was acknowledged as imported by UPC List Builder.',
    inputSchema:z.object({batchId:z.string().uuid()}).strict(), securitySchemes:oauthScheme
  },async ({batchId}) => result(store.status(subject,batchId)||{status:'not_found'}));
  return server;
},{responseMode:'json'});

function send(res, status, payload, extra = {}) {
  if (res.headersSent) return;
  res.writeHead(status, {'Content-Type':'application/json; charset=utf-8',...secureResponseHeaders,...extra});
  res.end(JSON.stringify(payload));
}
function cors(req,res) {
  const origin=req.headers.origin;
  if (origin && !allowedOrigins.has(origin)) {send(res,403,{error:'Origin not permitted'});return false;}
  if (origin) {
    res.setHeader('Access-Control-Allow-Origin',origin);
    res.setHeader('Vary','Origin');
    res.setHeader('Access-Control-Allow-Headers','Authorization, Content-Type');
    res.setHeader('Access-Control-Allow-Methods','GET, POST, DELETE, OPTIONS');
  }
  return true;
}
function bearer(req) {
  const auth=req.headers.authorization || '';
  return /^Bearer [A-Za-z0-9_-]+(?:\.[A-Za-z0-9_-]+){0,2}$/.test(auth)?auth.slice(7):null;
}
async function oauthIdentity(req) {
  const token = bearer(req);
  if (!token) return null;
  try {
    const {payload} = await jwtVerify(token,verifyKeys,{issuer,audience:publicUrl.href,algorithms:['RS256','ES256']});
    if (typeof payload.sub!=='string'||!(String(payload.scope||'').split(' ').includes('dsd:write'))) return null;
    return {subject:payload.sub,token};
  } catch (_) {return null;}
}
async function jsonInput(req) {
  let body='',total=0;
  for await (const chunk of req) {
    total+=chunk.length;if (total>maxBody) throw Error('Payload too large.');
    body+=chunk.toString('utf8');
  }
  return JSON.parse(body);
}
function mayAttempt(req) {
  // Single-instance bounded throttle; use an edge rate limit as well in production.
  const ip = String(req.socket.remoteAddress||'unknown'),t=Date.now();
  for (const [key, entry] of pairingThrottle) if (entry.until<t) pairingThrottle.delete(key);
  const entry=pairingThrottle.get(ip)||{count:0,until:t+600_000};
  if (entry.count>=8)return false;
  entry.count+=1;pairingThrottle.set(ip,entry);return true;
}
async function route(req,res) {
  try {
    if (req.headers.host!==publicUrl.host && !(process.env.MCP_LOCAL_HOST==='true' && req.headers.host?.startsWith('127.0.0.1:')))
      return send(res,403,{error:'Host not permitted'});
    if (!cors(req,res))return;
    if (req.method==='OPTIONS') {res.writeHead(204,secureResponseHeaders);res.end();return;}
    const path = new URL(req.url||'/',publicUrl.origin).pathname;
    if (req.method==='GET'&&path==='/health')return send(res,200,{status:'ok'});
    if (req.method==='GET'&&(path==='/.well-known/oauth-protected-resource'||path==='/.well-known/oauth-protected-resource/mcp'))
      return send(res,200,{resource:publicUrl.href,authorization_servers:[issuer],scopes_supported:['dsd:write']});
    if (path==='/mcp') {
      const auth = await oauthIdentity(req);
      if (!auth) return send(res,401,{error:'OAuth authorization required'},
        {'WWW-Authenticate':`Bearer resource_metadata="${publicUrl.origin}/.well-known/oauth-protected-resource", scope="dsd:write"`});
      const request=new Request(publicUrl.href,{method:req.method,headers:req.headers,
        ...(req.method==='GET'||req.method==='HEAD'?{}:{body:req,duplex:'half'})});
      const response=await mcp.fetch(request,{authInfo:{clientId:auth.subject,scopes:['dsd:write'],token:auth.token}});
      res.writeHead(response.status,Object.fromEntries(response.headers.entries()));
      if(response.body) Readable.fromWeb(response.body).pipe(res);else res.end();
      return;
    }
    if (path==='/api/v1/device/claim' && req.method==='POST') {
      if (!mayAttempt(req))return send(res,429,{error:'Too many attempts'});
      const input=await jsonInput(req), claimed=store.claim(input.code);
      return claimed?send(res,200,claimed):send(res,400,{error:'Invalid or expired pairing code'});
    }
    const token=bearer(req),subject=store.deviceOwner(token);
    if (!subject)return send(res,401,{error:'Not connected'});
    if (path==='/api/v1/device'&&req.method==='DELETE') {
      store.revoke(token);return send(res,200,{disconnected:true});
    }
    if (path==='/api/v1/batches'&&req.method==='GET')return send(res,200,{batches:store.list(subject)});
    const match=path.match(/^\/api\/v1\/batches\/([0-9a-f-]{36})(\/ack)?$/i);
    if (match) {
      if(req.method==='GET'&&!match[2]) {
        const record=store.get(subject,match[1]);
        return record?send(res,200,record):send(res,404,{error:'Batch not found'});
      }
      if(req.method==='POST'&&match[2]) {
        return store.acknowledge(subject,match[1])?send(res,200,{imported:true}):send(res,404,{error:'Batch not pending'});
      }
    }
    send(res,404,{error:'Not found'});
  } catch(e) {send(res,400,{error:e?.message==='Payload too large.'?'Payload too large.':'Invalid request'});}
}
const server=createServer((req,res)=>{void route(req,res);});
const port=Number(process.env.PORT||8787);
server.listen(port,process.env.HOST||'127.0.0.1');
process.on('SIGTERM',()=>{server.close();void mcp.close();store.close();});
