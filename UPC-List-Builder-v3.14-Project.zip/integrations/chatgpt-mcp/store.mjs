/**
 * OWNERSHIP: ChatGPT MCP bridge durable pending-import queue.
 * Owns: per-user device pairing, hashed device tokens, idempotent DSD batches, acknowledgments.
 * Does not own: OAuth verification, MCP transport, UPC List Builder/IndexedDB persistence, or pricing.
 * Side effects: SQLite storage only. All user keys are opaque OAuth subject IDs.
 */
import { createHash, randomBytes, randomUUID } from 'node:crypto';
import { DatabaseSync } from 'node:sqlite';
import { mkdirSync } from 'node:fs';
import { dirname } from 'node:path';

const digest = value => createHash('sha256').update(value).digest('hex');
const random = bytes => randomBytes(bytes).toString('base64url');
const now = () => Date.now();
const MAX_ITEMS = 200;
export function validateBatch(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) throw Error('Invoice payload must be an object.');
  const invoice = input.invoice;
  if (!invoice || typeof invoice !== 'object' || Array.isArray(invoice)) throw Error('Invoice metadata is required.');
  const clean = (value, max = 240) => {
    if (value === null || value === undefined) return '';
    if (typeof value !== 'string' && typeof value !== 'number') throw Error('Invalid invoice field type.');
    const text = String(value).trim();
    if (text.length > max) throw Error('Invoice field too long.');
    return text;
  };
  if (!Array.isArray(input.items) || input.items.length < 1 || input.items.length > MAX_ITEMS)
    throw Error('Invoice must contain 1–200 items.');
  const items = input.items.map((item, index) => {
    if (!item || typeof item !== 'object' || Array.isArray(item)) throw Error(`Invalid item ${index + 1}.`);
    const fields = ['upc','department','description','mfg','serialNumber','orderMultiple','caseCost','retailMethod','retail','markup'];
    return Object.fromEntries(fields.map(field => [field, clean(item[field], field === 'description' ? 400 : 120)]));
  });
  const normalized = {
    sourceFilename: clean(input.sourceFilename, 200),
    invoice: Object.fromEntries(['primaryVendor','secondaryVendor','invoiceNumber','department','defaultRetailMethod','defaultMarkup']
      .map(field => [field, clean(invoice[field], 200)])),
    items,
    warnings: Array.isArray(input.warnings) ? input.warnings.slice(0, 50).map(w => clean(w, 500)) : []
  };
  if (!normalized.invoice.primaryVendor || !normalized.invoice.invoiceNumber)
    throw Error('Manufacturer and invoice number are required; ask the user to identify them.');
  return normalized;
}
export function createStore(filename) {
  if (filename !== ':memory:') mkdirSync(dirname(filename), { recursive: true, mode: 0o700 });
  const db = new DatabaseSync(filename);
  db.exec(`PRAGMA journal_mode=WAL;
    CREATE TABLE IF NOT EXISTS pairings(hash TEXT PRIMARY KEY, owner TEXT NOT NULL, expires INTEGER NOT NULL);
    CREATE TABLE IF NOT EXISTS devices(hash TEXT PRIMARY KEY, owner TEXT NOT NULL, created INTEGER NOT NULL);
    CREATE TABLE IF NOT EXISTS batches(id TEXT PRIMARY KEY, owner TEXT NOT NULL, digest TEXT NOT NULL,
      payload TEXT NOT NULL, state TEXT NOT NULL, created INTEGER NOT NULL, updated INTEGER NOT NULL,
      UNIQUE(owner, digest));
    CREATE INDEX IF NOT EXISTS batches_owner_state ON batches(owner, state, created);`);
  const DAY = 86_400_000;
  function prune() {
    const t=now();
    db.prepare("DELETE FROM pairings WHERE expires < ?").run(t);
    db.prepare("DELETE FROM batches WHERE state='imported' AND updated < ?").run(t-30*DAY);
    db.prepare("DELETE FROM batches WHERE state='pending' AND created < ?").run(t-90*DAY);
    db.prepare("DELETE FROM devices WHERE created < ?").run(t-180*DAY);
  }
  const owner = subject => {
    if (typeof subject !== 'string' || !subject || subject.length > 500) throw Error('Invalid account identity.');
    return subject;
  };
  function createPairing(subject) {
    owner(subject);
    prune();
    const code = random(18);
    db.prepare('INSERT INTO pairings(hash,owner,expires) VALUES (?,?,?)')
      .run(digest(code), subject, now() + 10 * 60_000);
    return { code, expiresInSeconds: 600 };
  }
  function claim(code) {
    if (typeof code !== 'string' || !/^[A-Za-z0-9_-]{24}$/.test(code)) return null;
    const record = db.prepare('DELETE FROM pairings WHERE hash=? AND expires>? RETURNING owner')
      .get(digest(code), now());
    if (!record) return null;
    const token = random(32);
    db.prepare('INSERT INTO devices(hash,owner,created) VALUES (?,?,?)').run(digest(token), record.owner, now());
    return { token };
  }
  function deviceOwner(token) {
    prune();
    if (typeof token !== 'string' || !/^[A-Za-z0-9_-]{43}$/.test(token)) return null;
    return db.prepare('SELECT owner FROM devices WHERE hash=?').get(digest(token))?.owner || null;
  }
  function revoke(token) {
    if (!deviceOwner(token)) return false;
    return db.prepare('DELETE FROM devices WHERE hash=?').run(digest(token)).changes === 1;
  }
  function submit(subject, input) {
    prune();
    owner(subject);
    const payload = validateBatch(input), encoded = JSON.stringify(payload), hash = digest(encoded), id = randomUUID(), time = now();
    db.prepare('INSERT OR IGNORE INTO batches(id,owner,digest,payload,state,created,updated) VALUES (?,?,?,?,?,?,?)')
      .run(id, subject, hash, encoded, 'pending', time, time);
    const record = db.prepare('SELECT id,state FROM batches WHERE owner=? AND digest=?').get(subject, hash);
    return { id: record.id, state: record.state, itemCount: payload.items.length };
  }
  function list(subject) {
    prune();
    owner(subject);
    return db.prepare("SELECT id,created,state,payload FROM batches WHERE owner=? AND state='pending' ORDER BY created ASC LIMIT 50")
      .all(subject).map(row => ({ id: row.id, created: row.created, state: row.state,
        manufacturer: JSON.parse(row.payload).invoice.primaryVendor,
        invoiceNumber: JSON.parse(row.payload).invoice.invoiceNumber,
        itemCount: JSON.parse(row.payload).items.length }));
  }
  function get(subject, id) {
    prune();
    owner(subject);
    if (typeof id !== 'string') return null;
    const row = db.prepare('SELECT id,state,payload FROM batches WHERE id=? AND owner=?').get(id, subject);
    return row ? { id: row.id, state: row.state, ...JSON.parse(row.payload) } : null;
  }
  function status(subject, id) {
    prune();
    owner(subject);
    return db.prepare('SELECT id,state,updated FROM batches WHERE id=? AND owner=?').get(id, subject) || null;
  }
  function acknowledge(subject, id) {
    owner(subject);
    const updated = db.prepare("UPDATE batches SET state='imported',updated=? WHERE id=? AND owner=? AND state='pending'")
      .run(now(), id, subject);
    return updated.changes === 1 || status(subject, id)?.state === 'imported';
  }
  return Object.freeze({ createPairing, claim, deviceOwner, revoke, submit, list, get, status, acknowledge, close: () => db.close() });
}
