import test from 'node:test';
import assert from 'node:assert/strict';
import { createStore, validateBatch } from '../store.mjs';

const example = () => ({
 sourceFilename:'Vendor-123.pdf',
 invoice:{primaryVendor:'ACME',secondaryVendor:'',invoiceNumber:'INV-123',department:'72',defaultRetailMethod:'DIRECT'},
 items:[{upc:'012345678901',department:'72',description:'Example',mfg:'A100',orderMultiple:2,caseCost:'10.00',retail:'8.99'}],
 warnings:['Review vendor part number']
});

test('one-use 24-character pairing and hashed device token', () => {
 const store=createStore(':memory:');
 try{
  const pair=store.createPairing('owner-a');
  assert.match(pair.code,/^[A-Za-z0-9_-]{24}$/);
  assert.equal(store.claim('wrong'),null);
  const device=store.claim(pair.code);
  assert.match(device.token,/^[A-Za-z0-9_-]{43}$/);
  assert.equal(store.claim(pair.code),null);
  assert.equal(store.deviceOwner(device.token),'owner-a');
  assert.equal(store.revoke(device.token),true);
  assert.equal(store.deviceOwner(device.token),null);
 }finally{store.close()}
});

test('distinct accounts cannot see or acknowledge each other\'s DSD invoices',()=>{
 const store=createStore(':memory:');
 try{
  const batch=store.submit('owner-a',example());
  assert.equal(store.get('owner-b',batch.id),null);
  assert.equal(store.status('owner-b',batch.id),null);
  assert.equal(store.acknowledge('owner-b',batch.id),false);
  assert.equal(store.list('owner-b').length,0);
  assert.equal(store.list('owner-a').length,1);
  assert.equal(store.get('owner-a',batch.id).items[0].upc,'012345678901');
  assert.equal(store.acknowledge('owner-a',batch.id),true);
  assert.equal(store.acknowledge('owner-a',batch.id),true);
  assert.equal(store.list('owner-a').length,0);
  assert.equal(store.status('owner-a',batch.id).state,'imported');
 }finally{store.close()}
});

test('repeated requests are idempotent and cannot create duplicate DSD batches',()=>{
 const store=createStore(':memory:');
 try{
  const a=store.submit('owner-a',example()),b=store.submit('owner-a',example());
  assert.equal(a.id,b.id);
  assert.equal(store.list('owner-a').length,1);
  assert.notEqual(store.submit('owner-b',example()).id,a.id);
 }finally{store.close()}
});

test('untrusted invoice fields are bounded and absent values stay blank, not zero',()=>{
 const input=example();
 delete input.items[0].retail;
 const cleaned=validateBatch(input);
 assert.equal(cleaned.items[0].retail,'');
 assert.equal(cleaned.items[0].upc,'012345678901');
 assert.throws(()=>validateBatch({...input,items:[]}),/1–200/);
 assert.throws(()=>validateBatch({...input,items:Array(201).fill(input.items[0])}),/1–200/);
 assert.throws(()=>validateBatch({...input,items:[{description:'x'.repeat(401)}]}),/too long/);
});
