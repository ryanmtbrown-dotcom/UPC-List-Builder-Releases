#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
OUT="${1:-}"
[[ -n "$OUT" ]] || { echo 'Usage: ./package-release.sh /absolute/path/project.zip' >&2; exit 2; }
[[ "$OUT" = /* ]] || OUT="$PWD/$OUT"
OUT="$(realpath -m "$OUT")"
[[ "$OUT" != "$ROOT"/* ]] || { echo 'ERROR: output ZIP must be outside the project tree' >&2; exit 1; }

cd "$ROOT"
./verify-project.sh
if [[ -d .git ]]; then git diff --check; fi

rm -f "$OUT"
# Leading dot is intentional: it includes hidden project paths such as .github.
zip -q -r "$OUT" . \
  -x './.git/*' './.git' './*.zip' './build/*' './app/build/*' './release-out/*' './release-out' './.gradle/*' \
  './integrations/chatgpt-mcp/node_modules/*' './integrations/chatgpt-mcp/cloudflare/node_modules/*' \
  './integrations/chatgpt-mcp/cloudflare/.wrangler/*' './integrations/chatgpt-mcp/cloudflare/build-check/*'

required=(
  '.github/workflows/build-apk.yml'
  'AI_START_HERE.md'
  'DOCUMENTATION_INDEX.md'
  'CURRENT_ARCHITECTURE_AUTHORITY.md'
  'SOURCE_OWNERSHIP_MAP.md'
  'DEPLOYMENT_CONTRACT.md'
  'TERMUX_DEPLOYMENT_CONTRACT.md'
  'scripts/sync-release-identity.mjs'
  'verify-project.sh'
  'deploy-termux.sh'
  'package-release.sh'
  'install-release-termux.sh'
  'settings.gradle.kts'
  'build.gradle.kts'
  'gradle.properties'
  'app/build.gradle.kts'
  'app/src/main/AndroidManifest.xml'
  'app/src/main/java/com/rmtb/upclistbuilder/MainActivity.kt'
  'app/src/main/java/com/rmtb/upclistbuilder/AceNetProductionCoordinator.kt'
  'app/src/main/java/com/rmtb/upclistbuilder/AceNetProductionIncidentController.kt'
  'app/src/main/java/com/rmtb/upclistbuilder/AceNetRuntimeClassifier.kt'
  'app/src/main/java/com/rmtb/upclistbuilder/AppUpdateService.kt'
  'app/src/main/java/com/rmtb/upclistbuilder/NativeFileExportService.kt'
  'app/src/main/java/com/rmtb/upclistbuilder/NativeDiagnosticJournal.kt'
  'app/src/main/java/com/rmtb/upclistbuilder/NativeDiagnosticRecordFormatter.kt'
  'app/src/main/java/com/rmtb/upclistbuilder/AceNetSessionManager.kt'
  'app/src/main/java/com/rmtb/upclistbuilder/AceNetRetrievalService.kt'
  'ACENET_SESSION_RETRIEVAL_BOUNDARY_CONTRACT.md'
  'app/src/main/assets/www/app.v059.js'
  'app/src/main/assets/www/diagnostics/diagnostic-repository.js'
  'app/src/main/assets/www/diagnostics/diagnostic-journal.js'
  'app/src/main/assets/www/diagnostics/diagnostic-service.js'
  'app/src/main/assets/www/diagnostics/diagnostic-operation-service.js'
  'app/src/main/assets/www/diagnostics/diagnostic-export-service.js'
  'app/src/main/assets/www/diagnostics/diagnostic-ui-controller.js'
  'app/src/main/assets/www/styles.v059.css'
  'app/src/main/assets/www/application/dialogs.css'
  'app/src/main/assets/www/dsd/dsd.css'
  'app/src/main/assets/www/administration/data-management.css'
  'app/src/main/assets/www/misc/misc-workspace.css'
  'app/src/main/assets/www/service-worker.js'
  'app/src/main/assets/www/manifest.webmanifest'
)

mapfile -t ZIP_ENTRIES < <(unzip -Z1 "$OUT" | sed 's#^\./##')
# Do not use an early-closing grep pipeline here: under pipefail, grep -q can
# terminate after a match and cause the producer to receive SIGPIPE, creating
# a false "missing entry" failure. Compare the captured entry array directly.
for f in "${required[@]}"; do
  found=false
  for entry in "${ZIP_ENTRIES[@]}"; do
    if [[ "$entry" == "$f" ]]; then
      found=true
      break
    fi
  done
  if [[ "$found" != true ]]; then
    echo "ERROR: final ZIP missing required entry: $f" >&2
    exit 1
  fi
done
for entry in "${ZIP_ENTRIES[@]}"; do
  if [[ "$entry" =~ (^|/)\.git(/|$) ]]; then
    echo 'ERROR: final ZIP contains forbidden .git metadata' >&2
    exit 1
  fi
done

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
unzip -q "$OUT" -d "$TMP"
[[ -f "$TMP/verify-project.sh" ]] || { echo 'ERROR: extracted ZIP has no verify-project.sh' >&2; exit 1; }
chmod +x "$TMP/verify-project.sh" "$TMP/deploy-termux.sh" "$TMP/package-release.sh" "$TMP/install-release-termux.sh"
(
  cd "$TMP"
  ./verify-project.sh
)

SHA="$(sha256sum "$OUT" | awk '{print $1}')"
echo 'FINAL RELEASE ZIP AUDIT PASS'
echo "ZIP: $OUT"
echo 'Confirmed hidden workflow: .github/workflows/build-apk.yml'
echo 'Clean extraction verification: PASS'
echo 'Forbidden .git metadata: ABSENT'
echo "SHA-256: $SHA"
