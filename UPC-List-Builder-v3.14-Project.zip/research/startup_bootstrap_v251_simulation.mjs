import assert from 'node:assert/strict';
const S={BOOTSTRAP:'BOOTSTRAP',AUTH:'AUTH',DISCOVER:'DISCOVER',PRIME:'PRIME',READY:'READY',DONE:'DONE'};
class Startup{
 constructor(){this.s=S.BOOTSTRAP;this.auth=false;this.health='UNKNOWN';this.recovery=0;this.workerReady=false;this.actions=[];}
 start({savedCredentials=true,network='AVAILABLE'}={}){if(!savedCredentials)return this.done('UNVERIFIED');if(network==='UNAVAILABLE')return this.done('UNVERIFIED');this.actions.push('DISCOVER_TEMPLATE');this.s=S.DISCOVER}
 accept(e){if(this.s===S.DONE)return;
  if(e.type==='AUTH_REQUIRED'){if(this.recovery++)return this.done('UNVERIFIED');this.s=S.AUTH;this.actions.push('AUTHENTICATE_ONCE');return}
  if(e.type==='AUTHENTICATED'){this.auth=true;this.s=S.DISCOVER;this.actions.push('DISCOVER_TEMPLATE');return}
  if(e.type==='TEMPLATE'){assert.match(e.url,/^https:\/\/retailer\.aceservices\.com\/ItemDetailV2\/ItemDetail\/ItemDetailRedesign\.aspx\?/i);this.s=S.PRIME;this.actions.push('WORKER_PRIME_PRICE_50177');return}
  if(e.type==='WORKER_FOUND'){if(e.sku!=='50177'||!e.price)return this.done('UNVERIFIED');this.auth=true;this.workerReady=true;this.health='ONLINE';this.s=S.READY;return this.done('SIGNED_IN')}
  if(e.type==='HTTP_5XX'){this.health='DOWN';return this.done('UNVERIFIED')}
  if(e.type==='NETWORK_ERROR'||e.type==='WORKER_TIMEOUT'||e.type==='WORKER_MISMATCH'||e.type==='BACKGROUND'){this.health='UNKNOWN';return this.done('UNVERIFIED')}
 }
 done(status){this.status=status;this.s=S.DONE;this.actions.push('COMPLETE_'+status)}
}
const cases=[
 ['retained session', [{type:'TEMPLATE',url:'https://retailer.aceservices.com/ItemDetailV2/ItemDetail/ItemDetailRedesign.aspx?storesession=1&sku=50177&isDirectSku=Y'},{type:'WORKER_FOUND',sku:'50177',price:'12.99'}],'SIGNED_IN','ONLINE'],
 ['login once', [{type:'AUTH_REQUIRED'},{type:'AUTHENTICATED'},{type:'TEMPLATE',url:'https://retailer.aceservices.com/ItemDetailV2/ItemDetail/ItemDetailRedesign.aspx?storesession=1&sku=50177&isDirectSku=Y'},{type:'WORKER_FOUND',sku:'50177',price:'12.99'}],'SIGNED_IN','ONLINE'],
 ['worker mismatch', [{type:'TEMPLATE',url:'https://retailer.aceservices.com/ItemDetailV2/ItemDetail/ItemDetailRedesign.aspx?storesession=1&sku=50177&isDirectSku=Y'},{type:'WORKER_MISMATCH'}],'UNVERIFIED','UNKNOWN'],
 ['worker timeout', [{type:'TEMPLATE',url:'https://retailer.aceservices.com/ItemDetailV2/ItemDetail/ItemDetailRedesign.aspx?storesession=1&sku=50177&isDirectSku=Y'},{type:'WORKER_TIMEOUT'}],'UNVERIFIED','UNKNOWN'],
 ['background', [{type:'BACKGROUND'}],'UNVERIFIED','UNKNOWN'],
 ['observed server 503', [{type:'HTTP_5XX'}],'UNVERIFIED','DOWN']
];
for(const [name,events,status,health] of cases){const x=new Startup();x.start();for(const e of events)x.accept(e);assert.equal(x.status,status,name);assert.equal(x.health,health,name);if(status==='SIGNED_IN')assert.equal(x.workerReady,true,name);console.log(name,'PASS',x.actions.join(' -> '),status,health)}
const offline=new Startup();offline.start({network:'UNAVAILABLE'});assert.equal(offline.status,'UNVERIFIED');assert.equal(offline.health,'UNKNOWN');console.log('offline gate PASS');
console.log('v2.51 startup bootstrap simulation PASS');