import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';

const ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const CHECK=process.argv.includes('--check');
const read=rel=>fs.readFileSync(path.join(ROOT,rel),'utf8');
const write=(rel,value)=>fs.writeFileSync(path.join(ROOT,rel),value);
const gradle=read('gradle.properties');
const version=gradle.match(/^UPC_VERSION_NAME=(.+)$/m)?.[1]?.trim();
const buildId=gradle.match(/^UPC_BUILD_ID=(.+)$/m)?.[1]?.trim();
if(!version||!buildId)throw new Error('gradle.properties is missing UPC_VERSION_NAME or UPC_BUILD_ID.');

const desired=new Map();
let app=read('app/src/main/assets/www/app.v059.js');
if(!/const UPC_RELEASE=Object\.freeze\(\{version:'[^']+',build:'[^']+'\}\);/.test(app))throw new Error('app.v059.js release marker is missing.');
app=app.replace(/const UPC_RELEASE=Object\.freeze\(\{version:'[^']+',build:'[^']+'\}\);/,`const UPC_RELEASE=Object.freeze({version:'${version}',build:'${buildId}'});`);
desired.set('app/src/main/assets/www/app.v059.js',app);

let index=read('app/src/main/assets/www/index.html');
if(!/<meta name="build-id" content="[^"]+">/.test(index))throw new Error('index.html build-id marker is missing.');
index=index.replace(/(<meta name="build-id" content=")[^"]+(">)/,`$1${buildId}$2`).replace(/\?v=[^"']+/g,`?v=${buildId}`);
desired.set('app/src/main/assets/www/index.html',index);

let sw=read('app/src/main/assets/www/service-worker.js');
if(!/^const BUILD_ID='[^']+';/m.test(sw)||!/^const CACHE='[^']+';/m.test(sw))throw new Error('service-worker identity markers are missing.');
sw=sw.replace(/^const BUILD_ID='[^']+';/m,`const BUILD_ID='${buildId}';`)
  .replace(/^const CACHE='[^']+';/m,`const CACHE='upc-list-builder-${buildId}';`)
  .replace(/\?v=[^']+/g,`?v=${buildId}`)
  .replace(/,'\.\/build\.json'/,'');
desired.set('app/src/main/assets/www/service-worker.js',sw);

let manifest=read('app/src/main/assets/www/manifest.webmanifest').replace(/\?v=[^"]+/g,`?v=${buildId}`);
desired.set('app/src/main/assets/www/manifest.webmanifest',manifest);

const legacyBuild=path.join(ROOT,'app/src/main/assets/www/build.json');
const drift=[];
for(const [rel,want] of desired){
  const have=read(rel);
  if(have!==want){
    if(CHECK)drift.push(rel);
    else write(rel,want);
  }
}
if(fs.existsSync(legacyBuild)){
  if(CHECK)drift.push('app/src/main/assets/www/build.json (obsolete)');
  else fs.unlinkSync(legacyBuild);
}
if(CHECK&&drift.length){
  console.error('Release identity synchronization required: '+drift.join(', '));
  process.exit(1);
}
console.log(CHECK?'Release identity synchronization check PASS':'Release identity synchronized from gradle.properties');
