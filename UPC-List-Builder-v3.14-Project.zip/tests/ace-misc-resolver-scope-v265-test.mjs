import fs from 'node:fs';
import assert from 'node:assert/strict';
import {readWebRuntimeSource,readNativeRuntimeSource,findJsFunction} from './helpers/runtime-source-tree.mjs';

const web=readWebRuntimeSource(),native=readNativeRuntimeSource();
const app=web,db=fs.readFileSync('app/src/main/assets/www/db.js','utf8'),workflow=fs.readFileSync('app/src/main/assets/www/library-workflow-v093.js','utf8'),kt=native;
const runtimeResolver=fs.readFileSync('app/src/main/assets/www/misc/misc-runtime-resolver.js','utf8'),readiness=fs.readFileSync('app/src/main/assets/www/diagnostics/runtime-readiness-service.js','utf8'),shell=fs.readFileSync('app/src/main/assets/www/application/application-shell.js','utf8');
const gradle=fs.readFileSync('gradle.properties','utf8');


const manual=findJsFunction('performAceMiscLookup');
assert.match(manual,/resolveProvider\('ACE_MISC_MANUAL'\)/);
assert.match(manual,/resolveProvider\('ACE_MISC_MANUAL_UPC'\)/);
assert.doesNotMatch(manual,/\bresolveAceMiscSkuCandidate\s*\(/,'Global manual ACE MISC lookup must never call the block-scoped resolver directly.');

const bulk=findJsFunction('processAceMiscBulkSku');
assert.match(bulk,/resolveProvider\('ACE_MISC_BULK'\)/);
assert.doesNotMatch(bulk,/\bresolveAceMiscSkuCandidate\s*\(/,'Bulk ACE MISC lookup must never call the block-scoped resolver directly.');

assert.match(runtimeResolver,/windowRef\.UPCAceMiscResolver=exported/);
assert.match(runtimeResolver,/function requireResolver/);
assert.match(shell,/resolveProvider:miscRuntimeResolver\.requireResolver/,'MISC workspace and verification owners must receive the focused runtime resolver guard through composition.');
assert.match(runtimeResolver,/ace_misc_runtime_resolver_missing/);
assert.match(runtimeResolver,/ace_misc_runtime_resolver_exported/);
assert.match(readiness,/windowRef\.UPCAppRuntimeCapabilities=Object\.freeze/);
assert.match(shell,/aceMiscResolverExport:window\.UPCAceMiscResolver\?\.resolveSkuCandidate/);
assert.match(kt,/window\.UPCAppRuntimeCapabilities\|\|\{\}/);
assert.match(kt,/resolverFunctionType:typeof window\.UPCAceMiscResolver\?\.resolveSkuCandidate/);
assert.doesNotMatch(kt,/resolveAceMiscSkuCandidate:typeof resolveAceMiscSkuCandidate/,'Native probe must not inspect inaccessible block-scoped lexical declarations.');

assert.doesNotMatch(db,/restoreMissingPromotedLocalLibraryRecords|reconcilePromotedLocalLibraryRecord|masterPromotion|lastLocalLibraryPushAt/,'Stage 9 must retire promoted-Master restoration machinery.');
assert.doesNotMatch(workflow,/pushLocalLibraryToMaster|lastLocalLibraryPushAt:promotedAt|masterPromotion:\{status:'PROMOTED'/,'ACE MISC runtime must not depend on Local-to-Master promotion.');
console.log('Stage 9 ACE MISC resolver scope + promotion retirement requirements PASS');
