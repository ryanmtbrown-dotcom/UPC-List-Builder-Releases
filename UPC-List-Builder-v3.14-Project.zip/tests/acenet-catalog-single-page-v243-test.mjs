import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';

const worker=fs.readFileSync('app/src/main/java/com/rmtb/upclistbuilder/PersistentAceNetWorker.kt','utf8');
const marker='val js="""';
const inspectStart=worker.indexOf('private fun inspect(v:WebView)');
const start=worker.indexOf(marker,inspectStart);
const end=worker.indexOf('""".trimIndent()',start);
assert.ok(start>0&&end>start,'persistent worker injected JavaScript must be extractable');
let script=worker.slice(start+marker.length,end);
script=script.replaceAll('$expected',JSON.stringify('12345')).replaceAll('$mode',JSON.stringify('PRODUCTION_MISC_CATALOG'));

const nodes=[];
function node(id,text='',attrs={}){
 return {id,name:attrs.name||'',tagName:attrs.tagName||'SPAN',textContent:text,value:attrs.value||'',options:attrs.options||null,selectedIndex:attrs.selectedIndex??0,parentElement:null,nextElementSibling:null,
  getAttribute(k){return attrs[k]??null},closest(){return null},querySelectorAll(){return[]}};
}
nodes.push(
 node('ctl00_ctl00_contentMainPlaceHolder_MainContent_headerSkuDataBar_lblSkuNr','12345'),
 node('divStrL1L2','$19.99',{'data-retail':'19.99'}),
 node('articleDescription','SPECS'),
 node('omWeight','OM Weight:'),
 node('ctl00_ctl00_contentMainPlaceHolder_MainContent_headerSkuDataBar_lblLongDescr','Test Hammer'),
 node('spnEachCost','12.50'),
 node('ctl00_ctl00_contentMainPlaceHolder_MainContent_headerSkuDataBar_lblMfgNr','MFG-77'),
 node('spnEachOM','4'),
 node('spnEachWeight',''),
 node('ctl00_ctl00_contentMainPlaceHolder_MainContent_headerSkuDataBar_lblComGrpBcrumb','56 - FASTENERS'),
 node('ctl00_ctl00_contentMainPlaceHolder_MainContent_headerSkuDataBar_lblMerchClsBcrumb','576 - DRYWALL/DECK/EXT SCREWS')
);
const upc=node('ctl00_ctl00_contentMainPlaceHolder_MainContent_mainItemData_lvAceItemDetails_ctrl0_ddlUPC','',{tagName:'SELECT',name:'upcSelector',options:[
 {value:'012345678905',textContent:'012345678905'},
 {value:'012345678912',textContent:'012345678912'}
]});
nodes.push(upc);

let observerCallback=null;
class MutationObserver{constructor(cb){observerCallback=cb}observe(){}disconnect(){}}
const results=[],progress=[];
const document={
 documentElement:{},
 getElementById(id){return nodes.find(n=>n.id===id)||null},
 querySelector(sel){if(sel==='[id*=RetailPrice]')return nodes.find(n=>/RetailPrice/i.test(n.id))||null;return null},
 querySelectorAll(sel){
  if(sel==='select')return nodes.filter(n=>n.tagName==='SELECT');
  if(sel==='[id]')return nodes.filter(n=>n.id);
  if(sel==='label,th,td,dt,span,div')return[];
  return[];
 }
};
const context={window:{},document,MutationObserver,JSON,Array,String,RegExp,PersistentAceNetBridge:{result(raw){results.push(JSON.parse(raw))},progress(raw){progress.push(JSON.parse(raw))}}};
context.window=context;
vm.createContext(context);
vm.runInContext(script,context,{filename:'PersistentAceNetWorker.catalog.js'});

assert.equal(results.length,0);
assert.ok(progress.at(-1).missingFields.includes('productGroupNumber'));
assert.ok(progress.at(-1).missingFields.includes('omWeight'),'MISC mode must keep waiting while the exact weight value element is blank, even when a decoy OM Weight label exists');
nodes.push(node('ctl00_ctl00_contentMainPlaceHolder_MainContent_headerSkuDataBar_lblProdGrpBcrumb','01 - CARDED'));
nodes.find(n=>n.id==='spnEachWeight').textContent='2.5 LB';
assert.equal(typeof observerCallback,'function');
observerCallback();
assert.equal(results.length,1);
assert.equal(results[0].catalog.description,'Test Hammer','exact description element must win over unrelated SPECS text');
assert.equal(results[0].catalog.omWeight,'2.5 LB','exact spnEachWeight value must win over OM Weight label text');
assert.equal(results[0].catalog.masterUpc,'012345678905','first selector UPC must remain master');
assert.deepEqual(Array.from(results[0].catalog.allUpcs),['012345678905','012345678912']);
assert.equal((worker.match(/v\.loadUrl\(direct\)/g)||[]).length,1,'one ItemDetail navigation per request');
assert.ok(worker.includes("if($mode==='PRODUCTION_PRICE_UPCS')"),'combined normal enrichment mode missing');
assert.ok(worker.includes("if($mode==='PRODUCTION_UPCS')"),'UPC-only mode missing');
assert.ok(worker.includes("$mode!=='PRODUCTION_CATALOG'&&$mode!=='PRODUCTION_MISC_CATALOG'&&$mode!=='PRODUCTION_REPAIR_CATALOG'"),'catalog family must remain explicit');
assert.ok(worker.includes("if($mode==='PRODUCTION_MISC_CATALOG'||$mode==='PRODUCTION_REPAIR_CATALOG')required.push('omWeight')"),'MISC catalog must require weight');
assert.ok(!worker.includes('setInterval('),'catalog extractor must remain event-driven');
console.log('v2.59 exact ItemDetail catalog elements PASS');
