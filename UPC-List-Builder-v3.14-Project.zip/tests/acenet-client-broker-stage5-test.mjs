import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import {readWebRuntimeSource,readNativeRuntimeSource} from './helpers/runtime-source-tree.mjs';

const source=fs.readFileSync('app/src/main/assets/www/acenet-client.js','utf8');
const app=readWebRuntimeSource();
const priceService=fs.readFileSync('app/src/main/assets/www/lookup/acenet-price-service.js','utf8');
const shell=fs.readFileSync('app/src/main/assets/www/application/application-shell.js','utf8');
const bridge=fs.readFileSync('app/src/main/assets/www/platform/bridge-registration.js','utf8');
const html=fs.readFileSync('app/src/main/assets/www/index.html','utf8');
const kt=readNativeRuntimeSource();

assert.equal((source.match(/new Map\(\)/g)||[]).length,1,'AceNet Client must own one shared request map.');
assert.doesNotMatch(app,/aceNetPriceRequests|aceNetCatalogRequests|aceNetUpcRequests/,'Workflow coordinator must not retain per-capability request maps.');
assert.match(priceService,/function requestPrice\(sku,\{upcEnrichment=false\}=\{\}\)[\s\S]*client\.requestPrice/);
assert.match(shell,/requestCatalog:UPCAceNetClient\.requestCatalog/);
assert.match(shell,/requestUpcs:sku=>UPCAceNetClient\.requestUpcs\(sku\)/);
assert.match(bridge,/UPCNativeAceNetPriceResult:raw=>aceNetClient\.acceptPriceResult\(raw\)/);
assert.match(bridge,/UPCNativeAceNetCatalogResult:raw=>aceNetClient\.acceptCatalogResult\(raw\)/);
assert.match(bridge,/UPCNativeAceNetUpcResult:raw=>aceNetClient\.acceptUpcsResult\(raw\)/);
assert.match(source,/BROKER_TIMEOUT_FALLBACK_MS=52000/);
assert.match(source,/getAceNetProductionBrokerTimeoutMs/,'Installed runtime must derive broker ownership from native timing policy.');

const brokerLoad=html.indexOf('acenet-client.js'),priceServiceLoad=html.indexOf('lookup/acenet-price-service.js'),appLoad=html.indexOf('application/application-shell.js'),normalizationLoad=html.indexOf('identifier-normalization.js');
assert.ok(normalizationLoad>=0&&brokerLoad>normalizationLoad&&priceServiceLoad>brokerLoad&&priceServiceLoad<appLoad,'AceNet Client and focused price service must load after normalization and before app coordinator.');

for(const method of ['lookupAceNetPrice','lookupAceNetPriceWithUpcs','lookupAceNetUpcs','lookupAceNetCatalog','lookupAceNetMiscCatalog','lookupAceNetRepairCatalog']){
 assert.ok(kt.includes(method+'(requestId: String, sku: String)'),'Stage 5 must preserve native bridge '+method);
}

function build(){
 const timers=new Map(),bridgeCalls=[],events=[];
 let nextTimer=1;
 const setTimeoutFake=(fn,ms)=>{const id=nextTimer++;timers.set(id,{fn,ms});return id};
 const clearTimeoutFake=id=>timers.delete(id);
 const native={
  getAceNetProductionBrokerTimeoutMs:()=>52000,
  lookupAceNetPrice:(id,sku)=>bridgeCalls.push({method:'lookupAceNetPrice',id,sku}),
  lookupAceNetPriceWithUpcs:(id,sku)=>bridgeCalls.push({method:'lookupAceNetPriceWithUpcs',id,sku}),
  lookupAceNetUpcs:(id,sku)=>bridgeCalls.push({method:'lookupAceNetUpcs',id,sku}),
  lookupAceNetCatalog:(id,sku)=>bridgeCalls.push({method:'lookupAceNetCatalog',id,sku}),
  lookupAceNetMiscCatalog:(id,sku)=>bridgeCalls.push({method:'lookupAceNetMiscCatalog',id,sku}),
  lookupAceNetRepairCatalog:(id,sku)=>bridgeCalls.push({method:'lookupAceNetRepairCatalog',id,sku})
 };
 const context={window:{AndroidNative:native},Map,Set,Promise,Date,Math,String,Number,JSON,globalThis:null,setTimeout:setTimeoutFake,clearTimeout:clearTimeoutFake};
 context.globalThis=context;
 vm.createContext(context);vm.runInContext(source,context,{filename:'acenet-client.js'});
 const client=context.window.UPCAceNetClient;
 client.configure({
  normalizeSKU:v=>String(v??'').trim().toLowerCase(),
  normalizeUPC:v=>String(v??'').replace(/\D/g,''),
  parsePrice:v=>{const n=Number(String(v??'').replace(/[$,]/g,''));return Number.isFinite(n)&&n>0?n:null},
  diag:(event,payload)=>events.push({event,payload}),
  bridgeProvider:()=>native
 });
 return{client,timers,bridgeCalls,events};
}

{
 const {client,bridgeCalls}=build();
 const p=client.requestPrice('SKU1');
 assert.equal(bridgeCalls[0].method,'lookupAceNetPrice');
 client.acceptPriceResult({requestId:bridgeCalls[0].id,found:true,status:'FOUND',sku:'sku1',price:'$12.34'});
 const r=await p;assert.equal(r.status,'VERIFIED');assert.equal(r.price,12.34);assert.deepEqual(Array.from(r.upcs),[]);
}
{
 const {client,bridgeCalls}=build();
 const p=client.requestPrice('SKU2',{upcEnrichment:true});
 assert.equal(bridgeCalls[0].method,'lookupAceNetPriceWithUpcs');
 client.acceptPriceResult({requestId:bridgeCalls[0].id,found:true,status:'FOUND',sku:'sku2',price:'9.99',catalog:{allUpcs:['012345678905','012345678905','222222222222']}});
 const r=await p;assert.equal(r.status,'VERIFIED');assert.deepEqual(Array.from(r.upcs),['012345678905','222222222222']);
}
{
 const {client,bridgeCalls}=build();
 const first=client.requestPrice('A'),second=client.requestPrice('B');
 const r1=await first;assert.equal(r1.status,'SUPERSEDED');
 client.acceptPriceResult({requestId:bridgeCalls.at(-1).id,found:true,status:'FOUND',sku:'b',price:'1.00'});
 const r2=await second;assert.equal(r2.status,'VERIFIED');
}
{
 const {client,bridgeCalls}=build();
 const p=client.requestPrice('A');
 client.acceptPriceResult({requestId:bridgeCalls[0].id,found:true,status:'FOUND',sku:'wrong',price:'1.00'});
 const r=await p;assert.notEqual(r.status,'VERIFIED');
}
{
 const {client,timers}=build();
 const p=client.requestPrice('TIMEOUT');
 const timer=[...timers.values()][0];assert.equal(timer.ms,52000);timer.fn();
 const r=await p;assert.equal(r.status,'TIMEOUT');
}
{
 const {client,bridgeCalls,timers}=build();
 const p=client.requestUpcs('U1');assert.equal(bridgeCalls[0].method,'lookupAceNetUpcs');assert.equal([...timers.values()][0].ms,52000);
 client.acceptUpcsResult({requestId:bridgeCalls[0].id,found:true,status:'FOUND',sku:'u1',catalog:{allUpcs:['111111111111']}});
 const r=await p;assert.equal(r.status,'VERIFIED');assert.deepEqual(Array.from(r.upcs),['111111111111']);
}
{
 const {client,bridgeCalls}=build();
 const p=client.requestCatalog('C1',{misc:true});assert.equal(bridgeCalls[0].method,'lookupAceNetMiscCatalog');
 client.acceptCatalogResult({requestId:bridgeCalls[0].id,found:true,status:'FOUND',sku:'c1',catalog:{sku:'c1',description:'x'}});
 const r=await p;assert.equal(r.status,'VERIFIED');assert.equal(r.misc,true);assert.equal(r.catalog.description,'x');
}
{
 const {client,bridgeCalls}=build();
 const p=client.requestCatalog('R1',{repair:true});assert.equal(bridgeCalls[0].method,'lookupAceNetRepairCatalog');
 client.acceptCatalogResult({requestId:bridgeCalls[0].id,found:true,status:'FOUND_PARTIAL',sku:'r1',catalog:{sku:'r1'},missingFields:['description']});
 const r=await p;assert.equal(r.status,'VERIFIED_PARTIAL');assert.deepEqual(Array.from(r.missingFields),['description']);
}
{
 const {client,bridgeCalls}=build();
 const p=client.requestCatalog('C2');
 client.acceptCatalogResult({requestId:bridgeCalls[0].id,found:true,status:'FOUND_PARTIAL',sku:'c2',catalog:{sku:'c2'}});
 const r=await p;assert.notEqual(r.status,'VERIFIED_PARTIAL');assert.equal(r.catalog,null);
}
{
 const {client,bridgeCalls}=build();
 assert.equal(client.acceptUpcsResult({requestId:'missing',found:true,status:'FOUND',sku:'x',catalog:{allUpcs:['1']}}),false,'Stale callback must be ignored.');
 const p=client.requestUpcs('CANCEL');client.cancelAll('CANCELLED');const r=await p;assert.equal(r.status,'CANCELLED');
 assert.equal(client.acceptUpcsResult({requestId:bridgeCalls.at(-1).id,found:true,status:'FOUND',sku:'cancel',catalog:{allUpcs:['111111']}}),false,'Callback after cleanup must be stale.');
}

console.log('Stage 5 unified AceNet Client/Broker semantics PASS');
