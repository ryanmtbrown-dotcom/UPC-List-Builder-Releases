import {readNativeRuntimeSource} from './helpers/runtime-source-tree.mjs';
import fs from 'node:fs';
import assert from 'node:assert/strict';

const main=readNativeRuntimeSource();
const worker=fs.readFileSync('app/src/main/java/com/rmtb/upclistbuilder/PersistentAceNetWorker.kt','utf8');

assert.match(main,/wrapper_retailer_target_resolved/,'wrapper must resolve retailer target');
assert.match(main,/sourceView\.loadUrl\(frameUrl\)/,'wrapper must continue the owning transient view only for session readiness');
assert.match(main,/__upcWrapperObserver/,'wrapper readiness must remain event-driven');
assert.match(main,/new MutationObserver\(publish\)/,'wrapper target discovery must wait event-driven rather than poll');
assert.match(main,/AceNetResultBridge\.observedResult/,'wrapper must return readiness through the narrow bridge');
assert.match(main,/transient_retailer_item_page_no_extraction/,'transient retailer page must explicitly skip item extraction');
assert.match(main,/transient_item_evidence_ignored/,'non-wrapper transient item evidence must be ignored');
assert.doesNotMatch(main,/__upcAceObserver/,'retailer item extraction observer must not remain in MainActivity');
assert.doesNotMatch(main,/AndroidNative\.aceNetObservedResult/,'remote AceNet pages must not depend on the full app NativeBridge');
assert.doesNotMatch(main,/result_poll_armed|armAceNetResultWatchdog/,'periodic result polling/watchdog must remain removed');

const inspectStart=main.indexOf('private fun inspectAceNetResult');
const inspectEnd=main.indexOf('private fun handleAceNetObservedResult',inspectStart);
assert.ok(inspectStart>=0&&inspectEnd>inspectStart,'wrapper readiness inspector missing');
const inspect=main.slice(inspectStart,inspectEnd);
assert.doesNotMatch(inspect,/postDelayed/,'transient wrapper inspector must not own item-result timers');
assert.doesNotMatch(inspect,/divStrL1L2|ddlUPC|RetailPrice/,'transient wrapper inspector must not own item extraction');

assert.match(worker,/new MutationObserver\(read\)/,'persistent worker must use event-driven item observation');
assert.match(worker,/PersistentAceNetBridge\.result/,'persistent worker must own item result delivery');
assert.match(worker,/persistent_worker_sku_evidence_still_pending/,'worker must retain diagnostic visibility for delayed SKU evidence without terminating a merely slow page');
assert.match(worker,/AceNetTimingPolicy\.STRUCTURE_INSPECTION_MS/,'worker must inspect suspicious structure at the shared three-second checkpoint');
assert.match(worker,/AceNetTimingPolicy\.MALFORMED_CONFIRM_MS/,'worker must confirm persistent malformed structure at the shared five-second checkpoint');
assert.match(worker,/AceNetTimingPolicy\.ITEM_ATTEMPT_MS/,'all item capabilities must share the twelve-second hard item ceiling');
console.log('AceNet event-driven wrapper readiness + sole persistent-worker extraction PASS');
