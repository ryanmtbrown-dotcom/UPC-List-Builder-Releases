import {readNativeRuntimeSource} from './helpers/runtime-source-tree.mjs';
import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import {extractPersistentWorkerScript,makeWorkerBridge} from './helpers/persistent-worker-script.mjs';

const main=readNativeRuntimeSource();
const marker='        val wrapper="""';
const base=main.indexOf('private fun inspectAceNetResult');
const a=main.indexOf(marker,base),b=main.indexOf('        """.trimIndent()',a);
assert.ok(base>=0&&a>=0&&b>a,'session wrapper observer must remain extractable');
const wrapper=main.slice(a+marker.length,b).replace('${JSONObject.quote(aceNetRequestId ?: "")}','"REQ"');
const retailer=extractPersistentWorkerScript({expected:'50177',mode:'PRODUCTION_PRICE'});

class MO{static last=null;constructor(cb){this.cb=cb;MO.last=this}observe(){}disconnect(){this.disconnected=true}}
function wrapperRun(initial){
  let frame=initial;const out=[];
  const doc={documentElement:{},body:{innerText:''},getElementById:id=>id==='iframeItemDetail'&&frame?{src:frame,getAttribute:()=>frame}:null};
  const c={document:doc,MutationObserver:MO,AceNetResultBridge:{observedResult:j=>out.push(JSON.parse(j))}};c.window=c;
  vm.runInNewContext(wrapper,c);
  return{out,setFrame:v=>{frame=v;MO.last.cb()}};
}
const target='https://retailer.aceservices.com/ItemDetailV2/ItemDetail/?sku=50177';
let w=wrapperRun(target);assert.equal(w.out.length,1,'wrapper immediate');assert.equal(w.out[0].frameUrl,target);
w=wrapperRun('');assert.equal(w.out.length,0,'wrapper waits');w.setFrame(target);assert.equal(w.out.length,1,'wrapper delayed');w.setFrame(target);assert.equal(w.out.length,1,'wrapper exactly once');

function retailerRun(priceInitially){
  let price=priceInitially;const results=[],diagnostics=[];
  const skuId='ctl00_ctl00_contentMainPlaceHolder_MainContent_headerSkuDataBar_lblSkuNr';
  const doc={
    readyState:'complete',title:'',scripts:[],body:{innerText:''},location:{href:'https://retailer.aceservices.com/'},documentElement:{outerHTML:'<html></html>'},
    getElementById:id=>id===skuId?{textContent:'50177'}:id==='lblHeaderSellingDataStoreRetail'&&price?{getAttribute:n=>n==='data-storeretail'?price:'',textContent:''}:null,
    querySelector:()=>null,querySelectorAll:sel=>sel==='iframe'?[]:[]
  };
  const c={document:doc,MutationObserver:MO,PersistentAceNetBridge:makeWorkerBridge({diagnostics,results}),JSON,Array,String,RegExp};c.window=c;
  vm.runInNewContext(retailer,c);
  return{results,setPrice:v=>{price=v;MO.last.cb()}};
}
let r=retailerRun('$39.99');assert.equal(r.results.length,1,'worker immediate');
r=retailerRun('');assert.equal(r.results.length,0,'worker waits');r.setPrice('$39.99');assert.equal(r.results.length,1,'worker delayed');r.setPrice('$40.00');assert.equal(r.results.length,1,'worker exactly once');
console.log('PASS acenet-event-readiness-v219-test with wrapper readiness + PersistentAceNetWorker');
