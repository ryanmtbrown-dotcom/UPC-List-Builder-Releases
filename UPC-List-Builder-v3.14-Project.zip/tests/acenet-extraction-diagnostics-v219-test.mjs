import vm from 'node:vm';
import assert from 'node:assert/strict';
import {extractPersistentWorkerScript,makeWorkerBridge} from './helpers/persistent-worker-script.mjs';

const script=extractPersistentWorkerScript({expected:'50177',mode:'PRODUCTION_PRICE'});
class MutationObserver{constructor(cb){this.cb=cb}observe(){}disconnect(){}}
const skuId='ctl00_ctl00_contentMainPlaceHolder_MainContent_headerSkuDataBar_lblSkuNr';
function run({sku='',price=''}){
  const diagnostics=[],results=[];
  const document={
    readyState:'complete',title:'',scripts:[],body:{innerText:''},location:{href:'https://retailer.aceservices.com/'},
    documentElement:{outerHTML:'<html></html>'},
    getElementById:id=>id===skuId?(sku?{textContent:sku}:null):id==='lblHeaderSellingDataStoreRetail'&&(price?true:false)?{getAttribute:n=>n==='data-storeretail'?price:'',textContent:''}:null,
    querySelector:()=>null,querySelectorAll:sel=>sel==='iframe'?[]:[]
  };
  const context={document,MutationObserver,PersistentAceNetBridge:makeWorkerBridge({diagnostics,results}),JSON,Array,String,RegExp};
  context.window=context;vm.runInNewContext(script,context);return{diagnostics,results};
}
let x=run({});
assert.ok(x.diagnostics.some(d=>d.stage==='WAITING_FOR_SKU'),'missing SKU must be diagnosed as waiting');
x=run({sku:'50177'});
assert.ok(x.diagnostics.some(d=>d.stage==='WAITING_FOR_PRICE'),'exact SKU without price must remain nonterminal');
assert.equal(x.results.length,0);
x=run({sku:'99999',price:'$39.99'});
assert.equal(x.results[0].status,'SKU_MISMATCH');
assert.equal(x.results[0].sku,'99999');
x=run({sku:'50177',price:'$39.99'});
assert.ok(x.diagnostics.some(d=>d.stage==='PRICE_READY'));
assert.equal(x.results.length,1);
assert.equal(x.results[0].status,'FOUND');
console.log('PASS acenet-extraction-diagnostics-v219-test via PersistentAceNetWorker');
