import {readWebRuntimeSource,readNativeRuntimeSource} from './helpers/runtime-source-tree.mjs';
import fs from 'node:fs';
import assert from 'node:assert/strict';

const main=readNativeRuntimeSource();
const app=readWebRuntimeSource();
const auth=fs.readFileSync('ACENET_AUTH_SESSION_CONTRACT.md','utf8');
const health=fs.readFileSync('ACENET_SERVICE_HEALTH_CONTRACT.md','utf8');
const diagnostics=fs.readFileSync('DIAGNOSTICS_CONTRACT.md','utf8');

const beginStart=main.indexOf('private fun beginAceNetStartupAuthentication');
const beginEnd=main.indexOf('private fun showAceNetStartupCredentialPrompt',beginStart);
const begin=main.slice(beginStart,beginEnd);
assert.match(begin,/aceNetAuthenticationNetworkRetryAttempted=false/);
assert.match(begin,/aceNetRetailerBootstrapRetryAttempted=false/);
assert.match(begin,/aceNetExpectedFreshLogin=true/);
assert.match(begin,/startFreshAceNetSession\(requestId,credentials\.first,credentials\.second,aceNetWarmupSku,"cold_app_start"\)/);

const stsStart=main.indexOf('currentHost == "sts.aceservices.com" -> {');
const stsEnd=main.indexOf('\n                    else -> {',stsStart);
assert.ok(stsStart>=0&&stsEnd>stsStart,'STS navigation branch missing');
const sts=main.slice(stsStart,stsEnd);
assert.match(sts,/aceNetStartupOnly && aceNetRequestKind=="STARTUP_WARMUP"/);
assert.match(sts,/aceNetSessionRepairOnly/);
assert.match(sts,/aceNetRequestKind=="TEST"/);
assert.match(sts,/inspectAceNetRetailerSso\(v,current\)/);
assert.match(sts,/sts_login_route_selected/);
assert.match(sts,/expectedFreshLogin/);
assert.match(sts,/recoveryConsumed",false/);
assert.match(sts,/inspectAceNetLogin\(v,current\)/);
assert.doesNotMatch(sts,/recoverAceNetSessionAndRetry\("startup_sts_redirect"\)/);
assert.doesNotMatch(sts,/startFreshAceNetSession/);

const ssoStart=main.indexOf('private fun inspectAceNetRetailerSso');
const ssoEnd=main.indexOf('\n    private fun inspectAceNetLogin',ssoStart);
const sso=main.slice(ssoStart,ssoEnd);
assert.match(sso,/hasSamlResponse \|\| isSamlRequest/);
assert.match(sso,/authenticationPreserved",true/);
assert.match(sso,/retailer_sso_login_required/);
assert.match(sso,/recoverAceNetSessionAndRetry/);

const authRetryStart=main.indexOf('private fun retryAceNetStartupAuthenticationNetworkFailure');
const authRetryEnd=main.indexOf('private fun retryAceNetStartupRetailerBootstrap',authRetryStart);
const authRetry=main.slice(authRetryStart,authRetryEnd);
assert.match(authRetry,/aceNetAuthenticationNetworkRetryAttempted/);
assert.match(authRetry,/startup_authentication_network_retry_started/);
assert.match(authRetry,/startFreshAceNetSession/);

const retailerRetryStart=main.indexOf('private fun retryAceNetStartupRetailerBootstrap');
const retailerRetryEnd=main.indexOf('private fun scheduleAceNetSessionExtension',retailerRetryStart);
const retailerRetry=main.slice(retailerRetryStart,retailerRetryEnd);
assert.match(retailerRetry,/aceNetRetailerBootstrapRetryAttempted/);
assert.match(retailerRetry,/authenticationPreserved",true/);
assert.match(retailerRetry,/loadAceNetDirectItem\(v\)/);
assert.doesNotMatch(retailerRetry,/startFreshAceNetSession/);

const errStart=main.indexOf('override fun onReceivedError(view:WebView?');
const errEnd=main.indexOf('override fun onReceivedHttpError',errStart);
const err=main.slice(errStart,errEnd);
assert.match(err,/retryAceNetStartupAuthenticationNetworkFailure\(reason\)/);
assert.match(err,/retryAceNetStartupRetailerBootstrap\(view,reason\)/);

const httpStart=main.indexOf('override fun onReceivedHttpError(view:WebView?');
const http=main.slice(httpStart,httpStart+12000);
assert.match(http,/retryAceNetStartupRetailerBootstrap\(view,"http_404"\)/);
assert.match(http,/500,502,503,504 ->/);
assert.match(http,/aceNetHealthStatus="DOWN"/);

for(const marker of [
 'session_cookie_state_before_reset','session_cookie_state_after_reset','session_cookie_state_at_sts',
 'session_cookie_state_at_home','session_cookie_state_at_retailer_ready','aceNetCookieNames','stsCookieNames',
 'retailerCookieNames','home_session_surface_inspection','candidateControls','topRightControls',
 'localStorageKeys','sessionStorageKeys'
]) assert.ok(main.includes(marker),'missing session diagnostic marker: '+marker);
assert.match(main,/valuesRedacted",true/);
assert.match(main,/storageValuesRedacted:true/);
assert.match(main,/controlsClicked",false/);

assert.match(auth,/Authentication\/network retry and retailer-bootstrap retry are separately bounded/);
assert.match(health,/independent startup retry budgets/);
assert.match(diagnostics,/Canonical event model/);
assert.doesNotMatch(app,/UI_WAIT_TIMEOUT/);

console.log('AceNet expected-login + shared retailer readiness session diagnostics PASS');
