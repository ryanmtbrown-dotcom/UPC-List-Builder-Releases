import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';

const worker=fs.readFileSync('app/src/main/java/com/rmtb/upclistbuilder/PersistentAceNetWorker.kt','utf8');
const coordinator=fs.readFileSync('app/src/main/java/com/rmtb/upclistbuilder/AceNetProductionCoordinator.kt','utf8');
const brokerSource=fs.readFileSync('app/src/main/assets/www/acenet-client.js','utf8');
const miscSource=fs.readFileSync('app/src/main/assets/www/ace-misc.js','utf8');
const draftSource=fs.readFileSync('app/src/main/assets/www/misc/misc-draft-model.js','utf8');
const resolutionSource=fs.readFileSync('app/src/main/assets/www/misc/misc-resolution-service.js','utf8');
const workspaceSource=fs.readFileSync('app/src/main/assets/www/misc/misc-workspace-controller.js','utf8');
const normalSource=fs.readFileSync('app/src/main/assets/www/lookup/normal-lookup-controller.js','utf8');

assert.match(worker,/healthyEmptyItemAtThreeSeconds/,'worker must retain the first healthy-empty checkpoint');
assert.match(worker,/exactSkuNoUpcAtThreeSeconds/,'worker must retain the first exact-SKU/no-UPC checkpoint');
assert.match(worker,/HEALTHY_EMPTY_ITEM_DETAIL_STABLE/,'stable healthy empty item page must have an explicit NOT_FOUND classification basis');
assert.match(worker,/EXACT_SKU_STABLE_NO_UPC_SELECTOR/,'exact SKU without UPC selector must have an explicit classification basis');
assert.match(worker,/AceNetTimingPolicy\.STRUCTURE_INSPECTION_MS/);
assert.match(worker,/AceNetTimingPolicy\.MALFORMED_CONFIRM_MS/);
assert.match(worker,/expectedDetailPage[\s\S]*retailer\.aceservices\.com[\s\S]*ItemDetailRedesign\.aspx/,'not-found classification must require the expected AceNet detail route');
assert.match(worker,/healthyItemShell=complete && expectedDetailPage && !chromiumError[\s\S]*skuElementPresent[\s\S]*priceElementPresent[\s\S]*descriptionElementPresent[\s\S]*iframeCount[\s\S]*scriptCount/,'healthy item shell must require positive page structure and no Chromium error');
assert.match(worker,/healthyEmptyItemAtThreeSeconds && healthyEmptyItem && !skuEvidenceObserved[\s\S]*status","NOT_FOUND"/,'NOT_FOUND must require a stable healthy-empty state at the confirmation checkpoint');
assert.match(worker,/onlyMasterUpcMissing=missing!=null && missing\.length\(\)==1 && missing\.optString\(0\)=="masterUpc"/,'no-UPC classification must require masterUpc to be the sole missing catalog field');
assert.match(worker,/exactSkuNoUpcAtThreeSeconds && exactSkuNoUpc && onlyMasterUpcMissing && catalogSnapshot!=null/,'no-UPC result must require stable exact-SKU evidence plus a catalog snapshot');
assert.match(worker,/persistent_worker_not_found_classified/);
assert.match(worker,/persistent_worker_no_upc_data_classified/);
assert.match(coordinator,/status=="FOUND_NO_UPC_DATA"[\s\S]*persistent_worker_verified_no_upc_data[\s\S]*UPCNativeAceNetCatalogResult/,'coordinator must forward no-UPC as verified catalog evidence without recovery');

function buildBroker(){
 const bridgeCalls=[],timers=new Map();let nextTimer=1;
 const native={
  getAceNetProductionBrokerTimeoutMs:()=>52000,
  lookupAceNetCatalog:(id,sku)=>bridgeCalls.push({id,sku}),
  lookupAceNetMiscCatalog:(id,sku)=>bridgeCalls.push({id,sku}),
  lookupAceNetRepairCatalog:(id,sku)=>bridgeCalls.push({id,sku})
 };
 const context={window:{AndroidNative:native},Map,Set,Promise,Date,Math,String,Number,JSON,globalThis:null,
  setTimeout:(fn,ms)=>{const id=nextTimer++;timers.set(id,{fn,ms});return id},
  clearTimeout:id=>timers.delete(id)};
 context.globalThis=context;
 vm.createContext(context);vm.runInContext(brokerSource,context,{filename:'acenet-client.js'});
 const client=context.window.UPCAceNetClient;
 client.configure({
  normalizeSKU:v=>String(v??'').trim().toLowerCase(),
  normalizeUPC:v=>String(v??'').replace(/\D/g,''),
  parsePrice:v=>Number(v)||null,
  diag:()=>{},
  bridgeProvider:()=>native
 });
 return{client,bridgeCalls};
}

{
 const {client,bridgeCalls}=buildBroker();
 const pending=client.requestCatalog('ABC123',{misc:true});
 const requestId=bridgeCalls[0].id;
 client.acceptCatalogResult({requestId,found:true,status:'FOUND_NO_UPC_DATA',sku:'abc123',catalog:{sku:'abc123',description:'Item',aceRetailPrice:'9.99'},missingFields:['masterUpc']});
 const result=await pending;
 assert.equal(result.status,'VERIFIED_NO_UPC_DATA');
 assert.equal(result.sku,'abc123');
 assert.equal(result.catalog.description,'Item');
 assert.deepEqual(Array.from(result.missingFields),['masterUpc']);
 assert.equal(result.misc,true);
}

{
 const runtime={window:{}};vm.createContext(runtime);vm.runInContext(resolutionSource,runtime,{filename:'misc-resolution-service.js'});
 const diagnostics=[],snapshotCalls=[];let refreshCalled=false;
 const row={id:77,originalUPC:'111111111111',upcKey:'111111111111',fields:{'UPC/EAN':'111111111111'}};
 const service=runtime.window.UPCMiscResolutionService.create({
  effectiveResolver:{inspectSKU:async()=>({master:{count:1,row},local:{count:0,row:null}})},
  localRepository:{lookupSKU:async()=>({count:0,row:null})},
  relationshipService:{getSkuUpcs:async()=>[{skuKey:'12345',upcKey:'111111111111',isMaster:true},{skuKey:'12345',upcKey:'222222222222',isMaster:false}]},
  catalogRefreshService:{applyCatalogRefreshPolicyToExistingRecord:async()=>{refreshCalled=true;throw new Error('must not mutate relationships/catalog for no-UPC evidence')}},
  normalLookupController:{lookupItemBySku:async()=>({status:'FOUND'})},
  itemMapper:{itemFromLibraryRow:()=>({status:'FOUND',sku:'12345',upc:'111111111111',price:'10.00',fields:{}})},
  miscDomain:{
   UPC_VERIFICATION:{VERIFIED_COMPLETE:'VERIFIED_COMPLETE',VERIFIED_NO_ACENET_UPC_DATA:'VERIFIED_NO_ACENET_UPC_DATA',PENDING_ACENET:'PENDING_ACENET',NEEDS_USER_CONFIRMATION:'NEEDS_USER_CONFIRMATION'},
   snapshotFromLibraryAndAceNet:(record,sku,catalog,options)=>{snapshotCalls.push({record,sku,catalog,options});return{version:2,source:options.source,baseRow:Array(33).fill(''),orderedUpcs:[...options.fallbackUpcs],upcVerification:options.upcVerification}}
  },
  draftModel:{
   storedDraftUpcs:(primary,refs)=>[primary,...refs.map(x=>x.upcKey)].filter((x,i,a)=>x&&a.indexOf(x)===i),
   bulkItemFromResolved:(item,snapshot)=>({...item,aceMiscSnapshot:snapshot}),
   decorateItem:(item,snapshot,verification,status,price)=>({...item,aceMiscSnapshot:snapshot,aceMiscUpcVerification:verification,aceMiscAceNetStatus:status,aceNetPrice:price})
  },
  normalizeSku:v=>String(v??'').replace(/\D/g,''),
  requestCatalog:async()=>({status:'VERIFIED_NO_UPC_DATA',sku:'12345',catalog:{sku:'12345',description:'Live item',aceRetailPrice:'12.99'},missingFields:['masterUpc']}),
  diagnostic:(event,payload)=>diagnostics.push({event,payload})
 });
 const result=await service.aceMiscRefreshLibraryRecord('12345',row,{libraryKind:'MASTER',relationshipSource:'TEST'});
 assert.equal(result.status,'FOUND');
 assert.equal(result.upcVerification,'VERIFIED_NO_ACENET_UPC_DATA');
 assert.deepEqual(Array.from(result.upcs),['111111111111','222222222222']);
 assert.equal(refreshCalled,false,'no-UPC evidence must not replace or merge UPC relationships');
 assert.equal(snapshotCalls.length,1);
 assert.deepEqual(Array.from(snapshotCalls[0].options.fallbackUpcs),['111111111111','222222222222']);
 assert.equal(snapshotCalls[0].options.upcVerification,'VERIFIED_NO_ACENET_UPC_DATA');
 assert.equal(diagnostics.some(x=>x.event==='ace_misc_no_upc_data_ready'&&x.payload.relationshipSetChanged===false&&x.payload.exportReady===true),true);
}

assert.match(miscSource,/VERIFIED_NO_ACENET_UPC_DATA:'VERIFIED_NO_ACENET_UPC_DATA'/);
assert.match(miscSource,/EXPORTABLE_UPC_VERIFICATION=new Set\(\[UPC_VERIFICATION\.VERIFIED_COMPLETE,UPC_VERIFICATION\.VERIFIED_NO_ACENET_UPC_DATA,UPC_VERIFICATION\.USER_CONFIRMED_COMPLETE\]\)/);
assert.match(miscSource,/liveUpcs\.length\?liveUpcs:normalizeOrderedUpcs\(fallbackUpcs\)/,'MISC snapshot must use Library/current UPCs only when AceNet provides none');
assert.match(draftSource,/state===states\.VERIFIED_NO_ACENET_UPC_DATA/);
const sharedMessage='Item is not currently in Master Library, Local Library, or AceNet.';
assert.ok(workspaceSource.includes(sharedMessage),'MISC must use the shared terminal not-found wording');
assert.ok(normalSource.includes(sharedMessage),'Normal lookup must use the shared terminal not-found wording');
assert.match(workspaceSource,/AceNet verified the SKU but provides no UPC selector data\. Using the known Library UPC set for ACE MISC export\./);

console.log('v2.92 stable AceNet not-found + verified no-UPC classifier regression PASS');
