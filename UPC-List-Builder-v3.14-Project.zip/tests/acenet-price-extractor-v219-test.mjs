import vm from 'node:vm';
import assert from 'node:assert/strict';
import {extractPersistentWorkerScript,makeWorkerBridge} from './helpers/persistent-worker-script.mjs';

const script=extractPersistentWorkerScript({expected:'50177',mode:'PRODUCTION_PRICE'});
class MutationObserver{constructor(cb){this.cb=cb}observe(){}disconnect(){}}
const skuId='ctl00_ctl00_contentMainPlaceHolder_MainContent_headerSkuDataBar_lblSkuNr';

function run(elements){
  const results=[],diagnostics=[];
  const document={
    readyState:'complete',title:'',scripts:[],body:{innerText:''},location:{href:'https://retailer.aceservices.com/'},
    documentElement:{outerHTML:'<html></html>'},
    getElementById:id=>elements[id]||null,
    querySelector:sel=>sel==='[id*=RetailPrice]'?(elements.__wild||null):null,
    querySelectorAll:sel=>sel==='iframe'?[]:[]
  };
  const context={document,MutationObserver,PersistentAceNetBridge:makeWorkerBridge({diagnostics,results}),JSON,Array,String,RegExp};
  context.window=context;
  vm.runInNewContext(script,context);
  return{results,diagnostics};
}
const sku={textContent:'50177'};
const cases=[
 ['Store Retail data-storeretail',{[skuId]:sku,lblHeaderSellingDataStoreRetail:{getAttribute:n=>n==='data-storeretail'?'$38.88':'',textContent:''}},'38.88'],
 ['Store Retail text',{[skuId]:sku,lblHeaderSellingDataStoreRetail:{getAttribute:()=>'',textContent:'Store Retail: $37.77'}},'37.77'],
 ['Ace Retail $11.99 versus Store Retail $13.99',{[skuId]:sku,divStrL1L2:{getAttribute:()=>'$11.99',textContent:'$11.99'},lblHeaderSellingDataStoreRetail:{getAttribute:n=>n==='data-storeretail'?'$13.99':'',textContent:'$13.99'}},'13.99'],
];
for(const [name,elements,want] of cases){
 const out=run(elements).results;
 assert.equal(out.length,1,name);assert.equal(out[0].sku,'50177',name);assert.equal(out[0].price,want,name);
}
for(const [name,other] of [
 ['Ace retail is not Level 2',{divStrL1L2:{getAttribute:()=>'$11.99',textContent:'$11.99'}}],
 ['old retail selector is not Level 2',{lblRetailPrice:{textContent:'$11.99'}}],
 ['generic wildcard is not Level 2',{__wild:{textContent:'$11.99'}}]
])assert.equal(run({[skuId]:sku,...other}).results.length,0,name);
assert.equal(run({[skuId]:sku}).results.length,0,'missing price must wait rather than invent a result');
const mismatch=run({[skuId]:{textContent:'99999'},divStrL1L2:{getAttribute:()=>'$39.99',textContent:''}}).results[0];
assert.equal(mismatch.status,'SKU_MISMATCH');
assert.equal(mismatch.sku,'99999','worker must report returned SKU for exact-SKU rejection');
console.log('PASS acenet-price-extractor-v219-test via PersistentAceNetWorker');
