import {readWebRuntimeSource,readNativeRuntimeSource} from './helpers/runtime-source-tree.mjs';
import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';

const main=readNativeRuntimeSource();
const worker=fs.readFileSync('app/src/main/java/com/rmtb/upclistbuilder/PersistentAceNetWorker.kt','utf8');
const app=readWebRuntimeSource();
const db=fs.readFileSync('app/src/main/assets/www/db.js','utf8');
const auth=fs.readFileSync('ACENET_AUTH_SESSION_CONTRACT.md','utf8');
const retrieval=fs.readFileSync('ACENET_ITEM_RETRIEVAL_CONTRACT.md','utf8');
const identity=fs.readFileSync('PRODUCT_IDENTITY_INDEX_CONTRACT.md','utf8');
const refreshPolicy=fs.readFileSync('app/src/main/assets/www/catalog-refresh-policy.js','utf8');
const maintenance=fs.readFileSync('app/src/main/assets/www/catalog/catalog-maintenance-service.js','utf8');
const identityWork=fs.readFileSync('app/src/main/assets/www/identity/identity-work-controller.js','utf8');
const miscResolution=fs.readFileSync('app/src/main/assets/www/misc/misc-resolution-service.js','utf8');

assert.match(main,/restoreAceNetSessionHistory\(\)/,'persisted session history must be loaded at cold process start');
assert.match(main,/startFreshAceNetSession\(requestId,credentials\.first,credentials\.second,aceNetWarmupSku,"cold_app_start"\)/,'cold startup must not trust retained WebView cookies');
assert.match(main,/removeAllCookies/,'fresh app-owned AceNet session must clear retained WebView cookies');
assert.match(main,/sessionGeneration/,'session generation evidence missing');
assert.match(main,/sessionEstablishedMs/,'session establishment timestamp missing');
assert.match(main,/homeVerifiedMs/,'Home verification timestamp missing');
assert.match(main,/retailerVerifiedMs/,'retailer verification timestamp missing');
assert.match(main,/aceNetInitialStartupBegun && aceNetStartupResolved/,'initial onStart must not race authoritative startup');
assert.doesNotMatch(main,/session_extension_deferred/,'destroyed-Home-WebView keepalive loop must be retired');
assert.match(main,/session_refresh_required/,'age-authoritative renewal marker missing');
assert.match(main,/aceNetSessionAuthenticated && !aceNetSessionReusable\(\)/,'production request must renew a stale authenticated session');

const completion=main.slice(main.indexOf('private fun completeAceNetStartupAuthentication'),main.indexOf('private fun completeAceNetStartupUnavailable'));
assert.doesNotMatch(completion,/aceNetLastAuthenticatedMs=verifiedAt/,'terminal startup completion must not fabricate a new authentication age');

assert.match(main,/aceNetAuthenticationNetworkRetryAttempted/,'v2.60 must preserve v2.59 fresh-session foundation while separating retry ownership');
assert.match(main,/aceNetRetailerBootstrapRetryAttempted/,'v2.60 retailer retry state missing');

assert.match(auth,/## Session reuse and age/);
assert.match(retrieval,/### PRODUCTION_REPAIR_CATALOG/);
assert.match(identity,/## Local correction and repair/);

assert.match(main,/lookupAceNetRepairCatalog\(requestId: String, sku: String\)/,'repair-only native bridge missing');
assert.match(worker,/PRODUCTION_REPAIR_CATALOG/,'repair catalog mode missing');
assert.match(worker,/FOUND_PARTIAL/,'partial terminal result missing');
assert.match(worker,/repairCatalogSnapshot/,'partial catalog snapshot retention missing');
assert.match(worker,/repairCatalogMissingFields/,'missing-field retention missing');
assert.match(maintenance,/requestCatalog\(sku,\{repair:true\}\)/,'Local Library repair must use isolated repair mode through Catalog Maintenance');
assert.match(maintenance,/VERIFIED_PARTIAL/,'catalog maintenance repair must distinguish verified partial evidence');
assert.match(db,/async function clearLocalLibraryAceNetFields/,'explicit future authoritative clearing primitive must remain bounded and available');
assert.match(db,/userCorrections\[canonical\]/,'user corrections must remain protected by the clearing primitive');
assert.match(refreshPolicy,/PARTIAL_OR_MISSING_EVIDENCE_NOT_DESTRUCTIVE/,'Stage 7 partial/missing repair evidence must preserve stored fields rather than infer deletion.');
assert.match(db,/async function setLocalLibraryAceNetVerification/,'Local Library verification status must be visible in stored records');

assert.match(identityWork,/requestCatalog\(key\)/,'ordinary Add to Local Library must keep complete catalog mode');
assert.match(miscResolution,/requestAceNetCatalog\(key,\{misc:true\}\)/,'ordinary ACE MISC construction must keep complete MISC mode');

const marker='val js="""';
const inspectStart=worker.indexOf('private fun inspect(v:WebView)');
const start=worker.indexOf(marker,inspectStart),end=worker.indexOf('""".trimIndent()',start);
assert.ok(start>0&&end>start,'worker extraction JavaScript must remain extractable');
function runRepair({missingOm=false,missingUpc=false}){
 let script=worker.slice(start+marker.length,end).replaceAll('$expected',JSON.stringify('50177')).replaceAll('$mode',JSON.stringify('PRODUCTION_REPAIR_CATALOG'));
 const nodes=[];
 function node(id,text='',attrs={}){return{id,name:'',tagName:attrs.tagName||'SPAN',textContent:text,value:attrs.value||'',options:attrs.options||null,selectedIndex:0,parentElement:null,nextElementSibling:null,getAttribute(k){return attrs[k]??null},closest(){return null},querySelectorAll(){return[]}}}
 nodes.push(
  node('ctl00_ctl00_contentMainPlaceHolder_MainContent_headerSkuDataBar_lblSkuNr','50177'),
  node('divStrL1L2','$41.99',{'data-retail':'41.99'}),
  node('ctl00_ctl00_contentMainPlaceHolder_MainContent_headerSkuDataBar_lblLongDescr','Ace Plastic Sheeting'),
  node('spnEachCost','18.94'),
  node('ctl00_ctl00_contentMainPlaceHolder_MainContent_headerSkuDataBar_lblMfgNr','1414387'),
  node('spnEachWeight','9.3lbs'),
  node('ctl00_ctl00_contentMainPlaceHolder_MainContent_headerSkuDataBar_lblComGrpBcrumb','50 - Hardware'),
  node('ctl00_ctl00_contentMainPlaceHolder_MainContent_headerSkuDataBar_lblMerchClsBcrumb','544 - Polyethylene Sheeting'),
  node('ctl00_ctl00_contentMainPlaceHolder_MainContent_headerSkuDataBar_lblProdGrpBcrumb','03 - Consumer Roll Poly')
 );
 if(!missingOm)nodes.push(node('spnEachOM','1'));
 if(!missingUpc)nodes.push(node('ctl00_ctl00_contentMainPlaceHolder_MainContent_mainItemData_lvAceItemDetails_ctrl0_ddlUPC','',{tagName:'SELECT',options:[{value:'082901501770',textContent:'082901501770'}]}));
 class MutationObserver{constructor(cb){this.cb=cb}observe(){}disconnect(){}}
 const snapshots=[],progress=[],results=[];
 const document={documentElement:{},location:{href:'https://retailer.aceservices.com/'},scripts:[],
  getElementById(id){return nodes.find(n=>n.id===id)||null},
  querySelector(sel){if(sel==='[id*=RetailPrice]')return null;return null},
  querySelectorAll(sel){if(sel==='select')return nodes.filter(n=>n.tagName==='SELECT');if(sel==='[id]')return nodes.filter(n=>n.id);if(sel==='label,th,td,dt,span,div')return[];if(sel==='iframe')return[];return[]}
 };
 const bridge={skuObserved(){},result(raw){results.push(JSON.parse(raw))},progress(raw){progress.push(JSON.parse(raw))},catalogSnapshot(raw){snapshots.push(JSON.parse(raw))},repairSnapshot(raw){snapshots.push(JSON.parse(raw))},shouldCaptureForensics(){return false},forensics(){}};
 const context={window:{},document,MutationObserver,JSON,Array,String,RegExp,PersistentAceNetBridge:bridge};
 context.window=context;vm.createContext(context);vm.runInContext(script,context);
 return{snapshots,progress,results};
}
const missingOm=runRepair({missingOm:true});
assert.equal(missingOm.results.length,0,'repair mode must wait the full catalog deadline when a field is absent');
assert.ok(missingOm.snapshots.at(-1).missingFields.includes('orderMultiple'),'missing Order Multiple must be explicit');
assert.equal(missingOm.snapshots.at(-1).catalog.description,'Ace Plastic Sheeting','available exact fields must survive a partial repair');
assert.equal(missingOm.snapshots.at(-1).catalog.masterUpc,'082901501770','available UPC must survive a different missing field');

const missingUpc=runRepair({missingUpc:true});
assert.equal(missingUpc.results.length,0);
assert.ok(missingUpc.snapshots.at(-1).missingFields.includes('masterUpc'),'missing UPC must be explicit rather than invalidating the SKU');
assert.equal(missingUpc.snapshots.at(-1).catalog.orderMultiple,'1','available Order Multiple must survive missing UPC');

console.log('Current session/local-repair foundation requirements PASS');
