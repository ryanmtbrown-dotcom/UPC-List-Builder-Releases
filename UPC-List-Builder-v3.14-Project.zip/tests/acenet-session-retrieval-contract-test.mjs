import {readNativeRuntimeSource} from './helpers/runtime-source-tree.mjs';
import fs from 'node:fs';
import assert from 'node:assert/strict';

const main=readNativeRuntimeSource();
const activity=fs.readFileSync('app/src/main/java/com/rmtb/upclistbuilder/MainActivity.kt','utf8');
const session=fs.readFileSync('app/src/main/java/com/rmtb/upclistbuilder/AceNetSessionManager.kt','utf8');
const retrieval=fs.readFileSync('app/src/main/java/com/rmtb/upclistbuilder/AceNetRetrievalService.kt','utf8');
const worker=fs.readFileSync('app/src/main/java/com/rmtb/upclistbuilder/PersistentAceNetWorker.kt','utf8');
const auth=fs.readFileSync('ACENET_AUTH_SESSION_CONTRACT.md','utf8');
const item=fs.readFileSync('ACENET_ITEM_RETRIEVAL_CONTRACT.md','utf8');

assert.match(auth,/## Session reuse and age/,'current session reuse authority missing');
assert.match(item,/## Sole engine/,'current sole retrieval-engine authority missing');

assert.match(session,/getSharedPreferences\("acenet_session_state"/,'session manager must own persisted session state');
assert.match(session,/getSharedPreferences\("acenet_secure_credentials"/,'session manager must own encrypted credentials');
assert.match(session,/AES\/GCM\/NoPadding/,'session manager must retain encrypted credential storage');
assert.match(session,/fun markHomeVerified/);
assert.match(session,/fun markRetailerSessionReady/);
assert.match(session,/fun markRetailerVerified/);
assert.match(session,/fun markSuccessfulLookup/);
assert.doesNotMatch(session,/android\.webkit\.WebView|\.loadUrl\(|evaluateJavascript\(/,'session manager must not create/navigate WebViews or dispatch item extraction');

assert.match(retrieval,/private var worker: PersistentAceNetWorker\? = null/,'retrieval service must own retained worker lifecycle');
assert.match(retrieval,/PersistentAceNetWorker\(activity, emit, complete\)/,'retrieval service must be the worker construction boundary');
assert.match(retrieval,/fun search\(requestId: String, mode: String, sku: String\)/);
assert.match(retrieval,/fun prime\(template: String, sku: String, timeoutMs: Long = AceNetTimingPolicy\.ITEM_ATTEMPT_MS, callback:/);
assert.doesNotMatch(retrieval,/divStrL1L2|ddlUPC|lblHeaderSellingDataStoreRetail|querySelector/,'retrieval service must not become a second extractor');

const coordinator=fs.readFileSync('app/src/main/java/com/rmtb/upclistbuilder/AceNetProductionCoordinator.kt','utf8');
assert.match(activity,/aceNetCoordinator = AceNetProductionCoordinator\(/,'MainActivity must explicitly construct the AceNet coordinator');
assert.match(coordinator,/aceNetSessionManager = AceNetSessionManager\(activity, diagnostic = \{/,'AceNet coordinator must construct the session manager with the diagnostic callback explicitly bound');
assert.match(coordinator,/aceNetRetrievalService = AceNetRetrievalService\(/);
assert.doesNotMatch(activity,/getSharedPreferences\("acenet_session_state"/,'MainActivity must not own AceNet session persistence');
assert.doesNotMatch(activity,/getSharedPreferences\("acenet_secure_credentials"/,'MainActivity must not own AceNet credential persistence');
assert.doesNotMatch(activity,/PersistentAceNetWorker\(this|=\s*PersistentAceNetWorker/,'MainActivity must not construct the item worker directly');
assert.doesNotMatch(activity,/divStrL1L2|lblHeaderSellingDataStoreRetail|ddlUPC/,'MainActivity must not contain item extraction selectors');

const inspectStart=main.indexOf('private fun inspectAceNetResult');
const inspectEnd=main.indexOf('private fun handleAceNetObservedResult',inspectStart);
const inspect=main.slice(inspectStart,inspectEnd);
assert.match(inspect,/iframeItemDetail/,'transient view may discover the retailer wrapper target');
assert.match(inspect,/mode:'WRAPPER'/,'transient result bridge must publish wrapper readiness only');
assert.doesNotMatch(inspect,/price\(|ddlUPC|RetailPrice|PersistentAceNetBridge/,'transient result inspection must not extract item evidence');

const observedStart=main.indexOf('private fun handleAceNetObservedResult');
const observedEnd=main.indexOf('private fun finishAceNetTest',observedStart);
const observed=main.slice(observedStart,observedEnd);
assert.match(observed,/if\(result\.optString\("mode"\)!="WRAPPER"\)/,'transient bridge must reject non-wrapper item evidence');
assert.match(observed,/transient_item_evidence_ignored/);
assert.match(observed,/transient_item_retrieval_forbidden/);
assert.match(observed,/sourceView\.loadUrl\(frameUrl\)/,'session-readiness flow may enter retailer only to establish the session');

assert.match(worker,/divStrL1L2/);
assert.match(worker,/lblHeaderSellingDataStoreRetail/);
assert.match(worker,/ddlUPC/);
assert.match(worker,/PRODUCTION_CATALOG/);
assert.match(worker,/PRODUCTION_MISC_CATALOG/);
assert.match(worker,/PRODUCTION_REPAIR_CATALOG/);
assert.match(worker,/SKU_MISMATCH/,'worker must own exact-SKU rejection');

const productionStart=main.indexOf('private fun startProductionAceNetLookup');
const productionEnd=main.indexOf('private fun startDeferredAceNetCatalogLookup',productionStart);
const production=main.slice(productionStart,productionEnd);
assert.match(production,/aceNetRetrievalService\.search\(requestId,mode,cleanSku\)/,'production fast path must dispatch through retrieval service');
assert.match(production,/beginAceNetProductionSoftRepair\(requestId,cleanSku,mode/,'authenticated worker failure must have a retained-session soft repair path');
assert.match(production,/beginAceNetProductionHardRepair\(requestId,cleanSku,mode/,'stale or unauthenticated production session must have one full repair path');
assert.doesNotMatch(production,/startAceNetTest\(/,'production lookup must not fall back to transient item extraction');

const repairStart=main.indexOf('private fun completeAceNetProductionSessionRepair');
const repairEnd=main.indexOf('private fun completeAceNetBridgeTestThroughWorker',repairStart);
const repair=main.slice(repairStart,repairEnd);
assert.match(repair,/aceNetRetrievalService\.prime\(template,aceNetWarmupSku,canaryTimeout\)/,'repaired session must prove retained-worker readiness within the bounded canary window');
assert.match(repair,/aceNetRetrievalService\.search\(pending\.requestId,pending\.mode,pending\.sku\)/,'repaired request must be redispatched through the worker');
assert.match(repair,/itemExtractionOwner","PersistentAceNetWorker"/);

console.log('Stage 6 AceNet session/readiness vs retrieval boundary PASS');
