import {readWebRuntimeSource,readNativeRuntimeSource,findJsFunction} from './helpers/runtime-source-tree.mjs';
import fs from 'node:fs';
import assert from 'node:assert/strict';

const main=readNativeRuntimeSource();
const activity=fs.readFileSync('app/src/main/java/com/rmtb/upclistbuilder/MainActivity.kt','utf8');
const service=fs.readFileSync('app/src/main/java/com/rmtb/upclistbuilder/AceNetRetrievalService.kt','utf8');
const worker=fs.readFileSync('app/src/main/java/com/rmtb/upclistbuilder/PersistentAceNetWorker.kt','utf8');
const app=readWebRuntimeSource();

assert.match(main,/startProductionAceNetLookup\(requestId,\s*sku,\s*"PRODUCTION_PRICE"\)/,'price bridge mode missing');
assert.match(main,/startProductionAceNetLookup\(requestId,\s*sku,\s*"PRODUCTION_PRICE_UPCS"\)/,'price+UPC bridge mode missing');
assert.match(main,/startProductionAceNetLookup\(requestId,\s*sku,\s*"PRODUCTION_UPCS"\)/,'UPC bridge mode missing');
assert.match(main,/lookupAceNetCatalog\(requestId: String, sku: String\)/,'catalog bridge missing');

const productionStart=main.indexOf('private fun startProductionAceNetLookup');
const productionEnd=main.indexOf('private fun startDeferredAceNetCatalogLookup',productionStart);
const production=main.slice(productionStart,productionEnd);
assert.match(production,/aceNetRetrievalService\.search\(requestId,mode,cleanSku\)/,'normal production lookup must dispatch through retrieval service');
assert.match(production,/persistent_worker_fast_path_selected/);
assert.match(production,/persistent_worker_recovery_selected/);
assert.match(production,/beginAceNetProductionSoftRepair\(requestId,cleanSku,mode,"worker_not_ready"\)/,'authenticated worker failure should try the retained-session soft repair');
assert.match(production,/beginAceNetProductionHardRepair\(requestId,cleanSku,mode,"worker_not_ready_no_session"\)/,'missing authenticated session should go directly to full repair');
assert.doesNotMatch(production,/startAceNetTest\(/,'production fallback must repair session then redispatch, not transiently extract');

assert.match(service,/PersistentAceNetWorker\(activity, emit, complete\)/,'retrieval service must own the worker');
assert.match(service,/worker\?\.takeIf \{ it\.isReady\(\) \}\?\.search/,'service search must require ready retained worker');

assert.match(worker,/new MutationObserver\(read\)/,'persistent worker event-driven observer missing');
const priceStart=worker.indexOf("if($mode==='PRODUCTION_PRICE')");
const upcStart=worker.indexOf("document.getElementById('ctl00_ctl00_contentMainPlaceHolder_MainContent_mainItemData_lvAceItemDetails_ctrl0_ddlUPC')",priceStart);
assert.ok(priceStart>=0&&upcStart>priceStart,'PRICE and UPC branches must remain explicitly separated');
const priceBranch=worker.slice(priceStart,upcStart);
assert.doesNotMatch(priceBranch,/ddlUPC/,'PRICE branch must not inspect UPC selector');
assert.match(worker,/divStrL1L2/);
assert.match(worker,/lblHeaderSellingDataStoreRetail/);
assert.match(worker,/RetailPrice/);
assert.match(worker,/if\(\$mode==='PRODUCTION_UPCS'\)\{if\(!a\.length\)return;deliver\(\{status:'FOUND',outcome:'FOUND',sku:s,upcs:a\}\);return;\}/,'UPC-only branch must not require price');
assert.match(worker,/PRODUCTION_CATALOG/);
assert.match(worker,/PRODUCTION_MISC_CATALOG/);
assert.match(worker,/PRODUCTION_REPAIR_CATALOG/);
assert.doesNotMatch(activity,/divStrL1L2|lblHeaderSellingDataStoreRetail|ddlUPC/,'MainActivity must not contain production item selectors');

assert.match(app,/requestAceNetCatalog\(key,\{misc:true\}\)/,'MISC must use one full-catalog request so UPCs and other AceNet-owned fields come from the same exact-SKU page');
const miscVerificationAction=findJsFunction('aceMiscSearchAdditionalUpcs');
assert.match(miscVerificationAction,/verificationService\.retryPendingAceMiscVerification/,'MISC verification action must reuse the full-catalog verification service');
assert.doesNotMatch(miscVerificationAction,/requestAceNetPrice/,'MISC verification must not call the normal price-only lookup');
console.log('AceNet persistent isolated production lookup Stage 6 PASS');
