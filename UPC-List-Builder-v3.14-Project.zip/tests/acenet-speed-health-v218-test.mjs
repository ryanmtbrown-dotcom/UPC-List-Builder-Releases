import {readWebRuntimeSource,readNativeRuntimeSource} from './helpers/runtime-source-tree.mjs';
import fs from 'node:fs';
const kt=readNativeRuntimeSource();
const worker=fs.readFileSync('app/src/main/java/com/rmtb/upclistbuilder/PersistentAceNetWorker.kt','utf8');
const js=readWebRuntimeSource();
const html=fs.readFileSync('app/src/main/assets/www/index.html','utf8');
const ref=fs.readFileSync('ACENET_ITEM_DATA_EXTRACTION_REFERENCE.md','utf8');
const req=(v,m)=>{if(!v)throw new Error(m)};

req(js.includes('lookup_library_presented_immediately'),'library must present immediately');
req(js.includes('void enrichPresentedItemWithAceNetPrice'),'AceNet must run in background');
req(js.includes('acenet_background_price_stale_ignored'),'stale AceNet must be rejected');
req(html.includes('aceNetPriceCompare')&&html.includes('libraryPriceCompare'),'price sources must be separate');
req(js.includes('libraryPrice,aceNetPrice,labelPrice'),'three prices must persist independently');

req(kt.includes('wrapper_retailer_target_resolved'),'wrapper must resolve retailer target once');
req(worker.includes('new MutationObserver(read)'),'sole retained-worker item extraction must remain event driven');
req(!kt.includes('__upcAceObserver'),'transient MainActivity item extraction observer must remain retired');
req(!kt.includes('armAceNetResultWatchdog'),'watchdog must be absent');
req(!kt.includes('result_poll_armed'),'result polling must be absent');
req(!kt.includes('startup_direct_canary_started'),'startup canary must be absent');
req(kt.includes('if(request?.isForMainFrame != true) return'),'transient session/readiness subresource errors must be excluded');
req(kt.includes('class NativeDiagnosticJournal')&&/Executors\.newSingleThreadExecutor\(\)/.test(kt),'native diagnostics must be background queued');
req(js.includes('appendBatch(batch)')&&js.includes('setTimeout(()=>{flushTimer=null;flushDiagnosticRows()},500)'),'browser diagnostics must be asynchronously batched through the diagnostic repository');
req(/Case Cost.*not claimed.*direct AceNet ItemDetail/i.test(ref)&&/Department.*not a direct ItemDetail value/i.test(ref),'field reference must not invent direct fields');
console.log('AceNet progressive/event-driven architecture with sole worker extraction PASS');
