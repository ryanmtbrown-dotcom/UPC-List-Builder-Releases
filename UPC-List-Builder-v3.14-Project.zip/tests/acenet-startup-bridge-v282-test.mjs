import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';

const source=fs.readFileSync('app/src/main/assets/www/application/acenet-startup-service.js','utf8');
const bridgeSource=fs.readFileSync('app/src/main/assets/www/platform/bridge-registration.js','utf8');
const nativeSource=fs.readFileSync('app/src/main/java/com/rmtb/upclistbuilder/AceNetProductionCoordinator.kt','utf8');

assert.match(nativeSource,/UPCNativeAceNetStartupStatus/,'native coordinator must publish startup-state callbacks');
assert.match(nativeSource,/UPCNativeAceNetHealthStatus/,'native coordinator must publish health-state callbacks');
assert.match(nativeSource,/\.put\("startupResolved",aceNetStartupResolved\)/,'startup callback payload must state terminality explicitly');
assert.match(bridgeSource,/UPCNativeAceNetStartupStatus:raw=>aceNetStartupService\.acceptNativeStartupStatus\(raw\)/,'bridge registration must route startup status to the focused startup service');
assert.match(bridgeSource,/UPCNativeAceNetHealthStatus:raw=>aceNetStartupService\.acceptNativeHealthStatus\(raw\)/,'bridge registration must route health status to the focused startup service');
assert.doesNotMatch(source,/acenet-startup-resolved/,'retired orphan DOM-event wait must remain absent');

const context={window:{},console,setTimeout,clearTimeout};
vm.createContext(context);
vm.runInContext(source,context,{filename:'acenet-startup-service.js'});
const events=[];
const state={startupStatus:'PENDING',authenticated:false,healthStatus:'UNKNOWN',consecutiveEmptyBodies:0,consecutivePriceFailures:0,reason:'',message:''};
let nativeStatus={startupResolved:false,authenticated:false,healthStatus:'CHECKING'};
let beginCalls=0,refreshCalls=0,reconcileCalls=0,syncCalls=0;
const startupProgress=[];
const service=context.window.UPCAceNetStartupService.create({
 diagnostic:(event,data)=>events.push({event,data}),
 nativeBridgeProvider:()=>({
  beginAceNetStartup(){beginCalls++},
  getAceNetLoginStatus(){return JSON.stringify(nativeStatus)}
 }),
 getRuntimeState:()=>state,
 normalizeHealthStatus:value=>String(value||'UNKNOWN').toUpperCase(),
 refreshLoginStatus:()=>{refreshCalls++},
 reconcileAutomaticPricing:()=>{reconcileCalls++},
 syncFeatureUi:()=>{syncCalls++},
 reportStartupProgress:payload=>startupProgress.push(payload)
});

const pending=service.run();
assert.equal(beginCalls,1,'startup must invoke the native startup capability once');
service.acceptNativeStartupStatus(JSON.stringify({
 status:'CHECKING',message:'Signing into a fresh AceNet session…',authenticated:false,healthStatus:'CHECKING',startupResolved:false,startupPhase:'AUTHENTICATION',progress:62
}));
assert.equal(startupProgress.at(-1)?.startupPhase,'AUTHENTICATION','native startup phases must be forwarded to splash presentation ownership');
assert.equal(startupProgress.at(-1)?.progress,62,'native startup milestone progress must be forwarded without being discarded');
assert.equal(startupProgress.at(-1)?.message,'Signing into a fresh AceNet session…','native startup status text must reach splash presentation ownership');
nativeStatus={startupResolved:true,authenticated:true,healthStatus:'ONLINE'};
service.acceptNativeStartupStatus(JSON.stringify({
 status:'SIGNED_IN',message:'AceNet ready.',authenticated:true,healthStatus:'ONLINE',startupResolved:true,startupPhase:'PERSISTENT_VERIFY_1',progress:80,
 consecutiveEmptyBodies:0,consecutivePriceFailures:0
}));
const result=await Promise.race([
 pending,
 new Promise((_,reject)=>setTimeout(()=>reject(new Error('startup promise did not resolve from the registered native callback')),250))
]);
assert.equal(result.ready,true);
assert.equal(result.authenticated,true);
assert.equal(result.healthStatus,'ONLINE');
assert.equal(state.startupStatus,'SIGNED_IN');
assert.ok(refreshCalls>0&&reconcileCalls>0&&syncCalls>0,'terminal startup callback must refresh current UI/policy through injected owners');
assert.ok(events.some(x=>x.event==='acenet_startup_status_callback'&&x.data.startupResolved===true),'terminal startup callback diagnostic missing');
assert.equal(startupProgress.at(-1)?.startupResolved,true,'terminal native startup state must also reach splash presentation ownership');
assert.equal(startupProgress.at(-1)?.message,'AceNet ready.','terminal startup status text must be forwarded before Ready');

nativeStatus={...nativeStatus,healthStatus:'DOWN'};
service.acceptNativeHealthStatus(JSON.stringify({
 status:'DOWN',reason:'observed_server_unavailable',authenticated:true,consecutiveEmptyBodies:1,consecutivePriceFailures:2
}));
assert.equal(state.healthStatus,'DOWN');
assert.equal(state.reason,'observed_server_unavailable');
assert.equal(state.consecutiveEmptyBodies,1);
assert.equal(state.consecutivePriceFailures,2);
assert.ok(events.some(x=>x.event==='acenet_health_status_callback'&&x.data.healthStatus==='DOWN'),'health callback diagnostic missing');

console.log('AceNet registered startup/health bridge handoff v2.82 PASS');
