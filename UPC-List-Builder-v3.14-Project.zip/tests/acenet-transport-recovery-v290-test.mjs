import fs from 'node:fs';
import assert from 'node:assert/strict';

const coordinator=fs.readFileSync('app/src/main/java/com/rmtb/upclistbuilder/AceNetProductionCoordinator.kt','utf8');
const classifier=fs.readFileSync('app/src/main/java/com/rmtb/upclistbuilder/AceNetRuntimeClassifier.kt','utf8');
const health=fs.readFileSync('ACENET_SERVICE_HEALTH_CONTRACT.md','utf8');
const boundary=fs.readFileSync('ACENET_SESSION_RETRIEVAL_BOUNDARY_CONTRACT.md','utf8');
const diagnostics=fs.readFileSync('DIAGNOSTICS_CONTRACT.md','utf8');

assert.match(classifier,/fun isTransientTransportFailure\(result: JSONObject\): Boolean/);
for(const marker of ['ERR_EMPTY_RESPONSE','ERR_CONNECTION_RESET','ERR_CONNECTION_CLOSED','ERR_CONNECTION_ABORTED','ERR_TIMED_OUT'])assert.ok(classifier.includes(marker),`missing transient transport marker ${marker}`);

assert.match(coordinator,/startup_persistent_worker_transport_retry/,'startup transient transport must have a dedicated bounded retry diagnostic');
assert.match(coordinator,/retryableTransport&&boundedAttempt<2/,'startup transient transport must retry at most once');
assert.match(coordinator,/retryableTimeout&&boundedAttempt<3/,'startup timeout policy must retain its existing three-attempt ceiling');

assert.match(coordinator,/persistent_worker_timeout_after_verified_canary/,'second timeout after a healthy canary must be terminal without hard reset');
assert.match(coordinator,/production_soft_canary_verified_item_timeout/);
assert.match(coordinator,/persistent_worker_transient_network_after_verified_canary/,'repeated transient item failure after healthy canary must be terminal');
assert.match(coordinator,/production_soft_canary_verified_transient_item_failure/);
assert.match(coordinator,/TRANSIENT_TRANSPORT_UNAVAILABLE/,'transient canary failure must have an explicit operational status');
assert.match(coordinator,/"MALFORMED_PAGE","NETWORK_ERROR","SKU_MISMATCH","UNEXPECTED_HOST","TIMEOUT","SKU_TIMEOUT" -> beginAceNetProductionSoftRepair/,'initial item timeout must enter soft canary recovery');
assert.doesNotMatch(coordinator,/"TIMEOUT","SKU_TIMEOUT" -> beginAceNetProductionHardRepair/,'item timeout must not jump directly to full session repair');

assert.match(health,/first item timeout without exact-SKU field evidence uses the soft known-good canary/i);
assert.match(health,/repeated transient transport failure after a successful canary/i);
assert.match(boundary,/second item-specific timeout or classified transient transport failure terminates that request without full reauthentication/i);
assert.match(diagnostics,/soft-canary recovery choice, transient transport classification/i);

const lineCount=coordinator.endsWith('\n')?coordinator.split('\n').length-1:coordinator.split('\n').length;
assert.ok(lineCount<=2300,`AceNetProductionCoordinator exceeds architecture ceiling: ${lineCount}`);
console.log('v2.90 AceNet transient transport + soft-canary recovery PASS');
