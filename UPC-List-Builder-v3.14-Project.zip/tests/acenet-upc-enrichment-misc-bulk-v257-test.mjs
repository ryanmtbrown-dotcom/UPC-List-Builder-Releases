import {readWebRuntimeSource,readNativeRuntimeSource,findJsFunction} from './helpers/runtime-source-tree.mjs';
import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';

const app=readWebRuntimeSource();
const broker=fs.readFileSync('app/src/main/assets/www/acenet-client.js','utf8');
const html=fs.readFileSync('app/src/main/assets/www/index.html','utf8');
const db=fs.readFileSync('app/src/main/assets/www/db.js','utf8');
const misc=fs.readFileSync('app/src/main/assets/www/ace-misc.js','utf8');
const refreshService=fs.readFileSync('app/src/main/assets/www/catalog/catalog-refresh-service.js','utf8');
const miscResolution=fs.readFileSync('app/src/main/assets/www/misc/misc-resolution-service.js','utf8');
const miscDraft=fs.readFileSync('app/src/main/assets/www/misc/misc-draft-model.js','utf8');
const miscWorkspace=fs.readFileSync('app/src/main/assets/www/misc/misc-workspace-controller.js','utf8');
const normalLookup=fs.readFileSync('app/src/main/assets/www/lookup/normal-lookup-controller.js','utf8');
const listItem=fs.readFileSync('app/src/main/assets/www/work-sessions/list-item-controller.js','utf8');
const shell=fs.readFileSync('app/src/main/assets/www/application/application-shell.js','utf8');
const kt=readNativeRuntimeSource();
const worker=fs.readFileSync('app/src/main/java/com/rmtb/upclistbuilder/PersistentAceNetWorker.kt','utf8');

assert.match(html,/id="aceNetUpcEnrichmentEnabled"/,'UPC Enrichment toggle is missing.');
assert.match(html,/id="aceMiscBulkSkus"/);
assert.match(html,/id="aceMiscBulkRun"/);

assert.match(app,/const aceNetFeatureSession=\{initialized:false,comparisonEnabled:false,enrichmentPreference:false\}/);
assert.match(app,/STARTUP_DEFAULT_THEN_USER_AUTHORITY/);
assert.match(app,/function aceNetUpcEnrichmentEnabled\(\)\{return aceNetPriceCheckEnabled\(\)&&aceNetFeatureSession\.enrichmentPreference===true\}/);
assert.doesNotMatch(app,/localStorage\.setItem\(ACENET_PRICE_CHECK_PREF/,'AceNet feature toggles must be session-owned, not persisted across restarts.');
assert.match(app,/upcToggle\.disabled=false/,'UPC Enrichment preference must remain user-operable.');assert.doesNotMatch(app,/operationalSuppressed/);

const enrichmentSource=findJsFunction('enrichPresentedItemWithAceNetPrice');assert.match(enrichmentSource,/priceService\.requestPrice\(sku,\{upcEnrichment:false\}\)/,'Normal visible price must not wait for UPC enrichment.');assert.ok(enrichmentSource.indexOf('setAceNetPresentedPrice(value)')<enrichmentSource.indexOf('void enrichAceNetUpcsAfterPrice'),'Price must render before deferred UPC enrichment.');const normalUpcEnrichment=findJsFunction('enrichAceNetUpcsAfterPrice');assert.match(normalUpcEnrichment,/reconcileVerifiedUpcSetWithCatalog\(sku,ordered/);assert.match(normalUpcEnrichment,/relationshipSource:'ACENET_NORMAL_ENRICHMENT'/);assert.match(normalUpcEnrichment,/exactSkuVerified:true/,'Deferred UPC enrichment must route exact-SKU complete evidence through Stage 7 reconciliation.');
assert.match(refreshService,/plan\.relationship\.action==='REPLACE'[\s\S]*completeness:'COMPLETE',exactSkuVerified:true/,'Stage 7 policy execution must preserve complete-set replacement semantics.');
assert.match(kt,/lookupAceNetPriceWithUpcs\(requestId: String, sku: String\)/);
const priceOnlyStart=worker.indexOf("if($mode==='PRODUCTION_PRICE')");
const upcSelectorStart=worker.indexOf("var q=document.getElementById('ctl00_ctl00_contentMainPlaceHolder_MainContent_mainItemData_lvAceItemDetails_ctrl0_ddlUPC')",priceOnlyStart);
assert.ok(priceOnlyStart>=0&&upcSelectorStart>priceOnlyStart,'Price-only and UPC extraction branches must remain ordered and separate.');
const priceOnlyBranch=worker.slice(priceOnlyStart,upcSelectorStart);
assert.match(priceOnlyBranch,/deliver\(\{status:'FOUND',outcome:'FOUND',sku:s,price:p\}\);return;/,'Price-only mode must still terminate with price-only FOUND evidence.');
assert.doesNotMatch(priceOnlyBranch,/ddlUPC/,'Price-only mode must terminate before UPC extraction.');
assert.match(worker,/if\(\$mode==='PRODUCTION_PRICE_UPCS'\)\{var pp=price\(\);if\(!pp\|\|!a\.length\)return;deliver\(\{status:'FOUND',outcome:'FOUND',sku:s,price:pp,upcs:a\}\);return;\}/,'Enriched mode must wait for both price and UPCs.');
assert.equal((worker.match(/v\.loadUrl\(direct\)/g)||[]).length,1,'The retained worker must use one ItemDetail navigation per request.');

assert.match(db,/async function recordVerifiedSkuUpcs\(sku,upcs,source='ACENET_VERIFIED'\)/);
assert.match(db,/const masterUpc=normalized\[0\]/,'First ordered UPC must remain the master UPC.');
assert.match(misc,/snapshotFromMasterRecord/);
assert.match(misc,/snapshotFromAceNetCatalog/);
assert.match(misc,/item\?\.aceMiscSnapshot/,'ACE MISC export must prefer durable item snapshots.');
assert.match(misc,/UPCIdentifierRelationshipService\.recordVerifiedSkuUpcs\(normalizedSku,normalized,source,\{completeness:'COMPLETE',exactSkuVerified:true\}\)/);

const draftContext={window:{}};
vm.createContext(draftContext);vm.runInContext(miscDraft,draftContext,{filename:'misc-draft-model.js'});
const draftApi=draftContext.window.UPCMiscDraftModel.create({
 normalizeSku:v=>String(v??'').normalize('NFKC').replace(/\s+/g,'').replace(/d$/i,'').toLowerCase(),
 normalizeUpc:v=>String(v??'').replace(/\D/g,''),
 parseMoney:v=>Number(v),
 newId:()=> 'test-id',
 verificationStates:{VERIFIED_COMPLETE:'VERIFIED_COMPLETE',USER_CONFIRMED_COMPLETE:'USER_CONFIRMED_COMPLETE'}
});
assert.deepEqual(Array.from(draftApi.parseBulkSkus('3022333, 50177;\n3022333\t1234567 / 50177')),['3022333','50177','1234567']);

const editableMiscItem={
 sku:'3022333',upc:'111111111111',rawUPC:'111111111111',description:'Old Description',price:'10.00',libraryPrice:10,labelPrice:null,orderMultiple:'1',retailUnits:'1',
 aceMiscSnapshot:{version:2,source:'TEST',capturedAt:'old',baseRow:Array(33).fill(''),orderedUpcs:['111111111111','222222222222'],upcVerification:'VERIFIED_COMPLETE'}
};
editableMiscItem.aceMiscSnapshot.baseRow[0]='3022333';editableMiscItem.aceMiscSnapshot.baseRow[3]='Old Description';editableMiscItem.aceMiscSnapshot.baseRow[5]='1';editableMiscItem.aceMiscSnapshot.baseRow[6]='1';editableMiscItem.aceMiscSnapshot.baseRow[16]='10.00';
assert.equal(draftApi.applyUserEdit(editableMiscItem,'description','New Description'),true);
assert.equal(editableMiscItem.description,'New Description');assert.equal(editableMiscItem.aceMiscSnapshot.baseRow[3],'New Description','MISC description edit must update export draft');
draftApi.applyUserEdit(editableMiscItem,'upc','333333333333');
assert.deepEqual(Array.from(editableMiscItem.aceMiscSnapshot.orderedUpcs),['333333333333','111111111111','222222222222'],'MISC UPC edit must update ordered export UPCs');
draftApi.applyUserEdit(editableMiscItem,'libraryPrice','12.50');
assert.equal(editableMiscItem.price,12.5);assert.equal(editableMiscItem.aceMiscSnapshot.baseRow[16],'12.50','MISC Library Price edit must update export row price');
draftApi.applyUserEdit(editableMiscItem,'orderMultiple','4');draftApi.applyUserEdit(editableMiscItem,'retailUnits','2');
assert.equal(editableMiscItem.aceMiscSnapshot.baseRow[5],'4');assert.equal(editableMiscItem.aceMiscSnapshot.baseRow[6],'2');
const repairedSnapshot={version:2,source:'REPAIRED',baseRow:[...editableMiscItem.aceMiscSnapshot.baseRow],orderedUpcs:['444444444444'],upcVerification:'VERIFIED_COMPLETE'};
assert.equal(draftApi.applySnapshot(editableMiscItem,repairedSnapshot),true,'repair must apply through canonical MISC draft API');
assert.equal(editableMiscItem.upc,'444444444444');
assert.equal(draftApi.exportReady(editableMiscItem),true,'verified canonical snapshot must be export-ready');
assert.match(misc,/missing its canonical ACE MISC draft/,'export must require canonical draft state');

assert.match(miscWorkspace,/async function addPendingItem\(/,'manual MISC item add must be workspace-owned');
assert.match(miscWorkspace,/async function editItemField\(/,'MISC edit must be workspace-owned');
assert.match(miscWorkspace,/draftModel\.applyUserEdit\(item,key,raw\)/,'MISC workspace edits must update the canonical draft model');
assert.match(miscWorkspace,/async function removeItem\(/,'MISC deletion must be workspace-owned');
assert.match(listItem,/miscWorkspaceProvider\(\)\.addPendingItem\(pending/,'shared list-item owner must delegate manual MISC add');
assert.match(listItem,/miscWorkspaceProvider\(\)\.editItemField\(editItemIndex,key,raw\)/,'shared list-item owner must delegate MISC edit');
assert.match(listItem,/miscWorkspaceProvider\(\)\.removeItem\(index\)/,'shared list-item owner must delegate MISC deletion');


assert.match(miscWorkspace,/ACE New Items MISC\. · \$\{sessionName\(\)\}/,'Bulk import must use the injected session-name owner.');assert.match(shell,/sessionName:alaskaSessionName/,'MISC workspace composition must preserve the existing Alaska-date session naming authority.');
assert.match(miscResolution,/const evidence=await UPCEffectiveCatalogResolver\.inspectSKU\(key\),master=evidence\.master,local=evidence\.local/,'ACE MISC must obtain Master and Local evidence through Effective Catalog before AceNet.');
assert.match(miscResolution,/master\.count===1&&master\.row[\s\S]*aceMiscRefreshLibraryRecord/,'Exact official Master branch must refresh through full MISC catalog retrieval.');
assert.match(miscResolution,/local\.count===1&&local\.row[\s\S]*aceMiscFromLocalRecord/,'Local items must refresh through the same full-catalog authority.');
assert.match(miscResolution,/requestAceNetCatalog\(key,\{misc:true\}\)[\s\S]*persistVerifiedAceNetCatalogToLocalLibrary/,'Master+Local miss must persist the verified AceNet catalog to Local Library.');
assert.match(misc,/snapshotFromLibraryAndAceNet/,'Known library items must merge live AceNet-owned fields onto the library baseline.');
assert.match(miscWorkspace,/for\(let i=0;i<skus\.length;i\+\+\)[\s\S]*await processAceMiscBulkSku\(list,sku\)/,'Bulk processing must be sequential.');
assert.match(miscWorkspace,/catch\(e\)\{results\.push\(\{sku,status:'FAILED'/,'One failed SKU must not abort the batch.');
assert.match(miscWorkspace,/status:'SKIPPED_EXISTING'/,'Existing SKU must be skipped rather than duplicated.');
assert.match(broker,/BROKER_TIMEOUT_FALLBACK_MS=52000/,'Unified broker must sit just outside native incident ownership.');assert.match(shell,/requestUpcs:sku=>UPCAceNetClient\.requestUpcs\(sku\)/,'Normal lookup composition must delegate deferred UPC bookkeeping to the unified broker.');

assert.match(kt,/lookupAceNetMiscCatalog\(requestId: String, sku: String\)/);
assert.match(kt,/PRODUCTION_MISC_CATALOG/);
assert.match(worker,/if\(\$mode==='PRODUCTION_MISC_CATALOG'\|\|\$mode==='PRODUCTION_REPAIR_CATALOG'\)required\.push\('omWeight'\)/,'AceNet-only MISC snapshot must require weight before completion.');


assert.match(miscResolution,/record:row,evidence:catalog/,'ACE MISC refresh must pass its resolved row to Catalog Refresh Policy.');

async function exerciseAceMiscLiveRefresh(libraryKind){
 const row={id:940341,originalUPC:'195949371196',upcKey:'195949371196',fields:{'UPC/EAN':'195949371196'}};
 const policyCalls=[],diagnostics=[];
 const catalog={sku:'3022333',allUpcs:['195949371196'],masterUpc:'195949371196',aceRetailPrice:'149.99'};
 const runtime={window:{}};
 vm.createContext(runtime);vm.runInContext(miscResolution,runtime,{filename:'misc-resolution-service.js'});
 const service=runtime.window.UPCMiscResolutionService.create({
  effectiveResolver:{inspectSKU:async()=>libraryKind==='LOCAL'?{master:{count:0,row:null},local:{count:1,row}}:{master:{count:1,row},local:{count:0,row:null}}},
  localRepository:{lookupSKU:async()=>({count:1,row})},
  relationshipService:{getSkuUpcs:async()=>[]},
  catalogRefreshService:{applyCatalogRefreshPolicyToExistingRecord:async args=>{policyCalls.push(args);return{storage:{updated:false}}}},
  normalLookupController:{lookupItemBySku:async()=>({status:'FOUND'})},
  itemMapper:{itemFromLibraryRow:()=>({status:'FOUND',sku:'3022333',upc:'195949371196',fields:{}})},
  miscDomain:{UPC_VERIFICATION:{VERIFIED_COMPLETE:'VERIFIED_COMPLETE'},snapshotFromLibraryAndAceNet:()=>({orderedUpcs:['195949371196']})},
  draftModel:{storedDraftUpcs:()=>['195949371196'],bulkItemFromResolved:item=>item,decorateItem:item=>item},
  normalizeSku:v=>String(v??'').trim(),
  requestCatalog:async()=>({status:'VERIFIED',sku:'3022333',catalog}),
  diagnostic:(event,payload)=>diagnostics.push({event,payload})
 });
 const result=await service.aceMiscRefreshLibraryRecord('3022333',row,{libraryKind,relationshipSource:'ACENET_MISC_REGRESSION'});
 assert.equal(result.status,'FOUND');
 assert.equal(policyCalls.length,1);
 assert.strictEqual(policyCalls[0].record,row,'Catalog Refresh Policy must receive the exact resolved catalog row.');
 assert.equal(policyCalls[0].target,libraryKind==='LOCAL'?'LOCAL_LIBRARY':'MASTER_LIBRARY');
 assert.equal(policyCalls[0].evidence.sku,'3022333');
 assert.equal(diagnostics.some(x=>x.event==='ace_misc_full_catalog_ready'),true);
}
await exerciseAceMiscLiveRefresh('MASTER');
await exerciseAceMiscLiveRefresh('LOCAL');

console.log('v2.64 AceNet UPC enrichment + durable ACE MISC Master/Local/AceNet workflow PASS');
