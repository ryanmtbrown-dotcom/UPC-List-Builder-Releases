import vm from 'node:vm';
import assert from 'node:assert/strict';
import {extractPersistentWorkerScript,makeWorkerBridge} from './helpers/persistent-worker-script.mjs';

const script=extractPersistentWorkerScript({expected:'2496750',mode:'PRODUCTION_UPCS'});
class MutationObserver{constructor(cb){this.cb=cb}observe(){}disconnect(){}}
const skuId='ctl00_ctl00_contentMainPlaceHolder_MainContent_headerSkuDataBar_lblSkuNr';
const upcId='ctl00_ctl00_contentMainPlaceHolder_MainContent_mainItemData_lvAceItemDetails_ctrl0_ddlUPC';
function run(options){
  const results=[],diagnostics=[];
  const select={id:upcId,tagName:'SELECT',options:options.map(x=>({value:x,textContent:x}))};
  const document={
    readyState:'complete',title:'',scripts:[],body:{innerText:''},location:{href:'https://retailer.aceservices.com/'},
    documentElement:{outerHTML:'<html></html>'},
    getElementById:id=>id===skuId?{textContent:'2496750'}:id===upcId?select:null,
    querySelector:()=>null,
    querySelectorAll:sel=>sel==='iframe'?[]:[]
  };
  const context={document,MutationObserver,PersistentAceNetBridge:makeWorkerBridge({diagnostics,results}),JSON,Array,String,RegExp};
  context.window=context;
  vm.runInNewContext(script,context);
  return{results,diagnostics};
}
let out=run(['082901501770','082901501770','0 82901 50177 0','12345','12345678901234']).results;
assert.equal(out.length,1);
assert.equal(out[0].sku,'2496750');
assert.deepEqual(Array.from(out[0].upcs),['082901501770','12345678901234']);
assert.equal(run([]).results.length,0,'empty UPC selector must wait');
console.log('PASS acenet-upc-extractor-v219-test via PersistentAceNetWorker');
