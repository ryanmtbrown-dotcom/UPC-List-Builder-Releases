import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';

const policySource=fs.readFileSync('app/src/main/assets/www/catalog-refresh-policy.js','utf8');
const refreshServiceSource=fs.readFileSync('app/src/main/assets/www/catalog/catalog-refresh-service.js','utf8');
const identitySource=fs.readFileSync('app/src/main/assets/www/identity/identity-work-controller.js','utf8');
const dbSource=fs.readFileSync('app/src/main/assets/www/db.js','utf8');

const stageStart=dbSource.indexOf('async function stageLocalLibraryAceNetItem('),moneyStart=dbSource.indexOf('const money=v=>',stageStart),moneyEnd=dbSource.indexOf(',clean=v=>',moneyStart);
assert.ok(stageStart>0&&moneyStart>stageStart&&moneyEnd>moneyStart,'Local Library staging money normalizer must be extractable');
const stageMoney=vm.runInNewContext('('+dbSource.slice(moneyStart+'const money='.length,moneyEnd)+')');
assert.equal(stageMoney('12.50'),'12.50');
assert.equal(stageMoney('$1,234.56'),'1234.56');
assert.equal(stageMoney('Each Cost $12.50'),'12.50');
assert.equal(stageMoney('Each Cost unavailable'),'');
assert.equal(stageMoney('-$12.50'),'');

assert.match(identitySource,/async function processQueuedLocalLibrarySku/,'identity owner must own per-SKU queue processing');
assert.match(identitySource,/async function runAddToLocalLibraryBatch/,'identity owner must own the sequential batch');
assert.match(identitySource,/for\(const row of queued\)[\s\S]*await processQueuedLocalLibrarySku\(key\)/,'batch must remain sequential');
assert.doesNotMatch(identitySource,/window\.UPCRunAddToLibraryBatch/,'retired global batch entry point must not return');

const queue=[{sku:'1001'},{sku:'1002'},{sku:'1003'}];
const calls=[],staged=[],relationships=[],removed=[],diagnostics=[],alerts=[],localRows=new Map();
const host={innerHTML:'',querySelectorAll(){return[]}};
const catalogs={
 '1001':{sku:'1001',masterUpc:'111111111111',allUpcs:['111111111111','111111111112'],description:'ONE'},
 '1003':{sku:'1003',masterUpc:'333333333333',allUpcs:['333333333334','333333333333'],description:'THREE'}
};
const localRepository={
 async getUpdateQueue(){return queue.filter(x=>!removed.includes(x.sku)).map(x=>({...x}))},
 async lookupSKU(sku){const row=localRows.get(String(sku));return{count:row?1:0,row:row||null}},
 async stageAceNetItem(catalog){staged.push(catalog.sku);const row={id:'local-'+catalog.sku,skuKey:catalog.sku,upcKey:catalog.masterUpc,originalUPC:catalog.masterUpc,fields:{Description:catalog.description||''},source:'LOCAL_ADDITION'};localRows.set(catalog.sku,row);return{created:true,row}},
 async removeUpdateQueueSku(sku){removed.push(String(sku))}
};
const masterRepository={async lookupSKU(){return{count:0,row:null}},async updateMasterUpc(){}};
const relationshipService={
 async getResearchQueue(){return[]},async getResearch(){return null},async getConflictQueue(){return[]},async getDeferredAceNetRefreshQueue(){return[]},async setSkuIdentityStatus(){},async removeResearch(){},async removeDeferredAceNetRefresh(){},async enqueueDeferredAceNetRefresh(){},
 async recordVerifiedSkuUpcs(sku,upcs,source,options){relationships.push({sku,upcs:[...upcs],source,options});return{skuKey:sku,upcs:[...upcs],masterUpc:upcs[0],conflictCount:0,removed:0}}
};
const effectiveResolver={async inspectSKU(sku){return{master:await masterRepository.lookupSKU(sku),local:await localRepository.lookupSKU(sku)}}};
const normalizeSku=v=>String(v??'').replace(/\D/g,''),normalizeUpc=v=>String(v??'').replace(/\D/g,'');
const context={window:{},Date,Set,Map,Object,String,Array,Number,Promise,Math,UPCIdentifierNormalization:{normalizeSKU:normalizeSku,normalizeUPC:normalizeUpc}};
vm.createContext(context);
vm.runInContext(policySource,context,{filename:'catalog-refresh-policy.js'});
const policy=context.window.UPCCatalogRefreshPolicy;
vm.runInContext(refreshServiceSource,context,{filename:'catalog-refresh-service.js'});
const refreshService=context.window.UPCCatalogRefreshService.create({
 policy,masterRepository,localRepository,relationshipService,effectiveResolver,
 normalizeSku,normalizeUpc,resolveRetailUnits:async()=>({value:'1',source:'DEFAULT_NO_LIBRARY_RU'}),
 diagnostic:(event,payload={})=>diagnostics.push({event,payload})
});
vm.runInContext(identitySource,context,{filename:'identity-work-controller.js'});
const identity=context.window.UPCIdentityWorkController.create({
 elementById:id=>id==='identityWorkQueues'?host:null,escapeHtml:v=>String(v??''),normalizeSku,normalizeUpc,
 localRepository,relationshipService,catalogRefreshService:refreshService,
 requestCatalog:async sku=>{calls.push(String(sku));if(String(sku)==='1002')return{status:'TIMEOUT',catalog:null};return{status:'VERIFIED',catalog:catalogs[String(sku)]}},
 normalLookupProvider:()=>({lookupItemBySku:async()=>({status:'NOT_FOUND'})}),
 workSessionService:{list:async()=>[],save:async x=>x},getCurrentSession:()=>null,newId:()=>String(Math.random()),
 sessionName:()=> 'Oct 4, 2026',messageUser:async()=>{},alertUser:m=>alerts.push(String(m)),promptUser:async()=>null,confirmUser:async()=>true,comparisonEnabled:()=>true,
 libraryWorkflowProvider:()=>({refreshQueue:async()=>{}}),diagnostic:(event,payload={})=>diagnostics.push({event,payload})
});
await identity.runAddToLocalLibraryBatch();

assert.deepEqual(calls,['1001','1002','1003'],'catalog requests must execute sequentially and continue after a deferred SKU');
assert.deepEqual(staged,['1001','1003'],'only verified catalog results may persist Local Library rows');
assert.deepEqual(removed,['1001','1003'],'successful SKUs leave the queue while deferred SKU remains');
assert.deepEqual((await localRepository.getUpdateQueue()).map(x=>x.sku),['1002']);
for(const [sku,expected] of [['1001',['111111111111','111111111112']],['1003',['333333333334','333333333333']]]){
 const rel=relationships.find(x=>x.sku===sku);
 assert.deepEqual([...(rel?.upcs||[])].sort(),[...expected].sort(),sku+' must persist every returned UPC through the shared relationship owner');
 assert.deepEqual(JSON.parse(JSON.stringify(rel?.options)),{completeness:'COMPLETE',exactSkuVerified:true});
}
assert.ok(diagnostics.some(x=>x.event==='local_library_catalog_persist_verified'&&x.payload.sku==='1001'),'shared persistence must verify Local Library read-back');
assert.ok(diagnostics.some(x=>x.event==='identity_local_library_batch_completed'&&x.payload.completed===2&&x.payload.deferred===1&&x.payload.failed===0),'batch terminal diagnostic must report 2 completed / 1 deferred / 0 failed');
assert.ok(diagnostics.filter(x=>x.event==='identity_work_queues_rendered').length>=4,'queue refresh must execute throughout the focused batch path');
assert.match(alerts.at(-1),/2 completed; 1 deferred; 0 failed/);
console.log('v2.64 Add to Local Library focused-owner durable persistence batch + live cost normalization: PASS');
