import {readNativeRuntimeSource} from './helpers/runtime-source-tree.mjs';
import fs from 'node:fs';
import assert from 'node:assert/strict';
const native=readNativeRuntimeSource();
const activity=fs.readFileSync('app/src/main/java/com/rmtb/upclistbuilder/MainActivity.kt','utf8');
const coordinator=fs.readFileSync('app/src/main/java/com/rmtb/upclistbuilder/AceNetProductionCoordinator.kt','utf8');
const nativeDiagnostic=fs.readFileSync('app/src/main/assets/www/diagnostics/acenet-native-diagnostic-service.js','utf8');
const contract=fs.readFileSync('APPLICATION_LIFECYCLE_CONTRACT.md','utf8');
const onStop=coordinator.slice(coordinator.indexOf('fun onStop()'),coordinator.indexOf('fun handleBackPressed()',coordinator.indexOf('fun onStop()')));

for(const needle of [
  'startup_request_retained_for_background',
  'CONTINUE_IN_BACKGROUND_REVALIDATE_FAILURE_ON_FOREGROUND',
  'backgrounded_startup_still_running_after_foreground',
  'backgrounded_startup_terminal_retained',
  'backgrounded_startup_foreground_revalidation_started',
  'ONE_FOREGROUND_REVALIDATION',
  'reconcileBackgroundedStartupAfterForeground()',
  'active_request_interrupted_for_background',
  '"INTERRUPTED"',
  '"healthDecision","NONE"',
  '"downDeclared",false'
])assert.ok(native.includes(needle),'Lifecycle requirement missing: '+needle);

assert.doesNotMatch(onStop,/startup_interrupted_for_background/,'backgrounding must not destroy the active startup worker');
assert.doesNotMatch(onStop,/startup_request_invalidated_for_background/,'backgrounding must not invalidate the active startup request');
assert.match(onStop,/aceNetStartupBackgroundedDuringCheck=true/,'backgrounding during startup must retain explicit lifecycle context');
assert.match(coordinator,/if\(!aceNetStartupResolved\)\{aceNetNativeDiagnostic\("backgrounded_startup_still_running_after_foreground"/,'foreground return must preserve a still-running startup');
assert.match(coordinator,/aceNetHealthStatus=="ONLINE" \|\| aceNetHealthStatus=="DOWN"/,'verified ONLINE or authoritative DOWN background results must remain authoritative');
assert.match(coordinator,/restartPersistentAceNetWarmup\("backgrounded_startup_foreground_revalidation"/,'non-ONLINE background result must get one foreground warm-up revalidation');

for(const hook of ['override fun onStart()','override fun onResume()','override fun onPause()','override fun onStop()','override fun onBackPressed()','override fun onDestroy()'])assert.ok(activity.includes(hook),'MainActivity lifecycle hook missing: '+hook);
for(const delegate of ['aceNetCoordinator.onStart()','aceNetCoordinator.onResume()','aceNetCoordinator.onPause()','aceNetCoordinator.onStop()','aceNetCoordinator.handleBackPressed()','aceNetCoordinator.destroy()'])assert.ok(activity.includes(delegate),'MainActivity AceNet lifecycle delegation missing: '+delegate);

for(const needle of [
  "application_backgrounded:['Record that Android moved UPC List Builder fully into the background.",
  "startup_request_retained_for_background:['Retain the in-flight AceNet startup request across Android backgrounding.",
  "backgrounded_startup_still_running_after_foreground:['Observe a retained startup that is still running after foreground return.",
  "backgrounded_startup_terminal_retained:['Accept a terminal result produced by startup work that continued across backgrounding.",
  "backgrounded_startup_foreground_revalidation_started:['Revalidate a non-ONLINE backgrounded startup after foreground return.",
  "startOperation('ANDROID_BACKGROUND_STARTUP'",
  "observeOperation('ANDROID_BACKGROUND_STARTUP'",
  "finishOperation('ANDROID_BACKGROUND_STARTUP'",
  'No AceNet health decision was made by this lifecycle event.',
  'canary SKU 50177'
])assert.ok(nativeDiagnostic.includes(needle),'Lifecycle diagnostic observability missing: '+needle);
assert.doesNotMatch(nativeDiagnostic,/startup_request_invalidated_for_background|interrupted_startup_recheck_started|canary SKU 3022333/,'obsolete background-cancellation/canary diagnostics must be absent');

assert.match(contract,/in-flight AceNet startup WebView\/worker remains owned by the same coordinator and is allowed to continue/);
assert.match(contract,/exactly one foreground warm-up revalidation is required/);
assert.match(contract,/diagnostic-only and must not alter lifecycle or AceNet operational behavior/);
console.log('Current background-retained startup lifecycle and diagnostic requirements PASS');
