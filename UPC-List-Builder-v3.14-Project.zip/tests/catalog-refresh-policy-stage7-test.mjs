import {readWebRuntimeSource} from './helpers/runtime-source-tree.mjs';
import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';

const source=fs.readFileSync('app/src/main/assets/www/catalog-refresh-policy.js','utf8');
const app=readWebRuntimeSource();
const db=fs.readFileSync('app/src/main/assets/www/db.js','utf8');
const refreshService=fs.readFileSync('app/src/main/assets/www/catalog/catalog-refresh-service.js','utf8');
const appShell=fs.readFileSync('app/src/main/assets/www/application/application-shell.js','utf8');
const identityWork=fs.readFileSync('app/src/main/assets/www/identity/identity-work-controller.js','utf8');
const masterRepo=fs.readFileSync('app/src/main/assets/www/master-repository.js','utf8');
const localRepo=fs.readFileSync('app/src/main/assets/www/local-repository.js','utf8');
new Function(app);new Function(db);
const context={window:{},Date,Set,Object,String,Array,UPCIdentifierNormalization:{normalizeSKU:v=>String(v??'').trim(),normalizeUPC:v=>String(v??'').replace(/\D/g,'')}};
vm.createContext(context);vm.runInContext(source,context,{filename:'catalog-refresh-policy.js'});
const policy=context.window.UPCCatalogRefreshPolicy;

const master={id:'m1',skuKey:'100',upcKey:'111',originalUPC:'111',source:'MASTER',fields:{Description:'CURATED','Ace Retail Price':'9.99','Retailer Each Cost':'5.00','UPC/EAN':'111'}};
let p=policy.plan({target:'MASTER_LIBRARY',expectedSku:'100',storedRecord:master,evidence:{sku:'100',aceRetailPrice:'10.49',masterUpc:'222',allUpcs:['222','333'],description:'LONGER WEB DESCRIPTION',retailerEachCost:'6.00'},exactSkuVerified:true,completeUpcSet:true});
assert.equal(p.status,'APPLICABLE');
assert.equal(p.fieldActions.aceRetailPrice.action,'PRESERVE');
assert.equal(p.fieldActions.aceRetailPrice.reason,'MASTER_SNAPSHOT_FIELD_PROTECTED');
assert.equal(p.fieldActions.masterUpc.action,'UPDATE');
assert.equal(p.fieldActions.description.action,'PRESERVE');
assert.equal(p.fieldActions.retailerEachCost.action,'PRESERVE');
assert.equal(p.relationship.action,'REPLACE');
assert.deepEqual(Array.from(p.relationship.upcs),['222','333']);

p=policy.plan({target:'MASTER_LIBRARY',expectedSku:'100',storedRecord:master,evidence:{sku:'WRONG',masterUpc:'222',allUpcs:['222']},exactSkuVerified:true,completeUpcSet:true});
assert.equal(p.status,'REJECTED');
assert.equal(p.reason,'EXACT_SKU_NOT_VERIFIED');

const missingSku=policy.plan({target:'MASTER_LIBRARY',expectedSku:'100',storedRecord:master,evidence:{masterUpc:'222',allUpcs:['222']},exactSkuVerified:true,completeUpcSet:true});
assert.equal(missingSku.status,'REJECTED');
assert.equal(missingSku.reason,'EXACT_SKU_NOT_VERIFIED');

const local={id:'l1',skuKey:'100',upcKey:'111',originalUPC:'111',source:'LOCAL_ADDITION',fields:{Description:'LOCAL DESC','Retailer Each Cost':'5.00','MFG #':'OLD','Order Multiple':'1',Weight:'2','Ace Retail Price':'9.99','Retail Units':'4','Commodity Group':'60','Merchandise Class Number':'610','Product Group Number':'03','UPC/EAN':'111'},userCorrections:{manufacturerNumber:{value:'USER-MFG'}}};
p=policy.plan({target:'LOCAL_LIBRARY',expectedSku:'100',storedRecord:local,evidence:{sku:'100',description:'NEW WEB DESC',retailerEachCost:'5.50',manufacturerNumber:'NEW-MFG',orderMultiple:'2',omWeight:'3',aceRetailPrice:'10.49',retailUnits:'99',commodityGroup:'61',merchandiseClassNumber:'611',productGroupNumber:'04',masterUpc:'222',allUpcs:['222','333']},exactSkuVerified:true,completeUpcSet:true});
assert.equal(p.fieldActions.description.action,'PRESERVE');
assert.equal(p.fieldActions.manufacturerNumber.action,'PRESERVE');
for(const field of ['retailerEachCost','orderMultiple','omWeight','aceRetailPrice','commodityGroup','merchandiseClassNumber','productGroupNumber'])assert.equal(p.fieldActions[field].action,'UPDATE',field);
assert.equal(p.fieldActions.retailUnits.action,'PRESERVE');
assert.equal(p.fieldActions.masterUpc.action,'UPDATE');

const blankLocal={...local,fields:{...local.fields,Description:''},userCorrections:{}};
p=policy.plan({target:'LOCAL_LIBRARY',expectedSku:'100',storedRecord:blankLocal,evidence:{sku:'100',description:'ACE DESC'},exactSkuVerified:true});
assert.equal(p.fieldActions.description.action,'UPDATE');
assert.equal(p.fieldActions.description.reason,'DESCRIPTION_FILL_ONLY');

p=policy.plan({target:'LOCAL_LIBRARY',expectedSku:'100',storedRecord:blankLocal,evidence:{sku:'100',allUpcs:['222']},exactSkuVerified:true,completeUpcSet:false,repairPartial:true,missingFields:['commodityGroup']});
assert.equal(p.fieldActions.commodityGroup.action,'PRESERVE');
assert.equal(p.fieldActions.commodityGroup.reason,'PARTIAL_OR_MISSING_EVIDENCE_NOT_DESTRUCTIVE');
assert.equal(p.relationship.action,'MERGE');
assert.equal(p.relationship.masterUpc,'111');
assert.deepEqual(Array.from(p.relationship.upcs),['111','222']);

assert.match(masterRepo,/updateMasterUpc:UPCDB\.updateActiveLibraryMasterUpc/);
assert.match(localRepo,/updateMasterUpc:UPCDB\.updateLocalLibraryMasterUpc/);
assert.equal((db.match(/async function updateLocalLibraryMasterUpc\(/g)||[]).length,1);
assert.match(refreshService,/UPCCatalogRefreshPolicy\.plan\(/);
assert.doesNotMatch(appShell,/async function applyCatalogRefreshPolicyToExistingRecord\(/,'application shell must not own catalog refresh execution');
assert.match(appShell,/UPCCatalogRefreshService\.create\(/,'application composition root must explicitly construct the catalog refresh owner');
assert.match(identityWork,/catalogRefreshService\.persistVerifiedAceNetCatalogToLocalLibrary\(/,'catalog consumers must call the constructed refresh service');
assert.doesNotMatch(refreshService,/evidence:\{\.\.\.\(evidence\|\|\{\}\),sku:key\}/,'Stage 7 helper must not rewrite evidence SKU before exact-SKU validation');
assert.match(refreshService,/returnedSku=null,exactSkuVerified=false/,'UPC-set reconciliation must require explicit returned-SKU proof');
assert.doesNotMatch(app,/LOCAL_TO_MASTER_PROMOTION_DISABLED/,'Stage 9 must remove transitional Local-to-Master promotion markers.');
for(const event of ['catalog_refresh_policy_rejected','catalog_refresh_policy_applied','catalog_refresh_master_upc_update_started','catalog_refresh_master_upc_update_completed','catalog_refresh_master_upc_update_failed'])assert.ok(app.includes(event),`Stage 7 diagnostic missing: ${event}`);
assert.doesNotMatch(app,/UPCMasterRepository\.updatePrice\(record\.id,key,plan\.fieldActions\.aceRetailPrice/,'physical Master price must not be rewritten by Stage 7 live refresh');
assert.doesNotMatch(app,/reconcilePromoted\?await UPCMasterRepository\.reconcilePromotedLocalRecord/);
console.log('Stage 7 Catalog Refresh Policy core semantics PASS');
