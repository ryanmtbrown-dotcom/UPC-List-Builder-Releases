import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import {readWebRuntimeSource,readNativeRuntimeSource,findJsFunction} from './helpers/runtime-source-tree.mjs';

// Authority: user's explicit requirement that AceNet breadcrumb classifications are
// reduced to their numeric codes for durable storage/mapping, plus the current
// ACE MISC contract requiring POSDEPT derivation from Commodity Group.
const identifierSource=fs.readFileSync('app/src/main/assets/www/identifier-normalization.js','utf8');
const mapperSource=fs.readFileSync('app/src/main/assets/www/catalog/catalog-mappers.js','utf8');
const exportSchemaSource=fs.readFileSync('app/src/main/assets/www/catalog/standard-export-schema.js','utf8');
const miscSource=fs.readFileSync('app/src/main/assets/www/ace-misc.js','utf8');
const miscContext={console,window:{}};
vm.createContext(miscContext);
vm.runInContext(identifierSource+'\n'+mapperSource+'\n'+exportSchemaSource+'\n'+miscSource+';globalThis.__ACEMisc=ACEMisc;',miscContext);
const ACEMisc=miscContext.__ACEMisc;

const record={
  fields:{
    'ACE SKU':'6096856',
    'Description':'DREO 5118 Btu/h 250-300 sq ft Oil Filled Electric Radiator Heater',
    'MFG #':'DR-HSH011',
    'Order Multiple':'1',
    'Retail Units':'1',
    'Weight':'25.78',
    'Retailer Each Cost':'109.65',
    'Ace Retail Price':'139.99',
    'Commodity Group':'60 - Appliances And Home Entertainment',
    'Merchandise Class Number':'610 - Portable Electric Heaters',
    'Product Group Number':'03 - Oil-Filled'
  }
};
const upcs=['810181284478','850054613783'];

for(const [kind,snapshot] of [
  ['Local',ACEMisc.snapshotFromLocalRecord(record,'6096856',upcs)],
  ['Master',ACEMisc.snapshotFromMasterRecord(record,'6096856',upcs)]
]){
  assert.equal(snapshot.baseRow[23],'60',kind+' Commodity Group must be numeric code only');
  assert.equal(snapshot.baseRow[24],'610',kind+' Merchandise Class must be numeric code only');
  assert.equal(snapshot.baseRow[25],'03',kind+' Product Group must preserve numeric code including leading zero');
  assert.equal(snapshot.baseRow[30],'68',kind+' POSDEPT must derive from Commodity Group 60');
  assert.deepEqual([...snapshot.orderedUpcs],upcs,kind+' UPC ordering must remain unchanged');
}

const dbSource=fs.readFileSync('app/src/main/assets/www/db.js','utf8');
const helperSource=mapperSource.match(/function normalizeLocalClassificationCode\(value\)\{[^\n]+\}/)?.[0]||'';
assert.ok(helperSource,'normalizeLocalClassificationCode must live in the catalog mapper owner');
assert.doesNotMatch(dbSource,/function normalizeLocalClassificationCode\(/,'db.js must not own pure catalog classification mapping');
const helperContext={};
vm.createContext(helperContext);
vm.runInContext(helperSource+';globalThis.__normalize=normalizeLocalClassificationCode;',helperContext);
const normalize=helperContext.__normalize;
assert.equal(normalize('60 - Appliances And Home Entertainment'),'60');
assert.equal(normalize('610 - Portable Electric Heaters'),'610');
assert.equal(normalize('03 - Oil-Filled'),'03');
assert.equal(normalize(''),'');
const stageLocal=findJsFunction('stageLocalLibraryAceNetItem');
const correction=findJsFunction('normalizeLocalCorrectionValue');
assert.match(stageLocal,/commodityGroup:normalizeLocalClassificationCode\(c\.commodityGroup\)/);
assert.match(stageLocal,/merchandiseClassNumber:normalizeLocalClassificationCode\(c\.merchandiseClassNumber\)/);
assert.match(stageLocal,/productGroupNumber:normalizeLocalClassificationCode\(c\.productGroupNumber\)/);
assert.doesNotMatch(stageLocal,/commodityGroup:clean\(c\.commodityGroup\)/);
assert.match(correction,/normalizeLocalClassificationCode\(raw\)/);

console.log('v2.66 classification-code normalization regression PASS');
