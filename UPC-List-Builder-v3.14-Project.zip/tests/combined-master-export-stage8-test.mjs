import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';

const source=fs.readFileSync('app/src/main/assets/www/combined-master-export.js','utf8');
const workflow=fs.readFileSync('app/src/main/assets/www/library-workflow-v093.js','utf8');
const html=fs.readFileSync('app/src/main/assets/www/index.html','utf8');

assert.doesNotMatch(source,/saveMetadata|stageGeneration|cleanupGenerations|updateMasterUpc|updateAceNetFields|stageAceNetItem/,'Combined Master owner must remain read-only');
assert.match(source,/officialSkus\.has\(sku\)\|\|officialUpcs\.has\(upc\)/);
assert.match(source,/return await XLSXExporter\.build/,'Combined Master workbook generation must await the async XLSX builder');
assert.doesNotMatch(workflow,/XLSXExporter\.build/,'Stage 9 retired shadow Library XLSX workflow must not remain as a second builder caller');
assert.doesNotMatch(source,/PROMOTED_MASTER|promotedMasterRowsIgnored|Legacy promoted|isPromoted/,'Stage 9 Combined Master must not retain promoted-copy compatibility');
for(const event of ['combined_master_export_started','combined_master_export_composed','combined_master_export_completed','combined_master_export_failed'])assert.match(source,new RegExp(event));
assert.match(source,/suppressedSampleTruncated/,'suppression diagnostics must remain bounded');
assert.match(html,/id="exportCombinedMaster"/);assert.match(html,/combined-master-export\.js\?v=/);

let localRows=[
 {id:'l1',skuKey:'100',upcKey:'999',originalUPC:'999',source:'LOCAL_ADDITION',fields:{SKU:'100','UPC/EAN':'999',Description:'LOSE SKU'}},
 {id:'l2',skuKey:'300',upcKey:'111',originalUPC:'111',source:'LOCAL_ADDITION',fields:{SKU:'300','UPC/EAN':'111',Description:'LOSE UPC'}},
 {id:'l3',skuKey:'200',upcKey:'222',originalUPC:'222',source:'LOCAL_ADDITION',fields:{SKU:'200','UPC/EAN':'222',Description:'LOCAL 200'}},
 {id:'l4',skuKey:'400',upcKey:'444',originalUPC:'444',source:'LOCAL_ADDITION',fields:{SKU:'400','UPC/EAN':'444',Description:'LOCAL 400'}}
];
const active=[
 {id:'m1',skuKey:'100',upcKey:'111',originalUPC:'111',source:'MASTER_IMPORT',fields:{SKU:'100','UPC/EAN':'111',Description:'OFFICIAL 100',Mystery:'KEEP'}}
],meta={generation:'g1',fileName:'Home Office Master.xlsx',headers:['SKU','UPC/EAN','Description','Mystery'],skuHeader:'SKU',upcHeader:'UPC/EAN',skuIndex:3,upcIndex:2},deliveryCalls=[],buildCalls=[],events=[];

const context={window:{},UPCIdentifierNormalization:{normalizeSKU:v=>String(v??'').trim(),normalizeUPCUnicodeCompatible:v=>String(v??'').replace(/\D/g,'')},UPCMasterRepository:{getMetadata:async()=>meta,getActiveRecords:async()=>active},UPCLocalRepository:{getRecords:async()=>localRows},XLSXExporter:{MIME:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',build:async(headers,rows,options)=>{await Promise.resolve();buildCalls.push({headers:[...headers],rows:rows.map(r=>[...r]),options});return new Uint8Array([1,2,3,4])}},diag:(event,data)=>events.push({event,data}),console,Set,Map,Object,String,Array,Number,RegExp,Error,Promise,Uint8Array};
vm.createContext(context);vm.runInContext(source,context,{filename:'combined-master-export.js'});
const api=context.window.UPCCombinedMasterExport;assert.ok(api);

const composed=await api.compose();
assert.deepEqual([...composed.headers],meta.headers);
assert.equal(composed.stats.officialRows,1);
assert.equal('promotedMasterRowsIgnored' in composed.stats,false);
assert.equal(composed.stats.localRowsIncluded,2);
assert.equal(composed.stats.localRowsSuppressed,2);
assert.equal(composed.stats.outputRows,3);
assert.deepEqual([...composed.rows[0]],['100','111','OFFICIAL 100','KEEP']);
assert.deepEqual([...composed.rows[1]],['200','222','LOCAL 200','']);
assert.deepEqual([...composed.rows[2]],['400','444','LOCAL 400','']);
assert.equal(composed.suppressed.find(x=>x.sku==='100')?.reason,'OFFICIAL_MASTER_SKU');
assert.equal(composed.suppressed.find(x=>x.sku==='300')?.reason,'OFFICIAL_MASTER_UPC');

const fileDelivery={deliverBytes:(...args)=>deliveryCalls.push(args)};
const exported=await api.exportWorkbook(composed,'Combined Test',fileDelivery);
assert.equal(exported.name,'Combined Test.xlsx');assert.equal(exported.rowCount,3);assert.equal(buildCalls.length,1);
assert.deepEqual(buildCalls[0].headers,meta.headers);
assert.deepEqual([...buildCalls[0].options.textColumns].sort((a,b)=>a-b),[0,1],'identifier text columns must derive from current header names, not stale stored indices');
assert.equal(deliveryCalls.length,1);assert.deepEqual([...deliveryCalls[0][0]],[1,2,3,4]);assert.equal(deliveryCalls[0][1],'Combined Test.xlsx');assert.equal(deliveryCalls[0][2],context.XLSXExporter.MIME);
assert.ok(events.some(x=>x.event==='combined_master_export_started'));assert.ok(events.some(x=>x.event==='combined_master_export_completed'));

localRows=[localRows[2],{...localRows[2],id:'dup',upcKey:'555',originalUPC:'555',fields:{...localRows[2].fields,'UPC/EAN':'555'}}];
await assert.rejects(()=>api.compose(),/ambiguous duplicate identity/);

console.log('Stage 9 Combined Master official-only composition contract PASS');
