import {readWebRuntimeSource} from './helpers/runtime-source-tree.mjs';
import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';

const clone=value=>JSON.parse(JSON.stringify(value));
const source=fs.readFileSync('app/src/main/assets/www/data-backup.js','utf8');

function fakeDatabase(initial,{failOnMarker=false}={}){
  let committed=clone(initial);
  return {
    name:'upc-list-builder',
    version:8,
    dump:()=>clone(committed),
    transaction(names,mode){
      const working=clone(committed);
      let pending=0,aborted=false,completed=false,completionScheduled=false;
      const tx={error:null,oncomplete:null,onerror:null,onabort:null};
      const scheduleComplete=()=>{
        if(completionScheduled||completed||aborted)return;
        completionScheduled=true;
        setTimeout(()=>{
          completionScheduled=false;
          if(completed||aborted||pending)return;
          completed=true;
          if(mode==='readwrite')committed=working;
          tx.oncomplete?.();
        },0);
      };
      const request=action=>{
        pending++;
        const req={result:undefined,error:null,onsuccess:null,onerror:null};
        setTimeout(()=>{
          if(aborted){pending--;return}
          try{req.result=action();req.onsuccess?.()}
          catch(e){req.error=e;tx.error=e;req.onerror?.();aborted=true;tx.onabort?.()}
          finally{pending--;scheduleComplete()}
        },0);
        return req;
      };
      tx.objectStore=name=>{
        assert.ok(names.includes(name),'transaction must include requested store');
        return{
          getAll:()=>request(()=>clone(working[name]||[])),
          clear:()=>request(()=>{working[name]=[]}),
          put:row=>request(()=>{
            if(failOnMarker&&row?.__forceRestoreFailure)throw new Error('injected restore failure');
            working[name].push(clone(row));
            return row;
          })
        };
      };
      tx.abort=()=>{if(aborted)return;aborted=true;tx.error=new Error('aborted');tx.onabort?.()};
      scheduleComplete();
      return tx;
    }
  };
}

const context={window:{},console,setTimeout,clearTimeout};
vm.createContext(context);
vm.runInContext(source,context,{filename:'data-backup.js'});
const backupApi=context.window.UPCDataBackup;
assert.ok(backupApi,'backup service must export one explicit browser capability');

const stores=Object.fromEntries(backupApi.CORE_STORES.map((name,index)=>[name,[{store:name,id:index+1,value:'fixture-'+name}]]));
stores.library.push({id:99,generation:'active',skuKey:'123',upcKey:'456',fields:{Description:'Fixture'}});
stores.meta=[{key:'library',generation:'active',recordCount:2},{key:'localLibraryAdditions',records:[{id:'local-1',skuKey:'789'}]}];

const sourceDb=fakeDatabase(stores);
const backup=await backupApi.createBackup({database:sourceDb,appVersion:'2.67',buildId:'v2.67-test'});
assert.equal(backup.format,'UPC_LIST_BUILDER_DATA_BACKUP');
assert.equal(backup.backupFormatVersion,2);
assert.equal(backup.applicationDataSchemaVersion,2);
assert.deepEqual(Array.from(backup.manifest.stores,x=>x.name),Array.from(backupApi.CORE_STORES));
assert.equal(backup.manifest.totalRecords,Object.values(stores).reduce((n,rows)=>n+rows.length,0));
assert.equal(backup.manifest.credentialsIncluded,false);
assert.equal(backup.manifest.diagnosticsIncluded,false);
assert.deepEqual(Array.from(backup.manifest.excludedStores),['diagnostics']);
assert.equal(Object.hasOwn(backup.stores,'diagnostics'),false);

const generatedValidation=backupApi.validateBackup(backup,{maxIndexedDbVersion:8});
const preLocation=clone(backup);
preLocation.applicationDataSchemaVersion=1;
preLocation.backupFormatVersion=1;
const blockedOld=backupApi.validateBackup(preLocation,{maxIndexedDbVersion:8});
assert.equal(blockedOld.valid,false,'pre-location backup cannot silently overwrite location data');
assert.ok(blockedOld.errors.some(x=>/predates location storage/i.test(x)),
 'pre-location rejection must explain the actual danger');
assert.equal(generatedValidation.valid,true,generatedValidation.errors.join(' | '));
assert.equal(backupApi.validateBackup('{bad json',{maxIndexedDbVersion:8}).valid,false);

const newer=clone(backup);newer.indexedDb.version=9;
assert.equal(backupApi.validateBackup(newer,{maxIndexedDbVersion:8}).valid,false,'newer DB backup must be rejected');
const missing=clone(backup);delete missing.stores.skuIdentity;
assert.equal(backupApi.validateBackup(missing,{maxIndexedDbVersion:8}).valid,false,'missing durable store must be rejected');
const countMismatch=clone(backup);countMismatch.manifest.stores.find(x=>x.name==='lists').count++;
assert.equal(backupApi.validateBackup(countMismatch,{maxIndexedDbVersion:8}).valid,false,'manifest count mismatch must be rejected');
const credentials=clone(backup);credentials.manifest.credentialsIncluded=true;
assert.equal(backupApi.validateBackup(credentials,{maxIndexedDbVersion:8}).valid,false,'credential-bearing backup must be rejected');

const old=Object.fromEntries(backupApi.CORE_STORES.map(name=>[name,[{old:true,store:name}]]));
const restoreDb=fakeDatabase(old);
const restored=await backupApi.restoreBackup(backup,{database:restoreDb});
assert.equal(restored.restored,true);
assert.deepEqual(restoreDb.dump(),stores,'successful restore must replace every required durable store');

const failing=clone(backup);
failing.stores.skuIdentity.push({skuKey:'failure',__forceRestoreFailure:true});
failing.manifest.stores.find(x=>x.name==='skuIdentity').count++;
failing.manifest.totalRecords++;
assert.equal(backupApi.validateBackup(failing,{maxIndexedDbVersion:8}).valid,true);
const failureDb=fakeDatabase(old,{failOnMarker:true});
await assert.rejects(()=>backupApi.restoreBackup(failing,{database:failureDb}),/injected restore failure|transaction/i);
assert.deepEqual(failureDb.dump(),old,'failed atomic restore must preserve all prior data');

const index=fs.readFileSync('app/src/main/assets/www/index.html','utf8');
const app=readWebRuntimeSource();
const controller=fs.readFileSync('app/src/main/assets/www/application/data-backup-controller.js','utf8');
const contract=fs.readFileSync('APPLICATION_DATA_BACKUP_CONTRACT.md','utf8');
assert.match(index,/data-backup\.js/);
assert.match(index,/id="exportDataBackup"/);
assert.match(index,/id="restoreDataBackup"/);
assert.match(index,/id="restoreDataBackupFile"/);
assert.match(controller,/dataBackup\.createBackup/);
assert.match(controller,/dataBackup\.validateBackup/);
assert.match(controller,/dataBackup\.restoreBackup/);
assert.match(controller,/fileDelivery\.deliverText/);
assert.doesNotMatch(controller,/\.exportFile\b|createObjectURL\(/,'backup workflow must delegate standard file delivery');
assert.match(controller,/confirmUser\([\s\S]*current saved application data will be replaced/i);
assert.match(contract,/STATUS: CURRENT/);
assert.match(contract,/## Format/,'backup contract must define the current backup format without historical release pinning');
assert.match(contract,/one multi-store IndexedDB read\/write transaction/);
assert.match(contract,/passwords, cookies, authentication tokens/);

console.log('Current application data backup/restore safeguard PASS');
