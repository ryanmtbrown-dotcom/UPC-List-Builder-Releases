import fs from 'node:fs';
const must=(value,message)=>{if(!value)throw new Error(message)};
const deployment=fs.readFileSync('DEPLOYMENT_CONTRACT.md','utf8');
const termux=fs.readFileSync('TERMUX_DEPLOYMENT_CONTRACT.md','utf8');
const ai=fs.readFileSync('AI_START_HERE.md','utf8');
const release=fs.readFileSync('RELEASE_VERSIONING_CONTRACT.md','utf8');
const workflow=fs.readFileSync('.github/workflows/build-apk.yml','utf8');

must(deployment.includes('STATUS: CURRENT DEPLOYMENT AUTHORITY'),'overall deployment authority status missing');
must(deployment.includes('GitHub-native deployment is the normal release path'),'GitHub-native default is not authoritative');
must(deployment.includes('head_sha')&&deployment.includes('main'),'exact main-SHA deployment proof missing');
must(deployment.includes('Publish public updater feed'),'stable updater publication gate missing');
must(deployment.includes('TERMUX_DEPLOYMENT_CONTRACT.md')&&deployment.includes('fallback/recovery'),'Termux fallback routing missing');
must(termux.includes('CURRENT FALLBACK PROCEDURE'),'Termux contract must identify itself as fallback');
must(ai.includes('DEPLOYMENT_CONTRACT.md')&&ai.includes('GitHub-native deployment is the normal release path'),'AI first-stop authority must route normal deployment through GitHub');
must(release.includes('DEPLOYMENT_CONTRACT.md'),'release versioning must route through overall deployment authority');
must(workflow.includes('push:')&&workflow.includes('branches: [main]'),'main push workflow trigger missing');
must(workflow.includes("if: github.event_name == 'push' && github.ref == 'refs/heads/main'"),'stable updater feed must remain main-push only');
must(workflow.includes('Publish public updater feed'),'public updater step missing');
for(const guard of [
 "PREVIOUS_VERSION=", "PREVIOUS_SHA=", "PREVIOUS_SIZE=",
 "sha256sum UPC-List-Builder-latest.apk", "stat -c%s UPC-List-Builder-latest.apk",
 "ROLLBACK_APK=", "ROLLBACK_FEED=", 'cmp -s update.json',
 'git add "$ROLLBACK_APK" "$ROLLBACK_FEED"'
])must(workflow.includes(guard),`Rollback publication safeguard missing: ${guard}`);
must(workflow.indexOf('PREVIOUS_SHA=')<workflow.lastIndexOf('cp "$GITHUB_WORKSPACE/release-out/UPC-List-Builder-latest.apk" .'),
 'Existing stable APK must be validated and retained before it is overwritten');
console.log('GitHub-native default deployment contract v2.81 PASS');
