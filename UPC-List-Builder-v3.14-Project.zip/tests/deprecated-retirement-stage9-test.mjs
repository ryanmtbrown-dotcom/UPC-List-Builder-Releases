import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';

const read=p=>fs.readFileSync(p,'utf8');
const migrationSource=read('app/src/main/assets/www/migration-repository.js');
const app=read('app/src/main/assets/www/app.v059.js');
const db=read('app/src/main/assets/www/db.js');
const masterRepo=read('app/src/main/assets/www/master-repository.js');
const localRepo=read('app/src/main/assets/www/local-repository.js');
const effective=read('app/src/main/assets/www/effective-catalog-resolver.js');
const combined=read('app/src/main/assets/www/combined-master-export.js');
const workflow=read('app/src/main/assets/www/library-workflow-v093.js');
const html=read('app/src/main/assets/www/index.html');

const meta=new Map([
 ['library',{key:'library',generation:'g-old',skuHeader:'ACE SKU',upcHeader:'UPC/EAN',headers:['ACE SKU','UPC/EAN'],recordCount:2,localAdditionCount:1,lastLocalLibraryPushAt:'2026-09-30T00:00:00Z'}],
 ['localLibraryAdditions',{key:'localLibraryAdditions',records:[{id:'l200',skuKey:'200',upcKey:'200000000000',originalUPC:'200000000000',fields:{'ACE SKU':'200','UPC/EAN':'200000000000'},source:'LOCAL_ADDITION',masterPromotion:{status:'PROMOTED',promotedAt:'2026-09-30T00:00:00Z'}}]}],
 ['pendingLibraryAdditions',{key:'pendingLibraryAdditions',records:[{id:'p100',values:{sku:'100'}},{id:'p-no-sku',values:{sku:''}}]}]
]);
const lists=[{id:'list1',items:[
 {id:'i101',primaryPurpose:'Add to Library',sku:'101',libraryWorkflowStatus:'PENDING'},
 {id:'i-no-sku',tags:['Add to Library'],sku:'',libraryWorkflowStatus:'PENDING'},
 {id:'i-other',primaryPurpose:'Price Change',sku:'102'}
]}];
const active=[
 {id:'m1',generation:'g-old',skuKey:'001',upcKey:'001000000000',fields:{'ACE SKU':'001','UPC/EAN':'001000000000'},source:'MASTER'},
 {id:'pm200',generation:'g-old',skuKey:'200',upcKey:'200000000000',fields:{'ACE SKU':'200','UPC/EAN':'200000000000'},source:'LOCAL_ADDITION'}
];
const queued=[],deleted=[];
const UPCDB={
 async get(store,key){if(store!=='meta')return null;return meta.get(key)||null},
 async all(store){return store==='lists'?lists:[]},
 async put(store,value){assert.equal(store,'meta');meta.set(value.key,JSON.parse(JSON.stringify(value)));return value},
 async remove(store,key){assert.equal(store,'meta');meta.delete(key)},
 async getActiveLibraryRecords(){return active.map(x=>({...x,fields:{...x.fields}}))},
 async enqueueLibrarySku(row){queued.push(JSON.parse(JSON.stringify(row)));return{queued:true,row}},
 async deleteActiveLibraryRows(recordIds,generation){deleted.push({recordIds:[...recordIds],generation});return{deleted:recordIds.length,recordIds:[...recordIds]}}
};
const context={window:{},UPCDB,UPCWorkSessionService:{list:async()=>lists},UPCIdentifierNormalization:{normalizeSKU:v=>String(v??'').trim()}};
vm.createContext(context);vm.runInContext(migrationSource,context,{filename:'migration-repository.js'});
const migration=context.window.UPCMigrationRepository;
const result=await migration.retireStage9LegacyState();

assert.equal(result.appliedNow,true);
assert.equal(result.queuedSkus,2);
assert.equal(result.pendingRecordsSeen,2);
assert.equal(result.pendingRecordsDiscarded,1);
assert.equal(result.listCandidates,1);
assert.equal(result.listItemsDiscardedWithoutSku,1);
assert.equal(result.promotedRowsRetired,1);
assert.equal(result.localPromotionMetadataRemoved,1);
assert.equal(result.activeGeneration,'g-old');
assert.deepEqual(queued.map(x=>x.sku).sort(),['100','101']);
assert.deepEqual(deleted,[{recordIds:['pm200'],generation:'g-old'}],'Stage 9 must delete only promoted compatibility rows from the active generation');
assert.equal(meta.has('pendingLibraryAdditions'),false,'retired pending shadow metadata must be deleted');
assert.equal(Object.hasOwn(meta.get('localLibraryAdditions').records[0],'masterPromotion'),false,'Local records survive without promotion metadata');
assert.equal(meta.get('library').generation,'g-old');
assert.equal(meta.get('library').recordCount,1);
assert.equal(meta.get('migration.stage9.deprecatedRetirement').applied,true);

const second=await migration.retireStage9LegacyState();
assert.equal(second.appliedNow,false,'Stage 9 migration must be idempotent');
assert.equal(queued.length,2,'idempotent rerun must not enqueue duplicates');
assert.equal(deleted.length,1,'idempotent rerun must not delete Master rows again');

assert.doesNotMatch(localRepo,/pendingLibraryAdditions|getPendingAdditions|savePendingAdditions/);
assert.doesNotMatch(masterRepo,/reconcilePromoted|restoreMissingPromoted|updatePrice|updateAceNetFields/);
assert.doesNotMatch(db,/async function (?:repairV149AceNetWeight|repairV153NullCostOverwrite|repairV155MasterPriceContamination|repairLegacySkuMapping|reconcilePromotedLocalLibraryRecord|restoreMissingPromotedLocalLibraryRecords|reconcileAllPromotedLocalLibraryRecords|updateActiveLibraryPrice|updateActiveLibraryAceNetFields)\(/);
assert.doesNotMatch(app,/repairAceNetWeight|repairNullCostOverwrite|repairMasterPriceContamination|repairLegacySkuMapping|promoted_local_master_startup_reconciliation|LOCAL_TO_MASTER_PROMOTION_DISABLED/);
assert.doesNotMatch(effective,/PROMOTED_MASTER|promotedMaster|isPromotedMasterRow|MASTER_PROMOTED_LOCAL|LOCAL_LIBRARY_PROMOTED/);
assert.doesNotMatch(combined,/PROMOTED_MASTER|promotedMasterRowsIgnored|Legacy promoted/);
assert.doesNotMatch(workflow,/pushLocalLibraryToMaster|importCompleted\(|pendingLibraryAdditions|masterPromotion|lastLocalLibraryPushAt/);
assert.doesNotMatch(html,/pushLocalLibraryToMaster|manualLibraryOverlay|manualLibraryProgress/);
assert.match(migrationSource,/migration\.stage9\.deprecatedRetirement/);
assert.match(migrationSource,/LEGACY_ADD_TO_LIBRARY_RETIREMENT/);

console.log('Stage 9 deprecated workflow + historical runtime repair retirement PASS');
