import {readNativeRuntimeSource} from './helpers/runtime-source-tree.mjs';
import fs from 'node:fs';
const k=readNativeRuntimeSource();
const must=[
  'sourceCallback","WebViewClient.onReceivedError',
  'sourceFunction","startAceNetTest.onReceivedError',
  'evidenceKind","WEBVIEW_RESOURCE_ERROR',
  'observedVsInferred","OBSERVED',
  'rawHttpStatus",JSONObject.NULL',
  'webViewErrorCode",error?.errorCode',
  'rawDescription",error?.description',
  'sourceCallback","WebViewClient.onReceivedHttpError',
  'sourceFunction","startAceNetTest.onReceivedHttpError',
  'evidenceKind","HTTP_ERROR_RESPONSE',
  'rawHttpStatus",response?.statusCode',
  'rawReasonPhrase",response?.reasonPhrase',
  'decisionSourceFunction","notifyAceNetHealthState',
  'causalEvidence'
];
for(const s of must) if(!k.includes(s)) throw new Error(`Missing diagnostic provenance requirement: ${s}`);
console.log('Diagnostic raw-cause provenance requirements PASS');
