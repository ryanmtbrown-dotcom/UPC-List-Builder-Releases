import fs from 'node:fs';
import assert from 'node:assert/strict';

const html=fs.readFileSync('app/src/main/assets/www/index.html','utf8');
const ui=fs.readFileSync('app/src/main/assets/www/diagnostics/diagnostic-ui-controller.js','utf8');
const settings=fs.readFileSync('app/src/main/assets/www/application/settings-controller.js','utf8');
const contract=fs.readFileSync('DIAGNOSTICS_CONTRACT.md','utf8');
const ownership=fs.readFileSync('SOURCE_OWNERSHIP_MAP.md','utf8');

const start=html.indexOf('<section id="settingsScreen"');
const end=html.indexOf('</section>',start);
assert.ok(start>=0&&end>start,'Settings screen markup missing');
const settingsMarkup=html.slice(start,end);
assert.match(settingsMarkup,/id="settingsDeepDiag"/,'Settings must expose Deep Diagnostic Mode directly');
assert.match(settingsMarkup,/id="settingsDeepDiagStatus"/,'Settings Deep Diagnostic state text missing');
assert.match(settingsMarkup,/aria-pressed="false"/,'Settings Deep Diagnostic control must expose toggle state accessibly');
assert.match(ui,/function toggleDeepModeFromUi\(/,'one Diagnostic UI toggle owner must serve all surfaces');
assert.match(ui,/settingsDeepDiag/,'Diagnostic UI owner must bind the Settings control');
assert.match(ui,/toggleDeepDiag/,'Diagnostic UI owner must retain the diagnostics-overlay control');
assert.match(ui,/settingsDeepDiagStatus/,'Diagnostic UI owner must synchronize Settings state text');
assert.doesNotMatch(settings,/settingsDeepDiag|toggleDeepMode/,'Settings Controller must not duplicate Deep Diagnostic behavior ownership');
assert.match(contract,/Settings page and the Diagnostics overlay/,'diagnostics contract must define both UI surfaces');
assert.match(ownership,/Diagnostic UI \/ Deep Diagnostic controls/,'source ownership map must name the Deep Diagnostic UI owner');
console.log('Settings Deep Diagnostic Mode surface ownership v2.83 PASS');
