import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';

const root='app/src/main/assets/www/';
const src=fs.readFileSync(root+'diagnostics/diagnostic-export-service.js','utf8');
const native=fs.readFileSync('app/src/main/java/com/rmtb/upclistbuilder/NativeFileExportService.kt','utf8');
const writer=fs.readFileSync('app/src/main/java/com/rmtb/upclistbuilder/NativeDownloadsWriter.kt','utf8');
const main=fs.readFileSync('app/src/main/java/com/rmtb/upclistbuilder/MainActivity.kt','utf8');
const bridge=fs.readFileSync(root+'platform/bridge-registration.js','utf8');
for (const method of ['beginDiagnosticExport','appendDiagnosticExportChunk','finishDiagnosticExport','abortDiagnosticExport']) {
 assert.ok(native.includes('fun '+method+'('),`native missing ${method}`);
 assert.ok(main.includes('@JavascriptInterface fun '+method+'('),`native bridge missing ${method}`);
}
assert.match(native,/Executors\.newSingleThreadExecutor\(\)/);
assert.match(native,/maxDiagnosticBytes = 256L \* 1024L \* 1024L/);
assert.match(native,/diagnosticWorker\.shutdown\(\)/);
assert.match(writer,/MediaStore\.Downloads\.IS_PENDING, 1/);
assert.match(writer,/MediaStore\.Downloads\.IS_PENDING, 0/);
assert.match(writer,/if \(!published\)/);
assert.match(writer,/java\.util\.zip\.ZipOutputStream/);
assert.match(writer,/java\.util\.zip\.ZipEntry/);
assert.match(writer,/application\/zip/);
assert.match(writer,/zipStream\?\.closeEntry\(\)/);
assert.match(native,/safe\.endsWith\(\"\.zip\"\)/);
assert.match(bridge,/UPCNativeDiagnosticExportTransferEvent/);
assert.doesNotMatch(main,/@JavascriptInterface fun exportDiagnostics\(json/,'giant single-string diagnostic bridge must be retired');
assert.doesNotMatch(src,/JSON\.stringify\(payloadObject,null,2\)/);

const c={setTimeout,clearTimeout,console};c.window=c;vm.createContext(c);vm.runInContext(src,c);
const events=Array.from({length:3000},(_,i)=>({schemaVersion:2,sequence:i+1,timestamp:new Date(1791694500000+i*10).toISOString(),event:'synthetic',domain:'TEST',operationId:'operation-'+(i%70),phase:'EVENT',details:{longText:'x'.repeat(440)+(i===10?'\u{1F600}':'')}}));
let service,chunkMessages=[],eventsReported=[],finishCalls=[],nativeSave=false,beginCalls=0,abortCalls=0;
let callbacks=0;
const webElements={diagSummary:{textContent:''}};
const deepObservations=[];
const diagFn=(name,data)=>{eventsReported.push([name,data])};diagFn.event=(name,data,context)=>deepObservations.push({name,data,context});
const bridgeMock={
 beginDiagnosticExport(id,name){assert.match(name,/\.zip$/,'Android diagnostics must use compressed ZIP');beginCalls++;setTimeout(()=>service.acceptNativeExportTransferEvent(JSON.stringify({id,phase:'ready'})),0)},
 appendDiagnosticExportChunk(id,chunk){assert.ok(chunk.length<=24000);chunkMessages.push(chunk);setTimeout(()=>service.acceptNativeExportTransferEvent(JSON.stringify({id,phase:'chunk'})),0)},
 finishDiagnosticExport(id){nativeSave=true;setTimeout(()=>service.acceptNativeExportTransferEvent(JSON.stringify({id,phase:'saved'})),0)},
 abortDiagnosticExport(){abortCalls++},
 getNativeDiagnosticJournal(){return JSON.stringify([{schemaVersion:2,sequence:1,timestamp:'2026-10-11T04:30:00.000Z',domain:'ANDROID',event:'native-check'}])},
 getNetworkConnectivityState(){return '{}'},platform(){return 'android-native'}
};
service=c.UPCDiagnosticExportService.create({
 elementById:id=>webElements[id]||null,diagRows:()=>events,markCurrentStartupSession:()=>({rows:events,currentStartupSessionId:'test',currentCount:1,invariant:'PASS'}),
 diagnostic:diagFn,diagnosticStatus:()=>({deepDiagnosticMode:true,maxEvents:30000}),
 startOperation(){},finishOperation:(id,msg,status)=>{finishCalls.push({id,msg,status})},appVersion:'3.04',appBuild:'test',startupSessionId:'test',
 startupSnapshot:()=>({ok:true}),navigationSnapshot:()=>({}),scannerSnapshot:()=>({}),
 nativeBridgeProvider:()=>bridgeMock,windowRef:{visualViewport:{},screen:{width:100,height:200},innerWidth:100,innerHeight:200,devicePixelRatio:2},
 documentRef:{visibilityState:'visible'},navigatorRef:{serviceWorker:null,onLine:true,platform:'Android',userAgent:'test',language:'en-US',mediaDevices:null},
 locationRef:{href:'https://appassets.androidplatform.net'},matchMediaFn:()=>({matches:false}),secureContext:()=>true,urlRef:{},blobCtor:Blob
});

const large={rows:events,description:'Z'.repeat(105000),emoji:'\u{1F600}'.repeat(24000),nullProp:null,undefinedProp:undefined};
const reconstruct=[...function*(){const chunks=service.createDiagnosticChunkIterator(large);for(let step=chunks.next();!step.done;step=chunks.next())yield step.value;}()].join('');
assert.deepEqual(JSON.parse(reconstruct),JSON.parse(JSON.stringify(large)),'incremental encoding must preserve complete valid Unicode JSON');
assert.ok(reconstruct.includes('\u{1F600}'));
assert.equal(await service.downloadDiagnostics(),true);
assert.equal(await service.downloadDiagnostics(),false,'concurrent export must be rejected without starting a second');
await new Promise((resolve,reject)=>{const end=Date.now()+20000;const check=()=>{if(nativeSave&&finishCalls.length)return resolve();if(Date.now()>end)return reject(Error('Transfer did not finish'));setTimeout(check,15)};check()});
const result=JSON.parse(chunkMessages.join(''));
assert.equal(result.diagnosticSchemaVersion,2);
assert.equal(result.eventCount,3000);
assert.equal(result.events.length,3000);
assert.equal(result.timeline.length,3001);
assert.equal(result.nativeDiagnosticJournal.length,1);
assert.ok(chunkMessages.length>30);
assert.equal(beginCalls,1);
assert.equal(abortCalls,0);
assert.equal(finishCalls.at(-1).status,'PASS');
assert.ok(deepObservations.some(x=>x.name==='deep_diagnostic_export_chunk_checkpoint'&&x.context.severity==='TRACE'));
assert.ok(deepObservations.some(x=>x.name==='deep_diagnostic_native_transfer_phase'&&x.data.phase==='saved'));
assert.ok(deepObservations.some(x=>x.name==='deep_diagnostic_export_terminal'&&x.data.result==='PASS'));
assert.ok(eventsReported.some(x=>x[0]==='diagnostic_export_terminal'&&x[1].result==='PASS'));

// Native rejects on the initial ACK: no false success, no saved callback.
let failedTransfer;
bridgeMock.beginDiagnosticExport=(id)=>setTimeout(()=>service.acceptNativeExportTransferEvent(JSON.stringify({id,phase:'error',message:'Downloads inaccessible'})),0);
assert.equal(await service.downloadDiagnostics(),true);
await new Promise((resolve,reject)=>{const end=Date.now()+4000;const check=()=>{if(finishCalls.length===2)return resolve();if(Date.now()>end)return reject(Error('Failure was not acknowledged'));setTimeout(check,10)};check()});
assert.equal(finishCalls.at(-1).status,'FAIL');
assert.equal(abortCalls,1);
console.log('Diagnostic streaming bounded-JSON, round trip, single-flight, late success, and native failure regression PASS');
