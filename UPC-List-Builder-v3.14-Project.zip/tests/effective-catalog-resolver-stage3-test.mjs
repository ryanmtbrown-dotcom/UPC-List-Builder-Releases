import {readWebRuntimeSource,findJsFunction} from './helpers/runtime-source-tree.mjs';
import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';

const source=fs.readFileSync('app/src/main/assets/www/effective-catalog-resolver.js','utf8');
const app=readWebRuntimeSource();
const misc=fs.readFileSync('app/src/main/assets/www/ace-misc.js','utf8');
const miscResolution=fs.readFileSync('app/src/main/assets/www/misc/misc-resolution-service.js','utf8');
const localIdentifier=fs.readFileSync('app/src/main/assets/www/local-identifier-resolver.js','utf8');
const html=fs.readFileSync('app/src/main/assets/www/index.html','utf8');
const extract=(src,start,end)=>{const s=src.indexOf(start),e=src.indexOf(end,s);assert.ok(s>=0&&e>s,`Missing source block ${start}`);return src.slice(s,e)};
assert.doesNotMatch(source,/AceNet|AndroidNative|fetch\s*\(|XMLHttpRequest|UPCIdentityRepository|UPCDB\.|\.put\s*\(|\.saveMetadata|document\.|alert\s*\(/,'Effective Catalog must remain read-only, local, repository-backed, and UI/identity independent.');
assert.match(source,/UPCMasterRepository/);
assert.match(source,/UPCLocalRepository/);
assert.match(source,/LOCAL_LOOKUP_TIMEOUT_MS=1500/,'Effective Catalog must have a small resolver-level IndexedDB failsafe.');
assert.match(source,/boundedLocalRead/,'Local lookup failsafe must wrap reads without delaying ordinary misses.');

function build({masterSku={},localSku={},masterExact={},masterPrefix={},localExact={},localPrefix={}}={}){
 const calls=[];
 const get=(table,key,def)=>Object.prototype.hasOwnProperty.call(table,key)?table[key]:def;
 const context={
  window:{},
  Set,
  String,
  setTimeout,
  clearTimeout,
  UPCMasterRepository:{
   lookupSKU:async key=>{calls.push(['masterSku',key]);return get(masterSku,key,{row:null,count:0,mode:'SKU_EXACT'})},
   lookupExactUPC:async key=>{calls.push(['masterExact',key]);return get(masterExact,key,{row:null,count:0,mode:'EXACT'})},
   lookupPrefixUPC:async key=>{calls.push(['masterPrefix',key]);return get(masterPrefix,key,{row:null,count:0,mode:'PREFIX_11'})}
  },
  UPCLocalRepository:{
   lookupSKU:async key=>{calls.push(['localSku',key]);return get(localSku,key,{row:null,count:0,mode:'LOCAL_SKU_EXACT'})},
   lookupExactUPC:async key=>{calls.push(['localExact',key]);return get(localExact,key,{row:null,count:0,mode:'LOCAL_EXACT'})},
   lookupPrefixUPC:async key=>{calls.push(['localPrefix',key]);return get(localPrefix,key,{row:null,count:0,mode:'LOCAL_PREFIX_11'})}
  }
 };
 vm.createContext(context);vm.runInContext(source,context,{filename:'effective-catalog-resolver.js'});
 return{resolver:context.window.UPCEffectiveCatalogResolver,calls};
}

{
 const master={id:'m1',skuKey:'100',source:'MASTER',fields:{}};
 const {resolver,calls}=build({masterSku:{'100':{row:master,count:1,mode:'SKU_EXACT'}},localSku:{'100':{row:{id:'l1'},count:1,mode:'LOCAL_SKU_EXACT'}}});
 const r=await resolver.resolveSKU('100');
 assert.equal(r.status,'FOUND');assert.equal(r.row.id,'m1');assert.equal(r.provenance,'MASTER_LIBRARY');assert.equal(r.masterRecordId,'m1');assert.equal(r.localRecordId,null);
 assert.deepEqual(calls,[['masterSku','100']],'ordinary official-Master SKU resolution must not require a Local read');
}
{
 const local={id:'l1',skuKey:'200',source:'LOCAL_ADDITION',fields:{}};
 const {resolver}=build({localSku:{'200':{row:local,count:1,mode:'LOCAL_SKU_EXACT'}}});
 const r=await resolver.resolveSKU('200');
 assert.equal(r.status,'FOUND');assert.equal(r.row.id,'l1');assert.equal(r.provenance,'LOCAL_LIBRARY');assert.equal(r.localRecordId,'l1');
}
{
 const master={id:'m2',skuKey:'300',source:'MASTER',fields:{}},local={id:'l2',skuKey:'300',source:'LOCAL_ADDITION',fields:{}};
 const {resolver,calls}=build({masterSku:{'300':{row:master,count:1,mode:'SKU_EXACT'}},localSku:{'300':{row:local,count:1,mode:'LOCAL_SKU_EXACT'}}});
 const r=await resolver.resolveSKU('300');
 assert.equal(r.status,'FOUND');assert.equal(r.row.id,'m2');assert.equal(r.provenance,'MASTER_LIBRARY');assert.equal(r.activeMasterRecordId,'m2');assert.equal(r.localRecordId,null);
 assert.deepEqual(calls,[['masterSku','300']],'Stage 9 active Master rows are official and win without Local compatibility reads');
}
{
 const {resolver}=build({masterSku:{'400':{row:null,count:2,mode:'SKU_EXACT'}}});
 const r=await resolver.resolveSKU('400');assert.equal(r.status,'AMBIGUOUS');assert.equal(r.matches,2);assert.equal(r.provenance,'MASTER_LIBRARY_AMBIGUOUS');
}
{
 const {resolver}=build({localSku:{'500':{row:null,count:2,mode:'LOCAL_SKU_EXACT'}}});
 const r=await resolver.resolveSKU('500');assert.equal(r.status,'AMBIGUOUS');assert.equal(r.matches,2);assert.equal(r.provenance,'LOCAL_LIBRARY_AMBIGUOUS');
}
{
 const master={id:'mu',skuKey:'600',source:'MASTER',fields:{}};
 const {resolver}=build({masterExact:{'012345678905':{row:master,count:1,mode:'EXACT'}}});
 const r=await resolver.resolveDirectUPC('012345678905',{format:'ean_13'});assert.equal(r.status,'FOUND');assert.equal(r.provenance,'MASTER_LIBRARY');assert.equal(r.row.id,'mu');
}
{
 const local={id:'lu',skuKey:'700',source:'LOCAL_ADDITION',fields:{}};
 const {resolver}=build({localExact:{'777777777777':{row:local,count:1,mode:'LOCAL_EXACT'}}});
 const r=await resolver.resolveDirectUPC('777777777777');assert.equal(r.status,'FOUND');assert.equal(r.provenance,'LOCAL_LIBRARY');assert.equal(r.row.id,'lu');
}
{
 const master={id:'me',skuKey:'800',source:'MASTER',fields:{}};
 const {resolver}=build({masterExact:{
  '0012345678905':{row:null,count:0,mode:'EXACT'},
  '012345678905':{row:master,count:1,mode:'EXACT'}
 }});
 const r=await resolver.resolveDirectUPC('0012345678905',{format:'ean_13'});
 assert.equal(r.status,'FOUND');assert.equal(r.lookupMode,'EAN13_TO_UPCA');assert.deepEqual(JSON.parse(JSON.stringify(r.observations[0])),{type:'EAN13_TO_UPCA',input:'0012345678905',converted:'012345678905',count:1,authority:'MASTER_LIBRARY'});
}
{
 const master={id:'pm',skuKey:'900',source:'MASTER',fields:{}},local={id:'pl',skuKey:'900',source:'LOCAL_ADDITION',fields:{}};
 const {resolver,calls}=build({masterExact:{'999999999999':{row:master,count:1,mode:'EXACT'}},localSku:{'900':{row:local,count:1,mode:'LOCAL_SKU_EXACT'}}});
 const r=await resolver.resolveDirectUPC('999999999999');assert.equal(r.status,'FOUND');assert.equal(r.provenance,'MASTER_LIBRARY');assert.equal(r.activeMasterRecordId,'pm');assert.equal(r.row.id,'pm');
 assert.deepEqual(calls,[['masterExact','999999999999']],'Stage 9 direct UPC resolution must not redirect an active Master hit through Local');
}
{
 const master={id:'im',skuKey:'42',source:'MASTER',fields:{}},local={id:'il',skuKey:'42',source:'LOCAL_ADDITION',fields:{}};
 const {resolver}=build({masterSku:{'42':{row:master,count:1,mode:'SKU_EXACT'}},localSku:{'42':{row:local,count:1,mode:'LOCAL_SKU_EXACT'}}});
 const r=await resolver.inspectSKU('42');assert.equal(r.master.row.id,'im');assert.equal(r.local.row.id,'il');assert.equal('promotedMaster' in r,false);
}
const repoLoad=html.indexOf('local-repository.js'),resolverLoad=html.indexOf('effective-catalog-resolver.js'),miscLoad=html.indexOf('ace-misc.js'),appLoad=html.indexOf('app.v059.js');
assert.ok(repoLoad>=0&&resolverLoad>repoLoad&&resolverLoad<miscLoad&&resolverLoad<appLoad,'Effective Catalog must load after repositories and before workflow consumers.');
const normalUpc=findJsFunction('lookupItem');
const normalSku=findJsFunction('lookupItemBySku');
const retailUnits=findJsFunction('resolveAceNetRetailUnits');
const aceMiscResolver=findJsFunction('resolveAceMiscSkuCandidate');
assert.match(normalUpc,/UPCLocalIdentifierResolver\.resolveUPC/);assert.doesNotMatch(normalUpc,/UPCMasterRepository\.|UPCLocalRepository\.|UPCIdentityRepository\./);
assert.match(normalSku,/UPCLocalIdentifierResolver\.resolveSKU/);assert.doesNotMatch(normalSku,/UPCMasterRepository\.|UPCLocalRepository\.|UPCIdentityRepository\./);
assert.match(localIdentifier,/UPCEffectiveCatalogResolver\.resolveDirectUPC/,'Local Identifier Resolver must preserve Effective Catalog ownership of direct UPC catalog selection.');assert.match(localIdentifier,/UPCEffectiveCatalogResolver\.resolveSKU/,'Local Identifier Resolver must preserve Effective Catalog ownership of SKU catalog selection.');
assert.match(retailUnits,/effectiveResolver\.inspectSKU/);assert.doesNotMatch(retailUnits,/UPCMasterRepository\.|UPCLocalRepository\./);
assert.match(aceMiscResolver,/UPCEffectiveCatalogResolver\.inspectSKU/);assert.doesNotMatch(aceMiscResolver,/UPCMasterRepository\.lookupSKU\(key\)/,'ACE MISC ordinary catalog resolution must stay behind Effective Catalog.');const localReadBack=aceMiscResolver.indexOf('UPCLocalRepository.lookupSKU(key)'),persistCall=aceMiscResolver.indexOf('persistVerifiedAceNetCatalogToLocalLibrary');assert.ok(localReadBack<0||localReadBack>persistCall,'Any direct Local read in ACE MISC must be post-persistence physical read-back, not ordinary resolution.');assert.match(aceMiscResolver,/aceMiscRefreshLibraryRecord\(key,master\.row/,'Known Master MISC items must proceed through live full-catalog refresh.');
assert.match(miscResolution,/UPCEffectiveCatalogResolver\.inspectSKU\(key\)/,'MISC resolution must consume Effective Catalog before live AceNet refresh.');assert.doesNotMatch(misc,/UPCEffectiveCatalogResolver|UPCMasterRepository\.lookupSKU|UPCLocalRepository\.lookupSKU/,'MISC export/domain mapping must not reconstruct catalog authority at export time.');

assert.doesNotMatch(source,/PROMOTED_MASTER|promotedMaster|LOCAL_LIBRARY_PROMOTED|MASTER_PROMOTED_LOCAL/);
console.log('Stage 9 Effective Catalog official-Master + Local separation semantics PASS');
