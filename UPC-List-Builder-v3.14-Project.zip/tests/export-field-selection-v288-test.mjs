import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';

const read=path=>fs.readFileSync(path,'utf8');
const schemaSource=read('app/src/main/assets/www/catalog/standard-export-schema.js');
const miscSource=read('app/src/main/assets/www/ace-misc.js');
const exportSource=read('app/src/main/assets/www/field-session/field-session-export-service.js');
const settingsSource=read('app/src/main/assets/www/application/settings-controller.js');
const settingsRepoSource=read('app/src/main/assets/www/application/settings-repository.js');
const workSessionsSource=read('app/src/main/assets/www/work-sessions/work-session-controller.js');
const shellSource=read('app/src/main/assets/www/application/application-shell.js');
const html=read('app/src/main/assets/www/index.html');

const schemaContext={window:{}};
vm.createContext(schemaContext);
vm.runInContext(schemaSource,schemaContext,{filename:'standard-export-schema.js'});
const schema=schemaContext.window.UPCStandardExportSchema;

assert.equal(schema.MASTER_HEADERS.length,30,'ordinary export checkbox schema must match the 30 supported Master Library columns');
assert.equal(schema.ACE_MISC_HEADERS.length,33,'ACE MISC format must retain the exact 33-column header layout');
assert.equal(new Set(schema.ACE_MISC_HEADERS).size,33,'the verified ACE MISC example contains 33 unique header names');
assert.deepEqual(Array.from(schema.ACE_MISC_HEADERS.slice(0,30)),Array.from(schema.MASTER_HEADERS),'ACE MISC must begin with the 30 Master Library columns in the same order');
assert.deepEqual(Array.from(schema.ACE_MISC_HEADERS.slice(30)),['POSDEPT','VENDOR','S/O (72) Y']);
for(const miscOnly of ['POSDEPT','VENDOR','S/O (72) Y'])assert.equal(schema.MASTER_HEADERS.includes(miscOnly),false,`${miscOnly} must not appear as an ordinary Master-field checkbox`);
assert.deepEqual(Array.from(schema.defaultMasterSelection()),Array.from(schema.MASTER_HEADERS),'all 30 Master fields must default selected');
assert.deepEqual(Array.from(schema.normalizeMasterSelection(['UPC/EAN','ACE SKU','POSDEPT','ACE SKU'])),['ACE SKU','UPC/EAN'],'selection normalization must preserve Master order, deduplicate, and reject MISC-only fields');

assert.match(settingsRepoSource,/EXPORT_PREFERENCES_KEY='listExportPreferences'/);
assert.match(settingsRepoSource,/PREVIOUS_EXPORT_HEADERS_KEY='listExportHeaders'/,'v2.87 header-only preference must be bounded migration input');
assert.match(settingsRepoSource,/forceAceMiscFormat:defaultForceAceMiscFormat===true/,'Force ACE MISC Format must default ON for first use and migration');
assert.match(settingsRepoSource,/normalizeHeaders\(previous\.headers\)/,'migration must immediately remove fields not present in the Master schema');
assert.match(settingsSource,/initializeExportPreferences\(exportSchema\.defaultMasterSelection\(\),true\)/,'Settings must initialize all 30 Master fields and Force ON');
assert.match(settingsSource,/id="forceAceMiscFormat"/);
assert.match(settingsSource,/Force ACE MISC Format/);
assert.match(settingsSource,/Price Change adds Label Price as column 34, then optional Register Price as column 35/,'settings must disclose forced Price Change exception');
assert.match(settingsSource,/persistExportPreferences\('force_ace_misc_format'\)/);
assert.match(settingsSource,/subsystemOperationStart\('SETTINGS_PERSISTENCE'/,'export preference persistence must use structured operation diagnostics');
assert.match(settingsSource,/list_export_preferences_loaded/);
assert.match(settingsSource,/list_export_preferences_changed/);
assert.match(shellSource,/getExportPreferences:settingsRepository\.getExportPreferences/);
assert.match(shellSource,/aceMiscFormatter:ACEMisc/,'Field Session Export must receive the ACE MISC formatter through composition');

const miscContext={
 window:{},
 UPCIdentifierNormalization:{
  normalizeSKU:value=>String(value??'').replace(/\D/g,''),
  normalizeUPC:value=>String(value??'').replace(/\D/g,'')
 },
 UPCCatalogMappers:{normalizeAceNetWeight:value=>String(value??'').trim()},
 UPCIdentifierRelationshipService:{
  getSkuUpcs:async()=>[],
  recordVerifiedSkuUpcs:async()=>({upcs:[]})
 },
 XLSXExporter:{
  MIME:'application/test',
  build:(headers,rows,options)=>({headers:[...headers],rows:rows.map(row=>[...row]),options})
 }
};
vm.createContext(miscContext);
vm.runInContext(schemaSource+'\n'+miscSource,miscContext,{filename:'ace-misc-format-runtime.js'});
const misc=vm.runInContext('ACEMisc',miscContext);
const forcedWorkbook=await misc.buildAvailableFormat([
 {
  sku:'1001',
  upc:'111111111111',
  allUpcs:['111111111111','222222222222'],
  fields:{'Description':'ITEM ONE','MFG #':'M1','Commodity Group':'10','Ace Retail Price':'12.99'}
 },
 {
  sku:'2002',
  upc:'333333333333',
  fields:{'Description':'ITEM TWO','MFG #':'M2','Commodity Group':'14','Ace Retail Price':'7.49'}
 }
]);
assert.equal(forcedWorkbook.headers.length,33);
assert.deepEqual(forcedWorkbook.headers,Array.from(schema.ACE_MISC_HEADERS));
assert.equal(forcedWorkbook.rows.length,4,'two UPC rows plus separator plus second item row are required');
assert.equal(forcedWorkbook.rows[0][0],'1001');
assert.equal(forcedWorkbook.rows[0][21],'111111111111');
assert.equal(forcedWorkbook.rows[1][0],'1001');
assert.equal(forcedWorkbook.rows[1][21],'222222222222');
assert.ok(forcedWorkbook.rows[2].every(value=>value===''),'ACE MISC format must preserve blank item separator rows');
assert.equal(forcedWorkbook.rows[3][0],'2002');
assert.equal(forcedWorkbook.rows[3][21],'333333333333');
assert.equal(forcedWorkbook.rows[0][30],'55','Commodity Group 10 must derive POSDEPT 55');
assert.equal(forcedWorkbook.rows[3][30],'56','Commodity Group 14 must derive POSDEPT 56');
assert.equal(forcedWorkbook.rows[0][31],'');
assert.equal(forcedWorkbook.rows[0][32],'');
assert.equal(forcedWorkbook.options.sheetName,'ACE New Items MISC.');
assert.deepEqual(Array.from(forcedWorkbook.options.headerFillColumns),Array.from(misc.YELLOW));
assert.equal(forcedWorkbook.options.stripeRows,true);
assert.match(miscSource,/const HEADERS=UPCStandardExportSchema\.ACE_MISC_HEADERS;/);
assert.match(miscSource,/function rowsFromAvailableItems/);
assert.match(miscSource,/rowsFromAvailableItems/);
const extendedWorkbook=await misc.buildAvailableFormat([
 {sku:'1001',upc:'111111111111',allUpcs:['111111111111','222222222222'],labelPrice:0,fields:{Description:'ONE'}},
 {sku:'2002',upc:'333333333333',labelPrice:null,fields:{Description:'TWO'}},
 {sku:'3003',upc:'444444444444',labelPrice:18.49,fields:{Description:'THREE'}}
],{trailingColumn:{header:'Label Price',valueForItem:item=>item.labelPrice===null||item.labelPrice===undefined?'':item.labelPrice}});
assert.equal(extendedWorkbook.headers.length,34,'forced Price Change must have 34 columns');
assert.deepEqual(extendedWorkbook.headers.slice(0,33),Array.from(schema.ACE_MISC_HEADERS),'original ACE MISC fields remain unchanged and in order');
assert.equal(extendedWorkbook.headers[33],'Label Price','Label Price must be exactly the last column');
assert.deepEqual(Array.from(extendedWorkbook.rows,row=>row[33]),[0,0,'','','',18.49],'values repeat per UPC and remain blank for separators and skipped prices');
assert.ok(extendedWorkbook.rows.every(row=>row.length===34),'all data and spacer rows must have 34 cells');
assert.equal(extendedWorkbook.options.stripeLastColumn,33,'stripe formatting must cover the added column');
assert.deepEqual(Array.from(extendedWorkbook.options.currencyColumns),[33],'added label price must use currency formatting');
assert.deepEqual(Array.from(extendedWorkbook.options.headerFillColumns),[...Array.from(misc.YELLOW),33],'original yellow header columns must not shift and appended Label Price must be yellow');
const plainAgain=await misc.buildAvailableFormat([{sku:'1001',upc:'111111111111'}]);
assert.equal(plainAgain.headers.length,33,'subsequent normal ACE MISC export must remain exactly 33 columns');
assert.equal(plainAgain.rows[0].length,33,'no trailing field may leak into unrelated MISC exports');
await assert.rejects(misc.buildAvailableFormat([{sku:'1001'}],{trailingColumn:{header:'Label Price',valueForItem:null}}),/Invalid trailing column/);
assert.match(miscSource,/function buildAvailableFormat\(items,options=\{\}\)/,'available-evidence formatter accepts optional trailing columns');

const exportContext={window:{}};
vm.createContext(exportContext);
vm.runInContext(read('app/src/main/assets/www/pricing/price-authority.js'),exportContext,{filename:'price-authority.js'});
vm.runInContext(exportSource,exportContext,{filename:'field-session-export-service.js'});
const lifecycle=[],miscCalls=[],normalBuilds=[];
const service=exportContext.window.UPCFieldSessionExportService.create({
 getCurrentSession:()=>({items:[]}),
 exportTags:['NIF','Price Change','General Review','Add to Library','Duplicate Item'],
 dateStamp:()=> '2026-10-04',
 promptUser:async()=>null,
 alertUser:()=>{},
 diagnostic:()=>{},
 startOperation:(...args)=>lifecycle.push(['start',...args]),
 finishOperation:(...args)=>lifecycle.push(['finish',...args]),
 storage:{getItem:()=>'',setItem:()=>{}},
 zipCtor:function Zip(){},
 xlsxExporter:{MIME:'application/test',build:(headers,data,options)=>{const result={headers:[...headers],data:data.map(row=>[...row]),options};normalBuilds.push(result);return result}},
 fileDelivery:{deliverBytes:()=>true},
 exportSchema:schema,
 getExportPreferences:async()=>({headers:['ACE SKU','Description','UPC/EAN'],forceAceMiscFormat:false}),
 aceMiscFormatter:{buildAvailableFormat:async (rows,options)=>{miscCalls.push({rows,options});return{forced:true,rows,options}}},
 getKnownUpcsForSku:async sku=>sku==='3022333'?[{upcKey:'001234567890'},{upcKey:'009999999999'}]:[]
});

const item={
 sku:'3022333',
 upc:'001234567890',
 description:'TEST ITEM',
 libraryPrice:10,
 labelPrice:15,
 fields:{'ACE SKU':'9999999','Description':'OLD','UPC/EAN':'999999999999','Retail Units':'2','Level 2 Retail Price':'10.00'}
};

const normalPriceChange=await service.workbookForRows([item],'Price Change',{headers:['ACE SKU','Description','UPC/EAN'],forceAceMiscFormat:false});
assert.deepEqual(Array.from(normalPriceChange.headers),['ACE SKU','Description','UPC/EAN','Label Price','Price Difference']);
assert.deepEqual(Array.from(normalPriceChange.data[0]),['3022333','TEST ITEM','001234567890',15,5]);
assert.equal(normalPriceChange.headers.includes('POSDEPT'),false);
assert.equal(normalPriceChange.headers.includes('Tags'),false);

const selectedOnly=await service.workbookForRows([item],'General Review',{headers:['Description'],forceAceMiscFormat:false});
assert.deepEqual(Array.from(selectedOnly.headers),['Description'],'unchecked Master fields must be omitted entirely');

const forcedPriceChange=await service.workbookForRows([item],'Price Change',{headers:['Description'],forceAceMiscFormat:true});
assert.equal(forcedPriceChange.forced,true);
assert.equal(miscCalls.length,1,'forced mode must delegate exactly once to the ACE MISC formatter');
assert.equal(miscCalls[0].rows[0].sku,item.sku,'forced mode must preserve the persisted Work Session item evidence');
assert.deepEqual(Array.from(miscCalls[0].rows[0].allUpcs),['001234567890','009999999999'],'forced mode must supplement the item with already-verified local identity UPCs');
assert.equal(miscCalls[0].options.trailingColumn.header,'Label Price','forced Price Change must request only the trailing Label Price');
assert.equal(miscCalls[0].options.trailingColumn.valueForItem(item),15);
assert.equal(miscCalls[0].options.trailingColumn.valueForItem({...item,labelPrice:null}),'','skipped price stays blank');
assert.equal(miscCalls[0].options.trailingColumn.valueForItem({...item,labelPrice:0}),0,'zero price stays numeric');
const priceByUpc={...item,registerPricesByUpc:{'001234567890':8.75,'009999999999':0}};
const forcedRegister=await service.workbookForRows([priceByUpc],'Price Change',{headers:['Description'],forceAceMiscFormat:true},{includeRegisterPrice:true});
assert.equal(forcedRegister.forced,true);
const registerColumns=miscCalls.at(-1).options.trailingColumns;
assert.deepEqual(Array.from(registerColumns,c=>c.header),['Label Price','Register Price'],'register price is final column after label price');
assert.equal(registerColumns[0].valueForItem(priceByUpc,'001234567890'),15);
assert.equal(registerColumns[1].valueForItem(priceByUpc,'001234567890'),8.75);
assert.equal(registerColumns[1].valueForItem(priceByUpc,'009999999999'),0,'entered register zero is numeric');
assert.equal(registerColumns[1].valueForItem(priceByUpc,'888888888888'),'','unscanned UPC remains blank');
const normalRegister=await service.workbookForRows([priceByUpc],'Price Change',{headers:['ACE SKU','UPC/EAN'],forceAceMiscFormat:false},{includeRegisterPrice:true});
assert.deepEqual(Array.from(normalRegister.headers),['ACE SKU','UPC/EAN','Label Price','Price Difference','Register Price']);
assert.equal(normalRegister.data[0][4],8.75);
const forcedGeneral=await service.workbookForRows([item],'General Review',{headers:['Description'],forceAceMiscFormat:true});
assert.equal(forcedGeneral.forced,true);
assert.equal(miscCalls.length,3);
assert.equal(miscCalls[2].options.trailingColumn,null,'all non-Price Change forced exports must stay canonical');
assert.equal(normalBuilds.length,3,'forced mode must bypass the ordinary workbook builder, including the Price Change exception');
assert.match(exportSource,/format:'ACE_MISC_FORCED'/);
assert.match(exportSource,/getKnownUpcsForSku/,'forced mode must consume the injected local identity read owner');
assert.doesNotMatch(exportSource,/requestAceNet|lookupAceNet/,'export must not create a network retrieval path');
assert.match(exportSource,/format:'SELECTED_MASTER_FIELDS'/);
assert.match(exportSource,/root\.file\(\x60\$\{tag\} - \$\{date\}\.xlsx\x60/,'purpose-specific filenames must remain intact in both modes');
assert.match(exportSource,/startOperation\('FIELD_SESSION_EXPORT'/);

assert.match(workSessionsSource,/priceChangeDefaults=listType===fieldType&&selectedDefault==='Price Change'/);
assert.match(workSessionsSource,/promptLabelPriceAfterScan:priceChangeDefaults,autoAddPriceDifference:priceChangeDefaults/,'Price Change ON/ON defaults must remain intact');

assert.match(html,/Choose Master Library fields for ordinary exports, or force the exact ACE MISC workbook format/);
// Regression: verify actual serialized XLSX styles and every header's resolved fill.
// v3.02 omitted the required gray125 fill and used displaced fill IDs, causing
// solid-yellow ACE headers to appear white or black-speckled in Excel.
const xlsxContext={window:{},setImmediate,clearImmediate,setTimeout,clearTimeout,Uint8Array,ArrayBuffer,Buffer,Promise,TextEncoder};
vm.createContext(xlsxContext);
vm.runInContext(read('app/src/main/assets/www/vendor/jszip.min.js'),xlsxContext,{filename:'jszip.min.js'});
xlsxContext.JSZip=xlsxContext.window.JSZip;
assert.equal(typeof xlsxContext.JSZip,'function','bundled offline JSZip must load for real XLSX verification');
vm.runInContext(read('app/src/main/assets/www/xlsx-exporter.js'),xlsxContext,{filename:'xlsx-exporter.js'});
xlsxContext.UPCIdentifierNormalization={normalizeSKU:value=>String(value??'').replace(/\D/g,''),normalizeUPC:value=>String(value??'').replace(/\D/g,'')};
xlsxContext.UPCCatalogMappers={normalizeAceNetWeight:value=>String(value??'')};
xlsxContext.UPCIdentifierRelationshipService={getSkuUpcs:async()=>[],recordVerifiedSkuUpcs:async()=>({})};
vm.runInContext(schemaSource+'\n'+miscSource,xlsxContext,{filename:'ace-misc-actual-xlsx.js'});
const realMisc=vm.runInContext('ACEMisc',xlsxContext);
async function verifyRealHeaderFills(bytes,expectedExtraHeaders=[]){
 const archive=await xlsxContext.JSZip.loadAsync(bytes);
 const styles=await archive.file('xl/styles.xml').async('string');
 const sheet=await archive.file('xl/worksheets/sheet1.xml').async('string');
 const fillSection=styles.match(/<fills count="(\d+)">([\s\S]*?)<\/fills>/);
 const xfSection=styles.match(/<cellXfs count="(\d+)">([\s\S]*?)<\/cellXfs>/);
 assert.ok(fillSection&&xfSection,'XLSX styles must contain fill and cell style definitions');
 const fills=Array.from(fillSection[2].matchAll(/<fill>([\s\S]*?)<\/fill>/g),m=>m[1]);
 const cellXfs=Array.from(xfSection[2].matchAll(/<xf\s+([^>]*?)\/>/g),m=>m[1]);
 assert.equal(fills.length,Number(fillSection[1]),'fill count attribute matches actual definitions');
 assert.equal(cellXfs.length,Number(xfSection[1]),'cellXfs count attribute matches actual definitions');
 assert.match(fills[0],/patternType="none"/,'fill 0 is Excel default none');
 assert.match(fills[1],/patternType="gray125"/,'fill 1 is required Excel gray125 default');
 const headerRow=sheet.match(/<row r="1">([\s\S]*?)<\/row>/)?.[1];
 assert.ok(headerRow,'first row must contain Excel headers');
 const headerCells=Array.from(headerRow.matchAll(/<c r="([A-Z]+)1"[^>]*s="(\d+)"[^>]*>/g));
 const expectedHeaders=[...Array.from(schema.ACE_MISC_HEADERS),...expectedExtraHeaders];
 assert.equal(headerCells.length,expectedHeaders.length,'all generated header cells carry explicit styles');
 const yellow=new Set([...Array.from(realMisc.YELLOW),...expectedExtraHeaders.map((_,i)=>33+i)]);
 for(let index=0;index<headerCells.length;index++){
  const styleIndex=Number(headerCells[index][2]);
  const xf=cellXfs[styleIndex];
  assert.ok(xf,'header must refer to a defined cellXf: '+expectedHeaders[index]);
  const fillId=Number(xf.match(/\bfillId="(\d+)"/)?.[1]);
  assert.ok(Number.isInteger(fillId)&&fillId>=0&&fillId<fills.length,'defined header fill: '+expectedHeaders[index]);
  const fill=fills[fillId];
  assert.match(fill,/patternType="solid"/,'solid header fill required for '+expectedHeaders[index]);
  const expectedColor=yellow.has(index)?'FFFFFF00':'FFFFFFFF';
  assert.ok(fill.includes('fgColor rgb="'+expectedColor+'"'),expectedHeaders[index]+' should have '+(yellow.has(index)?'yellow':'white')+' solid fill, actual fillId '+fillId);
  assert.doesNotMatch(fill,/gray125/,'no header may have a speckled gray125 fill');
 }
 const yellowCount=headerCells.filter((_,i)=>yellow.has(i)).length;
 assert.equal(yellowCount,realMisc.YELLOW.length+expectedExtraHeaders.length);
}
const styleTestItem={sku:'3552056',upc:'741835105712',labelPrice:13.99,registerPricesByUpc:{'741835105712':13.99},fields:{'Ace Retail Price':'11.99','Level 2 Retail Price':'13.99',Description:'DIG OPTI TOSLINK CABLE 3'}};
await verifyRealHeaderFills(await realMisc.buildAvailableFormat([styleTestItem]));
await verifyRealHeaderFills(await realMisc.buildAvailableFormat([styleTestItem],{trailingColumn:{header:'Label Price',valueForItem:item=>item.labelPrice}}),['Label Price']);
await verifyRealHeaderFills(await realMisc.buildAvailableFormat([styleTestItem],{trailingColumns:[{header:'Label Price',valueForItem:item=>item.labelPrice},{header:'Register Price',valueForItem:(item,upc)=>item.registerPricesByUpc?.[upc]??''}]}),['Label Price','Register Price']);
console.log('Actual XLSX: all 33/34/35 header fills resolve to correct solid yellow or solid white; none use speckled gray125 PASS');

console.log('v2.88 Master-field selection + forced ACE MISC format PASS');
