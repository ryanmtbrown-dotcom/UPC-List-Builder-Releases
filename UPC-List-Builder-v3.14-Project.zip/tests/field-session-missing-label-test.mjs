import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';

const root='app/src/main/assets/www/';
const read=p=>fs.readFileSync(root+p,'utf8');
const fieldSource=read('field-session/field-session-controller.js');
const exportSource=read('field-session/field-session-export-service.js');
const listSource=read('work-sessions/list-item-controller.js');
const lookupSource=read('lookup/normal-lookup-controller.js');
const shellSource=read('application/application-shell.js');
const html=read('index.html');
const css=read('styles.v059.css');

for(const control of ['labelPricePromptSku','labelPricePromptItem','missingLabelFromPrompt','markMissingLabel'])
 assert.ok(html.includes('id="'+control+'"'),'Missing visible control: '+control);
assert.match(css,/pricePromptIdentity/);
assert.match(css,/max-height:calc\(100dvh - 24px\)/);
assert.match(shellSource,/SUPPLEMENTAL_TAGS=\['Duplicate Item','Missing Label'\]/);
assert.match(lookupSource,/finalizeFieldObservation\(itemPresentationController.getPresentedItem\(\),generation,'unknown_upc_no_sku'\)/);
assert.match(lookupSource,/skuResult\.scannedUpc=key;skuResult\.upc=key/);
assert.match(lookupSource,/finalizeFieldObservation\(skuResult,generation,'upc_identity_resolution'\)/);
assert.match(lookupSource,/finalizeFieldObservation\(result,generation,'sku_recovery'\)/);
assert.match(listSource,/fieldSessionController\.addPending\(options\)/);

const elements=new Map();
const makeElement=()=>({
 value:'',textContent:'',checked:false,disabled:false,onclick:null,
 classList:{add(){},remove(){},toggle(){},contains(){return false}},
 closest(){return{classList:{add(){},remove(){},toggle(){}}}}
});
const el=id=>{if(!elements.has(id))elements.set(id,makeElement());return elements.get(id)};
const money=value=>value===null||value===undefined||String(value).trim()===''?null:
 Number.isFinite(Number(String(value).replace(/[$,]/g,'')))?Number(String(value).replace(/[$,]/g,'')):null;
let idCounter=0,saves=0,renders=0;
let current={id:'session',sessionType:'GENERAL_LIST',promptLabelPriceAfterScan:true,autoAddPriceDifference:true,defaultTag:'Price Change',items:[]};
let pending=null,field=null,lookupGeneration=1;
const ctx={window:{},Date,Math,Promise,Set,Object,Number,String,Array,Error,setTimeout};
vm.createContext(ctx);
vm.runInContext(read('pricing/price-authority.js'),ctx,{filename:'price-authority.js'});
vm.runInContext(fieldSource,ctx,{filename:'field-session-controller.js'});
field=ctx.window.UPCFieldSessionController.create({
 elementById:el,getCurrent:()=>current,getPending:()=>pending,saveCurrent:async()=>{saves++},
 newId:()=>String(++idCounter),normalizeUpc:v=>String(v??''),parseMoney:money,
 primaryPurposeTags:['NIF','Price Change','General Review'],fieldTags:['NIF','Price Change','General Review'],
 diagnostic:()=>{},alertUser:()=>{throw Error('Unexpected user error')},
 presentationProvider:()=>({updatePriceDifference(){},currentGeneration:()=>lookupGeneration}),
 listItemProvider:()=>({addPending:options=>field.addPending(options),renderList(){renders++}}),
 libraryWorkflowProvider:()=>({enqueueFromListItem:async()=>{throw Error('Must not enqueue unknown observation')}}),
 unresolvedOriginProvider:()=>null,recordUnresolved:async()=>{}
});
const lookupPending={status:'NOT_FOUND',upc:'001234567890',scannedUpc:'001234567890',sku:null,description:null,price:null,requestedIdentifierType:'UPC',fields:{}};
pending={...lookupPending};
el('labelPrice').value='';
let prompt=field.applyScannedLabelPricePrompt();
assert.equal(el('labelPricePromptSku').textContent,'SKU Not Found · UPC 001234567890');
el('missingLabelFromPrompt').onclick();
await prompt;
assert.equal(current.items.length,1,'one-tap Missing Label must immediately persist');
assert.equal(saves,1);
assert.equal(current.items[0].upc,'001234567890','unknown observation must preserve scanned UPC');
assert.equal(current.items[0].sku,null,'missing SKU must remain unknown');
assert.equal(current.items[0].labelPrice,null,'missing label is not a numeric zero');
assert.equal(current.items[0].libraryPrice,null);
assert.equal(current.items[0].primaryPurpose,'General Review');
assert.ok(current.items[0].tags.includes('Missing Label'));
assert.ok(!current.items[0].tags.includes('Price Change'));
pending={...lookupPending,sku:'99999'};
const provisionalPrompt=field.applyScannedLabelPricePrompt();
assert.equal(el('labelPricePromptSku').textContent,'SKU Not Found · UPC 001234567890','provisional SKU must never appear verified');
el('skipLabelPrice').onclick();
await provisionalPrompt;
pending={...lookupPending};

await field.editItemField(0,'missingLabel','No');
assert.ok(!current.items[0].tags.includes('Missing Label'),'saved observation can be unmarked');
await field.editItemField(0,'missingLabel','Yes');
assert.ok(current.items[0].tags.includes('Missing Label'),'saved observation can be re-marked');

current.items=[];
pending={...lookupPending,upc:'002222222222',scannedUpc:'002222222222'};
el('labelPrice').value='';
prompt=field.applyScannedLabelPricePrompt();
el('skipLabelPrice').onclick();
await prompt;
assert.equal(current.items.length,0,'Skip must not automatically mark a missing label');
assert.equal(el('labelPrice').value,'');
const afterSkip=await field.addPending({missingLabel:true});
assert.equal(afterSkip.status,'ADDED');
assert.ok(afterSkip.item.tags.includes('Missing Label'));
assert.equal(afterSkip.item.labelPrice,null);

current.items=[];
pending={status:'FOUND',upc:'003333333333',sku:'78945',description:'Item',price:0,fields:{'Level 2 Retail Price':'0.00'}};
el('labelPrice').value='';
prompt=field.applyScannedLabelPricePrompt();
el('labelPriceKeypad').onclick({target:{closest:()=>({dataset:{priceKey:'0'}})}});
el('saveLabelPrice').onclick();
await prompt;
assert.equal(el('labelPrice').value,'0.00','entered zero is a legitimate observed price');
assert.equal(current.items.length,0,'matching zero must not auto-add Price Change');
const markedZero=await field.addPending({missingLabel:true});
assert.equal(markedZero.item.labelPrice,0,'explicit Missing Label must preserve an existing zero observation');
assert.ok(markedZero.item.tags.includes('Missing Label'));
assert.ok(!markedZero.item.tags.includes('Price Change'));

// Financially consequential regression: Ace Retail 11.99 must not create a
// false Price Change when verified Level 2 and physical label both equal 13.99.
vm.runInContext(read('lookup/item-record-mapper.js'),ctx,{filename:'item-record-mapper.js'});
const level2Mapper=ctx.window.UPCItemRecordMapper.create({normalizeUpc:value=>String(value)});
current.items=[];
current.autoAddPriceDifference=true;
pending=level2Mapper.itemFromLibraryRow({skuKey:'3552056',originalUPC:'741835105712',fields:{'Description':'DIG OPTI TOSLINK CABLE 3','Ace Retail Price':'11.99','Level 2 Retail Price':'13.99'}},{librarySource:'MASTER_LIBRARY'});
assert.equal(pending.price,'13.99','lookup must select Level 2 instead of Ace Retail');
el('labelPrice').value='';
prompt=field.applyScannedLabelPricePrompt();
for(const key of ['1','3','.','9','9'])el('labelPriceKeypad').onclick({target:{closest:()=>({dataset:{priceKey:key}})}});
el('saveLabelPrice').onclick();
await prompt;
assert.equal(el('labelPrice').value,'13.99');
assert.equal(current.items.length,0,'matching Level 2 label must never be auto-added as a false Price Change');

current.items=[];
pending={status:'FOUND',upc:'004444444444',sku:'45678',description:'Other',price:9,fields:{'Level 2 Retail Price':'9.00'}};
el('labelPrice').value='';
prompt=field.applyScannedLabelPricePrompt();
el('labelPriceKeypad').onclick({target:{closest:()=>({dataset:{priceKey:'5'}})}});
el('saveLabelPrice').onclick();
await prompt;
assert.equal(current.items.length,1,'a genuine 9-versus-5 price difference still auto-adds');
assert.ok(current.items[0].tags.includes('Price Change'));
assert.ok(!current.items[0].tags.includes('Missing Label'));

current.items=[];
current.autoAddPriceDifference=false;
pending={status:'FOUND',upc:'005555555555',scannedUpc:'005555555555',sku:'555',description:'Refreshed Item',price:10,fields:{'Level 2 Retail Price':'10.00'}};
el('labelPrice').value='';
const refreshingPrompt=field.applyScannedLabelPricePrompt();
pending={...pending,description:'Newer verified description'};
el('labelPriceKeypad').onclick({target:{closest:()=>({dataset:{priceKey:'8'}})}});
el('saveLabelPrice').onclick();
await refreshingPrompt;
assert.equal(el('labelPrice').value,'8.00','same-generation AceNet refresh must not discard an entered price');
assert.equal(current.items.length,0,'matching-generation user observation does not auto-add when disabled');

el('labelPrice').value='';
const supersededPrompt=field.applyScannedLabelPricePrompt();
lookupGeneration++;
pending={status:'FOUND',upc:'006666666666',scannedUpc:'006666666666',sku:'666',price:9,fields:{'Level 2 Retail Price':'9.00'}};
el('labelPriceKeypad').onclick({target:{closest:()=>({dataset:{priceKey:'7'}})}});
el('saveLabelPrice').onclick();
await supersededPrompt;
assert.equal(el('labelPrice').value,'','new lookup generation must discard the old popup result');
assert.match(lookupSource,/scannedUpc:item\.scannedUpc\|\|item\.upc/,'background refreshed item must retain observed UPC');

const exportCtx={window:{}};
vm.createContext(exportCtx);
vm.runInContext(read('pricing/price-authority.js'),exportCtx,{filename:'price-authority.js'});
vm.runInContext(exportSource,exportCtx,{filename:'field-session-export-service.js'});
let calls=0,miscCalls=0;
const exporter=exportCtx.window.UPCFieldSessionExportService.create({
 getCurrentSession:()=>current,exportTags:['Price Change','General Review','Missing Label'],
 dateStamp:()=> '2026-10-10',promptUser:async()=>null,alertUser:()=>{},diagnostic:()=>{},
 startOperation:()=>{},finishOperation:()=>{},storage:{getItem:()=>'',setItem:()=>{}},
 zipCtor:function(){},xlsxExporter:{MIME:'test',build:(headers,data,options)=>{calls++;return{headers:Array.from(headers),data:data.map(v=>Array.from(v)),options}}},
 fileDelivery:{deliverBytes:()=>{}},
 exportSchema:{MASTER_HEADERS:['UPC/EAN'],ACE_MISC_HEADERS:['UPC/EAN'],
  normalizeMasterSelection:v=>v,defaultMasterSelection:()=>['UPC/EAN']},
 getExportPreferences:async()=>({headers:['UPC/EAN'],forceAceMiscFormat:true}),
 aceMiscFormatter:{buildAvailableFormat:async()=>{miscCalls++;return{}}},
 getKnownUpcsForSku:async()=>[]
});
const observed=[
 {status:'NOT_FOUND',scannedUpc:'001234567890',upc:'111111111111',sku:null,labelPrice:null,libraryPrice:null},
 {status:'FOUND',upc:'002222222222',sku:'45678',labelPrice:0,libraryPrice:8,fields:{'Level 2 Retail Price':'8.00'},description:'Shelf Item'}
];
for(const forced of [false,true]){
 const result=await exporter.workbookForRows(observed,'Missing Label',{headers:['UPC/EAN'],forceAceMiscFormat:forced});
 assert.deepEqual(result.headers,['UPC/EAN','ACE SKU','Description','Label Price','Library Price','Lookup Status']);
 assert.equal(result.data[0][0],'001234567890','scanned UPC outranks catalog primary UPC in missing-label report');
 assert.equal(result.data[0][1],'','missing SKU remains blank');
 assert.equal(result.data[0][3],'','unknown label price is not exported as 0');
 assert.equal(result.data[1][3],0,'real entered zero remains 0');
 assert.equal(result.data[1][4],8);
 assert.equal(result.options.sheetName,'Missing Label');
}
assert.equal(calls,2);
assert.equal(miscCalls,0,'missing-label report must not be routed through forced ACE MISC formatter');
console.log('Field Session missing-label capture, zero/skip, edit, and UPC-first export PASS');
