import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';

const servicePath='app/src/main/assets/www/platform/file-export-delivery-service.js';
const serviceSource=fs.readFileSync(servicePath,'utf8');
const ordinaryOwners=[
 'app/src/main/assets/www/ace-dsd.js',
 'app/src/main/assets/www/ace-misc.js',
 'app/src/main/assets/www/field-session/field-session-export-service.js',
 'app/src/main/assets/www/combined-master-export.js',
 'app/src/main/assets/www/application/data-backup-controller.js'
];
for(const path of ordinaryOwners){
 const source=fs.readFileSync(path,'utf8');
 assert.doesNotMatch(source,/\.exportFile\b|createObjectURL\(|new\s+Blob\b/,`${path}: ordinary file delivery must be delegated to the platform owner`);
}
assert.match(serviceSource,/bridge\?\.exportFile/);
assert.match(serviceSource,/createObjectURL\(/);
assert.match(serviceSource,/deliverBytes/);
assert.match(serviceSource,/deliverText/);

const nativeCalls=[];
const nativeContext={window:{},Uint8Array,String,Object,Error,TextEncoder,setTimeout,btoa:value=>Buffer.from(value,'binary').toString('base64')};
vm.createContext(nativeContext);
vm.runInContext(serviceSource,nativeContext,{filename:servicePath});
const nativeService=nativeContext.window.UPCFileExportDeliveryService.create({
 bridgeProvider:()=>({exportFile:(...args)=>nativeCalls.push(args)}),
 documentRef:{createElement:()=>{throw new Error('browser fallback must not run')},body:{}},
 urlApi:{createObjectURL:()=>{throw new Error('browser fallback must not run')}},
 blobCtor:Blob,
 base64Encoder:nativeContext.btoa,
 setTimeoutFn:setTimeout,
 textEncoder:new TextEncoder()
});
const nativeResult=nativeService.deliverBytes(new Uint8Array([1,2,3]),'native.bin','application/octet-stream');
assert.equal(nativeResult.platform,'native');
assert.equal(nativeResult.filename,'native.bin');
assert.equal(nativeResult.byteCount,3);
assert.equal(nativeCalls.length,1);
assert.equal(nativeCalls[0][0],Buffer.from([1,2,3]).toString('base64'));
assert.equal(nativeCalls[0][1],'native.bin');
assert.equal(nativeCalls[0][2],'application/octet-stream');

let clicked=0,appended=0,removed=0,revoked=null,createdBlob=null;
const anchor={href:'',download:'',click:()=>{clicked++},remove:()=>{removed++}};
const browserContext={window:{},Uint8Array,String,Object,Error,TextEncoder,setTimeout,btoa:value=>Buffer.from(value,'binary').toString('base64')};
vm.createContext(browserContext);
vm.runInContext(serviceSource,browserContext,{filename:servicePath});
const browserService=browserContext.window.UPCFileExportDeliveryService.create({
 bridgeProvider:()=>null,
 documentRef:{createElement:tag=>{assert.equal(tag,'a');return anchor},body:{appendChild:node=>{assert.equal(node,anchor);appended++}}},
 urlApi:{createObjectURL:blob=>{createdBlob=blob;return'blob:stage13'},revokeObjectURL:url=>{revoked=url}},
 blobCtor:Blob,
 base64Encoder:browserContext.btoa,
 setTimeoutFn:fn=>fn(),
 textEncoder:new TextEncoder()
});
const browserResult=browserService.deliverText('hello','browser.txt','text/plain');
assert.equal(browserResult.platform,'browser');
assert.equal(browserResult.filename,'browser.txt');
assert.equal(browserResult.byteCount,5);
assert.ok(createdBlob instanceof Blob);
assert.equal(anchor.href,'blob:stage13');
assert.equal(anchor.download,'browser.txt');
assert.equal(appended,1);
assert.equal(clicked,1);
assert.equal(removed,1);
assert.equal(revoked,'blob:stage13');

const map=fs.readFileSync('SOURCE_OWNERSHIP_MAP.md','utf8');
const platformReadme=fs.readFileSync('app/src/main/assets/www/platform/README.md','utf8');
assert.match(map,/platform\/file-export-delivery-service\.js/);
assert.match(platformReadme,/file delivery/i);
console.log('Stage 13 standard file-export delivery ownership PASS');
