import fs from 'node:fs';

export function readPersistentWorkerSource(){
  return fs.readFileSync('app/src/main/java/com/rmtb/upclistbuilder/PersistentAceNetWorker.kt','utf8');
}

export function extractPersistentWorkerScript({expected='50177',mode='PRODUCTION_PRICE'}={}){
  const source=readPersistentWorkerSource();
  const inspect=source.indexOf('private fun inspect(v:WebView)');
  const marker='        val js="""';
  const start=source.indexOf(marker,inspect);
  const end=source.indexOf('        """.trimIndent()',start);
  if(inspect<0||start<0||end<=start)throw new Error('PersistentAceNetWorker inspection script is not extractable.');
  return source.slice(start+marker.length,end)
    .split('$expected').join(JSON.stringify(expected))
    .split('$mode').join(JSON.stringify(mode));
}

export function makeWorkerBridge({diagnostics=[],results=[],progress=[],snapshots=[],forensics=[]}={}){
  return {
    diagnostic:raw=>diagnostics.push(JSON.parse(raw)),
    skuObserved:()=>{},
    result:raw=>results.push(JSON.parse(raw)),
    progress:raw=>progress.push(JSON.parse(raw)),
    catalogSnapshot:raw=>snapshots.push(JSON.parse(raw)),
    repairSnapshot:raw=>snapshots.push(JSON.parse(raw)),
    shouldCaptureForensics:()=>false,
    forensics:raw=>forensics.push(JSON.parse(raw))
  };
}
