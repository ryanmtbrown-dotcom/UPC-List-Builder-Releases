import fs from 'node:fs';
import path from 'node:path';

const WEB_ROOT='app/src/main/assets/www';
const NATIVE_ROOT='app/src/main/java/com/rmtb/upclistbuilder';

function walk(dir,predicate){
  const out=[];
  for(const name of fs.readdirSync(dir).sort()){
    const full=path.join(dir,name);
    const stat=fs.statSync(full);
    if(stat.isDirectory()){if(name!=='vendor')out.push(...walk(full,predicate));continue;}
    if(predicate(full))out.push(full);
  }
  return out;
}

export function webRuntimeFiles(){return walk(WEB_ROOT,p=>p.endsWith('.js')&&!p.endsWith('.min.js')&&!p.endsWith('service-worker.js'));}
export function nativeRuntimeFiles(){return walk(NATIVE_ROOT,p=>p.endsWith('.kt'));}
function joinSources(files){return files.map(file=>'\n/* SOURCE: '+file+' */\n'+fs.readFileSync(file,'utf8')).join('\n');}
export function readWebRuntimeSource(){return joinSources(webRuntimeFiles());}
export function readNativeRuntimeSource(){return joinSources(nativeRuntimeFiles());}

function functionSlice(source,name,kind){
  const escaped=name.replace(/[.*+?^$()|[\]\\{}]/g,'\\$&');
  const pattern=kind==='js'
    ? new RegExp('(?:^|\\n)[ \\t]*(?:export\\s+)?(?:async\\s+)?function\\s+'+escaped+'\\s*\\(','m')
    : new RegExp('(?:^|\\n)[ \\t]*(?:(?:private|public|internal|protected|override|suspend)\\s+)*fun\\s+'+escaped+'\\s*\\(','m');
  const match=pattern.exec(source);
  if(!match)return null;
  const start=match.index+(match[0].startsWith('\n')?1:0);
  const rest=source.slice(start+1);
  const nextPattern=kind==='js'?/\n(?: ?(?:export\s+)?(?:async\s+)?function\s+[A-Za-z_$][\w$]*\s*\(|window\.|globalThis\.)/g:/\n\s*(?:(?:private|public|internal|protected|override|suspend)\s+)*fun\s+[A-Za-z_][\w]*\s*\(/g;
  const next=nextPattern.exec(rest);
  return source.slice(start,next?start+1+next.index:source.length);
}
export function findJsFunction(name){for(const file of webRuntimeFiles()){const src=fs.readFileSync(file,'utf8'),found=functionSlice(src,name,'js');if(found)return found;}throw new Error('JavaScript function not found in first-party runtime tree: '+name);}
export function findKotlinFunction(name){for(const file of nativeRuntimeFiles()){const src=fs.readFileSync(file,'utf8'),found=functionSlice(src,name,'kt');if(found)return found;}throw new Error('Kotlin function not found in first-party runtime tree: '+name);}
