import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import {performance} from 'node:perf_hooks';

const source=fs.readFileSync('app/src/main/assets/www/identifier-relationship-service.js','utf8');
const db=fs.readFileSync('app/src/main/assets/www/db.js','utf8');
const count=100000,index=new Map(),resolutions=new Map();
for(let i=0;i<count;i++){const upc=String(100000000000+i),sku='sku'+i;index.set(upc,[{skuKey:sku,upcKey:upc,isMaster:true,source:'PERF'}]);resolutions.set(upc,{upcKey:upc,status:'NORMAL',preferredSkuKey:sku,candidateSkuKeys:[sku]})}
const repo={
 getUpcResolution:async key=>resolutions.get(key)||null,
 lookupSkuByUpc:async key=>index.get(key)||[],
 replaceSkuUpcSet:async()=>{throw new Error('not used')},recordVerifiedSkuUpcs:async()=>{throw new Error('not used')},
 getSkuUpcs:async()=>[],recordIdentityRelationship:async()=>{},getSkuIdentity:async()=>null,setSkuIdentityStatus:async()=>{},setSkuReplacement:async()=>{},resolveConflict:async()=>{},enqueueResearch:async()=>{},getResearchQueue:async()=>[],removeResearch:async()=>{},updateResearchSku:async()=>{},discardResearch:async()=>{},getConflictQueue:async()=>[]
};
const context={window:{},UPCIdentityRepository:repo,UPCIdentifierNormalization:{normalizeSKU:v=>String(v??'').trim().toLowerCase(),normalizeUPC:v=>String(v??'').replace(/\D/g,'')}};
vm.createContext(context);vm.runInContext(source,context);
const service=context.window.UPCIdentifierRelationshipService,queries=5000,start=performance.now();
for(let i=0;i<queries;i++){const n=(i*7919)%count,upc=String(100000000000+n),r=await service.resolveUPC(upc);assert.equal(r.status,'KNOWN');assert.equal(r.sku,'sku'+n)}
const elapsed=performance.now()-start;
assert.ok(elapsed<10000,`5000 indexed relationship resolutions over 100000 relationships took too long: ${elapsed.toFixed(1)} ms`);
assert.match(db,/objectStore\('skuUpcs'\)\.index\('upcKey'\)\.getAll\(IDBKeyRange\.only\(upcKey\)\)/,'Physical UPC relationship lookup must use the upcKey index.');
console.log(`Stage 4 relationship performance PASS: ${queries} indexed resolutions over ${count} relationships in ${elapsed.toFixed(1)} ms`);
