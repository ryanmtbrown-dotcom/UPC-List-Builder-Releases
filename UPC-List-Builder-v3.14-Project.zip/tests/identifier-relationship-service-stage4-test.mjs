import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import {readWebRuntimeSource,webRuntimeFiles} from './helpers/runtime-source-tree.mjs';

const serviceSource=fs.readFileSync('app/src/main/assets/www/identifier-relationship-service.js','utf8');
const dbSource=fs.readFileSync('app/src/main/assets/www/db.js','utf8');
const web=readWebRuntimeSource();
const workflowRuntime=webRuntimeFiles().filter(file=>!file.endsWith('identity-repository.js')&&!file.endsWith('identifier-relationship-service.js')&&!file.endsWith('catalog/database-inspection-service.js')).map(file=>fs.readFileSync(file,'utf8')).join('\n');
const misc=fs.readFileSync('app/src/main/assets/www/ace-misc.js','utf8');
const stripOwnership=source=>source.replace(/^\/\*\*?[\s\S]*?\*\/\s*/,'');
const serviceBody=stripOwnership(serviceSource);

assert.doesNotMatch(serviceBody,/UPCAceNet|AndroidNative|fetch\s*\(|document\.|UPCDB\./,'Relationship service must depend on IdentityRepository rather than network/UI/raw DB; naming deferred AceNet work is not a network dependency.');
assert.match(serviceSource,/UPCIdentityRepository\.replaceSkuUpcSet/);
assert.match(serviceSource,/UPCIdentityRepository\.recordVerifiedSkuUpcs/);

function makeService({resolution=null,relationships=[]}={}){
 const calls=[];
 const repo={
  getUpcResolution:async key=>{calls.push(['getUpcResolution',key]);return resolution},
  lookupSkuByUpc:async key=>{calls.push(['lookupSkuByUpc',key]);return relationships},
  replaceSkuUpcSet:async(sku,upcs,source)=>{calls.push(['replaceSkuUpcSet',sku,[...upcs],source]);return{skuKey:sku,masterUpc:upcs[0],upcs:[...upcs],inserted:1,updated:0,removed:1,removedUpcs:['OLD'],resolutions:[],conflictCount:0}},
  recordVerifiedSkuUpcs:async(sku,upcs,source)=>{calls.push(['recordVerifiedSkuUpcs',sku,[...upcs],source]);return{skuKey:sku,masterUpc:upcs[0],upcs:[...upcs],inserted:1,updated:0,resolutions:[],conflictCount:0}},
  getSkuUpcs:async()=>[],recordIdentityRelationship:async()=>{},getSkuIdentity:async()=>null,setSkuIdentityStatus:async()=>{},setSkuReplacement:async()=>{},resolveConflict:async()=>{},enqueueResearch:async()=>{},getResearchQueue:async()=>[],removeResearch:async()=>{},updateResearchSku:async()=>{},discardResearch:async()=>{},getConflictQueue:async()=>[]
 };
 const context={window:{},UPCIdentityRepository:repo,UPCIdentifierNormalization:{normalizeSKU:v=>String(v??'').trim().toLowerCase(),normalizeUPC:v=>String(v??'').replace(/\D/g,'')}};
 vm.createContext(context);vm.runInContext(serviceSource,context,{filename:'identifier-relationship-service.js'});
 return{service:context.window.UPCIdentifierRelationshipService,calls};
}

{
 const {service}=makeService({relationships:[{skuKey:'abc',upcKey:'123'}]});
 const r=await service.resolveUPC('123');assert.equal(r.status,'KNOWN');assert.equal(r.sku,'abc');
}
{
 const {service}=makeService({resolution:{status:'UNRESOLVED_CONFLICT',candidateSkuKeys:['a','b']},relationships:[{skuKey:'a'},{skuKey:'b'}]});
 const r=await service.resolveUPC('123');assert.equal(r.status,'CONFLICT');assert.deepEqual(Array.from(r.candidateSkuKeys),['a','b']);
}
{
 const {service}=makeService({resolution:{status:'RESOLVED',preferredSkuKey:'b'},relationships:[{skuKey:'a'},{skuKey:'b'}]});
 const r=await service.resolveUPC('123');assert.equal(r.status,'KNOWN');assert.equal(r.sku,'b');assert.equal(r.reason,'EXPLICIT_RESOLUTION');
}
{
 const {service}=makeService({resolution:{status:'RESOLVED',preferredSkuKey:'stale'},relationships:[{skuKey:'current'}]});
 const r=await service.resolveUPC('123');assert.equal(r.status,'CONFLICT');assert.equal(r.reason,'STALE_RESOLUTION_DISAGREES_WITH_RELATIONSHIPS');
}
{
 const {service}=makeService();
 const r=await service.resolveUPC('123');assert.equal(r.status,'UNKNOWN');
}
{
 const {service,calls}=makeService();
 const r=await service.recordVerifiedSkuUpcs('SKU1',['111','222'],'COMPLETE_TEST',{completeness:'COMPLETE',exactSkuVerified:true});
 assert.equal(r.applied,true);assert.equal(r.destructiveReconciliation,true);assert.equal(calls.some(x=>x[0]==='replaceSkuUpcSet'),true);assert.equal(calls.some(x=>x[0]==='recordVerifiedSkuUpcs'),false);
}
{
 const {service,calls}=makeService();
 const r=await service.recordVerifiedSkuUpcs('SKU1',['111'],'PARTIAL_TEST',{completeness:'PARTIAL',exactSkuVerified:true});
 assert.equal(r.applied,true);assert.equal(r.destructiveReconciliation,false);assert.equal(r.removed,0);assert.equal(calls.some(x=>x[0]==='recordVerifiedSkuUpcs'),true);assert.equal(calls.some(x=>x[0]==='replaceSkuUpcSet'),false);
}
{
 const {service,calls}=makeService();
 const r=await service.recordVerifiedSkuUpcs('SKU1',['111'],'UNVERIFIED',{completeness:'COMPLETE',exactSkuVerified:false});
 assert.equal(r.applied,false);assert.equal(r.reason,'EXACT_SKU_NOT_VERIFIED');assert.equal(calls.some(x=>x[0]==='replaceSkuUpcSet'||x[0]==='recordVerifiedSkuUpcs'),false);
}

assert.match(dbSource,/existingMaster=existing\.find\(row=>Boolean\(row\.isMaster\)\)\?\.upcKey\|\|null/,'Partial merge must detect and preserve an existing master UPC.');
assert.match(dbSource,/isMaster:Boolean\(row\.isMaster\)/,'Partial evidence must not demote an existing master relationship.');
assert.match(dbSource,/isMaster:!existingMaster&&upcKey===masterUpc/,'A partial merge may assign a master only when the SKU has no existing master.');
assert.match(dbSource,/async function replaceSkuUpcSet\(sku,upcs,source='VERIFIED_COMPLETE_SET'\)/);
assert.match(dbSource,/transaction\(\['skuUpcs','upcIdentityResolution'\],'readwrite'\)/,'Replacement must update membership and derived resolution atomically.');
assert.match(dbSource,/for\(const row of removedRows\)relationships\.delete\(\[skuKey,row\.upcKey\]\)/,'Missing current relationships must be deleted.');
assert.match(dbSource,/if\(!candidates\.length\)\{\s*resolutions\.delete\(upcKey\)/,'Unused UPC resolution rows must be deleted.');
assert.match(dbSource,/prior\?\.status==='RESOLVED'/,'Atomic replacement must inspect prior explicit conflict resolution.');
assert.match(dbSource,/candidates\.includes\(normalizeSKU\(prior\.preferredSkuKey\)\)/,'A valid preferred SKU must remain resolved while still current.');
assert.match(dbSource,/retainResolved\?'RESOLVED':'UNRESOLVED_CONFLICT'/,'Only unresolved current conflicts may be reset to unresolved.');
assert.match(dbSource,/const DB='upc-list-builder',VER=9/,'Current location upgrade must preserve identity relationship logic under schema 9.');

assert.doesNotMatch(workflowRuntime,/UPCIdentityRepository\./,'Workflow code must use Identifier Relationship Service rather than IdentityRepository.');
assert.doesNotMatch(misc,/UPCIdentityRepository\./,'ACE MISC must use Identifier Relationship Service rather than IdentityRepository.');
assert.match(web,/relationshipSource:'ACENET_NORMAL_ENRICHMENT'/,'Normal enrichment must identify its relationship source at the Stage 7 policy boundary.');
assert.match(web,/relationshipSource:'ACENET_LOCAL_REPAIR'/,'Local repair must identify its relationship source at the Stage 7 policy boundary.');
assert.match(web,/plan\.relationship\.action==='REPLACE'[\s\S]*recordVerifiedSkuUpcs\(key,plan\.relationship\.upcs,relationshipSource,\{completeness:'COMPLETE',exactSkuVerified:true\}\)/,'Complete Stage 7 policy evidence must still use Stage 4 complete-set replacement.');
assert.match(web,/plan\.relationship\.action==='MERGE'[\s\S]*recordVerifiedSkuUpcs\(key,plan\.relationship\.upcs,relationshipSource,\{completeness:'PARTIAL',exactSkuVerified:true\}\)/,'Partial Stage 7 policy evidence must still use Stage 4 non-destructive merge.');
assert.match(web,/async function aceMiscRefreshLibraryRecord/,'ACE MISC full-catalog refresh owner missing.');
assert.match(web,/applyCatalogRefreshPolicyToExistingRecord\(\{sku:key,target,record:row,evidence:catalog,exactSkuVerified:true,source:'ACE_MISC_FULL_REFRESH',relationshipSource,completeUpcSet:true\}\)/,'ACE MISC live full-catalog evidence must pass the actual resolved row into the Stage 7 policy owner.');
assert.match(web,/identity_user_upc_rejected_by_complete_acenet_set/,'Complete exact-SKU evidence must be able to reject a provisional user UPC association.');
assert.match(web,/const verifiedRelationship=await UPCIdentifierRelationshipService\.resolveUPC\(key\)/,'Post-AceNet user UPC acceptance must re-check the reconciled current relationship state.');

console.log('Stage 4 Identifier Relationship Service current-state semantics PASS');
