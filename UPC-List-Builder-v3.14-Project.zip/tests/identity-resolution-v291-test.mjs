import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';

const relationshipSource=fs.readFileSync('app/src/main/assets/www/identifier-relationship-service.js','utf8');
const normalLookupSource=fs.readFileSync('app/src/main/assets/www/lookup/normal-lookup-controller.js','utf8');
const identityWorkSource=fs.readFileSync('app/src/main/assets/www/identity/identity-work-controller.js','utf8');
const dbSource=fs.readFileSync('app/src/main/assets/www/db.js','utf8');
const aceMiscSource=fs.readFileSync('app/src/main/assets/www/ace-misc.js','utf8');
const miscVerificationSource=fs.readFileSync('app/src/main/assets/www/misc/misc-verification-service.js','utf8');
const catalogMaintenanceSource=fs.readFileSync('app/src/main/assets/www/catalog/catalog-maintenance-service.js','utf8');
const toggleContract=fs.readFileSync('ACENET_COMPARISON_TOGGLE_CONTRACT.md','utf8');
const authorityContract=fs.readFileSync('PRODUCT_DATA_AUTHORITY_CONTRACT.md','utf8');
const researchContract=fs.readFileSync('IDENTITY_RESEARCH_RESOLUTION_CONTRACT.md','utf8');

const normalizeSku=v=>String(v??'').replace(/\D/g,'');
const normalizeUpc=v=>String(v??'').replace(/\D/g,'');
const SKU='12345',A='111111111111',B='222222222222',C='333333333333';

const currentBySku=new Map();
const research=new Map();
const deferred=new Map();
const identityRepo={
 async getUpcResolution(){return null},
 async lookupSkuByUpc(upc){
  const key=normalizeUpc(upc),rows=[];
  for(const [sku,set] of currentBySku)if(set.has(key))rows.push({skuKey:sku,upcKey:key});
  return rows;
 },
 async replaceSkuUpcSet(sku,upcs,source){
  const key=normalizeSku(sku),before=new Set(currentBySku.get(key)||[]),next=new Set(upcs.map(normalizeUpc).filter(Boolean)),removed=[...before].filter(x=>!next.has(x));
  currentBySku.set(key,next);
  return{skuKey:key,masterUpc:[...next][0]||null,upcs:[...next],inserted:[...next].filter(x=>!before.has(x)).length,updated:[...next].filter(x=>before.has(x)).length,removed:removed.length,removedUpcs:removed,resolutions:[],conflictCount:0,source};
 },
 async recordVerifiedSkuUpcs(sku,upcs,source){
  const key=normalizeSku(sku),set=new Set(currentBySku.get(key)||[]);for(const upc of upcs)set.add(normalizeUpc(upc));currentBySku.set(key,set);
  return{skuKey:key,masterUpc:[...set][0]||null,upcs:[...set],inserted:upcs.length,updated:0,conflictCount:0,source};
 },
 async getSkuUpcs(sku){return[...(currentBySku.get(normalizeSku(sku))||[])].map(upcKey=>({skuKey:normalizeSku(sku),upcKey}))},
 async recordRelationship(sku,upc,source){const key=normalizeSku(sku),set=new Set(currentBySku.get(key)||[]);set.add(normalizeUpc(upc));currentBySku.set(key,set);return{skuKey:key,upcKey:normalizeUpc(upc),source}},
 async getSkuIdentity(){return null},async setSkuIdentityStatus(){return{}},async setSkuReplacement(){return{}},async resolveConflict(){return{}},
 async enqueueResearch(candidate){const key=normalizeSku(candidate.sku),prior=research.get(key)||{},row={...prior,...candidate,skuKey:key,sku:String(candidate.sku),upcs:[...new Set([...(prior.upcs||[]),...(candidate.upcs||[])].map(normalizeUpc).filter(Boolean))]};research.set(key,row);return row},
 async getResearch(sku){return research.get(normalizeSku(sku))||null},
 async updateResearch(sku,patch){const key=normalizeSku(sku),row={...(research.get(key)||{}),...patch,skuKey:key};research.set(key,row);return row},
 async updateResearchUpc(sku,upc){const key=normalizeSku(sku),row={...(research.get(key)||{}),skuKey:key,upcs:[normalizeUpc(upc)]};research.set(key,row);return row},
 async getResearchQueue(){return[...research.values()]},async removeResearch(sku){research.delete(normalizeSku(sku))},
 async updateResearchSku(oldSku,newSku){const oldKey=normalizeSku(oldSku),newKey=normalizeSku(newSku),row={...(research.get(oldKey)||{}),skuKey:newKey,sku:String(newSku)};research.delete(oldKey);research.set(newKey,row);return row},
 async discardResearch(sku){return research.delete(normalizeSku(sku))},
 async enqueueDeferredRefresh(candidate){const key=normalizeSku(candidate.sku),prior=deferred.get(key)||{},row={...prior,...candidate,skuKey:key,sku:String(candidate.sku),upcs:[...new Set([...(prior.upcs||[]),...(candidate.upcs||[])].map(normalizeUpc).filter(Boolean))]};deferred.set(key,row);return row},
 async getDeferredRefreshQueue(){return[...deferred.values()]},async removeDeferredRefresh(sku){return deferred.delete(normalizeSku(sku))},
 async getConflictQueue(){return[]}
};

const relationshipContext={window:{},UPCIdentityRepository:identityRepo,UPCIdentifierNormalization:{normalizeSKU:normalizeSku,normalizeUPC:normalizeUpc},Set,Promise,String,Array,Object,Error};
vm.createContext(relationshipContext);
vm.runInContext(relationshipSource,relationshipContext,{filename:'identifier-relationship-service.js'});
const relationships=relationshipContext.window.UPCIdentifierRelationshipService;

await relationships.recordVerifiedSkuUpcs(SKU,[A,B,C],'SIM_INITIAL',{completeness:'COMPLETE',exactSkuVerified:true});
assert.equal((await relationships.resolveUPC(C)).status,'KNOWN','initial complete set must contain C');
const replaced=await relationships.recordVerifiedSkuUpcs(SKU,[A,B],'SIM_NEWER_ACENET',{completeness:'COMPLETE',exactSkuVerified:true});
assert.deepEqual(JSON.parse(JSON.stringify(replaced.removedUpcs)),[C],'newer complete AceNet set must retire C');
assert.equal((await relationships.resolveUPC(C)).status,'UNKNOWN','retired C must not remain current lookup authority');
assert.deepEqual([...(currentBySku.get(SKU)||[])],[A,B],'relationship state must contain only the new complete set');

let comparisonOn=true,catalogResponse={status:'NOT_FOUND',sku:SKU,catalog:null},catalogPersisted=false;
const localIdentifierResolver={
 async resolveSKU(sku){
  if(catalogPersisted)return{status:'FOUND',catalog:{row:{skuKey:normalizeSku(sku),upcKey:A,fields:{}},lookupMode:'LOCAL_SKU_EXACT',provenance:'LOCAL_LIBRARY',activeMasterRecordId:null}};
  return{status:'NOT_FOUND',catalog:{lookupMode:'MASTER_LOCAL_SKU_MISS',matches:0}};
 },
 async resolveUPC(){return{status:'UNKNOWN',directCatalog:{observations:[]},relationship:{status:'UNKNOWN'}}}
};
const itemMapper={itemFromLibraryRow:(row,{fallbackSku,librarySource})=>({status:'FOUND',sku:fallbackSku||row.skuKey,upc:row.upcKey,description:'SIM ITEM',price:'10.00',libraryPrice:'10.00',orderMultiple:'1',retailUnits:'1',fields:row.fields||{},librarySource:librarySource||'LOCAL_LIBRARY',recordOrigin:'ACE_DERIVED'})};
const catalogRefreshService={
 async persistVerifiedAceNetCatalogToLocalLibrary(sku,catalog,{relationshipSource}={}){
  await relationships.recordVerifiedSkuUpcs(sku,catalog.allUpcs||[catalog.masterUpc],relationshipSource||'SIM_ACENET',{completeness:'COMPLETE',exactSkuVerified:true});
  catalogPersisted=true;return{status:'COMPLETED',upcs:[...(catalog.allUpcs||[])]};
 },
 async reconcileVerifiedUpcSetWithCatalog(sku,upcs,{relationshipSource}={}){return relationships.recordVerifiedSkuUpcs(sku,upcs,relationshipSource||'SIM_ENRICH',{completeness:'COMPLETE',exactSkuVerified:true})}
};
const dummyPresentation={};
const elements=new Map([['upc',{value:''}],['status',{textContent:''}],['addToList',{disabled:false}]]);
const normalContext={window:{},performance:{now:()=>0},Date,Math,Set,Map,Object,String,Array,Number,Promise,Error};
vm.createContext(normalContext);vm.runInContext(normalLookupSource,normalContext,{filename:'normal-lookup-controller.js'});
const normal=normalContext.window.UPCNormalLookupController.create({
 localIdentifierResolver,itemMapper,relationshipService:relationships,catalogRefreshService,normalizeSku,normalizeUpc,
 requestCatalog:async()=>catalogResponse,requestUpcs:async()=>({status:'UNAVAILABLE',upcs:[]}),
 priceService:{requestPrice:async()=>({status:'UNAVAILABLE',price:null})},comparisonEnabled:()=>comparisonOn,upcEnrichmentEnabled:()=>comparisonOn,
 diagnostic:()=>{},presentationController:dummyPresentation,elementById:id=>elements.get(id)||{value:'',textContent:'',classList:{add(){},remove(){},toggle(){}}},
 getManualLookupMode:()=> 'UPC',setManualLookupMode:()=>{},promptForUnknownUpcSku:async()=>SKU,applyScannedLabelPricePrompt:async()=>{},
 subsystemOperationStart:()=>{},subsystemOperationFinish:()=>{},lookupOperationStart:()=>{},lookupOperationFinish:()=>{},getCurrentSession:()=>null
});

research.clear();deferred.clear();catalogPersisted=false;comparisonOn=true;catalogResponse={status:'NOT_FOUND',sku:SKU,catalog:null};
const retiredScan=await normal.resolveMissingSkuThroughAceNet({status:'NOT_FOUND',sku:SKU,scannedUpc:C,upc:C});
assert.equal(retiredScan.authority.status,'NOT_FOUND');
assert.deepEqual(research.get(SKU).upcs,[C],'later scan of retired C must reach current research with observed UPC context');
assert.equal((await relationships.resolveUPC(C)).status,'UNKNOWN','research must not resurrect retired relationship');

research.clear();deferred.clear();comparisonOn=false;catalogPersisted=false;
const offline=await normal.resolveMissingSkuThroughAceNet({status:'NOT_FOUND',sku:SKU,scannedUpc:C,upc:C});
assert.equal(offline.authority.status,'DEFERRED');
assert.deepEqual(research.get(SKU).upcs,[C],'offline unresolved item must be retained for research');
assert.deepEqual(deferred.get(SKU).upcs,[C],'offline unresolved SKU must be deduplicated into deferred live refresh work');

research.clear();deferred.clear();comparisonOn=true;catalogPersisted=false;
catalogResponse={status:'VERIFIED',sku:SKU,catalog:{sku:SKU,masterUpc:A,allUpcs:[A,B],description:'SIM ITEM'}};
await normal.resolveMissingSkuThroughAceNet({status:'NOT_FOUND',sku:SKU,scannedUpc:C,upc:C});
assert.deepEqual([...(currentBySku.get(SKU)||[])],[A,B],'verified current AceNet set must remain authoritative when scanned C is absent');
assert.equal((await relationships.resolveUPC(C)).status,'UNKNOWN','user-scanned C must not be written when complete current AceNet excludes it');

catalogPersisted=false;catalogResponse={status:'VERIFIED',sku:SKU,catalog:{sku:SKU,masterUpc:A,allUpcs:[A,B,C],description:'SIM ITEM'}};
await normal.resolveMissingSkuThroughAceNet({status:'NOT_FOUND',sku:SKU,scannedUpc:C,upc:C});
assert.equal((await relationships.resolveUPC(C)).status,'KNOWN','scanned C becomes current only when complete AceNet evidence includes it');

assert.match(dbSource,/transaction\(\['skuUpcs','upcIdentityResolution'\],'readwrite'\)/,'single relationship write must atomically own relationship + resolution state');
assert.match(dbSource,/if\(wanted\.has\(row\.upcKey\)\)\{store\.put\(next\);updated\+\+\}/,'same-source observations must persist refreshed lastSeenAt');
for(const action of ['Correct SKU','Correct UPC','Mark Third-Party Vendor','Mark Recall','Mark Old / Deprecated Supplier','Keep Unknown / Review Later','Delete'])assert.ok(identityWorkSource.includes(action),`research resolution UI missing ${action}`);
assert.match(identityWorkSource,/Refresh Pending Item Data/);
assert.match(identityWorkSource,/if\(!comparisonEnabled\(\)\).*Turn on AceNet Comparison/s,'deferred batch must refuse live work while comparison is OFF');
assert.match(toggleContract,/UPC Enrichment must never be operationally ON while Comparison Pricing is OFF/);
assert.match(authorityContract,/AceNet is the live upstream authority/);
assert.match(authorityContract,/lookup key and user observation, not another catalog source/);
assert.match(authorityContract,/Do not add a historical\/retired UPC↔SKU table/);
assert.match(researchContract,/ACE New Items MISC retains its own required UPC-verification\/retry workflow/);
assert.match(normalLookupSource,/relationshipSource:'ACENET_NORMAL_ENRICHMENT'/,'normal UPC enrichment must persist through Catalog Refresh/relationship ownership');
assert.match(identityWorkSource,/relationshipSource:'ACENET_CATALOG'/,'Add-to-Local batch must harvest complete AceNet UPCs');
assert.match(identityWorkSource,/relationshipSource:'ACENET_RESEARCH_RECHECK'/,'research recheck must harvest complete AceNet UPCs');
assert.match(identityWorkSource,/relationshipSource:'ACENET_DEFERRED_REFRESH'/,'deferred live refresh must harvest complete AceNet UPCs');
assert.match(aceMiscSource,/recordVerifiedSkuUpcs[\s\S]*completeness:'COMPLETE'/,'ACE MISC complete UPC ingestion must use the shared relationship owner');
assert.match(miscVerificationSource,/relationshipSource:'ACENET_MISC_PENDING_RETRY'/,'MISC retry verification must preserve relationship handoff');
assert.match(catalogMaintenanceSource,/relationshipSource:'ACENET_LOCAL_REPAIR'/,'Local repair must preserve relationship handoff');

console.log('v2.91 identity authority, retirement, research, deferred refresh, and resolution simulation: PASS');
