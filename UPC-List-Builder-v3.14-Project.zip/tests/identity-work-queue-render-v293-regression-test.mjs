import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';

const source=fs.readFileSync('app/src/main/assets/www/identity/identity-work-controller.js','utf8');
const diagnostics=[];
const host={
  innerHTML:'',
  querySelectorAll(){return[]}
};

const localRepository={
  async getUpdateQueue(){return[]}
};
const relationshipService={
  async getResearchQueue(){
    return [{
      sku:'123456',
      skuKey:'123456',
      upcs:['012345678905'],
      classification:'UNKNOWN',
      reason:'NOT_IN_MASTER_LOCAL_OR_ACENET'
    }];
  },
  async getConflictQueue(){return[]},
  async getDeferredAceNetRefreshQueue(){return[]}
};

const context={window:{},Date,Set,Map,Object,String,Array,Number,Promise,Math};
vm.createContext(context);
vm.runInContext(source,context,{filename:'identity-work-controller.js'});

const identity=context.window.UPCIdentityWorkController.create({
  elementById:id=>id==='identityWorkQueues'?host:null,
  escapeHtml:value=>String(value??''),
  normalizeSku:value=>String(value??'').replace(/\D/g,''),
  normalizeUpc:value=>String(value??'').replace(/\D/g,''),
  localRepository,
  relationshipService,
  catalogRefreshService:{persistVerifiedAceNetCatalogToLocalLibrary:async()=>({status:'COMPLETED',upcs:[]})},
  requestCatalog:async()=>({status:'NOT_FOUND',catalog:null}),
  normalLookupProvider:()=>({lookupItemBySku:async()=>({status:'NOT_FOUND'})}),
  workSessionService:{list:async()=>[],save:async value=>value},
  getCurrentSession:()=>null,
  newId:()=> 'test-id',
  sessionName:()=> 'Oct 4, 2026',
  messageUser:async()=>{},
  alertUser:()=>{},
  promptUser:async()=>null,
  confirmUser:async()=>true,
  comparisonEnabled:()=>true,
  libraryWorkflowProvider:()=>null,
  diagnostic:(event,payload={})=>diagnostics.push({event,payload})
});

await identity.refreshWorkQueues();

assert.match(host.innerHTML,/Items Needing Research · 1/,'non-empty research queue must render its count');
assert.match(host.innerHTML,/SKU 123456/,'research row must render the queued SKU');
assert.match(host.innerHTML,/identityResearchAction/,'research resolution controls must render');
assert.doesNotMatch(host.innerHTML,/Identity work queues unavailable/,'research rendering must not fall into the generic unavailable state');
assert.ok(diagnostics.some(entry=>entry.event==='identity_work_queues_rendered'&&entry.payload.needsResearch===1),'successful queue-render diagnostic must be emitted');
assert.ok(!diagnostics.some(entry=>entry.event==='identity_work_queues_failed'),'queue-render failure diagnostic must not be emitted');

console.log('identity work queue non-empty research render regression: PASS');
