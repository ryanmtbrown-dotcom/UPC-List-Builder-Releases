import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import {extractPersistentWorkerScript,makeWorkerBridge} from './helpers/persistent-worker-script.mjs';
const root='app/src/main/assets/www/';
const source=path=>fs.readFileSync(root+path,'utf8');
const c={window:{}};c.window=c;vm.createContext(c);
vm.runInContext(source('pricing/price-authority.js'),c);
vm.runInContext(source('lookup/item-record-mapper.js'),c);
const fields={'ACE SKU':'3552056','Description':'DIG OPTI TOSLINK CABLE 3','UPC/EAN':'741835105712','Ace Retail Price':'11.99','Level 2 Retail Price':'13.99'};
const map=c.UPCItemRecordMapper.create({normalizeUpc:x=>String(x)});
const master=map.itemFromLibraryRow({id:1,skuKey:'3552056',originalUPC:'741835105712',fields},{librarySource:'MASTER_LIBRARY'});
assert.equal(master.price,'13.99','master lookup MUST use Level 2, not Ace Retail');
assert.equal(c.UPCPriceAuthority.observedPrice(master),13.99);
const matched={...master,libraryPrice:11.99,labelPrice:13.99,priceDifference:2,tags:['Price Change']};
assert.equal(c.UPCPriceAuthority.observedPrice(matched),13.99,'old saved list price must re-evaluate stored Level 2 evidence');
assert.equal(c.UPCPriceAuthority.observedAceNetPrice({...matched,aceNetPrice:11.99,aceNetPriceStatus:'VERIFIED'}),null,'v3.02 VERIFIED flag alone cannot authenticate former Ace Retail comparison');
assert.equal(c.UPCPriceAuthority.observedAceNetPrice({...matched,aceNetPrice:11.99,aceNetPriceAuthority:'ACE_RETAIL'}),null,'Ace Retail provenance must be rejected even when numeric');
assert.equal(c.UPCPriceAuthority.observedAceNetPrice({...matched,aceNetPrice:13.99,aceNetPriceAuthority:'LEVEL2_STORE_RETAIL'}),13.99,'corrected live Store Retail can be displayed');
assert.equal(c.UPCPriceAuthority.observedPrice({...matched,aceNetPrice:14.99,aceNetPriceAuthority:'LEVEL2_STORE_RETAIL'}),14.99,'verified live Level 2 must outrank older Master Level 2 even when both exist');
assert.equal(c.UPCPriceAuthority.observedPrice({...matched,aceNetPrice:11.99,aceNetPriceAuthority:'ACE_RETAIL'}),13.99,'unverified corporate price must never override Master Level 2');
assert.equal(c.UPCPriceAuthority.observedPrice({...matched,fields:{'Ace Retail Price':'11.99'},aceNetPrice:14.99,aceNetPriceAuthority:'LEVEL2_STORE_RETAIL'}),14.99,'verified live Level 2 works even when Master Level 2 is absent');
assert.equal(c.UPCPriceAuthority.observedPrice({...matched,recordOrigin:'THIRD_PARTY_VENDOR',aceNetPrice:14.99,aceNetPriceAuthority:'LEVEL2_STORE_RETAIL'}),11.99,'live AceNet Level 2 must not override independent vendor catalog authority');
assert.equal(c.UPCPriceAuthority.observedAceNetPrice({...matched,aceNetPrice:null,aceNetPriceAuthority:'LEVEL2_STORE_RETAIL'}),null,'a provenance marker without numeric evidence cannot invent a price');
assert.ok(source('lookup/normal-lookup-controller.js').includes('pending.aceNetPriceAuthority=UPCPriceAuthority.VERIFIED_ACENET_SOURCE'),'new verified exact-SKU requests must mark Store Retail provenance');
assert.ok(source('work-sessions/list-item-controller.js').includes('UPCPriceAuthority.observedAceNetPrice(x)'),'saved rows must not display historical unverified AceNet values');
assert.match(source('work-sessions/list-item-controller.js'),/thirdParty\?parseMoney\(x\.aceNetPrice\):UPCPriceAuthority\.observedAceNetPrice\(x\)/,'vendor price display must remain independent');
assert.equal(matched.labelPrice-c.UPCPriceAuthority.observedPrice(matched),0,'old false Price Change displays a zero difference without destructive deletion');
assert.equal(map.itemFromLibraryRow({...master,fields:{'Ace Retail Price':'11.99'}},{librarySource:'MASTER_LIBRARY'}).price,null,'never fallback when Level 2 absent');
assert.equal(c.UPCPriceAuthority.observedPrice({libraryPrice:11.99,labelPrice:13.99,recordOrigin:'ACE_DERIVED'}),null,'unsafe old saved Ace Retail reference must be unavailable');
assert.equal(map.itemFromLibraryRow({skuKey:'3552056',fields:{'Ace Retail Price':'11.99','Level 2 Retail Price':'13.99'},localOrigin:'ACE_DERIVED'},{librarySource:'LOCAL_LIBRARY'}).price,'13.99');
assert.equal(map.itemFromLibraryRow({skuKey:'EXAMPLE',fields:{'Ace Retail Price':'11.99'},localOrigin:'THIRD_PARTY_VENDOR'},{librarySource:'LOCAL_LIBRARY'}).price,'11.99','vendor price unaffected');
assert.equal(c.UPCPriceAuthority.level2({'LEVEL 2 RETAIL PRICE':'$13.99'}),'13.99','case insensitive and formatted');
assert.equal(c.UPCPriceAuthority.level2({'Level 2 Retail Price':'not a price'}),null,'invalid L2 cannot be treated as numeric');
assert.ok(source('field-session/field-session-export-service.js').includes('UPCPriceAuthority.observedPrice(item)'),'workflow XLSX needs authoritative Level 2 observation');
assert.ok(source('work-sessions/list-item-controller.js').includes('UPCPriceAuthority.observedPrice(x)'),'saved list must display authoritative Level 2');
assert.ok(source('field-session/register-price-controller.js').includes('UPCPriceAuthority.observedPrice(item)'),'register review must display authoritative Level 2');
assert.match(source('ace-misc.js'),/base\[16\]=firstNonblank\(base\[16\]/,'ACE MISC Ace Retail column must retain its own evidence');
const worker=fs.readFileSync('app/src/main/java/com/rmtb/upclistbuilder/PersistentAceNetWorker.kt','utf8');
assert.ok(worker.includes("remember('level2RetailPrice',price(),numeric)"),'native full catalog must preserve Store Retail separately');
assert.ok(worker.includes("remember('aceRetailPrice',acePrice(),numeric)"),'native full catalog must preserve Ace Retail separately');
assert.ok(source('db.js').includes('level2RetailPrice:money(c.level2RetailPrice)'),'Local must persist Level 2 where supported');
const script=extractPersistentWorkerScript({expected:'3552056',mode:'PRODUCTION_PRICE'});
const skuId='ctl00_ctl00_contentMainPlaceHolder_MainContent_headerSkuDataBar_lblSkuNr';
function extract({ace,store}){
 const out=[],diagnostics=[],elements={[skuId]:{textContent:'3552056'}};
 if(ace!==undefined)elements.divStrL1L2={getAttribute:()=>`$${ace}`,textContent:`$${ace}`};
 if(store!==undefined)elements.lblHeaderSellingDataStoreRetail={getAttribute:n=>n==='data-storeretail'?`$${store}`:'',textContent:`$${store}`};
 class MutationObserver{observe(){}disconnect(){}}
 const document={readyState:'complete',title:'',body:{innerText:''},scripts:[],documentElement:{outerHTML:'<html></html>'},location:{href:'https://retailer.aceservices.com/'},getElementById:id=>elements[id]||null,querySelector:()=>null,querySelectorAll:()=>[]};
 const ctx={document,MutationObserver,PersistentAceNetBridge:makeWorkerBridge({diagnostics,results:out}),JSON,Array,String,RegExp};ctx.window=ctx;
 vm.runInNewContext(script,ctx);return out;
}
assert.equal(extract({ace:'11.99',store:'13.99'})[0]?.price,'13.99','live UPC/SKU comparison ignores conflicting Ace Retail');
assert.equal(extract({ace:'11.99'}).length,0,'live result must not silently fall back to Ace Retail');

// Actual lookup presentation must share the pricing authority with automatic
// Price Change capture, including late exact-SKU AceNet Level 2 arrivals.
vm.runInContext(source('lookup/item-presentation-controller.js'),c);
const ui=new Map();
function element(id){
 if(!ui.has(id))ui.set(id,{textContent:'',value:'',disabled:false,className:'',src:'',alt:'',classList:{add(){},remove(){},toggle(){},contains(){return false}},removeAttribute(){},setAttribute(){}});
 return ui.get(id);
}
const presentation=c.UPCItemPresentationController.create({
 elementById:element,setText:(id,text)=>{element(id).textContent=String(text)},
 subsystemOperationStart(){},subsystemOperationFinish(){},diagnostic(){},
 releaseNotFoundSystemPurpose(){},applyNotFoundSystemPurpose(){},configureTags(){},applyDefaultTagSelection(){},
 syncManualPriceVisibility(){},productImageService:{lookupProductImage:async()=>null},
 parseMoney:x=>x==null||String(x).trim()===''?null:Number(String(x).replace(/[$,]/g,'')),
 comparisonEnabled:()=>true,barcodePlanner:()=>({ok:false})
});
element('labelPrice').value='13.99';
const oldSaved={...master,libraryPrice:11.99,aceNetPrice:11.99,aceNetPriceStatus:'VERIFIED'};
presentation.renderPreview(oldSaved);
assert.equal(element('previewPrice').textContent,'$13.99','primary lookup price must use Level 2, not historical Ace Retail');
assert.equal(element('libraryPriceCompare').textContent,'$13.99','offline Library row must use Master Level 2');
assert.equal(element('aceNetPriceCompare').textContent,'—','unverified historical Ace Retail must not be shown as live Level 2');
assert.equal(element('priceDifference').textContent,'+0.00','matching physical label must have zero displayed price difference');
assert.equal(element('libraryPriceLabel').textContent,'Library Level 2 Retail');
assert.equal(element('aceNetPriceLabel').textContent,'AceNet Level 2 Retail');
oldSaved.aceNetPrice=14.99;
oldSaved.aceNetPriceAuthority='LEVEL2_STORE_RETAIL';
presentation.setAceNetPresentedPrice('14.99');
assert.equal(element('previewPrice').textContent,'$14.99','verified live Level 2 must refresh the primary displayed price');
assert.equal(element('libraryPriceCompare').textContent,'$13.99','live comparison must not rewrite independent Master Level 2');
assert.equal(element('aceNetPriceCompare').textContent,'$14.99','verified live Store Retail must appear under AceNet Level 2');
assert.equal(element('priceDifference').textContent,'−1.00','live Level 2 must immediately refresh visible label comparison');
presentation.renderPreview({...master,price:11.99,fields:{'Ace Retail Price':'11.99'},aceNetPrice:11.99});
assert.equal(element('previewPrice').textContent,'—','missing Level 2 must not display cheaper corporate Ace Retail');
assert.equal(element('libraryPriceCompare').textContent,'—','missing offline Level 2 must remain unavailable');
assert.equal(element('priceDifference').textContent,'—','no apparent price difference may be fabricated without Level 2 evidence');
const vendor=map.itemFromLibraryRow({skuKey:'LOCAL123',fields:{'Ace Retail Price':'12.45'},localOrigin:'THIRD_PARTY_VENDOR'},{librarySource:'LOCAL_LIBRARY'});
presentation.renderPreview(vendor);
assert.equal(element('libraryPriceLabel').textContent,'Vendor Library Price','third-party vendor source must not masquerade as Level 2');
assert.equal(element('aceNetPriceLabel').textContent,'Vendor Price','vendor source label must remain accurate');
assert.equal(element('aceNetPriceCompare').textContent,'$12.45','third-party vendor value must remain visible');

console.log('Level 2 Retail source authority and regression guard PASS');
