import {readWebRuntimeSource} from './helpers/runtime-source-tree.mjs';
import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';

const source=fs.readFileSync('app/src/main/assets/www/local-identifier-resolver.js','utf8');
const app=readWebRuntimeSource();
const html=fs.readFileSync('app/src/main/assets/www/index.html','utf8');
const stripOwnership=source=>source.replace(/^\/\*\*?[\s\S]*?\*\/\s*/,'');
const sourceBody=stripOwnership(source);

assert.doesNotMatch(sourceBody,/AceNet|AndroidNative|fetch\s*\(|document\.|\.put\s*\(|recordRelationship|recordVerifiedSkuUpcs/,'Local Identifier Resolver must be read-only and network-free.');
assert.match(source,/UPCEffectiveCatalogResolver/);assert.match(source,/UPCIdentifierRelationshipService/);

function build({direct={status:'NOT_FOUND',row:null,lookupMode:'MASTER_LOCAL_UPC_MISS'},relationship={status:'UNKNOWN',sku:null,candidateSkuKeys:[]},skuResults={}}={}){
 const calls=[];
 const effective={
  resolveDirectUPC:async(upc,options)=>{calls.push(['direct',upc,options?.format||null]);return direct},
  resolveSKU:async sku=>{calls.push(['sku',sku]);return skuResults[sku]||{status:'NOT_FOUND',row:null,lookupMode:'MASTER_LOCAL_SKU_MISS'}}
 };
 const relationships={resolveUPC:async upc=>{calls.push(['relationship',upc]);return relationship}};
 const context={window:{},UPCEffectiveCatalogResolver:effective,UPCIdentifierRelationshipService:relationships,UPCIdentifierNormalization:{normalizeSKU:v=>String(v??'').trim().toLowerCase(),normalizeUPC:v=>String(v??'').replace(/\D/g,'')}};
 vm.createContext(context);vm.runInContext(source,context,{filename:'local-identifier-resolver.js'});
 return{resolver:context.window.UPCLocalIdentifierResolver,calls};
}
const master=id=>({status:'FOUND',row:{id,skuKey:id,source:'MASTER'},lookupMode:'SKU_EXACT',provenance:'MASTER_LIBRARY',masterRecordId:id,activeMasterRecordId:id,localRecordId:null});
const local=id=>({status:'FOUND',row:{id,skuKey:id,source:'LOCAL_ADDITION'},lookupMode:'LOCAL_SKU_EXACT',provenance:'LOCAL_LIBRARY',masterRecordId:null,activeMasterRecordId:null,localRecordId:id});

{
 const direct=master('a'),{resolver}=build({direct});const r=await resolver.resolveUPC('111');assert.equal(r.status,'FOUND');assert.equal(r.source,'DIRECT_CATALOG');assert.equal(r.catalog.row.id,'a');
}
{
 const related=local('b'),{resolver}=build({relationship:{status:'KNOWN',sku:'b',candidateSkuKeys:['b']},skuResults:{b:related}});
 const r=await resolver.resolveUPC('222');assert.equal(r.status,'FOUND');assert.equal(r.source,'RELATIONSHIP');assert.equal(r.sku,'b');assert.equal(r.catalog.row.id,'b');
}
{
 const direct=master('a'),{resolver}=build({direct,relationship:{status:'KNOWN',sku:'a',candidateSkuKeys:['a']},skuResults:{a:direct}});
 const r=await resolver.resolveUPC('333');assert.equal(r.status,'FOUND');assert.equal(r.source,'DIRECT_CATALOG_AND_RELATIONSHIP');
}
{
 const direct=master('a'),other=master('b'),{resolver}=build({direct,relationship:{status:'KNOWN',sku:'b',candidateSkuKeys:['b']},skuResults:{b:other}});
 const r=await resolver.resolveUPC('444');assert.equal(r.status,'CONFLICT');assert.equal(r.reason,'DIRECT_CATALOG_DISAGREES_WITH_RELATIONSHIP');
}
{
 const direct=master('a'),{resolver}=build({direct,relationship:{status:'CONFLICT',sku:null,candidateSkuKeys:['a','b']}});
 const r=await resolver.resolveUPC('555');assert.equal(r.status,'CONFLICT');assert.equal(r.reason,'RELATIONSHIP_CONFLICT');
}
{
 const {resolver}=build({direct:{status:'AMBIGUOUS',row:null,lookupMode:'EXACT',matches:2},relationship:{status:'KNOWN',sku:'a',candidateSkuKeys:['a']}});
 const r=await resolver.resolveUPC('666');assert.equal(r.status,'AMBIGUOUS');assert.equal(r.reason,'DIRECT_CATALOG_AMBIGUOUS');
}
{
 const {resolver}=build({relationship:{status:'KNOWN',sku:'missing',candidateSkuKeys:['missing']}});
 const r=await resolver.resolveUPC('777');assert.equal(r.status,'SKU_NOT_FOUND');assert.equal(r.sku,'missing');
}
{
 const {resolver}=build();const r=await resolver.resolveUPC('888');assert.equal(r.status,'UNKNOWN');
}

assert.match(app,/UPCLocalIdentifierResolver\.resolveUPC\(digits,\{format\}\)/,'Normal UPC lookup must use Local Identifier Resolver.');
assert.match(app,/UPCLocalIdentifierResolver\.resolveSKU\(key\)/,'Normal SKU lookup must use Local Identifier Resolver.');
assert.doesNotMatch(app,/resolveUpcThroughIdentityIndex/,'Legacy workflow identity-index resolver must be retired.');
assert.match(app,/ACE_MISC_MANUAL_UPC_RELATIONSHIP/,'ACE MISC manual UPC must be able to continue by a saved secondary relationship SKU.');
const serviceLoad=html.indexOf('identifier-relationship-service.js'),effectiveLoad=html.indexOf('effective-catalog-resolver.js'),localLoad=html.indexOf('local-identifier-resolver.js'),miscLoad=html.indexOf('ace-misc.js'),appLoad=html.indexOf('app.v059.js');
assert.ok(serviceLoad>=0&&effectiveLoad>=0&&localLoad>serviceLoad&&localLoad>effectiveLoad&&localLoad<miscLoad&&localLoad<appLoad,'Local Identifier Resolver must load after both dependencies and before workflow consumers.');

console.log('Stage 4 Local Identifier Resolver semantic requirements PASS');
