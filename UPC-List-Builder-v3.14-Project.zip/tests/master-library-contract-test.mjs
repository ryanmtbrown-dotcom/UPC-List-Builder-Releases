import fs from 'node:fs';
import assert from 'node:assert/strict';
import {readWebRuntimeSource,findJsFunction} from './helpers/runtime-source-tree.mjs';

const web=readWebRuntimeSource();
const db=fs.readFileSync('app/src/main/assets/www/db.js','utf8');
const workflow=fs.readFileSync('app/src/main/assets/www/library-workflow-v093.js','utf8');
const contract=fs.readFileSync('MASTER_LIBRARY_CONTRACT.md','utf8');
assert.match(contract,/Master Library/);

function extract(name){return findJsFunction(name)}

// Generation-scoped unique lookup primitives remain authoritative.
const exact=extract('lookupUniqueExact');
assert.match(exact,/meta\.generation/);assert.match(exact,/generationUPC/);assert.match(exact,/r\.result\.length===1\?r\.result\[0\]:null/);
const prefix=extract('lookupUniquePrefix');
assert.match(prefix,/meta\.generation/);assert.match(prefix,/rows\.length===1\?rows\[0\]:null/);assert.match(prefix,/rows\.length>=2/);
const sku=extract('lookupUniqueSKU');
assert.match(sku,/normalizeSKU\(key\)/);assert.match(sku,/generationSKU/);assert.match(sku,/indexed\.length===1\?indexed\[0\]:null/);assert.doesNotMatch(sku,/fallback/,'Stage 9 no longer needs legacy unmapped-SKU fallback scanning.');
const active=extract('getActiveLibraryRecords');
assert.match(active,/c\.value\.generation===meta\.generation/);

// Stage 7's narrow canonical UPC correction remains; obsolete broad Master writers are retired.
const masterUpcWrite=extract('updateActiveLibraryMasterUpc');
for(const guard of [/No active Master Library/,/SKU and verified Master UPC are required/,/generationMatches/,/skuMatches/,/t\.abort\(\)/])assert.match(masterUpcWrite,guard);
assert.match(masterUpcWrite,/generationUPC/,'Canonical UPC correction must collision-check the active Master generation.');
assert.match(masterUpcWrite,/upcKey:nextUpc/);assert.match(masterUpcWrite,/originalUPC:nextUpc/);assert.match(masterUpcWrite,/fields,aceNetMasterUpcVerifiedAt/);
assert.doesNotMatch(db,/async function updateActiveLibraryPrice\(/,'Stage 9 must retire the obsolete direct Master price writer.');
assert.doesNotMatch(db,/async function updateActiveLibraryAceNetFields\(/,'Stage 9 must retire the obsolete broad Master AceNet writer.');
assert.doesNotMatch(db,/repairV149AceNetWeight|repairV153NullCostOverwrite|repairV155MasterPriceContamination|repairLegacySkuMapping/,'Historical runtime repair functions must be retired.');

// Reindex keeps the active generation while changing only lookup mapping/index keys.
const reindex=extract('reindexActiveLibrary');
assert.match(reindex,/const db=await open\(\),generation=meta\.generation/);assert.match(reindex,/meta\.upcHeader=upcHeader/);assert.match(reindex,/meta\.skuHeader=skuHeader/);assert.doesNotMatch(reindex,/crypto\.randomUUID/);

// Replacement staging strips previous primary keys/generation ownership.
const stageLibrary=extract('stageLibrary');
assert.match(stageLibrary,/const \{id:_oldId,generation:_oldGeneration,\.\.\.source\}=x\|\|\{\}/);
assert.match(stageLibrary,/t\.onabort=.*Master Library staging transaction aborted/);

// Import is official-Master-only. Local remains durable and separate.
const save=extract('saveMapping');
const stageAt=save.indexOf('UPCMasterRepository.stageGeneration(parsed.records');
const metaAt=save.indexOf('await UPCMasterRepository.saveMetadata(meta)');
const activeProofAt=save.indexOf('persistedMeta?.generation!==generation');
const cleanupAt=save.indexOf('UPCMasterRepository.cleanupGenerations(generation)');
assert.ok(stageAt>=0&&metaAt>stageAt&&activeProofAt>metaAt&&cleanupAt>activeProofAt,'Import must stage -> activate metadata -> verify -> cleanup.');
assert.match(save,/Local Library remained separate|Local Library record\(s\) remain separate/);
assert.doesNotMatch(save,/Apply Local Library|mergeLocalAdditions|localGeneration/,'Master import must not copy Local rows into Master.');

// Current Add-to-Library path persists durable Local records only.
const stagedLocal=extract('stageLocalLibraryAceNetItem');
assert.match(stagedLocal,/meta','localLibraryAdditions'/);assert.doesNotMatch(stagedLocal,/put\('library'/);
assert.doesNotMatch(workflow,/function pushLocalLibraryToMaster\(/,'Stage 9 must remove manual Local-to-Master promotion.');
assert.doesNotMatch(workflow,/function importCompleted\(/,'Stage 9 must remove the stranded completed-shadow import workflow.');
assert.doesNotMatch(workflow,/pendingLibraryAdditions|manualLibraryOverlay|masterPromotion|lastLocalLibraryPushAt/,'Retired shadow/promotion state must not remain in runtime workflow code.');
assert.doesNotMatch(db,/reconcilePromotedLocalLibraryRecord|restoreMissingPromotedLocalLibraryRecords|reconcileAllPromotedLocalLibraryRecords/,'Promoted-Master repair machinery must be absent.');

// Master workflow keeps human-readable operation evidence.
for(const token of ['masterLibraryOperationStart(','masterLibraryOperationObserve(','masterLibraryOperationFinish(','whatWeAreDoing','expectedResult','actualResult','durationMs','previousGeneration','activeGeneration'])assert.ok(workflow.includes(token),`Missing Master Library diagnostic requirement ${token}`);
assert.match(workflow,/Master Library import failed before activation/);

console.log('Stage 9 Master Library official-only + durable Local separation requirements PASS');
