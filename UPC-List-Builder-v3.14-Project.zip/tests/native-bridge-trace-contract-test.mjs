import {readNativeRuntimeSource} from './helpers/runtime-source-tree.mjs';
import fs from 'node:fs';
import assert from 'node:assert/strict';

const k=fs.readFileSync('app/src/main/java/com/rmtb/upclistbuilder/MainActivity.kt','utf8');
const session=fs.readFileSync('app/src/main/java/com/rmtb/upclistbuilder/AceNetSessionManager.kt','utf8');
const native=readNativeRuntimeSource();
const bridge=fs.readFileSync('app/src/main/assets/www/platform/bridge-registration.js','utf8');
const aceStartup=fs.readFileSync('app/src/main/assets/www/application/acenet-startup-service.js','utf8');

assert.match(k,/addJavascriptInterface\(NativeBridge\(\), "AndroidNative"\)/);
assert.match(k,/allowFileAccess = false/);
assert.match(k,/allowContentAccess = false/);
assert.match(session,/AndroidKeyStore/,'Stage 6 session manager must retain Android Keystore credential protection');
assert.match(session,/KeyProperties\.BLOCK_MODE_GCM/);
assert.match(session,/AES\/GCM\/NoPadding/);
assert.doesNotMatch(k,/AndroidKeyStore|KeyProperties\.BLOCK_MODE_GCM|AES\/GCM\/NoPadding/,'MainActivity must not reclaim credential crypto ownership');
assert.match(native,/@JavascriptInterface fun openScanner/);
assert.match(native,/@JavascriptInterface fun lookupAceNetPrice/);
assert.match(native,/@JavascriptInterface fun lookupAceNetUpcs/);
assert.match(native,/aceNetNativeDiagnostic/);
assert.match(native,/@JavascriptInterface fun reportRuntimeProbe/);
assert.match(native,/app_runtime_asset_probe/);
assert.match(bridge,/UPCNativeAceNetStartupStatus:raw=>aceNetStartupService\.acceptNativeStartupStatus\(raw\)/);
assert.match(bridge,/UPCNativeAceNetHealthStatus:raw=>aceNetStartupService\.acceptNativeHealthStatus\(raw\)/);
assert.match(aceStartup,/acceptNativeStartupStatus/);
assert.match(aceStartup,/acceptNativeHealthStatus/);
assert.match(native,/\.put\("startupResolved",aceNetStartupResolved\)/);
assert.doesNotMatch(aceStartup,/acenet-startup-resolved/);
assert.match(k,/LOAD_NO_CACHE/);
assert.doesNotMatch(native,/AceNetUpcRouteLab|startAceNetUpcRouteLab|cancelAceNetUpcRouteLab/);

const suspicious=[/diag[^\n]{0,120}password/i,/aceNetNativeDiagnostic\([^\n]{0,120}password/i];
for(const re of suspicious)assert.doesNotMatch(native,re);
console.log('Native bridge/trace + Stage 6 credential-owner requirements PASS; deprecated laboratory absent');
