import {readWebRuntimeSource,findJsFunction} from './helpers/runtime-source-tree.mjs';
import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';

const source=readWebRuntimeSource();
const aceClient=fs.readFileSync('app/src/main/assets/www/acenet-client.js','utf8');
const priceService=fs.readFileSync('app/src/main/assets/www/lookup/acenet-price-service.js','utf8');
const appShell=fs.readFileSync('app/src/main/assets/www/application/application-shell.js','utf8');
const contract=fs.readFileSync('NORMAL_ITEM_SEARCH_CONTRACT.md','utf8');
assert.match(contract,/## Deferred UPC enrichment/,'current Normal Item Search UPC-enrichment authority missing.');

function extract(name,next){
 const start=source.indexOf(name);assert.ok(start>=0,`Missing ${name}`);
 const end=source.indexOf(next,start);assert.ok(end>start,`Missing boundary after ${name}`);
 return source.slice(start,end);
}

// Normal Search delegates local identity reconciliation to Local Identifier Resolver; Effective Catalog remains beneath that owner for direct catalog selection.
const lookupItemSrc=findJsFunction('lookupItem');
assert.match(lookupItemSrc,/UPCLocalIdentifierResolver\.resolveUPC\(digits,\{format\}\)/,'UPC lookup must delegate local catalog plus relationship reconciliation.');
assert.doesNotMatch(lookupItemSrc,/UPCMasterRepository\.|UPCLocalRepository\.|UPCIdentityRepository\./,'Normal UPC lookup must not reimplement repository or identity-index routing.');
assert.match(lookupItemSrc,/observation\.type==='EAN13_TO_UPCA'/,'EAN-13 fallback diagnostics must remain caller-owned.');
assert.match(lookupItemSrc,/resolved\.status==='AMBIGUOUS'/,'Normal UPC lookup must preserve explicit ambiguity.');

const skuSrc=findJsFunction('lookupItemBySku');
assert.match(skuSrc,/UPCLocalIdentifierResolver\.resolveSKU\(key\)/,'SKU lookup must delegate through the Local Identifier Resolver.');
assert.doesNotMatch(skuSrc,/UPCMasterRepository\.|UPCLocalRepository\.|UPCIdentityRepository\./,'Normal SKU lookup must not reimplement repository or identity-index routing.');
assert.doesNotMatch(skuSrc,/PROMOTED_MASTER_LOCAL_CHECK|LOCAL_LIBRARY_PROMOTED/,'Stage 9 must remove promoted-Local compatibility diagnostics from normal SKU lookup.');
assert.match(skuSrc,/local\.status==='AMBIGUOUS'/,'Normal SKU lookup must preserve explicit ambiguity from Local Identifier Resolver.');

// Authoritative AceNet price parsing remains strict and positive-only.
{
 let configured=null;
 const context={window:{},Number,String,Boolean,Promise,Object};
 vm.createContext(context);vm.runInContext(priceService,context,{filename:'acenet-price-service.js'});
 const api=context.window.UPCAceNetPriceService.create({
  client:{configure:options=>{configured=options},requestPrice:async()=>({status:'UNAVAILABLE'})},
  normalizeSku:v=>String(v??'').trim(),normalizeUpc:v=>String(v??'').replace(/\D/g,''),
  normalizeHealthStatus:v=>String(v??'').toUpperCase(),getRuntimeState:()=>({healthStatus:'ONLINE'}),diagnostic:()=>{},bridgeProvider:()=>null
 });
 assert.ok(configured&&typeof configured.parsePrice==='function','focused price owner must configure the broker with its strict parser');
 assert.equal(api.parseVerifiedPrice('$12.34'),12.34);
 assert.equal(api.parseVerifiedPrice('12.34'),12.34);
 assert.equal(api.parseVerifiedPrice('0.00'),null);
 assert.equal(api.parseVerifiedPrice('TIMEOUT'),null);
}

// v2.57 behavior remains, with broker/configuration owned by the focused AceNet Price Service.
assert.match(appShell,/UPCAceNetPriceService\.create\(/,'application composition must construct the focused AceNet price owner.');
assert.match(priceService,/client\.configure\(/,'focused AceNet price owner must configure the shared broker once.');
assert.match(priceService,/health==='DOWN'\|\|health==='UNAVAILABLE'/,'known-unavailable health must skip native dispatch before broker invocation.');
assert.match(priceService,/client\.requestPrice\(expectedSku,\{upcEnrichment:Boolean\(upcEnrichment\)\}\)/,'normal price request must delegate to the shared broker.');
assert.match(aceClient,/productionBrokerTimeout/,'Broker must derive production ownership from the native incident policy.');
assert.match(aceClient,/getAceNetProductionBrokerTimeoutMs/,'Installed runtime must read the native broker timeout.');
const enrichSrc=findJsFunction('enrichPresentedItemWithAceNetPrice');
assert.match(enrichSrc,/priceService\.requestPrice\(sku,\{upcEnrichment:false\}\)/,'Visible price must use price-only retrieval.');
assert.ok(enrichSrc.indexOf('setAceNetPresentedPrice(value)')<enrichSrc.indexOf('void enrichAceNetUpcsAfterPrice'),'Verified price must be presented before UPC enrichment starts.');
const upcEnrichSrc=findJsFunction('enrichAceNetUpcsAfterPrice');
assert.match(upcEnrichSrc,/relationshipSource:'ACENET_NORMAL_ENRICHMENT'/,'Deferred UPC enrichment must retain Stage 7 identity reconciliation.');
const missingSkuSrc=findJsFunction('resolveMissingSkuThroughAceNet');
assert.match(missingSkuSrc,/requestAceNetCatalog\(requestedSku\)/,'Master+Local miss must request the full AceNet catalog, not price-only evidence.');
assert.match(missingSkuSrc,/persistVerifiedAceNetCatalogToLocalLibrary/,'Verified full catalog must be persisted before success is returned.');
assert.match(missingSkuSrc,/lookupItemBySku\(canonicalSku\)/,'Persisted item must be re-read through normal Master/Local authority before success.');
assert.match(missingSkuSrc,/NOT_IN_MASTER_LOCAL_OR_ACENET/,'Conclusive absence must distinguish both local authorities from AceNet.');
assert.doesNotMatch(missingSkuSrc,/enqueueLibraryUpdate|createActiveLibraryAceNetItem|requestAceNetPrice/,'New AceNet-only success must not use the old deferred price-only queue/direct-write path.');
assert.match(source,/async function persistVerifiedAceNetCatalogToLocalLibrary/);
assert.match(source,/local_library_catalog_persist_verified/,'Full persistence must emit read-back verification diagnostics.');

// Retail Units is library/default enrichment, never an AceNet search input.
const ruSrc=findJsFunction('resolveAceNetRetailUnits');
assert.match(ruSrc,/effectiveResolver\.inspectSKU\(key\)/,'Retail Units must obtain Master/Local evidence through Effective Catalog.');
assert.doesNotMatch(ruSrc,/UPCMasterRepository\.|UPCLocalRepository\./,'Retail Units must not bypass Effective Catalog for local catalog reads.');
assert.match(ruSrc,/source:'DEFAULT_NO_LIBRARY_RU'/);
assert.doesNotMatch(ruSrc,/lookupAceNetPrice|requestPrice\(/,'Retail Units must not trigger an AceNet search.');

// v2.18 progressive presentation and supersession are required around the real normal lookup.
const performSrc=findJsFunction('performNormalLookup');
for(const required of ['lookupOperationStart(','lookupOperationFinish(','lookup_library_presented_immediately']) assert.ok(source.includes(required),`Missing diagnostic lifecycle requirement ${required}`);
assert.match(performSrc,/itemPresentationController\.isCurrent\((?:presentationGeneration|generation)\)/,'Older lookup must not overwrite a newer lookup presentation.');
assert.match(performSrc,/result\.priceSource=result\.priceSource\|\|'MASTER_LIBRARY'/,'Master Library remains the default truthful price source without overwriting Local source.');assert.match(performSrc,/refreshLocalLibraryLookupInBackground/,'Found Local items must use durable full-catalog refresh rather than Master price mutation.');
assert.match(performSrc,/void enrichPresentedItemWithAceNetPrice/,'AceNet price must enrich in the background without blocking Library presentation.');
assert.match(performSrc,/aceNetBackground:/,'Terminal lifecycle must disclose whether background AceNet enrichment was launched.');
assert.match(performSrc,/libraryMs:/);assert.match(performSrc,/totalToPresentationMs:/);

console.log('Current Normal Item Search progressive-contract requirements PASS');
