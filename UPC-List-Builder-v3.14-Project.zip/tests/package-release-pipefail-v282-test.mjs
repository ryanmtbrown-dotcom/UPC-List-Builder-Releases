import fs from 'node:fs';
import assert from 'node:assert/strict';

const pkg=fs.readFileSync('package-release.sh','utf8');
assert.match(pkg,/mapfile -t ZIP_ENTRIES/,'final ZIP entries must be captured before membership checks');
assert.match(pkg,/for f in "\$\{required\[@\]\}"; do/,'required-entry audit loop missing');
assert.match(pkg,/for entry in "\$\{ZIP_ENTRIES\[@\]\}"; do/,'captured ZIP entries must be compared directly');
assert.match(pkg,/\[\[ "\$entry" == "\$f" \]\]/,'required-entry comparison must use direct shell equality');
assert.doesNotMatch(pkg,/printf[^\n]*ZIP_ENTRIES[^\n]*\|[^\n]*grep[^\n]*-q/,'pipefail-unsafe early-closing required-entry pipeline must remain absent');
assert.doesNotMatch(pkg,/printf[^\n]*ZIP_ENTRIES[^\n]*\|[^\n]*grep[^\n]*\.git/,'pipefail-unsafe forbidden-entry pipeline must remain absent');
assert.match(pkg,/false "missing entry" failure/,'source must document why direct membership is required');
assert.ok(pkg.includes("'./release-out/*'"),'Final source ZIP must exclude previously generated signed APKs and update metadata');
console.log('Final ZIP archive membership pipefail guard v2.82 PASS');

