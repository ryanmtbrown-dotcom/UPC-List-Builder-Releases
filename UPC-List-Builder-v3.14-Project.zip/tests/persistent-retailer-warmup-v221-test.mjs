import {readWebRuntimeSource,readNativeRuntimeSource} from './helpers/runtime-source-tree.mjs';
import fs from 'node:fs';
import assert from 'node:assert/strict';

const main=readNativeRuntimeSource();
const service=fs.readFileSync('app/src/main/java/com/rmtb/upclistbuilder/AceNetRetrievalService.kt','utf8');
const worker=fs.readFileSync('app/src/main/java/com/rmtb/upclistbuilder/PersistentAceNetWorker.kt','utf8');
const web=readWebRuntimeSource();
const retrieval=fs.readFileSync('ACENET_ITEM_RETRIEVAL_CONTRACT.md','utf8');
const diagnostics=fs.readFileSync('DIAGNOSTICS_CONTRACT.md','utf8');
const trace=fs.readFileSync('NATIVE_TRACE_CONTRACT.md','utf8');

assert.match(main,/aceNetWarmupSku = "50177"/);
assert.match(main,/aceNetRequestKind="STARTUP_WARMUP"/);
assert.match(main,/startup_retailer_session_ready/);
assert.match(main,/val template=aceNetPersistentRetailerTemplate/);
assert.match(main,/startAceNetStartupPersistentVerification\(template,1\)/);
assert.match(main,/persistent_worker_fast_path_selected/);
assert.match(main,/persistent_worker_recovery_selected/);
assert.match(main,/production_soft_repair_started/);
assert.match(main,/production_hard_repair_selected/);
assert.match(main,/production_session_repair_redispatched/);
assert.match(main,/persistent_worker_retained_for_background/);
assert.match(service,/class AceNetRetrievalService/);
assert.match(service,/PersistentAceNetWorker\(activity, emit, complete\)/);
assert.match(service,/fun prime\(template: String, sku: String, timeoutMs: Long = AceNetTimingPolicy\.ITEM_ATTEMPT_MS, callback:/);

assert.match(worker,/class PersistentAceNetWorker/);
assert.match(worker,/fun isBusy\(\): Boolean/);
assert.doesNotMatch(worker,/PARALLEL_2|PARALLEL_3|maxWorkers/);
assert.match(worker,/if\(s!==\$expected\).*SKU_MISMATCH/s);
assert.match(worker,/if\(\$mode==='PRODUCTION_PRICE'\).*price\(\)/s);
assert.match(worker,/getElementById\('ctl00_ctl00_contentMainPlaceHolder_MainContent_mainItemData_lvAceItemDetails_ctrl0_ddlUPC'\)/);
for(const marker of [
  'persistent_worker_main_frame_navigation','persistent_worker_page_started','persistent_worker_page_finished',
  'persistent_worker_main_frame_network_error','persistent_worker_main_frame_http_error','persistent_worker_console_message',
  'persistent_worker_page_forensics','persistent_worker_dom_state','persistent_worker_inspection_script_callback',
  'persistent_worker_sku_evidence_still_pending','persistent_worker_structure_probe'
]) assert.ok(worker.includes(marker),'missing retained-worker forensic marker: '+marker);
assert.match(worker,/cookieValuesRedacted",true/);
assert.match(worker,/valuesRedacted",true/);
assert.match(worker,/sanitizedHtml:fullHtml\.slice\(0,40000\)/);
assert.match(worker,/pricePresent:pricePresent/);
assert.doesNotMatch(worker,/persistent_worker_dom_state[^]*\.put\("price"/);
assert.match(worker,/AceNetTimingPolicy\.STRUCTURE_INSPECTION_MS/);
assert.match(worker,/AceNetTimingPolicy\.MALFORMED_CONFIRM_MS/);
assert.match(worker,/AceNetTimingPolicy\.ITEM_ATTEMPT_MS/);
assert.doesNotMatch(worker,/if\(!activeRequestId\.startsWith\("__startup_prime__"\)\)return/,'Main-frame worker network errors must terminate production requests too.');

assert.match(retrieval,/A diagnostic snapshot is never item evidence and cannot create a FOUND result/);
assert.match(diagnostics,/Permanent instrumentation targets meaningful boundaries/);
assert.match(trace,/Retained-worker forensic boundary/i);
assert.doesNotMatch(web,/UI_WAIT_TIMEOUT|resolve\('TIMEOUT'\),12000/);
assert.match(web,/UPCNativeAceNetStartupStatus/);
assert.match(web,/acceptNativeStartupStatus/);
assert.doesNotMatch(web,/acenet-startup-resolved/);
assert.match(web,/startup_acenet_warmup/);
console.log('persistent retailer warm-up through retrieval service + retained worker PASS');
