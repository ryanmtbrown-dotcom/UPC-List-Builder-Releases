import {readWebRuntimeSource,readNativeRuntimeSource} from './helpers/runtime-source-tree.mjs';
import fs from 'node:fs';
import assert from 'node:assert/strict';
import vm from 'node:vm';
const main=readNativeRuntimeSource();
const coordinator=fs.readFileSync('app/src/main/java/com/rmtb/upclistbuilder/AceNetProductionCoordinator.kt','utf8');
const web=readWebRuntimeSource();
const lifecycle=fs.readFileSync('APPLICATION_LIFECYCLE_CONTRACT.md','utf8');

const onStop=coordinator.slice(coordinator.indexOf('fun onStop()'),coordinator.indexOf('fun handleBackPressed()',coordinator.indexOf('fun onStop()')));
assert.doesNotMatch(onStop,/aceNetRetrievalService\.destroy\("application_backgrounded"\)/,'idle ready worker must not be unconditionally destroyed on background');
assert.match(onStop,/persistentWorkerBusy/,'background handling must distinguish an active persistent lookup from an idle worker');
assert.match(onStop,/persistent_worker_retained_for_background/,'idle ready worker retention must be diagnostic');
assert.match(main,/if\(status=="INTERRUPTED"\)/,'background interruption must terminate without entering the production recovery ladder');
assert.match(main,/persistent_worker_interrupted_terminal/,'interrupted worker termination must explicitly prove no recovery was started');
assert.match(main,/beginAceNetProductionSoftRepair/,'authenticated unready transport must have a bounded soft worker repair path');
assert.match(main,/beginAceNetProductionHardRepair/,'stale or authentication-invalid sessions must have one bounded full session repair path');
assert.match(main,/production_session_repair_redispatched/,'successful session repair must redispatch the original request through the retained worker');
assert.doesNotMatch(main,/reprimePersistentAceNetWorkerAfterFallback|persistent_worker_reprime_complete/,'retired transient fallback re-prime path must remain absent');
assert.match(main,/aceNetInitialStartupBegun && aceNetStartupResolved && hasSavedAceNetCredentials\(\)/,'foreground worker repair must not race initial cold startup');
assert.match(main,/if\(!workerReady \|\| !fresh\)/,'foreground must repair a genuinely missing/unready worker or stale session');
assert.match(lifecycle,/idle, ready persistent retailer worker is retained/i,'lifecycle contract must preserve the ready worker across harmless background transitions');

const finish=web.slice(web.indexOf('function startupOperationFinish('),web.indexOf('function startupOperationObserve(',web.indexOf('function startupOperationFinish(')));
assert.match(finish,/outcome\.duplicate/,'startup terminal result must use the shared tracker duplicate-completion result');
assert.match(finish,/startup_operation_duplicate_completion_ignored/,'duplicate terminal attempts must be observable without rewriting the result');
// Execute the public diagnostic-operation service with the shared OperationTracker in an isolated runtime.
const trackerSource=fs.readFileSync('app/src/main/assets/www/operation-tracker.js','utf8');
const operationServiceSource=fs.readFileSync('app/src/main/assets/www/diagnostics/diagnostic-operation-service.js','utf8');
const events=[];
const context={window:{},performance:{now:()=>100},Date};
vm.createContext(context);
vm.runInContext(trackerSource+'\n'+operationServiceSource,context);
const operationService=context.window.UPCDiagnosticOperationService.create({
 operationTracker:context.window.UPCOperationTracker,
 diagnostic:(event,data)=>events.push({event,data}),
 alaskaStamp:()=>({date:'2026-09-25',time:'21:00:00',zone:'AKDT'}),
 startupNow:()=>100
});
operationService.startupOperationStart('ACENET_STARTUP','Warm AceNet','Reach terminal ready state.');
operationService.startupOperationFinish('ACENET_STARTUP','AceNet warm-up passed.','PASS');
operationService.startupOperationFinish('ACENET_STARTUP','Later duplicate said inconclusive.','INCONCLUSIVE');
assert.equal(events.filter(x=>x.event==='startup_operation_completed').length,1,'terminal startup operation must complete only once');
assert.equal(events.filter(x=>x.event==='startup_operation_duplicate_completion_ignored').length,1,'duplicate terminal completion must be explicitly ignored');
console.log('Current persistent worker lifecycle requirements PASS');

const worker=fs.readFileSync('app/src/main/java/com/rmtb/upclistbuilder/PersistentAceNetWorker.kt','utf8');
assert.match(worker,/AceNetTimingPolicy\.ITEM_ATTEMPT_MS/,'persistent item requests must use the shared twelve-second hard item ceiling');
assert.match(worker,/persistent_worker_sku_evidence_still_pending/,'slow SKU evidence must remain diagnostic rather than a premature terminal cutoff');
assert.match(worker,/AceNetTimingPolicy\.STRUCTURE_INSPECTION_MS/,'worker must inspect structure at the shared three-second checkpoint');
assert.match(worker,/AceNetTimingPolicy\.MALFORMED_CONFIRM_MS/,'worker must confirm persistent malformed structure at five seconds before early recovery');
assert.match(worker,/skuEvidenceObserved/,'persistent worker must track listener-observed SKU evidence');
assert.match(main,/status=="TIMEOUT" && skuEvidence/,'healthy exact-SKU field incompleteness must terminate without session repair');
assert.match(main,/persistent_worker_field_incomplete_terminal/,'field-level incompleteness must be diagnostic');
assert.match(main,/if\(status=="NOT_FOUND"\)/,'conclusive persistent NOT_FOUND must terminate without fallback for every production capability');
assert.match(main,/persistent_worker_not_found_terminal/,'direct persistent NOT_FOUND terminal path must be diagnostic');
assert.match(main,/registerAceNetHealthyResponse\("persistent_worker_conclusive_not_found"\)/,'conclusive NOT_FOUND must count as healthy item-service evidence');
assert.match(worker,/persistent_worker_404_observation_window_started/,'main-frame 404 must receive a rendered-page observation window');
assert.match(worker,/main_frame_http_404_observation/,'404 characterization must capture sanitized page evidence before fallback');
assert.match(worker,/MAIN_FRAME_HTTP_404_UNCLASSIFIED/,'unrecognized 404 must retain explicit abnormal HTTP classification');
assert.match(worker,/item not found\|sku not found\|no results found\|no item found\|no product found/i,'worker must retain explicit rendered not-found phrase classification');
