/** v3.12 source/identity contract retained; presentation assertions updated for v3.13 compact normal lookup. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
const root='app/src/main/assets/www/',read=f=>fs.readFileSync(root+f,'utf8');
const html=read('index.html'),css=read('store-locations/location-explorer.css');
for(const id of ['locationExplorerImage','locationExplorerImageEmpty','locationExplorerAceNetRetail','locationExplorerRetail','locationExplorerFootage','locationExplorerSourceCoordinates','locationExplorerEditMenu','locationExplorerMissing','locationExplorerNavigation','locationExplorerCount'])assert.ok(html.includes('id="'+id+'"'),id);
assert.doesNotMatch(html,/<option value="AUTO"/);
assert.match(html,/data-explorer-lookup-mode="UPC"/);
assert.match(html,/data-explorer-lookup-mode="SKU"/);
assert.match(html,/<details id="locationExplorerMore"[^>]*>/);
assert.match(css,/normal-lookup layout adaptation/);
for(const q of ['productImageFrame','priceCompare','facts','locationExplorerModes'])assert.ok(css.includes('#locationExplorerScreen .'+q),q);
const controller=read('store-locations/location-explorer-controller.js');
assert.match(controller,/productImageService\.lookupProductImage/);
assert.match(controller,/priceService\.requestPrice/);
assert.match(controller,/normalizeSKU\(result\.sku\)===normalizeSKU\(item\.sku\)/);
assert.match(controller,/Ace source · unverified/i);
assert.doesNotMatch(controller,/saveCurrent\(/);
const ctx=vm.createContext({console,window:{}});
vm.runInContext(read('store-locations/location-explorer-policy.js'),ctx);
vm.runInContext(read('store-locations/location-explorer-service.js'),ctx);
vm.runInContext(read('pricing/price-authority.js'),ctx);
vm.runInContext(read('lookup/item-record-mapper.js'),ctx);
const P=vm.runInContext('UPCLocationExplorerPolicy',ctx),R=vm.runInContext('UPCLocationExplorerService',ctx),M=ctx.window.UPCItemRecordMapper.create({normalizeUpc:x=>String(x)});
const source={id:'s1',modularId:'tape',nominalWidthFt:8,name:'Tape',current:true};
const rows=[{skuKey:'100',positions:[{sourceSegment:'1',sourceRow:19,sourceColumn:44},{sourceSegment:'2',sourceRow:2,sourceColumn:1}]}];
const ordered=P.ordered({modular:{id:'tape'},source,sourceMembers:rows,mode:'ACE'});
assert.equal(ordered.length,2,'Source positions must not be discarded');
assert.equal(ordered.every(x=>x.sourceOnly&&!x.physicalEvidence),true);
assert.notEqual(ordered[0].id,ordered[1].id);
const one={skuKey:'100',upcKey:'00012345678905',fields:{'Description':'Mount tape','Level 2 Retail Price':'15.99','Order Multiple':'6','Retail Units':'6'}};
const other={skuKey:'9023686',upcKey:'000052427603609',fields:{'Description':'Other item','Level 2 Retail Price':'11.50'}};
const catalog={
 resolveSKU:async key=>key===one.skuKey?{status:'FOUND',row:one,provenance:'MASTER_LIBRARY'}:key===other.skuKey?{status:'FOUND',row:other,provenance:'MASTER_LIBRARY'}:{status:'NOT_FOUND'},
 resolveDirectUPC:async key=>key===one.upcKey?{status:'FOUND',row:one,provenance:'MASTER_LIBRARY'}:key===other.upcKey?{status:'FOUND',row:other,provenance:'MASTER_LIBRARY'}:{status:'NOT_FOUND'}
};
const fakeRepo={bySku:async()=>({placements:[],sourceMembers:[]}),byUpc:async()=>({placements:[],sourceMembers:[]})};
const service=R.create({repository:fakeRepo,catalog,policy:P,itemMapper:M});
const identity=await service.resolveIdentity(one.upcKey,'AUTO');assert.equal(identity.skuKey,'100');assert.equal(identity.upcKey,one.upcKey);
const details=await service.details(identity);
assert.equal(details.product.status,'FOUND');
assert.equal(details.retail,'15.99','Level 2 price authority must come from shared mapper');
assert.equal(details.upc,one.upcKey,'UPC leading zeros must be retained');
assert.equal((await service.resolveIdentity(one.skuKey,'AUTO')).requestedKind,'SKU');
await assert.rejects(service.resolveIdentity('BAD','AUTO'),/Choose UPC or SKU/);
const ambiguous=R.create({repository:fakeRepo,policy:P,catalog:{
 resolveSKU:async()=>({status:'FOUND',row:one}),resolveDirectUPC:async()=>({status:'FOUND',row:other})
}});
await assert.rejects(ambiguous.resolveIdentity('100','AUTO'),/two different products/);
console.log('v3.12 Explorer identity, source positions, shared Level 2 authority and presentation PASS');
