/** v3.11: View Planogram is a Field Session activity, not a saved merchandise list. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
const root='app/src/main/assets/www/';
const read=(path)=>fs.readFileSync(root+path,'utf8');
const html=read('index.html');
assert.match(html,/<select id="newListType"[^>]*>[^<]*<option value="FIELD_SESSION">Field Session<\/option><option value="ACE_NEW_ITEMS_MISC">/);
assert.match(html,/<select id="defaultPurpose"[^>]*>[\s\S]*?<option value="General Review">General Review<\/option><option value="VIEW_PLANOGRAM">View Planogram<\/option>/);
assert.doesNotMatch(html.match(/<select id="newListType"[^>]*>([\s\S]*?)<\/select>/)[1],/VIEW_PLANOGRAM/);
assert.match(html,/id="planogramSessionHelp"/);
assert.match(html,/id="newSessionIntro"/);
assert.doesNotMatch(html,/id="fieldViewPlanogram"/,'Planogram session must not require creating an ordinary list first');
const shell=read('application/application-shell.js');
assert.match(shell,/explorerProvider:\(\)=>locationExplorerController/,'Work Session selection routes to the one existing Explorer controller');
assert.match(read('store-locations/location-explorer-controller.js'),/return Object\.freeze\(\{open,active,onAcceptedScan,bind\}\)/);
assert.doesNotMatch(read('store-locations/location-explorer-controller.js'),/fieldViewPlanogram/);

const elements=new Map();
const classes=()=>({values:new Set(),toggle(name,force){if(force)this.values.add(name);else this.values.delete(name);},add(name){this.values.add(name)},remove(name){this.values.delete(name)},contains(name){return this.values.has(name)}});
function element(id){if(!elements.has(id))elements.set(id,{id,value:'',textContent:'',innerHTML:'',classList:classes(),onclick:null,addEventListener(){}});return elements.get(id)}
let created=[],opened=[],diagnostics=[],started=[],operationResults=[],alerts=[],clicked=[],openedDSD=0,current=null;
const service={create:async (v)=>{created.push(structuredClone(v));return v},save:async()=>{},list:async()=>[],open:async()=>null,remove:async()=>{}};
const context=vm.createContext({window:{},console,Date});
vm.runInContext(read('work-sessions/work-session-controller.js'),context);
const controller=context.window.UPCWorkSessionController.create({
 elementById:element,service,fieldTags:['Price Change','NIF','General Review'],newId:()=>`id-${created.length+1}`,sessionName:()=> 'Oct 12, 2026',escapeHtml:s=>s,dsdListName:()=>'',
 dsdWorkspaceProvider:()=>({startNew:()=>openedDSD++}),explorerProvider:()=>({open:async()=>{opened.push('locationExplorerScreen')}}),
 presentationProvider:()=>({resetPreview:()=>{}}),settingsProvider:()=>({syncManualPriceVisibility:()=>{}}),onSessionChanged:()=>{},
 diagnostic:(...a)=>diagnostics.push(a),startOperation:(...a)=>started.push(a),finishOperation:(...a)=>operationResults.push(a),
 showScreen:(...a)=>clicked.push(a),goBack:()=>{},confirmUser:async()=>true,alertUser:v=>alerts.push(v)
});
const $=element;
controller.beginNewSession();
assert.equal($('newListType').value,'FIELD_SESSION');
assert.equal($('defaultPurpose').classList.contains('hidden'),false);
assert.equal(clicked.at(-1)[0],'nameScreen');
$('defaultPurpose').value='VIEW_PLANOGRAM';controller.syncNewListTypeUI();
assert.equal($('defaultPurpose').classList.contains('hidden'),false,'Activity selector must remain visible');
assert.equal($('defaultPurposeHelp').classList.contains('hidden'),true);assert.equal($('nextName').textContent,'Start Viewing');
assert.equal($('planogramSessionHelp').classList.contains('hidden'),false);
assert.match($('newSessionIntro').textContent,/Browse official Ace planograms/);
let result=await controller.startNamedList();
assert.equal(result,null);assert.deepEqual(opened,['locationExplorerScreen']);
assert.equal(created.length,0,'Explorer session must not create a list');
assert.equal(started.length,0,'Explorer session must not enter LIST_MANAGEMENT write operation');
assert.equal(controller.getCurrent(),null,'Explorer session must not install an empty list');
assert.equal(diagnostics.at(-1)[0],'planogram_explorer_session_started');
assert.equal(alerts.length,0);
// Existing Field Session, ACE MISC, and DSD behavior is deliberately unchanged.
$('defaultPurpose').value='NIF';controller.syncNewListTypeUI();
assert.equal($('defaultPurpose').classList.contains('hidden'),false);
assert.equal($('planogramSessionHelp').classList.contains('hidden'),true);
$('defaultPurpose').value='NIF';result=await controller.startNamedList();
assert.equal(created.length,1);assert.equal(created[0].sessionType,'FIELD_SESSION');assert.equal(created[0].defaultTag,'NIF');
assert.equal(clicked.at(-1)[0],'builder');
const priorCurrent=controller.getCurrent();
$('defaultPurpose').value='VIEW_PLANOGRAM';await controller.startNamedList();
assert.equal(controller.getCurrent(),priorCurrent,'Browsing does not discard an already active saved Field Session');
assert.equal(created.length,1);
$('newListType').value='ACE_NEW_ITEMS_MISC';controller.syncNewListTypeUI();
assert.equal($('defaultPurpose').classList.contains('hidden'),true);
assert.equal($('planogramSessionHelp').classList.contains('hidden'),true);
result=await controller.startNamedList();
assert.equal(created.length,2);assert.equal(created[1].sessionType,'ACE_NEW_ITEMS_MISC');
$('newListType').value='ACE_NEW_DSD_ITEMS';controller.syncNewListTypeUI();
await controller.startNamedList();assert.equal(openedDSD,1);assert.equal(created.length,2);
// A missing Explorer does not fall through and create a phantom Field Session.
let failed=[],written=[];
const broken=context.window.UPCWorkSessionController.create({
 elementById:element,service:{...service,create:async x=>written.push(x)},fieldTags:[],newId:()=> 'bad',sessionName:()=> 'Today',escapeHtml:s=>s,
 diagnostic:()=>{},startOperation:()=>{},finishOperation:()=>{},showScreen:()=>{},goBack:()=>{},confirmUser:async()=>true,
 alertUser:x=>failed.push(x),explorerProvider:()=>null
});
$('newListType').value='FIELD_SESSION';$('defaultPurpose').value='VIEW_PLANOGRAM';await broken.startNamedList();
assert.equal(written.length,0);assert.equal(failed.length,1);
console.log('v3.11 Planogram session selection, zero-list routing, visibility, existing field/MISC/DSD flows, failure handling: PASS');
