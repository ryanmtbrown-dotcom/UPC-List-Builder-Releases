import fs from 'node:fs';
import assert from 'node:assert/strict';

const html=fs.readFileSync('app/src/main/assets/www/index.html','utf8');
const shared=fs.readFileSync('app/src/main/assets/www/styles.v059.css','utf8');
const focused=[
 'app/src/main/assets/www/store-locations/location-maintenance.css',
 'app/src/main/assets/www/store-locations/location-display.css',
 'app/src/main/assets/www/store-locations/location-work.css',
 'app/src/main/assets/www/store-locations/location-explorer.css',
 'app/src/main/assets/www/application/dialogs.css',
 'app/src/main/assets/www/dsd/dsd.css',
 'app/src/main/assets/www/administration/data-management.css',
 'app/src/main/assets/www/misc/misc-workspace.css'
].map(path=>({path,source:fs.readFileSync(path,'utf8')}));

const ids=[...html.matchAll(/\bid="([^"]+)"/g)].map(m=>m[1]);
assert.equal(new Set(ids).size,ids.length,'HTML IDs must remain unique');
for(const id of [
 'home','nameScreen','builder','listScreen','openScreen','importScreen','settingsScreen',
 'buildList','openList','importLibrary','settings','builderBackHome','listSettings','activeListName',
 'itemPreview','lookupBadge','previewDescription','previewSku','productImageFrame','productImage',
 'priceCompare','labelPrice','upc','scan','lookup','addToList','tagPanel','viewItems','exportPackage',
 'listSearch','libraryFile','settingsDeepDiag','settingsDiag','aceNetPriceCheckEnabled','navBack','navMenu'
]) assert.ok(ids.includes(id),`protected presentation/behavior ID missing: ${id}`);

assert.match(html,/data-lookup-mode=/,'manual lookup behavioral data hook missing');
assert.match(html,/data-price-key=/,'price keypad behavioral data hook missing');
assert.match(html,/data-identifier-key=/,'identifier keypad behavioral data hook missing');
assert.match(html,/<p class="eyebrow">UPC LIST BUILDER<\/p>/,'Home product identity eyebrow missing');

const linked=[...html.matchAll(/<link\b[^>]*href="([^"]+\.css[^"]*)"/g)].map(m=>m[1].split('?')[0]);
assert.deepEqual(linked,[
 'styles.v059.css',
 'store-locations/location-maintenance.css',
 'store-locations/location-display.css',
 'store-locations/location-explorer.css',
 'store-locations/location-work.css',
 'application/dialogs.css',
 'dsd/dsd.css',
 'administration/data-management.css',
 'misc/misc-workspace.css'
],'stylesheet ownership/order changed unexpectedly');

assert.match(shared,/Current portrait-first shared presentation authority/,'current portrait presentation authority missing');
for(const token of ['--surface-primary:','--surface-raised:','--border-subtle:','--radius-md:','--space-md:','--text-primary:','--text-secondary:','--accent:','--focus-ring:']){
 assert.ok(shared.includes(token),`shared design token missing: ${token}`);
}
const importantCount=(shared.match(/!important/g)||[]).length;
assert.ok(importantCount<=80,`shared CSS !important ceiling exceeded: ${importantCount}`);
for(const marker of [
 'v0.53 phone containment repair','v0.53 Android geometry reset','v0.59 navigation visibility',
 'v0.59 field-work navigation','v0.59 Builder navigation','v0.71 compact manual-price',
 'v0.74 compact builder','v0.75 label-price priority'
]) assert.ok(!shared.includes(marker),`obsolete presentation patch marker returned: ${marker}`);

assert.match(shared,/\.app>section\.screen\.hidden\{display:none!important\}/,'primary screen hidden invariant missing');
assert.match(shared,/#builder \.productPanel\.empty/,'Builder empty-state presentation missing');
assert.match(shared,/#builder \.productPanel:not\(\.empty\)/,'Builder result-state presentation missing');
assert.match(shared,/@media\(max-width:430px\)/,'phone presentation breakpoint missing');
assert.match(shared,/@media\(orientation:landscape\)/,'landscape containment breakpoint missing');

for(const {path,source} of focused){
 assert.match(source,/OWNERSHIP:/,`${path} ownership header missing`);
 assert.match(source,/var\(--/,`${path} must consume shared presentation tokens`);
}
console.log('HTML/CSS presentation contract v2.84 PASS');
