import fs from 'node:fs';
import {readWebRuntimeSource,readNativeRuntimeSource,findJsFunction} from './helpers/runtime-source-tree.mjs';

const web=readWebRuntimeSource();
const native=readNativeRuntimeSource();
const broker=fs.readFileSync('app/src/main/assets/www/acenet-client.js','utf8');
const retrieval=fs.readFileSync('app/src/main/java/com/rmtb/upclistbuilder/AceNetRetrievalService.kt','utf8');
const worker=fs.readFileSync('app/src/main/java/com/rmtb/upclistbuilder/PersistentAceNetWorker.kt','utf8');
const refreshPolicy=fs.readFileSync('app/src/main/assets/www/catalog-refresh-policy.js','utf8');
const relationshipService=fs.readFileSync('app/src/main/assets/www/identifier-relationship-service.js','utf8');
const app=web,db=web,kt=native,contract=fs.readFileSync('PRODUCT_IDENTITY_INDEX_CONTRACT.md','utf8');
const identityWork=fs.readFileSync('app/src/main/assets/www/identity/identity-work-controller.js','utf8');
const must=(v,m)=>{if(!v)throw new Error(m)};

must(kt.includes('lookupAceNetCatalog(requestId: String, sku: String)'),'catalog native bridge missing');
must(retrieval.includes('worker?.takeIf { it.isReady() }?.search(requestId, mode, sku) == true'),'catalog dispatch must reuse the ready retained worker through AceNetRetrievalService');
must(!retrieval.includes('PRODUCTION_CATALOG')&&!retrieval.includes('ddlUPC')&&!retrieval.includes('divStrL1L2'),'retrieval service must remain mode-agnostic and contain no item extraction');
must(worker.includes("if($mode!=='PRODUCTION_CATALOG'&&$mode!=='PRODUCTION_MISC_CATALOG'&&$mode!=='PRODUCTION_REPAIR_CATALOG')return"),'catalog mode guard missing from sole item worker');
for(const f of ['aceRetailPrice','retailerEachCost','description','manufacturerNumber','orderMultiple','masterUpc','commodityGroup','merchandiseClassNumber','productGroupNumber'])must(worker.includes(f),`catalog field missing: ${f}`);
must(identityWork.includes('runAddToLocalLibraryBatch')&&identityWork.includes('processQueuedLocalLibrarySku')&&identityWork.includes('requestCatalog'),'Add to Local Library sequential batch action missing');
must(findJsFunction('refreshWorkQueues').length>0&&findJsFunction('runAddToLocalLibraryBatch').length>0,'identity queue refresh and batch operations must remain discoverable runtime capabilities');
must(broker.includes("acenet_catalog_enrichment_js_timeout")&&broker.includes('productionBrokerTimeout'),'unified broker catalog watchdog must derive from the production incident policy');
must(identityWork.includes('recheckResearchSku')&&identityWork.includes("result.status==='NOT_FOUND'"),'research Recheck triage missing');
must(db.includes('removeLibraryUpdateQueueSku'),'completed queue removal missing');
const persistCatalog=findJsFunction('persistVerifiedAceNetCatalogToLocalLibrary'),applyRefresh=findJsFunction('applyCatalogRefreshPolicyToExistingRecord');
must(persistCatalog.includes('UPCCatalogRefreshPolicy.plan')&&persistCatalog.includes('gate.relationship.upcs'),'verified catalog persistence must route complete UPC evidence through the Stage 7 policy plan');
must(applyRefresh.includes("plan.relationship.action==='REPLACE'")&&applyRefresh.includes('recordVerifiedSkuUpcs(key,plan.relationship.upcs'),'Stage 7 policy execution must retain shared complete-set UPC relationship ingestion');
must(contract.includes('### Add to Local Library'),'current deferred Local Library work-queue contract section missing');
console.log('product identity index v2.31 deferred enrichment under Stage 6 retrieval boundary: PASS');
