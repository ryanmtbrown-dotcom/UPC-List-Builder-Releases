import fs from 'node:fs';
import {readWebRuntimeSource,readNativeRuntimeSource,findJsFunction} from './helpers/runtime-source-tree.mjs';
const web=readWebRuntimeSource(),native=readNativeRuntimeSource();
const identityWork=fs.readFileSync('app/src/main/assets/www/identity/identity-work-controller.js','utf8');
const app=web,db=web,misc=web,worker=native;
const refreshPolicy=fs.readFileSync('app/src/main/assets/www/catalog-refresh-policy.js','utf8');
const relationshipService=fs.readFileSync('app/src/main/assets/www/identifier-relationship-service.js','utf8');
const contract=fs.readFileSync('PRODUCT_IDENTITY_INDEX_CONTRACT.md','utf8');
const start=fs.readFileSync('AI_START_HERE.md','utf8');
const must=(v,m)=>{if(!v)throw new Error(m)};
// Phase 2/3: Master-first unknown UPC resolution and explicit classifications.
must(app.includes('local_library_catalog_persist_verified')&&app.includes('acenet_missing_sku_resolved_durably')&&app.includes('acenet_missing_sku_classified_research'),'durable Local/research classification lifecycle missing');
// Phase 4: conflicts are explicit and user-resolved, never guessed.
must(identityWork.includes('async function resolveConflict')&&identityWork.includes('identity_conflict_resolved')&&identityWork.includes('identity_conflict_left_unknown'),'conflict-resolution lifecycle missing');
// Phase 5: accepted MISC UPCs feed identity without a second route.
must(misc.includes("UPCIdentifierRelationshipService.recordVerifiedSkuUpcs(normalizedSku,normalized,source,{completeness:'COMPLETE',exactSkuVerified:true})"),'MISC identity ingestion must use the Stage 4 relationship owner');
// Phase 6: deliberate Update/Recheck and complete terminal diagnostics.
must(identityWork.includes('identity_local_library_update_requested')&&identityWork.includes('identity_local_library_update_completed')&&identityWork.includes('identity_local_library_update_deferred'),'Local Library Update diagnostics incomplete');
must(identityWork.includes('runAddToLocalLibraryBatch')&&identityWork.includes('for(const row of queued)')&&identityWork.includes('await processQueuedLocalLibrarySku(key)'),'single sequential Add to Local Library batch missing');
must(!app.includes('data-identity-update-sku'),'per-SKU Add to Local Library Update controls must be removed');
must(db.includes('stageLocalLibraryAceNetItem')&&db.includes('lookupUniqueLocalSKU')&&db.includes('enqueueLibrarySku'),'unified durable Local lookup/staging plus durable queue APIs missing');
must(!db.includes('reconcilePromotedLocalLibraryRecord')&&!db.includes('restoreMissingPromotedLocalLibraryRecords'),'Stage 9 must retire promoted-Master reconciliation/restoration.');
const persistCatalog=findJsFunction('persistVerifiedAceNetCatalogToLocalLibrary'),applyRefresh=findJsFunction('applyCatalogRefreshPolicyToExistingRecord');
must(persistCatalog.includes('UPCCatalogRefreshPolicy.plan')&&persistCatalog.includes('gate.relationship.upcs'),'all returned complete UPC evidence must pass through the Stage 7 policy gate');
must(applyRefresh.includes("plan.relationship.action==='REPLACE'")&&applyRefresh.includes('recordVerifiedSkuUpcs(key,plan.relationship.upcs'),'complete UPC relationship ingestion must remain delegated to the Stage 4 relationship owner');
must(identityWork.includes('identity_research_recheck_requested')&&identityWork.includes('identity_research_recheck_reclassified')&&identityWork.includes('identity_research_recheck_still_not_found')&&identityWork.includes('identity_research_recheck_inconclusive'),'Research Recheck diagnostics incomplete');
must(db.includes('removeLibraryUpdateQueueSku')&&db.includes('removeIdentityResearch'),'terminal queue cleanup APIs missing');
must(worker.includes("PRODUCTION_CATALOG")&&worker.includes("PRODUCTION_PRICE")&&worker.includes("PRODUCTION_UPCS"),'required worker modes missing');
must(contract.includes('**STATUS: CURRENT**')&&contract.includes('## Durable identity state')&&start.includes('SOURCE_OWNERSHIP_MAP.md'),'current identity authority missing');
console.log('product identity index v2.32 closure/hardening: PASS');
