import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';

const root='app/src/main/assets/www/';
const barcodeSrc=fs.readFileSync(root+'field-session/register-barcode.js','utf8');
const source=fs.readFileSync(root+'field-session/register-price-controller.js','utf8');
const html=fs.readFileSync(root+'index.html','utf8');
const css=fs.readFileSync(root+'styles.v059.css','utf8');
const shell=fs.readFileSync(root+'application/application-shell.js','utf8');
const preview=fs.readFileSync(root+'lookup/item-presentation-controller.js','utf8');
const sessionOwner=fs.readFileSync(root+'work-sessions/work-session-controller.js','utf8');

for(const id of ['registerExportQuestionOverlay','registerExportYes','registerExportNo','registerExportCancel',
 'registerPriceOverlay','registerReviewBarcode','registerReviewKeypad','registerReviewPrevious',
 'registerReviewNext','registerReviewNif','registerReviewClear','registerReviewSaveLater',
 'registerReviewExport','resumeRegisterPrices','registerBarcodeOverlay','registerLookupBarcode',
 'registerBarcodeClose','previewBarcodeButton'])assert.ok(html.includes('id="'+id+'"'),'Required modal/action missing: '+id);
assert.match(css,/\.registerReviewDialog,\.registerQuestionDialog,\.registerLookupDialog\{[^}]*overflow:hidden/,'review must never scroll');
assert.match(css,/\.registerReviewGrid\{[^}]*overflow:hidden/,'review content must never scroll');
assert.match(css,/@media\(orientation:landscape\) and \(max-height:520px\)/,'landscape layout required');
assert.match(shell,/registerPriceController\.offerExport\(\)/);
assert.match(shell,/registerPriceController\.bind\(\)/);
assert.match(preview,/setText\('previewUpc',item\.upc\|\|'—'\);syncBarcodeButton\(item\.upc\)/);
assert.match(sessionOwner,/onSessionChanged\?\.\(\)/,'reopened sessions must update Resume Register Prices');

const barcodeContext={window:{}};
vm.createContext(barcodeContext);
vm.runInContext(barcodeSrc,barcodeContext,{filename:'register-barcode.js'});
const barcode=barcodeContext.window.UPCRegisterBarcode;
for(const [digits,format,modules] of [['036000291452','UPC',95],['4006381333931','EAN13',95],['96385074','EAN8',67]]){
 const p=barcode.plan(digits);assert.equal(p.ok,true);assert.equal(p.format,format);assert.equal(p.bits.length,modules);
}
assert.equal(barcode.plan('036000291453').format,'CODE128','bad check digit must not be falsely labeled UPC-A');
assert.equal(barcode.plan('123456789012345').format,'CODE128');
assert.equal(barcode.plan('ABC').ok,false);

const elements=new Map();
function element(){const classes=new Set(['hidden']);return{
 textContent:'',disabled:false,onclick:null,style:{},dataset:{},
 classList:{add:x=>classes.add(x),remove:x=>classes.delete(x),contains:x=>classes.has(x),toggle(x,force){if(force===undefined)force=!classes.has(x);if(force)classes.add(x);else classes.delete(x);return force;}},focus(){},
 };}
const $=id=>{if(!elements.has(id))elements.set(id,element());return elements.get(id)};
const UPCS=Array.from({length:251},(_,i)=>String(i+1).padStart(11,'0')+String(i%10));
const items=UPCS.map((upc,i)=>({id:'item-'+i,sku:'SKU-'+Math.floor(i/2),upc,tags:['Price Change'],labelPrice:i%2?4.99:8.99,libraryPrice:7.99}));
// Even though register marks one UPC NIF, its label still differs from Level 2.
// The Price Change observation must remain in the price-change workbook.
items[10].fields={'Ace Retail Price':'11.99','Level 2 Retail Price':'13.99'};
items[10].labelPrice=12.99;
let current={id:'list',sessionType:'FIELD_SESSION',items};
let saveCount=0,exportCalls=[],exNext='EXPORTED',failNextSave=false;
const persisted=[];
const exportService={
 registerReviewEntries:async rows=>rows.map(item=>({item,upc:item.upc})),
 currentExportPreferences:async()=>({forceAceMiscFormat:true}),
 registerPriceForItem:(item,upc)=>Object.hasOwn(item.registerPricesByUpc||{},upc)?item.registerPricesByUpc[upc]:'',
 exportTaggedPackage:async opts=>{exportCalls.push(opts);return{status:exNext}}
};
const context={window:{},document:{addEventListener(){}},Date,Math,Number,Object,String,Array,Set,Promise,Error};
vm.createContext(context);vm.runInContext(fs.readFileSync(root+'pricing/price-authority.js','utf8'),context,{filename:'price-authority.js'});vm.runInContext(source,context,{filename:'register-price-controller.js'});
const Controller=context.window.UPCRegisterPriceController;
const create=()=>Controller.create({elementById:$,getCurrent:()=>current,saveCurrent:async()=>{saveCount++;if(failNextSave){failNextSave=false;throw Error('Simulated storage failure')}persisted.push(JSON.parse(JSON.stringify(current)))},exportService,barcode:{plan:barcode.plan,render:(svg,upc)=>barcode.plan(upc)},alertUser:message=>{throw Error(message)},diagnostic:()=>{}});
let ctrl=create();ctrl.bind();
ctrl.offerExport();assert.equal($('registerExportQuestionOverlay').classList.contains('hidden'),false);
$('registerExportYes').onclick();await new Promise(resolve=>setImmediate(resolve));
assert.equal($('registerPriceOverlay').classList.contains('hidden'),false);
assert.equal($('registerReviewPosition').textContent,'1 / 251');
assert.equal($('registerReviewChecked').textContent,'0 priced · 0 NIF · 251 unchecked');
assert.equal($('registerReviewNext').disabled,true,'cannot skip an unchecked UPC with Save Price & Next');
assert.equal($('registerReviewKeypad').disabled,false,'collector keypad must be enabled when opening completes');

// Enter a few UPCs, with a saved cursor at the first unchecked UPC.
async function clickNext(){await $('registerReviewNext').onclick();await new Promise(resolve=>setImmediate(resolve))}
for(let i=0;i<10;i++){
 const pad=$('registerReviewKeypad');pad.onclick({target:{closest:()=>({dataset:{registerKey:'1'}})}});
 pad.onclick({target:{closest:()=>({dataset:{registerKey:'2'}})}});
 pad.onclick({target:{closest:()=>({dataset:{registerKey:'5'}})}});
 await clickNext();
}
assert.equal(saveCount,10);assert.equal(current.items[0].registerPricesByUpc[UPCS[0]],1.25);
assert.equal(current.items[9].registerPricesByUpc[UPCS[9]],1.25);
assert.equal($('registerReviewPosition').textContent,'11 / 251');
assert.equal($('registerReviewChecked').textContent,'10 priced · 0 NIF · 241 unchecked');
assert.equal(current.registerPriceReview.cursorUpc,UPCS[10],'Next must persist the destination cursor immediately');
await $('registerReviewSaveLater').onclick();
assert.equal($('registerPriceOverlay').classList.contains('hidden'),true);
assert.equal($('resumeRegisterPrices').classList.contains('hidden'),false);
const checkpoint=JSON.parse(JSON.stringify(persisted.at(-1)));
// Reopening a session from persisted storage resumes at the same UPC.
current=checkpoint;ctrl=create();ctrl.bind();
await ctrl.openCollector();
assert.equal($('registerReviewPosition').textContent,'11 / 251');
assert.equal($('registerReviewChecked').textContent,'10 priced · 0 NIF · 241 unchecked');
// A zero is an entered price, not unchecked.
$('registerReviewKeypad').onclick({target:{closest:()=>({dataset:{registerKey:'0'}})}});
await clickNext();
assert.equal(current.items[10].registerPricesByUpc[UPCS[10]],0);
// Correct previous UPC and prove the change is per UPC, not per SKU.
await $('registerReviewPrevious').onclick();
$('registerReviewKeypad').onclick({target:{closest:()=>({dataset:{registerKey:'9'}})}});
await clickNext();
assert.equal(current.items[10].registerPricesByUpc[UPCS[10]],0.09);
assert.equal(current.items[11].registerPricesByUpc?.[UPCS[11]],undefined);
// Clearing a saved price restores the unchecked state (distinct from 0).
await $('registerReviewPrevious').onclick();await $('registerReviewClear').onclick();
assert.equal(current.items[10].registerPricesByUpc?.[UPCS[10]],undefined);
assert.equal($('registerReviewChecked').textContent,'10 priced · 0 NIF · 241 unchecked');
// No unrestricted forward navigation: Save Price & Next refuses an unchecked UPC.
assert.equal($('registerReviewNext').disabled,true);
await $('registerReviewNext').onclick();
assert.equal($('registerReviewPosition').textContent,'11 / 251');
// Failure of a NIF write restores tags, UPC evidence and position atomically.
failNextSave=true;
await $('registerReviewNif').onclick();
assert.equal(current.items[10].tags.includes('NIF'),false);
assert.equal(current.items[10].registerNifUpcs,undefined);
assert.equal($('registerReviewPosition').textContent,'11 / 251');
await $('registerReviewNif').onclick();
assert.deepEqual(Array.from(current.items[10].registerNifUpcs),[UPCS[10]]);
assert.equal(current.items[10].tags.includes('NIF'),true);
assert.equal(current.items[10].tags.includes('Price Change'),true,'NIF must never discard a true Level 2 label discrepancy');
assert.equal(context.window.UPCPriceAuthority.observedPrice(current.items[10]),13.99,'NIF cannot change Level 2 pricing authority');
assert.equal(current.items[10].labelPrice-context.window.UPCPriceAuthority.observedPrice(current.items[10]),-1,'NIF label discrepancy stays real');
assert.equal(current.items[10].registerPricesByUpc?.[UPCS[10]],undefined);
assert.equal($('registerReviewChecked').textContent,'10 priced · 1 NIF · 240 unchecked');
assert.equal($('registerReviewPosition').textContent,'12 / 251');
assert.equal(current.registerPriceReview.cursorUpc,UPCS[11]);
// Previous allows correcting an incorrectly marked NIF.
await $('registerReviewPrevious').onclick();
assert.equal($('registerReviewNif').textContent,'Undo NIF');
await $('registerReviewNif').onclick();
assert.equal(current.items[10].tags.includes('NIF'),false);
assert.equal(current.items[10].registerNifUpcs.length,0);
assert.equal($('registerReviewPosition').textContent,'11 / 251');
await $('registerReviewNif').onclick();
assert.equal(current.items[10].tags.includes('NIF'),true);
assert.equal($('registerReviewPosition').textContent,'12 / 251');
// Export is allowed with 241 unchecked UPCs, and contains a Register Price column request.
exNext='CANCELLED';await $('registerReviewExport').onclick();
assert.equal($('registerPriceOverlay').classList.contains('hidden'),false,'cancelled export returns to review');
exNext='EXPORTED';await $('registerReviewExport').onclick();
assert.equal($('registerPriceOverlay').classList.contains('hidden'),true);
assert.equal(exportCalls.at(-1).includeRegisterPrice,true);
assert.equal(current.registerPriceReview.cursorUpc,UPCS[11]);
// No means legacy export path (without optional Register Price column).
ctrl.offerExport();$('registerExportNo').onclick();await new Promise(resolve=>setImmediate(resolve));
assert.equal(exportCalls.at(-1).includeRegisterPrice,false);
assert.ok(saveCount>=14);
console.log('Register Price: 251 UPCs, currency entry, NIF navigation, saved resume, correction, clear, partial export and barcode validation PASS');

// Real export service: forced UPC expansion returns temporary copies. Collector must
// retain the original Work Session item so edits persist and are exported correctly.
const exportSource=fs.readFileSync(root+'field-session/field-session-export-service.js','utf8');
const exportContext={window:{}};vm.createContext(exportContext);
vm.runInContext(fs.readFileSync(root+'pricing/price-authority.js','utf8'),exportContext,{filename:'price-authority.js'});
vm.runInContext(exportSource,exportContext,{filename:'field-session-export-service.js'});
const original={id:'test-original',sku:'1234',upc:'036000291452',tags:['Price Change'],registerPricesByUpc:{}};
const originalRows=[original];
let pricedWorkbook=null;
const realExport=exportContext.window.UPCFieldSessionExportService.create({
 getCurrentSession:()=>({id:'test',items:originalRows}),exportTags:['Price Change'],dateStamp:()=> '2026-10-10',
 promptUser:async()=>null,alertUser:()=>{},diagnostic:()=>{},startOperation:()=>{},finishOperation:()=>{},
 storage:{getItem:()=>'',setItem:()=>{}},zipCtor:function(){},
 xlsxExporter:{MIME:'test',build:()=>({})},fileDelivery:{deliverBytes:()=>{}},
 exportSchema:{MASTER_HEADERS:['UPC/EAN'],ACE_MISC_HEADERS:['UPC/EAN'],normalizeMasterSelection:x=>x,defaultMasterSelection:()=>['UPC/EAN']},
 getExportPreferences:async()=>({forceAceMiscFormat:true,headers:['UPC/EAN']}),
 aceMiscFormatter:{buildAvailableFormat:async(rows,opts)=>{pricedWorkbook={rows,opts};return pricedWorkbook},rowsFromAvailableItems:items=>items.flatMap(item=>(item.allUpcs||[item.upc]).map(upc=>{const row=Array(33).fill('');row[21]=upc;return row}))},
 getKnownUpcsForSku:async()=>[{upcKey:'036000291452'},{upcKey:'04006381333931'}]
});
const expanded=await realExport.registerReviewEntries(originalRows,{forceAceMiscFormat:true});
assert.equal(expanded.length,2,'forced MISC evidence expands to two UPC rows');
assert.equal(expanded[0].item,original,'first UPC retains original persisted item identity');
assert.equal(expanded[1].item,original,'secondary UPC retains original persisted item identity');
expanded[1].item.registerPricesByUpc[expanded[1].upc]=19.95;
assert.equal(original.registerPricesByUpc['04006381333931'],19.95,'register price is saved to authoritative original item');
assert.equal(realExport.registerPriceForItem(original,'036000291452'),'','other UPC stays unchecked');
assert.equal(realExport.registerPriceForItem(original,'04006381333931'),19.95);
// One NIF UPC from the two known UPCs must produce exactly one NIF row.
original.registerNifUpcs=['04006381333931'];original.tags.push('NIF');
original.fields={'Ace Retail Price':'11.99','Level 2 Retail Price':'13.99'};
original.labelPrice=12.99;
assert.equal(original.tags.includes('Price Change'),true,'marking one UPC NIF cannot erase Price Change');
assert.equal(realExport.registerPriceForItem(original,'04006381333931'),'','NIF register price must export blank even when a legacy numeric value remains');
await realExport.workbookForRows([original],'Price Change',{forceAceMiscFormat:true,headers:['UPC/EAN']},{includeRegisterPrice:true});
assert.equal(pricedWorkbook.rows.length,1,'NIF item remains present in Price Change export');
assert.deepEqual(Array.from(pricedWorkbook.opts.trailingColumns.map(c=>c.header)),['Label Price','Register Price']);
assert.equal(pricedWorkbook.opts.trailingColumns[0].valueForItem(original),12.99,'Price Change retains observed label');
assert.equal(pricedWorkbook.opts.trailingColumns[1].valueForItem(original,'04006381333931'),'','NIF records have blank register price, not zero');
let nifExportRows=null;
const originalFormatter=realExport;
const nifCtx={window:{}};
vm.createContext(nifCtx);
vm.runInContext(fs.readFileSync(root+'pricing/price-authority.js','utf8'),nifCtx);
vm.runInContext(exportSource,nifCtx);
const nifExporter=nifCtx.window.UPCFieldSessionExportService.create({
 getCurrentSession:()=>({id:'test',items:[original]}),exportTags:['NIF'],dateStamp:()=> '2026-10-10',
 promptUser:async()=>null,alertUser:()=>{},diagnostic:()=>{},startOperation:()=>{},finishOperation:()=>{},
 storage:{getItem:()=>'',setItem:()=>{}},zipCtor:function(){},
 xlsxExporter:{MIME:'test',build:(headers,data)=>({headers,data})},fileDelivery:{deliverBytes:()=>{}},
 exportSchema:{MASTER_HEADERS:['UPC/EAN'],ACE_MISC_HEADERS:['UPC/EAN'],normalizeMasterSelection:x=>x,defaultMasterSelection:()=>['UPC/EAN']},
 getExportPreferences:async()=>({forceAceMiscFormat:true,headers:['UPC/EAN']}),
 aceMiscFormatter:{buildAvailableFormat:async(rows)=>{nifExportRows=rows;return rows},rowsFromAvailableItems:items=>items.flatMap(item=>(item.allUpcs||[item.upc]).map(upc=>{const row=Array(33).fill('');row[21]=upc;return row}))},
 getKnownUpcsForSku:async()=>[{upcKey:'036000291452'},{upcKey:'04006381333931'}]
});
await nifExporter.workbookForRows([original],'NIF',{forceAceMiscFormat:true,headers:['UPC/EAN']});
assert.equal(nifExportRows.length,1,'only explicitly NIF-marked UPC is exported');
assert.deepEqual(Array.from(nifExportRows[0].allUpcs),['04006381333931']);
assert.equal(nifExportRows[0].upc,'04006381333931');
const nonforced=await nifExporter.workbookForRows([original],'NIF',{forceAceMiscFormat:false,headers:['UPC/EAN']});
assert.equal(nonforced.data.length,1);
assert.equal(nonforced.data[0][0],'04006381333931');
const standardPriceChange=await nifExporter.workbookForRows([original],'Price Change',{forceAceMiscFormat:false,headers:['UPC/EAN','Level 2 Retail Price']},{includeRegisterPrice:true});
assert.equal(standardPriceChange.headers.at(-1),'Register Price');
assert.equal(standardPriceChange.data[0].at(-1),'','NIF also leaves Register Price blank in the non-forced export');
assert.equal(original.tags.includes('Price Change'),true,'both exports preserve Price Change status');
console.log('Register NIF: no skip, explicit mark, per-UPC worksheet, undo, persistence and rollback PASS');
