import {readWebRuntimeSource} from './helpers/runtime-source-tree.mjs';
import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';

const read=p=>fs.readFileSync(p,'utf8');
const plain=value=>JSON.parse(JSON.stringify(value));
const paths={
  master:'app/src/main/assets/www/master-repository.js',
  local:'app/src/main/assets/www/local-repository.js',
  identity:'app/src/main/assets/www/identity-repository.js',
  migration:'app/src/main/assets/www/migration-repository.js',
  workSessionRepository:'app/src/main/assets/www/work-sessions/work-session-repository.js',
  workSessionService:'app/src/main/assets/www/work-sessions/work-session-service.js',
  miscMaintenance:'app/src/main/assets/www/misc/misc-maintenance-service.js',
  catalogMaintenance:'app/src/main/assets/www/catalog/catalog-maintenance-service.js',
  effective:'app/src/main/assets/www/effective-catalog-resolver.js',
  relationship:'app/src/main/assets/www/identifier-relationship-service.js',
  localIdentifier:'app/src/main/assets/www/local-identifier-resolver.js',
  app:'app/src/main/assets/www/app.v059.js',
  misc:'app/src/main/assets/www/ace-misc.js',
  miscResolution:'app/src/main/assets/www/misc/misc-resolution-service.js',
  workflow:'app/src/main/assets/www/library-workflow-v093.js',
  index:'app/src/main/assets/www/index.html',
  db:'app/src/main/assets/www/db.js'
};
const source=Object.fromEntries(Object.entries(paths).map(([k,p])=>[k,read(p)]));
const webRuntime=readWebRuntimeSource();

const calls=[];
const stub=(name,result)=>async(...args)=>{calls.push({name,args});return typeof result==='function'?result(...args):result};
const UPCDB={
 get:stub('get',(store,key)=>store==='meta'&&key==='library'?{key:'library',generation:'g1'}:null),
 all:stub('all',[]),
 remove:stub('remove'),
 put:stub('put',(store,value)=>value),
 lookupUniqueExact:stub('lookupUniqueExact',{row:{id:1},count:1,mode:'EXACT'}),
 lookupUniquePrefix:stub('lookupUniquePrefix',{row:null,count:0,mode:'PREFIX_11'}),
 lookupUniqueSKU:stub('lookupUniqueSKU',{row:{skuKey:'1'},count:1,mode:'SKU_EXACT'}),
 getActiveLibraryRecords:stub('getActiveLibraryRecords',[{id:1}]),
 updateActiveLibraryMasterUpc:stub('updateActiveLibraryMasterUpc',{updated:true}),
 stageLibrary:stub('stageLibrary','g2'),
 cleanupLibraries:stub('cleanupLibraries'),
 discardLibraryGeneration:stub('discardLibraryGeneration'),
 reindexActiveLibrary:stub('reindexActiveLibrary',{generation:'g1'}),
 lookupUniqueLocalExact:stub('lookupUniqueLocalExact',{row:null,count:0,mode:'LOCAL_EXACT'}),
 lookupUniqueLocalPrefix:stub('lookupUniqueLocalPrefix',{row:null,count:0,mode:'LOCAL_PREFIX_11'}),
 lookupUniqueLocalSKU:stub('lookupUniqueLocalSKU',{row:null,count:0,mode:'LOCAL_SKU_EXACT'}),
 getLocalLibraryRecords:stub('getLocalLibraryRecords',[]),
 getLocalLibraryRecordBySku:stub('getLocalLibraryRecordBySku',null),
 stageLocalLibraryAceNetItem:stub('stageLocalLibraryAceNetItem',{created:true}),
 stageLocalLibraryThirdPartyItem:stub('stageLocalLibraryThirdPartyItem',{created:true}),
 correctLocalLibraryFields:stub('correctLocalLibraryFields',{updated:true}),
 clearLocalLibraryAceNetFields:stub('clearLocalLibraryAceNetFields',{updated:true}),
 setLocalLibraryAceNetVerification:stub('setLocalLibraryAceNetVerification',{updated:true}),
 updateLocalLibraryMasterUpc:stub('updateLocalLibraryMasterUpc',{updated:true}),
 findLocalLibraryRepairCandidates:stub('findLocalLibraryRepairCandidates',[]),
 findAceMiscSnapshotRepairCandidates:stub('findAceMiscSnapshotRepairCandidates',[]),
 replaceAceMiscSnapshotsForSku:stub('replaceAceMiscSnapshotsForSku',{itemsUpdated:0}),
 enqueueLibrarySku:stub('enqueueLibrarySku',{queued:true}),
 enqueueLibraryUpdate:stub('enqueueLibraryUpdate',{queued:true}),
 getLibraryUpdateQueue:stub('getLibraryUpdateQueue',[]),
 clearLibraryUpdateQueue:stub('clearLibraryUpdateQueue'),
 removeLibraryUpdateQueueSku:stub('removeLibraryUpdateQueueSku'),
 upsertSkuUpcs:stub('upsertSkuUpcs',{skuKey:'1'}),
 getSkuUpcs:stub('getSkuUpcs',[]),
 lookupSkuByUpc:stub('lookupSkuByUpc',[]),
 getSkuIdentity:stub('getSkuIdentity',null),
 setSkuIdentityStatus:stub('setSkuIdentityStatus',{skuKey:'1'}),
 setSkuReplacement:stub('setSkuReplacement',{skuKey:'1'}),
 getUpcIdentityResolution:stub('getUpcIdentityResolution',null),
 recordIdentityRelationship:stub('recordIdentityRelationship',{skuKey:'1'}),
 recordVerifiedSkuUpcs:stub('recordVerifiedSkuUpcs',{skuKey:'1'}),
 replaceSkuUpcSet:stub('replaceSkuUpcSet',{skuKey:'1'}),
 resolveUpcConflict:stub('resolveUpcConflict',{resolved:true}),
 enqueueIdentityResearch:stub('enqueueIdentityResearch',{queued:true}),
 getIdentityResearch:stub('getIdentityResearch',null),
 updateIdentityResearch:stub('updateIdentityResearch',{updated:true}),
 updateIdentityResearchUpc:stub('updateIdentityResearchUpc',{updated:true}),
 getIdentityResearchQueue:stub('getIdentityResearchQueue',[]),
 removeIdentityResearch:stub('removeIdentityResearch'),
 updateIdentityResearchSku:stub('updateIdentityResearchSku',{updated:true}),
 discardIdentityResearch:stub('discardIdentityResearch',true),
 enqueueDeferredAceNetRefresh:stub('enqueueDeferredAceNetRefresh',{queued:true}),
 getDeferredAceNetRefreshQueue:stub('getDeferredAceNetRefreshQueue',[]),
 removeDeferredAceNetRefreshSku:stub('removeDeferredAceNetRefreshSku',true),
 getIdentityConflictQueue:stub('getIdentityConflictQueue',[]),
};
const context={window:{},UPCDB,UPCIdentifierNormalization:{normalizeSKU:v=>String(v??'').trim()}};
vm.createContext(context);
for(const key of ['master','local','identity','migration'])vm.runInContext(source[key],context,{filename:paths[key]});

const master=context.window.UPCMasterRepository,local=context.window.UPCLocalRepository,identity=context.window.UPCIdentityRepository,migration=context.window.UPCMigrationRepository;
assert.ok(master&&local&&identity&&migration,'all four repository facades must export');
assert.deepEqual(plain(await master.getMetadata()),{key:'library',generation:'g1'});
await master.saveMetadata({generation:'g9',key:'wrong'});
assert.deepEqual(plain(calls.at(-1)),{name:'put',args:['meta',{generation:'g9',key:'library'}]});
await master.lookupSKU(' 123 ');
assert.equal(calls.at(-1).name,'lookupUniqueSKU');
await master.updateMasterUpc(1,'123','456');assert.equal(calls.at(-1).name,'updateActiveLibraryMasterUpc');

assert.deepEqual(plain(await local.getMetadata()),{key:'localLibraryAdditions',records:[]},'missing Local metadata must preserve current empty default');
await local.saveMetadata({records:[{id:1}],key:'wrong'});
assert.deepEqual(plain(calls.at(-1)),{name:'put',args:['meta',{records:[{id:1}],key:'localLibraryAdditions'}]});
assert.equal(local.getPendingAdditions,undefined,'Stage 9 must retire the pending-additions shadow repository surface.');
assert.equal(local.findAceMiscSnapshotRepairCandidates,undefined,'Local Repository must not own MISC work-session traversal.');
assert.equal(local.replaceAceMiscSnapshotsForSku,undefined,'Local Repository must not mutate MISC work sessions.');
await local.updateMasterUpc('123','456');assert.equal(calls.at(-1).name,'updateLocalLibraryMasterUpc');

await identity.recordVerifiedSkuUpcs('123',['456'],'TEST');
assert.deepEqual(plain(calls.at(-1)),{name:'recordVerifiedSkuUpcs',args:['123',['456'],'TEST']});
await identity.replaceSkuUpcSet('123',['456'],'COMPLETE');
assert.deepEqual(plain(calls.at(-1)),{name:'replaceSkuUpcSet',args:['123',['456'],'COMPLETE']});
assert.equal(typeof migration.prepareWorkSessions,'function','Stage 2 migration facade must expose bounded Work Session preparation.');
assert.equal(typeof migration.retireStage9LegacyState,'function','Stage 9 migration facade must expose the one-time retirement migration.');

const index=source.index;
for(const name of ['master-repository.js','local-repository.js','identity-repository.js','migration-repository.js']){
  assert.ok(index.indexOf(name)>index.indexOf('db.js'),name+' must load after db.js');
  assert.ok(index.indexOf(name)<index.indexOf('ace-misc.js'),name+' must load before repository consumers');
}
assert.ok(index.indexOf('work-session-repository.js')>index.indexOf('db.js'),'Work Session repository must load above raw IndexedDB.');
assert.ok(index.indexOf('work-session-service.js')>index.indexOf('work-session-repository.js'),'Work Session service must load above its repository.');
assert.ok(index.indexOf('work-session-service.js')<index.indexOf('migration-repository.js'),'Migration must consume the Work Session boundary rather than raw list storage.');
assert.ok(index.indexOf('misc-maintenance-service.js')>index.indexOf('work-session-service.js'),'MISC maintenance must depend on the Work Session service.');
assert.ok(index.indexOf('misc-maintenance-service.js')<index.indexOf('app.v059.js'),'MISC maintenance must be available before the application composition root.');
assert.ok(index.indexOf('migration-repository.js')<index.indexOf('app.v059.js'));
assert.ok(index.indexOf('effective-catalog-resolver.js')>index.indexOf('local-repository.js')&&index.indexOf('effective-catalog-resolver.js')<index.indexOf('ace-misc.js'),'Effective Catalog must sit above repositories and below workflow consumers.');

const targeted=/UPCDB\.(lookupUnique(?:Local)?(?:Exact|Prefix|SKU)|getActiveLibraryRecords|updateActiveLibraryMasterUpc|stageLocalLibraryAceNetItem|stageLocalLibraryThirdPartyItem|getLocalLibraryRecordBySku|correctLocalLibraryFields|clearLocalLibraryAceNetFields|setLocalLibraryAceNetVerification|updateLocalLibraryMasterUpc|findLocalLibraryRepairCandidates|findAceMiscSnapshotRepairCandidates|replaceAceMiscSnapshotsForSku|enqueueLibrarySku|enqueueLibraryUpdate|getLibraryUpdateQueue|clearLibraryUpdateQueue|removeLibraryUpdateQueueSku|upsertSkuUpcs|getSkuUpcs|lookupSkuByUpc|getSkuIdentity|setSkuIdentityStatus|setSkuReplacement|getUpcIdentityResolution|recordIdentityRelationship|recordVerifiedSkuUpcs|replaceSkuUpcSet|resolveUpcConflict|enqueueIdentityResearch|getIdentityResearch|updateIdentityResearch|updateIdentityResearchUpc|getIdentityResearchQueue|removeIdentityResearch|updateIdentityResearchSku|discardIdentityResearch|enqueueDeferredAceNetRefresh|getDeferredAceNetRefreshQueue|removeDeferredAceNetRefreshSku|getIdentityConflictQueue|getLocalLibraryRecords|reindexActiveLibrary|stageLibrary|cleanupLibraries|discardLibraryGeneration)/;
for(const [name,src] of [['app',source.app],['ACE MISC',source.misc],['library workflow',source.workflow]]){
 assert.doesNotMatch(src,targeted,name+' must not bypass repository facades for catalog/identity/migration persistence');
}
assert.doesNotMatch(source.workflow,/UPCDB\.(?:get|put)\('meta',\s*'(?:library|localLibraryAdditions|pendingLibraryAdditions)'/,'library workflow must not know physical catalog metadata keys');
assert.doesNotMatch(source.app,/UPCDB\.(?:get|put|all|remove)\(\s*['"]lists['"]/,'application workflow must not bypass Work Session persistence.');
assert.doesNotMatch(source.migration,/UPCDB\.(?:get|put|all|remove)\(\s*['"]lists['"]/,'migration must use Work Session persistence rather than the physical lists store.');
assert.match(source.workSessionRepository,/const STORE='lists'/);
assert.match(source.workSessionRepository,/UPCDB\.all\(STORE\)/);
assert.match(source.workSessionService,/UPCWorkSessionRepository/);
assert.doesNotMatch(source.db,/findAceMiscSnapshotRepairCandidates|replaceAceMiscSnapshotsForSku/,'raw database core must not own MISC session maintenance.');
assert.doesNotMatch(source.local,/findAceMiscSnapshotRepairCandidates|replaceAceMiscSnapshotsForSku/,'Local Repository must not own MISC session maintenance.');
assert.match(source.miscMaintenance,/workSessionService\.list\(\)/);
assert.match(source.miscMaintenance,/workSessionService\.save\(/);
assert.match(source.miscMaintenance,/draftModel\.applySnapshot\(next,snapshot\)/,'MISC repair must mutate saved drafts through the canonical draft model.');
assert.doesNotMatch(source.miscMaintenance,/UPCDB\.(?:get|put|all|remove)\(\s*['"]lists['"]/,'MISC maintenance must not bypass Work Session persistence.');
assert.match(source.catalogMaintenance,/miscMaintenanceService\.findSnapshotRepairCandidates\(\)/);
assert.match(source.catalogMaintenance,/miscMaintenanceService\.replaceSnapshotsForSku\(/);
assert.match(webRuntime,/UPCMasterRepository/);
assert.match(webRuntime,/UPCLocalRepository/);
assert.match(webRuntime,/UPCIdentifierRelationshipService/);assert.doesNotMatch(source.app,/UPCIdentityRepository\./,'Current application shell must not bypass the relationship service.');
assert.match(webRuntime,/UPCMigrationRepository/);
assert.match(source.effective,/UPCMasterRepository/);
assert.match(source.effective,/UPCLocalRepository/);
assert.match(source.relationship,/UPCIdentityRepository/);
assert.match(source.localIdentifier,/UPCIdentifierRelationshipService/);assert.match(source.localIdentifier,/UPCEffectiveCatalogResolver/);
assert.match(source.miscResolution,/UPCEffectiveCatalogResolver/,'MISC resolution must consume Effective Catalog.');
assert.doesNotMatch(source.misc,/UPCEffectiveCatalogResolver/,'MISC export/domain mapping must not perform catalog resolution.');
assert.match(source.misc,/UPCIdentifierRelationshipService/);assert.doesNotMatch(source.misc,/UPCIdentityRepository\./,'ACE MISC must not bypass the relationship service.');
assert.match(source.workflow,/UPCMasterRepository/);
assert.match(source.workflow,/UPCLocalRepository/);



const wsCalls=[];
const wsContext={
 window:{},
 UPCDB:{
  all:async store=>{wsCalls.push(['all',store]);return[]},
  get:async(store,id)=>{wsCalls.push(['get',store,id]);return null},
  put:async(store,value)=>{wsCalls.push(['put',store,plain(value)]);return value},
  remove:async(store,id)=>{wsCalls.push(['remove',store,id]);return true}
 }
};
vm.createContext(wsContext);
vm.runInContext(source.workSessionRepository,wsContext,{filename:paths.workSessionRepository});
wsContext.UPCWorkSessionRepository=wsContext.window.UPCWorkSessionRepository;
vm.runInContext(source.workSessionService,wsContext,{filename:paths.workSessionService});
const workSessions=wsContext.window.UPCWorkSessionService;
const legacySession={id:'legacy-no-timestamps',items:[]};
await workSessions.save(legacySession,{touch:false});
assert.equal(Object.prototype.hasOwnProperty.call(legacySession,'createdAt'),false,'legacy persistence must not synthesize createdAt');
assert.equal(Object.prototype.hasOwnProperty.call(legacySession,'updatedAt'),false,'legacy persistence must not synthesize updatedAt when touch is false');
const ordinarySession={id:'ordinary',createdAt:'2000-01-01T00:00:00.000Z',updatedAt:'2000-01-01T00:00:00.000Z'};
await workSessions.save(ordinarySession);
assert.notEqual(ordinarySession.updatedAt,'2000-01-01T00:00:00.000Z','ordinary save must retain prior updatedAt-touch behavior');
assert.equal(ordinarySession.createdAt,'2000-01-01T00:00:00.000Z','ordinary save must preserve createdAt');

const migrationMeta=new Map([['migration.stage9.deprecatedRetirement',{key:'migration.stage9.deprecatedRetirement',applied:true}]]);
const migrationSessions=[{id:'legacy-existing',defaultTag:'Not in File',items:[{id:'i1',tags:['Not in File'],price:'$2.50'}]}],migrationSaves=[];
const legacyStorage=new Map([['upcFieldLists.v0.01',JSON.stringify([{id:'legacy-local-storage',items:[],captures:[]}])]]);
const stage2MigrationContext={
 window:{},
 UPCIdentifierNormalization:{normalizeSKU:v=>String(v??'').trim()},
 UPCWorkSessionService:{
  list:async()=>migrationSessions,
  save:async(session)=>{migrationSaves.push(plain(session));const i=migrationSessions.findIndex(x=>x.id===session.id);if(i>=0)migrationSessions[i]=session;else migrationSessions.push(session);return session}
 },
 UPCDB:{
  get:async(store,key)=>store==='meta'?(migrationMeta.get(key)||null):null,
  put:async(store,value)=>{assert.equal(store,'meta');migrationMeta.set(value.key,plain(value));return value}
 }
};
vm.createContext(stage2MigrationContext);vm.runInContext(source.migration,stage2MigrationContext,{filename:paths.migration});
const boundedMigration=stage2MigrationContext.window.UPCMigrationRepository;
const storageFacade={getItem:key=>legacyStorage.get(key)||null,removeItem:key=>legacyStorage.delete(key)};
const firstMigration=plain(await boundedMigration.prepareWorkSessions({storage:storageFacade}));
assert.equal(firstMigration.appliedNow,true,'first Work Session migration must apply once');
assert.equal(firstMigration.legacyImported,1);
assert.equal(firstMigration.sessionsUpdated,2);
assert.equal(legacyStorage.has('upcFieldLists.v0.01'),false,'legacy localStorage payload must retire after import');
assert.equal(migrationMeta.get('migration.workSessions.v279Normalization').applied,true,'bounded migration marker must persist');
const savesAfterFirst=migrationSaves.length;
const secondMigration=plain(await boundedMigration.prepareWorkSessions({storage:storageFacade}));
assert.equal(secondMigration.appliedNow,false,'bounded Work Session migration must be marker-idempotent');
assert.equal(migrationSaves.length,savesAfterFirst,'marker-backed rerun must not rescan or rewrite Work Sessions');


const badRow=Array(33).fill('');
badRow[3]='SPECS';badRow[23]='BAD';badRow[24]='';badRow[25]='';
const protectedRow=Array(33).fill('');protectedRow[3]='Protected';protectedRow[11]='1';protectedRow[23]='60';protectedRow[24]='610';protectedRow[25]='03';
const miscSessions=[{id:'m1',sessionType:'ACE_NEW_ITEMS_MISC',items:[
 {sku:'100',aceMiscSnapshot:{source:'ACENET_ONLY',baseRow:badRow}},
 {sku:'100',aceMiscSnapshot:{source:'MASTER_LIBRARY_PLUS_ACENET_UPCS',baseRow:protectedRow}}
]}];
const savedSessions=[];
let repairDraftApplications=0;
const miscContext={window:{}};
vm.createContext(miscContext);
vm.runInContext(source.miscMaintenance,miscContext,{filename:paths.miscMaintenance});
const miscMaintenance=miscContext.window.UPCMiscMaintenanceService.create({
 workSessionService:{list:async()=>miscSessions,save:async session=>{savedSessions.push(plain(session));return session}},
 draftModel:{applySnapshot:(item,snapshot)=>{repairDraftApplications++;item.aceMiscSnapshot={...snapshot};return true}},
 normalizeSku:v=>String(v??'').trim().toLowerCase(),
 normalizeWeight:v=>String(v??'').trim()
});
const repairCandidates=plain(await miscMaintenance.findSnapshotRepairCandidates());
assert.equal(repairCandidates.length,1);
assert.equal(repairCandidates[0].sku,'100');
assert.ok(repairCandidates[0].reasons.includes('description'));
assert.ok(repairCandidates[0].reasons.includes('commodityGroup'));
const replacement={source:'ACENET_REPAIRED',baseRow:protectedRow};
assert.deepEqual(plain(await miscMaintenance.replaceSnapshotsForSku('100',replacement)),{listsUpdated:1,itemsUpdated:1});
assert.equal(savedSessions.length,1);
assert.equal(savedSessions[0].items[0].aceMiscSnapshot.source,'ACENET_REPAIRED');
assert.equal(savedSessions[0].items[1].aceMiscSnapshot.source,'MASTER_LIBRARY_PLUS_ACENET_UPCS');
assert.equal(repairDraftApplications,1,'only the repairable MISC item must pass through the canonical draft snapshot boundary');

assert.match(source.db,/const DB='upc-list-builder',VER=9/,'Current location upgrade preserves repository facades under schema 9');
for(const store of ['lists','library','meta','diagnostics','libraryUpdateQueue','skuUpcs','skuIdentity','upcIdentityResolution','identityResearchQueue'])assert.ok(source.db.includes(`createObjectStore('${store}'`),`existing store must remain: ${store}`);

console.log('Stage 2 repository facade boundaries PASS');
