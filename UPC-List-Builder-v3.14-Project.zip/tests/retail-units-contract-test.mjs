import fs from 'node:fs';import vm from 'node:vm';import assert from 'node:assert/strict';
import {readWebRuntimeSource,readNativeRuntimeSource,findJsFunction} from './helpers/runtime-source-tree.mjs';
const source=readWebRuntimeSource(),resolverSource=fs.readFileSync('app/src/main/assets/www/catalog/retail-units-resolver.js','utf8'),contract=fs.readFileSync('RETAIL_UNITS_CONTRACT.md','utf8');
assert.match(contract,/## Current Local Library fallback/);
assert.match(contract,/STATUS: CURRENT/);
const fn=findJsFunction('resolveAceNetRetailUnits');
assert.doesNotMatch(fn,/requestAceNetPrice|lookupAceNetPrice/,'Retail Units must never trigger AceNet.');
assert.match(fn,/effectiveResolver\.inspectSKU\(key\)/,'Retail Units must use Effective Catalog for Master/Local evidence.');
assert.doesNotMatch(fn,/UPCMasterRepository\.|UPCLocalRepository\./,'Retail Units must not read catalog repositories directly.');
assert.match(fn,/DEFAULT_NO_LIBRARY_RU/);assert.match(fn,/DEFAULT_LIBRARY_LOOKUP_FAILED/);assert.match(fn,/startOperation\('RETAIL_UNITS'/);assert.match(fn,/finishOperation/);
async function run(master,local){const completed=[],c={window:{},Object,Date,Math,String,Number};vm.createContext(c);vm.runInContext(resolverSource,c,{filename:'retail-units-resolver.js'});const api=c.window.UPCRetailUnitsResolver.create({effectiveResolver:{inspectSKU:async()=>({master,local})},normalizeSku:x=>String(x),diagnostic:()=>{},startOperation:()=>{},finishOperation:(...x)=>completed.push(x)});return{out:await api.resolveAceNetRetailUnits('123'),completed}}
let x=await run({count:1,row:{id:7,fields:{'Retail Units':12}}},{count:1,row:{id:'local',fields:{'Retail Units':8}}});assert.equal(x.out.value,'12');assert.equal(x.out.source,'MASTER_LIBRARY');
x=await run({count:0,row:null},{count:1,row:{id:'local',fields:{'Retail Units':8}}});assert.equal(x.out.value,'8');assert.equal(x.out.source,'LOCAL_LIBRARY');
x=await run({count:0,row:null},{count:0,row:null});assert.equal(x.out.value,'1');assert.equal(x.out.source,'DEFAULT_NO_LIBRARY_RU');
console.log('Retail Units v2.64 Master -> Local -> default contract requirements PASS');
