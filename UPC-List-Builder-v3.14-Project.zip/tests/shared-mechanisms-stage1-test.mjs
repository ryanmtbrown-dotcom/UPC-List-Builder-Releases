import {readWebRuntimeSource,readNativeRuntimeSource} from './helpers/runtime-source-tree.mjs';
import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';

const read=p=>fs.readFileSync(p,'utf8');
const identifierSource=read('app/src/main/assets/www/identifier-normalization.js');
const trackerSource=read('app/src/main/assets/www/operation-tracker.js');
const app=readWebRuntimeSource();
const shell=read('app/src/main/assets/www/application/application-shell.js');
const operationService=read('app/src/main/assets/www/diagnostics/diagnostic-operation-service.js');
const db=read('app/src/main/assets/www/db.js');
const importer=read('app/src/main/assets/www/xlsx-importer.js');
const misc=read('app/src/main/assets/www/ace-misc.js');
const workflow=read('app/src/main/assets/www/library-workflow-v093.js');
const index=read('app/src/main/assets/www/index.html');
const main=read('app/src/main/java/com/rmtb/upclistbuilder/MainActivity.kt');
const downloads=read('app/src/main/java/com/rmtb/upclistbuilder/NativeDownloadsWriter.kt');
const native=readNativeRuntimeSource();

const identifierContext={window:{}};
vm.createContext(identifierContext);
vm.runInContext(identifierSource,identifierContext,{filename:'identifier-normalization.js'});
const ids=identifierContext.window.UPCIdentifierNormalization;
assert.ok(ids);
assert.equal(ids.normalizeSKU(' 30 22333D '),'3022333');
assert.equal(ids.normalizeSKU('ＡＢＣ d'),'abc');
assert.equal(ids.normalizeSKU(null),'');
assert.equal(ids.normalizeUPC(' ０829-01 234 567 '),'82901234567','ASCII-only UPC normalization must not convert full-width digits');
assert.equal(ids.normalizeUPC('UPC: 123-45'),'12345');
assert.equal(ids.normalizeUPC(null),'');
assert.equal(ids.normalizeUPCUnicodeCompatible(' ０829-01 234 567 '),'082901234567','spreadsheet/general-input compatibility must preserve NFKC behavior');

for(const [name,source] of [['db',db],['app',app],['xlsx importer',importer],['ACE MISC',misc],['library workflow',workflow]]){
 assert.match(source,/UPCIdentifierNormalization/,`${name} must route identifier normalization through the shared owner`);
}
const webFiles=fs.readdirSync('app/src/main/assets/www').filter(x=>x.endsWith('.js'));
const skuRule=/normalize\('NFKC'\)\.replace\(\/\\s\+\/g,''\)\.replace\(\/d\$\/i,''\)\.toLowerCase\(\)/g;
let skuRuleCount=0;
for(const file of webFiles)skuRuleCount+=(read('app/src/main/assets/www/'+file).match(skuRule)||[]).length;
assert.equal(skuRuleCount,1,'the SKU normalization rule must exist in exactly one first-party web owner');
assert.match(importer,/normalizeUPCUnicodeCompatible/,'XLSX import must retain Unicode-compatible UPC normalization');
assert.match(shell,/const normalizeUPC=UPCIdentifierNormalization\.normalizeUPCUnicodeCompatible/,'general app UPC input must retain its prior Unicode-compatible rule');
assert.match(shell,/const normalizeAceNetUPC=UPCIdentifierNormalization\.normalizeUPC/,'AceNet UPC evidence must retain prior ASCII-digit normalization');
assert.match(db,/normalizeImportedUPC=UPCIdentifierNormalization\.normalizeUPCUnicodeCompatible/,'Master reindex must retain prior Unicode-compatible UPC normalization');
assert.equal((importer.match(/function cellValue\(/g)||[]).length,1,'XLSX cell parser must be singular');
assert.equal((importer.match(/function rowArray\(/g)||[]).length,1,'XLSX row parser must be singular');

const trackerContext={window:{},performance:{now:()=>0}};
vm.createContext(trackerContext);
vm.runInContext(trackerSource,trackerContext,{filename:'operation-tracker.js'});
const trackerApi=trackerContext.window.UPCOperationTracker;
let clock=100;
const retained=trackerApi.create({now:()=>clock,reuseActive:true,retainCompleted:true});
const first=retained.start('A',{what:'test'});
assert.equal(first.reused,false);
clock=125;
assert.equal(retained.observe('A').durationMs,25);
assert.equal(retained.start('A',{what:'ignored while active'}).reused,true);
clock=160;
const finished=retained.finish('A');
assert.equal(finished.durationMs,60);
assert.equal(finished.duplicate,false);
clock=200;
const duplicate=retained.finish('A');
assert.equal(duplicate.duplicate,true);
assert.equal(duplicate.durationMs,60);
assert.equal(retained.peek('A').what,'test');
const transient=trackerApi.create({now:()=>clock});
transient.start('B');clock=230;assert.equal(transient.finish('B').durationMs,30);assert.equal(transient.peek('B'),null);
assert.equal(transient.finish('missing').missing,true);

assert.doesNotMatch(app,/startupOperationState|lookupOperationState|subsystemOperationState/);
assert.match(operationService,/operationTracker\.create/);
for(const eventName of ['item_search_operation_started','item_search_operation_completed','item_search_operation_observation','subsystem_operation_started','subsystem_operation_completed','startup_operation_started','startup_operation_completed','startup_operation_observation','startup_operation_duplicate_completion_ignored'])assert.ok(operationService.includes(`'${eventName}'`),`domain diagnostic event must remain at diagnostic operation owner: ${eventName}`);
assert.ok(index.indexOf('identifier-normalization.js')<index.indexOf('db.js'),'identifier normalization must load before persistence');
assert.ok(index.indexOf('operation-tracker.js')<index.indexOf('diagnostics/diagnostic-operation-service.js'),'operation tracker must load before diagnostic operation owner');assert.ok(index.indexOf('diagnostics/diagnostic-operation-service.js')<index.indexOf('application/application-shell.js'),'diagnostic operation owner must load before the application composition root');

assert.match(downloads,/object NativeDownloadsWriter/);
assert.match(downloads,/@RequiresApi\(Build\.VERSION_CODES\.Q\)/);
assert.equal((downloads.match(/MediaStore\.Downloads\.EXTERNAL_CONTENT_URI/g)||[]).length,2,'both single-file and incremental Downloads are implemented by the ONE shared native Downloads owner');
assert.doesNotMatch(main,/\bContentValues\b|\bMediaStore\.Downloads\b/,'MainActivity must not duplicate Downloads-writing mechanics');
assert.equal((native.match(/NativeDownloadsWriter\.write/g)||[]).length,1,'ordinary native file export must use shared one-shot Downloads writer');
assert.match(native,/PendingDiagnosticDownload/,'diagnostic export uses shared incremental writer');
assert.match(downloads,/getExternalFilesDir\(Environment\.DIRECTORY_DOWNLOADS\)/,'diagnostic pre-Q fallback remains in the shared Downloads owner');
assert.match(main,/UPCNativeExportStatus/);
assert.match(main,/UPCNativeDiagnosticExportStatus/);
assert.match(main,/UPCNativeDiagnosticExportTransferEvent/);

console.log('Stage 1 shared mechanisms semantic requirements PASS');
