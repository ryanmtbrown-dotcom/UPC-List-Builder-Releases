import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';

const ROOT=process.cwd();
const read=rel=>fs.readFileSync(path.join(ROOT,rel),'utf8');
const exists=rel=>fs.existsSync(path.join(ROOT,rel));
const stripOwnership=source=>source.replace(/^\/\*\*?[\s\S]*?\*\/\s*/,'');
const walk=dir=>{
  const out=[];
  for(const entry of fs.readdirSync(path.join(ROOT,dir),{withFileTypes:true})){
    const rel=path.posix.join(dir,entry.name);
    if(entry.isDirectory()) out.push(...walk(rel));
    else out.push(rel);
  }
  return out;
};

const webFiles=walk('app/src/main/assets/www')
  .filter(p=>/\.(?:js|css)$/.test(p))
  .filter(p=>!p.includes('/vendor/')&&!p.endsWith('.min.js'));
const nativeFiles=walk('app/src/main/java/com/rmtb/upclistbuilder').filter(p=>p.endsWith('.kt'));
const production=[...webFiles,...nativeFiles];

assert.ok(production.length>=99,'expected the maintained first-party production source set');
for(const rel of production){
  const source=read(rel);
  const head=source.slice(0,8000);
  assert.equal((head.match(/OWNERSHIP:/g)||[]).length,1,`${rel}: exactly one OWNERSHIP header required`);
  for(const field of ['File:','Owner:','Role:','Responsibility:','Does not own:','Side effects:','Related code:']){
    assert.ok(head.includes(field),`${rel}: ownership header missing ${field}`);
  }
  assert.ok(head.includes(`File: ${rel}`),`${rel}: ownership header path must match source location`);
}

const directoryDocs=[
 'app/src/main/assets/www/README.md',
 'app/src/main/assets/www/administration/README.md',
 'app/src/main/assets/www/application/README.md',
 'app/src/main/assets/www/catalog/README.md',
 'app/src/main/assets/www/diagnostics/README.md',
 'app/src/main/assets/www/dsd/README.md',
 'app/src/main/assets/www/field-session/README.md',
 'app/src/main/assets/www/identity/README.md',
 'app/src/main/assets/www/lookup/README.md',
 'app/src/main/assets/www/misc/README.md',
 'app/src/main/assets/www/platform/README.md',
 'app/src/main/assets/www/pricing/README.md',
 'app/src/main/assets/www/scanner/README.md',
 'app/src/main/assets/www/work-sessions/README.md',
 'app/src/main/java/com/rmtb/upclistbuilder/README.md'
];
for(const rel of directoryDocs){
 assert.ok(exists(rel),`missing directory ownership document: ${rel}`);
 const text=read(rel);
 assert.match(text,/OWNS:/,`${rel}: directory scope must identify ownership`);
 assert.match(text,/DOES NOT OWN:/,`${rel}: directory scope must identify exclusions`);
}

for(const rel of ['AI_START_HERE.md','DOCUMENTATION_INDEX.md','CURRENT_ARCHITECTURE_AUTHORITY.md','SOURCE_OWNERSHIP_MAP.md']){
 assert.ok(exists(rel),`missing current architecture authority: ${rel}`);
}

const forbiddenHistorical=[
 'ARCHITECTURE_REFACTOR_TRANSITION_AUTHORITY.md',
 'ARCHITECTURE_REFACTOR_TROUBLESHOOTING_LEDGER.md',
 'UPC_List_Builder_Architecture_Refactor_HANDOFF_Stage7_COMPLETE_2026-10-02.md',
 'research/acenet_retrieval_vnext'
];
for(const rel of forbiddenHistorical) assert.ok(!exists(rel),`historical/obsolete source must not remain active: ${rel}`);

const activeDocs=[
 ...fs.readdirSync(ROOT).filter(name=>name.endsWith('.md')),
 ...directoryDocs
];
for(const rel of activeDocs){
 const text=read(rel);
 for(const forbidden of forbiddenHistorical.slice(0,3)){
   assert.ok(!text.includes(forbidden),`${rel}: stale reference to deleted historical document ${forbidden}`);
 }
}

const html=read('app/src/main/assets/www/index.html');
const loaded=new Set([...html.matchAll(/(?:src|href)="([^"]+\.(?:js|css))(?:\?[^"]*)?"/g)]
  .map(m=>path.posix.join('app/src/main/assets/www',m[1].replace(/^\.\//,''))));
const unreferenced=webFiles.filter(p=>p!=='app/src/main/assets/www/service-worker.js'&&!loaded.has(p));
assert.deepEqual(unreferenced,[],'first-party web JS/CSS must be reachable from the active page or be the service worker');

const rawDbAllowed=new Set([
 'app/src/main/assets/www/application/application-shell.js',
 'app/src/main/assets/www/data-backup.js',
 'app/src/main/assets/www/identity-repository.js',
 'app/src/main/assets/www/local-repository.js',
 'app/src/main/assets/www/master-repository.js',
 'app/src/main/assets/www/store-locations/location-repository.js',
 'app/src/main/assets/www/migration-repository.js',
 'app/src/main/assets/www/work-sessions/work-session-repository.js'
]);
const rawDbUsers=webFiles.filter(p=>stripOwnership(read(p)).includes('UPCDB.'));
assert.deepEqual(new Set(rawDbUsers),rawDbAllowed,'raw UPCDB access escaped approved repository/backup/migration owners');

const globalIndexedDbUsers=webFiles.filter(p=>/\bindexedDB\b/.test(stripOwnership(read(p))));
assert.deepEqual(globalIndexedDbUsers,['app/src/main/assets/www/db.js'],'global indexedDB access must remain isolated to db.js');

const authority=read('SOURCE_OWNERSHIP_MAP.md');
for(const marker of [
 '## Dependency direction',
 '## Authoritative responsibility map',
 '## State ownership',
 '## Side-effect ownership',
 '## Lifecycle ownership',
 '## Boundary contracts',
 '## Critical workflow maps',
 '## Obsolete/deprecated-code rule'
]) assert.ok(authority.includes(marker),`SOURCE_OWNERSHIP_MAP missing ${marker}`);

const requiredOwners=[
 'application/application-shell.js',
 'application/startup-orchestrator.js',
 'lookup/normal-lookup-controller.js',
 'work-sessions/work-session-service.js',
 'diagnostics/diagnostic-service.js',
 'dsd/dsd-workspace-controller.js',
 'misc/misc-workspace-controller.js',
 'platform/file-export-delivery-service.js',
 'MainActivity.kt',
 'AceNetProductionCoordinator.kt'
];
for(const owner of requiredOwners) assert.ok(authority.includes(owner),`ownership map missing authoritative owner: ${owner}`);

const currentBehaviorDocs=[
 'REPOSITORY_BOUNDARIES_CONTRACT.md',
 'ACENET_AUTH_SESSION_CONTRACT.md','ACENET_CLIENT_BROKER_CONTRACT.md','ACENET_COMPARISON_TOGGLE_CONTRACT.md',
 'ACENET_ITEM_DATA_EXTRACTION_REFERENCE.md','ACENET_ITEM_RETRIEVAL_CONTRACT.md','ACENET_SERVICE_HEALTH_CONTRACT.md',
 'ACENET_SESSION_RETRIEVAL_BOUNDARY_CONTRACT.md','ACE_MISC_ADDITIONAL_UPC_CONTRACT.md',
 'APPLICATION_DATA_BACKUP_CONTRACT.md','APPLICATION_LIFECYCLE_CONTRACT.md','CATALOG_FIELD_MAPPING_CONTRACT.md',
 'CATALOG_REFRESH_POLICY_CONTRACT.md','COMBINED_MASTER_EXPORT_CONTRACT.md','DEPLOYMENT_CONTRACT.md','DIAGNOSTICS_CONTRACT.md',
 'DIAGNOSTIC_EXPORT_CONTRACT.md','EFFECTIVE_CATALOG_RESOLVER_CONTRACT.md','IDENTIFIER_RELATIONSHIP_SERVICE_CONTRACT.md',
 'IDENTIFIER_RESOLUTION_CONTRACT.md','ITEM_PRESENTATION_CONTRACT.md','LIST_MANAGEMENT_CONTRACT.md',
 'LOCAL_IDENTIFIER_RESOLVER_CONTRACT.md','MASTER_LIBRARY_CONTRACT.md','NAVIGATION_CONTRACT.md',
 'NETWORK_CONNECTIVITY_CONTRACT.md','NORMAL_ITEM_SEARCH_CONTRACT.md','NATIVE_ANDROID_BRIDGE_CONTRACT.md',
 'NATIVE_TRACE_CONTRACT.md','PRICE_AUTHORITY_CONTRACT.md','PRODUCT_IDENTITY_INDEX_CONTRACT.md',
 'RETAIL_UNITS_CONTRACT.md','SETTINGS_PERSISTENCE_CONTRACT.md','UI_OPERATION_LIFECYCLE_CONTRACT.md'
];
for(const rel of currentBehaviorDocs){
 const doc=read(rel);
 assert.doesNotMatch(doc,/(?:^|\n)\s*(?:\*\*)?STATUS:\s*PROVISIONAL\b/mi,`${rel}: active current contract must not retain provisional document status`);
 assert.doesNotMatch(doc,/^##\s+v\d+\.\d+/mi,`${rel}: active current contract must not retain version-amendment chronology`);
 assert.doesNotMatch(doc,/rollback baseline/i,`${rel}: Git history, not the active contract, owns rollback chronology`);
 assert.doesNotMatch(doc,/architecture Stage\s+\d+/i,`${rel}: active current contract must describe ownership directly rather than stage chronology`);
}

console.log(`Current source ownership audit PASS: ${production.length} production files, ${directoryDocs.length} directory scopes; ${currentBehaviorDocs.length} current behavioral documents`);
