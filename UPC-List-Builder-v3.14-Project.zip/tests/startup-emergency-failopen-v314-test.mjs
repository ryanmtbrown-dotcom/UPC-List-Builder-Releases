import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';

const ace=fs.readFileSync('app/src/main/assets/www/application/acenet-startup-service.js','utf8');
const startup=fs.readFileSync('app/src/main/assets/www/application/startup-orchestrator.js','utf8');
const native=fs.readFileSync('app/src/main/java/com/rmtb/upclistbuilder/AceNetProductionCoordinator.kt','utf8');
const context={window:{},setTimeout,clearTimeout,console};
vm.createContext(context);
vm.runInContext(ace,context,{filename:'acenet-startup-service.js'});

const state={startupStatus:'PENDING',authenticated:false,healthStatus:'CHECKING',message:''};
let nativeStatus={startupResolved:false,authenticated:false,healthStatus:'CHECKING'};
let started=0;
const events=[];
const service=context.window.UPCAceNetStartupService.create({
 diagnostic:(event,details)=>events.push({event,details}),
 nativeBridgeProvider:()=>({
  beginAceNetStartup(){started++},
  getAceNetLoginStatus(){return JSON.stringify(nativeStatus)}
 }),
 getRuntimeState:()=>state,
 normalizeHealthStatus:x=>String(x).toUpperCase(),
 refreshLoginStatus(){},
 reconcileAutomaticPricing(){},
 syncFeatureUi(){},
 reportStartupProgress(){}
});
const result=await Promise.race([
 service.run({maxWaitMs:15}),
 new Promise((_,reject)=>setTimeout(()=>reject(new Error('AceNet startup blocked past fail-open deadline')),300))
]);
assert.equal(started,1);
assert.equal(result.ready,false);
assert.equal(result.healthStatus,'UNAVAILABLE');
assert.equal(result.knownUnavailable,true);
assert.equal(state.healthStatus,'UNAVAILABLE');
assert.ok(events.some(x=>x.event==='acenet_startup_ui_deadline_reached'));
assert.match(startup,/const startupCeilingMs=30000/);
assert.match(startup,/ordinaryElapsedMs\(\)/);
assert.match(startup,/runAceNetStartup\(\{maxWaitMs:budgetMs\}\)/);
assert.match(startup,/state==='DOWNLOADING'\|\|state==='INSTALLING'/);
assert.match(native,/private val aceNetStartupReadinessHandler/);
assert.match(native,/startup_session_absolute_deadline_reached/);
assert.match(native,/beginAceNetStartupReadinessDeadline\(\)/);
assert.match(native,/releaseAceNetStartupReadinessDeadline\(\)/);
assert.match(native,/if\(!productionRepair && !bridgeTest\)releaseAceNetStartupReadinessDeadline\(\)/);

nativeStatus={startupResolved:true,authenticated:true,healthStatus:'ONLINE'};
service.acceptNativeStartupStatus({status:'SIGNED_IN',authenticated:true,healthStatus:'ONLINE',startupResolved:true,message:'AceNet ready.'});
assert.equal(state.healthStatus,'ONLINE','late successful native proof must restore online after splash releases');
assert.equal(state.authenticated,true);
console.log('Emergency v3.14 native/readiness deadline + web fail-open + late recovery PASS');
