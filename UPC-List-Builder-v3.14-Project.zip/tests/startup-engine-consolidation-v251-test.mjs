import {readWebRuntimeSource,readNativeRuntimeSource} from './helpers/runtime-source-tree.mjs';
import fs from 'node:fs';
import assert from 'node:assert/strict';

const main=readNativeRuntimeSource();
const service=fs.readFileSync('app/src/main/java/com/rmtb/upclistbuilder/AceNetRetrievalService.kt','utf8');
const worker=fs.readFileSync('app/src/main/java/com/rmtb/upclistbuilder/PersistentAceNetWorker.kt','utf8');
const html=fs.readFileSync('app/src/main/assets/www/index.html','utf8');
const app=readWebRuntimeSource();
const startup=fs.readFileSync('app/src/main/assets/www/application/startup-orchestrator.js','utf8');
const aceStartup=fs.readFileSync('app/src/main/assets/www/application/acenet-startup-service.js','utf8');

assert.match(main,/startup_bootstrap_template_ready/);
assert.match(main,/transientRetailerExtractionSkipped/);
assert.match(main,/handoffToPersistentWorker/);
assert.match(main,/if\(result\.optString\("mode"\)!="WRAPPER"\)/,'transient bridge must accept readiness wrapper evidence only');

const observedStart=main.indexOf('private fun handleAceNetObservedResult');
const observedEnd=main.indexOf('private fun finishAceNetTest',observedStart);
const observed=main.slice(observedStart,observedEnd);
assert.match(observed,/startup_bootstrap_template_ready/);
assert.match(observed,/sourceView\.loadUrl\(frameUrl\)/,'startup bootstrap must enter retailer realm to establish session readiness');
assert.match(observed,/transient_item_retrieval_forbidden/,'non-readiness transient item retrieval must be guarded');

const ready=main.indexOf('startup_retailer_session_ready');
const verify=main.indexOf('startAceNetStartupPersistentVerification(template,1)',ready);
assert.ok(ready>=0&&verify>ready,'persistent verification must follow retailer-session establishment');
assert.match(main,/aceNetSessionManager\.markRetailerSessionReady\(\)/,'session manager must own retailer readiness transition');
assert.match(main,/aceNetHealthStatus="ONLINE"/);
assert.match(main,/aceNetHealthStatus="UNAVAILABLE"/);
assert.match(main,/completeAceNetStartupAuthentication/);
assert.doesNotMatch(main,/completeAceNetStartupInconclusive/,'obsolete terminal UNKNOWN path must remain removed');

assert.match(main,/private fun startProductionAceNetLookup/);
const production=main.slice(main.indexOf('private fun startProductionAceNetLookup'),main.indexOf('private fun startDeferredAceNetCatalogLookup'));
assert.match(production,/aceNetRetrievalService\.search/,'production retrieval must use retrieval service');
assert.match(production,/beginAceNetProductionSoftRepair/,'authenticated production recovery must expose a soft retained-session repair path');
assert.match(production,/beginAceNetProductionHardRepair/,'production recovery must expose one bounded full session repair path');
assert.doesNotMatch(production,/startAceNetTest\(/,'production fallback must not revive transient extraction');
assert.match(service,/PersistentAceNetWorker\(activity, emit, complete\)/);
assert.doesNotMatch(main,/PersistentAceNetWorker\(this|=\s*PersistentAceNetWorker/,'MainActivity must not directly own the worker');

const updateIndex=startup.indexOf('await awaitUpdateDecision()'),dataIndex=startup.indexOf('await prepareSavedData()'),masterIndex=startup.indexOf('await Promise.all([refreshLibraryStatus(),refreshSavedListSummary()])'),aceIndex=startup.indexOf('await runAceNetStartup({maxWaitMs:budgetMs})');
assert.ok(updateIndex>=0&&dataIndex>updateIndex&&masterIndex>dataIndex&&aceIndex>masterIndex,'startup must serialize update decision -> local data -> Master/Local readiness -> AceNet release');
assert.match(startup,/beginStartupUpdateCheck\(appVersion\)/,'web startup owner must explicitly begin the update prerequisite');
assert.match(aceStartup,/canBegin=typeof bridge\?\.beginAceNetStartup==='function'/,'AceNet startup owner must verify the native startup capability before release');
assert.match(aceStartup,/bridge\.beginAceNetStartup\(\)/,'AceNet startup capability must explicitly release native AceNet after orchestrated prerequisites');
assert.doesNotMatch(main,/view\?\.postDelayed\(\{ checkForUpdateAsync[\s\S]*view\?\.post \{ recordStartupNetworkPreflight\(\); beginAceNetStartupAuthentication\(\) \}/,'main page load must not restart parallel updater/AceNet startup');
assert.match(main,/@JavascriptInterface fun beginStartupUpdateCheck/);
assert.match(main,/@JavascriptInterface fun beginAceNetStartup/);

assert.match(worker,/PRODUCTION_PRICE/);
assert.match(worker,/PRODUCTION_UPCS/);
assert.match(worker,/PRODUCTION_CATALOG/);
assert.doesNotMatch(main,/AceNetUpcRouteLab|startAceNetUpcRouteLab|cancelAceNetUpcRouteLab/);
assert.doesNotMatch(html,/ACENET UPC ROUTE LABORATORY|aceNetUpcLab/);
assert.doesNotMatch(app,/runAceNetUpcRouteLab|cancelAceNetUpcRouteLab|UPCNativeAceNetUpcRouteLabResult/);
console.log('startup engine consolidation with Stage 6 session/retrieval boundaries PASS');
