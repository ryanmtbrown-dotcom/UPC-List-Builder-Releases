import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';

const source=fs.readFileSync('app/src/main/assets/www/application/settings-controller.js','utf8');

function harness(startupStatus,authenticated,healthStatus){
 const runtime={startupStatus,authenticated,healthStatus},events=[];
 const context={window:{},console};
 vm.createContext(context);vm.runInContext(source,context,{filename:'settings-controller.js'});
 const api=context.window.UPCSettingsController.create({
  elementById:()=>null,queryAll:()=>[],escapeHtml:v=>String(v),getCurrentSession:()=>null,saveCurrentSession:async()=>{},
  diagnostic:(event,data)=>events.push({event,data}),startOperation:()=>{},finishOperation:()=>{},
  getAceNetRuntimeState:()=>runtime,normalizeAceNetHealthStatus:v=>['ONLINE','DOWN','UNAVAILABLE','DEGRADED','CHECKING'].includes(String(v||'').toUpperCase())?String(v).toUpperCase():null,unknownHealth:null,
  nativeBridgeProvider:()=>null,showScreen:()=>{},refreshIdentityWorkQueues:()=>{},refreshDatabaseViewerSummary:()=>{},
  exportSchema:{MASTER_HEADERS:['ACE SKU'],ACE_MISC_HEADERS:['ACE SKU','POSDEPT','VENDOR','S/O (72) Y'],normalizeMasterSelection:headers=>Array.isArray(headers)?headers.filter(header=>header==='ACE SKU'):[],defaultMasterSelection:()=>['ACE SKU']},
  initializeExportPreferences:async defaults=>({headers:[...defaults],forceAceMiscFormat:true}),saveExportPreferences:async()=>{}
 });
 return{api,runtime,events};
}

const online=harness('SIGNED_IN',true,'ONLINE');
online.api.reconcileAceNetAutomaticPricing('startup_online');
assert.equal(online.api.aceNetPriceCheckEnabled(),true,'ONLINE startup must default comparison ON.');
assert.equal(online.api.aceNetUpcEnrichmentEnabled(),true,'ONLINE startup must default UPC enrichment ON.');
online.api.setAceNetUpcEnrichmentEnabled(false,'user',false);
assert.equal(online.api.aceNetUpcEnrichmentEnabled(),false,'User must be able to disable UPC enrichment for the running session.');
online.api.setAceNetPriceCheckEnabled(false,'user',false);
assert.equal(online.api.aceNetPriceCheckEnabled(),false,'User must be able to disable comparison for the running session.');
assert.equal(online.api.aceNetUpcEnrichmentEnabled(),false,'Comparison OFF must make UPC enrichment effectively OFF.');
online.api.setAceNetPriceCheckEnabled(true,'user',false);
assert.equal(online.api.aceNetPriceCheckEnabled(),true);
assert.equal(online.api.aceNetUpcEnrichmentEnabled(),false,'Re-enabling comparison must restore the last session UPC preference rather than force enrichment ON.');

const unavailable=harness('UNAVAILABLE',false,'UNAVAILABLE');
unavailable.api.reconcileAceNetAutomaticPricing('startup_unavailable');
assert.equal(unavailable.api.aceNetPriceCheckEnabled(),false,'Unavailable startup must default comparison OFF.');
assert.equal(unavailable.api.aceNetUpcEnrichmentEnabled(),false,'Unavailable startup must default UPC enrichment OFF.');
assert.doesNotMatch(source,/localStorage\.setItem\(/,'v2.57 feature toggles must be session-owned.');
console.log('v2.57 AceNet startup/session feature policy PASS');
