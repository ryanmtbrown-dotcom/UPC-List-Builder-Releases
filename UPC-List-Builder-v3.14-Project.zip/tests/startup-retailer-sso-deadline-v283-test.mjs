import fs from 'node:fs';
import assert from 'node:assert/strict';

const timing=fs.readFileSync('app/src/main/java/com/rmtb/upclistbuilder/AceNetTimingPolicy.kt','utf8');
const coordinator=fs.readFileSync('app/src/main/java/com/rmtb/upclistbuilder/AceNetProductionCoordinator.kt','utf8');
const auth=fs.readFileSync('ACENET_AUTH_SESSION_CONTRACT.md','utf8');
const health=fs.readFileSync('ACENET_SERVICE_HEALTH_CONTRACT.md','utf8');

assert.match(timing,/STARTUP_SESSION_READINESS_MS = 25_000L/);
assert.match(coordinator,/if\(aceNetStartupOnly\)AceNetTimingPolicy\.STARTUP_SESSION_READINESS_MS else 60_000L/);
assert.match(coordinator,/aceNetStartupRetailerDeadlineRunnable/);
assert.match(coordinator,/aceNetPhase=="RETAILER_SSO"/);
assert.match(coordinator,/val remaining=\(aceNetAuthDeadlineMs-System\.currentTimeMillis\(\)\)\.coerceAtLeast\(1L\)/);
assert.match(coordinator,/postDelayed\(aceNetStartupRetailerDeadlineRunnable,remaining\)/);
assert.match(coordinator,/startup_retailer_sso_deadline_reached/);
assert.match(coordinator,/completeAceNetStartupUnavailable\("startup_retailer_sso_deadline"/);
assert.match(coordinator,/globalServerDownEvidence",false/);
assert.match(coordinator,/removeCallbacks\(aceNetStartupRetailerDeadlineRunnable\)/);
assert.match(coordinator,/aceNetResultHandler\.removeCallbacksAndMessages\(null\)/);
assert.match(auth,/startup session-readiness deadline/);
assert.match(health,/does not establish DOWN/);
console.log('Bounded AceNet retailer SSO session-readiness deadline v2.83 PASS');
