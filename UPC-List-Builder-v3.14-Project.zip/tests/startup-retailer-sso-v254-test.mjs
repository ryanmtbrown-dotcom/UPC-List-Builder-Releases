import {readWebRuntimeSource,readNativeRuntimeSource} from './helpers/runtime-source-tree.mjs';
import fs from 'node:fs';
import assert from 'node:assert/strict';

const main=readNativeRuntimeSource();
const app=readWebRuntimeSource();
const healthPolicy=fs.readFileSync('app/src/main/assets/www/platform/acenet-health-policy.js','utf8');
const aceStartup=fs.readFileSync('app/src/main/assets/www/application/acenet-startup-service.js','utf8');
const shell=fs.readFileSync('app/src/main/assets/www/application/application-shell.js','utf8');
const worker=fs.readFileSync('app/src/main/java/com/rmtb/upclistbuilder/PersistentAceNetWorker.kt','utf8');
const service=fs.readFileSync('app/src/main/java/com/rmtb/upclistbuilder/AceNetRetrievalService.kt','utf8');
const auth=fs.readFileSync('ACENET_AUTH_SESSION_CONTRACT.md','utf8');
const health=fs.readFileSync('ACENET_SERVICE_HEALTH_CONTRACT.md','utf8');
const retrieval=fs.readFileSync('ACENET_ITEM_RETRIEVAL_CONTRACT.md','utf8');

assert.match(auth,/## Retailer SSO/,'current authentication\/retailer SSO authority missing');
assert.match(health,/## Startup health/,'current startup service-health authority missing');
assert.match(retrieval,/## Recovery/,'current retrieval recovery authority missing');

const stsStart=main.indexOf('currentHost == "sts.aceservices.com" -> {');
const stsEnd=main.indexOf('\n                    else -> {',stsStart);
assert.ok(stsStart>=0&&stsEnd>stsStart,'STS navigation branch missing');
const sts=main.slice(stsStart,stsEnd);
assert.match(sts,/aceNetSessionRepairOnly/,'STS retailer readiness routing must include production session repair');
assert.match(sts,/aceNetRequestKind=="TEST"/,'STS retailer readiness routing must include native bridge test');
assert.match(sts,/inspectAceNetRetailerSso\(v,current\)/,'shared retailer SSO inspector missing');
assert.ok(sts.indexOf('inspectAceNetRetailerSso(v,current)') < sts.indexOf('val wasAuthenticated=aceNetSessionAuthenticated'),'legitimate retailer SSO must be classified before generic session invalidation');
assert.match(sts,/sts_login_route_selected/);
assert.match(sts,/inspectAceNetLogin\(v,current\)/,'ordinary STS login must retain saved-credential inspection');

const ssoStart=main.indexOf('private fun inspectAceNetRetailerSso');
const ssoEnd=main.indexOf('\n    private fun inspectAceNetLogin',ssoStart);
const sso=main.slice(ssoStart,ssoEnd);
assert.match(sso,/startupFlow=aceNetStartupOnly && aceNetRequestKind=="STARTUP_WARMUP"/);
assert.match(sso,/repairFlow=aceNetSessionRepairOnly/);
assert.match(sso,/testFlow=!aceNetStartupOnly && !aceNetSessionRepairOnly && aceNetRequestKind=="TEST"/);
assert.match(sso,/readinessFlow/);
assert.match(sso,/retailer_sso_transit/);
assert.match(sso,/authenticationPreserved",true/);

const readyStart=main.indexOf('val readinessHandoff=');
const readyEnd=main.indexOf('currentHost == "acenet.aceservices.com"',readyStart);
assert.ok(readyStart>=0&&readyEnd>readyStart,'retailer readiness handoff block missing');
const readyBlock=main.slice(readyStart,readyEnd);
assert.match(readyBlock,/val template=aceNetPersistentRetailerTemplate/);
assert.match(readyBlock,/preservedTemplateHasQuery/);
assert.match(readyBlock,/preservedTemplateValid/);
assert.match(readyBlock,/aceNetSessionManager\.markRetailerSessionReady\(\)/);
assert.match(readyBlock,/completeAceNetProductionSessionRepair\(template,templateValid\)/);
assert.match(readyBlock,/completeAceNetBridgeTestThroughWorker\(template,templateValid\)/);
assert.match(readyBlock,/startAceNetStartupPersistentVerification\(template,1\)/);
assert.doesNotMatch(readyBlock,/aceNetPersistentRetailerTemplate=current/);

const verifierStart=main.indexOf('private fun startAceNetStartupPersistentVerification');
const verifierEnd=main.indexOf('\n    private fun deliverAceNetProductionFailure',verifierStart);
const verifier=main.slice(verifierStart,verifierEnd);
assert.match(verifier,/aceNetRetrievalService\.prime\(template,aceNetWarmupSku\)/);
assert.match(verifier,/retryableTimeout=primeStatus=="TIMEOUT"\|\|primeStatus=="SKU_TIMEOUT"/);
assert.match(verifier,/retryableTimeout&&boundedAttempt<3/);
assert.match(verifier,/retryableTransport&&boundedAttempt<2/);
assert.match(verifier,/startAceNetStartupPersistentVerification\(template,boundedAttempt\+1\)/);
assert.match(verifier,/startup_persistent_worker_three_timeouts/);
assert.match(verifier,/startup_persistent_worker_terminal_error/);
assert.match(verifier,/aceNetHealthStatus="UNAVAILABLE"/);
assert.match(verifier,/aceNetHealthStatus="DOWN"/);
assert.match(verifier,/completeAceNetStartupAuthentication\(true,"SIGNED_IN"/);

assert.match(service,/PersistentAceNetWorker\(activity, emit, complete\)/);
assert.match(worker,/override fun onReceivedError/);
assert.match(worker,/status","NETWORK_ERROR"/);
assert.match(worker,/override fun onReceivedHttpError/);
assert.match(worker,/status","HTTP_ERROR"/);

const begin=main.slice(main.indexOf('private fun beginAceNetStartupAuthentication'),main.indexOf('private fun showAceNetStartupCredentialPrompt'));
assert.match(begin,/aceNetStartupResolved=false/);
assert.match(begin,/aceNetHealthStatus="CHECKING"/);
assert.match(begin,/startup_acenet_credentials_required/);
assert.doesNotMatch(main,/completeAceNetStartupInconclusive/);

assert.match(healthPolicy,/\['ONLINE','DOWN','UNAVAILABLE','DEGRADED','CHECKING'\]/);
assert.doesNotMatch(app,/UI_WAIT_TIMEOUT|resolve\('TIMEOUT'\),12000/);
assert.match(aceStartup,/acceptNativeStartupStatus/);
assert.match(aceStartup,/resolveStartupIfTerminal/);
assert.doesNotMatch(aceStartup,/acenet-startup-resolved/);
assert.match(aceStartup,/if\(!ready&&!knownUnavailable\)throw new Error/);
assert.match(app,/acenet_live_check_known_unavailable_handoff/);assert.doesNotMatch(app,/acenet_live_check_skipped_known_unavailable/);assert.match(main,/production_acenet_user_recovery_retry_consumed/);

console.log('Retailer SSO + shared readiness handoff PASS');

const sharedState=shell.indexOf('const aceNetRuntimeState='),uiBindingTry=shell.indexOf("try{\n  diag('boot_stage',{stage:'binding_ui'});"),startupBoot=shell.indexOf('void startupOrchestrator.run({');
assert.ok(sharedState>=0&&uiBindingTry>sharedState&&startupBoot>sharedState,'shared AceNet runtime state must be visible to UI callbacks and startup.');
assert.doesNotMatch(app,/ACE_NET_ONLINE/);
