import {readWebRuntimeSource,readNativeRuntimeSource} from './helpers/runtime-source-tree.mjs';
import fs from 'node:fs';
import assert from 'node:assert/strict';

const main=readNativeRuntimeSource();
const activity=fs.readFileSync('app/src/main/java/com/rmtb/upclistbuilder/MainActivity.kt','utf8');
const worker=fs.readFileSync('app/src/main/java/com/rmtb/upclistbuilder/PersistentAceNetWorker.kt','utf8');
const web=readWebRuntimeSource();
const aceStartup=fs.readFileSync('app/src/main/assets/www/application/acenet-startup-service.js','utf8');
const startupOrchestrator=fs.readFileSync('app/src/main/assets/www/application/startup-orchestrator.js','utf8');

assert.match(aceStartup,/acceptNativeStartupStatus/);
assert.match(aceStartup,/acceptNativeHealthStatus/);
assert.match(aceStartup,/startupResolver/);
assert.doesNotMatch(aceStartup,/acenet-startup-resolved/);
assert.match(main,/\.put\("startupResolved",aceNetStartupResolved\)/);
assert.doesNotMatch(web,/UI_WAIT_TIMEOUT|resolve\('TIMEOUT'\),12000/);
assert.match(aceStartup,/state\.authenticated=status\.authenticated===true/,'final web authentication projection must reflect authoritative native session truth');
assert.match(aceStartup,/knownUnavailable=health==='DOWN'\|\|health==='UNAVAILABLE'/);
assert.match(aceStartup,/if\(!ready&&!knownUnavailable\)throw new Error/);
assert.match(startupOrchestrator,/setStage\(56,'Starting AceNet readiness checks…'\)/,'AceNet splash phase must start below the former fixed 60% plateau');
assert.match(startupOrchestrator,/function acceptAceNetProgress\(raw\)/,'startup orchestrator must own projection of native AceNet phase progress');
assert.match(startupOrchestrator,/Math\.max\(56,Math\.min\(94,nativeProgress\)\)/,'native AceNet progress must advance the splash without regressing below the AceNet phase floor or reaching Ready early');
assert.match(startupOrchestrator,/if\(terminal\)requested=Math\.max\(progress,96\)/,'terminal native AceNet status should visibly advance before the final Ready transition');
assert.match(startupOrchestrator,/startup_acenet_progress_projected/,'projected splash progress must remain diagnostically observable');

const homeStart=main.indexOf('private fun inspectAceNetHome');
const homeEnd=main.indexOf('private fun inspectAceNetRetailerSso',homeStart);
const home=main.slice(homeStart,homeEnd);
assert.match(home,/startup_warmup_item_lookup_started/,'authenticated Home must continue to retailer-session bootstrap');
assert.match(home,/loadAceNetDirectItem\(view\)/,'startup may navigate transient view only to establish retailer readiness');
assert.doesNotMatch(home,/completeAceNetStartupAuthentication\(true,"SIGNED_IN"/,'Home authentication alone must not complete startup service proof');

const observedStart=main.indexOf('private fun handleAceNetObservedResult');
const observedEnd=main.indexOf('private fun finishAceNetTest',observedStart);
const observed=main.slice(observedStart,observedEnd);
assert.match(observed,/transientRetailerExtractionSkipped/);
assert.match(observed,/sourceView\.loadUrl\(frameUrl\)/,'readiness bootstrap must enter retailer realm');
assert.match(observed,/transient_item_retrieval_forbidden/);

const handoffStart=main.indexOf('val readinessHandoff=');
const handoffEnd=main.indexOf('currentHost == "acenet.aceservices.com"',handoffStart);
const handoff=main.slice(handoffStart,handoffEnd);
assert.match(handoff,/aceNetSessionManager\.markRetailerSessionReady\(\)/);
assert.match(handoff,/startAceNetStartupPersistentVerification\(template,1\)/);

const verifyStart=main.indexOf('private fun startAceNetStartupPersistentVerification');
const verifyEnd=main.indexOf('\n    private fun deliverAceNetProductionFailure',verifyStart);
const verify=main.slice(verifyStart,verifyEnd);
assert.match(verify,/aceNetRetrievalService\.prime\(template,aceNetWarmupSku\)/);
assert.match(verify,/primeSku==aceNetWarmupSku && primePrice\.isNotBlank\(\) && aceNetRetrievalService\.isReady\(\)/);
assert.match(verify,/retryableTimeout&&boundedAttempt<3/);
assert.match(verify,/retryableTransport&&boundedAttempt<2/);
assert.match(verify,/startup_persistent_worker_transport_retry/);
assert.match(verify,/startup_persistent_worker_terminal_error/);
assert.match(verify,/startup_persistent_worker_three_timeouts/);
assert.match(verify,/completeAceNetStartupAuthentication\(true,"SIGNED_IN"/);
assert.doesNotMatch(main,/completeAceNetStartupInconclusive/);

assert.match(worker,/fun prime\(template: String, sku: String, timeoutMs: Long = AceNetTimingPolicy\.ITEM_ATTEMPT_MS, callback: \(JSONObject\) -> Unit\): Boolean/);
assert.match(worker,/startSearch\("__startup_prime__\$\{System\.currentTimeMillis\(\)\}", "PRODUCTION_PRICE", sku, requirePrimed=false, timeoutOverrideMs=timeoutMs\)/);
assert.match(verify,/primeSku==aceNetWarmupSku && primePrice\.isNotBlank\(\)/,'MainActivity startup verifier must prove exact canary SKU plus price.');
assert.doesNotMatch(activity,/divStrL1L2|lblHeaderSellingDataStoreRetail|ddlUPC/,'MainActivity host must not contain production item selectors');
console.log('startup warm-up orchestration through Stage 6 readiness/retrieval split PASS');
