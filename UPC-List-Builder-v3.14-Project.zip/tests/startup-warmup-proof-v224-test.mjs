import {readWebRuntimeSource,readNativeRuntimeSource} from './helpers/runtime-source-tree.mjs';
import fs from 'node:fs';
import assert from 'node:assert/strict';

const main=readNativeRuntimeSource();
const worker=fs.readFileSync('app/src/main/java/com/rmtb/upclistbuilder/PersistentAceNetWorker.kt','utf8');
const web=readWebRuntimeSource();

assert.match(main,/startup_bootstrap_template_ready/);
assert.match(main,/transientRetailerExtractionSkipped/);
assert.match(main,/handoffToPersistentWorker/);
assert.ok(worker.includes('fun prime(template: String, sku: String, timeoutMs: Long = AceNetTimingPolicy.ITEM_ATTEMPT_MS, callback: (JSONObject) -> Unit): Boolean'));
assert.match(worker,/startSearch\("__startup_prime__\$\{System\.currentTimeMillis\(\)\}", "PRODUCTION_PRICE", sku, requirePrimed=false, timeoutOverrideMs=timeoutMs\)/);
assert.match(main,/primeStatus=="FOUND" && primeSku==aceNetWarmupSku && primePrice\.isNotBlank\(\) && aceNetRetrievalService\.isReady\(\)/,'Startup must validate exact canary SKU plus price before ONLINE.');

const wrapperStart=main.indexOf('private fun inspectAceNetResult');
const wrapperEnd=main.indexOf('private fun handleAceNetObservedResult',wrapperStart);
const wrapper=main.slice(wrapperStart,wrapperEnd);
assert.match(wrapper,/mode:'WRAPPER'/);
assert.match(wrapper,/__upcWrapperObserver/);
assert.doesNotMatch(wrapper,/divStrL1L2|ddlUPC|RetailPrice/);

const observedStart=main.indexOf('private fun handleAceNetObservedResult');
const observedEnd=main.indexOf('private fun finishAceNetTest',observedStart);
const observed=main.slice(observedStart,observedEnd);
assert.match(observed,/if\(result\.optString\("mode"\)!="WRAPPER"\)/);
assert.match(observed,/startup_bootstrap_template_ready/);
assert.match(observed,/sourceView\.loadUrl\(frameUrl\)/);

const ready=main.indexOf('startup_retailer_session_ready');
const prime=main.indexOf('startAceNetStartupPersistentVerification(template,1)',ready);
assert.ok(ready>=0&&prime>ready,'worker verification must begin after retailer session establishment');
assert.match(main,/aceNetSessionManager\.markRetailerSessionReady\(\)/);

assert.doesNotMatch(web,/UI_WAIT_TIMEOUT|waitResult==='TIMEOUT'/);
assert.match(main,/@JavascriptInterface fun cancelAceNetStartupWarmup\(\)/);
assert.match(main,/startup_ui_timeout_non_destructive/);
const cancel=main.slice(main.indexOf('private fun cancelAceNetStartupWarmupForSplashTimeout'),main.indexOf('private fun currentNetworkConnectivityState'));
assert.doesNotMatch(cancel,/destroyAceNetTestView|completeAceNetStartupAuthentication\(false|aceNetRetrievalService\.destroy/);

assert.match(worker,/val isPrime=id\.startsWith\("__startup_prime__"\)[\s\S]*if\(isPrime\)\{ primeCallback=null; prime\?\.invoke\(interrupted\) \} else complete\(id, mode, interrupted\)/);
console.log('startup warm-up Stage 6 end-to-end proof PASS');
