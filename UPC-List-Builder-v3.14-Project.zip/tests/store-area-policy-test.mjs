/** B1.1 pure policy regression, no runtime side effects. */
import assert from 'node:assert/strict';import vm from 'node:vm';import fs from 'node:fs';
const c=vm.createContext({});vm.runInContext(fs.readFileSync('app/src/main/assets/www/store-locations/location-policy.js','utf8'),c);const p=vm.runInContext('UPCStoreLocationPolicy',c);
assert.equal(p.normalizeAreaName(' Behind--Counter '),'BEHIND COUNTER');assert.equal(p.findPotentialAreaDuplicates('behind counter',[{id:'a',name:'Behind Counter'}])[0].match,'EXACT');assert.equal(p.findPotentialAreaDuplicates('Behind CTR',[{id:'a',name:'Behind Counter'}])[0].match,'REVIEW');assert.equal(p.validateAreaReference({kind:'CUSTOM',id:'area1',name:'Behind Counter'}).id,'area1');assert.throws(()=>p.validateAreaReference({kind:'AISLE',id:'not aisle'}));
console.log('Area policy: PASS');
