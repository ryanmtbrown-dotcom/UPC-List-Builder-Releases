/**
 * OWNERSHIP: B1.0 source/contract acceptance tests; no runtime mutation or PDF importer.
 * Scope: check fixed user decisions, real PDF fixture anchors, source-import rules.
 */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const root=process.cwd();
const location=fs.readFileSync(path.join(root,'STORE_LOCATION_CONTRACT.md'),'utf8');
const imports=fs.readFileSync(path.join(root,'PLANOGRAM_IMPORT_CONTRACT.md'),'utf8');
const fixtures=JSON.parse(fs.readFileSync(path.join(root,'tests/fixtures/planogram-source-scenarios.json'),'utf8'));
for(const term of ['OFFICIAL_SOURCE_MEMBER','CURRENT_PLACEMENT','LAST_KNOWN_ASSOCIATION','STORE_ADDED','Behind Counter','source-derived','only when the employee deliberately confirms','physicalSectionIds','NOT_IN_CURRENT_LAYOUT','IndexedDB','backup','price']){
  assert.ok(location.toLowerCase().includes(term.toLowerCase()),`Missing location rule: ${term}`);
}
for(const term of ['ChatGPT','@UPC','Cloudflare','D1','PLANOGRAM_IMPORT_V1','planogram:write','sourceReportRows','unrepresentedRows','merchandiseRows','unresolvedRows','sourceRowId','sourceSegment','digest','ACK','idempotent','DSD','PDF','signs','12704']){
  assert.ok(imports.includes(term),`Missing import rule: ${term}`);
}
assert.equal(fixtures.families.length,6);
assert.equal(new Set(fixtures.families.map(f=>f.planogramId)).size,6);
assert.deepEqual(fixtures.families.map(f=>f.planogramId).sort(),['N5NLSSCW','S1SANDHP','S1TAPE04','S2CMPLRS','S2CMSCKT','S2SCRWDV']);
for(const f of fixtures.families){assert.ok(f.sourcePage>0&&f.nominalFeet>0&&f.expected.includes('_'));}
assert.ok(!/new PDF upload\/import page|Android parser required/i.test(imports));
console.log('B1.0 contract test: 2 contract docs + six real PDF family anchors passed');
