import fs from 'node:fs';import vm from 'node:vm';import assert from 'node:assert/strict';
const root='app/src/main/assets/www/store-locations/';const c=vm.createContext({});
for(const f of ['location-policy.js','location-lookup-service.js'])vm.runInContext(fs.readFileSync(root+f,'utf8'),c);
const policy=vm.runInContext('UPCStoreLocationPolicy',c),make=vm.runInContext('UPCLocationLookupService',c).create;
let calls=[];
const source={id:'source1',current:true,modularId:'tape',planogramId:'S1TAPE04',name:'Tape',sourceSegments:[{id:'SOURCE-1',ordinal:1},{id:'SOURCE-2',ordinal:2}]};
const shared={byUpc:async()=>({placements:[],sourceMembers:[]}),getModular:async id=>{calls.push('modular:'+id);return{id,areaId:'area1',name:'Tape',physicalSectionIds:['1','2'],active:true}},
 getArea:async id=>{calls.push('area:'+id);return{id,name:'Aisle 8',kind:'AISLE',aisle:'8',active:true}},
 getSource:async id=>{calls.push('source:'+id);return source}};
const memberships=[{skuKey:'9023686',sourceId:'source1',positions:[{sourceSegment:'SOURCE-2',sourceRow:'4',sourceColumn:'5',fixtureType:'PEG'}]}];
const fromSource=make({policy,repository:{...shared,bySku:async()=>({placements:[],sourceMembers:memberships,history:[]})}});
const fallback=await fromSource.find({skuKey:'9023686'});
assert.equal(fallback.kind,'CURRENT');assert.equal(fallback.headline,'A8 · S2 · R4 · P5');
// Accepted imported coordinates have the same precision even without physical audit.
const seeded=make({policy,repository:{...shared,bySku:async()=>({placements:[{id:'source:source1:9023686',skuKey:'9023686',modularId:'tape',origin:'ACE_IMPORT',role:'HOME',physicalEvidence:false,fixtureType:'PEG',sourceSegment:'SOURCE-2',sourceRow:'4',sourceColumn:'5'}],sourceMembers:memberships,history:[]})}});
assert.equal((await seeded.find({skuKey:'9023686'})).headline,'A8 · S2 · R4 · P5');
// An accepted employee correction supersedes the source, never awaits a second confirmation.
const corrected=make({policy,repository:{...shared,bySku:async()=>({placements:[{id:'physical:1',skuKey:'9023686',modularId:'tape',origin:'USER_EDIT',role:'HOME',physicalEvidence:true,physicalSectionId:'1',rowOrdinal:2,columnOrdinal:3,fixtureType:'PEG'}, {id:'source:source1:9023686',skuKey:'9023686',modularId:'tape',origin:'ACE_IMPORT',fixtureType:'PEG',sourceRow:'4',sourceColumn:'5'}],sourceMembers:memberships,history:[]})}});
assert.equal((await corrected.find({skuKey:'9023686'})).headline,'A8 · S1 · R2 · P3');
// Accepted absence overrides any stale source-derived item; never resurrect on lookup.
const marked=make({policy,repository:{...shared,bySku:async()=>({placements:[],sourceMembers:[{...memberships[0],notPlaced:true}],history:[]})}});
assert.equal((await marked.find({skuKey:'9023686'})).kind,'EXPECTED_NOT_PLACED');
const special=make({policy,repository:{...shared,bySku:async()=>({placements:[],sourceMembers:[{skuKey:'5',sourceId:'source1',positions:[{sourceSegment:'SOURCE-1',sourceRow:'3',fixtureType:'SPCFIX',fixtureZone:'CR'}]}],history:[]})}});
assert.equal((await special.find({skuKey:'5'})).headline,'A8 · S1 · SF · R3 · CR');
// Compressing a two-source-section plan to one physical bay does not invent a 1:1 map.
const compressed=make({policy,repository:{...shared,getModular:async id=>({id,areaId:'area1',name:'Tape',physicalSectionIds:['4'],active:true}),bySku:async()=>({placements:[],sourceMembers:memberships,history:[]})}});
assert.equal((await compressed.find({skuKey:'9023686'})).headline,'A8 · S4 · PS2 · R4 · P5');
const historical=make({policy,repository:{...shared,bySku:async()=>({placements:[],sourceMembers:[],history:[{kind:'LAST_KNOWN_STORE_ADDED',skuKey:'DSD01',areaName:'Behind Counter',updatedAt:10}]})}});
assert.equal((await historical.find({skuKey:'DSD01'})).kind,'HISTORICAL');
const unknown=make({policy,repository:{...shared,bySku:async()=>({placements:[],sourceMembers:[],history:[]})}});
assert.equal((await unknown.find({skuKey:'123'})).kind,'UNKNOWN');
assert.ok(!calls.some(x=>x.includes('all(')));
const item=fs.readFileSync('app/src/main/assets/www/lookup/item-presentation-controller.js','utf8');
assert.ok(item.includes('if(!isCurrent(generation)||getPending()?.sku!==expectedSku||getPending()?.upc!==expectedUpc)return'));
assert.match(item,/locationLookupService\.find/);assert.ok(item.includes('void Promise.resolve()'));
const html=fs.readFileSync('app/src/main/assets/www/index.html','utf8');
assert.ok(html.includes('priceLocationStack')&&html.includes('locationLookupPanel')&&!html.includes('locationLookupDescription'));
console.log('Compact location hierarchy, source precision, fixture zones and persistence fallback PASS');
