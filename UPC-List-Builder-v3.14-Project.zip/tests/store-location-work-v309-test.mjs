/** Build 2 permanent physical layout, audit and integration regression. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
const root='app/src/main/assets/www/';
const read=x=>fs.readFileSync(root+x,'utf8');
const ctx=vm.createContext({});
for(const f of ['store-locations/location-work-policy.js','store-locations/location-work-service.js'])
 vm.runInContext(read(f),ctx);
const P=vm.runInContext('UPCLocationWorkPolicy',ctx);
vm.runInContext(read('store-locations/location-policy.js'),ctx);
const localPolicy=vm.runInContext('UPCStoreLocationPolicy',ctx);
const S=vm.runInContext('UPCLocationWorkService',ctx);
const make=(i,s='1')=>({id:'accepted:'+i,modularId:'Tape',skuKey:'SKU'+i,origin:'USER_SCAN',role:'HOME',
 physicalEvidence:true,physicalSectionId:s,fixtureType:'PEG',rowOrdinal:i+1,observedOrder:i+1,facings:1,storeAdded:true});
const base=Array.from({length:65},(_,i)=>make(i));
const observed=n=>base.slice(0,n).map((x,i)=>({...x,id:'scan:'+i}));
let r=P.audit({baseline:base,observed:observed(60),sections:['1'],completeSections:['1']});
assert.equal(r.notObserved.length,5);
r=P.audit({baseline:base,observed:observed(23),sections:['1'],completeSections:[]});
assert.equal(r.notObserved.length,0);
assert.equal(r.notVerified.length,42);
assert.equal(localPolicy.formatCompactLocation({current:{origin:'USER_SCAN',physicalEvidence:true,aisle:'8',
 physicalSectionId:'1',fixtureType:'PEG',rowOrdinal:2,observedOrder:3}}),'A8 · S1 · R2 · ORD3',
 'Observed order must be shown as observed order, not as an invented peg column');
const custom={...base[0],physicalSectionId:null};
const customPartial=P.audit({baseline:[custom],observed:[],sections:[],allSections:[],completeSections:[]});
assert.equal(customPartial.partial,true);
assert.equal(customPartial.notObserved.length,0);
const customComplete=P.audit({baseline:[custom],observed:[],sections:[],allSections:[],completeSections:['FIXTURE']});
assert.equal(customComplete.partial,false);
assert.equal(customComplete.notObserved.length,1,'custom fixture only creates not-observed after deliberate completion');
const facings=P.makePlacement({id:'facings',modularId:'Tape',skuKey:'100',facings:4,physicalSectionId:'1'},[]);
assert.equal(facings.facings,4);
assert.equal(facings.storeAdded,true);
assert.equal(P.makePlacement({id:'source',modularId:'Tape',skuKey:'100'},[{skuKey:'100'}]).storeAdded,false);
const proposal=P.changes({baseline:[make(0)],observed:[{...make(0),id:'new',physicalSectionId:'2'}],
 sourceMembers:[{skuKey:'SKU0'}],sections:['1','2'],allSections:['1','2']});
assert.equal(proposal[0].type,'MOVE');
assert.equal(proposal[0].after.storeAdded,false);
assert.equal(P.composeAcceptance({baseline:[make(0)],proposals:proposal,approvedIds:[],mode:'LAYOUT'}).placements[0].physicalSectionId,'1');
assert.equal(P.composeAcceptance({baseline:[make(0)],proposals:proposal,approvedIds:[proposal[0].id],mode:'LAYOUT'}).placements[0].physicalSectionId,'2');
assert.throws(()=>P.composeAcceptance({baseline:base,proposals:[{id:'remove',type:'REMOVE',before:base[0]}],approvedIds:['remove'],mode:'AUDIT'}),/Audit cannot/);
assert.equal(P.audit({baseline:[make(0,'1')],observed:[{...make(0,'2'),id:'observed'}],sections:['1','2'],completeSections:['1','2']}).wrongSection.length,1);
assert.equal(P.audit({baseline:[],observed:[make(0,'1'),{...make(0,'2'),id:'dup'}],sections:['1','2']}).possibleSeparateDuplicate.length,1);
// First observation into a seasonal/custom display must not silently create a second HOME.
const secondaryIdentity={skuKey:'SKU0'};
const elsewhere={...make(0),modularId:'HOME',physicalEvidence:true};
const promptFacts={identity:secondaryIdentity,modularId:'ENDCAP',observations:[],baseline:[],
 otherPlacements:[elsewhere],activeModularIds:['HOME']};
assert.equal(P.needsSeparateLocationConfirmation(promptFacts),true,'existing accepted active HOME needs the same separate-placement Yes/No gate');
assert.equal(P.needsSeparateLocationConfirmation({...promptFacts,activeModularIds:[]}),false,'inactive display is not a current physical duplicate');
assert.equal(P.needsSeparateLocationConfirmation({...promptFacts,otherPlacements:[{...elsewhere,physicalEvidence:false}]}),false,'corporate source hint is not a stocked physical placement');
assert.equal(P.needsSeparateLocationConfirmation({...promptFacts,baseline:[make(0)]}),false,'current accepted position must remain auditable without a duplicate prompt');
assert.equal(P.needsSeparateLocationConfirmation({...promptFacts,observations:[make(0)]}),true,'repeating the same draft observation needs deliberate review');
assert.equal(P.samePosition({physicalSectionId:'1',fixtureType:'PEG',rowOrdinal:1,observedOrder:1},{physicalSectionId:'1',fixtureType:'PEG',rowOrdinal:1,observedOrder:2}),false);
assert.equal(P.changes({baseline:[make(0)],observed:[{...make(0),id:'scan',facings:4}],sections:['1'],allSections:['1']})[0].type,'MOVE');
// A nominal 12-foot corporate source can be mapped to two real four-foot bays without invented coordinates.
const imported={id:'source:ACE:X',modularId:'Tape',skuKey:'SAND',origin:'ACE_IMPORT',role:'HOME',
 physicalEvidence:false,physicalSectionId:null,sourceSegment:'SOURCE-3',sourceRow:'52'};
const compressed=P.changes({baseline:[imported],observed:[{id:'scan:SAND',modularId:'Tape',skuKey:'SAND',
 origin:'USER_SCAN',role:'HOME',physicalSectionId:'1',rowOrdinal:2,fixtureType:'PEG',observedOrder:1}],
 sourceMembers:[{skuKey:'SAND'}],sections:['1'],allSections:['1','2']});
assert.equal(compressed.length,1,'partial physical observation must not duplicate a source-derived HOME');
assert.equal(compressed[0].type,'MOVE');
assert.equal(compressed[0].after.id,imported.id);
assert.equal(compressed[0].after.physicalSectionId,'1');
assert.equal(compressed[0].after.sourceSegment??null,null,'physical coordinates must come from observation only');
assert.equal(P.changes({baseline:[make(0)],observed:[{...make(0,'2'),id:'SECONDARY',role:'SECONDARY'}],
 sections:['2'],allSections:['1','2']})[0].type,'ADD','secondary placement cannot steal HOME');

const approvedSecondary={...make(0),role:'SECONDARY',approvedException:{placementId:'accepted:0',skuKey:'SKU0',
 physicalSectionId:'1',rowOrdinal:1,observedOrder:1}};
const secondaryChanged=P.changes({baseline:[approvedSecondary],observed:[{...make(0,'2'),id:'new:second'}],
 sections:['1','2'],allSections:['1','2']})[0];
assert.equal(P.requiresSecondaryApproval(secondaryChanged.after),true,'moved secondary must require renewed specific approval');
assert.equal(P.requiresSecondaryApproval(approvedSecondary),false,'unchanged approved secondary remains valid');
const state={draft:null,accepted:[]};
const db={async get(){return state.draft},async put(_store,value){state.draft=value}};
const repository={
 async getModular(){return{active:true,name:'Tape',areaId:'A8',physicalSectionIds:['1','2']}},
 async listPlacements(){return state.accepted},
 async listSourcesForModular(){return []},
 async listSourceMembers(){return[]},
 sourceSignature(){return '[]'},
 async approvePhysicalLayout(command){
  assert.equal(command.expectedFingerprint,P.fingerprint(state.accepted));
  state.accepted=command.items;return{accepted:true};
 }
};
let seq=0;const service=S.create({repository,db,idFactory:()=>String(++seq)});
let draft=await service.start({modularId:'Tape',mode:'LAYOUT',sections:['1','2']});
draft=await service.record(draft,{skuKey:'DSD',origin:'USER_SCAN'});
draft=await service.changeFacing(draft,draft.observations[0].id,1);
draft=await service.changeFixture(draft,'SHELF');
assert.equal(draft.fixtureType,'SHELF','fixture type can change mid-display');
assert.equal(draft.rowOrdinal,1,'new fixture begins at first shelf/row');
assert.equal((await service.resume()).observations[0].facings,2);
assert.equal(state.accepted.length,0);
let prepared=service.review(draft).proposals;
await service.approve(draft,prepared.map(x=>x.id));
assert.equal(state.accepted.length,1);
assert.equal(state.accepted[0].storeAdded,true);
assert.equal(await service.resume(),null);
draft=await service.start({modularId:'Tape',mode:'AUDIT',sections:['1','2']});
draft=await service.record(draft,{skuKey:'DSD',origin:'USER_SCAN'});
draft=await service.markSectionComplete(draft,'1',true);
assert.equal((await service.resume()).completeSections.length,1);
assert.equal(state.accepted.length,1);
await service.clear();
assert.equal(state.accepted.length,1);
// Unnumbered custom fixtures support row moves without inventing a real SEC or changing source evidence.
const originalGetModular=repository.getModular;
repository.getModular=async()=>({active:true,name:'Counter endcap',areaId:'COUNTER',physicalSectionIds:[]});
let fixture=await service.start({modularId:'COUNTER',mode:'LAYOUT',sections:[]});
fixture=await service.record(fixture,{skuKey:'DISPLAY',origin:'USER_SCAN',secondary:true});
fixture=await service.move(fixture,fixture.observations[0].id,{section:'',row:3,confirmSecondary:true});
assert.equal(fixture.observations[0].physicalSectionId,null);
assert.equal(fixture.observations[0].rowOrdinal,3);
assert.equal(P.requiresSecondaryApproval(fixture.observations[0]),false,'custom display move rebinds exact secondary approval');
repository.getModular=originalGetModular;
await service.clear();
// Existing secondary display positions are approved for a specific spot, not for arbitrary moves.
state.accepted=[{...make(0),role:'SECONDARY',approvedException:{placementId:'accepted:0',skuKey:'SKU0',
 physicalSectionId:'1',rowOrdinal:1,observedOrder:1,confirmedAt:42}}];
draft=await service.start({modularId:'Tape',mode:'LAYOUT',sections:['1','2']});
draft=await service.record(draft,{skuKey:'SKU0',origin:'USER_SCAN'});
draft=await service.move(draft,draft.observations[0].id,{section:'2',row:1});
const changedSecondary=service.review(draft).proposals.find(x=>x.type==='MOVE');
assert.ok(changedSecondary);
await assert.rejects(service.approve(draft,[changedSecondary.id]),/secondary placement moved/i);
assert.equal(state.accepted[0].physicalSectionId,'1','unapproved move did not modify accepted secondary');
await service.approve(draft,[changedSecondary.id],[changedSecondary.id]);
assert.equal(state.accepted[0].physicalSectionId,'2');
assert.equal(P.requiresSecondaryApproval(state.accepted[0]),false,'renewed approval belongs to this exact changed placement');
// Deactivating a seasonal endcap hides only that physical placement, not its independent HOME.
vm.runInContext(read('store-locations/location-lookup-service.js'),ctx);
const Lookup=vm.runInContext('UPCLocationLookupService',ctx);
let endcapActive=true;
const seasonalRepo={
 async bySku(){return {sourceMembers:[],history:[],placements:[
  {id:'home',skuKey:'SKU0',modularId:'HOME',origin:'USER_SCAN',role:'HOME',physicalEvidence:true,
   physicalSectionId:'1',rowOrdinal:1,fixtureType:'SHELF'},
  {id:'seasonal',skuKey:'SKU0',modularId:'ENDCAP',origin:'USER_SCAN',role:'SECONDARY',physicalEvidence:true,
   physicalSectionId:null,rowOrdinal:1,fixtureType:'PEG'}]};},
 async getModular(id){return {id,active:id==='HOME'||endcapActive,areaId:id,name:id,physicalSectionIds:id==='HOME'?['1']:[]};},
 async getArea(id){return {id,kind:'CUSTOM',name:id,active:true};}
};
const seasonalLookup=Lookup.create({repository:seasonalRepo,policy:localPolicy});
assert.equal((await seasonalLookup.find({skuKey:'SKU0'})).otherLocations.length,1);
endcapActive=false;
const afterEndcap=(await seasonalLookup.find({skuKey:'SKU0'}));
assert.equal(afterEndcap.kind,'CURRENT');
assert.equal(afterEndcap.otherLocations.length,0,'deactivated endcap no longer appears');
assert.equal(afterEndcap.modularId,'HOME','original home location remains available');
assert.match(read('store-locations/location-maintenance-controller.js'),/setConfirmUser/);
assert.match(read('store-locations/location-maintenance-controller.js'),/Activate'\s*:\s*'Deactivate/);
const html=read('index.html'),router=read('scanner/scanner-workspace-router.js'),repo=read('store-locations/location-repository.js');
for(const id of ['locationWorkScan','locationWorkFinish','locationWorkNextSection','locationWorkResume','locationWorkCompletedSections'])
 assert.ok(html.includes('id="'+id+'"'),id+' UI control missing');
assert.match(router,/locationWorkProvider/);
assert.match(repo,/expectedFingerprint/);
assert.match(repo,/sourceSignature\(currentSources\)/);
assert.match(repo,/LAST_KNOWN_STORE_ADDED/);
assert.match(read('application/application-shell.js'),/locationWorkController\.bind\(\)/);
assert.match(read('store-locations/location-work-controller.js'),/needsSeparateLocationConfirmation/,'active accepted locations must be checked for separate display placements');
console.log('Build 2 physical layouts, 60-of-65 completed and 23-of-65 partial audits, provenance, facings, approval gates, recoverable drafts and scanner routing: PASS');
