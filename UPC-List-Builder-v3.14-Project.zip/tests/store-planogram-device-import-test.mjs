import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import {webcrypto} from 'node:crypto';
import {validatePlanogram,digestSource} from '../integrations/chatgpt-mcp/cloudflare/src/planogram-validate.mjs';
const base='app/src/main/assets/www/store-locations/';
const source=fs.readFileSync(base+'planogram-import-service.js','utf8');
const context=vm.createContext({crypto:webcrypto,TextEncoder,console});vm.runInContext(source,context);
const service=vm.runInContext('UPCPlanogramImportService',context);
const draft=validatePlanogram({schemaVersion:'PLANOGRAM_IMPORT_V1',source:{planogramId:'S1TAPE04',name:'Tape',sourceIdentityEvidence:'Ace Product Report',nominalWidthFt:8,nominalFourFootSections:2,widthEvidence:'Title TAPE 8FT'},
 sourceSegments:[{id:'1',ordinal:1,fixtureType:'PEG'}],placements:[
 {sourceRowId:'row-1',sku:'12704',upcOrGtin:'036000291452',sourceSegment:'1',fixtureType:'PEG',reportRow:'4',reportColumn:'5',sourcePage:1,membershipDisposition:'MERCHANDISE'},
 {sourceRowId:'row-2',sku:'12704',sourceSegment:'1',fixtureType:'PEG',reportRow:'5',reportColumn:'6',sourcePage:2,membershipDisposition:'MERCHANDISE'},
 {sourceRowId:'row-3',description:'Shelf sign',sourceSegment:'1',fixtureType:'OTHER',membershipDisposition:'NON_MERCHANDISE'}],
 reconciliation:{sourceReportRows:3,submittedRowRecords:3,merchandiseRows:2,excludedNonMerchandiseRows:1,unresolvedRows:0,distinctMerchandiseSkus:1,unrepresentedRows:0},
 exclusions:[{sourceRowId:'row-3',reason:'Sign'}],unresolved:[],manifest:{submissionId:'source-1',expectedChunks:1,status:'COMPLETE'}});
draft.manifest.sourceDigest=await digestSource(draft);
const packet={batchId:'98765432-1234-4abc-8aaa-123456789012',state:'pending',...draft};
const valid=await service.verify(packet);assert.equal(valid.distinctMerchandiseSkus,1);
const members=service.stageSource(packet);assert.equal(members.length,1);assert.equal(members[0].sourceRowIds.length,2);
assert.equal(members[0].skuKey,'12704');assert.equal(members[0].positions[0].sourcePage,1);assert.equal(members[0].positions[0].sourceRow,'4');assert.equal(members[0].positions[0].sourceColumn,'5');
const tampered=structuredClone(packet);tampered.placements[0].description='Tampered product description';
await assert.rejects(()=>service.verify(tampered),/digest mismatch/);
const missing=structuredClone(packet);missing.placements.pop();assert.throws(()=>service.validate(missing),/reconcile|count|Exception/i);
const forged=structuredClone(packet);forged.placements[0].physicalSectionId='3';assert.throws(()=>service.validate(forged),/Unsupported/);
const html=fs.readFileSync('app/src/main/assets/www/index.html','utf8');
const shell=fs.readFileSync('app/src/main/assets/www/application/application-shell.js','utf8');
const deviceJs=fs.readFileSync(base+'planogram-import-controller.js','utf8');
const repo=fs.readFileSync(base+'location-repository.js','utf8');
for(const id of ['planogramBatchSelect','planogramReview','planogramImportReview','planogramAccept','planogramAssign','planogramSourceAssignSelect','planogramModularAssignSelect','planogramImportStatus','planogramPlacementSku','planogramMarkNotPlaced','planogramRestoreItem'])assert.ok(html.includes('id="'+id+'"'));
assert.ok(shell.indexOf('confirm:appConfirm,prompt:appPrompt')<shell.indexOf('const planogramImportController='),'controller cannot reference appConfirm before initialization');
assert.match(deviceJs,/await repository\.acceptSource/);
assert.ok(deviceJs.indexOf('await repository.acceptSource')<deviceJs.indexOf('await adapter.ack(batchId)'),'ACK must follow accepted local commit');
assert.match(repo,/assignSource/);assert.match(repo,/markSourceMemberNotPlaced/);assert.match(repo,/restoreSourceMember/);
assert.ok(!deviceJs.includes('PDFParser')&&!html.includes('input type="file" accept=".pdf"'));
console.log('B1.5 strict packet revalidation, digest, source grouping, ACK-order, app wiring PASS');
