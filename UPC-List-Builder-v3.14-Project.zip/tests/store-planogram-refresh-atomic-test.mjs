/**
 * OWNERSHIP: Store Location accepted-source replacement and override regression.
 * Distinct transaction stub; does not emulate browser timing or SQLite storage.
 * Ensures explicit re-import preserves approved store decisions, and rejects unapproved mutations atomically.
 */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
const data=new Map();const storePaths={storeSources:'id',storeSourceMembers:['sourceId','skuKey'],storeHistory:['skuKey','kind','contextId'],storeImportReceipts:'batchId',storePlacements:'id',storeModulars:'id',storeAreas:'id'};
for(const name of Object.keys(storePaths))data.set(name,new Map());
const key=(value)=>JSON.stringify(value);
const rowKey=(table,row)=>key(Array.isArray(storePaths[table])?storePaths[table].map(p=>row[p]):row[storePaths[table]]);
const putNow=(table,row)=>data.get(table).set(rowKey(table,row),structuredClone(row));
putNow('storeAreas',{id:'a8',name:'Aisle 8',aisle:'8',kind:'AISLE',active:true});
putNow('storeModulars',{id:'tape',name:'Tape',areaId:'a8',active:true,physicalSectionIds:['1','2']});
class DB {
 transaction(stores,mode){
  let ended=false,pending=0,finishing=false;
  const maps=new Map(stores.map(name=>[name,new Map([...data.get(name)].map(([k,v])=>[k,structuredClone(v)]))]));
  const tx={oncomplete:null,onerror:null,onabort:null,error:null,abort(){if(ended)return;ended=true;setTimeout(()=>tx.onabort?.(),0)}};
  const tryFinish=()=>{if(finishing||ended||pending)return;finishing=true;setTimeout(()=>{finishing=false;if(ended||pending)return;ended=true;for(const [name,m] of maps){if(mode==='readwrite')data.set(name,m)}tx.oncomplete?.()},0)};
  const request=(operation)=>{pending++;const req={result:undefined,error:null,onsuccess:null,onerror:null};queueMicrotask(()=>{if(ended)return;try{req.result=operation();req.onsuccess?.({target:req})}catch(e){req.error=e;req.onerror?.({target:req})}finally{pending--;tryFinish()}});return req};
  tx.objectStore=name=>{const map=maps.get(name);if(!map)throw Error('Unknown table '+name);
   const all=()=>[...map.values()].map(x=>structuredClone(x));
   return {get(v){return request(()=>structuredClone(map.get(key(v)))||undefined)},getAll(){return request(all)},put(row){return request(()=>{map.set(rowKey(name,row),structuredClone(row));return row})},delete(v){return request(()=>map.delete(key(v)))},
    index(prop){return{getAll(val){return request(()=>all().filter(x=>x[({bySku:'skuKey',byUpc:'upcKey',bySource:'sourceId',byModular:'modularId'})[prop]||prop]===val))}}}};
  };
  return tx;
 }
}
const conn=new DB();
const facade={open:async()=>conn,get:async(n,k)=>structuredClone(data.get(n).get(key(k)))||null,all:async n=>[...data.get(n).values()].map(structuredClone)};
const context=vm.createContext({UPCDB:facade,console,Date,setTimeout,queueMicrotask,structuredClone,IDBKeyRange:{only:v=>v}});
for(const f of ['location-policy.js','location-work-policy.js','location-repository.js'])vm.runInContext(fs.readFileSync('app/src/main/assets/www/store-locations/'+f,'utf8'),context);
const repo=vm.runInContext('UPCLocationRepository',context);
const item=(sku,row,col)=>({skuKey:sku,sourceRowIds:[`p:${sku}`],positions:[{sourceSegment:'SOURCE-1',sourceRow:String(row),sourceColumn:String(col),fixtureType:'PEG'}]});
const source=(id,digest)=>({id,planogramId:'S1TAPE04',name:'Tape 8ft',digest,modularId:'tape',nominalWidthFt:8,nominalFourFootSections:2,
 sourceSegments:[{id:'SOURCE-1',ordinal:1},{id:'SOURCE-2',ordinal:2}]});
const before=await repo.acceptSource({source:source('source-first','a'.repeat(64)),items:[item('9023686',19,44),item('12704',2,3),item('DROPPED',6,7)],batchId:'batch1'});
assert.equal(before.memberCount,3);assert.equal((await repo.bySku('9023686')).placements.length,1);
await repo.markSourceMemberNotPlaced({sourceId:'source-first',skuKey:'12704'});
assert.equal((await repo.bySku('12704')).sourceMembers[0].notPlaced,true);
assert.equal((await repo.bySku('12704')).placements.length,0);
// Real employee adjustment must override the old source-derived position.
putNow('storePlacements',{id:'employee:9023686',skuKey:'9023686',modularId:'tape',origin:'USER_EDIT',physicalEvidence:true,physicalSectionId:'2',rowOrdinal:5,columnOrdinal:1,fixtureType:'PEG'});
await assert.rejects(repo.acceptSource({source:source('source-second','b'.repeat(64)),items:[item('9023686',9,11)],batchId:'batch2'}),/Explicitly approve replacement/);
assert.equal((await repo.getSource('source-first')).digest,'a'.repeat(64));
assert.equal(await repo.getReceipt('batch2'),null);
const updated=await repo.acceptSource({source:source('source-second','b'.repeat(64)),items:[item('9023686',20,45),item('12704',10,6)],batchId:'batch2',replaceSourceId:'source-first'});
assert.equal(updated.replaced,true);
assert.equal(updated.modularId,'tape');
assert.equal((await repo.getSource('source-first')).digest,'b'.repeat(64));
assert.equal((await repo.getSource('source-first')).nominalFourFootSections,2);
assert.equal(await repo.getSource('source-second'),null);
assert.equal((await repo.bySku('12704')).sourceMembers[0].notPlaced,true,'absence survives source replacement');
assert.equal((await repo.bySku('12704')).placements.length,0,'not-placed item remains absent');
assert.equal((await repo.bySku('9023686')).sourceMembers[0].positions[0].sourceRow,'20','source updates coordinate');
assert.equal((await repo.bySku('9023686')).placements.some(p=>p.id==='employee:9023686'),true,'approved correction survives');
assert.equal((await repo.bySku('9023686')).placements.some(p=>p.origin==='ACE_IMPORT'),false,'do not put source copy over correction');
assert.equal((await repo.bySku('DROPPED')).sourceMembers.length,0,'obsolete source membership removed');
assert.equal((await repo.bySku('DROPPED')).history.length,1,'former source reference retained');
const replay=await repo.acceptSource({source:source('source-second','b'.repeat(64)),items:[item('9023686',20,45),item('12704',10,6)],batchId:'batch2'});
assert.equal(replay.replayed,true);
await repo.restoreSourceMember({sourceId:'source-first',skuKey:'12704'});
assert.equal((await repo.bySku('12704')).sourceMembers[0].notPlaced,false);
assert.equal((await repo.bySku('12704')).placements[0].sourceRow,'10');
console.log('Accepted planogram replacement, atomic refusal, current corrections, saved absences and history PASS');

// Build 2 atomic acceptance: reject stale drafts, bad sections and unapproved secondaries without partial writes.
const workPolicy=vm.runInContext('UPCLocationWorkPolicy',context);
const acceptedBefore=await repo.listPlacements('tape');
const originalFingerprint=workPolicy.fingerprint(acceptedBefore);
const sourceSignature=repo.sourceSignature(await repo.listSourcesForModular('tape'));
const added={id:'employee:regional',modularId:'tape',skuKey:'REGION-DSD',upcKey:'012345678905',
 origin:'USER_SCAN',role:'HOME',storeAdded:true,physicalEvidence:true,
 physicalSectionId:'1',fixtureType:'PEG',rowOrdinal:2,observedOrder:2,facings:4};
await assert.rejects(repo.approvePhysicalLayout({modularId:'tape',items:[...acceptedBefore,added],
 expectedFingerprint:'outdated',expectedSourceSignature:sourceSignature}),/Accepted layout changed/);
assert.equal((await repo.listPlacements('tape')).length,acceptedBefore.length,'stale approval leaves accepted layout intact');
await assert.rejects(repo.approvePhysicalLayout({modularId:'tape',items:[...acceptedBefore,{...added,physicalSectionId:'9'}],
 expectedFingerprint:originalFingerprint,expectedSourceSignature:sourceSignature}),/Physical section is no longer assigned/);
assert.equal((await repo.listPlacements('tape')).length,acceptedBefore.length,'invalid physical section aborts whole update');
await assert.rejects(repo.approvePhysicalLayout({modularId:'tape',items:[...acceptedBefore,{...added,id:'employee:second',role:'SECONDARY'}],
 expectedFingerprint:originalFingerprint,expectedSourceSignature:sourceSignature}),/Secondary placement requires approval/);
assert.equal((await repo.listPlacements('tape')).length,acceptedBefore.length,'secondary approval cannot leak');
const approved=await repo.approvePhysicalLayout({modularId:'tape',items:[...acceptedBefore,added],
 expectedFingerprint:originalFingerprint,expectedSourceSignature:sourceSignature});
assert.equal(approved.accepted,true);
assert.equal((await repo.bySku('REGION-DSD')).placements.length,1,'store-added merchandise accepted atomically');
assert.equal((await repo.bySku('9023686')).sourceMembers[0].positions[0].sourceRow,'20',
 'physical acceptance cannot rewrite corporate source coordinates');
console.log('Build 2 atomic stale-draft, section-guard, specific-secondary approval and successful acceptance PASS');
