import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';

const read=p=>fs.readFileSync(p,'utf8');
const repoSource=read('app/src/main/assets/www/diagnostics/diagnostic-repository.js');
const journal=read('app/src/main/assets/www/diagnostics/diagnostic-journal.js');
const serviceSource=read('app/src/main/assets/www/diagnostics/diagnostic-service.js');
const operations=read('app/src/main/assets/www/diagnostics/diagnostic-operation-service.js');
const exportService=read('app/src/main/assets/www/diagnostics/diagnostic-export-service.js');
const ui=read('app/src/main/assets/www/diagnostics/diagnostic-ui-controller.js');
const shell=read('app/src/main/assets/www/application/application-shell.js');
const html=read('app/src/main/assets/www/index.html');
const nativeJournal=read('app/src/main/java/com/rmtb/upclistbuilder/NativeDiagnosticJournal.kt');
const nativeFormatter=read('app/src/main/java/com/rmtb/upclistbuilder/NativeDiagnosticRecordFormatter.kt');

assert.match(repoSource,/STORE='diagnostics'/);
assert.match(repoSource,/appendBatch/);
assert.match(repoSource,/replaceAll/);
assert.match(journal,/DIAG_RETAINED_ACTIVE_DAYS=5/);
assert.match(journal,/DIAG_EMERGENCY_MAX_BYTES=25000000/);
assert.match(journal,/DIAG_DEEP_MAX_BYTES=50000000/);
assert.match(journal,/DIAG_NORMAL_MAX_EVENTS=12000/);
assert.match(journal,/DIAG_DEEP_MAX_EVENTS=30000/);
assert.match(journal,/errorPriority/);
assert.doesNotMatch(journal,/storage\.setItem\(DIAG_KEY/,'localStorage must not remain the primary diagnostic journal');
assert.match(serviceSource,/schemaVersion:2/);
for(const field of ['operationId','spanId','parentSpanId','domain','module','function','phase','purpose','inputSummary','stateSummary','expected','actual','durationMs']) assert.ok(serviceSource.includes(field),`canonical field missing: ${field}`);
assert.match(serviceSource,/DEEP_MODE_KEY/);
assert.match(serviceSource,/sourceLocation/);
assert.match(serviceSource,/redactKey/);
assert.match(serviceSource,/details\.lookupId/);
assert.match(operations,/spanId\(kind,id\)/);
assert.match(exportService,/timeline/);
assert.match(exportService,/operationSummary/);
assert.match(exportService,/unfinishedSpans/);
assert.match(exportService,/diagnosticSchemaVersion:2/);
assert.match(ui,/toggleDeepMode/);
assert.match(html,/id="toggleDeepDiag"/);
for(const asset of ['db.js','diagnostics/diagnostic-repository.js','diagnostics/diagnostic-journal.js','diagnostics/diagnostic-service.js','diagnostics/diagnostic-operation-service.js','application/application-shell.js']){
 assert.ok(html.indexOf(asset)>=0,`missing runtime asset: ${asset}`);
}
assert.ok(html.indexOf('db.js')<html.indexOf('diagnostics/diagnostic-repository.js'));
assert.ok(html.indexOf('diagnostics/diagnostic-repository.js')<html.indexOf('diagnostics/diagnostic-journal.js'));
assert.ok(html.indexOf('diagnostics/diagnostic-journal.js')<html.indexOf('diagnostics/diagnostic-service.js'));
assert.ok(html.indexOf('diagnostics/diagnostic-service.js')<html.indexOf('application/application-shell.js'));
assert.ok(shell.indexOf('await diagnosticService.initialize()')<shell.indexOf('startupOrchestrator.begin()'),'retained diagnostics must hydrate before startup session begins');
assert.match(shell,/fatalDiagnostic\?\.event\?\.\('application_shell_fatal'/,'fatal bootstrap errors must use the structured diagnostic owner when available');
assert.match(shell,/severity:'FATAL',phase:'ERROR',result:'FAIL'/,'fatal bootstrap evidence must retain terminal severity and phase');
assert.ok(shell.indexOf('fatalDiagnostic=diag;')<shell.indexOf('const scannerController=UPCScannerController.create('),'fatal diagnostic scope must be bound before composition constructors can fail');
assert.match(nativeJournal,/upc-native-diagnostics-v2\.json/);
assert.match(nativeJournal,/maxRows = 4000/);
assert.match(nativeJournal,/maxBytes = 4_000_000/);
assert.doesNotMatch(nativeJournal,/putString\(/,'native SharedPreferences must not be the primary diagnostic journal');
assert.match(nativeFormatter,/class NativeDiagnosticRecordFormatter/);
assert.match(nativeFormatter,/\[redacted\]/);
assert.match(nativeFormatter,/schemaVersion", 2/);

const captured=[];
let now=10;
const settings=new Map();
const storage={getItem:k=>settings.has(k)?settings.get(k):null,setItem:(k,v)=>settings.set(k,String(v))};
const journalStub={
 initialize:async()=>[],
 append:row=>{captured.push(row);return row},
 alaskaDiagnosticStamp:()=>({date:'2026-10-03',time:'19:45:00.000',zone:'AKDT'}),
 beginStartupDiagnosticSession:row=>{captured.push(row);return{rows:captured,currentCount:1,currentStartupSessionId:'startup-test',invariant:'PASS'}},
 status:()=>({eventCount:captured.length})
};
const context={window:{},performance:{now:()=>now},Date,Map,Set,Error,String,Number,RegExp,Object,Array,JSON,Math};
vm.createContext(context);
vm.runInContext(serviceSource,context,{filename:'diagnostic-service.js'});
const service=context.window.UPCDiagnosticService.create({
 journal:journalStub,settingsStorage:storage,appVersion:'2.79',appBuild:'test',startupSessionId:'startup-test',
 getSinceBootMs:()=>100,getScreen:()=> 'home'
});
await service.initialize();
const scoped=service.scope({domain:'LOOKUP',module:'lookup/test-service'});
const span=scoped.diag.start({operationId:'OP-1',function:'lookup',purpose:'Resolve item.',expected:'ProductLookupResult',inputSummary:{upc:'082901234567'}});
now=44;
scoped.diag.success(span,{event:'lookup_completed',actual:'Product found.',details:{status:'FOUND'}});
assert.equal(captured.length,2);
assert.equal(captured[0].phase,'START');
assert.equal(captured[1].phase,'SUCCESS');
assert.equal(captured[0].operationId,'OP-1');
assert.equal(captured[0].spanId,captured[1].spanId);
assert.equal(captured[0].module,'lookup/test-service');
assert.equal(captured[0].function,'lookup');
assert.equal(captured[1].durationMs,34);

const beforeDebug=captured.length;
service.emit('debug_probe',{x:1},{severity:'DEBUG'});
assert.equal(captured.length,beforeDebug,'DEBUG must be suppressed in normal mode');
service.setDeepMode(true);
service.emit('debug_probe',{x:1},{severity:'DEBUG'});
assert.equal(captured.length,beforeDebug+1,'DEBUG must be retained in Deep Diagnostic Mode');

const sanitized=service.sanitize({password:'secret',cookieValue:'abc',url:'https://example.test/?token=abc&x=1'});
assert.equal(sanitized.password,'[redacted]');
assert.equal(sanitized.cookieValue,'[redacted]');
assert.match(sanitized.url,/token=\[redacted\]/);
assert.doesNotMatch(sanitized.url,/token=abc/);

const error=vm.runInContext("(()=>{const e=new Error('bad response');e.stack='Error: bad response\\n    at parseThing (src/parse.js:184:22)';return e})()",context);
const failed=scoped.diag.start({operationId:'OP-2',function:'parseThing',purpose:'Parse response.',expected:'Normalized result'});
scoped.diag.error(failed,error,{event:'parse_failed',actual:'Response could not be parsed.'});
const errorRow=captured.at(-1);
assert.equal(errorRow.severity,'ERROR');
assert.equal(errorRow.phase,'ERROR');
assert.equal(errorRow.sourceLocation.line,184);
assert.equal(errorRow.sourceLocation.column,22);
assert.match(errorRow.stack,/src\/parse\.js:184:22/);

console.log('Stage 11 structured diagnostics contract + runtime behavior PASS');
