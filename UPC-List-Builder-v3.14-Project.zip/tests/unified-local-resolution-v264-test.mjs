import fs from 'node:fs';
import assert from 'node:assert/strict';
import {readWebRuntimeSource,readNativeRuntimeSource,findJsFunction} from './helpers/runtime-source-tree.mjs';

const web=readWebRuntimeSource();
const app=readWebRuntimeSource(),db=fs.readFileSync('app/src/main/assets/www/db.js','utf8'),misc=fs.readFileSync('app/src/main/assets/www/ace-misc.js','utf8');
const readiness=fs.readFileSync('app/src/main/assets/www/diagnostics/runtime-readiness-service.js','utf8');
const html=fs.readFileSync('app/src/main/assets/www/index.html','utf8');
const native=readNativeRuntimeSource();
const kt=native,worker=native,workflow=fs.readFileSync('app/src/main/assets/www/library-workflow-v093.js','utf8');
const gradle=fs.readFileSync('gradle.properties','utf8');
const normalContract=fs.readFileSync('NORMAL_ITEM_SEARCH_CONTRACT.md','utf8');
const miscContract=fs.readFileSync('ACE_MISC_ADDITIONAL_UPC_CONTRACT.md','utf8');


// Runtime/package identity must be independently observable even if JavaScript is stale.
const currentBuildId=gradle.match(/^UPC_BUILD_ID=(.+)$/m)?.[1];
assert.ok(currentBuildId,'current Gradle build identity missing');
assert.ok(html.includes(`meta name="build-id" content="${currentBuildId}"`),'HTML build identity must match Gradle');
for(const asset of ['app.v059.js','db.js','ace-misc.js'])assert.match(html,new RegExp(asset.replaceAll('.','\\.')+'\\?v=[^"]+'),'runtime asset must retain an explicit cache fingerprint: '+asset);
assert.match(kt,/cacheMode = android\.webkit\.WebSettings\.LOAD_NO_CACHE/);
assert.ok(kt.includes('index.html?v=${BuildConfig.UPC_BUILD_ID.removePrefix("v")}'),'native packaged-index fingerprint must derive from BuildConfig build authority');
assert.match(kt,/reportRuntimeProbe/);assert.match(kt,/app_runtime_asset_probe/);
assert.match(kt,/window\.UPCAppRuntimeCapabilities\|\|\{\}/);
assert.match(kt,/resolverFunctionType:typeof window\.UPCAceMiscResolver\?\.resolveSkuCandidate/);
assert.match(kt,/runtimeReady:window\.UPCAppRuntimeReady===true/);
assert.doesNotMatch(kt,/resolveAceMiscSkuCandidate:typeof resolveAceMiscSkuCandidate/,'Native probe must not inspect the inaccessible lexical resolver directly.');
assert.match(readiness,/windowRef\.UPCAppRuntimeCapabilities=Object\.freeze/);
assert.match(readiness,/runtime_asset_fingerprint/);assert.match(readiness,/runtime_required_function_missing/);

// Local Library is a real lookup authority, not just a queue.
for(const fn of ['lookupUniqueLocalSKU','lookupUniqueLocalExact','lookupUniqueLocalPrefix']) assert.ok(db.includes(`async function ${fn}`),`DB missing ${fn}`);
const skuLookup=findJsFunction('lookupItemBySku');
assert.match(skuLookup,/UPCLocalIdentifierResolver\.resolveSKU\(key\)/,'Normal SKU lookup must use Local Identifier Resolver, which delegates catalog selection to Effective Catalog.');assert.doesNotMatch(skuLookup,/UPCMasterRepository\.|UPCLocalRepository\.|UPCIdentityRepository\./);
const upcLookup=findJsFunction('lookupItem');
assert.match(upcLookup,/UPCLocalIdentifierResolver\.resolveUPC\(digits,\{format\}\)/,'Normal UPC lookup must use the shared Local Identifier Resolver.');assert.doesNotMatch(upcLookup,/UPCMasterRepository\.|UPCLocalRepository\.|UPCIdentityRepository\./);
assert.match(normalContract,/Master Library -> durable Local Library -> AceNet/);

// New AceNet-only item success requires full catalog persistence and read-back.
const missing=findJsFunction('resolveMissingSkuThroughAceNet');
assert.match(missing,/requestAceNetCatalog\(requestedSku\)/);
assert.match(missing,/persistVerifiedAceNetCatalogToLocalLibrary/);
assert.match(missing,/lookupItemBySku\(canonicalSku\)/);
assert.doesNotMatch(missing,/requestAceNetPrice|enqueueLibraryUpdate|createActiveLibraryAceNetItem/);
const persist=findJsFunction('persistVerifiedAceNetCatalogToLocalLibrary');
for(const token of ['UPCCatalogRefreshPolicy.plan','UPCLocalRepository.stageAceNetItem','UPCIdentifierRelationshipService.recordVerifiedSkuUpcs','UPCLocalRepository.lookupSKU','local_library_catalog_persist_verified']) assert.ok(persist.includes(token),`Persistence chain missing ${token}`);
assert.doesNotMatch(persist,/reconcilePromotedLocalRecord/,'Stage 7 live refresh must not synchronize Local into Master.');

// Stage 9: Local and Master remain separate; promoted-Master compatibility is retired.
assert.doesNotMatch(db,/reconcilePromotedLocalLibraryRecord|restoreMissingPromotedLocalLibraryRecords|reconcileAllPromotedLocalLibraryRecords|masterPromotion/);
assert.doesNotMatch(app,/promoted_local_master_startup_reconciliation|LOCAL_TO_MASTER_PROMOTION_DISABLED/);
assert.doesNotMatch(workflow,/pushLocalLibraryToMaster|replacementById|lastLocalLibraryPushAt/);
assert.match(workflow,/Local Library remain separate|Local Library remains separate/);

// Retail Units must preserve Master/Local authority instead of being reset during catalog refresh.
const ru=findJsFunction('resolveAceNetRetailUnits');
assert.match(ru,/effectiveResolver\.inspectSKU\(key\)/);assert.doesNotMatch(ru,/UPCMasterRepository\.|UPCLocalRepository\./);assert.match(ru,/DEFAULT_NO_LIBRARY_RU/);

// ACE MISC uses Master/Local as baseline, but current export authority requires live full-catalog verification or explicit NOT_FOUND confirmation.
const resolver=findJsFunction('resolveAceMiscSkuCandidate');
assert.match(resolver,/UPCEffectiveCatalogResolver\.inspectSKU\(key\)/,'ACE MISC SKU resolution must obtain Master/Local evidence through Effective Catalog.');
assert.match(resolver,/aceMiscRefreshLibraryRecord\(key,master\.row/,'Known Master rows must enter the full MISC refresh owner.');
assert.match(resolver,/aceMiscFromLocalRecord/,'Known Local rows must enter the same full MISC refresh owner.');
assert.match(resolver,/persistVerifiedAceNetCatalogToLocalLibrary/,'Master+Local misses must persist verified full catalog to Local.');
const refresh=findJsFunction('aceMiscRefreshLibraryRecord');
assert.match(refresh,/requestAceNetCatalog\(key,\{misc:true\}\)/,'Every known MISC SKU must attempt one full exact-SKU catalog request.');
assert.match(refresh,/ACEMisc\.snapshotFromLibraryAndAceNet/,'Verified live fields must overlay the library baseline in the MISC snapshot.');
assert.match(misc,/PENDING_ACENET/);assert.match(misc,/VERIFIED_COMPLETE/);assert.match(misc,/VERIFIED_NO_ACENET_UPC_DATA/);assert.match(misc,/USER_CONFIRMED_COMPLETE/);
assert.match(miscContract,/## Mandatory live verification/);
assert.match(miscContract,/VERIFIED_NO_ACENET_UPC_DATA[\s\S]*exportable[\s\S]*PENDING_ACENET[\s\S]*draft only[\s\S]*three complete\/exportable states/i);

// Removed/stale direct-write path must stay absent.
assert.doesNotMatch(app,/createActiveLibraryAceNetItem/);

// v2.61 worker forensics remain present under all live AceNet calls.
for(const marker of ['persistent_worker_main_frame_navigation','persistent_worker_page_started','persistent_worker_page_finished','persistent_worker_main_frame_network_error','persistent_worker_main_frame_http_error','persistent_worker_console_message','persistent_worker_page_forensics','persistent_worker_dom_state','persistent_worker_sku_evidence_still_pending']) assert.ok(worker.includes(marker),`Retained-worker forensic marker missing: ${marker}`);

console.log('Current unified Master/Local/AceNet resolution + runtime trace requirements PASS');
