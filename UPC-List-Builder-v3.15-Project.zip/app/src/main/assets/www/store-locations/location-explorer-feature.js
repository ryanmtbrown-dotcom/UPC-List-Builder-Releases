/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/store-locations/location-explorer-feature.js
 * Owner: Store Locations / Explorer Dependency Assembly
 * Role: Feature composition adapter
 * Responsibility: Instantiates Explorer read, edit and presentation owners with the existing shared repositories.
 * Does not own: Domain mutation rules, shell lifecycle, scanner hardware, or product catalog authority.
 * Side effects: Constructs services only; controller binding is explicit.
 * Related code: application/application-shell.js, location-explorer-controller.js, location-explorer-service.js.
 */
const UPCLocationExplorerFeature=(()=>{
 'use strict';
 function create({repository,catalog,workController,elementById,documentRef,showScreen,goBack,startScanner,
  normalizeUPC,normalizeSKU,confirmUser,idFactory,itemMapper,productImageService,priceService,comparisonEnabled,openIdentifierKeypad,db,tagNames=[]}={}){
  const policy=UPCLocationExplorerPolicy;
  const read=UPCLocationExplorerService.create({repository,catalog,policy,itemMapper});
  const edit=UPCLocationExplorerEditService.create({repository,policy,workPolicy:UPCLocationWorkPolicy,idFactory});
  const drafts=UPCLocationExplorerDraftService.create({db,repository,workPolicy:UPCLocationWorkPolicy});
  return UPCLocationExplorerController.create({repository,read,edit,policy,elementById,documentRef,showScreen,goBack,
   startScanner,normalizeUPC,normalizeSKU,confirmUser,workController,idFactory,productImageService,priceService,comparisonEnabled,openIdentifierKeypad,drafts,tagNames});
 }
 return Object.freeze({create});
})();
