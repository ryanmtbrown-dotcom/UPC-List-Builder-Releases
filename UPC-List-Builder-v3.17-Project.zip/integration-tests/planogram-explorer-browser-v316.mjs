/** Synthetic Chromium acceptance of real v3.16 Explorer markup/controller and 100% isolated data. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import {pathToFileURL} from 'node:url';
const root=path.resolve('app/src/main/assets/www');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');
const source=read('index.html');
const start=source.indexOf('<section id="locationExplorerScreen"'),end=source.indexOf('<section id="locationScreen"',start);
assert.ok(start>=0&&end>start,'Explorer markup missing');
const explorer=source.slice(start,end);
const appDialog='<div id="appDialogOverlay" class="modal hidden"><div class="appDialog"><strong id="appDialogTitle"></strong><p id="appDialogMessage"></p><div id="appDialogInputWrap" class="appDialogInputWrap"><input id="appDialogInput"></div><button id="appDialogCancel">Cancel</button><button id="appDialogOk">OK</button></div></div>';
const fixture='<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'+
 '<link rel="stylesheet" href="/styles.v059.css"><link rel="stylesheet" href="/store-locations/location-explorer.css"><link rel="stylesheet" href="/application/dialogs.css">'+
 '<style>:root{--surface-primary:#fff;--surface-raised:#fff;--surface-muted:#f1f3f5;--text-primary:#191d27;--text-secondary:#555f6c;--accent:#c70b35;--accent-strong:#a10a2b;--border-strong:#cbd1d5;--border-subtle:#dce1e6;--danger:#a10a2b;--shadow-sm:0 3px 12px #0001}body{margin:0;background:#f3f4f7}.hidden{display:none!important}</style></head><body>'+
 '<button id="locationExploreOpen" type="button">View Planogram</button>'+explorer+appDialog+
 '<script src="/store-locations/location-explorer-policy.js"></script>'+
 '<script src="/store-locations/location-work-policy.js"></script>'+
 '<script src="/store-locations/location-explorer-draft-service.js"></script>'+
 '<script src="/store-locations/location-explorer-difference-service.js"></script>'+
 '<script src="/store-locations/location-explorer-tag-service.js"></script>'+
 '<script src="/application/dialog-service.js"></script>'+
 '<script src="/store-locations/location-explorer-controller.js"></script>'+
 '<script src="/__fixture.js"></script></body></html>';
const server=http.createServer((req,res)=>{
 const pathname=new URL(req.url,'http://localhost').pathname;
 if(pathname==='/__fixture.js'){res.writeHead(200,{'Content-Type':'text/javascript'});res.end(fs.readFileSync('integration-tests/planogram-explorer-synthetic-fixture-v316.js'));return}
 if(pathname==='/__explorer'){res.writeHead(200,{'Content-Type':'text/html'});res.end(fixture);return}
 const safe=path.normalize(decodeURIComponent(pathname)).replace(/^[/\\]+/,'');
 if(safe.startsWith('..')){res.writeHead(403);res.end();return}
 try{const data=read(safe);res.writeHead(200,{'Content-Type':safe.endsWith('.css')?'text/css':'text/javascript'});res.end(data)}
 catch{res.writeHead(404);res.end('Not found')}
});
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const url='http://127.0.0.1:'+server.address().port+'/__explorer';
const modulePath=process.env.UPC_PLAYWRIGHT_MODULE;
assert.ok(modulePath,'UPC_PLAYWRIGHT_MODULE must reference the isolated Playwright installation');
const {chromium}=await import(modulePath.startsWith('/')?pathToFileURL(modulePath).href:modulePath);
const browser=await chromium.launch({headless:true,args:['--no-sandbox'],
 ...(process.env.UPC_CHROME_EXECUTABLE?{executablePath:process.env.UPC_CHROME_EXECUTABLE}:{})});
const failures=[];
try{
 const page=await browser.newPage({viewport:{width:412,height:915}});
 page.on('pageerror',error=>failures.push(error.message));
 await page.goto(url);
 await page.locator('#locationExploreOpen').click();
 await page.evaluate(()=>window.__fixture.ctl.onAcceptedScan({upc:'100'}));
 await page.locator('#locationExplorerItemName').getByText('SYNTHETIC PRODUCT 100').waitFor();
 const toggle=await page.locator('#locationExplorerScreen .lookupModeToggle').boundingBox();
 const gear=await page.locator('#locationExplorerSettingsOpen').boundingBox();
 assert.ok(gear.x>toggle.x+toggle.width-2,'Settings gear must be right of UPC/SKU');
 assert.equal(await page.locator('#locationExplorerTags').count(),0,'Do not hide tags behind Tag Item');
 assert.ok(await page.locator('[data-explorer-tag="NIF"]').isVisible(),'NIF visible without toggle');
 await page.locator('[data-explorer-tag="NIF"]').click();
 assert.equal(await page.locator('[data-explorer-tag="NIF"]').getAttribute('aria-pressed'),'true');
 assert.equal(await page.evaluate(()=>window.__fixture.tagLists().length),0,'Browsing and choosing tags never creates a list');
 assert.equal(await page.locator('#locationExplorerAddTagged').isDisabled(),false,'Tag selection activates Add to Tag List');
 await page.locator('#locationExplorerAddTagged').click();
 await page.locator('#appDialogOverlay').waitFor({state:'visible'});
 assert.match(await page.locator('#appDialogMessage').innerText(),/create a Planogram Tags list/i);
 assert.equal(await page.evaluate(()=>window.__fixture.tagLists().length),0,'List creation requires explicit confirmation');
 await page.locator('#appDialogCancel').click();
 await page.locator('#appDialogOverlay').waitFor({state:'hidden'});
 assert.equal(await page.evaluate(()=>window.__fixture.tagLists().length),0,'Cancel must leave no list');
 await page.locator('#locationExplorerAddTagged').click();
 await page.locator('#appDialogOverlay').waitFor({state:'visible'});
 await page.locator('#appDialogOk').click();
 await page.locator('#appDialogOverlay').waitFor({state:'hidden'});
 const saved=await page.evaluate(()=>window.__fixture.tagLists());
 assert.equal(saved.length,1,'Creates one Field Session only after explicit Add + confirmation');
 assert.equal(saved[0].items.length,1);
 assert.deepEqual(saved[0].items[0].tags,['NIF'],'NIF is saved to the ordinary Field Session');
 await page.locator('[data-explorer-tag="Missing Label"]').click();
 await page.locator('#locationExplorerAddTagged').click();
 const updated=await page.evaluate(()=>window.__fixture.tagLists());
 assert.equal(updated.length,1,'Existing tag list is reused');
 assert.equal(updated[0].items.length,1,'Repeated UPC never creates duplicate tag rows');
 assert.ok(updated[0].items[0].tags.includes('Missing Label'),'Additional tag is persisted');

 await page.locator('#locationExplorerSettingsOpen').click();
 assert.ok(await page.locator('#locationExplorerSettings').isVisible(),'Settings gear must open modal');
 assert.equal(await page.locator('#locationExplorerSettings').evaluate(el=>getComputedStyle(el).position),'fixed');
 assert.ok(await page.locator('#locationExplorerSettingsDifferences').isVisible(),'Differences is in Settings');
 await page.locator('#locationExplorerSettingsClose').click();
 assert.ok(await page.locator('#locationExplorerSettings').isHidden(),'Settings close works');
 await page.locator('#locationExplorerInsert').click();
 assert.ok(await page.locator('#locationExplorerEdit').isVisible(),'Insert opens modal');
 assert.ok(await page.locator('[data-explorer-insert-direction="INSERT_BEFORE"]').isVisible());
 const editBox=await page.locator('#locationExplorerEdit').boundingBox();
 assert.ok(editBox.y>=0&&editBox.y+editBox.height<=916,'Edit modal contained within phone viewport');
 await page.locator('[data-explorer-insert-direction="INSERT_BEFORE"]').click();
 await page.locator('#locationExplorerEditIdType').selectOption('SKU');
 await page.locator('#locationExplorerEditIdentifier').fill('900');
 await page.locator('#locationExplorerPrepare').click();
 await page.locator('#locationExplorerReview').waitFor({state:'visible'});
 assert.ok(await page.locator('#locationExplorerEdit').isHidden(),'Review must replace, not overlap, Edit');
 await page.locator('#locationExplorerCancelReview').click();
 assert.ok(await page.locator('#locationExplorerEdit').isVisible(),'Back to Edit restores form');
 await page.locator('#locationExplorerPrepare').click();
 await page.locator('#locationExplorerConfirm').click();
 await page.locator('#locationExplorerItemName').getByText('SYNTHETIC PRODUCT 900').waitFor();
 await page.locator('#locationExplorerEditButton').click();
 await page.locator('#locationExplorerEditSection').selectOption('1');
 await page.locator('#locationExplorerEditRow').fill('3');
 await page.locator('#locationExplorerEditLocationNote').fill('A8 · S1 · SF · R3 · P23');
 await page.locator('#locationExplorerPrepare').click();
 await page.locator('#locationExplorerConfirm').click();
 assert.match(await page.locator('#locationExplorerLocationSummary').innerText(),/P23/);
 // Simulate close/restart and open saved work through Settings.
 await page.reload();
 await page.locator('#locationExploreOpen').click();
 await page.locator('#locationExplorerSettingsOpen').click();
 await page.locator('#locationExplorerSettingsLoad').click();
 assert.ok(await page.locator('#locationExplorerAuditList button').count()>0);
 await page.locator('#locationExplorerAuditList button').first().click();
 await page.locator('#locationExplorerItemName').getByText('SYNTHETIC PRODUCT 900').waitFor();
 assert.match(await page.locator('#locationExplorerLocationSummary').innerText(),/P23/);
 await page.evaluate(()=>window.__fixture.ctl.onAcceptedScan({upc:'300'}));
 await page.locator('#locationExplorerItemName').getByText('SYNTHETIC PRODUCT 300').waitFor();
 await page.locator('#locationExplorerDelete').click();
 await page.locator('#appDialogOverlay').waitFor({state:'visible'});
 assert.match(await page.locator('#appDialogMessage').innerText(),/original Ace planogram remains unchanged/i);
 await page.locator('#appDialogOk').click();
 await page.locator('#appDialogOverlay').waitFor({state:'hidden'});
 await page.evaluate(()=>window.__fixture.ctl.onAcceptedScan({upc:'100'}));
 await page.locator('#locationExplorerItemName').getByText('SYNTHETIC PRODUCT 100').waitFor();
 await page.locator('#locationExplorerEditButton').click();
 await page.locator('#locationExplorerEditSection').selectOption('1');
 await page.locator('#locationExplorerEditRow').fill('4');
 await page.locator('#locationExplorerEditLocationNote').fill('A8 · S1 · R4 · P5');
 await page.locator('#locationExplorerPrepare').click();
 await page.locator('#locationExplorerConfirm').click();
 assert.deepEqual(await page.evaluate(()=>window.__fixture.original()),['100','200','200','300'],'Ace original must remain untouched');
 await page.locator('#locationExplorerSettingsOpen').click();
 await page.locator('#locationExplorerSettingsConfirm').click();
 await page.locator('#appDialogOverlay').waitFor({state:'visible'});
 await page.locator('#appDialogOk').click();
 await page.locator('#appDialogOverlay').waitFor({state:'hidden'});
 // The physical-layout draft is cleared by confirmation. Tags must still be actionable.
 assert.equal(await page.locator('[data-explorer-tag="General Review"]').isDisabled(),false,'Confirmed planogram tags remain enabled without layout draft');
 await page.locator('[data-explorer-tag="General Review"]').click();
 assert.equal(await page.locator('#locationExplorerAddTagged').isDisabled(),false,'Tag-list action still works after layout confirmation');
 await page.locator('#locationExplorerAddTagged').click();
 const resumedTagRows=await page.evaluate(()=>window.__fixture.tagLists());
 assert.equal(resumedTagRows.length,1,'Existing Planogram Tags list reused after page reload');
 assert.equal(resumedTagRows[0].items.length,1,'Confirmed planogram tagging updates existing UPC without duplicate');
 assert.ok(resumedTagRows[0].items[0].tags.includes('General Review'));
 await page.evaluate(()=>window.__fixture.seedElectrical());
 await page.locator('#locationExplorerSettingsOpen').click();
 await page.locator('#locationExplorerSettingsDifferences').click();
 assert.ok(await page.locator('#locationExplorerDifferences').isVisible(),'View Differences opens full-screen');
 assert.equal(await page.locator('#locationExplorerDifferences').evaluate(el=>getComputedStyle(el).position),'fixed');
 assert.equal(await page.locator('#locationExplorerDifferencesSelect option').count(),2);
 await page.locator('#locationExplorerDifferencesSelect').selectOption('tape');
 const counts=await page.locator('.locationExplorerDiffStat strong').allInnerTexts();
 assert.deepEqual(counts,['1','1','1'],'Only insertion, deletion and edited placement differ');
 const items=await page.locator('.locationExplorerDiffEntry strong').allInnerTexts();
 assert.ok(items.includes('SKU:900')&&items.includes('SKU:300')&&items.includes('SKU:100'));
 assert.ok(!items.includes('SKU:200'),'Unchanged repeated SKU must not appear');
 await page.locator('#locationExplorerDifferencesSelect').selectOption('electrical');
 assert.match(await page.locator('#locationExplorerDifferencesList').innerText(),/No differences/);
 await page.locator('#locationExplorerDifferencesClose').click();
 assert.ok(await page.locator('#locationExplorerDifferences').isHidden());
 await page.setViewportSize({width:360,height:640});
 const smallGear=await page.locator('#locationExplorerSettingsOpen').boundingBox();
 assert.ok(smallGear.x+smallGear.width<=361,'Gear stays within small phone width');
 await page.locator('#locationExplorerSettingsOpen').click();
 const settings=await page.locator('#locationExplorerSettings').boundingBox();
 assert.ok(settings.x>=0&&settings.x+settings.width<=361&&settings.y>=0&&settings.y+settings.height<=641,'Settings fits small phone');
 assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth<=window.innerWidth),true,'No phone horizontal overflow');
 await page.locator('#locationExplorerSettingsClose').click();
 assert.deepEqual(failures,[],'No uncaught browser errors');
 console.log('v3.16 real Chromium synthetic planogram: scan, gear, tags, insert, edit, delete, resume, confirm, differences and mobile geometry PASS');
}finally{await browser.close();await new Promise(resolve=>server.close(resolve))}
