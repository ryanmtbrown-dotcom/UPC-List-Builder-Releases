/* Isolated synthetic planogram browser fixture. No real IndexedDB or user data is read. */
(()=>{
 'use strict';
 const fixtures={
  tape:{id:'tape',name:'Synthetic Tape',records:[['100',1,1],['200',1,2],['200',2,1],['300',2,2]]},
  electrical:{id:'electrical',name:'Synthetic Electrical',records:[['500',1,1],['600',1,2]]}
 };
 const clone=value=>JSON.parse(JSON.stringify(value));
 const get=(key,fallback)=>{const raw=localStorage.getItem('fixture:'+key);return raw?JSON.parse(raw):clone(fallback)};
 const put=(key,value)=>localStorage.setItem('fixture:'+key,JSON.stringify(value));
 const evidence=id=>{
  const f=fixtures[id];
  return {source:{id:'source-'+id,current:true,modularId:id,digest:'synthetic-revision-one',
   name:f.name,nominalWidthFt:8,sourceSegments:[{id:'SOURCE-1',ordinal:1},{id:'SOURCE-2',ordinal:2}]},
   members:f.records.reduce((acc,row)=>{
    const sku=row[0],r=row[1],col=row[2];
    let m=acc.find(x=>x.skuKey===sku);
    if(!m){m={skuKey:sku,upcKey:null,positions:[]};acc.push(m)}
    m.positions.push({sourceSegment:r===1?'SOURCE-1':'SOURCE-2',sourceRow:r,sourceColumn:col,fixtureType:'PEG'});
    return acc;
   },[])};
 };
 const model=id=>{
  const f=fixtures[id],parts=evidence(id);
  const modular={id,name:f.name,areaId:'area-'+id,physicalSectionIds:['1','2'],active:true};
  const area={id:'area-'+id,kind:'AISLE',aisle:id==='tape'?'8':'12',name:'Aisle '+(id==='tape'?'8':'12'),active:true};
  const placements=get('accepted-'+id,[]);
  const store=UPCLocationExplorerPolicy.ordered({modular,placements,mode:'STORE'});
  const ace=UPCLocationExplorerPolicy.ordered({modular,source:parts.source,sourceMembers:parts.members,mode:'ACE'});
  return{modular,area,source:parts.source,sourceMembers:parts.members,placements,store,ace,mode:store.length?'STORE':'ACE'};
 };
 const db={get:async(store,key)=>get(store+':'+key,null),put:async(store,row)=>{put(store+':'+row.key,row);return row}};
 const repo={
  sourceSignature:rows=>JSON.stringify((rows||[]).filter(x=>x.current===true).map(x=>x.id+':'+(x.digest||'')).sort()),
  bySku:async()=>({placements:[]}),byUpc:async()=>({placements:[]}),
  listModulars:async()=>Object.values(fixtures).map(f=>model(f.id).modular),
  approvePhysicalLayout:async({modularId,items,expectedFingerprint,expectedSourceSignature})=>{
   if(UPCLocationWorkPolicy.fingerprint(get('accepted-'+modularId,[]))!==expectedFingerprint)throw Error('Stale store revision');
   if(repo.sourceSignature([evidence(modularId).source])!==expectedSourceSignature)throw Error('Stale Ace source');
   if(items.some(x=>x.modularId!==modularId))throw Error('Foreign placement');
   put('accepted-'+modularId,items);return{accepted:true}
  }
 };
 const read={
  resolveIdentity:async(raw,type='AUTO')=>({skuKey:String(raw),upcKey:type==='UPC'?String(raw):null,status:'FOUND'}),
  candidates:async identity=>{
   const sku=identity.skuKey||identity.upcKey;
   for(const id of Object.keys(fixtures)){
    if(model(id).ace.some(p=>p.skuKey===sku)||model(id).store.some(p=>p.skuKey===sku))
     return[{modularId:id,name:fixtures[id].name,area:'Aisle 8',physical:false}]
   }
   return[];
  },
  display:async(id,mode=null)=>{
   const m=model(id);m.mode=mode==='ACE'?'ACE':mode==='STORE'&&m.store.length?'STORE':m.mode;
   m.items=m.mode==='STORE'?m.store:m.ace;return m;
  },
  details:async p=>({description:'SYNTHETIC PRODUCT '+p.skuKey,sku:p.skuKey,upc:p.upcKey||('000000000000'+p.skuKey).slice(-12),
   retail:'15.99',orderMultiple:6,retailUnits:6,catalogFound:false,product:null})
 };
 const drafts=UPCLocationExplorerDraftService.create({db,repository:repo,workPolicy:UPCLocationWorkPolicy});
 const dialog=UPCDialogService.create({elementById:id=>document.getElementById(id),setTimeoutFn:setTimeout});
 let activeSession=null;
 const tagStore={
  list:async()=>get('field-session-lists',[]),
  create:async session=>{const all=get('field-session-lists',[]);all.push(clone(session));put('field-session-lists',all);return session},
  save:async session=>{const all=get('field-session-lists',[]),at=all.findIndex(x=>x.id===session.id);if(at<0)throw Error('No Field Session found');all[at]=clone(session);put('field-session-lists',all);return session}
 };
 const tags=UPCLocationExplorerTagService.create({sessionService:tagStore,
  getCurrentSession:()=>activeSession,setCurrentSession:s=>activeSession=s,
  newId:()=>String(Date.now())+String(++seq),sessionName:()=> 'Synthetic Oct 13',
  confirmUser:dialog.confirm});

 window.UPCPriceAuthority={money:value=>value==null?null:Number(value).toFixed(2)};
 let seq=0;
 const ctl=UPCLocationExplorerController.create({
  repository:repo,read,edit:{},policy:UPCLocationExplorerPolicy,drafts,
  differences:UPCLocationExplorerDifferenceService,
  tagService:tags,
  elementById:id=>document.getElementById(id),documentRef:document,
  showScreen:id=>document.getElementById(id).classList.remove('hidden'),goBack:()=>{},
  startScanner:()=>{window.__scannerInvoked=true},normalizeUPC:x=>x,normalizeSKU:x=>x,
  confirmUser:dialog.confirm,workController:{},idFactory:()=>String(++seq),comparisonEnabled:()=>false,
  openIdentifierKeypad:({onAccept})=>{window.__typeOnKeypad=onAccept},
  tagNames:['NIF','Price Change','General Review','Missing Label','Duplicate Item']
 });
 ctl.bind();
 window.__fixture={ctl,drafts,read,repo,model,tagLists:()=>get('field-session-lists',[]),currentTaggedList:()=>activeSession,original:()=>model('tape').ace.map(p=>p.skuKey),
  seedElectrical:async()=>{
   const m=model('electrical');
   await drafts.finish('electrical',{kind:'ACE',name:m.modular.name,area:m.area.name,
    sourceId:m.source.id,sourceDigest:m.source.digest,
    sourceSnapshot:m.ace.map(UPCLocationExplorerDifferenceService.take),
    storeSnapshot:m.ace.map(UPCLocationExplorerDifferenceService.take),tags:{},viewed:[],entryCount:m.ace.length});
  }};
})();
