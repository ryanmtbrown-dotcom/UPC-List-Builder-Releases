/** v3.13 regression: normal-lookup geometry, compact controls, zero jump picker and live navigation. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
const root='app/src/main/assets/www/';
const read=p=>fs.readFileSync(root+p,'utf8');
const html=read('index.html'),css=read('store-locations/location-explorer.css'),ctrl=read('store-locations/location-explorer-controller.js');
const a=html.indexOf('<section id="locationExplorerScreen"'),b=html.indexOf('<section id="locationScreen"',a);
assert.ok(a>=0&&b>a,'Explorer must remain a separate field activity');
const explorer=html.slice(a,b);
assert.doesNotMatch(explorer,/Jump to position|locationExplorerSelectItem|locationExplorerInputMode|value="AUTO"/i);
assert.doesNotMatch(ctrl,/locationExplorerSelectItem|locationExplorerInputMode|locationExplorerJump/);
assert.doesNotMatch(css,/locationExplorerJump|locationExplorerSelectItem/);
for(const marker of ['class="scanPanel locationExplorerLookupPanel"','class="lookupModeToggle"','data-explorer-lookup-mode="UPC"','data-explorer-lookup-mode="SKU"','class="scanRow"','class="scanButton"','class="lookupButton"','class="productPanel locationExplorerProductPanel"','class="productImageFrame"','class="priceCompare"','class="facts"'])assert.ok(explorer.includes(marker),'Shared normal-lookup structure missing '+marker);
for(const id of ['locationExplorerPrevious','locationExplorerNext','locationExplorerCount','locationExplorerAceMode','locationExplorerStoreMode','locationExplorerLocationSummary','locationExplorerImage','locationExplorerRetail','locationExplorerAceNetRetail','locationExplorerUpc','locationExplorerOrderMultiple','locationExplorerRetailUnits'])assert.ok(explorer.includes('id="'+id+'"'),id);
assert.match(explorer,/<button id="locationExplorerPrevious" class="primary"/);
assert.match(explorer,/<button id="locationExplorerNext" class="primary"/);
assert.match(explorer,/<details id="locationExplorerMore"/);
assert.match(css,/#locationExplorerScreen \.locationExplorerNavigation>button\{[^}]*height:40px[^}]*background:var\(--accent\);color:#fff/);
assert.match(css,/#locationExplorerScreen \.productPanel\{[^}]*grid-template-columns:clamp\(108px,33vw,146px\)/);
assert.match(css,/#locationExplorerScreen \.scanRow input\{[^}]*height:46px/);
assert.match(css,/#locationExplorerScreen \.priceCompare>div\{[^}]*min-height:44px/);
assert.match(ctrl,/openIdentifierKeypad\(\{title:'Enter '\+manualMode/);
assert.match(ctrl,/read\.resolveIdentity\(value,'AUTO',format\)/);
assert.match(read('application/application-shell.js'),/openIdentifierKeypad:options=>manualIdentifierController\.keypad\.open\(options\)/);
const ids=[...html.matchAll(/\bid="([^"]+)"/g)].map(x=>x[1]);
assert.equal(new Set(ids).size,ids.length,'No duplicate HTML IDs');
for(const match of ctrl.matchAll(/\$\(['"]([^'"]+)['"]\)/g))assert.ok(ids.includes(match[1]),'Controller references nonexistent HTML ID '+match[1]);
const initialHidden=new Set(['locationExplorerScreen','locationExplorerDisplay','locationExplorerMissing']);
const fakeClassList=hidden=>({set:new Set(hidden?['hidden']:[]),add(x){this.set.add(x)},remove(x){this.set.delete(x)},contains(x){return this.set.has(x)},toggle(x,forced){if(forced===undefined)forced=!this.set.has(x);if(forced)this.set.add(x);else this.set.delete(x);return forced}});
const elements=new Map();
function element(id){if(!elements.has(id))elements.set(id,{id,value:'',textContent:'',src:'',alt:'',placeholder:'',dataset:{},classList:fakeClassList(initialHidden.has(id)),disabled:false,style:{},handlers:{},addEventListener(name,callback){(this.handlers[name]||=[]).push(callback)},click(){for(const fn of this.handlers.click||[])fn({target:this})},focus(){for(const fn of this.handlers.focus||[])fn({target:{blur(){}}})},setAttribute(name,value){this[name]=value},removeAttribute(name){delete this[name]},replaceChildren(...children){this.children=[...children];this.options=this.children},append(...children){this.children=(this.children||[]).concat(children)}});return elements.get(id)}
for(const id of ids)element(id);
const modes=['UPC','SKU'].map(mode=>{const x=element('mode-'+mode);x.dataset.explorerLookupMode=mode;return x});
const doc={createElement(tag){const e={tagName:tag,value:'',textContent:'',className:'',children:[],append(...items){this.children.push(...items)},setAttribute(){}};return e},querySelectorAll(selector){if(selector==='[data-explorer-lookup-mode]')return modes;if(selector==='#locationExplorerEditMenu [data-explorer-edit]')return [];return []}};
const calls=[],keypads=[];
const rows=[{id:'p1',skuKey:'9023686',upcKey:'052427603609',sourceOnly:true},{id:'p2',skuKey:'9000001',upcKey:'012345678901',sourceOnly:true}];
const modular={id:'tape',name:'Tape',physicalSectionIds:['1','2']};
const source={nominalWidthFt:8,nominalFourFootSections:2};
const readMock={
 async resolveIdentity(value,type){calls.push({value,type});return{skuKey:String(value)==='052427603609'?'9023686':String(value),upcKey:type==='UPC'?String(value):null,status:'FOUND'}},
 async candidates(identity){return identity.skuKey==='NOT_PLACED'?[]:[{modularId:'tape',name:'Tape',area:'Aisle 8'}]},
 async display(id,preferredMode){return{modular,area:{name:'Aisle 8'},source,items:rows,store:[],ace:rows,mode:'ACE',sourceMembers:[],placements:[]}},
 async details(item){return{description:'Mounting tape',sku:item.skuKey||'—',upc:item.upcKey||'—',retail:'15.99',orderMultiple:6,retailUnits:6,catalogFound:false,product:null}}
};
const repo={listModulars:async()=>[]};
const window={};
const context=vm.createContext({window,UPCPriceAuthority:{money:x=>x==null?null:Number(x).toFixed(2)}});
vm.runInContext(ctrl,context);
const Controller=vm.runInContext('UPCLocationExplorerController',context);
const drafts={load:async()=>null,confirmed:async()=>null,save:async x=>x,
 initial:m=>({modularId:m.modular.id,items:m.ace.map(p=>({...p})),mode:m.mode,focusId:null,index:0,viewed:[],tags:{},edits:0}),
 isCurrent:()=>true};
const service=Controller.create({repository:repo,read:readMock,edit:{},drafts,differences:{},tagService:{add:async()=>({status:'ADDED',name:'Synthetic Tag List'})},policy:{same:(p,id)=>Boolean(p.skuKey&&p.skuKey===id?.skuKey),key:p=>p?.skuKey?'SKU:'+p.skuKey:null,position:()=> 'Ace import'},elementById:element,documentRef:doc,showScreen:id=>element(id).classList.remove('hidden'),goBack:()=>{},startScanner:()=>{},normalizeUPC:x=>x,normalizeSKU:x=>x,confirmUser:async()=>true,workController:{},idFactory:()=>String(1),openIdentifierKeypad:options=>keypads.push(options),comparisonEnabled:()=>false});
service.bind();element('locationExploreOpen').click();await Promise.resolve().then(()=>Promise.resolve());
assert.equal(element('locationExplorerLookupLabel').textContent,'UPC');
assert.ok(!element('locationExplorerScreen').classList.contains('hidden'));
element('locationExplorerLookup').click();
assert.equal(keypads.length,1,'Input must reuse the standard keypad');
await keypads[0].onAccept('9023686');
assert.equal(calls.at(-1).type,'AUTO','Default manual lookup detects identifier behind the scenes');
assert.equal(element('locationExplorerCount').textContent,'1 / 2');
assert.equal(element('locationExplorerRetail').textContent,'$15.99');
element('locationExplorerNext').click();
await new Promise(resolve=>setImmediate(resolve));
assert.equal(element('locationExplorerCount').textContent,'2 / 2','Next should navigate without a jump picker');
modes[1].click();element('locationExplorerLookup').click();assert.equal(keypads.at(-1).title,'Enter SKU');
await keypads.at(-1).onAccept('9000001');
assert.equal(calls.at(-1).type,'SKU','Explicit SKU mode should be respected');
assert.equal(element('locationExplorerCount').textContent,'2 / 2');
await service.onAcceptedScan({upc:'052427603609'});
assert.equal(calls.at(-1).type,'UPC','Scanner always supplies a UPC');
assert.equal(element('locationExplorerCount').textContent,'1 / 2','Scanning navigates straight to item');
modes[0].click();element('locationExplorerLookup').click();await keypads.at(-1).onAccept('NOT_PLACED');
assert.ok(!element('locationExplorerMissing').classList.contains('hidden'));
assert.ok(!element('locationExplorerDisplay').classList.contains('hidden'),'Missing item uses the same normal product panel');
element('locationExplorerNewLayout').click();await new Promise(resolve=>setImmediate(resolve));
element('locationExplorerWizardCancel').click();
assert.ok(!element('locationExplorerMissing').classList.contains('hidden'),'Cancel must restore missing product');
assert.ok(!element('locationExplorerDisplay').classList.contains('hidden'),'Cancel must restore visible result');
console.log('v3.13 compact normal lookup, hidden automatic detection, scanner navigation, no jump picker, wizard return: PASS');
