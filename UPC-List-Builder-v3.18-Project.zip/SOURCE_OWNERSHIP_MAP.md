# UPC List Builder — Source Ownership Map

**Status:** CURRENT SOURCE-PLACEMENT AUTHORITY  
**Parent authority:** `CURRENT_ARCHITECTURE_AUTHORITY.md`  
**Purpose:** Answer “where does this responsibility belong, who owns it, and what may cross the boundary?”

This map describes the current approved source architecture. Git history is the historical record. It does not authorize obsolete or duplicate implementations to remain in the active tree.

## Dependency direction

Web runtime dependency direction is:

`UI / workspace controller → application or domain service → repository facade → raw persistence adapter`

Platform capabilities cross through explicit boundaries:

`web owner → bridge registration / injected platform capability → focused native owner → Android API`

Diagnostics observe every layer but never provide business truth.

Forbidden directions include repository → UI, policy → UI, diagnostics → business decisions, workspace → raw IndexedDB list persistence, domain helpers → unrelated DOM/navigation, and multiple independent implementations of one authoritative responsibility.

## Authoritative responsibility map

| Responsibility | Authoritative owner |
|---|---|
| Application composition | `application/application-shell.js` |
| Planogram Explorer explicit Field Session tag handoff | `store-locations/location-explorer-tag-service.js` |
| Shared location verification evidence and combined draft projection | `store-locations/location-verification-service.js` |
| Planogram Explorer read-only differences | `store-locations/location-explorer-difference-service.js` |
| Planogram Explorer draft and confirmed snapshot storage | `store-locations/location-explorer-draft-service.js` |
| Shared web presentation system | `styles.v059.css` |
| Application dialog presentation | `application/dialogs.css` |
| DSD presentation | `dsd/dsd.css` |
| Administration presentation | `administration/data-management.css` |
| MISC presentation | `misc/misc-workspace.css` |
| Startup orchestration | `application/startup-orchestrator.js` |
| AceNet web startup/health state projection | `application/acenet-startup-service.js` |
| Navigation/history | `application/navigation-controller.js` |
| Dialog presentation | `application/dialog-service.js` |
| Settings workflow | `application/settings-controller.js` |
| Settings persistence | `application/settings-repository.js` |
| Release presentation | `application/release-presentation-service.js` |
| UPC/SKU normalization | `identifier-normalization.js` |
| Raw IndexedDB mechanism | `db.js` |
| Master persistence facade | `master-repository.js` |
| Local persistence facade | `local-repository.js` |
| Identity persistence facade | `identity-repository.js` |
| Work Session persistence | `work-sessions/work-session-repository.js` |
| Work Session workflow | `work-sessions/work-session-service.js` |
| Migration state/retirement | `migration-repository.js` |
| Current SKU↔UPC relationships | `identifier-relationship-service.js` |
| Master-vs-Local selection | `effective-catalog-resolver.js` |
| Local identifier resolution | `local-identifier-resolver.js` |
| Normal UPC/SKU lookup orchestration | `lookup/normal-lookup-controller.js` |
| Item presentation state/rendering | `lookup/item-presentation-controller.js` |
| JavaScript AceNet request broker | `acenet-client.js` |
| AceNet price request policy | `lookup/acenet-price-service.js` |
| Catalog refresh execution | `catalog/catalog-refresh-service.js` |
| Catalog repair/maintenance | `catalog/catalog-maintenance-service.js` |
| Catalog data mapping | `catalog/catalog-mappers.js` |
| Master/ACE MISC export field identity | `catalog/standard-export-schema.js` |
| Database read-only inspection | `catalog/database-inspection-service.js` |
| Retail Units authority | `catalog/retail-units-resolver.js` |
| DSD domain/workbook rules | `ace-dsd.js` |
| DSD workspace/UI workflow | `dsd/dsd-workspace-controller.js` |
| Optional ChatGPT DSD pairing, pending import/rejection and DSD handoff | `dsd/dsd-chatgpt-import.js` |
| Optional native encrypted ChatGPT device pairing | `ChatGPTConnectionVault.kt` |
| External authenticated MCP import queue | `integrations/chatgpt-mcp/` (separate deployable service) |
| MISC domain/export rules | `ace-misc.js` |
| MISC editable draft model | `misc/misc-draft-model.js` |
| MISC resolution | `misc/misc-resolution-service.js` |
| MISC verification/export readiness | `misc/misc-verification-service.js` |
| MISC workspace/UI workflow | `misc/misc-workspace-controller.js` |
| MISC saved-session maintenance | `misc/misc-maintenance-service.js` |
| Field Session workflow | `field-session/field-session-controller.js` |
| Field Session export | `field-session/field-session-export-service.js` |
| Field Session register review and barcode viewing | `field-session/register-price-controller.js` |
| Offline UPC / EAN / Code 128 display | `field-session/register-barcode.js` |
| Scanner web lifecycle | `scanner/scanner-controller.js` |
| Scan-to-workspace routing | `scanner/scanner-workspace-router.js` |
| Identity conflict/research/deferred-refresh workflow | `identity/identity-work-controller.js` |
| Master Library UI/workflow | `catalog/master-library-controller.js` + `library-workflow-v093.js` with distinct controller/workflow roles |
| Combined Master composition/export | `combined-master-export.js` |
| XLSX parsing | `xlsx-importer.js` |
| XLSX workbook generation | `xlsx-exporter.js` |
| Application backup/restore mechanics | `data-backup.js` |
| Backup UI/orchestration | `application/data-backup-controller.js` |
| Structured diagnostic schema | `diagnostics/diagnostic-service.js` |
| Web diagnostic retention | `diagnostics/diagnostic-journal.js` |
| Diagnostic IndexedDB persistence | `diagnostics/diagnostic-repository.js` |
| Diagnostic operation/span adaptation | `diagnostics/diagnostic-operation-service.js` |
| Diagnostic export/reconstruction | `diagnostics/diagnostic-export-service.js` |
| Diagnostic UI / Deep Diagnostic controls | `diagnostics/diagnostic-ui-controller.js` |
| Native callback registration | `platform/bridge-registration.js` |
| Standard web file export delivery | `platform/file-export-delivery-service.js` |
| Browser/PWA install lifecycle | `platform/web-install-service.js` |
| Android lifecycle/WebView composition | `MainActivity.kt` |
| Native AceNet session/credentials | `AceNetSessionManager.kt` |
| Retained worker lifecycle/dispatch | `AceNetRetrievalService.kt` |
| Production AceNet page extraction | `PersistentAceNetWorker.kt` |
| AceNet session/request coordination | `AceNetProductionCoordinator.kt` |
| AceNet incident timing/escalation | `AceNetProductionIncidentController.kt` |
| Native runtime URL/error classification | `AceNetRuntimeClassifier.kt` |
| Native diagnostic file retention | `NativeDiagnosticJournal.kt` |
| Native diagnostic formatting/redaction | `NativeDiagnosticRecordFormatter.kt` |
| Native file export | `NativeFileExportService.kt` |
| Downloads/MediaStore write primitive | `NativeDownloadsWriter.kt` |
| Native update/download/install | `AppUpdateService.kt` |
| Update decision policy | `UpdatePolicy.kt` |
| Native scanner activity/camera lifecycle | `ScannerActivity.kt` |
| Scanner overlay rendering | `ScannerOverlayView.kt` |
| Scanner pure calculations | `ScannerPureLogic.kt` |
| Native product-image search | `ProductImageSearch.kt` |

## Planned store-location owners (B1.0 contracts only; modules not yet implemented)
- Pure area, placement, source membership, and last-known-reference rules: `store-locations/location-model.js`, `location-policy.js`, `location-formatter.js`, `location-reconciliation.js`, `physical-area-policy.js`, and `planogram-association-policy.js` (subject to documented consolidation).
- IndexedDB domain facade and accepted-layout mutations: `store-locations/location-repository.js` and narrowly scoped location service; `db.js` retains raw schema/index ownership; `data-backup.js` retains atomic backup/restore ownership.
- Premium location/area selection and planogram import review: dedicated `store-locations/` controllers/styles; existing application shell composes, navigation registers screens, item presentation owns lookup display.
- Planogram interpretation is AI through the existing @UPC ChatGPT integration, **not** Android PDF code. Future Cloudflare planogram validator/queue are independent of the existing DSD invoice queue and validator; OAuth/tool/API scope enforcement belongs to their existing owners.
- See `STORE_LOCATION_CONTRACT.md` and `PLANOGRAM_IMPORT_CONTRACT.md` for exact stage boundaries. These ownership reservations are not claims that those modules already exist.

## Implemented B1.1 location policy
`store-locations/location-policy.js` owns pure area normalization, collision/orphan validation, location formatting, source membership, safe identifier matching, and compact last-known references; it does not own persistence or UI. Later stages may split this focused owner only for demonstrated responsibility separation.

## Implemented B1.2 location persistence owner
`store-locations/location-repository.js` alone adapts the seven location stores using `UPCDB.open()` and short atomic transactions; ordinary SKU/UPC queries use indexes. Master/Local/catalog, DSD and lists remain untouched. Backup remains owned by `data-backup.js`.

## Build 2 physical workflow ownership (v3.09 candidate)
- `store-locations/location-work-policy.js`: pure proposals, physical-group comparisons, scoped audit classifications and approval composition.
- `store-locations/location-work-service.js`: explicit scan/typed-observation draft lifecycle, recovery in the preexisting `meta` store and review/acceptance orchestration.
- `store-locations/location-work-controller.js` and `location-work.css`: themed employee interface; accepted scanner events are routed through the single `scanner/scanner-workspace-router.js` owner.
- `store-locations/location-work-feature.js`: dedicated feature-level assembly of the existing repository, draft service, employee UI, and canonical catalog-read adapter; keeps the application shell inside its established composition size budget.
- `store-locations/location-repository.js`: authoritative existing placement/source stores and atomic stale-revision guarded acceptance. No competing catalog, scanner, Research or planogram repository.
- Existing `lookup/item-presentation-controller.js` owns the sole reused duplicate Yes/No modal; existing Research remains owned by the identity workflow.
- A temporary draft is not a second current physical layout. No passive scanner observations, employee activity ledger, or production publication are part of this candidate.

## Implemented B1.3 location UI ownership
`store-locations/location-maintenance-controller.js` owns physical area/section management DOM presentation; `location-maintenance.css` consumes the established theme variables. App shell composes the controller; navigation owns screen/Back routing. The location repository retains validated writes and in-use-area deactivation protection.

## Store locations and planogram import (candidate implementation)
- `store-locations/location-policy.js` owns pure location and source-provenance rules.
- `store-locations/location-repository.js` owns indexed local storage, atomic official source assignment and layout acceptance.
- `store-locations/location-maintenance-controller.js` owns store-area and physical-section management; `location-maintenance.css` owns its scoped premium styling.
- `store-locations/planogram-import-service.js` independently revalidates downloaded structured planogram data and SHA-256 evidence; `planogram-import-adapter.js` uses the existing encrypted paired-device connection; `planogram-import-controller.js` owns review, local approval and post-commit ACK.
- `integrations/chatgpt-mcp/cloudflare/src/planogram-validate.mjs` owns import schema/reconciliation; `planogram-queue.mjs` owns separate D1 staging. `tools.mjs` declares MCP tools and permission; `index.mjs` routes existing-token device API. DSD invoice queue, tools and workbook authority remain independent.
- No Android PDF parsing or PDF upload path is present, and source drawings never create verified physical hook locations.

## State ownership

- Active Work Session: Work Session controller/service. Workspace controllers may mutate their domain portion only through that boundary.
- DSD invoice/items: DSD workspace; persisted through Work Session service. Item `department` is classification/SKU authority. The plugin interprets manufacturer identity and invoice-versus-PO numbers upstream. The device ChatGPT adapter owns only pairing, pending/reject API calls and direct DSD draft handoff; it does not render its own item editor.
- MISC draft/verification state: MISC draft/verification owners; persisted through Work Session service.
- Catalog Master/Local records: repository facades; workflows mutate only through approved catalog/relationship services.
- SKU↔UPC identity state: Identifier Relationship Service over Identity Repository.
- AceNet web request correlation: `acenet-client.js`.
- Native AceNet authentication/session readiness: `AceNetSessionManager.kt`; production request coordination remains with the coordinator.
- Web AceNet startup/health projection: Application Shell composes the shared runtime state; `application/acenet-startup-service.js` is the native callback mutator; Settings Controller reads that projection and owns feature/UI policy.
- Navigation/history: Navigation Controller.
- Settings: Settings Controller + Settings Repository.
- Diagnostics: Diagnostic Service/Journal; observational only.
- Scanner runtime/camera state: scanner controller/activity respectively.

## Side-effect ownership

- IndexedDB primitives: `db.js`; direct domain-store access is limited to repository, migration, backup, or explicitly audited inspection boundaries.
- Network/native AceNet requests: web request broker → Android bridge → native AceNet coordinator/retrieval worker.
- Ordinary file downloads/exports: domain/application export owner prepares validated bytes or text plus filename/MIME metadata; `platform/file-export-delivery-service.js` alone selects the existing native `exportFile` bridge or browser Blob-download fallback.
- Diagnostic export remains specialized under Diagnostic Export Service because it assembles diagnostic/native evidence and may use the dedicated native diagnostic-export capability.
- Android filesystem/MediaStore: Native File Export Service / Native Downloads Writer.
- Native update network/install: App Update Service.
- DOM mutation: UI/controllers/renderers only.
- Browser install/service worker lifecycle: Web Install Service + service worker.
- Timers: owner that creates a bounded operation owns cancellation/terminal cleanup.
- Global bridge callbacks: one Bridge Registration surface.
- Diagnostics persistence: Diagnostic Repository / Native Diagnostic Journal.

## Lifecycle ownership

Persistent resources must be created and released by the same architectural owner:
- scanner camera/listeners → Scanner Controller / ScannerActivity;
- browser service-worker/install hooks → Web Install Service;
- AceNet retained worker → AceNet Retrieval Service;
- transient AceNet WebViews/session coordination → AceNet Production Coordinator;
- diagnostic flush timer → Diagnostic Journal;
- request safety timers → AceNet Client;
- navigation listeners/history hooks → Navigation Controller;
- native bridge registration → MainActivity + Bridge Registration, once per runtime composition.

Duplicate registration is prohibited.

## Boundary contracts

### Scanner → lookup/workspace
Validated scanner output crosses through Scanner Workspace Router. Routing selects DSD/manual/normal workflow; scanner code does not own lookup policy.

### Web → Android
Web code uses the single `AndroidNative` interface and registered callback families. MainActivity owns interface composition; focused native services own implementation. Web validates domain inputs before dispatch; native validates platform/session requirements. Native owns Android errors/recovery.

### Lookup → AceNet
Normal/MISC workflows call the JavaScript AceNet broker or injected service. The broker owns request IDs/correlation/timeouts. Native owns authentication/session repair and page extraction. Catalog services own durable writes after verified evidence.

### Domain → persistence
Domain/workspace code calls repository/service boundaries. Raw IndexedDB keys/store mechanics remain infrastructure concerns.

### Application → diagnostics
Callers provide meaningful context. Diagnostic Service sanitizes/normalizes; journals persist. Diagnostic failure must never change business outcome.

### Export → platform
Export owners validate/build domain output. Ordinary web delivery crosses `platform/file-export-delivery-service.js`, which selects the existing native `AndroidNative.exportFile` capability or browser download fallback without reinterpreting domain content. Diagnostic export remains on its dedicated diagnostic boundary.

## Critical workflow maps

### Scan UPC
`ScannerActivity/ScannerController → ScannerWorkspaceRouter → Manual/DSD/LookupRouter → NormalLookupController or DSDWorkspaceController → presentation/persistence owner`

### Normal lookup
`LookupRouter → NormalLookupController → LocalIdentifierResolver / EffectiveCatalogResolver → optional AceNetClient → native coordinator/retrieval worker → CatalogRefreshService → ItemPresentationController`

### ACE MISC lookup
`MiscWorkspaceController → MiscResolutionService → EffectiveCatalogResolver → optional AceNetClient → native retrieval → CatalogRefreshService → MiscDraftModel/VerificationService → WorkSessionService`

### DSD edit/export
`DsdWorkspaceController → ace-dsd domain rules → WorkSessionService` for persistence; export continues through the approved XLSX/native file-delivery boundary.

### Startup
`app.v059.js → ApplicationShell → StartupOrchestrator → migration/library/session readiness → AceNetStartupService → native session/retrieval owners → BridgeRegistration startup/health callbacks → AceNetStartupService terminal projection → Ready`

### Diagnostic trace/export
`scoped diagnostic caller → DiagnosticService → DiagnosticJournal/Repository (+ NativeDiagnosticJournal) → DiagnosticExportService merged timeline`

### Ordinary Field Session export
`SettingsRepository → StandardExportSchema → FieldSessionExportService → XLSXExporter → FileExportDeliveryService`

Settings owns the saved ordinary-export preferences: selected Master Library fields plus Force ACE MISC Format. Catalog owns the 30-field Master identity and 33-field ACE MISC header identity. Field Session Export owns purpose classification, ordinary selected-field row shaping, workbook names, Price Change workflow columns, package composition, and export diagnostics. When Force ACE MISC Format is enabled, Field Session Export delegates exact row/layout construction to the ACE MISC domain rather than duplicating MISC rules. ACE DSD remains independent.

## Directory placement

Directory `README.md` files define local scope. New code belongs in the directory of its authoritative domain. Root-level web files are retained only for established foundational/domain owners in the current non-module script-order runtime; do not add new miscellaneous root modules when a named domain directory exists.



## Public module/API documentation standard

File-level ownership headers establish the module contract. For architecturally significant public surfaces, callers must also be able to determine inputs, outputs, errors, and side effects from the source/API contract.

High-value public boundaries include:
- `UPCApplicationShell.start({release})` — input: synchronized release metadata; output: startup/composition promise; side effects: constructs/binds the web application and begins startup; errors render the fatal shell surface.
- `UPCWorkSessionService.create(repository)` — input: Work Session repository; output: workflow CRUD API; side effects: durable Work Session reads/writes only through that repository.
- `UPCEffectiveCatalogResolver.create(...)` — input: Master/Local repository capabilities; output: read-only resolved catalog evidence; errors remain explicit/inconclusive; no writes/network.
- `UPCLocalIdentifierResolver.create(...)` — input: normalized identifier plus catalog/relationship owners; output: FOUND/NOT_FOUND/AMBIGUOUS-style local identity evidence; no writes/network.
- `UPCAceNetClient.create(...)` — input: typed lookup request and injected bridge; output: request-correlated terminal result/promise; side effects: native bridge dispatch and bounded timers; owns timeout/supersession cleanup.
- `UPCDiagnosticService.create(...)` — input: journal/runtime context; output: scoped diagnostic emit/span API; side effects: diagnostic evidence only; must never determine business outcome.
- DSD/MISC workspace controller factories — input: DOM plus injected domain/persistence/platform owners; output: bound workspace controller API; side effects: DOM and active Work Session mutation only through injected boundaries.
- Repository facades — input: normalized keys/records; output: persisted/read records or explicit absence/errors; side effects limited to the physical store named by the repository.
- `MainActivity` / `AndroidNative` — input: validated web bridge calls; output: native callbacks/results; side effects delegated to focused native owners.
- `AceNetRetrievalService` — input: production retrieval requests/session readiness; output: typed retained-worker evidence; side effects: retained worker lifecycle/dispatch.
- `PersistentAceNetWorker` — input: exact production item request; output: typed extraction evidence; side effects: retailer WebView navigation/extraction only.

New or materially changed public APIs must document meaningful parameters, result contract, exceptional/error outcomes, and side effects in source comments or the governing current contract. Trivial internal helpers do not require ceremonial documentation.

## Obsolete/deprecated-code rule

No production implementation is retained solely as historical backup. Git is the rollback/history mechanism.

Current enforced source audit baseline:
- all 101 first-party production JS/CSS/Kotlin files carry exactly one current ownership header with explicit non-ownership and side-effect boundaries;
- all 83 first-party web JS/CSS runtime files are accounted for: 82 are referenced by the active page/runtime and the service worker is intentionally outside page load;
- major production directories carry local ownership README files;
- no unreferenced first-party web production file was found;
- no duplicate business owner was identified by the side-effect/ownership audit;
- ordinary file delivery is centralized behind one web platform adapter rather than duplicated across feature exporters;
- direct raw `UPCDB.*` use is confined to the approved repository/backup/migration owners;
- obsolete architecture transition/handoff/troubleshooting documents and the retired AceNet research package are removed from active source; Git history remains the archive;
- legacy migration code remains only where an explicitly maintained migration contract still requires it;
- any future obsolete implementation must be deleted when safe or carried into an explicit later task with proof of why immediate removal is unsafe.

## Change rule

A responsibility move is incomplete until source header, directory scope, this map, affected workflow/boundary documentation, tests, and architecture guards all name the same owner.

### v3.07 store-layout workflow
The location policy persists explicit overlap approvals identifying the intersecting modular and exact physical section numbers. The transactional repository rechecks all shared-space approvals against current active assignments. The location maintenance UI owns task separation, contiguous four-foot section selectors, preview and confirmation; it must not write directly to IndexedDB. The Ace planogram import controller retains source import and linking controls under its dedicated view.

## Planogram Explorer v3.15 audit draft ownership
- `store-locations/location-explorer-draft-service.js` owns independent, per-display unfinished browsing/edit/tag drafts in existing backed-up `meta` storage, plus whole-layout confirmation markers. It creates no Field Session lists and owns no official Ace records.
- `location-explorer-controller.js` presents direct Insert, Edit, Delete, and existing item review-tag choices, and submits an entire reviewed store layout to the existing atomic `location-repository.js` acceptance pathway only after explicit whole-layout confirmation.
- Original source coordinates remain separate and unchanged; unknown physical coordinates cannot be promoted into exact shelf/peg claims.
- Drafts persist until confirmation or explicit discard; one per display, up to 40 concurrently, and are checked against source digest and accepted-layout fingerprint before confirmation.

## Planogram Explorer ownership (v3.10)
- `store-locations/location-explorer-policy.js` alone owns pure traversal ordering and per-row local correction proposals; corporate row/column coordinates stay explicitly source-only.
- `store-locations/location-explorer-service.js` reads active accepted placements, assigned Ace source memberships, and offline Effective Catalog facts. It does not mutate or network-fetch prices.
- `store-locations/location-explorer-edit-service.js` prepares and commits reviewed corrections through the existing `location-repository.js` atomic accepted-layout and stale-source guard; Undo is a guarded inverse snapshot, not a parallel location store.
- `store-locations/location-explorer-controller.js` and `location-explorer.css` own the compact normal-lookup-compatible screen, direct scan/manual-to-position, previous/next navigation without jump picker, confirmed edit and guided layout entry. The controller does not own catalog or raw store logic.
- v3.13 shares the normal manual UPC/SKU keypad, product-image service, offline Level 2 pricing mapper and guarded AceNet Level 2 price service; the code does not introduce another catalog or remote lookup owner.
- `store-locations/location-explorer-feature.js` composes feature dependencies. Field Session and Planograms & Locations are entry points only. The shared `scanner/scanner-workspace-router.js` routes explicitly active explorer scans, never passive scans; application navigation owns Back/history; `location-work-controller.js` resumes original physical layout wizard with a preserved seed scan.
