/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/store-locations/location-maintenance-controller.js
 * Owner: Store Locations / premium location maintenance UI.
 * Role: Task-separated physical assignments and reusable area management.
 * Responsibility: Exact 4-foot section ranges, visual occupancy warnings, intentional shared-space confirmation.
 * Does not own: Raw IndexedDB, PDF extraction, official source membership, DSD or pricing.
 * Side effects: DOM presentation and explicit validated location repository mutations.
 * Related code: location-repository.js, location-policy.js, location-maintenance.css, planogram-import-controller.js.
 */
const UPCLocationMaintenanceController=(()=>{
'use strict';
function create({repository,policy,verification,elementById,showScreen,documentRef=document}={}){
 if(!repository||!policy||typeof elementById!=='function'||typeof showScreen!=='function')throw Error('Location UI dependencies missing');
 const $=elementById,doc=documentRef;
 let areas=[],modules=[],sources=[],editingAreaId=null,editingModularId=null,planogramRefresh=null,confirmUser=null,workRefresh=null,openVisual=null;
 let pendingFingerprint='',pendingConflicts=[];
 const make=(tag,cls,value)=>{const el=doc.createElement(tag);if(cls)el.className=cls;if(value!=null)el.textContent=value;return el};
 const set=(id,value)=>{const e=$(id);if(e)e.textContent=value};
 const namedArea=a=>a.kind==='AISLE'?'Aisle '+(a.aisle||a.id):a.name;
 const areaOf=m=>areas.find(a=>a.id===m.areaId)||m.area;
 const namesOf=m=>m.physicalSectionIds?.length?'Sections '+m.physicalSectionIds.join(', '):'Fixture '+(m.fixtureId||'—');
 const status=(value,kind='info')=>{const e=$('locationMessage');e.textContent=value;e.dataset.kind=kind;e.classList.toggle('hidden',!value)};
 const numeric=(v)=>/^\d+$/.test(String(v))?Number(v):NaN;
 function physicalSections(){
  const a=numeric($('locationStartSection').value),b=numeric($('locationEndSection').value);
  if(!Number.isSafeInteger(a)||!Number.isSafeInteger(b)||a<1||b<a)return null;
  return Array.from({length:b-a+1},(_,i)=>String(a+i));
 }
 function overlapFingerprint({name,areaId,sections,fixtureId,conflicts}){
  return JSON.stringify([editingModularId||'',name,areaId,sections,fixtureId,
   conflicts.map(x=>[x.otherId,[...x.sections].sort().join(',')])]);
 }
 function draft(approvals=[]){
  const area=areas.find(a=>a.id===$('locationModularArea').value&&a.active!==false);
  if(!area)throw Error('Choose a saved aisle or custom area first.');
  const name=$('locationModularName').value.trim();
  if(!name)throw Error('Give this modular a name (for example, Tape).');
  const sections=area.kind==='AISLE'?physicalSections():[];
  if(!sections)throw Error('Choose an end section that is the same as or after the start section.');
  const fixtureId=area.kind==='CUSTOM'?$('locationFixtureId').value.trim()||null:null;
  if(area.kind==='CUSTOM'&&!fixtureId)throw Error('Enter the custom fixture name for this area.');
  return {id:editingModularId||'pending-preview',name,active:true,
   area:{kind:area.kind,id:area.id,aisle:area.aisle},physicalSectionIds:sections,fixtureId,overlapApprovals:approvals};
 }
 function renderAssignmentPreview(){
  const preview=$('locationSectionChoices'),warning=$('locationOverlapBox');
  preview.replaceChildren();warning.classList.add('hidden');pendingFingerprint='';pendingConflicts=[];
  $('locationOverlapConfirmed').checked=false;
  const area=areas.find(x=>x.id===$('locationModularArea').value);
  $('locationBayFields').classList.toggle('hidden',area?.kind==='CUSTOM');
  $('locationFixtureWrap').classList.toggle('hidden',area?.kind!=='CUSTOM');
  if(!area){preview.append(make('span','locationPreviewQuiet','Choose a saved location to begin.'));return}
  const sections=area.kind==='AISLE'?physicalSections():[];
  if(sections===null){preview.append(make('strong','locationPreviewError','End section must be at or after the start section.'));return}
  const label=make('strong','locationPreviewTitle',namedArea(area)+' · '+(sections.length?'Sections '+sections[0]+(sections.length>1?'–'+sections.at(-1):'')+' · '+(sections.length*4)+' ft':'Custom fixture'));
  preview.append(label);
  if(area.kind==='AISLE')preview.append(make('small','locationPreviewQuiet','Each section is one specific 4-foot bay, counted from the same end of this aisle face.'));
  const name=$('locationModularName').value.trim(),fixtureId=$('locationFixtureId').value.trim();
  // Do not warn about occupied bays when the user has not started an assignment.
  if(!name)return;
  const incoming={id:editingModularId||'pending-preview',name:name||'New display',area:{kind:area.kind,id:area.id,aisle:area.aisle},physicalSectionIds:sections,fixtureId:fixtureId||null,active:true};
  try{
   const check=policy.validateActiveSectionAssignment(incoming,modules);
   if(check.conflicts.length){
    warning.classList.remove('hidden');
    pendingConflicts=check.conflicts;
    const entries=check.conflicts.map(x=>x.otherName+' — '+(x.sections.includes('FIXTURE')?'same fixture':'section'+(x.sections.length>1?'s':'')+' '+x.sections.join(', ')));
    set('locationOverlapDescription','Already assigned to '+entries.join('; ')+'. Only confirm if these modulars really share physical space.');
    pendingFingerprint=overlapFingerprint({name,areaId:area.id,sections,fixtureId,conflicts:check.conflicts});
   }else set('locationOverlapDescription','');
  }catch(e){preview.append(make('span','locationPreviewError',e.message))}
 }
 function renderAreas(preferId=''){
  const list=$('locationAreaList'),selector=$('locationModularArea'),previous=preferId||selector.value;
  list.replaceChildren();selector.replaceChildren();let opt=make('option','','Choose an aisle or custom area…');opt.value='';selector.append(opt);
  for(const area of areas.filter(a=>a.active!==false).sort((a,b)=>namedArea(a).localeCompare(namedArea(b)))){
   const row=make('div','locationSavedRow'),copy=make('div','locationSavedCopy');
   copy.append(make('strong','',namedArea(area)),make('small','',area.kind==='AISLE'?'Store aisle':'Reusable custom area'));
   const use=make('button','secondary','Select'),rename=make('button','locationQuiet','Rename'),deactivate=make('button','locationQuiet','Deactivate');
   for(const button of [use,rename,deactivate])button.type='button';
   use.addEventListener('click',()=>{selector.value=area.id;$('locationAreaManager').open=false;renderAssignmentPreview();status(namedArea(area)+' selected.')});
   rename.addEventListener('click',()=>{editingAreaId=area.id;$('locationAreaManager').open=true;$('locationAreaKind').value=area.kind;$('locationAreaName').value=area.kind==='AISLE'?(area.aisle||area.id):area.name;setAreaInputLabel();$('locationAreaSave').textContent='Save changes';$('locationAreaName').focus()});
   deactivate.addEventListener('click',async()=>{try{await repository.saveArea({...area,active:false});await refresh();status(namedArea(area)+' deactivated.')}catch(e){status(e.message,'error')}});
   row.append(copy,use,rename,deactivate);list.append(row);
   opt=make('option','',namedArea(area));opt.value=area.id;selector.append(opt);
  }
  if(!list.childElementCount)list.append(make('p','locationEmpty','No areas yet. Choose “Add an aisle or custom area” to create your first.'));
  if(areas.some(a=>a.id===previous&&a.active!==false))selector.value=previous;
 }
 function renderModulars(){
  const p=$('locationModularList');p.replaceChildren();
  for(const x of modules.sort((a,b)=>a.areaId?.localeCompare(b.areaId)||a.name.localeCompare(b.name))){
   const main=make('div','locationSavedRow'),copy=make('div','locationSavedCopy'),area=areaOf(x);
   const sharing=x.overlapApprovals?.length?' · Approved shared space':'';
   copy.append(make('strong','',x.name),make('small','',(x.active===false?'INACTIVE · ':'')+(area?namedArea(area):'Unassigned area')+' · '+namesOf(x)+sharing));
   const edit=make('button','secondary','Edit');edit.type='button';edit.dataset.locationEdit=x.id;
   edit.addEventListener('click',()=>{
    editingModularId=x.id;$('locationModularArea').value=x.areaId||x.area?.id||'';
    $('locationModularName').value=x.name;$('locationFixtureId').value=x.fixtureId||'';
    const nums=(x.physicalSectionIds||[]).map(Number).filter(Number.isInteger).sort((a,b)=>a-b);
    if(nums.length){$('locationStartSection').value=String(nums[0]);$('locationEndSection').value=String(nums.at(-1))}
    $('locationModularSave').textContent='Save display changes';$('locationModularCancel').classList.remove('hidden');
    renderAssignmentPreview();
    status('Editing '+x.name+'. Saving will validate the existing product placements and any shared sections.');
   });
   const toggle=make('button','secondary',x.active===false?'Activate':'Deactivate');
   toggle.type='button';
   toggle.addEventListener('click',async()=>{
    const nextActive=x.active===false,action=nextActive?'Activate':'Deactivate';
    if(typeof confirmUser!=='function')return status('Confirmation unavailable. No location changed.','error');
    const message=nextActive
     ?'Activate '+x.name+'? Its existing merchandise placements will become available in ordinary lookup. Any active shared-section conflict must be reviewed.'
     :'Deactivate '+x.name+'? Its locations will be hidden from ordinary lookup, but saved for later activation. Home locations elsewhere remain unaffected.';
    if(!await confirmUser(message,action+' Display'))return status(action+' canceled. Accepted locations unchanged.');
    try{await repository.saveModular({...x,active:nextActive});await refresh();
     status(x.name+(nextActive?' activated; its accepted locations are searchable.':' deactivated; accepted locations retained but hidden from lookup.'));
    }catch(e){status('No changes saved: '+e.message,'error')}
   });
   if(x.active===false)main.append(copy,toggle);
   else main.append(copy,edit,toggle);
   p.append(main);
  }
  if(!p.childElementCount)p.append(make('p','locationEmpty','No displays assigned. Choose an aisle and set the exact four-foot section range above.'));
 }
 function renderSources(){
  const p=$('locationSourceList');p.replaceChildren();
  for(const source of sources){const row=make('div','locationSavedRow'),copy=make('div','locationSavedCopy');
   copy.append(make('strong','',source.name||source.planogramId),make('small','',(source.modularId?'Assigned':'Not yet assigned')+' · '+(source.planogramId||'Official source')));row.append(copy);p.append(row)}
  if(!p.childElementCount)p.append(make('p','locationEmpty','No official planograms saved locally yet. Import one through ChatGPT, then check pending planograms.'));
 }
 async function refreshOverview(){
  const host=$('locationVerificationList');if(!host||!verification)return;
  host.replaceChildren();
  const displays=await verification.summary();
  if(!displays.length){host.append(make('p','locationEmpty','No saved displays yet. Create an aisle and display under Store Locations.'));return}
  for(const display of displays){
   const modular=modules.find(x=>x.id===display.modularId),area=modular?areaOf(modular):null;
   const source=sources.find(x=>x.current===true&&x.modularId===display.modularId);
   const card=make('details','locationVerificationItem'),head=make('summary','locationVerificationName'),summary=make('strong','',display.name);
   const place=area?(namedArea(area)+' · '+namesOf(modular)):'Location unavailable';
   const flags=[place,source?'Ace: '+(source.name||source.planogramId):'No Ace source assigned'];
   if(display.guided)flags.push('Unfinished '+(display.guided.mode==='AUDIT'?'physical audit':'layout build')+' · '+display.guided.recorded+' scans');
   if(display.visual)flags.push('Unfinished visual review · '+display.visual.edits+' edits');
   let proof=display.latest;
   if(proof){
    let valid=false;
    try{const e=await verification.evidence(display.modularId);valid=e.sourceSignature===proof.sourceSignature&&e.layoutFingerprint===proof.layoutFingerprint}catch{}
    const method=({VISUAL_ACE_MATCH:'Visually confirmed to match Ace',VISUAL_STORE_LAYOUT:'Visual store-layout confirmation',
     GUIDED_PHYSICAL_AUDIT:'Physical scan audit',GUIDED_LAYOUT_BUILD:'Scanned floor-layout build',
     GUIDED_LAYOUT_CORRECTION:'Scanned layout correction'})[proof.method]||'Verification';
    flags.push((valid?'Verified':'Prior verification — layout or Ace source has changed')+' · '+method+(proof.complete===false?' (partial)':'')+' · '+new Date(proof.confirmedAt).toLocaleDateString());
   }else if(display.legacy)flags.push('Previous visual confirmation · '+(display.legacy.kind==='ACE'?'Ace match':'Store layout')+' · '+new Date(display.legacy.confirmedAt).toLocaleDateString()+' (earlier version, review current revision)');
   else flags.push('Not yet verified');
   head.append(summary,make('small','',flags.join(' | ')));card.append(head);
   const tools=make('div','locationVerificationActions');
   const add=(label,fn)=>{const b=make('button','secondary',label);b.type='button';b.addEventListener('click',()=>{void Promise.resolve().then(fn).catch(e=>status(e.message,'error'))});tools.append(b)};
   add(display.visual?'Resume Visual':'Visual Review',()=>openVisual?.(display.modularId));
   add(display.guided?'Resume Guided':'Guided Audit',()=>openWork(display.modularId));
   add('Physical Assignment',()=>openAssignment(display.modularId));
   add('Ace Assignment',()=>openSourceAssignment(display.modularId));
   card.append(tools);host.append(card);
  }
 }
 async function openAssignment(modularId){
  showScreen('locationScreen','Planograms & Locations');showTab('layout');await refresh();
  const button=[...doc.querySelectorAll('#locationModularList [data-location-edit]')].find(b=>b.dataset.locationEdit===modularId);
  if(!button)throw Error('Physical display assignment was not found');
  button.click();$('locationModularName').scrollIntoView?.({block:'center'});
 }
 async function openWork(modularId){
  showScreen('locationScreen','Planograms & Locations');showTab('work');await refresh();
  const input=$('locationWorkModular');input.value=modularId;input.dispatchEvent(new Event('change',{bubbles:true}));
  $('locationWorkHeading').scrollIntoView?.({block:'start'});
 }
 async function openSourceAssignment(modularId){
  showScreen('locationScreen','Planograms & Locations');showTab('planograms');await refresh();
  if(planogramRefresh)await planogramRefresh();
  const input=$('planogramModularAssignSelect');input.value=modularId;input.dispatchEvent(new Event('change',{bubbles:true}));
 }
 async function refresh(preferArea=''){
  try{[areas,modules,sources]=await Promise.all([repository.listAreas(),repository.listModulars(),repository.listSources()]);
   renderAreas(preferArea);renderModulars();renderSources();renderAssignmentPreview();
   await refreshOverview();
   if(workRefresh)void Promise.resolve().then(workRefresh).catch(()=>{});
   if(!areas.some(a=>a.active!==false))$('locationAreaManager').open=true;
  }catch(e){status('Could not load saved locations: '+e.message,'error')}
 }
 function showTab(name){
  for(const [mode,tab,pane] of [['layout','locationLayoutTab','locationLayoutPane'],['work','locationWorkTab','locationWorkPane'],['planograms','locationPlanogramTab','locationPlanogramPane']]){
   const active=mode===name;$(tab).classList.toggle('active',active);$(tab).setAttribute('aria-selected',String(active));
   $(pane).classList.toggle('hidden',!active);
  }
  if(name==='planograms'&&planogramRefresh)void Promise.resolve().then(planogramRefresh).catch(()=>{});
 }
 async function open(){showScreen('locationScreen','Planograms & Locations');showTab('layout');await refresh()}
 function resetArea(){editingAreaId=null;$('locationAreaName').value='';$('locationAreaSeparate').checked=false;
  $('locationAreaSeparateWrap').classList.add('hidden');$('locationAreaSave').textContent='Save area';set('locationAreaSuggestions','')}
 function resetModular(){editingModularId=null;$('locationModularName').value='';$('locationFixtureId').value='';
  $('locationModularSave').textContent='Save display location';$('locationModularCancel').classList.add('hidden');
  $('locationStartSection').value='1';$('locationEndSection').value='1';renderAssignmentPreview()}
 function setAreaInputLabel(){set('locationAreaNameLabelText',$('locationAreaKind').value==='AISLE'?'Aisle number':'Custom area name');
  $('locationAreaName').placeholder=$('locationAreaKind').value==='AISLE'?'Example: 8':'Example: Behind Counter'}
 async function saveArea(){
  const kind=$('locationAreaKind').value,raw=$('locationAreaName').value.trim();
  if(!raw)return status('Enter the aisle number or custom area name.','error');
  if(kind==='AISLE'&&!/^\d{1,3}[A-Za-z]?$/.test(raw))return status('Enter an aisle number such as 8 or 8A.','error');
  const name=kind==='AISLE'?'Aisle '+raw:raw;
  const candidates=policy.findPotentialAreaDuplicates(name,areas,editingAreaId);
  if(candidates.some(x=>x.match==='EXACT')){set('locationAreaSuggestions','This area already exists. Select it from the saved list below.');return status('Duplicate area blocked.','error')}
  const near=candidates.find(c=>c.match==='REVIEW');
  if(near&&!$('locationAreaSeparate').checked){set('locationAreaSuggestions','Possibly the same place as '+near.name+'. Select the existing area or confirm these really differ.');
   $('locationAreaSeparateWrap').classList.remove('hidden');return status('Confirm which area you mean.','warning')}
  const prior=areas.find(a=>a.id===editingAreaId);
  const id=editingAreaId||(kind==='AISLE'?'aisle-'+raw:doc.defaultView?.crypto?.randomUUID?.()||'area-'+Date.now().toString(36));
  const data=kind==='AISLE'?{id,kind,name,aisle:raw,active:true}:{id,kind,name,active:true};
  try{await repository.saveArea(prior?{...prior,...data}:data);resetArea();await refresh(id);$('locationAreaManager').open=false;
   status(namedArea(data)+' saved. Now name the display and choose its exact position.')}
  catch(e){status('Area not saved: '+e.message,'error')}
 }
 async function saveModular(){
  let input;
  try{input=draft()}catch(e){return status(e.message,'error')}
  const check=policy.validateActiveSectionAssignment(input,modules);
  let confirmed=[];
  if(check.conflicts.length){
   const mark=overlapFingerprint({name:input.name,areaId:input.area.id,sections:input.physicalSectionIds,fixtureId:input.fixtureId||'',conflicts:check.conflicts});
   if(mark!==pendingFingerprint||!$('locationOverlapConfirmed').checked){renderAssignmentPreview();return status('Shared sections require checking the confirmation box before saving.','warning')}
   confirmed=check.conflicts.map(x=>({modularId:x.otherId,sections:x.sections,confirmedAt:Date.now()}));
  }
  const newId=editingModularId||doc.defaultView?.crypto?.randomUUID?.()||'modular-'+Date.now().toString(36);
  try{const result=await repository.saveModular({...input,id:newId,overlapApprovals:confirmed});
   const detail=input.physicalSectionIds.length?'sections '+input.physicalSectionIds.join('–'):'fixture '+input.fixtureId;
   resetModular();await refresh(input.area.id);status(result.name+' assigned to '+detail+(confirmed.length?' with approved shared sections.':'.'));
  }catch(e){status('No changes saved: '+e.message,'error')}
 }
 function bind(){
  $('openLocations').addEventListener('click',open);
  $('locationLayoutTab').addEventListener('click',()=>showTab('layout'));
  $('locationWorkTab').addEventListener('click',()=>showTab('work'));
  $('locationPlanogramTab').addEventListener('click',()=>showTab('planograms'));
  $('locationGoLayout').addEventListener('click',()=>showTab('layout'));
  $('locationCreateArea').addEventListener('click',()=>{$('locationAreaManager').open=true;$('locationAreaManager').scrollIntoView({block:'start',behavior:'smooth'});$('locationAreaName').focus()});
  $('locationModularArea').addEventListener('change',renderAssignmentPreview);
  for(const id of ['locationStartSection','locationEndSection','locationFixtureId','locationModularName'])$(id).addEventListener('input',renderAssignmentPreview);
  for(const id of ['locationStartSection','locationEndSection']){
   const select=$(id);for(let n=1;n<=32;n++){const o=make('option','',n+' · '+((n-1)*4)+'–'+(n*4)+' ft');o.value=String(n);select.append(o)}select.value='1';
  }
  $('locationAreaSave').addEventListener('click',saveArea);$('locationAreaCancel').addEventListener('click',resetArea);
  $('locationModularSave').addEventListener('click',saveModular);$('locationModularCancel').addEventListener('click',()=>{resetModular();status('Edit canceled.')});
  $('locationAreaKind').addEventListener('change',()=>{set('locationAreaSuggestions','');$('locationAreaSeparateWrap').classList.add('hidden');setAreaInputLabel()});
  $('locationAreaName').addEventListener('input',()=>{set('locationAreaSuggestions','');$('locationAreaSeparate').checked=false;$('locationAreaSeparateWrap').classList.add('hidden')});
  setAreaInputLabel();renderAssignmentPreview();
 }
 return Object.freeze({bind,open,refresh,openAssignment,openWork,openSourceAssignment,
  setOpenVisual(callback){openVisual=callback},setPlanogramRefresh(callback){planogramRefresh=callback},
  setConfirmUser(callback){confirmUser=callback},setWorkRefresh(callback){workRefresh=callback}});
}
return Object.freeze({create});
})();
