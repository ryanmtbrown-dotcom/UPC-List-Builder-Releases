#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

echo '=== UPC List Builder verification ==='
[[ ! -e app/src/main/assets/www/asset-integrity.json ]] || { echo 'ERROR: obsolete stale asset-integrity.json must not be shipped' >&2; exit 1; }
[[ ! -e app/src/main/assets/www/build.json ]] || { echo 'ERROR: obsolete build.json release identity must not be shipped' >&2; exit 1; }
node scripts/sync-release-identity.mjs --check
echo 'Maintained requirement test suite: current behavioral and architecture contracts.'
echo 'Verification covers current subsystem behavior, ownership boundaries, diagnostics, build, and release invariants.'
echo

required=(
  settings.gradle.kts
  build.gradle.kts
  gradle.properties
  app/build.gradle.kts
  app/src/main/AndroidManifest.xml
  app/src/main/java/com/rmtb/upclistbuilder/MainActivity.kt
  app/src/main/java/com/rmtb/upclistbuilder/AceNetProductionCoordinator.kt
  app/src/main/java/com/rmtb/upclistbuilder/AceNetProductionIncidentController.kt
  app/src/main/java/com/rmtb/upclistbuilder/AceNetRuntimeClassifier.kt
  app/src/main/java/com/rmtb/upclistbuilder/AppUpdateService.kt
  app/src/main/java/com/rmtb/upclistbuilder/NativeFileExportService.kt
  app/src/main/java/com/rmtb/upclistbuilder/NativeDiagnosticJournal.kt
  app/src/main/java/com/rmtb/upclistbuilder/NativeDiagnosticRecordFormatter.kt
  app/src/main/java/com/rmtb/upclistbuilder/AceNetSessionManager.kt
  app/src/main/java/com/rmtb/upclistbuilder/AceNetRetrievalService.kt
  app/src/main/java/com/rmtb/upclistbuilder/NativeDownloadsWriter.kt
  app/src/main/assets/www/index.html
  app/src/main/assets/www/app.v059.js
  app/src/main/assets/www/service-worker.js
  app/src/main/assets/www/manifest.webmanifest
  scripts/sync-release-identity.mjs
  app/src/main/assets/www/application/application-shell.js
  app/src/main/assets/www/diagnostics/diagnostic-repository.js
  app/src/main/assets/www/diagnostics/diagnostic-journal.js
  app/src/main/assets/www/diagnostics/diagnostic-service.js
  app/src/main/assets/www/diagnostics/diagnostic-operation-service.js
  app/src/main/assets/www/diagnostics/diagnostic-export-service.js
  app/src/main/assets/www/diagnostics/diagnostic-ui-controller.js
  app/src/main/assets/www/application/startup-orchestrator.js
  app/src/main/assets/www/application/navigation-controller.js
  app/src/main/assets/www/application/settings-controller.js
  app/src/main/assets/www/application/dialog-service.js
  app/src/main/assets/www/application/dom-adapter.js
  app/src/main/assets/www/platform/bridge-registration.js
  app/src/main/assets/www/platform/file-export-delivery-service.js
  app/src/main/assets/www/scanner/scanner-workspace-router.js
  app/src/main/assets/www/lookup/lookup-router.js
  app/src/main/assets/www/misc/misc-runtime-resolver.js
  app/src/main/assets/www/styles.v059.css
  app/src/main/assets/www/application/dialogs.css
  app/src/main/assets/www/dsd/dsd.css
  app/src/main/assets/www/administration/data-management.css
  app/src/main/assets/www/misc/misc-workspace.css
  app/src/main/assets/www/identifier-normalization.js
  app/src/main/assets/www/catalog-refresh-policy.js
  app/src/main/assets/www/acenet-client.js
  app/src/main/assets/www/operation-tracker.js
  app/src/main/assets/www/db.js
  app/src/main/assets/www/catalog/catalog-mappers.js
  app/src/main/assets/www/catalog/database-inspection-service.js
  app/src/main/assets/www/catalog/catalog-refresh-service.js
  app/src/main/assets/www/catalog/catalog-maintenance-service.js
  app/src/main/assets/www/lookup/item-record-mapper.js
  app/src/main/assets/www/lookup/normal-lookup-controller.js
  app/src/main/assets/www/lookup/product-image-service.js
  app/src/main/assets/www/lookup/item-presentation-controller.js
  app/src/main/assets/www/field-session/field-session-export-service.js
  app/src/main/assets/www/misc/misc-draft-model.js
  app/src/main/assets/www/misc/misc-resolution-service.js
  app/src/main/assets/www/misc/misc-verification-service.js
  app/src/main/assets/www/misc/misc-workspace-controller.js
  app/src/main/assets/www/dsd/dsd-workspace-controller.js
  app/src/main/assets/www/work-sessions/work-session-repository.js
  app/src/main/assets/www/work-sessions/work-session-service.js
  app/src/main/assets/www/misc/misc-maintenance-service.js
  app/src/main/assets/www/master-repository.js
  app/src/main/assets/www/local-repository.js
  app/src/main/assets/www/identity-repository.js
  app/src/main/assets/www/migration-repository.js
  app/src/main/assets/www/effective-catalog-resolver.js
  app/src/main/assets/www/identifier-relationship-service.js
  app/src/main/assets/www/local-identifier-resolver.js
  app/src/main/assets/www/data-backup.js
  app/src/main/assets/www/xlsx-importer.js
  app/src/main/assets/www/xlsx-exporter.js
  app/src/main/assets/www/ace-misc.js
  app/src/main/assets/www/vendor/jszip.min.js
  install-release-termux.sh
  signing/upc-list-builder.jks
  .github/workflows/build-apk.yml
  AI_START_HERE.md
  DOCUMENTATION_INDEX.md
  CURRENT_ARCHITECTURE_AUTHORITY.md
  SOURCE_OWNERSHIP_MAP.md
  DEPLOYMENT_CONTRACT.md
  STORE_LOCATION_CONTRACT.md
  TERMUX_DEPLOYMENT_CONTRACT.md
  PLANOGRAM_IMPORT_CONTRACT.md
  NORMAL_ITEM_SEARCH_CONTRACT.md
  MASTER_LIBRARY_CONTRACT.md
  RETAIL_UNITS_CONTRACT.md
  IDENTIFIER_RESOLUTION_CONTRACT.md
  IDENTITY_RESEARCH_RESOLUTION_CONTRACT.md
  PRODUCT_DATA_AUTHORITY_CONTRACT.md
  PRODUCT_IDENTITY_INDEX_CONTRACT.md
  PRICE_AUTHORITY_CONTRACT.md
  ACENET_CLIENT_BROKER_CONTRACT.md
ACENET_COMPARISON_TOGGLE_CONTRACT.md
ACENET_ITEM_DATA_EXTRACTION_REFERENCE.md
  DIAGNOSTICS_CONTRACT.md
  DIAGNOSTIC_EXPORT_CONTRACT.md
  APPLICATION_DATA_BACKUP_CONTRACT.md
  REPOSITORY_BOUNDARIES_CONTRACT.md
  EFFECTIVE_CATALOG_RESOLVER_CONTRACT.md
  IDENTIFIER_RELATIONSHIP_SERVICE_CONTRACT.md
  LOCAL_IDENTIFIER_RESOLVER_CONTRACT.md
  CATALOG_FIELD_MAPPING_CONTRACT.md
  CATALOG_REFRESH_POLICY_CONTRACT.md
  ITEM_PRESENTATION_CONTRACT.md
  UI_OPERATION_LIFECYCLE_CONTRACT.md
  NAVIGATION_CONTRACT.md
  SETTINGS_PERSISTENCE_CONTRACT.md
  LIST_MANAGEMENT_CONTRACT.md
  NATIVE_ANDROID_BRIDGE_CONTRACT.md
  NATIVE_TRACE_CONTRACT.md
  RELEASE_VERSIONING_CONTRACT.md
  ACENET_AUTH_SESSION_CONTRACT.md
  ACE_MISC_ADDITIONAL_UPC_CONTRACT.md
  ACENET_ITEM_RETRIEVAL_CONTRACT.md
  ACENET_SERVICE_HEALTH_CONTRACT.md
  ACENET_SESSION_RETRIEVAL_BOUNDARY_CONTRACT.md
  NETWORK_CONNECTIVITY_CONTRACT.md
  APPLICATION_LIFECYCLE_CONTRACT.md
    UPDATER_SETUP.md
)
for f in "${required[@]}"; do
  [[ -f "$f" ]] || { echo "ERROR: missing required project file: $f" >&2; exit 1; }
done

# Authority reset: only deliberately reconstructed tests may exist.
[[ -f tests/diagnostics-reconstruction-test.mjs ]] || { echo 'ERROR: reconstructed diagnostics test is missing' >&2; exit 1; }
mapfile -t TEST_FILES < <(find tests -maxdepth 1 -type f -printf '%f\n' | sort)
EXPECTED_TESTS=$'ace-dsd-department-authority-v235-test.mjs
ace-misc-additional-upc-v211-test.mjs
ace-misc-resolver-scope-v265-test.mjs
acenet-catalog-forensics-v244-test.mjs
acenet-catalog-single-page-v243-test.mjs
acenet-client-broker-stage5-test.mjs
acenet-event-driven-continuation-v218-test.mjs
acenet-event-readiness-v219-test.mjs
acenet-extraction-diagnostics-v219-test.mjs
acenet-login-session-v260-test.mjs
acenet-not-found-classifier-v292-test.mjs
acenet-price-extractor-v219-test.mjs
acenet-service-network-contract-test.mjs
acenet-session-local-repair-v259-test.mjs
acenet-session-retrieval-contract-test.mjs
acenet-simple-production-lookup-v213-test.mjs
acenet-speed-health-v218-test.mjs
acenet-startup-bridge-v282-test.mjs
acenet-transport-recovery-v290-test.mjs
acenet-upc-enrichment-misc-bulk-v257-test.mjs
acenet-upc-extractor-v219-test.mjs
acenet-visual-status-v304-test.mjs
add-to-local-library-batch-v242-runtime-test.mjs
application-lifecycle-v190-test.mjs
application-shell-contracts-test.mjs
catalog-refresh-policy-stage7-test.mjs
chatgpt-dsd-import-test.mjs
classification-code-normalization-v266-test.mjs
combined-master-export-stage8-test.mjs
comparison-toggle-contract-test.mjs
connectivity-current-startup-v193-test.mjs
data-backup-restore-v267-test.mjs
database-viewer-v233-test.mjs
deep-diagnostic-evidence-v305-test.mjs
deployment-contract-compliance-v238-test.mjs
deployment-end-to-end-v238-test.mjs
deployment-github-default-v281-test.mjs
deployment-network-resilience-v236-test.mjs
deprecated-retirement-stage9-test.mjs
diagnostic-export-contract-test.mjs
diagnostic-export-runtime-v196-test.mjs
diagnostic-health-repair-v192-test.mjs
diagnostic-provenance-test.mjs
diagnostic-settings-deep-mode-v283-test.mjs
diagnostic-streaming-regression-test.mjs
diagnostics-contract-test.mjs
diagnostics-reconstruction-test.mjs
effective-catalog-resolver-stage3-test.mjs
export-field-selection-v288-test.mjs
field-session-missing-label-test.mjs
file-export-delivery-stage13-test.mjs
identifier-relationship-performance-stage4-test.mjs
identifier-relationship-service-stage4-test.mjs
identifier-resolution-contract-test.mjs
identity-resolution-v291-test.mjs
identity-work-queue-render-v293-regression-test.mjs
level2-retail-authority-test.mjs
list-purpose-presentation-v190-test.mjs
local-identifier-resolver-stage4-test.mjs
location-verification-v318-test.mjs
master-library-contract-test.mjs
native-bridge-trace-contract-test.mjs
normal-item-search-contract-test.mjs
obsolete-feature-absence-test.mjs
package-release-pipefail-v282-test.mjs
persistent-retailer-warmup-v221-test.mjs
persistent-worker-lifecycle-v225-test.mjs
planogram-explorer-audit-v315-test.mjs
planogram-explorer-compact-v313-test.mjs
planogram-explorer-differences-v316-test.mjs
planogram-explorer-v312-test.mjs
planogram-session-entry-v311-test.mjs
presentation-html-css-contract-v284-test.mjs
price-authority-contract-test.mjs
product-identity-index-v228-test.mjs
product-identity-index-v229-test.mjs
product-identity-index-v230-test.mjs
product-identity-index-v231-test.mjs
product-identity-index-v232-closure-test.mjs
register-price-workflow-test.mjs
release-versioning-contract-test.mjs
repository-facades-stage2-test.mjs
retail-units-contract-test.mjs
shared-mechanisms-stage1-test.mjs
source-ownership-v279-test.mjs
startup-emergency-failopen-v314-test.mjs
startup-engine-consolidation-v251-test.mjs
startup-health-probe-test.mjs
startup-health-terminal-v195-test.mjs
startup-pricing-policy-test.mjs
startup-retailer-sso-deadline-v283-test.mjs
startup-retailer-sso-v254-test.mjs
startup-verification-repair-v252-test.mjs
startup-warmup-orchestration-v222-test.mjs
startup-warmup-proof-v224-test.mjs
store-area-policy-test.mjs
store-location-contract-test.mjs
store-location-explorer-v310-test.mjs
store-location-lookup-v1-test.mjs
store-location-maintenance-test.mjs
store-location-model-test.mjs
store-location-persistence-test.mjs
store-location-work-v309-test.mjs
store-planogram-association-test.mjs
store-planogram-device-import-test.mjs
store-planogram-refresh-atomic-test.mjs
structured-diagnostics-v279-test.mjs
termux-clean-release-install-v212-test.mjs
unified-local-resolution-v264-test.mjs'
ACTUAL_TESTS="$(printf '%s\n' "${TEST_FILES[@]}")"
[[ "$ACTUAL_TESTS" == "$EXPECTED_TESTS" ]] || { echo 'ERROR: unexpected or non-maintained behavioral tests are present' >&2; printf '%s\n' "${TEST_FILES[@]}" >&2; exit 1; }
mapfile -t ROOT_DOCS < <(find . -maxdepth 1 -type f \( -iname '*.md' -o -iname '*.txt' \) -printf '%f\n' | sort)
EXPECTED_DOCS="$(cat <<'EOF'
ACENET_AUTH_SESSION_CONTRACT.md
ACENET_CLIENT_BROKER_CONTRACT.md
ACENET_COMPARISON_TOGGLE_CONTRACT.md
ACENET_ITEM_DATA_EXTRACTION_REFERENCE.md
ACENET_ITEM_RETRIEVAL_CONTRACT.md
ACENET_SERVICE_HEALTH_CONTRACT.md
ACENET_SESSION_RETRIEVAL_BOUNDARY_CONTRACT.md
ACE_MISC_ADDITIONAL_UPC_CONTRACT.md
AI_START_HERE.md
APPLICATION_DATA_BACKUP_CONTRACT.md
APPLICATION_LIFECYCLE_CONTRACT.md
CATALOG_FIELD_MAPPING_CONTRACT.md
CATALOG_REFRESH_POLICY_CONTRACT.md
COMBINED_MASTER_EXPORT_CONTRACT.md
CURRENT_ARCHITECTURE_AUTHORITY.md
DEPLOYMENT_CONTRACT.md
DIAGNOSTICS_CONTRACT.md
DIAGNOSTIC_EXPORT_CONTRACT.md
DOCUMENTATION_INDEX.md
EFFECTIVE_CATALOG_RESOLVER_CONTRACT.md
IDENTIFIER_RELATIONSHIP_SERVICE_CONTRACT.md
IDENTIFIER_RESOLUTION_CONTRACT.md
IDENTITY_RESEARCH_RESOLUTION_CONTRACT.md
ITEM_PRESENTATION_CONTRACT.md
LIST_MANAGEMENT_CONTRACT.md
LOCAL_IDENTIFIER_RESOLVER_CONTRACT.md
MASTER_LIBRARY_CONTRACT.md
NATIVE_ANDROID_BRIDGE_CONTRACT.md
NATIVE_TRACE_CONTRACT.md
NAVIGATION_CONTRACT.md
NETWORK_CONNECTIVITY_CONTRACT.md
NORMAL_ITEM_SEARCH_CONTRACT.md
PLANOGRAM_IMPORT_CONTRACT.md
PRICE_AUTHORITY_CONTRACT.md
PRODUCT_DATA_AUTHORITY_CONTRACT.md
PRODUCT_IDENTITY_INDEX_CONTRACT.md
RELEASE_VERSIONING_CONTRACT.md
REPOSITORY_BOUNDARIES_CONTRACT.md
RETAIL_UNITS_CONTRACT.md
SETTINGS_PERSISTENCE_CONTRACT.md
SOURCE_OWNERSHIP_MAP.md
STORE_LOCATION_CONTRACT.md
TERMUX_DEPLOYMENT_CONTRACT.md
UI_OPERATION_LIFECYCLE_CONTRACT.md
UPDATER_SETUP.md
EOF
)"
ACTUAL_DOCS="$(printf '%s\n' "${ROOT_DOCS[@]}")"
[[ "$ACTUAL_DOCS" == "$EXPECTED_DOCS" ]] || {
  echo 'ERROR: unexpected root documentation found. Current documentation set permits exactly:' >&2
  printf '%s\n' "$EXPECTED_DOCS" >&2
  echo 'Actual:' >&2
  printf '%s\n' "$ACTUAL_DOCS" >&2
  exit 1
}

[[ -f install-release-termux.sh ]] || { echo 'ERROR: install-release-termux.sh missing' >&2; exit 1; }

# REQUIRED current-documentation and ownership authority guards.
grep -q '## Ace-sourced merchandise' PRODUCT_DATA_AUTHORITY_CONTRACT.md
grep -q 'A scanned UPC or manually typed UPC/SKU is a lookup key' PRODUCT_DATA_AUTHORITY_CONTRACT.md
grep -q 'UPC Enrichment must never be operationally ON while Comparison Pricing is OFF' ACENET_COMPARISON_TOGGLE_CONTRACT.md
grep -q '## User resolution actions' IDENTITY_RESEARCH_RESOLUTION_CONTRACT.md
grep -q 'Refresh Pending Item Data' IDENTITY_RESEARCH_RESOLUTION_CONTRACT.md
grep -q '## REQUIRED reading-chain rule' AI_START_HERE.md
grep -q 'GitHub-native deployment is the normal release path' AI_START_HERE.md
grep -q '## REQUIRED current-architecture routing' AI_START_HERE.md
grep -q 'CURRENT_ARCHITECTURE_AUTHORITY.md' AI_START_HERE.md
grep -q 'SOURCE_OWNERSHIP_MAP.md' AI_START_HERE.md
grep -q '# UPC List Builder Documentation Index' DOCUMENTATION_INDEX.md
grep -q '## Required reading order' DOCUMENTATION_INDEX.md
grep -q '## Architectural model' CURRENT_ARCHITECTURE_AUTHORITY.md
grep -q '## Verified architecture-stage status' CURRENT_ARCHITECTURE_AUTHORITY.md
grep -q '## Scope-safe stopping rule' CURRENT_ARCHITECTURE_AUTHORITY.md
grep -q '## Authoritative responsibility map' SOURCE_OWNERSHIP_MAP.md
grep -q '## State ownership' SOURCE_OWNERSHIP_MAP.md
grep -q '## Side-effect ownership' SOURCE_OWNERSHIP_MAP.md
grep -q '## Lifecycle ownership' SOURCE_OWNERSHIP_MAP.md
grep -q '## Critical workflow maps' SOURCE_OWNERSHIP_MAP.md
grep -q 'scripts/sync-release-identity.mjs' RELEASE_VERSIONING_CONTRACT.md
grep -q 'gradle.properties' RELEASE_VERSIONING_CONTRACT.md
grep -q '## Canonical event model' DIAGNOSTICS_CONTRACT.md
grep -q '## GitHub-native deployment — normal path' DEPLOYMENT_CONTRACT.md
grep -q '## Public updater boundary' DEPLOYMENT_CONTRACT.md
grep -q '## Termux fallback / recovery' DEPLOYMENT_CONTRACT.md
grep -q '## REQUIRED Termux fallback user-facing handoff — exact canonical procedure' TERMUX_DEPLOYMENT_CONTRACT.md
grep -q 'REQUIRED Termux fallback changed-release procedure' TERMUX_DEPLOYMENT_CONTRACT.md
grep -q 'install-release-termux.sh' TERMUX_DEPLOYMENT_CONTRACT.md
grep -q 'deploy-termux.sh' TERMUX_DEPLOYMENT_CONTRACT.md
grep -q -- '--rebuild-head' TERMUX_DEPLOYMENT_CONTRACT.md
grep -q 'REQUIRED no-change exception' TERMUX_DEPLOYMENT_CONTRACT.md
for stale in ARCHITECTURE_REFACTOR_TRANSITION_AUTHORITY.md ARCHITECTURE_REFACTOR_TROUBLESHOOTING_LEDGER.md UPC_List_Builder_Architecture_Refactor_HANDOFF_Stage7_COMPLETE_2026-10-02.md; do
  [[ ! -e "$stale" ]] || { echo "ERROR: historical architecture document must not remain active: $stale" >&2; exit 1; }
done
[[ ! -e research/acenet_retrieval_vnext ]] || { echo 'ERROR: retired AceNet research package must not remain in active source' >&2; exit 1; }

# Structural/source syntax checks only. Behavioral contracts/tests will be rebuilt subsystem by subsystem.
grep -q 'gradleProperty("UPC_VERSION_NAME")' app/build.gradle.kts
grep -q 'gradleProperty("UPC_VERSION_CODE")' app/build.gradle.kts
grep -q 'buildConfigField("String", "UPC_BUILD_ID"' app/build.gradle.kts
grep -q 'BuildConfig.UPC_BUILD_ID' app/src/main/java/com/rmtb/upclistbuilder/MainActivity.kt
CURRENT_BUILD_ID="$(sed -n 's/^UPC_BUILD_ID=//p' gradle.properties | tail -n1)"
if grep -Fq "\"$CURRENT_BUILD_ID\"" app/src/main/java/com/rmtb/upclistbuilder/MainActivity.kt; then
  echo 'ERROR: MainActivity contains a copied current build ID instead of BuildConfig authority' >&2
  exit 1
fi
grep -q 'compileSdk = 36' app/build.gradle.kts
grep -q 'targetSdk = 36' app/build.gradle.kts
# Native compile-risk guard: this project does not expose generated BuildConfig to runtime Kotlin.
if grep -R -q 'BuildConfig\.VERSION_NAME' app/src/main/java/com/rmtb/upclistbuilder --include='*.kt'; then
  echo 'ERROR: native runtime must not depend on unavailable BuildConfig.VERSION_NAME' >&2
  exit 1
fi
grep -q 'private fun installedAppVersion()' app/src/main/java/com/rmtb/upclistbuilder/NativeDiagnosticRecordFormatter.kt
grep -q 'context.packageManager.getPackageInfo(context.packageName, 0).versionName' app/src/main/java/com/rmtb/upclistbuilder/NativeDiagnosticRecordFormatter.kt

# Native ownership guards.
grep -q 'aceNetCoordinator = AceNetProductionCoordinator(' app/src/main/java/com/rmtb/upclistbuilder/MainActivity.kt
grep -q 'class AceNetProductionCoordinator' app/src/main/java/com/rmtb/upclistbuilder/AceNetProductionCoordinator.kt
grep -q 'class AceNetProductionIncidentController' app/src/main/java/com/rmtb/upclistbuilder/AceNetProductionIncidentController.kt
grep -q 'private val productionIncident = AceNetProductionIncidentController()' app/src/main/java/com/rmtb/upclistbuilder/AceNetProductionCoordinator.kt
grep -q 'object AceNetRuntimeClassifier' app/src/main/java/com/rmtb/upclistbuilder/AceNetRuntimeClassifier.kt
grep -q 'AceNetRuntimeClassifier.safeUrl' app/src/main/java/com/rmtb/upclistbuilder/AceNetProductionCoordinator.kt
if grep -Eq 'private fun (aceNetSafeUrl|aceNetUrlForensics|shouldCaptureAceNetAuthPage|isAceNetLogoutPage|isAceNetItemResultUrl|isDeviceConnectivityFailure)' app/src/main/java/com/rmtb/upclistbuilder/AceNetProductionCoordinator.kt; then
  echo "ERROR: AceNetProductionCoordinator reclaimed stateless runtime classification helpers" >&2
  exit 1
fi
if grep -Eq 'private fun (startProductionAceNetLookup|beginAceNetStartupAuthentication|aceNetNativeDiagnostic|startAceNetTest|inspectAceNetHome)' app/src/main/java/com/rmtb/upclistbuilder/MainActivity.kt; then
  echo 'ERROR: MainActivity reclaimed AceNet workflow ownership' >&2
  exit 1
fi
if grep -Eq 'AppUpdateService|NativeFileExportService|openScanner\(|lookupProductImageNative' app/src/main/java/com/rmtb/upclistbuilder/AceNetProductionCoordinator.kt; then
  echo 'ERROR: AceNetProductionCoordinator absorbed unrelated native responsibilities' >&2
  exit 1
fi
MAIN_ACTIVITY_LINES="$(wc -l < app/src/main/java/com/rmtb/upclistbuilder/MainActivity.kt)"
[[ "$MAIN_ACTIVITY_LINES" -le 700 ]] || { echo "ERROR: MainActivity exceeds its reviewed composition-host budget: $MAIN_ACTIVITY_LINES lines" >&2; exit 1; }
ACENET_COORDINATOR_LINES="$(wc -l < app/src/main/java/com/rmtb/upclistbuilder/AceNetProductionCoordinator.kt)"
[[ "$ACENET_COORDINATOR_LINES" -le 2300 ]] || { echo "ERROR: AceNetProductionCoordinator exceeded its reviewed architecture exception ceiling: $ACENET_COORDINATOR_LINES lines" >&2; exit 1; }
ACENET_INCIDENT_LINES="$(wc -l < app/src/main/java/com/rmtb/upclistbuilder/AceNetProductionIncidentController.kt)"
[[ "$ACENET_INCIDENT_LINES" -le 120 ]] || { echo "ERROR: AceNetProductionIncidentController requires responsibility review: $ACENET_INCIDENT_LINES lines" >&2; exit 1; }
APP_UPDATE_LINES="$(wc -l < app/src/main/java/com/rmtb/upclistbuilder/AppUpdateService.kt)"
[[ "$APP_UPDATE_LINES" -le 250 ]] || { echo "ERROR: AppUpdateService requires responsibility review: $APP_UPDATE_LINES lines" >&2; exit 1; }
NATIVE_EXPORT_LINES="$(wc -l < app/src/main/java/com/rmtb/upclistbuilder/NativeFileExportService.kt)"
[[ "$NATIVE_EXPORT_LINES" -le 150 ]] || { echo "ERROR: NativeFileExportService requires responsibility review: $NATIVE_EXPORT_LINES lines" >&2; exit 1; }
NATIVE_JOURNAL_LINES="$(wc -l < app/src/main/java/com/rmtb/upclistbuilder/NativeDiagnosticJournal.kt)"
[[ "$NATIVE_JOURNAL_LINES" -le 150 ]] || { echo "ERROR: NativeDiagnosticJournal requires responsibility review: $NATIVE_JOURNAL_LINES lines" >&2; exit 1; }
NATIVE_DIAGNOSTIC_FORMATTER_LINES="$(wc -l < app/src/main/java/com/rmtb/upclistbuilder/NativeDiagnosticRecordFormatter.kt)"
[[ "$NATIVE_DIAGNOSTIC_FORMATTER_LINES" -le 150 ]] || { echo "ERROR: NativeDiagnosticRecordFormatter requires responsibility review: $NATIVE_DIAGNOSTIC_FORMATTER_LINES lines" >&2; exit 1; }

# Structured diagnostics ownership and observability guards.
grep -q "STORE='diagnostics'" app/src/main/assets/www/diagnostics/diagnostic-repository.js
grep -q 'DIAG_NORMAL_MAX_EVENTS=12000' app/src/main/assets/www/diagnostics/diagnostic-journal.js
grep -q 'DIAG_DEEP_MAX_EVENTS=30000' app/src/main/assets/www/diagnostics/diagnostic-journal.js
grep -q 'DIAG_EMERGENCY_MAX_BYTES=25000000' app/src/main/assets/www/diagnostics/diagnostic-journal.js
grep -q 'DIAG_DEEP_MAX_BYTES=50000000' app/src/main/assets/www/diagnostics/diagnostic-journal.js
grep -q 'schemaVersion:2' app/src/main/assets/www/diagnostics/diagnostic-service.js
grep -q 'parentSpanId' app/src/main/assets/www/diagnostics/diagnostic-service.js
grep -q 'unfinishedSpans' app/src/main/assets/www/diagnostics/diagnostic-export-service.js
grep -q 'id="toggleDeepDiag"' app/src/main/assets/www/index.html
grep -q 'id="settingsDeepDiag"' app/src/main/assets/www/index.html
grep -q 'await diagnosticService.initialize()' app/src/main/assets/www/application/application-shell.js
grep -q 'upc-native-diagnostics-v2.json' app/src/main/java/com/rmtb/upclistbuilder/NativeDiagnosticJournal.kt
grep -q 'class NativeDiagnosticRecordFormatter' app/src/main/java/com/rmtb/upclistbuilder/NativeDiagnosticRecordFormatter.kt
if grep -q 'storage.setItem(DIAG_KEY' app/src/main/assets/www/diagnostics/diagnostic-journal.js; then
  echo 'ERROR: localStorage reclaimed primary diagnostic-journal persistence' >&2
  exit 1
fi
if grep -q 'putString(' app/src/main/java/com/rmtb/upclistbuilder/NativeDiagnosticJournal.kt; then
  echo 'ERROR: SharedPreferences reclaimed primary native diagnostic-journal persistence' >&2
  exit 1
fi
RAW_WEB_CONSOLE="$(grep -R -nE 'console\.(log|info|warn|error|debug)' app/src/main/assets/www --include='*.js' | grep -v 'application/application-shell.js:.*Fatal application-shell startup failure' | grep -v 'diagnostics/diagnostic-journal.js:.*UPC-DIAG-EMERGENCY' || true)"
if [[ -n "$RAW_WEB_CONSOLE" ]]; then
  echo 'ERROR: production web code bypasses the centralized diagnostic service:' >&2
  printf '%s\n' "$RAW_WEB_CONSOLE" >&2
  exit 1
fi
RAW_NATIVE_LOG="$(grep -R -nE 'android\.util\.Log\.|\bLog\.(d|i|w|e|v)\(' app/src/main/java/com/rmtb/upclistbuilder --include='*.kt' | grep -v 'NativeDiagnosticJournal.kt:.*native diagnostic persistence failure' || true)"
if [[ -n "$RAW_NATIVE_LOG" ]]; then
  echo 'ERROR: native production code bypasses the diagnostic safety journal:' >&2
  printf '%s\n' "$RAW_NATIVE_LOG" >&2
  exit 1
fi
grep -q '## Source documentation rule' CURRENT_ARCHITECTURE_AUTHORITY.md

node --check app/src/main/assets/www/app.v059.js
node --check app/src/main/assets/www/identifier-normalization.js
node --check app/src/main/assets/www/acenet-client.js
node --check app/src/main/assets/www/operation-tracker.js
node --check app/src/main/assets/www/db.js
node --check app/src/main/assets/www/catalog/catalog-mappers.js
node --check app/src/main/assets/www/catalog/database-inspection-service.js
node --check app/src/main/assets/www/catalog/catalog-refresh-service.js
node --check app/src/main/assets/www/catalog/catalog-maintenance-service.js
node --check app/src/main/assets/www/catalog/retail-units-resolver.js
node --check app/src/main/assets/www/lookup/item-record-mapper.js
node --check app/src/main/assets/www/lookup/normal-lookup-controller.js
node --check app/src/main/assets/www/lookup/acenet-price-service.js
node --check app/src/main/assets/www/lookup/product-image-service.js
node --check app/src/main/assets/www/lookup/item-presentation-controller.js
node --check app/src/main/assets/www/field-session/field-session-export-service.js
node --check app/src/main/assets/www/misc/misc-draft-model.js
node --check app/src/main/assets/www/misc/misc-resolution-service.js
node --check app/src/main/assets/www/misc/misc-verification-service.js
node --check app/src/main/assets/www/misc/misc-workspace-controller.js
node --check app/src/main/assets/www/dsd/dsd-workspace-controller.js
node --check app/src/main/assets/www/ace-misc.js
node --check app/src/main/assets/www/ace-dsd.js
node --check app/src/main/assets/www/work-sessions/work-session-repository.js
node --check app/src/main/assets/www/work-sessions/work-session-service.js
node --check app/src/main/assets/www/misc/misc-maintenance-service.js
node --check app/src/main/assets/www/master-repository.js
node --check app/src/main/assets/www/local-repository.js
node --check app/src/main/assets/www/identity-repository.js
node --check app/src/main/assets/www/migration-repository.js
node --check app/src/main/assets/www/effective-catalog-resolver.js
node --check app/src/main/assets/www/identifier-relationship-service.js
node --check app/src/main/assets/www/local-identifier-resolver.js
node --check app/src/main/assets/www/data-backup.js
node --check app/src/main/assets/www/xlsx-importer.js
node --check app/src/main/assets/www/xlsx-exporter.js
node --check app/src/main/assets/www/combined-master-export.js

while IFS= read -r focused_js; do
  node --check "$focused_js"
done < <(find   app/src/main/assets/www/application   app/src/main/assets/www/diagnostics   app/src/main/assets/www/work-sessions   app/src/main/assets/www/lookup   app/src/main/assets/www/scanner   app/src/main/assets/www/identity   app/src/main/assets/www/catalog   app/src/main/assets/www/misc   app/src/main/assets/www/dsd   app/src/main/assets/www/platform   app/src/main/assets/www/field-session   app/src/main/assets/www/pricing   -type f -name '*.js' | sort)

# Work Session ownership guard.
RAW_LIST_BYPASS="$(grep -R -nE "UPCDB\.(get|put|all|remove)\([[:space:]]*['\"]lists['\"]" app/src/main/assets/www --include='*.js' | grep -v '/work-sessions/work-session-repository.js:' || true)"
if [[ -n "$RAW_LIST_BYPASS" ]]; then
  echo 'ERROR: production workflow bypasses the Work Session persistence owner:' >&2
  printf '%s\n' "$RAW_LIST_BYPASS" >&2
  exit 1
fi
grep -q 'work-sessions/work-session-repository.js' app/src/main/assets/www/index.html
grep -q 'work-sessions/work-session-service.js' app/src/main/assets/www/index.html
grep -q 'misc/misc-maintenance-service.js' app/src/main/assets/www/index.html
! grep -q 'findAceMiscSnapshotRepairCandidates\|replaceAceMiscSnapshotsForSku' app/src/main/assets/www/local-repository.js
! grep -q 'findAceMiscSnapshotRepairCandidates\|replaceAceMiscSnapshotsForSku' app/src/main/assets/www/db.js
grep -q 'migration.workSessions.v279Normalization' app/src/main/assets/www/migration-repository.js
grep -q 'prepareWorkSessions' app/src/main/assets/www/migration-repository.js
grep -q 'UPCMigrationRepository.prepareWorkSessions' app/src/main/assets/www/application/application-shell.js
! grep -qE 'migrateLegacyLists|loadLists\(|storeLists\(|upcFieldLists\.v0\.01' app/src/main/assets/www/app.v059.js

# Catalog ownership guard.
for catalog_asset in \
  catalog/catalog-mappers.js \
  catalog/database-inspection-service.js \
  catalog/catalog-refresh-service.js \
  catalog/catalog-maintenance-service.js \
  catalog/retail-units-resolver.js
do
  grep -q "$catalog_asset" app/src/main/assets/www/index.html
done
! grep -q 'function normalizeAceNetWeight\|function findHeader\|function normalizeLocalClassificationCode' app/src/main/assets/www/db.js
! grep -q 'getDatabaseViewerSnapshot\|getLocalLibraryRecords' app/src/main/assets/www/db.js
! grep -q 'async function applyCatalogRefreshPolicyToExistingRecord\|async function reconcileVerifiedUpcSetWithCatalog\|async function persistVerifiedAceNetCatalogToLocalLibrary' app/src/main/assets/www/app.v059.js
grep -q 'UPCCatalogRefreshService.create' app/src/main/assets/www/application/application-shell.js
grep -q 'UPCCatalogMaintenanceService.create' app/src/main/assets/www/application/application-shell.js
grep -q 'UPCDatabaseInspectionService.snapshot' app/src/main/assets/www/application/admin-database-controller.js
CATALOG_RAW_DB_BYPASS="$(grep -nE 'UPCDB\.' app/src/main/assets/www/catalog/database-inspection-service.js app/src/main/assets/www/catalog/catalog-refresh-service.js app/src/main/assets/www/catalog/catalog-maintenance-service.js || true)"
if [[ -n "$CATALOG_RAW_DB_BYPASS" ]]; then
  echo 'ERROR: catalog service bypasses repository/service boundaries:' >&2
  printf '%s\n' "$CATALOG_RAW_DB_BYPASS" >&2
  exit 1
fi

# Normal lookup / presentation / Field Session ownership guard.
for stage4_asset in \
  lookup/item-record-mapper.js \
  lookup/acenet-price-service.js \
  lookup/normal-lookup-controller.js \
  lookup/product-image-service.js \
  lookup/item-presentation-controller.js \
  field-session/field-session-export-service.js
do
  grep -q "$stage4_asset" app/src/main/assets/www/index.html
done
! grep -q 'async function lookupItem(input\|async function lookupItemBySku\|async function resolveMissingSkuThroughAceNet\|async function performNormalLookup' app/src/main/assets/www/app.v059.js
! grep -q 'function renderPreview\|function resetPreview\|function lookupProductImage\|function safeExportName\|async function exportTaggedPackage' app/src/main/assets/www/app.v059.js
! grep -q 'let lookupPresentationGeneration' app/src/main/assets/www/app.v059.js
! grep -qE 'function (requestAceNetPrice|enrichAceNetUpcsAfterPrice|enrichPresentedItemWithAceNetPrice|refreshLocalLibraryLookupInBackground|resolveAceNetRetailUnits|updatePriceDifference|showDuplicateBlockedModal|promptDuplicateItem|clearLookupTransientPriceState)\b' app/src/main/assets/www/app.v059.js
grep -q 'UPCAceNetPriceService.create' app/src/main/assets/www/application/application-shell.js
grep -q 'UPCRetailUnitsResolver.create' app/src/main/assets/www/application/application-shell.js
grep -q 'priceService.requestPrice' app/src/main/assets/www/lookup/normal-lookup-controller.js
grep -q 'function updatePriceDifference' app/src/main/assets/www/lookup/item-presentation-controller.js
grep -q 'function promptDuplicateItem' app/src/main/assets/www/lookup/item-presentation-controller.js
! grep -qE 'document\.(getElementById|querySelector)|productImageFrame|lookupBadge|previewDescription|addToList' app/src/main/assets/www/lookup/product-image-service.js
grep -q 'productImageService.acceptNativeProductImageResult' app/src/main/assets/www/platform/bridge-registration.js
grep -q 'UPCNormalLookupController.create' app/src/main/assets/www/application/application-shell.js
grep -q 'UPCItemPresentationController.create' app/src/main/assets/www/application/application-shell.js
grep -q 'UPCProductImageService.create' app/src/main/assets/www/application/application-shell.js
grep -q 'UPCFieldSessionExportService.create' app/src/main/assets/www/application/application-shell.js
grep -q 'return normalLookupController.performNormalLookup(value,options)' app/src/main/assets/www/lookup/lookup-router.js
STAGE4_RAW_REPOSITORY_BYPASS="$(grep -nE 'UPCDB\.|UPCMasterRepository\.|UPCLocalRepository\.|UPCIdentityRepository\.' app/src/main/assets/www/lookup/item-record-mapper.js app/src/main/assets/www/lookup/acenet-price-service.js app/src/main/assets/www/lookup/normal-lookup-controller.js app/src/main/assets/www/lookup/product-image-service.js app/src/main/assets/www/lookup/item-presentation-controller.js app/src/main/assets/www/field-session/field-session-export-service.js || true)"
if [[ -n "$STAGE4_RAW_REPOSITORY_BYPASS" ]]; then
  echo 'ERROR: lookup/identity owner bypasses approved repository/service boundaries:' >&2
  printf '%s\n' "$STAGE4_RAW_REPOSITORY_BYPASS" >&2
  exit 1
fi
! grep -q 'UPCWorkSessionService\|UPCCatalogRefreshService\|UPCIdentifierRelationshipService' app/src/main/assets/www/field-session/field-session-export-service.js
! grep -q 'UPCDB\.\|UPCMasterRepository\.\|UPCLocalRepository\.\|UPCIdentifierRepository\.\|UPCAceNetClient' app/src/main/assets/www/lookup/item-presentation-controller.js

# Independent DSD / MISC workspace ownership guard.
for stage5_asset in \
  misc/misc-draft-model.js \
  misc/misc-resolution-service.js \
  misc/misc-verification-service.js \
  misc/misc-workspace-controller.js \
  dsd/dsd-workspace-controller.js
do
  grep -q "$stage5_asset" app/src/main/assets/www/index.html
done
grep -q 'UPCDsdWorkspaceController.create' app/src/main/assets/www/application/application-shell.js
grep -q 'UPCMiscDraftModel.create' app/src/main/assets/www/application/application-shell.js
grep -q 'UPCMiscResolutionService.create' app/src/main/assets/www/application/application-shell.js
grep -q 'UPCMiscVerificationService.create' app/src/main/assets/www/application/application-shell.js
grep -q 'UPCMiscWorkspaceController.create' app/src/main/assets/www/application/application-shell.js
grep -q 'UPCMiscRuntimeResolver.create' app/src/main/assets/www/application/application-shell.js
grep -q 'windowRef.UPCAceMiscResolver=exported' app/src/main/assets/www/misc/misc-runtime-resolver.js
grep -q "sessionType===miscType)return miscWorkspaceProvider().performLookup(value,options)" app/src/main/assets/www/lookup/lookup-router.js
! grep -qE 'function (dsdInvoiceFromForm|dsdOpenDepartmentPicker|dsdSyncRetailUi|dsdSyncGenerated|dsdRender|dsdShowSetup|dsdCommitSetup|dsdAddOrSave|dsdImportExisting|dsdExport)\(' app/src/main/assets/www/app.v059.js
! grep -qE '(async[[:space:]]+)?function (performAceMiscLookup|syncAceMiscBulkPreview|getOrCreateTodaysAceMiscList|processAceMiscBulkSku|renderAceMiscBulkResults|runAceMiscBulkImport|aceMiscSetUpcSearchBusy|aceMiscSearchAdditionalUpcs|resolveAceMiscSkuCandidate|aceMiscRefreshLibraryRecord|retryPendingAceMiscVerification|aceMiscDuplicate|syncCurrentAceMiscSnapshot)\(' app/src/main/assets/www/app.v059.js
! grep -q 'dsdEditingIndex\|aceMiscBulkRunning\|aceMiscUpcSearchRunning\|aceMiscVerificationRetryRunning' app/src/main/assets/www/app.v059.js
STAGE5_RAW_DB_BYPASS="$(grep -nE 'UPCDB\.' app/src/main/assets/www/dsd/dsd-workspace-controller.js app/src/main/assets/www/misc/misc-draft-model.js app/src/main/assets/www/misc/misc-resolution-service.js app/src/main/assets/www/misc/misc-verification-service.js app/src/main/assets/www/misc/misc-workspace-controller.js || true)"
if [[ -n "$STAGE5_RAW_DB_BYPASS" ]]; then
  echo 'ERROR: workspace owner bypasses approved persistence/service boundaries:' >&2
  printf '%s\n' "$STAGE5_RAW_DB_BYPASS" >&2
  exit 1
fi
DSD_CROSS_DOMAIN_BYPASS="$(awk 'p{print} /^[[:space:]]*\*\/[[:space:]]*$/{p=1}' app/src/main/assets/www/dsd/dsd-workspace-controller.js | grep -nE 'AceNet|UPCAceNet|UPCMasterRepository|UPCLocalRepository|UPCIdentityRepository|UPCIdentifierRelationshipService|UPCEffectiveCatalogResolver|UPCCatalogRefresh' || true)"
if [[ -n "$DSD_CROSS_DOMAIN_BYPASS" ]]; then
  echo 'ERROR: DSD workspace depends on lookup/catalog/AceNet ownership:' >&2
  printf '%s\n' "$DSD_CROSS_DOMAIN_BYPASS" >&2
  exit 1
fi
! grep -qE 'promotedMaster|MASTER_PROMOTED_LOCAL|LOCAL_LIBRARY_PROMOTED' app/src/main/assets/www/ace-misc.js
! grep -qE 'UPCMasterRepository|UPCIdentityRepository|UPCWorkSessionRepository|UPCDB\.' app/src/main/assets/www/misc/misc-resolution-service.js
! grep -qE 'document\.|UPCDB\.|UPCMasterRepository|UPCLocalRepository|UPCIdentityRepository|UPCEffectiveCatalogResolver|UPCCatalogRefreshService' app/src/main/assets/www/misc/misc-verification-service.js
! grep -qE 'UPCDB\.|UPCMasterRepository|UPCLocalRepository|UPCIdentityRepository|UPCEffectiveCatalogResolver|UPCCatalogRefreshService' app/src/main/assets/www/misc/misc-workspace-controller.js
grep -q 'function applyUserEdit' app/src/main/assets/www/misc/misc-draft-model.js
grep -q 'function applySnapshot' app/src/main/assets/www/misc/misc-draft-model.js
grep -q 'function exportReady' app/src/main/assets/www/misc/misc-draft-model.js
grep -q 'UPCMiscMaintenanceService.create' app/src/main/assets/www/application/application-shell.js
grep -q 'draftModel.applySnapshot(next,snapshot)' app/src/main/assets/www/misc/misc-maintenance-service.js
grep -q 'draftModel.applySnapshot(next,snapshot)' app/src/main/assets/www/misc/misc-workspace-controller.js
grep -q 'missing its canonical ACE MISC draft' app/src/main/assets/www/ace-misc.js
! grep -q 'UPCEffectiveCatalogResolver.inspectSKU(sku)' app/src/main/assets/www/ace-misc.js

grep -q 'async function addPendingItem' app/src/main/assets/www/misc/misc-workspace-controller.js
grep -q 'async function editItemField' app/src/main/assets/www/misc/misc-workspace-controller.js
grep -q 'async function removeItem' app/src/main/assets/www/misc/misc-workspace-controller.js
grep -q 'miscWorkspaceProvider().addPendingItem' app/src/main/assets/www/work-sessions/list-item-controller.js
grep -q 'miscWorkspaceProvider().editItemField' app/src/main/assets/www/work-sessions/list-item-controller.js
grep -q 'miscWorkspaceProvider().removeItem' app/src/main/assets/www/work-sessions/list-item-controller.js

# Application-shell / bootstrap ownership guard.
grep -q 'application/application-shell.js' app/src/main/assets/www/index.html
grep -q 'UPCApplicationShell.start' app/src/main/assets/www/app.v059.js
! grep -qE 'function[[:space:]]+[A-Za-z_$][A-Za-z0-9_$]*[[:space:]]*\(' app/src/main/assets/www/app.v059.js
BOOTSTRAP_LINES="$(wc -l < app/src/main/assets/www/app.v059.js)"
if (( BOOTSTRAP_LINES > 20 )); then
  echo "ERROR: app.v059.js must remain a compact bootstrap; found ${BOOTSTRAP_LINES} lines" >&2
  exit 1
fi
! grep -qE 'window\.UPCNative[A-Za-z0-9_]+[[:space:]]*=' app/src/main/assets/www/application/application-shell.js
grep -q 'UPCBridgeRegistration.register' app/src/main/assets/www/application/application-shell.js
grep -q 'UPCStartupOrchestrator.create' app/src/main/assets/www/application/application-shell.js
grep -q 'UPCNavigationController.create' app/src/main/assets/www/application/application-shell.js
grep -q 'UPCSettingsController.create' app/src/main/assets/www/application/application-shell.js
grep -q 'UPCDialogService.create' app/src/main/assets/www/application/application-shell.js
grep -q 'UPCWorkSessionController.create' app/src/main/assets/www/application/application-shell.js
grep -q 'UPCScannerWorkspaceRouter.create' app/src/main/assets/www/application/application-shell.js
grep -q 'UPCLookupRouter.create' app/src/main/assets/www/application/application-shell.js
grep -q 'UPCNativeAceNetPriceResult' app/src/main/assets/www/platform/bridge-registration.js
grep -q 'UPCNativeUpdateLifecycle' app/src/main/assets/www/platform/bridge-registration.js
grep -q 'application/dom-adapter.js' app/src/main/assets/www/index.html
grep -q 'application/settings-repository.js' app/src/main/assets/www/index.html
grep -q 'application/release-presentation-service.js' app/src/main/assets/www/index.html
grep -q 'diagnostics/runtime-readiness-service.js' app/src/main/assets/www/index.html
grep -q 'diagnostics/diagnostic-ui-controller.js' app/src/main/assets/www/index.html
grep -q 'platform/acenet-health-policy.js' app/src/main/assets/www/index.html
grep -q 'platform/web-install-service.js' app/src/main/assets/www/index.html
grep -q 'lookup/lookup-router.js' app/src/main/assets/www/index.html
grep -q 'scanner/scanner-workspace-router.js' app/src/main/assets/www/index.html
grep -q 'identity/identity-work-controller.js' app/src/main/assets/www/index.html
grep -q 'field-session/field-session-controller.js' app/src/main/assets/www/index.html
grep -q 'work-sessions/work-session-controller.js' app/src/main/assets/www/index.html
grep -q 'work-sessions/list-item-controller.js' app/src/main/assets/www/index.html
grep -q 'catalog/master-library-controller.js' app/src/main/assets/www/index.html
grep -q 'misc/misc-runtime-resolver.js' app/src/main/assets/www/index.html
grep -q 'pricing/money-value.js' app/src/main/assets/www/index.html
! grep -qE 'UPCDB\.(get|put|all|remove)' app/src/main/assets/www/application/application-shell.js
! grep -qE '(async[[:space:]]+)?function (addPending|saveItemEdit|removeListItem|performNormalLookup|performAceMiscLookup|startNamedList|openLists|refreshIdentityWorkQueues|runAddToLocalLibraryBatch|openMasterLibrary|applyScannedLabelPricePrompt)\b' app/src/main/assets/www/application/application-shell.js
APPLICATION_SHELL_LINES="$(wc -l < app/src/main/assets/www/application/application-shell.js)"
if (( APPLICATION_SHELL_LINES > 450 )); then
  echo "ERROR: application/application-shell.js exceeded its justified explicit-composition budget; found ${APPLICATION_SHELL_LINES} lines" >&2
  exit 1
fi
grep -q 'COMPOSITION ROOT SIZE JUSTIFICATION' app/src/main/assets/www/application/application-shell.js


# The optional MCP server store tests use only Node built-ins; no secrets or hosting required.
node --check integrations/chatgpt-mcp/server.mjs
node --check integrations/chatgpt-mcp/store.mjs
node --test integrations/chatgpt-mcp/test/store.test.mjs

# Full maintained-regression sweep: collect every failing test before stopping.
# This prevents one obsolete assertion from hiding additional failures in the same candidate.
FULL_TEST_FAILURES=()
set +e
for test_file in "${TEST_FILES[@]}"; do
  node "tests/${test_file}"
  rc=$?
  if [[ $rc -ne 0 ]]; then FULL_TEST_FAILURES+=("${test_file}") ; fi
done
set -e
if (( ${#FULL_TEST_FAILURES[@]} )); then
  echo 'ERROR: maintained regression sweep found failures:' >&2
  printf ' - %s\n' "${FULL_TEST_FAILURES[@]}" >&2
  exit 1
fi
echo "Full maintained regression sweep PASS (${#TEST_FILES[@]} tests)"

# Final local asset/CSS integrity audit.
python3 - <<'PY'
from pathlib import Path
import re
root=Path('app/src/main/assets/www')
html=(root/'index.html').read_text()
for attr in ('src','href'):
    for v in re.findall(fr'{attr}="([^"]+)"', html):
        v=v.split('?',1)[0]
        if v.startswith(('http:','https:','#','data:')):
            continue
        if v.startswith('/'):
            raise SystemExit(f'ERROR root-relative local reference: {v}')
        if Path(v).suffix and not (root/v).exists():
            raise SystemExit(f'ERROR unresolved local reference: {v}')
for rel in ('styles.v059.css','application/dialogs.css','dsd/dsd.css','administration/data-management.css','misc/misc-workspace.css'):
    css=(root/rel).read_text()
    if css.count('{') != css.count('}'):
        raise SystemExit(f'ERROR CSS brace imbalance: {rel}')
print('Structural local asset + syntax audit PASS')
PY

echo 'UPC List Builder project verification PASS'
