/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/ace-dsd.js
 * Owner: ACE New DSD Domain
 * Role: Domain/workbook service
 * Responsibility: Owns DSD invoice/item validation, generated DSD fields, workbook import mapping, and DSD export composition.
 * Does not own: DSD workspace rendering; Work Session persistence; AceNet/catalog/identity policy; native filesystem implementation.
 * Side effects: May parse/build XLSX data; file delivery is delegated by the DSD workspace through the platform boundary; no catalog or identity mutation.
 * Related code: New DSD workflow/UI code belongs in dsd/; shared XLSX mechanics belong to xlsx-* owners.
 */
const ACEDSD=(()=>{
 const TYPE='ACE_NEW_DSD_ITEMS',DEFAULT_VENDOR='WWD 663',MAX_DESCRIPTION=24;
 const HEADERS=['(25) (298) SKU','2 UPC','3 Dept','(4) (10) Description','(5) (300) Order Mult','6 CASE COST','9 RETAIL/MSRP','13 VENDOR','(25) (298) SKU','51 COST','268 MERCH ','269 PROD GROUP','270 COMOD GROUP','(25) (298) SKU','299 MFG#','301 RETAIL UNITS','S/O(72)Y','Serial#','Gun#'];
 const DEPARTMENTS=[
  ['46','Firearms'],['55','Cleaning Supplies'],['56','Paint and Paint Supplies'],['57','Hand Tools and Tool Accessories'],['58','Power Tools'],['59','Flashlights and Lighting Supplies'],['60','Electrical Supplies'],['61','Plumbing Supplies and Fixtures'],['62','Heating and Cooling Supplies'],['63','Hardware'],['64','Fasteners'],['67','Building Materials and Products'],['68','Appliances and Home Entertainment'],['69','Housewares and Gifts'],['70','Lawn Garden / Farm Supplies'],['71','Outdoor Equipment and Power Tools'],['72','Sporting Goods'],['73','Automotive'],['74','Outdoor Living and Furniture'],['75','Stationary Supplies / Office Equipment'],['77','Notions and Miscellaneous'],['170','Major Department - Ace']
 ];
 const FIREARM_DEPARTMENT='46',NON_FIREARM_DEPARTMENT='72';
 const deptName=n=>DEPARTMENTS.find(x=>x[0]===String(n||'').trim())?.[1]||'';
 const isFirearmDepartment=n=>String(n??'').trim()===FIREARM_DEPARTMENT;
 const departmentForFirearmState=active=>active?FIREARM_DEPARTMENT:NON_FIREARM_DEPARTMENT;
 const clean=s=>String(s??'').trim(), upper=s=>clean(s).toUpperCase(), invoiceNumbers=s=>upper(s).replace(/\s+/g,' '), money=v=>{const s=String(v??'').replace(/[$,\s]/g,'');if(!s)return null;const n=Number(s);return Number.isFinite(n)?n:null};
 const effectiveDepartment=(draft,invoice)=>{const own=clean(draft?.department);return deptName(own)?own:clean(invoice?.department)};
 function withLegacyDepartment(item,invoice){const department=effectiveDepartment(item,invoice);return deptName(item?.department)?item:{...item,department,sku:sku(department,item?.upc)}}
 function sku(dept,upc){const d=clean(dept),u=clean(upc).replace(/\D/g,'');if(!d||u.length<6)return'';return d+u.slice(-6)}
 function vendor(invoice){return upper(invoice?.vendor)||DEFAULT_VENDOR}
 // On-device descriptions shorten predictably; AI may preselect a more useful phrase.
 function shortDescription(value){
  const text=upper(value).replace(/\s+/g,' ');
  if(text.length<=MAX_DESCRIPTION)return text;
  const prefix=text.slice(0,MAX_DESCRIPTION);
  let cut=-1;
  for(let i=prefix.length-1;i>0;i--){
   const c=prefix[i];
   if(/[ ,;:|()[\]{}]/.test(c)){cut=i;break}
   if((c==='-'||c==='/')&&i<prefix.length-1){
    // Keep embedded model/dimension separators; do not split fractions.
    if(/\d/.test(prefix[i-1])&&/\d/.test(prefix[i+1]))continue;
    cut=i;break;
   }
  }
  return (cut>0?prefix.slice(0,cut):prefix).replace(/[\s,;:|/\-]+$/,'').trim()||prefix;
 }
 function listName(invoice){
  const vendorNames=[upper(invoice?.secondaryVendor),upper(invoice?.primaryVendor)].filter(Boolean).join(' ');
  const id=invoiceNumbers(invoice?.invoiceNumber);
  return ['ACE New DSD Items',vendorNames,id].filter(Boolean).join(' · ');
 }
 function unitCost(caseCost,orderMultiple){const c=money(caseCost),o=Number(orderMultiple);return c!=null&&Number.isFinite(o)&&o>0?c/o:null}
 // Automatic markup pricing is department-sensitive. Departments 46/72 use the approved enhanced .99 engine; all others use the closest legal .39-.99 ending.
 const AUTO_ENDINGS=[39,49,59,69,79,89,99];
 const AUTO_DOWN_SACRIFICE=.0999,AUTO_WINDOW=500,AUTO_LOCAL_RADIUS=250,AUTO_9999_RADIUS=300,AUTO_9999_PREMIUM=250;
 const AUTO_BANDS=[[0,10000,{ones:[1,.020,.020],tens:[.55,.025,.030]}],[10000,25000,{ones:[.8,.012,.018],tens:[1,.018,.025]}],[25000,50000,{ones:[.55,.010,.015],tens:[1,.015,.023]}],[50000,100000,{ones:[.3,.0075,.012],tens:[1,.0125,.020],hundreds:[.45,.010,.022]}],[100000,250000,{tens:[1,.010,.018],hundreds:[.65,.0125,.025]}],[250000,500000,{tens:[1,.008,.015],hundreds:[.85,.010,.022]}],[500000,1000000,{tens:[.9,.006,.012],hundreds:[.9,.0065,.016],thousands:[.3,.004,.016]}],[1000000,Infinity,{tens:[.8,.005,.011],hundreds:[.95,.006,.015],thousands:[.45,.004,.016],tenThousands:[.2,.003,.016]}]];
 const automatic99Department=department=>['46','72'].includes(clean(department));
 function markupSacrifice(costCents,requestedMarkup,candidateCents){const actual=candidateCents/costCents-1;return Math.abs(actual-requestedMarkup)/requestedMarkup}
 function passesDownwardRule(costCents,requestedMarkup,targetCents,candidateCents){return candidateCents>=targetCents||markupSacrifice(costCents,requestedMarkup,candidateCents)<AUTO_DOWN_SACRIFICE}
 function ordinary99Candidates(targetCents){const dollars=Math.floor(targetCents/100);let lower=dollars*100+99;if(lower>targetCents)lower-=100;lower=Math.max(99,lower);return[lower,lower+100]}
 function chooseOrdinary99(targetCents,costCents,requestedMarkup){const candidates=ordinary99Candidates(targetCents),legal=candidates.filter(x=>passesDownwardRule(costCents,requestedMarkup,targetCents,x)),pool=legal.length?legal:candidates.filter(x=>x>=targetCents);return pool.slice().sort((a,b)=>Math.abs(a-targetCents)-Math.abs(b-targetCents)||a-b)[0]}
 const protected9999=candidateCents=>candidateCents%10000===9999;
 function stable99Candidates(targetCents){const center=Math.floor((targetCents-99)/100),set=new Set();for(let offset=-5;offset<=6;offset++){const candidate=(center+offset)*100+99;if(candidate>=99&&Math.abs(candidate-targetCents)<=AUTO_WINDOW)set.add(candidate)}for(const candidate of ordinary99Candidates(targetCents))set.add(candidate);return[...set].sort((a,b)=>a-b)}
 function endingQuality(candidateCents,targetCents){const dollars=Math.floor(candidateCents/100),ones=dollars%10,tens=Math.floor(dollars/10)%10;let quality=ones===0?-.5:ones===1?(targetCents<10001?.08:0):(ones===4||ones===7)?.15:ones===9?.35:.08;if(tens===9)quality+=.15;return quality}
 function pricingBand(targetCents){return AUTO_BANDS.find(([low,high])=>targetCents>=low&&targetCents<high)?.[2]||AUTO_BANDS.at(-1)[2]}
 function passesSoftCaps(costCents,requestedMarkup,targetCents,candidateCents){const retailMove=Math.abs(candidateCents-targetCents)/targetCents,markupMove=markupSacrifice(costCents,requestedMarkup,candidateCents);return Object.values(pricingBand(targetCents)).some(([,retailCap,markupCap])=>retailMove<=retailCap&&markupMove<=markupCap)}
 function candidateUtility(candidateCents,targetCents){let value=endingQuality(candidateCents,targetCents)*100;if(protected9999(candidateCents))value+=AUTO_9999_PREMIUM;return value-Math.abs(candidateCents-targetCents)}
 function chooseEnhanced99(costCents,requestedMarkup,targetCents){const ordinary=chooseOrdinary99(targetCents,costCents,requestedMarkup),evaluated=[];for(const candidate of stable99Candidates(targetCents)){if(candidate%100!==99||!passesDownwardRule(costCents,requestedMarkup,targetCents,candidate))continue;if(candidate!==ordinary){const radius=protected9999(candidate)?AUTO_9999_RADIUS:AUTO_LOCAL_RADIUS;if(Math.abs(candidate-ordinary)>radius||!passesSoftCaps(costCents,requestedMarkup,targetCents,candidate))continue}evaluated.push({candidate,utility:candidateUtility(candidate,targetCents),distance:Math.abs(candidate-targetCents)})}if(!evaluated.length)return ordinary;evaluated.sort((a,b)=>b.utility-a.utility||a.distance-b.distance||a.candidate-b.candidate);return evaluated[0].candidate}
 function chooseStandardEnding(costCents,requestedMarkup,targetCents){const dollar=Math.floor(targetCents/100),candidates=[];for(let offset=-1;offset<=1;offset++)for(const ending of AUTO_ENDINGS){const candidate=(dollar+offset)*100+ending;if(candidate>=39&&passesDownwardRule(costCents,requestedMarkup,targetCents,candidate))candidates.push(candidate)}if(!candidates.length)throw new RangeError('No legal DSD retail candidate was found.');return candidates.sort((a,b)=>Math.abs(a-targetCents)-Math.abs(b-targetCents)||a-b)[0]}
 function prettyPrice(raw,department,cost=null,markup=null){if(!Number.isFinite(raw)||raw<0)return null;const targetCents=Math.round(raw*100),costCents=Math.round(Number(cost)*100),requestedMarkup=Number(markup)/100;if(!Number.isInteger(costCents)||costCents<1||!Number.isFinite(requestedMarkup)||requestedMarkup<0)return null;const cents=automatic99Department(department)?chooseEnhanced99(costCents,requestedMarkup,targetCents):chooseStandardEnding(costCents,requestedMarkup,targetCents);return cents/100}
 function actualMarkup(caseCost,orderMultiple,retail){const cost=unitCost(caseCost,orderMultiple),price=money(retail);return cost!=null&&cost>0&&price!=null?((price/cost)-1)*100:null}
 function retailFromMarkup(caseCost,orderMultiple,markup,department){const cost=unitCost(caseCost,orderMultiple),m=Number(markup);if(cost==null||clean(markup)===''||!deptName(department)||!Number.isFinite(m)||m<0)return null;const raw=cost*(1+m/100),pretty=prettyPrice(raw,department,cost,m);return pretty==null?null:{raw,pretty,actualMarkup:actualMarkup(caseCost,orderMultiple,pretty)}}
 // Only unpriced markup drafts are eligible; never change authored retail prices.
 function fillMissingMarkupRetail(draft,invoice){
  if(draft?.retailMethod!=='MARKUP'||clean(draft.retail)!=='')return draft;
  const department=effectiveDepartment(draft,invoice);
  if(!deptName(department)||clean(draft.caseCost)===''||clean(draft.orderMultiple)===''||clean(draft.markup)==='')return draft;
  const calc=retailFromMarkup(draft.caseCost,draft.orderMultiple,draft.markup,department);
  return calc?.pretty==null?draft:{...draft,retail:String(calc.pretty)};
 }
 function buildItem(draft,invoice){
  const upc=clean(draft.upc).replace(/\D/g,''),order=clean(draft.orderMultiple)===''?null:Number(draft.orderMultiple),caseCost=money(draft.caseCost),method=draft.retailMethod==='MARKUP'?'MARKUP':'DIRECT',department=effectiveDepartment(draft,invoice);
  const calc=method==='MARKUP'?retailFromMarkup(caseCost,order,draft.markup,department):null,retail=method==='MARKUP'?(clean(draft.retail)!==''?money(draft.retail):calc?.pretty):money(draft.retail);
  return{id:draft.id||`dsd-${Date.now()}-${Math.random().toString(36).slice(2,8)}`,upc,department,description:shortDescription(draft.description),sourceDescription:upper(draft.sourceDescription||draft.description),mfg:upper(draft.mfg),serialNumber:upper(draft.serialNumber),orderMultiple:order,caseCost,retailMethod:method,markup:method==='MARKUP'&&clean(draft.markup)!==''?Number(draft.markup):null,retail,rawRetail:calc?.raw??null,sku:sku(department,upc),vendor:vendor(invoice),unitCost:unitCost(caseCost,order),addedAt:draft.addedAt||new Date().toISOString()};
 }
 function validateInvoice(x){const e=[],primary=clean(x.primaryVendor),secondary=clean(x.secondaryVendor),numbers=invoiceNumbers(x.invoiceNumber).split(' ').filter(Boolean);if(!primary)e.push('Primary Vendor is required.');if(/\d/.test(primary)||/\d/.test(secondary))e.push('Manufacturer names cannot contain numbers.');if(!numbers.length)e.push('Invoice Number is required.');else if(numbers.some(v=>!/\d/.test(v)))e.push('Each invoice number must contain at least one number.');if(!deptName(x.department))e.push('Choose a valid Myers Department.');if(Object.hasOwn(x,'vendor')&&!clean(x.vendor))e.push('Invoice Vendor is required.');if(x.defaultRetailMethod==='MARKUP'&&(!Number.isFinite(Number(x.defaultMarkup))||Number(x.defaultMarkup)<0))e.push('Enter a valid default markup.');return e}
 function validateItem(x){const e=[];if(!/^\d{6,}$/.test(x.upc))e.push('Enter or scan a valid UPC.');if(!deptName(x.department))e.push('Choose a valid Myers Department for this item.');if(!x.description)e.push('Description is required.');if(x.description&&x.description.length>MAX_DESCRIPTION)e.push('Description exceeds 24 characters.');if(!Number.isFinite(x.orderMultiple)||x.orderMultiple<=0)e.push('Order Multiple must be greater than zero.');if(x.caseCost==null||x.caseCost<0)e.push('Enter a valid Case Cost.');if(x.retail==null||!Number.isFinite(x.retail)||x.retail<0)e.push('Enter a valid Retail/MSRP or markup.');if(!x.sku)e.push('SKU could not be generated.');return e}
 function row(item,invoice){const department=effectiveDepartment(item,invoice),generatedSku=sku(department,item.upc),generatedVendor=vendor(invoice),cost=unitCost(item.caseCost,item.orderMultiple);return[generatedSku,item.upc,department,shortDescription(item.description),item.orderMultiple,item.caseCost,item.retail,generatedVendor,generatedSku,cost,'','','',generatedSku,upper(item.mfg),'','',upper(item.serialNumber),''].map(v=>typeof v==='string'?v.toUpperCase():v)}
 function filenameParts(name){
  const base=clean(name).replace(/\.xlsx$/i,'').replace(/_+/g,' '),match=base.match(/^ACE\s+New\s+DSD\s+Items\s+(.*)$/i),tokens=invoiceNumbers(match?.[1]||'').split(' ').filter(Boolean),invoiceStart=tokens.findIndex(v=>/\d/.test(v));
  if(invoiceStart<0)return{manufacturerText:invoiceNumbers(tokens.join(' ')),invoiceNumber:''};
  return{manufacturerText:invoiceNumbers(tokens.slice(0,invoiceStart).join(' ')),invoiceNumber:invoiceNumbers(tokens.slice(invoiceStart).join(' '))};
 }
 function invoiceNumberFromFilename(name){return filenameParts(name).invoiceNumber}
 function importedVendorPrimary(value){return upper(value).replace(/\s+663\s*$/,'').trim()}
 function mostCommonDepartment(items){
  const counts=new Map();for(const x of items){const d=clean(x.department);if(deptName(d))counts.set(d,(counts.get(d)||0)+1)}
  return [...counts.entries()].sort((a,b)=>b[1]-a[1]||Number(a[0])-Number(b[0]))[0]?.[0]||'';
 }
 async function importWorkbook(file,progress=()=>{}){
  if(!file)throw new Error('Choose an ACE New DSD Items XLSX file.');
  let parsed=await XLSXImporter.importFile(file,progress);
  const headers=parsed.headers||[],headerIndex=name=>headers.findIndex(h=>upper(h)===upper(name));
  const required=['2 UPC','3 Dept','(4) (10) Description','(5) (300) Order Mult','6 CASE COST','9 RETAIL/MSRP','13 VENDOR','299 MFG#','Serial#'];
  const missing=required.filter(h=>headerIndex(h)<0);if(missing.length)throw new Error(`This is not a compatible ACE New DSD Items workbook. Missing: ${missing.join(', ')}`);
  const actual=Object.fromEntries(required.map(h=>[h,headers[headerIndex(h)]]));
  if(parsed.needsUPCMapping)parsed=await XLSXImporter.continueWithMapping(parsed,headerIndex('2 UPC'),progress);
  const records=Array.isArray(parsed.records)?parsed.records:[];if(!records.length)throw new Error('The workbook contains no importable DSD item rows.');
  const raw=records.map((record,i)=>{
   const fields=record.fields||{},department=clean(fields[actual['3 Dept']]);if(!deptName(department))throw new Error(`Item ${i+1}: invalid Myers Department ${department||'(blank)'}.`);
   return{upc:clean(fields[actual['2 UPC']]).replace(/\D/g,''),department,description:fields[actual['(4) (10) Description']],mfg:fields[actual['299 MFG#']],serialNumber:fields[actual['Serial#']],orderMultiple:fields[actual['(5) (300) Order Mult']],caseCost:fields[actual['6 CASE COST']],retailMethod:'DIRECT',retail:fields[actual['9 RETAIL/MSRP']],markup:'',vendor:upper(fields[actual['13 VENDOR']])};
  });
  const vendorValues=[...new Set(raw.map(x=>x.vendor).filter(Boolean))],departmentValues=[...new Set(raw.map(x=>x.department).filter(Boolean))],fileParts=filenameParts(file.name),invoiceNumber=fileParts.invoiceNumber,workbookVendor=importedVendorPrimary(vendorValues[0]||''),primaryVendor=fileParts.manufacturerText||workbookVendor;
  const invoice={primaryVendor,secondaryVendor:'',vendor:vendorValues.length===1?vendorValues[0]:DEFAULT_VENDOR,invoiceNumber,department:mostCommonDepartment(raw),defaultRetailMethod:'DIRECT',defaultMarkup:''};
  const items=raw.map((x,i)=>{const item=buildItem(x,invoice),err=validateItem(item);if(err.length)throw new Error(`Item ${i+1}: ${err.join(' ')}`);return item});
  const warnings=[];if(vendorValues.length===1&&vendorValues[0]!==DEFAULT_VENDOR)warnings.push('The imported vendor differs from WWD 663; confirm your choice.');if(!vendorValues.length)warnings.push('The imported workbook has no vendor; confirm the default before continuing.');if(!invoiceNumber)warnings.push('Invoice number could not be recovered from the filename. Enter it before continuing.');if(!primaryVendor)warnings.push('Manufacturer could not be recovered from the filename or workbook. Enter it before continuing.');if(vendorValues.length>1)warnings.push('The workbook contains multiple vendor values. Select the invoice vendor before continuing.');
  const groups=new Map();for(const item of items){const key=item.description,entries=groups.get(key)||[];entries.push(item);groups.set(key,entries)}
  const ambiguous=[...groups.entries()].filter(([,entries])=>entries.length>1&&new Set(entries.map(x=>x.sourceDescription)).size>1);
  if(ambiguous.length)warnings.push(ambiguous.length+' description group(s) became indistinguishable after shortening (for example '+ambiguous[0][0]+'). Review variants, sizes and colors in Edit Item before export.');if(departmentValues.length>1)warnings.push('The workbook contains multiple item departments, so the original invoice default department cannot be recovered. Review the invoice default before continuing.');
  const shortened=items.filter(x=>x.sourceDescription!==x.description).length;if(shortened)warnings.push(shortened+' description(s) shortened to 24 characters; original wording is preserved.');return{invoice,items,warnings,importedVendors:vendorValues,needsInvoiceReview:!invoiceNumber||!primaryVendor||departmentValues.length>1,sourceFilename:file.name};
 }
 async function exportList(list){
  if(!list?.dsdInvoice)throw new Error('DSD invoice information is missing.');
  const invErr=validateInvoice(list.dsdInvoice);if(invErr.length)throw new Error(invErr.join(' '));
  if(!Array.isArray(list.items)||!list.items.length)throw new Error('There are no DSD items to export.');
  const rows=list.items.map((x,i)=>{
   // Imported drafts keep unknown fields blank. Do not allow Number('') or
   // money('') to turn an omission into a valid zero at export time.
   const missing=[];
   if(clean(x.orderMultiple)==='')missing.push('Order Multiple');
   if(clean(x.caseCost)==='')missing.push('Case Cost');
   if(x.retailMethod==='MARKUP'&&clean(x.markup)===''&&clean(x.retail)==='')missing.push('Markup or Retail');
   if(x.retailMethod!=='MARKUP'&&clean(x.retail)==='')missing.push('Retail / MSRP');
   if(missing.length)throw Error('Item '+(i+1)+' needs '+missing.join(', ')+'.');
   const rebuilt=buildItem(x,list.dsdInvoice),err=validateItem(rebuilt);if(err.length)throw new Error(`Item ${i+1}: ${err.join(' ')}`);return row(rebuilt,list.dsdInvoice)});
  // Yellow supplied headers: A-E, G-J, N-O, R-S. F preserves the source/theme behavior by intentionally not forcing RGB yellow.
  const yellow=[0,1,2,3,4,6,7,8,9,13,14,17,18];
  const bytes=await XLSXExporter.build(HEADERS,rows,{sheetName:'ACE New DSD Items',textColumns:[0,1,2,3,7,8,10,11,12,13,14,15,16,17,18],currencyColumns:[5,6,9],headerFillColumns:yellow,maxColumnWidth:48});
  const manufacturer=invoiceNumbers([list.dsdInvoice.primaryVendor,list.dsdInvoice.secondaryVendor].filter(Boolean).join(' ')).replace(/[\\/:*?"<>|]+/g,' ').replace(/\s+/g,' ').trim(),safeInvoice=invoiceNumbers(list.dsdInvoice.invoiceNumber).replace(/[\\/:*?"<>|]+/g,' ').replace(/\s+/g,' ').trim(),name=`ACE New DSD Items ${manufacturer} ${safeInvoice}`.replace(/\s+/g,' ').trim()+'.xlsx';
  return{name,rows:rows.length,bytes,mime:XLSXExporter.MIME};
 }
 return{TYPE,DEFAULT_VENDOR,MAX_DESCRIPTION,shortDescription,HEADERS,DEPARTMENTS,FIREARM_DEPARTMENT,NON_FIREARM_DEPARTMENT,listName,deptName,isFirearmDepartment,departmentForFirearmState,effectiveDepartment,withLegacyDepartment,sku,vendor,upper,invoiceNumbers,filenameParts,unitCost,prettyPrice,actualMarkup,retailFromMarkup,fillMissingMarkupRetail,buildItem,validateInvoice,validateItem,row,invoiceNumberFromFilename,importWorkbook,exportList};
})();