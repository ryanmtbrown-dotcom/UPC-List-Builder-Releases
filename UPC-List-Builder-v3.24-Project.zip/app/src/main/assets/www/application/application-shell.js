/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/application/application-shell.js
 * Owner: Application Composition
 * Role: Composition root
 * Responsibility: Owns construction/wiring of web runtime owners, dependency injection, top-level bootstrap integration, and one-time binding order.
 * Does not own: Feature business rules; raw persistence; native implementation; duplicated subsystem behavior.
 * Side effects: Creates services/controllers, binds approved lifecycle entry points, and starts startup orchestration.
 * Related code: New business behavior belongs to the focused owner; this file should remain composition/integration only.
 */
/* COMPOSITION ROOT SIZE JUSTIFICATION
 * This file is intentionally the single visible web dependency graph for the current architecture.
 * It may exceed the normal 150-line review threshold because it explicitly constructs and connects focused owners.
 * Business/workflow rules must remain in those owners; this shell is limited to dependency wiring, top-level routing,
 * lifecycle binding, fatal bootstrap handling, and startup composition. Splitting this graph solely by line count would
 * create artificial composition fragments and obscure dependency direction without establishing new system ownership.
 */
const UPCApplicationShell=(()=>{
 let fatalDiagnostic=null;
 function renderFatal(error){
  const message=error?.message||String(error);
  try{fatalDiagnostic?.event?.('application_shell_fatal',{name:error?.name||null,message,stack:error?.stack||null},{severity:'FATAL',phase:'ERROR',result:'FAIL',function:'boot',purpose:'Compose and start the application shell.',expected:'Application composition completes without an unhandled bootstrap exception.',actual:message,error});}catch(_){}
  try{
   const stage=document.getElementById('splashStage'),detail=document.getElementById('splashMessage'),pct=document.getElementById('splashPercent');
   if(stage)stage.textContent='Startup failed';if(detail)detail.textContent=message;if(pct)pct.textContent='STARTUP FAILED';
  }catch(_){}
  try{console.error('[UPC-BOOT] Fatal application-shell startup failure',error);}catch(_){}
 }
 async function boot(release){
  const UPC_RELEASE=release;
  const APP_VERSION=UPC_RELEASE.version;
  const APP_BUILD=UPC_RELEASE.build;
  const splashStarted=performance.now();
  const ALASKA_TZ='America/Anchorage';
  const startupSessionId=`startup-${Date.now()}-${Math.random().toString(36).slice(2,10)}`;
  let startupOrchestrator=null;
  let navigationController=null;
  let workSessionController=null;
  let dsdWorkspaceController=null;
  let fieldSessionController=null;
  let registerPriceController=null;
  let listItemController=null;
  let identityWorkController=null;
  let manualIdentifierController=null;
  let masterLibraryController=null;
  let masterLibraryWorkflow=null;
  let lookupRouter=null;
  let scannerWorkspaceRouter=null;
  const diagnosticRepository=UPCDiagnosticRepository.create({db:UPCDB});
  let diagnosticService=null;
  const diagnosticJournal=UPCDiagnosticJournal.create({
   repository:diagnosticRepository,legacyStorage:localStorage,timeZone:ALASKA_TZ,startupSessionId,appVersion:APP_VERSION,appBuild:APP_BUILD,
   getSinceBootMs:()=>Math.round(performance.now()-splashStarted),getScreen:()=>navigationController?.currentScreen?.()||'boot',isAppReady:()=>startupOrchestrator?.isReady?.()===true,
   getDeepMode:()=>diagnosticService?.isDeepMode?.()===true
  });
  diagnosticService=UPCDiagnosticService.create({
   journal:diagnosticJournal,settingsStorage:localStorage,appVersion:APP_VERSION,appBuild:APP_BUILD,startupSessionId,timeZone:ALASKA_TZ,
   getSinceBootMs:()=>Math.round(performance.now()-splashStarted),getScreen:()=>navigationController?.currentScreen?.()||'boot'
  });
  await diagnosticService.initialize();
  const diagnosticFor=(domain,module)=>diagnosticService.scope({domain,module}).diag;
  const diag=diagnosticFor('APPLICATION','application/application-shell');
  fatalDiagnostic=diag;
  const {diagRows,markCurrentStartupSession,alaskaDiagnosticStamp}=diagnosticJournal;
  const beginDiagnosticSession=()=>diagnosticService.startupRecord({sessionId:startupSessionId,version:APP_VERSION,buildId:APP_BUILD,currentStartup:true,retentionPolicy:'Five active Alaska days; 25 MB/12,000 events normal, 50 MB/30,000 events deep.'});
  const diagnosticOperations=UPCDiagnosticOperationService.create({
   operationTracker:UPCOperationTracker,diagnosticService,diagnostic:diag,alaskaStamp:alaskaDiagnosticStamp,
   startupNow:()=>Math.round(performance.now()-splashStarted)
  });
  const {lookupOperationStart,lookupOperationFinish,lookupOperationObserve,subsystemOperationStart,subsystemOperationFinish,startupOperationStart,startupOperationFinish,startupOperationObserve}=diagnosticOperations;
  navigationController=UPCNavigationController.create({
   elementById:id=>document.getElementById(id),querySelector:selector=>document.querySelector(selector),
   historyRef:history,locationRef:location,diagnostic:diagnosticFor('NAVIGATION','application/navigation-controller'),startOperation:subsystemOperationStart,finishOperation:subsystemOperationFinish,
   saveCurrent:()=>workSessionController?.saveCurrentSafe?.()
  });
  const {show,goHome,goBack}=navigationController;
  // Constructor dependencies are initialized before any owner consumes them.
  const domAdapter=UPCDomAdapter.create({documentRef:document,diagnostic:diagnosticFor('APPLICATION','application/dom-adapter')});
  const $=domAdapter.elementById;
  const on=domAdapter.bind;
  const locationLookupService=UPCLocationLookupService.create({repository:UPCLocationRepository,policy:UPCStoreLocationPolicy});
  const locationVerificationService=UPCLocationVerificationService.create({db:UPCDB,repository:UPCLocationRepository,explorerPolicy:UPCLocationExplorerPolicy,workPolicy:UPCLocationWorkPolicy});
  const locationMaintenanceController=UPCLocationMaintenanceController.create({repository:UPCLocationRepository,policy:UPCStoreLocationPolicy,verification:locationVerificationService,elementById:$,showScreen:show});
  const setText=domAdapter.setText;
  const parseMoney=UPCMoneyValue.parse;
  const normalizeAceNetUPC=UPCIdentifierNormalization.normalizeUPC;
  const normalizeUPC=UPCIdentifierNormalization.normalizeUPCUnicodeCompatible;
  const normalizeSKU=UPCIdentifierNormalization.normalizeSKU;
  const scannerController=UPCScannerController.create({
   elementById:id=>document.getElementById(id),setText,normalizeUpc:normalizeUPC,diagnostic:diagnosticFor('SCANNER','scanner/scanner-controller'),onDetected:payload=>scannerWorkspaceRouter?.accept(payload),
   nativeBridgeProvider:()=>window.AndroidNative,windowRef:window,documentRef:document,navigatorRef:navigator,storage:localStorage,
   performanceNow:()=>performance.now(),requestFrame:cb=>requestAnimationFrame(cb),secureContext:()=>isSecureContext
  });
  const {startScanner,stopScanner}=scannerController;
  const diagnosticExportService=UPCDiagnosticExportService.create({
   elementById:id=>document.getElementById(id),diagRows,markCurrentStartupSession,diagnostic:diagnosticFor('DIAGNOSTICS','diagnostics/diagnostic-export-service'),diagnosticStatus:()=>diagnosticService.status(),
   startOperation:subsystemOperationStart,finishOperation:subsystemOperationFinish,appVersion:APP_VERSION,appBuild:APP_BUILD,startupSessionId,
   startupSnapshot:()=>startupOrchestrator?.snapshot?.()||({progress:0,appReady:false,elapsedMs:Math.round(performance.now()-splashStarted)}),
   navigationSnapshot:()=>({activeScreen:navigationController.currentScreen(),stack:navigationController.stack()}),
   scannerSnapshot:()=>scannerController.snapshot(),nativeBridgeProvider:()=>window.AndroidNative,
   windowRef:window,documentRef:document,navigatorRef:navigator,locationRef:location,matchMediaFn:query=>matchMedia(query),
   secureContext:()=>isSecureContext,urlRef:URL,blobCtor:Blob
  });
  const {diagPayload,showDiagnostics,downloadDiagnostics}=diagnosticExportService;
  const diagnosticUiController=UPCDiagnosticUiController.create({
   elementById:id=>document.getElementById(id),exportService:diagnosticExportService,journal:diagnosticJournal,diagnosticService,diagnostic:diagnosticFor('DIAGNOSTICS','diagnostics/diagnostic-ui-controller'),navigatorRef:navigator
  });
  startupOrchestrator=UPCStartupOrchestrator.create({
   elementById:id=>document.getElementById(id),diagnostic:diagnosticFor('STARTUP','application/startup-orchestrator'),beginDiagnosticSession,
   startOperation:startupOperationStart,finishOperation:startupOperationFinish,
   performanceNow:()=>performance.now(),startedAt:splashStarted,requestFrame:cb=>requestAnimationFrame(cb),
   windowRef:window,nativeBridgeProvider:()=>window.AndroidNative,appVersion:APP_VERSION
  });
  const {setStage:setSplashStage}=startupOrchestrator;
  const aceNetNativeDiagnosticService=UPCAceNetNativeDiagnosticService.create({
   diagnostic:diagnosticFor('ACENET','diagnostics/acenet-native-diagnostic-service'),isStartupReady:()=>startupOrchestrator.isReady(),
   startOperation:startupOperationStart,finishOperation:startupOperationFinish,observeOperation:startupOperationObserve
  });
  const runtimeReadinessService=UPCRuntimeReadinessService.create({
   elementById:$,windowRef:window,documentRef:document,locationRef:location,diagnostic:diagnosticFor('DIAGNOSTICS','diagnostics/runtime-readiness-service'),release:UPC_RELEASE
  });
  const webInstallService=UPCWebInstallService.create({
   elementById:$,windowRef:window,navigatorRef:navigator,diagnostic:diagnosticFor('PLATFORM','platform/web-install-service'),nativeBridgeProvider:()=>window.AndroidNative,setIntervalFn:setInterval
  });
  const dialogService=UPCDialogService.create({elementById:$,setTimeoutFn:setTimeout});
  const {message:appMessage,confirm:appConfirm,prompt:appPrompt}=dialogService;
  dialogService.installCompatibility(window);
  const fileExportDeliveryService=UPCFileExportDeliveryService.create({
   bridgeProvider:()=>window.AndroidNative,documentRef:document,urlApi:URL,blobCtor:Blob,base64Encoder:btoa,setTimeoutFn:setTimeout,textEncoder:new TextEncoder()
  });
  const releasePresentationService=UPCReleasePresentationService.create({elementById:$,version:APP_VERSION});
  const PRIMARY_PURPOSE_TAGS=['NIF','Price Change','General Review'];
  const SYSTEM_PRIMARY_TAGS=['Add to Library'];
  const SUPPLEMENTAL_TAGS=['Duplicate Item','Missing Label'];
  const EXPORT_TAGS=[...PRIMARY_PURPOSE_TAGS,...SYSTEM_PRIMARY_TAGS,...SUPPLEMENTAL_TAGS];
  const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const alaskaTimeService=UPCAlaskaTimeService.create({timeZone:ALASKA_TZ});
  const today=alaskaTimeService.dateStamp;
  const alaskaSessionName=alaskaTimeService.sessionName;
  function newId(){return globalThis.crypto?.randomUUID?.()||`list-${Date.now()}-${Math.random().toString(36).slice(2,10)}`}
  workSessionController=UPCWorkSessionController.create({
   elementById:$,service:UPCWorkSessionService,fieldTags:PRIMARY_PURPOSE_TAGS,newId,sessionName:alaskaSessionName,escapeHtml:esc,dsdListName:ACEDSD.listName,
   dsdType:ACEDSD.TYPE,miscType:'ACE_NEW_ITEMS_MISC',fieldType:'FIELD_SESSION',
   dsdWorkspaceProvider:()=>dsdWorkspaceController,explorerProvider:()=>locationExplorerController,presentationProvider:()=>itemPresentationController,settingsProvider:()=>settingsController,onSessionChanged:()=>registerPriceController?.syncResumeButton?.(),
   diagnostic:diagnosticFor('WORK_SESSIONS','work-sessions/work-session-controller'),startOperation:subsystemOperationStart,finishOperation:subsystemOperationFinish,showScreen:show,goBack,confirmUser:appConfirm,alertUser:alert
  });
  dsdWorkspaceController=UPCDsdWorkspaceController.create({
   domain:ACEDSD,
   elementById:$,
   queryAll:selector=>document.querySelectorAll(selector),
   escapeHtml:esc,
   getSession:workSessionController.getCurrent,
   setSession:workSessionController.setCurrent,
   saveSession:workSessionController.saveCurrent,
   newId,
   sessionName:alaskaSessionName,
   showScreen:show,
   confirmUser:appConfirm,
   alertUser:alert,
   refreshSavedLists:workSessionController.refreshSummary,
   diagnostic:diagnosticFor('DSD','dsd/dsd-workspace-controller'),
   scrollToTop:()=>window.scrollTo({top:0,behavior:'smooth'}),fileDelivery:fileExportDeliveryService
  });
  const dsdChatGPTImportController=UPCDsdChatGPTImport.create({
   domain:ACEDSD,elementById:$,escapeHtml:esc,
   nativeBridgeProvider:()=>window.AndroidNative,
   acceptImported:payload=>dsdWorkspaceController.acceptImported(payload),
   listSessions:()=>UPCWorkSessionService.list(),confirmUser:appConfirm,
   fetchFn:(...args)=>fetch(...args),storage:localStorage,
   diagnostic:diagnosticFor('DSD','dsd/dsd-chatgpt-import')
  });
  startupOrchestrator.begin();
  diag('boot_script_entered',{progress:12});
  scannerController.bindControls({startOperation:startupOperationStart,finishOperation:startupOperationFinish,setStartupStage:setSplashStage});
  setSplashStage(38,'Binding application controls…');
  const dataBackupController=UPCDataBackupController.create({
   elementById:$,dataBackup:UPCDataBackup,databaseProvider:()=>UPCDB.open(),appVersion:APP_VERSION,buildId:APP_BUILD,
   diagnostic:diagnosticFor('BACKUP','application/data-backup-controller'),startOperation:subsystemOperationStart,finishOperation:subsystemOperationFinish,
   messageUser:appMessage,confirmUser:appConfirm,nativeBridgeProvider:()=>window.AndroidNative,
   locationRef:location,fileDelivery:fileExportDeliveryService
  });
  const ACE_NET_UNKNOWN=UPCAceNetHealthPolicy.UNKNOWN;
  const normalizeAceNetHealthStatus=UPCAceNetHealthPolicy.normalize;
  // Native Android remains authoritative for service health. Feature choices below are
  // session-only: startup sets their initial values, then user actions own the running session.
  const aceNetRuntimeState={
   startupStatus:'PENDING',
   authenticated:false,
   healthStatus:ACE_NET_UNKNOWN,
   consecutiveEmptyBodies:0,
   consecutivePriceFailures:0,
   reason:'',
   message:'Waiting for startup sign-in check.'
  };
  let adminDatabaseController=null;
  const settingsRepository=UPCSettingsRepository.create({db:UPCDB});
  const settingsController=UPCSettingsController.create({
   elementById:id=>document.getElementById(id),queryAll:selector=>document.querySelectorAll(selector),escapeHtml:esc,
   getCurrentSession:workSessionController.getCurrent,saveCurrentSession:workSessionController.saveCurrent,diagnostic:diagnosticFor('SETTINGS','application/settings-controller'),startOperation:subsystemOperationStart,finishOperation:subsystemOperationFinish,
   getAceNetRuntimeState:()=>aceNetRuntimeState,normalizeAceNetHealthStatus,unknownHealth:ACE_NET_UNKNOWN,nativeBridgeProvider:()=>window.AndroidNative,
   showScreen:show,refreshIdentityWorkQueues:()=>identityWorkController?.refreshWorkQueues?.(),refreshDatabaseViewerSummary:()=>adminDatabaseController?.refreshSummary?.(),exportSchema:UPCStandardExportSchema,
   initializeExportPreferences:settingsRepository.initializeExportPreferences,
   saveExportPreferences:settingsRepository.saveExportPreferences
  });
  const {aceNetPriceCheckEnabled,aceNetUpcEnrichmentEnabled,reconcileAceNetAutomaticPricing,syncAceNetFeatureUi,refreshAceNetLoginStatus,setAceNetPriceCheckEnabled,setAceNetUpcEnrichmentEnabled,syncManualPriceVisibility,syncListSettingsUI,openListSettings,closeListSettings,setListPromptLabelPrice,setListAutoAddPriceDifference,refreshAceNetCredentialStatus,saveAceNetCredentialsFromSettings,deleteAceNetCredentials,loadSettings}=settingsController;
  const aceNetStartupService=UPCAceNetStartupService.create({
   diagnostic:diagnosticFor('ACENET','application/acenet-startup-service'),nativeBridgeProvider:()=>window.AndroidNative,getRuntimeState:()=>aceNetRuntimeState,
   normalizeHealthStatus:normalizeAceNetHealthStatus,refreshLoginStatus:refreshAceNetLoginStatus,
   reconcileAutomaticPricing:reconcileAceNetAutomaticPricing,syncFeatureUi:syncAceNetFeatureUi,
   reportStartupProgress:startupOrchestrator.acceptAceNetProgress
  });
  const updateStatusService=UPCUpdateStatusService.create({
   elementById:$,diagnostic:diagnosticFor('UPDATE','application/update-status-service'),nativeBridgeProvider:()=>window.AndroidNative,appVersion:APP_VERSION
  });
  const aceNetPriceService=UPCAceNetPriceService.create({
   client:UPCAceNetClient,normalizeSku:normalizeSKU,normalizeUpc:normalizeAceNetUPC,normalizeHealthStatus:normalizeAceNetHealthStatus,
   getRuntimeState:()=>aceNetRuntimeState,diagnostic:diagnosticFor('ACENET','lookup/acenet-price-service'),bridgeProvider:()=>window.AndroidNative||null
  });
  const retailUnitsResolver=UPCRetailUnitsResolver.create({
   effectiveResolver:UPCEffectiveCatalogResolver,normalizeSku:normalizeSKU,diagnostic:diagnosticFor('CATALOG','catalog/retail-units-resolver'),startOperation:subsystemOperationStart,finishOperation:subsystemOperationFinish
  });
  manualIdentifierController=UPCManualIdentifierController.create({
   elementById:$,queryAll:selector=>document.querySelectorAll(selector),normalizeUpc:normalizeUPC,normalizeSku:normalizeSKU,
   diagnostic:diagnosticFor('LOOKUP','lookup/manual-identifier-controller'),performLookup:(...args)=>lookupRouter.perform(...args)
  });
  const itemRecordMapper=UPCItemRecordMapper.create({normalizeUpc:normalizeUPC});
  const catalogRefreshService=UPCCatalogRefreshService.create({
   policy:UPCCatalogRefreshPolicy,
   masterRepository:UPCMasterRepository,
   localRepository:UPCLocalRepository,
   relationshipService:UPCIdentifierRelationshipService,
   effectiveResolver:UPCEffectiveCatalogResolver,
   normalizeSku:normalizeSKU,
   normalizeUpc:normalizeUPC,
   resolveRetailUnits:retailUnitsResolver.resolve,
   diagnostic:diagnosticFor('CATALOG','catalog/catalog-refresh-service')
  });
  const productImageService=UPCProductImageService.create({
   normalizeUpc:normalizeUPC,
   comparisonEnabled:aceNetPriceCheckEnabled,
   diagnostic:diagnosticFor('LOOKUP','lookup/product-image-service'),
   storage:localStorage,
   fetchFn:(...args)=>fetch(...args),
   imageCtor:Image,
   bridgeProvider:()=>window.AndroidNative
  });
  // The planogram read-only viewer consumes Settings, mapper, AceNet price and image
  // services. Construct it only after all four dependencies are initialized.
  const planogramImportController=UPCPlanogramImportController.create({repository:UPCLocationRepository,adapter:UPCPlanogramImportAdapter.create({nativeBridgeProvider:()=>window.AndroidNative}),service:UPCPlanogramImportService,elementById:$,confirmUser:appConfirm,
   getSkuDetails:sku=>UPCLocationExplorerService.create({repository:UPCLocationRepository,catalog:UPCEffectiveCatalogResolver,policy:UPCLocationExplorerPolicy,itemMapper:itemRecordMapper}).details({skuKey:sku}),productImageService:{lookupProductImage:item=>productImageService.lookupProductImage(item)},priceService:{requestPrice:(...args)=>aceNetPriceService.requestPrice(...args)},comparisonEnabled:aceNetPriceCheckEnabled});
   locationMaintenanceController.setPlanogramRefresh(()=>planogramImportController.refreshSources());locationMaintenanceController.setConfirmUser(appConfirm);
  fieldSessionController=UPCFieldSessionController.create({
   elementById:$,getCurrent:workSessionController.getCurrent,getPending:()=>itemPresentationController.getPending(),saveCurrent:workSessionController.saveCurrent,newId,normalizeUpc:normalizeUPC,parseMoney,
   primaryPurposeTags:PRIMARY_PURPOSE_TAGS,fieldTags:PRIMARY_PURPOSE_TAGS,miscType:'ACE_NEW_ITEMS_MISC',diagnostic:diagnosticFor('FIELD_SESSION','field-session/field-session-controller'),alertUser:alert,
   presentationProvider:()=>itemPresentationController,listItemProvider:()=>listItemController,libraryWorkflowProvider:()=>masterLibraryWorkflow,
   unresolvedOriginProvider:()=>identityWorkController?.unresolvedOriginForCurrent?.(),recordUnresolved:(...args)=>identityWorkController.recordUnresolved(...args)
  });
  const itemPresentationController=UPCItemPresentationController.create({
   elementById:$,
   setText,
   subsystemOperationStart,
   subsystemOperationFinish,
   diagnostic:diagnosticFor('LOOKUP','lookup/item-presentation-controller'),
   releaseNotFoundSystemPurpose:fieldSessionController.releaseNotFoundSystemPurpose,
   applyNotFoundSystemPurpose:fieldSessionController.applyNotFoundSystemPurpose,
   configureTags:fieldSessionController.configureTags,
   applyDefaultTagSelection:fieldSessionController.applyDefaultTagSelection,
   syncManualPriceVisibility,
   productImageService,
   parseMoney,
   comparisonEnabled:aceNetPriceCheckEnabled,barcodeProvider:()=>registerPriceController,barcodePlanner:UPCRegisterBarcode.plan,locationLookupService
  });
  const normalLookupController=UPCNormalLookupController.create({
   localIdentifierResolver:UPCLocalIdentifierResolver,
   itemMapper:itemRecordMapper,
   relationshipService:UPCIdentifierRelationshipService,
   catalogRefreshService,
   normalizeSku:normalizeSKU,
   normalizeUpc:normalizeUPC,
   requestCatalog:UPCAceNetClient.requestCatalog,
   requestUpcs:sku=>UPCAceNetClient.requestUpcs(sku),
   priceService:aceNetPriceService,
   comparisonEnabled:aceNetPriceCheckEnabled,
   upcEnrichmentEnabled:aceNetUpcEnrichmentEnabled,
   diagnostic:diagnosticFor('LOOKUP','lookup/normal-lookup-controller'),
   presentationController:itemPresentationController,
   elementById:$,
   getManualLookupMode:manualIdentifierController.getMode,
   setManualLookupMode:manualIdentifierController.setMode,
   promptForUnknownUpcSku:manualIdentifierController.promptForUnknownUpcSku,
   applyScannedLabelPricePrompt:fieldSessionController.applyScannedLabelPricePrompt,
   subsystemOperationStart,
   subsystemOperationFinish,
   lookupOperationStart,
   lookupOperationFinish,
   getCurrentSession:workSessionController.getCurrent
  });
  identityWorkController=UPCIdentityWorkController.create({
   elementById:$,escapeHtml:esc,normalizeSku:normalizeSKU,normalizeUpc:normalizeUPC,localRepository:UPCLocalRepository,
   relationshipService:UPCIdentifierRelationshipService,catalogRefreshService,requestCatalog:UPCAceNetClient.requestCatalog,
   normalLookupProvider:()=>normalLookupController,workSessionService:UPCWorkSessionService,getCurrentSession:workSessionController.getCurrent,
   newId,sessionName:alaskaSessionName,messageUser:appMessage,alertUser:alert,promptUser:appPrompt,confirmUser:appConfirm,comparisonEnabled:aceNetPriceCheckEnabled,
   libraryWorkflowProvider:()=>masterLibraryWorkflow,diagnostic:diagnosticFor('IDENTITY','identity/identity-work-controller')
  });
  masterLibraryController=UPCMasterLibraryController.create({
   elementById:$,masterRepository:UPCMasterRepository,diagnostic:diagnosticFor('CATALOG','catalog/master-library-controller'),showScreen:show,
   navigationProvider:()=>navigationController,workflowProvider:()=>masterLibraryWorkflow,goBack,documentRef:document
  });
  masterLibraryWorkflow=UPCMasterLibraryWorkflow.create({
   elementById:$,escapeHtml:esc,diagnostic:diagnosticFor('CATALOG','library-workflow-v093'),progress:masterLibraryController.progress,refreshLibraryStatus:masterLibraryController.refreshStatus,
   localRepository:UPCLocalRepository,masterRepository:UPCMasterRepository,identifierNormalization:UPCIdentifierNormalization,xlsxImporter:XLSXImporter,
   combinedMasterExportProvider:()=>window.UPCCombinedMasterExport,identityWorkController,messageUser:appMessage,alertUser:alert,promptUser:appPrompt,fileDelivery:fileExportDeliveryService,performanceNow:()=>performance.now()
  });
  lookupRouter=UPCLookupRouter.create({
   getCurrentSession:workSessionController.getCurrent,miscWorkspaceProvider:()=>miscWorkspaceController,normalLookupController,miscType:'ACE_NEW_ITEMS_MISC'
  });
  const locationWorkController=UPCLocationWorkFeature.create({repository:UPCLocationRepository,db:UPCDB,policy:UPCLocationWorkPolicy,catalogResolver:UPCEffectiveCatalogResolver,elementById:$,documentRef:document,startScanner,normalizeUPC,normalizeSKU,idFactory:newId,promptDuplicate:entry=>itemPresentationController.promptDuplicateItem(entry,{purpose:'LOCATION'}),confirmUser:appConfirm,relationshipService:UPCIdentifierRelationshipService,verification:locationVerificationService,onManageAssignment:id=>locationMaintenanceController.openAssignment(id)});locationMaintenanceController.setWorkRefresh(()=>locationWorkController.refreshChoices());
  const locationExplorerController=UPCLocationExplorerFeature.create({repository:UPCLocationRepository,catalog:UPCEffectiveCatalogResolver,workController:locationWorkController,elementById:$,documentRef:document,showScreen:show,goBack,startScanner,normalizeUPC,normalizeSKU,confirmUser:appConfirm,idFactory:newId,itemMapper:itemRecordMapper,productImageService,priceService:aceNetPriceService,comparisonEnabled:aceNetPriceCheckEnabled,openIdentifierKeypad:options=>manualIdentifierController.keypad.open(options),db:UPCDB,tagSessionService:UPCWorkSessionService,tagGetCurrent:workSessionController.getCurrent,tagSetCurrent:workSessionController.setCurrent,tagSessionName:alaskaSessionName,tagOnSaved:()=>{workSessionController.refreshSummary?.();workSessionController.syncActiveListTypeUI?.()},verification:locationVerificationService,onManageAssignment:id=>locationMaintenanceController.openAssignment(id),tagNames:[...PRIMARY_PURPOSE_TAGS,...SUPPLEMENTAL_TAGS]});
  locationMaintenanceController.setOpenVisual(id=>locationExplorerController.openDisplay(id));
  scannerWorkspaceRouter=UPCScannerWorkspaceRouter.create({
   normalizeUpc:normalizeUPC,navigationProvider:()=>navigationController,getCurrentSession:workSessionController.getCurrent,dsdType:ACEDSD.TYPE,
   dsdWorkspaceProvider:()=>dsdWorkspaceController,manualIdentifierController,elementById:$,lookupRouter,locationWorkProvider:()=>locationWorkController,explorerProvider:()=>locationExplorerController
  });
  const miscDraftModel=UPCMiscDraftModel.create({
   normalizeSku:normalizeSKU,normalizeUpc:normalizeUPC,parseMoney,newId,verificationStates:ACEMisc.UPC_VERIFICATION
  });
  const miscMaintenanceService=UPCMiscMaintenanceService.create({
   workSessionService:UPCWorkSessionService,draftModel:miscDraftModel,normalizeSku:normalizeSKU,normalizeWeight:UPCCatalogMappers.normalizeAceNetWeight
  });
  const miscResolutionService=UPCMiscResolutionService.create({
   effectiveResolver:UPCEffectiveCatalogResolver,
   localRepository:UPCLocalRepository,
   relationshipService:UPCIdentifierRelationshipService,
   catalogRefreshService,
   normalLookupController,
   itemMapper:itemRecordMapper,
   miscDomain:ACEMisc,
   draftModel:miscDraftModel,
   normalizeSku:normalizeSKU,
   requestCatalog:UPCAceNetClient.requestCatalog,
   diagnostic:diagnosticFor('MISC','misc/misc-resolution-service')
  });
  const miscRuntimeResolver=UPCMiscRuntimeResolver.create({
   windowRef:window,documentRef:document,releaseProvider:()=>window.UPC_RELEASE_INFO||UPC_RELEASE,diagnostic:diagnosticFor('MISC','misc/misc-runtime-resolver'),resolutionService:miscResolutionService
  });
  const miscVerificationService=UPCMiscVerificationService.create({
   draftModel:miscDraftModel,miscDomain:ACEMisc,normalizeSku:normalizeSKU,normalizeUpc:normalizeUPC,
   resolveProvider:miscRuntimeResolver.requireResolver,promptUser:appPrompt,messageUser:appMessage,
   workSessionService:UPCWorkSessionService,getCurrentSession:workSessionController.getCurrent,setCurrentSession:workSessionController.setCurrent,diagnostic:diagnosticFor('MISC','misc/misc-verification-service')
  });
  const miscWorkspaceController=UPCMiscWorkspaceController.create({
   elementById:$,escapeHtml:esc,getCurrentSession:workSessionController.getCurrent,setCurrentSession:workSessionController.setCurrent,
   getManualLookupMode:manualIdentifierController.getMode,setManualLookupMode:manualIdentifierController.setMode,normalizeSku:normalizeSKU,normalizeUpc:normalizeUPC,
   presentationController:itemPresentationController,clearLookupTransientPriceState:itemPresentationController.clearLookupTransientPriceState,normalLookupController,
   resolveProvider:miscRuntimeResolver.requireResolver,verificationService:miscVerificationService,draftModel:miscDraftModel,miscDomain:ACEMisc,
   workSessionService:UPCWorkSessionService,newId,sessionName:alaskaSessionName,fileDelivery:fileExportDeliveryService,refreshSavedLists:workSessionController.refreshSummary,
   messageUser:appMessage,diagnostic:diagnosticFor('MISC','misc/misc-workspace-controller'),getAceNetRuntimeState:()=>aceNetRuntimeState,
   normalizeAceNetHealthStatus,performanceNow:()=>performance.now(),parseMoney,primaryPurposeTags:PRIMARY_PURPOSE_TAGS
  });
  listItemController=UPCListItemController.create({
   elementById:$,queryAll:selector=>document.querySelectorAll(selector),getCurrent:workSessionController.getCurrent,getPending:itemPresentationController.getPending,
   fieldSessionController,miscWorkspaceProvider:()=>miscWorkspaceController,itemPresentationController,identifierKeypadProvider:()=>manualIdentifierController.keypad,
   primaryPurposeTags:PRIMARY_PURPOSE_TAGS,parseMoney,escapeHtml:esc,aceNetPriceCheckEnabled,diagnostic:diagnosticFor('WORK_SESSIONS','work-sessions/list-item-controller'),messageUser:appMessage,miscType:'ACE_NEW_ITEMS_MISC'
  });
  const fieldSessionExportService=UPCFieldSessionExportService.create({
   getCurrentSession:workSessionController.getCurrent,exportTags:EXPORT_TAGS,dateStamp:today,promptUser:appPrompt,alertUser:alert,diagnostic:diagnosticFor('FIELD_SESSION','field-session/field-session-export-service'),startOperation:subsystemOperationStart,finishOperation:subsystemOperationFinish,
   storage:localStorage,zipCtor:JSZip,xlsxExporter:XLSXExporter,fileDelivery:fileExportDeliveryService,exportSchema:UPCStandardExportSchema,getExportPreferences:settingsRepository.getExportPreferences,aceMiscFormatter:ACEMisc,getKnownUpcsForSku:UPCIdentifierRelationshipService.getSkuUpcs
  });
  registerPriceController=UPCRegisterPriceController.create({
   elementById:$,getCurrent:workSessionController.getCurrent,saveCurrent:workSessionController.saveCurrent,
   exportService:fieldSessionExportService,barcode:UPCRegisterBarcode,alertUser:alert,
   diagnostic:diagnosticFor('FIELD_SESSION','field-session/register-price-controller')
  });
  const bridgeRegistration=UPCBridgeRegistration.register({
   windowRef:window,aceNetClient:UPCAceNetClient,productImageService,scannerController,aceNetDiagnosticService:aceNetNativeDiagnosticService,aceNetStartupService,
   startupOrchestrator,updateStatusService,diagnosticExportService
  });
  const miscSnapshotService=UPCMiscSnapshotService.create({
   relationshipService:UPCIdentifierRelationshipService,miscDomain:ACEMisc,normalizeUpc:normalizeUPC
  });
  const catalogMaintenanceService=UPCCatalogMaintenanceService.create({
   requestCatalog:UPCAceNetClient.requestCatalog,
   refreshService:catalogRefreshService,
   localRepository:UPCLocalRepository,
   miscMaintenanceService,
   normalizeSku:normalizeSKU,
   buildCorrectedSnapshot:miscSnapshotService.correctedSnapshotForLocalRow,
   buildSnapshotFromCatalog:ACEMisc.snapshotFromAceNetCatalog,
   syncCurrentSnapshot:miscWorkspaceController.syncCurrentSnapshot,
   diagnostic:diagnosticFor('CATALOG','catalog/catalog-maintenance-service')
  });
  adminDatabaseController=UPCAdminDatabaseController.create({
   elementById:id=>document.getElementById(id),escapeHtml:esc,normalizeSku:normalizeSKU,normalizeUpc:normalizeUPC,
   relationshipService:UPCIdentifierRelationshipService,localRepository:UPCLocalRepository,databaseInspectionService:UPCDatabaseInspectionService,miscMaintenanceService,
   miscSnapshotService,miscWorkspaceController,catalogMaintenanceService,identityWorkController,messageUser:appMessage,promptUser:appPrompt,confirmUser:appConfirm,alertUser:alert,diagnostic:diagnosticFor('ADMIN','application/admin-database-controller')
  });
  try{
  diag('boot_stage',{stage:'binding_ui'});
  masterLibraryController.bind();
  masterLibraryWorkflow.bind();
  navigationController.bind({windowRef:window,documentRef:document});
  locationMaintenanceController.bind();locationWorkController.bind();locationExplorerController.bind();
  planogramImportController.bind();
  settingsController.bind({on,goBack});
  updateStatusService.bind();
  workSessionController.bind({on});
  fieldSessionController.bind({on});
  manualIdentifierController.bind({on});
  itemPresentationController.bind({on});
  dsdWorkspaceController.bind({on,startScanner});
  dsdChatGPTImportController.bind({on});
  identityWorkController.bind({on});adminDatabaseController.bind({on});dataBackupController.bind({on});
  miscWorkspaceController.bind({on});
  registerPriceController.bind();
  $('exportPackage').onclick=async()=>{if(workSessionController.getCurrent()?.sessionType==='ACE_NEW_ITEMS_MISC')await miscWorkspaceController.exportCurrent();else registerPriceController.offerExport()};listItemController.bind({on,showScreen:show,goBack});
  diagnosticUiController.bind();webInstallService.start();
  diag('app_loaded',{buildId:APP_BUILD,standalone:matchMedia('(display-mode: standalone)').matches||navigator.standalone===true});
  runtimeReadinessService.evaluate({
   performLookup:lookupRouter.perform,
   performAceMiscLookup:miscWorkspaceController?.performLookup,
   aceMiscResolverExport:window.UPCAceMiscResolver?.resolveSkuCandidate,
   persistVerifiedAceNetCatalogToLocalLibrary:catalogRefreshService?.persistVerifiedAceNetCatalogToLocalLibrary,
   lookupItemBySku:normalLookupController?.lookupItemBySku,
   localSkuLookup:UPCLocalRepository?.lookupSKU,
   localUpcLookup:UPCLocalRepository?.lookupExactUPC,
   aceMiscLocalSnapshot:ACEMisc?.snapshotFromLocalRecord
  });
  diag('boot_stage',{stage:'ui_bound'});
  }catch(e){diag('ui_binding_error',{name:e?.name,message:e?.message,stack:e?.stack});}
  releasePresentationService.apply();diag('viewport',{innerWidth,innerHeight,dpr:devicePixelRatio,screenWidth:screen.width,screenHeight:screen.height,visualWidth:window.visualViewport?.width||null,visualHeight:window.visualViewport?.height||null});show('home','Scan. Build. Organize.',{push:false,reset:true});
  void startupOrchestrator.run({
   prepareSavedData:()=>UPCMigrationRepository.prepareWorkSessions({storage:localStorage,diagnostic:diagnosticFor('MIGRATION','migration-repository')}),
   refreshLibraryStatus:masterLibraryController.refreshStatus,
   refreshSavedListSummary:workSessionController.refreshSummary,
   runAceNetStartup:()=>aceNetStartupService.run()
  });
  
  // The unified lookup lifecycle owns presentation supersession while retaining compatibility diagnostics.
  
 }
 async function start({release}={}){
  try{
   if(!release?.version||!release?.build)throw new Error('Application release metadata is incomplete.');
   window.UPC_RELEASE_INFO=release;
   return await boot(release);
  }catch(error){renderFatal(error);return null}
 }
 return Object.freeze({start});
})();
window.UPCApplicationShell=UPCApplicationShell;
