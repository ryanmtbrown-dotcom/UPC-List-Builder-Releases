/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/dsd/dsd-workspace-controller.js
 * Owner: ACE New DSD Workspace
 * Role: Controller
 * Responsibility: Owns DSD setup/edit/import/export UI workflow, item editing, department/firearm controls, scanner acceptance, rendering, and DSD Work Session mutation.
 * Does not own: DSD workbook/domain rules, raw Work Session persistence, AceNet/catalog/identity policy, or native file APIs.
 * Side effects: Mutates DSD DOM and active DSD session through injected Work Session boundary; invokes DSD domain import/export.
 * Related code: Domain validation/workbook rules belong to ../ace-dsd.js.
 */
const UPCDsdWorkspaceController=(()=>{
 function create({
  domain,elementById,queryAll,escapeHtml,getSession,setSession,saveSession,newId,sessionName,showScreen,
  confirmUser,alertUser,refreshSavedLists,diagnostic,scrollToTop,fileDelivery
 }={}){
  if(!domain||typeof elementById!=='function'||typeof queryAll!=='function'||typeof getSession!=='function'||typeof setSession!=='function')throw new Error('DSD Workspace Controller state/view dependencies are incomplete.');
  if(typeof saveSession!=='function'||typeof newId!=='function'||typeof sessionName!=='function'||typeof showScreen!=='function'||typeof fileDelivery?.deliverBytes!=='function')throw new Error('DSD Workspace Controller persistence/navigation dependencies are incomplete.');
  const ACEDSD=domain,$=elementById,esc=escapeHtml,diag=typeof diagnostic==='function'?diagnostic:()=>{};
  let editingIndex=null,firearmControlRevealed=false;
  const current=()=>getSession();

  function invoiceFromForm(){return{primaryVendor:ACEDSD.upper($('dsdPrimaryVendor').value),secondaryVendor:ACEDSD.upper($('dsdSecondaryVendor').value),vendor:ACEDSD.upper($('dsdInvoiceVendor').value),invoiceNumber:ACEDSD.invoiceNumbers($('dsdInvoice').value),department:$('dsdDepartment').value.trim(),defaultRetailMethod:ACEDSD.upper($('dsdDefaultRetailMethod').value),defaultMarkup:$('dsdDefaultMarkup').value.trim()}}
  function setError(id,messages){const el=$(id),text=Array.isArray(messages)?messages.join(' '):String(messages||'');el.textContent=text;el.classList.toggle('hidden',!text)}
  function openDepartmentPicker(){
   $('dsdDepartmentRows').innerHTML=ACEDSD.DEPARTMENTS.map(([n,name])=>`<button type="button" class="dsdDepartmentRow" data-dsd-dept="${esc(n)}"><strong>${esc(n)}</strong><span>${esc(name)}</span></button>`).join('');
   queryAll('[data-dsd-dept]').forEach(b=>b.onclick=()=>{$('dsdDepartment').value=b.dataset.dsdDept;$('dsdDepartmentOverlay').classList.add('hidden')});
   $('dsdDepartmentOverlay').classList.remove('hidden');
  }
  function populateItemDepartments(value){const session=current(),select=$('dsdItemDepartment');if(!select)return;select.innerHTML=ACEDSD.DEPARTMENTS.map(([n,name])=>`<option value="${esc(n)}">${esc(n)} — ${esc(name)}</option>`).join('');const wanted=String(value||session?.dsdInvoice?.department||'');select.value=ACEDSD.deptName(wanted)?wanted:String(session?.dsdInvoice?.department||'')}
  function syncFirearmControl({keepRevealed=false}={}){const button=$('dsdFirearmToggle'),department=$('dsdItemDepartment')?.value||'',active=ACEDSD.isFirearmDepartment(department);if(!button)return;if(active)firearmControlRevealed=true;else if(!keepRevealed)firearmControlRevealed=false;button.classList.toggle('hidden',!firearmControlRevealed);button.setAttribute('aria-pressed',active?'true':'false')}
  function toggleFirearm(){const select=$('dsdItemDepartment');if(!select)return;const active=ACEDSD.isFirearmDepartment(select.value);select.value=ACEDSD.departmentForFirearmState(!active);firearmControlRevealed=true;syncFirearmControl({keepRevealed:true});syncRetailUi(false)}
  function syncRetailUi(preserveRetail=false){const markup=$('dsdRetailMethod').value==='MARKUP';$('dsdDirectWrap').classList.toggle('hidden',markup);$('dsdMarkupWrap').classList.toggle('hidden',!markup);const department=$('dsdItemDepartment')?.value||current()?.dsdInvoice?.department||'',requested=Number($('dsdMarkup').value),calc=markup?ACEDSD.retailFromMarkup($('dsdCaseCost').value,$('dsdOrderMult').value,$('dsdMarkup').value,department):null;if(markup&&!preserveRetail)$('dsdPrettyRetail').value=calc?.pretty!=null?calc.pretty.toFixed(2):'';const currentRetail=$('dsdPrettyRetail').value,actual=markup?ACEDSD.actualMarkup($('dsdCaseCost').value,$('dsdOrderMult').value,currentRetail):null;$('dsdRawRetail').innerHTML=calc?.raw!=null&&Number.isFinite(requested)&&actual!=null?`<span>Requested markup <strong>${requested.toFixed(2).replace(/\\.00$/,'')}%</strong></span><span>Current retail markup <strong>${actual.toFixed(2)}%</strong></span><span>Calculated target <strong>${calc.raw.toFixed(4)}</strong></span>`:'';syncGenerated()}
  function syncGenerated(){const session=current();if(!session?.dsdInvoice)return;const department=$('dsdItemDepartment')?.value||session.dsdInvoice.department,generatedSku=ACEDSD.sku(department,$('dsdUpc').value),generatedVendor=ACEDSD.vendor(session.dsdInvoice),cost=ACEDSD.unitCost($('dsdCaseCost').value,$('dsdOrderMult').value);$('dsdGenerated').innerHTML=`<span>SKU <strong>${esc(generatedSku||'—')}</strong></span><span>Vendor <strong>${esc(generatedVendor)}</strong></span><span>Unit Cost <strong>${cost==null?'—':'$'+cost.toFixed(4)}</strong></span>`}
  // A spreadsheet's vendor is untrusted input. Resolve it before creating a session.
  async function reviewImportedVendor(values){
   const raw=(values||[]).map(v=>ACEDSD.upper(v)),known=[...new Set(raw.filter(Boolean))];
   if(known.length===1&&known[0]===ACEDSD.DEFAULT_VENDOR)return ACEDSD.DEFAULT_VENDOR;
   const dialog=$('dsdVendorImportDialog'),multi=known.length>1,existing=known[0]||'';
   $('dsdVendorImported').textContent=known.join(' · ')||'Missing from workbook';
   $('dsdVendorReviewMessage').textContent=multi?'The workbook contains multiple vendor values. Choose a single invoice vendor before importing.':!existing?'No vendor was found. Confirm the default vendor or enter one.':'The imported vendor differs from WWD 663. Which vendor should be used?';
   $('dsdVendorKeep').classList.toggle('hidden',multi||!existing);
   $('dsdVendorEditWrap').classList.add('hidden');$('dsdVendorEdit').textContent='Edit Vendor';
   $('dsdVendorEditInput').value=multi?'':existing;setError('dsdVendorDialogError','');
   dialog.classList.remove('hidden');const previousFocus=document.activeElement;
   dialog.querySelector('.dsdImportModal')?.focus();
   return await new Promise(resolve=>{
    const controls=['dsdVendorUseDefault','dsdVendorKeep','dsdVendorEdit','dsdVendorCancel'];
    const finish=value=>{dialog.classList.add('hidden');dialog.removeEventListener('keydown',onKey);for(const id of controls)$(id).onclick=null;previousFocus?.focus?.();resolve(value)};
    const onKey=e=>{if(e.key==='Escape'){e.preventDefault();finish(null)}else if(e.key==='Tab'){
     const enabled=[...dialog.querySelectorAll('button,input')].filter(x=>!x.classList.contains('hidden')&&!x.closest('.hidden'));
     const first=enabled[0],last=enabled.at(-1);if(e.shiftKey&&document.activeElement===first){e.preventDefault();last?.focus()}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first?.focus()}
    }};
    dialog.addEventListener('keydown',onKey);
    $('dsdVendorUseDefault').onclick=()=>finish(ACEDSD.DEFAULT_VENDOR);
    $('dsdVendorKeep').onclick=()=>finish(existing);
    $('dsdVendorCancel').onclick=()=>finish(null);
    $('dsdVendorEdit').onclick=()=>{
     if($('dsdVendorEditWrap').classList.contains('hidden')){$('dsdVendorEditWrap').classList.remove('hidden');$('dsdVendorEdit').textContent='Save Vendor';$('dsdVendorEditInput').focus();return}
     const value=ACEDSD.upper($('dsdVendorEditInput').value);
     if(!value){setError('dsdVendorDialogError','Enter a vendor before continuing.');return}
     finish(value);
    };
   });
  }
  function syncDescriptionPreview(){
   const original=ACEDSD.upper($('dsdDescription').value).replace(/\s+/g,' '),short=ACEDSD.shortDescription(original);
   const changed=original!==short;
   $('dsdDescriptionPreview').classList.toggle('hidden',!changed);
   $('dsdDescriptionPreview').textContent=changed?'Export description ('+short.length+'/24): '+short:'';
  }
  function draftFromForm(){const method=$('dsdRetailMethod').value;return{upc:$('dsdUpc').value,department:$('dsdItemDepartment').value,description:$('dsdDescription').value,sourceDescription:(editingIndex!=null&&$('dsdDescription').value===current()?.items?.[editingIndex]?.description)?(current().items[editingIndex].sourceDescription||$('dsdDescription').value):$('dsdDescription').value,mfg:$('dsdMfg').value,serialNumber:$('dsdSerialNumber').value,orderMultiple:$('dsdOrderMult').value,caseCost:$('dsdCaseCost').value,retailMethod:method,retail:method==='MARKUP'?$('dsdPrettyRetail').value:$('dsdRetail').value,markup:$('dsdMarkup').value}}
  function fillDraft(d={}){const session=current();$('dsdUpc').value=d.upc??'';populateItemDepartments(d.department??session?.dsdInvoice?.department);firearmControlRevealed=ACEDSD.isFirearmDepartment($('dsdItemDepartment')?.value);syncFirearmControl();$('dsdDescription').value=d.description??'';
   const original=d.sourceDescription||d.description||'',different=ACEDSD.upper(original)!==ACEDSD.upper(d.description||'');
   $('dsdOriginalDescription').textContent=different?'Original: '+original:'';
   $('dsdOriginalDescription').classList.toggle('hidden',!different);
   $('dsdRestoreDescription').classList.toggle('hidden',!different);
   syncDescriptionPreview();$('dsdMfg').value=d.mfg??'';$('dsdSerialNumber').value=d.serialNumber??'';$('dsdOrderMult').value=d.orderMultiple??'';$('dsdCaseCost').value=d.caseCost??'';$('dsdRetailMethod').value=d.retailMethod||session?.dsdInvoice?.defaultRetailMethod||'DIRECT';$('dsdRetail').value=d.retail??'';$('dsdMarkup').value=d.markup??session?.dsdInvoice?.defaultMarkup??'';$('dsdPrettyRetail').value=d.retail??'';syncRetailUi(d.retail!==undefined&&d.retail!==null&&d.retail!=='')}
  function updatePreviousButtons(){const x=current()?.items?.at(-1),pairs=[['dsdPrevUpc','upc','UPC'],['dsdPrevDescription','description','Description'],['dsdPrevMfg','mfg','MFG #'],['dsdPrevOrderMult','orderMultiple','Order Multiple'],['dsdPrevCaseCost','caseCost','Case Cost']];for(const [id,key,label] of pairs){const b=$(id),v=x?.[key];b.classList.toggle('hidden',v===undefined||v===null||v==='');if(v!==undefined&&v!==null&&v!=='')b.textContent=`Previous ${label}: ${key==='caseCost'?'$'+Number(v).toFixed(2):v}`}}
  function render(){
   const session=current();if(!session?.dsdInvoice)return;const inv=session.dsdInvoice,name=ACEDSD.deptName(inv.department);$('dsdTitle').textContent=`Invoice ${inv.invoiceNumber}`;$('dsdSubtitle').textContent='Add DSD items. Saved items are persisted to this invoice.';$('dsdSetup').classList.add('hidden');$('dsdEntry').classList.remove('hidden');$('dsdInvoiceSummary').textContent=`Invoice ${inv.invoiceNumber} · ${ACEDSD.vendor(inv)} · Default Dept ${inv.department||'needed'} ${name}`;const notices=session.dsdImportNotices||[];$('dsdImportReviewSummary').classList.toggle('hidden',!notices.length);$('dsdImportReviewSummary').innerHTML=notices.length?'<strong>Imported item review</strong>'+notices.map(x=>'<p>'+esc(x)+'</p>').join(''):'';$('dsdItemNumber').textContent=editingIndex==null?`Item ${(session.items?.length||0)+1}`:`Edit Item ${editingIndex+1}`;$('dsdAddItem').textContent=editingIndex==null?'Add Item':'Save Changes';
    const rows=session.items||[];
    $('dsdCount').textContent=`${rows.length} item${rows.length===1?'':'s'}`;
    $('dsdRows').innerHTML=rows.length?rows.map((x,i)=>{
     const department=ACEDSD.effectiveDepartment(x,inv);
     const serial=x.serialNumber?` · Serial ${esc(x.serialNumber)}`:'';
     const retail=x.retail!==''&&x.retail!=null&&Number.isFinite(Number(x.retail))
      ?'$'+Number(x.retail).toFixed(2):'Retail needed';
     return `<div class="dsdRecord"><div class="dsdRecordCopy"><strong>${esc(x.description)}</strong><small>SKU ${esc(ACEDSD.sku(department,x.upc))} · Dept ${esc(department||'needed')} · UPC ${esc(x.upc)}${serial} · ${retail}</small></div><div class="dsdRecordActions"><button data-dsd-edit="${i}">Edit</button><button data-dsd-delete="${i}">Delete</button></div></div>`;
    }).join(''):'<p class="formHelp">No items added yet.</p>';
   queryAll('[data-dsd-edit]').forEach(b=>b.onclick=()=>{editingIndex=Number(b.dataset.dsdEdit);fillDraft(current().items[editingIndex]);render();scrollToTop?.()});
   queryAll('[data-dsd-delete]').forEach(b=>b.onclick=async()=>{const active=current(),i=Number(b.dataset.dsdDelete);if(!await confirmUser(`Delete ${active.items[i]?.description||'this item'}?`,'Delete Item',{okLabel:'Delete'}))return;active.items.splice(i,1);await saveSession();editingIndex=null;render()});
   updatePreviousButtons();syncFirearmControl({keepRevealed:true});syncGenerated();
  }
  function showSetup(existing=false){const session=current();$('dsdSetup').classList.remove('hidden');$('dsdEntry').classList.add('hidden');$('dsdTitle').textContent=existing?'Edit invoice':'Invoice setup';$('dsdSubtitle').textContent='Enter invoice defaults once. The default department may be overridden on any item.';$('dsdImportPanel')?.classList.toggle('hidden',existing);if(!existing){$('dsdPrimaryVendor').value='';$('dsdSecondaryVendor').value='';$('dsdInvoiceVendor').value=ACEDSD.DEFAULT_VENDOR;$('dsdInvoice').value='';$('dsdDepartment').value='';$('dsdDefaultRetailMethod').value='DIRECT';$('dsdDefaultMarkup').value=''}
  if(existing&&session?.dsdInvoice){const x=session.dsdInvoice;$('dsdPrimaryVendor').value=x.primaryVendor||'';$('dsdSecondaryVendor').value=x.secondaryVendor||'';$('dsdInvoiceVendor').value=ACEDSD.vendor(x);$('dsdInvoice').value=x.invoiceNumber||'';$('dsdDepartment').value=x.department||'';$('dsdDefaultRetailMethod').value=x.defaultRetailMethod||'DIRECT';$('dsdDefaultMarkup').value=x.defaultMarkup??''}$('dsdDefaultMarkupWrap').classList.toggle('hidden',$('dsdDefaultRetailMethod').value!=='MARKUP');setError('dsdSetupError','');showScreen('dsdScreen','ACE New DSD Items')}
  async function commitSetup(){const inv=invoiceFromForm(),span=diag.start?.({function:'commitSetup',purpose:'Validate and persist ACE New DSD invoice defaults.',expected:'A valid DSD invoice session is created or updated without changing existing item departments.',inputSummary:{invoiceNumber:inv.invoiceNumber,department:inv.department,hasSecondaryVendor:Boolean(inv.secondaryVendor)}}),err=ACEDSD.validateInvoice(inv);if(err.length){setError('dsdSetupError',err);diag.success?.(span,{event:'ace_dsd_invoice_validation_blocked',actual:'Invoice validation blocked persistence.',result:'INCONCLUSIVE',details:{validationErrors:err}});return}let session=current(),now=new Date().toISOString();if(!session||session.sessionType!==ACEDSD.TYPE){session={id:newId(),name:ACEDSD.listName(inv),createdAt:now,updatedAt:now,sessionType:ACEDSD.TYPE,items:[],captures:[],dsdInvoice:inv};setSession(session)}else{const previousInvoice=session.dsdInvoice;session.items=(session.items||[]).map(x=>ACEDSD.fillMissingMarkupRetail(ACEDSD.withLegacyDepartment(x,previousInvoice),inv));session.dsdInvoice=inv;session.name=ACEDSD.listName(inv)}await saveSession();editingIndex=null;fillDraft({department:inv.department,retailMethod:inv.defaultRetailMethod,markup:inv.defaultMarkup});render();diag('ace_dsd_invoice_saved',{operationId:span?.operationId,spanId:span?.spanId,listId:session.id,invoiceNumber:inv.invoiceNumber,department:inv.department,itemCount:session.items.length});await refreshSavedLists();diag.success?.(span,{event:'ace_dsd_invoice_commit_completed',actual:'DSD invoice defaults persisted and workspace refreshed.',details:{listId:session.id,department:inv.department,itemCount:session.items.length}})}
  async function addOrSave(){const session=current(),item=ACEDSD.buildItem(draftFromForm(),session.dsdInvoice),wasNew=editingIndex==null,span=diag.start?.({function:'addOrSave',purpose:wasNew?'Validate and add a DSD item.':'Validate and save DSD item edits.',expected:'The authoritative item department drives the generated SKU and the saved item is persisted.',inputSummary:{listId:session?.id||null,upc:item.upc,department:item.department,sku:item.sku,mode:wasNew?'ADD':'EDIT'}}),err=ACEDSD.validateItem(item);if(err.length){setError('dsdItemError',err);diag.success?.(span,{event:'ace_dsd_item_validation_blocked',actual:'Item validation blocked persistence.',result:'INCONCLUSIVE',details:{validationErrors:err}});return}setError('dsdItemError','');if(wasNew)session.items.push(item);else{item.id=session.items[editingIndex].id;item.addedAt=session.items[editingIndex].addedAt;session.items[editingIndex]=item;editingIndex=null}await saveSession();diag('ace_dsd_item_saved',{operationId:span?.operationId,spanId:span?.spanId,listId:session.id,sku:item.sku,upc:item.upc,department:item.department,count:session.items.length});if(wasNew)startNext($('dsdPreloadPrevious').checked);else render();diag.success?.(span,{event:'ace_dsd_item_commit_completed',actual:'DSD item persisted.',details:{listId:session.id,sku:item.sku,department:item.department,count:session.items.length}})}
  function startNext(similar){const session=current(),prev=session?.items?.at(-1);editingIndex=null;if(similar&&prev)fillDraft({...prev,serialNumber:''});else fillDraft({department:session.dsdInvoice.department,retailMethod:session.dsdInvoice.defaultRetailMethod,markup:session.dsdInvoice.defaultMarkup});render();$('dsdUpc').focus();scrollToTop?.()}
  async function importExisting(file){
   if(!file)return;
   const span=diag.start?.({function:'importExisting',purpose:'Review vendor and shortened descriptions before DSD workbook persistence.',inputSummary:{filename:file.name,size:file.size??null}});
   try{
    const imported=await ACEDSD.importWorkbook(file,()=>{});
    const chosen=await reviewImportedVendor(imported.importedVendors);
    if(chosen===null){diag('ace_dsd_import_cancelled',{filename:file.name});return}
    imported.invoice.vendor=chosen;
    const now=new Date().toISOString(),previous=current();
    const session={id:newId(),name:ACEDSD.listName(imported.invoice),createdAt:now,updatedAt:now,sessionType:ACEDSD.TYPE,items:imported.items,captures:[],dsdImportNotices:imported.warnings.filter(x=>!x.includes('imported vendor')&&!x.includes('has no vendor')&&!x.includes('multiple vendor values')),dsdInvoice:imported.invoice};
    setSession(session);
    try{await saveSession()}catch(error){setSession(previous);throw error}
    editingIndex=null;
    await refreshSavedLists();
    if(imported.needsInvoiceReview){showSetup(true);setError('dsdSetupError',imported.warnings.join(' '))}
    else{fillDraft({department:session.dsdInvoice.department,retailMethod:session.dsdInvoice.defaultRetailMethod,markup:session.dsdInvoice.defaultMarkup});render()}
    diag('ace_dsd_import_completed',{listId:session.id,filename:file.name,itemCount:session.items.length,vendor:chosen,warnings:imported.warnings});
    diag.success?.(span,{event:'ace_dsd_import_span_completed',actual:'Imported DSD workbook saved after vendor decision.',details:{listId:session.id,itemCount:session.items.length}});
   }catch(e){diag('ace_dsd_import_failed',{filename:file.name,message:e?.message||String(e)});diag.error?.(span,e,{event:'ace_dsd_import_span_failed',actual:'DSD import failed.'});setError('dsdSetupError','Import failed: '+(e?.message||e))}
   finally{if($('dsdImportFile'))$('dsdImportFile').value=''}
  }
  async function acceptImported(payload){
   // The existing ACE New DSD Work Session is the only editor. Imported source
   // data is untrusted and may be incomplete; export remains strictly validated.
   const sourceInvoice=payload?.invoice||{},raw=payload?.items;
   if(!Array.isArray(raw)||!raw.length||raw.length>200)throw Error('Choose 1–200 imported invoice items.');
   if(!String(sourceInvoice.primaryVendor||'').trim()||!String(sourceInvoice.invoiceNumber||'').trim())
    throw Error('The imported invoice needs a manufacturer and invoice number.');
   const invoice={
    primaryVendor:ACEDSD.upper(sourceInvoice.primaryVendor),
    secondaryVendor:ACEDSD.upper(sourceInvoice.secondaryVendor),
     vendor:ACEDSD.upper(sourceInvoice.vendor||ACEDSD.DEFAULT_VENDOR),
    invoiceNumber:ACEDSD.invoiceNumbers(sourceInvoice.invoiceNumber),
    department:String(sourceInvoice.department||'').trim(),
    defaultRetailMethod:ACEDSD.upper(sourceInvoice.defaultRetailMethod)==='MARKUP'||(ACEDSD.upper(sourceInvoice.defaultRetailMethod)!=='DIRECT'&&String(sourceInvoice.defaultMarkup??'').trim()!=='')?'MARKUP':'DIRECT',
    defaultMarkup:String(sourceInvoice.defaultMarkup??'').trim()
   };
   const items=raw.map(draft=>{
    // Preserve unknown data as blanks, not zero-valued merchandise.
    // Preserve explicit per-item method; otherwise an item markup takes priority.
    const requested=ACEDSD.upper(draft.retailMethod);
    if(requested&&requested!=='MARKUP'&&requested!=='DIRECT')throw Error('Unknown imported DSD retail method.');
    const method=requested||(String(draft.markup??'').trim()!==''?'MARKUP':invoice.defaultRetailMethod);
    const item={
     id:newId(),
     upc:String(draft.upc??'').replace(/\D/g,''),
     department:String(draft.department||invoice.department||'').trim(),
     description:ACEDSD.shortDescription(draft.description),
      sourceDescription:ACEDSD.upper(draft.originalDescription||draft.sourceDescription||draft.description),
     mfg:ACEDSD.upper(draft.mfg),
     serialNumber:ACEDSD.upper(draft.serialNumber),
     orderMultiple:String(draft.orderMultiple??'').trim(),
     caseCost:String(draft.caseCost??'').trim(),
     retailMethod:method,
     markup:method==='MARKUP'?String(String(draft.markup??'').trim()!==''?draft.markup:invoice.defaultMarkup).trim():'',
     retail:String(draft.retail??'').trim()
    };
    // Price an otherwise complete cost-plus-markup draft, not a manual override.
    return ACEDSD.fillMissingMarkupRetail(item,invoice);
   });
   const choice=await reviewImportedVendor([invoice.vendor]);
   if(choice===null)throw Error('DSD invoice import cancelled by user.');
   invoice.vendor=choice;
   const old=current(),now=new Date().toISOString();
   const session={id:newId(),name:ACEDSD.listName(invoice),
    createdAt:now,updatedAt:now,sessionType:ACEDSD.TYPE,items,captures:[],dsdInvoice:invoice,
    ...(payload?.dsdImportBatchId?{dsdImportBatchId:payload.dsdImportBatchId}:{})};
   setSession(session);
   try{await saveSession()}catch(error){setSession(old);throw error}
   editingIndex=null;
   await refreshSavedLists();
   fillDraft({department:invoice.department,retailMethod:invoice.defaultRetailMethod,markup:invoice.defaultMarkup});
   render();showScreen('dsdScreen','ACE New DSD Items');
   diag('ace_dsd_chatgpt_import_saved',{listId:session.id,itemCount:items.length,needsReview:false,
    incompleteCount:items.filter(x=>!x.department||!x.caseCost||!x.orderMultiple||!x.retail).length});
   return session.id;
  }
  async function exportCurrent(){const session=current(),span=diag.start?.({function:'exportCurrent',purpose:'Validate and export the current ACE New DSD workbook.',expected:'Every saved item is rebuilt from its authoritative department and exported to a compatible XLSX.',inputSummary:{listId:session?.id||null,itemCount:session?.items?.length||0,invoiceNumber:session?.dsdInvoice?.invoiceNumber||null}});try{const payload=await ACEDSD.exportList(session),out={name:payload.name,rows:payload.rows};fileDelivery.deliverBytes(payload.bytes,payload.name,payload.mime);diag('ace_dsd_export_requested',{operationId:span?.operationId,spanId:span?.spanId,...out,listId:session.id,invoiceNumber:session.dsdInvoice.invoiceNumber});diag.success?.(span,{event:'ace_dsd_export_span_completed',actual:'DSD export was generated and handed to the platform export path.',details:out});alertUser(`Exported ${out.name}`)}catch(e){diag('ace_dsd_export_failed',{operationId:span?.operationId,spanId:span?.spanId,message:e?.message||String(e)});diag.error?.(span,e,{event:'ace_dsd_export_span_failed',actual:'DSD export failed.'});alertUser(`ACE DSD export failed: ${e?.message||e}`)}}
  function startNew(){setSession(null);editingIndex=null;showSetup(false)}
  function openExisting(){const session=current();editingIndex=null;fillDraft({retailMethod:session?.dsdInvoice?.defaultRetailMethod,markup:session?.dsdInvoice?.defaultMarkup});render();showScreen('dsdScreen',session?.name||'ACE New DSD Items')}
  function acceptScannedUpc(upc){$('dsdUpc').value=upc;syncGenerated()}
  function bind({on,startScanner}={}){if(typeof on!=='function')throw new Error('DSD Workspace Controller requires the shared event binder.');on('dsdDepartmentHelp','click',openDepartmentPicker);on('dsdDepartmentClose','click',()=> $('dsdDepartmentOverlay').classList.add('hidden'));on('dsdDefaultRetailMethod','change',()=> $('dsdDefaultMarkupWrap').classList.toggle('hidden',$('dsdDefaultRetailMethod').value!=='MARKUP'));on('dsdSetupCancel','click',()=>showScreen('home','Scan. Build. Organize.'));on('dsdSetupNext','click',commitSetup);on('dsdImportButton','click',()=>$('dsdImportFile')?.click());on('dsdImportFile','change',()=>importExisting($('dsdImportFile')?.files?.[0]));on('dsdEditInvoice','click',()=>showSetup(true));on('dsdRetailMethod','change',()=>syncRetailUi(false));on('dsdItemDepartment','change',()=>{firearmControlRevealed=ACEDSD.isFirearmDepartment($('dsdItemDepartment').value);syncFirearmControl();syncRetailUi(false)});on('dsdFirearmToggle','click',toggleFirearm);['dsdCaseCost','dsdOrderMult','dsdMarkup'].forEach(id=>on(id,'input',()=>syncRetailUi(false)));on('dsdPrettyRetail','input',()=>syncRetailUi(true));on('dsdUpc','input',syncGenerated);on('dsdDescription','input',syncDescriptionPreview);on('dsdRestoreDescription','click',()=>{const original=current()?.items?.[editingIndex]?.sourceDescription;if(original){$('dsdDescription').value=original;syncDescriptionPreview();$('dsdDescription').focus()}});on('dsdAddItem','click',addOrSave);on('dsdHome','click',()=>showScreen('home','Scan. Build. Organize.'));on('dsdExport','click',exportCurrent);on('dsdScan','click',startScanner);[['dsdPrevUpc','dsdUpc','upc'],['dsdPrevDescription','dsdDescription','description'],['dsdPrevMfg','dsdMfg','mfg'],['dsdPrevOrderMult','dsdOrderMult','orderMultiple'],['dsdPrevCaseCost','dsdCaseCost','caseCost']].forEach(([bid,fid,key])=>on(bid,'click',()=>{const v=current()?.items?.at(-1)?.[key];if(v!==undefined&&v!==null){$(fid).value=v;syncRetailUi();$(fid).focus()}}))}
  return Object.freeze({bind,startNew,openExisting,showSetup,render,acceptScannedUpc,syncGenerated,acceptImported});
 }
 return Object.freeze({create});
})();
window.UPCDsdWorkspaceController=UPCDsdWorkspaceController;
