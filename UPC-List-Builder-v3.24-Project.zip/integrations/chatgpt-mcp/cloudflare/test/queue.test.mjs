import test from 'node:test';
import assert from 'node:assert/strict';
import { DatabaseSync } from 'node:sqlite';
import {readFileSync} from 'node:fs';
import {createQueue} from '../src/queue.mjs';
import {validateBatch} from '../src/validate.mjs';
import {prepareReview,requireMissingDepartmentAcknowledgment,DEPARTMENTS} from '../src/review-policy.mjs';
import {REVIEW_UI_HTML} from '../src/review-ui.mjs';

function dbHarness(){
 const database=new DatabaseSync(':memory:');
 database.exec(readFileSync(new URL('../migrations/0001_import_queue.sql',import.meta.url),'utf8'));
 const binding={
  prepare(sql){
   let args=[];
   const op={
    bind(...values){args=values;return op},
    async run(){const result=database.prepare(sql).run(...args);return{meta:{changes:result.changes}}},
    async first(){return database.prepare(sql).get(...args)||null},
    async all(){return{results:database.prepare(sql).all(...args)}}
   };
   return op;
  },
  async batch(queries){return Promise.all(queries.map(q=>q.run()))}
 };
 return{database,binding,queue:createQueue(binding)};
}
const invoice=()=>({
 sourceFilename:'Supplier.pdf',
 invoice:{primaryVendor:'ACME',invoiceNumber:'INV-123',department:'72',defaultRetailMethod:'DIRECT'},
 items:[{upc:'001234567890',description:'Example',mfg:'ABC-1',orderMultiple:2,caseCost:12.5,retail:8.99}]
});
test('one-use ten-minute pairing and device token revocation',async()=>{
 const h=dbHarness();try{
  const p=await h.queue.createPairing('github:111');
  assert.match(p.code,/^[A-Za-z0-9_-]{24}$/);
  const d=await h.queue.claim(p.code);
  assert.match(d.token,/^[A-Za-z0-9_-]{43}$/);
  assert.equal(await h.queue.claim(p.code),null);
  assert.equal(await h.queue.deviceOwner(d.token),'github:111');
  assert.equal(await h.queue.deviceOwner('garbage'),null);
  assert.equal(await h.queue.revoke(d.token),true);
  assert.equal(await h.queue.deviceOwner(d.token),null);
 }finally{h.database.close();}
});
test('account isolation, delivery, idempotency, and receipt',async()=>{
 const h=dbHarness();try{
  const a=await h.queue.submit('github:111',invoice());
  const b=await h.queue.submit('github:111',invoice());
  assert.equal(a.id,b.id);
  assert.equal((await h.queue.list('github:111')).length,1);
  assert.equal((await h.queue.list('github:222')).length,0);
  assert.equal(await h.queue.get('github:222',a.id),null);
  assert.equal(await h.queue.status('github:222',a.id),null);
  assert.equal(await h.queue.acknowledge('github:222',a.id),false);
  assert.equal((await h.queue.get('github:111',a.id)).items[0].upc,'001234567890');
  assert.equal(await h.queue.acknowledge('github:111',a.id),true);
  assert.equal(await h.queue.acknowledge('github:111',a.id),true);
  assert.equal((await h.queue.list('github:111')).length,0);
  assert.equal((await h.queue.status('github:111',a.id)).state,'imported');
 }finally{h.database.close();}
});
test('do not invent missing case cost or retail; enforce batch limits',()=>{
 const input=invoice();delete input.items[0].retail;
 assert.equal(validateBatch(input).items[0].retail,'');
 assert.equal(validateBatch(input).items[0].upc,'001234567890');
 assert.throws(()=>validateBatch({...input,items:[]}),/1–200/);
 assert.throws(()=>validateBatch({...input,items:Array(201).fill(input.items[0])}),/1–200/);
 assert.throws(()=>validateBatch({...input,items:[{description:'x'.repeat(401)}]}),/maximum/);
});

test('WWD is resolved as secondary manufacturer by the plugin, not Android',()=>{
 const data=invoice();
 data.sourceFilename='Pradco Outdoor Invoice WWD 7452875(1).pdf';
 data.invoice.primaryVendor='PRADCO';
 const staged=validateBatch(data);
 assert.equal(staged.invoice.primaryVendor,'PRADCO');
 assert.equal(staged.invoice.secondaryVendor,'WWD');
 assert.equal(staged.sourceFilename,data.sourceFilename);
});
test('unrelated WWD-like text does not trigger false secondary manufacturer',()=>{
 const data=invoice();
 data.sourceFilename='WWDSupplier invoice.pdf';
 assert.equal(validateBatch(data).invoice.secondaryVendor,'');
});
test('independent manufacturer fields accept multiword names without artificial splitting',()=>{
 const data=invoice();
 data.invoice.primaryVendor='PRADCO OUTDOOR BRANDS';
 assert.equal(validateBatch(data).invoice.primaryVendor,'PRADCO OUTDOOR BRANDS');
 data.manufacturerClarification='split'; // legacy requests cannot force whitespace parsing
 assert.equal(validateBatch(data).invoice.primaryVendor,'PRADCO OUTDOOR BRANDS');
 data.invoice.secondaryVendor='WORLDWIDE DISTRIBUTORS';
 delete data.manufacturerClarification;
 assert.equal(validateBatch(data).invoice.secondaryVendor,'WORLDWIDE DISTRIBUTORS');
});
test('WWD conflicts are blocked rather than silently overriding supplied secondary',()=>{
 const data=invoice();
 data.sourceFilename='PRADCO WWD.pdf';
 data.invoice.secondaryVendor='ANOTHER';
 assert.throws(()=>validateBatch(data),/WWD and another Second Manufacturer/);
});

test('WWD invoice reference never becomes a different primary manufacturer invoice',()=>{
 const input=invoice();
 input.sourceFilename='Pradco Outdoor Invoice WWD 7452875(1).pdf';
 input.invoice.primaryVendor='PRADCO';
 input.invoice.invoiceNumber='114774552';
 input.invoiceNumberSource='primary';
 assert.equal(validateBatch(input).invoice.invoiceNumber,'114774552');
 input.invoice.invoiceNumber='7452875';
 delete input.invoiceNumberSource;
 const result=validateBatch(input);
 assert.equal(result.invoice.invoiceNumber,'00000');
 assert.equal(result.invoice.secondaryVendor,'WWD');
 assert.ok(result.warnings.some(x=>x.includes('placeholder')));
});

test('explicit secondary references are excluded from primary invoice and PO precedence',()=>{
 const input=invoice();
 input.secondaryInvoiceNumbers=['99813','99814'];
 input.invoice.invoiceNumber='INV-123';
 input.invoiceNumberSource='primary';
 assert.equal(validateBatch(input).invoice.invoiceNumber,'INV-123');
 input.invoice.invoiceNumber='99813';
 delete input.invoiceNumberSource;
 assert.equal(validateBatch(input).invoice.invoiceNumber,'00000');
});

test('reject only own pending batch, keep others and accepted invoices intact',async()=>{
 const h=dbHarness();try{
  const a=await h.queue.submit('github:111',invoice());
  assert.equal(await h.queue.reject('github:222',a.id),false);
  assert.equal((await h.queue.list('github:111')).length,1);
  assert.equal(await h.queue.reject('github:111',a.id),true);
  assert.equal((await h.queue.list('github:111')).length,0);
  assert.equal(await h.queue.get('github:111',a.id),null);
  assert.equal(await h.queue.acknowledge('github:111',a.id),false);
  const b=await h.queue.submit('github:111',invoice());
  assert.equal(await h.queue.acknowledge('github:111',b.id),true);
  assert.equal(await h.queue.reject('github:111',b.id),false);
  assert.equal((await h.queue.status('github:111',b.id)).state,'imported');
 }finally{h.database.close()}
});

test('source evidence automatically resolves Pradco invoice vs WWD number without clarification',()=>{
 const input=invoice();
 input.sourceFilename='Pradco Outdoor Invoice WWD 7452875(1).pdf';
 input.invoice.primaryVendor='PRADCO';
 input.invoice.invoiceNumber='07452875'; // wrong choice must be corrected, not silently accepted
 input.invoiceIdentifiers=[
  {value:'114774552',sourceLabel:'PRADCO Invoice Number',issuer:'primary',kind:'invoice'},
  {value:'07452875',sourceLabel:'WWD Invoice Number',issuer:'secondary',kind:'invoice'},
  {value:'PO-4408',sourceLabel:'Customer PO',issuer:'buyer',kind:'purchase_order'}
 ];
 input.secondaryInvoiceNumbers=['07452875'];
 const staged=validateBatch(input);
 assert.equal(staged.invoice.invoiceNumber,'114774552');
 assert.equal(staged.invoice.secondaryVendor,'WWD');
 assert.ok(staged.warnings.some(x=>x.includes('PRADCO Invoice Number')));
 assert.ok(staged.warnings.some(x=>x.includes('corrected')));
 assert.equal(Object.hasOwn(staged,'invoiceIdentifiers'),false);
});
test('one repeated primary invoice with leading-zero variants is one identity',()=>{
 const input=invoice();
 input.invoice.invoiceNumber='';
 input.invoiceIdentifiers=[
  {value:'00012345',sourceLabel:'Maker invoice header',issuer:'primary',kind:'invoice'},
  {value:'12345',sourceLabel:'Maker invoice footer',issuer:'primary',kind:'invoice'},
  {value:'PO-7',sourceLabel:'Purchase order',issuer:'buyer',kind:'purchase_order'}
 ];
 assert.equal(validateBatch(input).invoice.invoiceNumber,'00012345');
});
test('two distinct primary numbers require one targeted question',()=>{
 const input=invoice();
 input.invoiceIdentifiers=[
  {value:'12345',sourceLabel:'Invoice A',issuer:'primary',kind:'invoice'},
  {value:'12346',sourceLabel:'Invoice B',issuer:'primary',kind:'invoice'}
 ];
 assert.throws(()=>validateBatch(input),/Multiple distinct primary-manufacturer invoice numbers/);
});
test('unknown issuer on a competing invoice number requires clarification',()=>{
 const input=invoice();
 input.invoiceIdentifiers=[
  {value:'12345',sourceLabel:'Issuer invoice',issuer:'primary',kind:'invoice'},
  {value:'12346',sourceLabel:'Unlabeled second invoice',issuer:'unknown',kind:'invoice'}
 ];
 assert.throws(()=>validateBatch(input),/unknown issuer/);
});
test('source evidence may not assign buyer purchase order as primary invoice',()=>{
 const input=invoice();
 input.invoice.invoiceNumber='PO-456';
 input.invoiceIdentifiers=[
  {value:'PO-456',sourceLabel:'Buyer PO',issuer:'buyer',kind:'purchase_order'},
  {value:'INV-123',sourceLabel:'Supplier Invoice',issuer:'primary',kind:'invoice'}
 ];
 const staged=validateBatch(input);
 assert.equal(staged.invoice.invoiceNumber,'INV-123');
 assert.ok(staged.warnings.some(x=>x.includes('corrected')));
});
test('WWD labels cannot override a different primary manufacturer',()=>{
 const input=invoice();
 input.invoice.invoiceNumber='12345';
 input.invoiceIdentifiers=[
  {value:'12345',sourceLabel:'WWD invoice header',issuer:'primary',kind:'invoice'},
  {value:'12345',sourceLabel:'WWD reference',issuer:'secondary',kind:'reference'}
 ];
 assert.equal(validateBatch(input).invoice.invoiceNumber,'00000');
 input.invoiceIdentifiers[1].sourceLabel='';
 assert.throws(()=>validateBatch(input),/actual document label/);
});


test('WWD-only manufacturer and single WWD invoice use actual number, not PO or zero',()=>{
 const input=invoice();
 input.sourceFilename='WWD 123456 invoice.pdf';
 input.invoice.primaryVendor='WWD';
 input.invoice.invoiceNumber='';
 input.invoiceIdentifiers=[
  {value:'123456',sourceLabel:'WWD invoice',issuer:'primary',kind:'invoice'},
  {value:'78910',sourceLabel:'Buyer PO',issuer:'buyer',kind:'purchase_order'}
 ];
 const result=validateBatch(input);
 assert.equal(result.invoice.primaryVendor,'WWD');
 assert.equal(result.invoice.secondaryVendor,'');
 assert.equal(result.invoice.invoiceNumber,'123456');
});
test('WWD plus Pradco uses Pradco invoice before any primary PO',()=>{
 const input=invoice();
 input.invoice.primaryVendor='PRADCO';
 input.sourceFilename='WWD PRADCO 123456.pdf';
 input.invoice.invoiceNumber='123456';
 input.invoiceIdentifiers=[
  {value:'123456',sourceLabel:'WWD Invoice',issuer:'secondary',kind:'invoice'},
  {value:'114774552',sourceLabel:'Pradco Invoice',issuer:'primary',kind:'invoice'},
  {value:'78910',sourceLabel:'Pradco PO',issuer:'primary',kind:'purchase_order'}
 ];
 const result=validateBatch(input);
 assert.equal(result.invoice.secondaryVendor,'WWD');
 assert.equal(result.invoice.invoiceNumber,'114774552');
});
test('WWD invoice with primary manufacturer PO uses PO prefix',()=>{
 const input=invoice();
 input.sourceFilename='WWD PRADCO invoice 123456.pdf';
 input.invoice.primaryVendor='PRADCO';
 input.invoice.invoiceNumber='123456';
 input.invoiceIdentifiers=[
  {value:'123456',sourceLabel:'WWD invoice',issuer:'secondary',kind:'invoice'},
  {value:'78910',sourceLabel:'Pradco PO',issuer:'primary',kind:'purchase_order'}
 ];
 const result=validateBatch(input);
 assert.equal(result.invoice.primaryVendor,'PRADCO');
 assert.equal(result.invoice.secondaryVendor,'WWD');
 assert.equal(result.invoice.invoiceNumber,'PO78910');
 assert.ok(result.warnings.some(x=>x.includes('purchase-order identifier')));
});
test('WWD invoice with no primary invoice and no primary PO uses numeric placeholder',()=>{
 const input=invoice();
 input.sourceFilename='WWD PRADCO invoice 123456.pdf';
 input.invoice.primaryVendor='PRADCO';
 input.invoice.invoiceNumber='123456';
 input.invoiceIdentifiers=[
  {value:'123456',sourceLabel:'WWD invoice',issuer:'secondary',kind:'invoice'},
  {value:'78910',sourceLabel:'Buyer PO',issuer:'buyer',kind:'purchase_order'}
 ];
 const result=validateBatch(input);
 assert.equal(result.invoice.invoiceNumber,'00000');
 assert.ok(result.warnings.some(x=>x.includes('placeholder')));
});
test('WWD-only invoice may use filename invoice number when no other invoice exists',()=>{
 const input=invoice();
 input.sourceFilename='WWD 123456.pdf';
 input.invoice.primaryVendor='WWD';
 input.invoice.invoiceNumber='';
 const result=validateBatch(input);
 assert.equal(result.invoice.invoiceNumber,'123456');
});
test('primary PO identifier already prefixed PO is not double-prefixed',()=>{
 const input=invoice();
 input.sourceFilename='WWD PRADCO.pdf';
 input.invoice.primaryVendor='PRADCO';
 input.invoice.invoiceNumber='';
 input.invoiceIdentifiers=[{value:'PO 78910',sourceLabel:'Pradco purchase order',issuer:'primary',kind:'purchase_order'}];
 assert.equal(validateBatch(input).invoice.invoiceNumber,'PO78910');
});
test('conflicting primary POs require clarification rather than arbitrary selection',()=>{
 const input=invoice();
 input.sourceFilename='WWD PRADCO.pdf';
 input.invoice.primaryVendor='PRADCO';
 input.invoice.invoiceNumber='';
 input.invoiceIdentifiers=[
  {value:'78910',sourceLabel:'Primary PO A',issuer:'primary',kind:'purchase_order'},
  {value:'78911',sourceLabel:'Primary PO B',issuer:'primary',kind:'purchase_order'}
 ];
 assert.throws(()=>validateBatch(input),/Multiple primary-manufacturer purchase order/);
});


test('DSD missing order multiple defaults to one and reconciled invoice cost is per unit',()=>{
 const input=invoice();
 input.items=[
  {upc:'012345678901',description:'SANDALS BLUE',orderedQuantity:2,lineTotal:'75.80'},
  {upc:'012345678902',description:'SANDALS PURPLE',orderedQuantity:3,eachCost:'37.90',lineTotal:'113.70'},
  {upc:'012345678903',description:'SANDALS BLACK',orderMultiple:2,orderedQuantity:2,eachCost:'37.90',lineTotal:'75.80'}
 ];
 const rows=validateBatch(input).items;
 assert.deepEqual(rows.map(x=>x.orderMultiple),['1','1','2']);
 assert.deepEqual(rows.map(x=>Number(x.caseCost)),[37.9,37.9,75.8]);
 assert.equal(rows[0].department,'','No per-item department required when invoice default is supplied.');
});
test('cost sources must reconcile; ambiguous cost never silently divides a line price',()=>{
 const input=invoice();
 input.items=[{description:'SANDALS',orderedQuantity:3,caseCost:75.8}];
 assert.throws(()=>validateBatch(input),/ambiguous caseCost/);
 input.items[0].lineTotal='75.80';
 assert.equal(Number(validateBatch(input).items[0].caseCost),Number((75.80/3).toFixed(4)));
 input.items[0].eachCost='37.90';
 assert.throws(()=>validateBatch(input),/does not reconcile/);
});
test('zero-cost displays are excluded but zero-cost merchandise remains',()=>{
 const input=invoice();
 input.items=[
  {description:'PROMO COUNTER DISPLAY',caseCost:'0.00'},
  {description:'SANDALS',caseCost:'0.00'},
  {description:'DISPLAY STAND',orderedQuantity:1,lineTotal:'0.00'},
  {description:'DIGITAL DISPLAY PRODUCT',caseCost:0}
 ];
 const staged=validateBatch(input);
 assert.deepEqual(staged.items.map(x=>x.description),['SANDALS','DIGITAL DISPLAY PRODUCT']);
 assert.equal(staged.warnings.filter(x=>x.includes('excluded: zero-cost display')).length,2);
 input.items=[{description:'FREE DISPLAY',caseCost:'0.00'}];
 assert.throws(()=>validateBatch(input),/no merchandise items/);
});
test('serial number forces 46 while optional departments and ammunition defaults remain per item',()=>{
 const input=invoice();input.invoice.department='72';
 input.items=[
  {description:'SANDALS',caseCost:12},
  {description:'RIFLE',serialNumber:'ABC123',department:'72',caseCost:300},
  {description:'9MM FMJ 115GR 50 ROUNDS',caseCost:12},
  {description:'9MM FMJ 115GR 50 ROUNDS',department:'69',caseCost:12},
  {description:'AMMO BOX STORAGE',caseCost:12},
  {description:'GARDEN HOSE',department:'70',caseCost:9}
 ];
 const staged=validateBatch(input);
 assert.equal(staged.invoice.department,'72');
 assert.deepEqual(staged.items.map(x=>x.department),['','46','46','69','','70']);
 assert.ok(staged.warnings.some(x=>x.includes('serial number')));
 assert.ok(staged.warnings.some(x=>x.includes('verify classification')));
});


test('staging response reports excluded display lines without importing them',async()=>{
 const h=dbHarness();try{
  const input=invoice();input.items=[
   {upc:'',description:'FREE COUNTER DISPLAY',caseCost:0},
   {upc:'012345678901',description:'PAID SANDALS',orderedQuantity:2,lineTotal:'75.80'}
  ];
  const submitted=await h.queue.submit('github:111',input);
  assert.equal(submitted.itemCount,1);
  assert.ok(submitted.warnings.some(x=>x.includes('excluded: zero-cost display')));
  const saved=await h.queue.get('github:111',submitted.id);
  assert.deepEqual(saved.items.map(x=>x.description),['PAID SANDALS']);
  assert.equal(saved.items[0].orderMultiple,'1');
  assert.equal(Number(saved.items[0].caseCost),37.9);
 }finally{h.database.close();}
});


test('ammunition invoice abbreviations do not reclassify unrelated accessories',()=>{
 const input=invoice();input.invoice.department='72';
 input.items=[
  {description:'22LR 40GR 50 RDS',caseCost:12},
  {description:'5.56 NATO 55GR 20RD',caseCost:12},
  {description:'380 ACP 95GR FMJ 50 RDS',originalDescription:'380 ACP 95 GR FMJ 50 ROUNDS',caseCost:12},
  {description:'PRIMER SMALL RIFLE 1000',originalDescription:'PRIMER SMALL RIFLE 1000CT',caseCost:12},
  {description:'AMMO STORAGE BOX',caseCost:12},
  {description:'9MM DRILL BIT',caseCost:12}
 ];
 const rows=validateBatch(input).items;
 assert.deepEqual(rows.map(x=>x.department),['46','46','46','46','','']);
});

test('department registry mirrors the Android DSD authoritative registry',()=>{
 const source=readFileSync(new URL('../../../../app/src/main/assets/www/ace-dsd.js',import.meta.url),'utf8');
 for(const [code,name] of DEPARTMENTS)
  assert.ok(source.includes("['"+code+"','"+name+"']"),'Missing Android department '+code);
 assert.equal(DEPARTMENTS.length,22);
});
test('invoice preflight normalizes known preferred names without guessing all multiword names',()=>{
 const a=invoice();a.invoice.primaryVendor='PRADCO OUTDOOR BRANDS';
 a.invoice.secondaryVendor='WORLDWIDE DISTRIBUTORS';
 a.invoice.department='';
 a.items=[{upc:'012345678901',description:'FISHING LURE',orderMultiple:1,caseCost:7.10,retailMethod:'MARKUP',markup:65}];
 const review=prepareReview(a);
 assert.equal(review.invoice.primaryVendor,'PRADCO');
 assert.equal(review.invoice.secondaryVendor,'WWD');
 assert.equal(review.missingDepartmentCount,1);
 assert.equal(review.items[0].suggestedDepartment,'72');
 assert.equal(review.batch.invoice.primaryVendor,'PRADCO');
 assert.throws(()=>requireMissingDepartmentAcknowledgment(review.batch),/Department missing/);
 review.batch.invoice.department='72';
 assert.doesNotThrow(()=>requireMissingDepartmentAcknowledgment(review.batch));
 review.batch.invoice.department='';
 review.batch.missingDepartmentsAcknowledged=true;
 assert.doesNotThrow(()=>requireMissingDepartmentAcknowledgment(review.batch));
});
test('queue requires missing-department confirmation without breaking mixed department invoices',async()=>{
 const h=dbHarness();try{
  const a=invoice();a.invoice.department='';
  await assert.rejects(h.queue.submit('github:111',a),/Department missing/);
  a.missingDepartmentsAcknowledged=true;
  const staged=await h.queue.submit('github:111',a);
  assert.equal(staged.itemCount,1);
  const b=invoice();b.invoice.department='';
  b.items[0].department='72';
  assert.equal((await h.queue.submit('github:111',b)).itemCount,1);
 }finally{h.database.close()}
});
test('MCP review widget provides accessible interactive import controls',()=>{
 assert.match(REVIEW_UI_HTML,/ui\/notifications\/tool-result/);
 assert.match(REVIEW_UI_HTML,/tools\/call/);
 assert.match(REVIEW_UI_HTML,/submit_dsd_import/);
 assert.match(REVIEW_UI_HTML,/I approve|Proceed with any departments still missing/);
 assert.match(REVIEW_UI_HTML,/aria-label/);
});

test('preflight resolves WorldWide Distributors alias before WWD conflict detection',()=>{
 const x=invoice();
 x.sourceFilename='Pradco WWD 7452875.pdf';
 x.invoice.primaryVendor='PRADCO OUTDOOR BRANDS';
 x.invoice.secondaryVendor='Worldwide Distributors';
 const review=prepareReview(x);
 assert.equal(review.invoice.primaryVendor,'PRADCO');
 assert.equal(review.invoice.secondaryVendor,'WWD');
 assert.equal(review.batch.invoice.secondaryVendor,'WWD');
});
