/** DOM/bridge behavior; hosted ChatGPT rendering remains a separate verification. */
import test from 'node:test';
import assert from 'node:assert/strict';
import {JSDOM} from 'jsdom';
import {REVIEW_UI_HTML} from '../src/review-ui.mjs';
import {prepareReview,validateResearch} from '../src/review-policy.mjs';
const proof='test-component-only-proof-not-an-oauth-token';
function result(unresolved=false,serial=false){
 const review=prepareReview({invoice:{primaryVendor:'PRADCO',invoiceNumber:'114774552',department:'72',defaultMarkup:65,defaultRetailMethod:'MARKUP'},items:[{upc:'657139063378',description:'<img src=x onerror=1>',originalDescription:'<img src=x onerror=alert(1)> Sexxy Shad 4 inch',mfg:'WESFS419',caseCost:7.10,serialNumber:serial?'TEST123':''}]});
 review.research=validateResearch([{itemIndexes:[0],query:'War Eagle WESFS419',productName:'Sonar Flash Spoon 4 inch',status:unresolved?'unavailable':'identified',sources:unresolved?[]:['https://example.com/sonar-spoon'],notes:unresolved?'Search unavailable in this test.':'Exact variant report test fixture.'}],1);
 return {structuredContent:{...review,reviewId:'dd4525aa-b828-4f71-906d-d8e5f34eec9'},_meta:{approvalProof:proof}};
}
const pause=()=>new Promise(resolve=>setTimeout(resolve,60));
async function widget(output,behavior={}){
 const calls=[],errors=[];let fail=behavior.failSubmit;
 const dom=new JSDOM(REVIEW_UI_HTML,{runScripts:'dangerously',pretendToBeVisual:true,url:'https://widget.example.com/',beforeParse(w){w.structuredClone=structuredClone;const timer=w.setTimeout.bind(w);w.setTimeout=(fn,delay)=>timer(fn,delay===15000?30:delay);w.addEventListener('error',e=>errors.push(e.message));w.postMessage=m=>{
 if(!m.id)return;calls.push(m);
 if(m.method==='ui/initialize'){respond({protocolVersion:'2026-01-26'});return}
 if(m.params?.name==='record_dsd_review_rendered'){if(!behavior.dropRender)respond({structuredContent:behavior.restore||{uiRendered:true}});return}
 if(m.params?.name==='submit_dsd_import'){if(fail){fail=false;respond({isError:true,structuredContent:{submitted:null},content:[{type:'text',text:'Submission receipt unconfirmed. Retry the exact choices.'}]})}else respond({structuredContent:{id:'test-batch',state:'pending'}})}
 function respond(r){queueMicrotask(()=>w.dispatchEvent(new w.MessageEvent('message',{source:w,data:{jsonrpc:'2.0',id:m.id,result:r}})))}}
 }});
 await pause();dom.window.dispatchEvent(new dom.window.MessageEvent('message',{source:dom.window,data:{jsonrpc:'2.0',method:'ui/notifications/tool-result',params:output}}));await pause();return {dom,w:dom.window,d:dom.window.document,calls,errors,close(){dom.window.close()}};
}
test('standard handshake renders facts and links; invoice text cannot inject HTML',async()=>{const h=await widget(result());try{assert.equal(h.calls[0].method,'ui/initialize');assert.equal(h.calls[0].params.protocolVersion,'2026-01-26');assert.equal(h.d.querySelectorAll('#items article').length,1);assert.equal(h.d.querySelectorAll('#items img').length,0);assert.match(h.d.getElementById('items').textContent,/657139063378.*WESFS419/);assert.equal(h.d.querySelector('#items a').href,'https://example.com/sonar-spoon');assert.ok(h.calls.some(x=>x.params?.name==='record_dsd_review_rendered'));assert.equal(h.d.getElementById('submit').disabled,false);assert.deepEqual(h.errors,[])}finally{h.close()}});
test('no auto-submit; button approval and retries preserve exact choices',async()=>{const h=await widget(result(),{failSubmit:true});try{assert.equal(h.calls.filter(x=>x.params?.name==='submit_dsd_import').length,0);h.d.getElementById('markup').value='70';h.d.getElementById('markup').dispatchEvent(new h.w.Event('input'));h.d.getElementById('submit').click();await pause();assert.match(h.d.getElementById('status').textContent,/unconfirmed/);assert.equal(h.d.getElementById('markup').disabled,true);h.d.getElementById('submit').click();await pause();const sent=h.calls.filter(x=>x.params?.name==='submit_dsd_import');assert.equal(sent.length,2);assert.deepEqual(sent[0].params.arguments,sent[1].params.arguments);assert.equal(sent[0].params.arguments.approvalProof,proof);assert.equal(sent[0].params.arguments.decisions.invoice.defaultMarkup,'70');assert.equal(sent[0].params.arguments.items,undefined);assert.match(h.d.getElementById('status').textContent,/Submitted/);assert.equal(h.d.getElementById('submit').disabled,true)}finally{h.close()}});
test('unresolved research requires acknowledgment',async()=>{const h=await widget(result(true));try{assert.equal(h.d.getElementById('submit').disabled,true);h.d.getElementById('researchAck').checked=true;h.d.getElementById('researchAck').dispatchEvent(new h.w.Event('change'));assert.equal(h.d.getElementById('submit').disabled,false)}finally{h.close()}});
test('missing proof or silent host never enables approval',async()=>{const output=result();delete output._meta.approvalProof;for(const [r,b] of [[output,{}],[result(),{dropRender:true}]]){const h=await widget(r,b);try{assert.equal(h.d.getElementById('submit').disabled,true);assert.match(h.d.getElementById('status').textContent,/unavailable|No response/)}finally{h.close()}}});
test('serial department stays fixed and invalid markup blocks approval',async()=>{const h=await widget(result(false,true));try{assert.equal(h.d.querySelector('#items select').value,'46');assert.equal(h.d.querySelector('#items select').disabled,true);h.d.getElementById('markup').value='';h.d.getElementById('markup').dispatchEvent(new h.w.Event('input'));assert.equal(h.d.getElementById('submit').disabled,true)}finally{h.close()}});

test('reopening an approved review restores choices and receipt without another submit',async()=>{const h=await widget(result(),{restore:{uiRendered:true,approvedChoices:{invoice:{department:'72',defaultRetailMethod:'MARKUP',defaultMarkup:70},itemDepartments:['72']},receipt:{id:'already-submitted'}}});try{assert.equal(h.d.getElementById('markup').value,'70');assert.equal(h.d.getElementById('submit').disabled,true);assert.match(h.d.getElementById('status').textContent,/Submitted/);assert.equal(h.calls.filter(x=>x.params?.name==='submit_dsd_import').length,0)}finally{h.close()}});
