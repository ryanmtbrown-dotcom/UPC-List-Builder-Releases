import {readWebRuntimeSource,findJsFunction} from './helpers/runtime-source-tree.mjs';
import fs from 'node:fs';
const src=readWebRuntimeSource();
const fieldExport=fs.readFileSync('app/src/main/assets/www/field-session/field-session-export-service.js','utf8');
const appShell=fs.readFileSync('app/src/main/assets/www/application/application-shell.js','utf8');
const lookupRouter=fs.readFileSync('app/src/main/assets/www/lookup/lookup-router.js','utf8');
const scannerRouter=fs.readFileSync('app/src/main/assets/www/scanner/scanner-workspace-router.js','utf8');
const runtimeResolver=fs.readFileSync('app/src/main/assets/www/misc/misc-runtime-resolver.js','utf8');
const dsdWorkspace=fs.readFileSync('app/src/main/assets/www/dsd/dsd-workspace-controller.js','utf8');
const workSessions=fs.readFileSync('app/src/main/assets/www/work-sessions/work-session-controller.js','utf8');
const contract=fs.readFileSync('LIST_MANAGEMENT_CONTRACT.md','utf8');
function must(v,m){if(!v)throw new Error(m)}
const stripOwnership=source=>source.replace(/^\/\*\*?[\s\S]*?\*\/\s*/,'');
for(const needle of [
  "function savedListPurpose(x)",
  "return purpose||'Field Session'",
  "if(x?.sessionType===miscType)return 'ACE New Items MISC.'",
  '<strong>${esc(purpose)}</strong>',
  'formatAlaskaCreated(x.createdAt||x.updatedAt)',
  "function displayName(x)",
  "dsdListName(x.dsdInvoice)",
  "x.sessionType===dsdType?'':formatAlaskaCreated(x.createdAt||x.updatedAt)"
]) if(!workSessions.includes(needle)) throw new Error(`Purpose-first list presentation missing: ${needle}`);
if(!contract.includes('purpose is more important than the creation date')) throw new Error('Authorized list amendment missing');

const aceMiscManual=findJsFunction('performAceMiscLookup');
const aceMiscResolver=findJsFunction('resolveAceMiscSkuCandidate');
const aceMiscBulk=findJsFunction('processAceMiscBulkSku');
must(aceMiscManual.includes("resolveProvider('ACE_MISC_MANUAL')(key,{relationshipSource:'ACENET_MISC_MANUAL'})"),'ACE MISC manual SKU lookup must use the injected exported-resolver provider');must(!/\bresolveAceMiscSkuCandidate\s*\(/.test(aceMiscManual),'Global ACE MISC manual lookup must not call the block-scoped resolver directly');
must(aceMiscManual.includes('lookupItem(key,options)'),'ACE MISC UPC lookup must use normal Master/Local resolution before SKU handoff');
must(aceMiscManual.includes('masterFirst:true')&&aceMiscManual.includes('localSecond:true')&&aceMiscManual.includes('localLibraryWriteAllowed:true'),'ACE MISC diagnostics must disclose Master -> Local -> AceNet authority and durable Local writes');
must(lookupRouter.includes("sessionType===miscType")&&lookupRouter.includes('miscWorkspaceProvider().performLookup(value,options)'),'ACE MISC must branch to its dedicated workspace controller');
must(aceMiscResolver.includes('UPCEffectiveCatalogResolver.inspectSKU(key)'),'ACE MISC resolver must inspect Master and Local through Effective Catalog.');
must(aceMiscResolver.indexOf('UPCEffectiveCatalogResolver.inspectSKU(key)')<aceMiscResolver.indexOf("requestAceNetCatalog(key,{misc:true})"),'Effective local catalog resolution must occur before AceNet catalog fallback.');
must(aceMiscResolver.includes("return{status:'AMBIGUOUS'"),'Ambiguous library SKU must terminate without silent selection');
must(aceMiscResolver.includes('aceMiscFromLocalRecord'),'ACE MISC must be able to construct from durable Local Library');
must(aceMiscResolver.includes("aceMiscRefreshLibraryRecord(key,master.row,{libraryKind:'MASTER'"),'Official Master-backed ACE MISC must refresh through the shared full-catalog owner');
must(aceMiscResolver.includes("requestAceNetCatalog(key,{misc:true})"),'Master+Local miss must continue through exact-SKU MISC catalog retrieval');
must(aceMiscResolver.includes('persistVerifiedAceNetCatalogToLocalLibrary'),'AceNet-only ACE MISC success must persist into Local Library before success');
must(src.includes('ACEMisc.snapshotFromLibraryAndAceNet'),'Verified MISC results must merge live AceNet-owned fields onto the Master/Local baseline');
must(aceMiscBulk.includes("resolveProvider('ACE_MISC_BULK')(key,{relationshipSource:'ACENET_MISC_BULK'})"),'ACE MISC bulk and manual lookup must share the injected exported-resolver provider');must(!/\bresolveAceMiscSkuCandidate\s*\(/.test(aceMiscBulk),'Bulk ACE MISC must not call the block-scoped resolver directly');
must(src.includes('async function persistVerifiedAceNetCatalogToLocalLibrary'),'Shared Local Library persistence owner missing');must(runtimeResolver.includes('windowRef.UPCAceMiscResolver=exported'),'Explicit ACE MISC resolver export missing');must(appShell.includes('resolveProvider:miscRuntimeResolver.requireResolver'),'MISC workspace composition must route consumers through the focused resolver guard');

must(fieldExport.includes("storage.setItem(EXPORT_BASE_KEY,base)")&&fieldExport.includes("diag('export_base_cache_write_failed'"),'Export-name cache write must be non-fatal when storage quota is exhausted');
must(fieldExport.includes("nonFatal:true"),'Export-name cache failure diagnostics must explicitly identify the failure as non-fatal');
must(fieldExport.includes("previous||'Field Export'")&&fieldExport.includes("dateStamp()"),'Export naming must retain the established fallback when cached export-base storage is unavailable');
must(appShell.includes('registerPriceController.offerExport()'),'Field Session export must delegate to the register-review controller before optional export');
must(!appShell.includes('function workbookForRows(')&&!appShell.includes('function exportTaggedPackage('),'application shell must not own Field Session workbook/package mechanics');

must(src.includes("ACE_NEW_DSD_ITEMS"),'ACE New DSD Items session type must be wired into the application');
must(workSessions.includes('dsdWorkspaceProvider()?.startNew?.()')&&dsdWorkspace.includes('function startNew()'),'DSD must open its workspace-owned invoice setup before item entry');
must(scannerRouter.includes("currentScreen()==='dsdScreen'")&&scannerRouter.includes('dsdWorkspaceProvider().acceptScannedUpc'),'Scanner results must route directly into the DSD workspace without normal/AceNet lookup');
const dsd=fs.readFileSync('app/src/main/assets/www/ace-dsd.js','utf8');
const dsdExecutable=stripOwnership(dsd);
must(dsd.includes("['46','Firearms']"),'Myers department registry must include department 46 Firearms');
must(dsd.includes("['72','Sporting Goods']"),'Myers department registry must include department 72 Sporting Goods');
must(dsd.includes("['73','Automotive']"),'Myers department registry must include department 73 Automotive');
must(dsd.includes("['77','Notions and Miscellaneous']"),'Myers department registry must include department 77 Notions and Miscellaneous');
must(dsd.includes("return d+u.slice(-6)"),'DSD SKU must be Myers department plus last six UPC digits');
must(dsd.includes("DEFAULT_VENDOR='WWD 663'"),'DSD has a dedicated independent invoice vendor default');
must(dsd.includes("caseCost,item.orderMultiple"),'DSD unit cost must derive from case cost and order multiple');
must(dsd.includes("'299 MFG#'"),'DSD export must include manufacturer number column');
must(dsd.includes("const HEADERS=[")&&dsd.includes("'Gun#'"),'DSD exact A-S export headers must exist');
must(dsd.includes("headerFillColumns:yellow"),'DSD exporter must preserve specified yellow header fills');
must(!dsdExecutable.includes('AceNet')&&!dsdExecutable.includes('lookupItem(')&&!dsdExecutable.includes('lookupItemBySku('),'DSD workflow/export must not depend on AceNet or Master Library lookup');
must(dsd.includes("ACE New DSD Items ${manufacturer} ${safeInvoice}"),'DSD must use the dedicated space-separated manufacturer + invoice XLSX filename');
console.log('Open List purpose-first v1.90 presentation requirements PASS');
