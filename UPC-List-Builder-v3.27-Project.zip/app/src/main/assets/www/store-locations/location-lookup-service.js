/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/store-locations/location-lookup-service.js
 * Owner: Store Locations / indexed read-only product location facts.
 * Role: Compose accepted layout, current official source and last-known association for lookup.
 * Responsibility: Provide honest offline location evidence without touching price/catalog authority.
 * Does not own: Mutation, UI generations, scanner events, network or Work Session rows.
 * Side effects: Read-only IndexedDB requests through UPCLocationRepository.
 * Related code: lookup/item-presentation-controller.js, location-policy.js, location-repository.js.
 */
const UPCLocationLookupService=(()=>{
'use strict';
function create({repository,policy}={}){
 if(!repository||!policy)throw Error('Location lookup dependencies missing');
 // A planogram owns source-relative sections; the assigned aisle section list
 // names the physical bays in that display. The first source section maps to
 // the first reserved bay, the second to the second, and so on. Extra reserved
 // bays remain unclaimed by the source (until an approved physical audit).
 // If there are more source sections than reserved bays, do not invent a map.
 function mapAceSection(target,source,segmentId){
  const segments=Array.isArray(source?.sourceSegments)?source.sourceSegments:[];
  const segment=segments.find(x=>x.id===segmentId);
  if(segmentId==null)return;
  const ordinal=Number(segment?.ordinal);
  const assigned=Array.isArray(target.assignedSections)?target.assignedSections:[];
  const sourceBays=Number(source?.nominalFourFootSections)||segments.length;
  if(Number.isSafeInteger(ordinal)&&ordinal>=1&&ordinal<=segments.length&&ordinal<=sourceBays&&ordinal<=assigned.length&&String(assigned[ordinal-1]??'').trim()){
   target.resolvedSection=String(assigned[ordinal-1]).trim();
   delete target.unmappedSourceSegment;
  }else target.unmappedSourceSegment=Number.isSafeInteger(ordinal)&&ordinal>0?ordinal:String(segmentId).replace(/^SOURCE-/,'');
 }
 async function find({skuKey,upcKey}={}){
  const key=String(skuKey||'').trim(),upc=String(upcKey||'').trim();
  const facts=key?await repository.bySku(key):upc?await repository.byUpc(upc):{placements:[],sourceMembers:[],history:[]};
  const excluded=new Set((facts.sourceMembers||[]).filter(x=>x.notPlaced===true).map(x=>x.skuKey));
  const placements=[];
  // Resolve only SKUs actually found by indexed lookup; no full store scan per barcode.
  for(const place of (facts.placements||[]).slice(0,16)){
   if(place.skuKey&&key&&place.skuKey!==key)continue;
   if(place.origin==='ACE_IMPORT'&&excluded.has(place.skuKey))continue;
   const modular=await repository.getModular(place.modularId);
   if(!modular||modular.active===false)continue;
   const area=await repository.getArea(modular.areaId||modular.area?.id);
   if(!area||area.active===false)continue;
   const enriched={...place,areaName:area.kind==='AISLE'?'Aisle '+(area.aisle||area.id):area.name,
    modularName:modular.name,assignedSections:modular.physicalSectionIds||[]};
   if(area.kind==='AISLE')enriched.aisle=area.aisle||area.id;
   if(place.origin==='ACE_IMPORT'&&!place.physicalEvidence){
    const members=(facts.sourceMembers||[]).filter(x=>x.skuKey===place.skuKey);
    for(const member of members){
     const src=await repository.getSource(member.sourceId);
     if(!src?.current||src.modularId!==place.modularId)continue;
     const pos=(member.positions||[]).find(p=>p.sourceSegment===place.sourceSegment&&p.sourceRow===place.sourceRow&&p.sourceColumn===place.sourceColumn)||member.positions?.[0]||{};
     enriched.sourcePositionStatus=pos.sourcePositionStatus??enriched.sourcePositionStatus??null;
     enriched.sourcePositionNote=pos.sourcePositionNote??enriched.sourcePositionNote??null;
     const segmentId=enriched.sourceSegment??pos.sourceSegment;
     if(segmentId!=null){
      enriched.sourceSegment=segmentId;
      mapAceSection(enriched,src,segmentId);
     }
     break;
    }
   }
   placements.push(enriched);
  }
  placements.sort((a,b)=>(a.physicalEvidence===true?0:1)-(b.physicalEvidence===true?0:1)||(a.role==='HOME'?0:1)-(b.role==='HOME'?0:1));
  if(placements.length){
   const primary=placements[0];
   const expanded=policy.formatExpandedLocation({current:primary});
   return{kind:'CURRENT',headline:policy.formatCompactLocation({current:primary}),
    details:expanded,otherLocations:placements.slice(1).map(x=>policy.formatCompactLocation({current:x})),
    sourceDerived:primary.origin==='ACE_IMPORT'&&!primary.physicalEvidence,
    skuKey:key,modularId:primary.modularId};
  }
  for(const member of facts.sourceMembers||[]){
   const source=await repository.getSource(member.sourceId);
   if(!source||source.current!==true||!source.modularId)continue;
   const modular=await repository.getModular(source.modularId);
   if(!modular||modular.active===false)continue;
   const area=await repository.getArea(modular.areaId||modular.area?.id);
   if(!area||area.active===false)continue;
   if(member.notPlaced===true){
    return{kind:'EXPECTED_NOT_PLACED',headline:'No current location',details:'Previous Ace: '+(source.name||source.planogramId),otherLocations:[],skuKey:key,modularId:source.modularId};
   }
   const pos=member.positions?.[0]||{};
   const expected={skuKey:member.skuKey,modularId:source.modularId,origin:'ACE_IMPORT',role:'HOME',
    physicalEvidence:false,fixtureType:pos.fixtureType||'UNKNOWN',sourceSegment:pos.sourceSegment,
    sourceRow:pos.sourceRow,sourceColumn:pos.sourceColumn,fixtureZone:pos.fixtureZone,sourcePositionStatus:pos.sourcePositionStatus,sourcePositionNote:pos.sourcePositionNote,
    areaName:area.kind==='AISLE'?'Aisle '+(area.aisle||area.id):area.name,
    aisle:area.kind==='AISLE'?(area.aisle||area.id):null,
    modularName:modular.name,assignedSections:modular.physicalSectionIds||[]};
   mapAceSection(expected,source,pos.sourceSegment);

   return{kind:'CURRENT',headline:policy.formatCompactLocation({current:expected}),details:'',
    otherLocations:[],sourceDerived:true,skuKey:key,modularId:source.modularId};
  }
  const historic=(facts.history||[]).filter(x=>['LAST_KNOWN_ACE','LAST_KNOWN_STORE_ADDED'].includes(x.kind));
  if(historic.length){
   historic.sort((a,b)=>(Number(b.updatedAt)||0)-(Number(a.updatedAt)||0));
   const first=historic[0],extras=historic.slice(1).map(x=>x.kind==='LAST_KNOWN_ACE'?'Earlier Ace planogram: '+(x.sourceName||x.sourceId||'Unknown'):'Earlier store-added display: '+(x.areaName||x.areaId||'Unknown'));
   return{kind:'HISTORICAL',headline:'No current location',
    details:first.kind==='LAST_KNOWN_ACE'?'Last known Ace planogram: '+(first.sourceName||first.sourceId||'Unknown')
     :'Last known store-added layout: '+(first.areaName||first.areaId||'Unknown'),
    otherLocations:extras,sourceDerived:false,skuKey:key,modularId:first.modularId||null};
  }
  return{kind:'UNKNOWN',headline:'No location',details:'',otherLocations:[],sourceDerived:false,skuKey:key,modularId:null};
 }
 return Object.freeze({find});
}
return Object.freeze({create});
})();
