# Diagnostic Export Contract

> **REQUIRED REFERENCE RULE:** Read `DIAGNOSTICS_CONTRACT.md`, `AI_START_HERE.md`, and `CURRENT_ARCHITECTURE_AUTHORITY.md` before changing diagnostic export.

**STATUS: CURRENT**

## Purpose

Produce a non-destructive JSON snapshot that can reconstruct current structured diagnostic evidence across web and native journals.

## Required payload

The export includes:

- `diagnosticSchemaVersion: 2`;
- current release/build identity;
- export/generation timestamp;
- current application/runtime summary;
- current startup-session identity/invariant;
- diagnostic mode/retention status;
- retained web `events`;
- raw/canonical native diagnostic journal;
- one chronological merged `timeline`;
- journal coverage counts;
- `operationSummary` with operations, spans, and `unfinishedSpans`;
- relevant startup/navigation/scanner/runtime/connectivity summaries.

Legacy native rows may be normalized for merged ordering, but original native journal evidence remains available in the payload.

Sorting uses timestamps and sequence evidence where available.

An unfinished span means a START was retained without a terminal phase. Export reports that fact and does not infer success/failure.

## Filename and delivery

On Android the default download is a standard `.zip` archive with one `.json` entry containing the complete schema-v2 snapshot. The ZIP is compressed incrementally on the native background writer while acknowledged JSON chunks arrive; no second whole-file payload is assembled. ZIP finalization must complete before Downloads publication and a saved acknowledgment. A legacy native `.json` request remains accepted. The browser fallback continues to download ordinary `.json`, since the browser does not own the native ZIP writer.


The filename includes the current app version and export timestamp.

Native Android diagnostic export uses bounded incremental JSON serialization and an acknowledged JavaScript→Android chunk protocol. A single active transfer is permitted. The native owner writes chunks on a dedicated background worker to a pending Downloads entry, with a size ceiling, timeouts, cleanup on interruption, and an explicit terminal saved acknowledgment. A JSON snapshot is not recorded as successfully exported merely because preparation finished. Browser Blob download remains a fallback and yields between chunks.

Additional DEBUG/TRACE export-phase and sparse per-256-chunk progress observations are recorded only in Deep Diagnostic Mode. Events emitted while exporting appear in a subsequent snapshot, not retroactively inside the already-frozen current one.

The Diagnostics overlay shows a bounded preview instead of materializing the entire log as a second multi-megabyte string. Oversized clipboard copies request a full download rather than risking a crash.

Diagnostic export is intentionally specialized and is not replaced by the ordinary standard file-export adapter because it owns diagnostic/native reconstruction semantics and the dedicated native diagnostic export capability.

## Non-destructive rule

Creating, displaying, copying, or downloading an export must not:

- clear diagnostic history;
- mutate business state;
- alter retention policy;
- change application lifecycle or AceNet behavior.

Export preparation/transfer/completion is itself diagnosed with operation evidence including platform, filename, event counts, timing, and startup-session context. The operation is marked PASS only after native confirmation of successful publication.

## Ownership

`diagnostics/diagnostic-export-service.js` owns snapshot assembly, web/native merge, operation reconstruction, and export handoff.

It does not own subsystem event meaning, business behavior, Android filesystem implementation, or diagnostic retention.

## Verification

Maintained tests must prove:

- schema-v2 fields are present;
- native/web evidence is retained and merged;
- unfinished spans are represented without fabricated completion;
- filename uses current release identity;
- export lifecycle diagnostics are emitted;
- no history-clearing side effect exists.

## Native diagnostic download failure recovery (v3.28)

On Android, an incomplete diagnostic-stream bridge must report an explicit failure instead of falling through to an unreliable WebView browser Blob download and claiming success. Native transfer preparation, periodic acknowledged chunk progress and the exact saved/failure result must be visible from Settings as well as the Diagnostics overlay. Web/native transfer uses bounded 24,000 UTF-16-character chunks within the established native 65,536-character ceiling, with 90-second inactivity timeout. Failure cleans up the pending transfer; native success is reported only after ZIP finalization and Downloads publication are acknowledged. Browser-only JSON fallback, canonical diagnostic content, diagnostic retention, camera scanning and business data remain unchanged.
