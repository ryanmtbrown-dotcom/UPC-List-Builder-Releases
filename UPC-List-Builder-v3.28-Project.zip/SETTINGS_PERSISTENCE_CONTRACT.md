# Settings and Preference Persistence Contract

> **REQUIRED REFERENCE RULE:** Read `AI_START_HERE.md`, `CURRENT_ARCHITECTURE_AUTHORITY.md`, and `ACENET_COMPARISON_TOGGLE_CONTRACT.md` before changing settings persistence.

**STATUS: CURRENT**

## Purpose

Keep durable preferences, per-list settings, running-session feature choices, runtime service state, and native credentials in their correct owners.

## Durable application settings

`UPCSettingsRepository` owns one durable ordinary-list export preference record in the approved settings/meta store.

It contains:
- the selected subset of the 30 supported Master Library fields;
- `forceAceMiscFormat`.

When no current preference exists, all 30 Master fields are selected and Force ACE MISC Format defaults ON. The Settings UI reads/writes both values atomically through the repository rather than raw storage. The immediately superseded header-only preference is bounded migration input; its selected Master-compatible headers are retained and the newly introduced Force option initializes ON. Obsolete display-only preference state is removed during current preference initialization.

The three ACE MISC-only columns `POSDEPT`, `VENDOR`, and `S/O (72) Y` are not individual checkboxes because they do not exist in the supported Master Library.

## Per-list settings

The active Work Session owns:

- `promptLabelPriceAfterScan`;
- `autoAddPriceDifference`.

Those values persist with that list through Work Session persistence.

Automatic price-difference adding cannot remain enabled when label-price prompting is disabled.

Price Change Work Sessions may independently persist optional `offlinePriceMode` and `offlinePriceChecks` through the existing Work Session service. The checkbox affects only that list's capture path and never changes global AceNet comparison or UPC enrichment settings. Explicit deferred validation may use those existing live capabilities.

## AceNet feature choices are session-only

AceNet Comparison Pricing and UPC Enrichment are running-session controls and are not written to localStorage or durable Settings persistence.

At the conclusive startup decision:

- authenticated + ONLINE initializes both ON;
- unavailable/offline initializes both OFF.

User changes then remain authoritative preference choices for the running process and reset on the next startup decision.

Comparison Pricing is the parent capability. When effective comparison is OFF, effective UPC Enrichment is OFF/unavailable even if its session preference remains remembered for later re-enablement.

Health remains operational evidence and informs startup defaults/status presentation, but it does not lock the controls after startup. A user may turn Comparison Pricing or UPC Enrichment preferences on or off regardless of the startup health result. Comparison remains the parent capability for effective enrichment.

## Runtime and credential boundaries

AceNet authentication/health state is runtime state, not a preference.

AceNet credentials are owned by the native encrypted credential service and are not stored by Settings Repository.

Settings Controller may invoke the explicit native credential-management bridge methods but does not own encryption/persistence.

## Diagnostics

Preference mutations identify owner, requested/effective value, dependency effects, and source/authority.

## Optional ChatGPT DSD connectivity

The opt-in enabled/disabled preference is a non-secret local application setting. No ChatGPT password, OAuth token, MCP device token, or API key may be persisted in browser localStorage or diagnostics. The Android build stores its paired-device token and HTTPS MCP origin via the dedicated Keystore-backed vault; browser fallback keeps the token in memory for the current session only. Disabling the feature stops import network access without removing saved DSD sessions or automatically discarding a paired credential. Disconnect revokes the remote device token before clearing local secure storage.

## Verification

Tests protect durable export preference ownership/defaults/migration, per-list isolation, dependent list-setting behavior, session-only AceNet feature choices, user-authoritative AceNet recovery controls, and credential/runtime separation.
