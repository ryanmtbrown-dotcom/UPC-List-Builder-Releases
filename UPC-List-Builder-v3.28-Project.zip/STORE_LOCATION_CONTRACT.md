# Store Location Contract — Builds 1 and 2

**Status:** Build 1 contract authority; implementation gated. **Scope:** one store, initially one device. **Parent:** UPC List Builder Two-Build Location Implementation Plan v4. **Source baseline:** `2ae0f2084b2b7de3931aa5d77f8f8b0d25718ce8`. **No runtime behavior is claimed by this document.**

## Core authority and provenance

The authoritative *current physical store layout* is one accepted layout per modular. Each modular may be associated with at most one *current official Ace source planogram*. Product-level factual last-known associations are permitted but are **not** current layouts or full planogram revision archives. Working audits in Build 2 are not accepted layouts until their changes are explicitly approved.

Keep three meanings separate in every storage record, API response, and screen:

1. `CURRENT_PLACEMENT`: merchandise currently assigned to a store area. `ACE_IMPORT` may seed a current layout **as a source-derived, not physically verified starting location**; `USER_SCAN` and `USER_EDIT` must be distinguished.
2. `OFFICIAL_SOURCE_MEMBER`: merchandise verified from the Ace Product Report belonging to a named source planogram. An imported source position is **not evidence that the product was physically located there**.
3. `LAST_KNOWN_ASSOCIATION`: compact factual product-level memory, including an original Ace planogram source association or an actual accepted store-added location. Preserve even after source replacement or deletion, but do not claim it is still current.

A local Ace product or DSD product deliberately added to a modular is `STORE_ADDED`, not an original member merely because it shares the modular. An item may possess genuine memberships in multiple sources over time; preserve a useful last-known factual reference without creating a complete old-planogram archive. Never automatically infer `DISCONTINUED`, overstock, clearance, reorder status, or actual inventory quantity from a location outcome.

## Physical area registry — reusable first

Every modular or display references **exactly one stable `PhysicalArea.id`** for its primary location. `PhysicalArea.kind` is `AISLE` or `CUSTOM`. Both kinds can be used by any modular. The user must be shown searchable existing custom areas *before* creating a new one. Creation is a deliberate step; show duplicate/near-duplicate candidates and obtain a user decision on genuine ambiguous matches. Normalized identical labels cannot create two active areas. Similarity is a suggestion, not permission to silently merge unrelated places.

A custom area has stable ID, canonical user-visible name, normalization key, active state, and optional user-confirmed alias. A rename changes labels, not IDs; accepted product placements and last-known references continue to resolve by stable IDs or preserved literal fallback when the area is deleted. In-use areas cannot be deleted/deactivated in a way that leaves silent orphaned placements; require deliberate reassignment/deactivation review. Examples: `Behind Counter` versus `Behind CTR` and `Front Registers` are candidates for review but not provably equal by their wording alone.

## Modular assignment and section exclusivity

An assigned modular references one physical area and a **set of real physical section IDs**, normally ordered left-to-right while facing the display. Section numbering is based on actual display position, not aisle entrance or Ace diagram numbering. Distinguish `physicalSectionIds` from `sourceSegmentIds`. A nominal 12-foot planogram may occupy two, three, or four actual sections. Import is permitted **unassigned** and must not assert a location until the employee assigns a real area and section span.

Two active modulars may occupy the same `(physicalAreaId, physicalSectionId)` **only when the employee deliberately confirms the exact intersecting physical sections after seeing the existing modular name**. Without exact, current confirmation, a conflict is rejected atomically with the existing holder identified. Store the confirmed counterpart modular ID and exact intersecting section IDs; changing a section range invalidates earlier confirmation. Never overwrite, displace, or assume the selected sections merely represent a count. Store section numbers as four-foot physical positions along the aisle face (e.g., Aisle 8 SEC 1–2 is 8 feet in the first two four-foot bays, not just an unspecified 8-foot display). Build 2 explicit audit against an occupied area may proceed as draft observation after warning, not as simultaneous accepted official assignment. Changing a modular from four sections to three must resolve placements on the removed fourth section before commit. A source segment/row/column cannot simply be cast into a physical section/row/column if an imported source is compressed or expanded.

## Current placement and source position honesty

`CurrentPlacement` must carry stable ID, modular ID, product identity with provenance, role (`HOME` or `SECONDARY`), origin (`ACE_IMPORT`, `USER_SCAN`, or `USER_EDIT`), assigned physical section **only if known**, optional fixture/row/column/zone/facings, source-link when applicable, and specific approved exception metadata if used. A placement is one merchandise group; multiple adjacent facings are **not** multiple labels or independent placements. The usual target is one HOME group per SKU in a modular. Distant repeated placements may be shown and reviewed instead of being silently removed. A seasonal endcap does not automatically approve every second SKU placed there.

The location renderer MUST distinguish `SRC SEC`, `PLANOGRAM ROW`, and Ace Product Report `ROW/COL` from physical `SEC`, `PEG R/C`, and `SHELF S/C`. `PEG R4 C5` means the fourth discernible hook row from top and fifth physical product group left-to-right, never the 4th pegboard hole or drawing pixel. `SHELF S4 C5` has comparable actual physical meaning. `SPCFIX` is allowed without imaginary row/column. Partial known positions remain useful: `SEC 1 · ROW 5`, `SEC 1 · POSITION —`, or assigned `SEC 1–2 · SRC SEC 3`, clearly labeled. No invented physical position from a 12-foot corporate drawing assigned to eight feet.

## Unplaced items and durable last-known references

Build 1 supports marking a source-listed SKU `NOT_IN_CURRENT_LAYOUT`, without deleting its `OFFICIAL_SOURCE_MEMBER` membership. If an official source is replaced and omits the SKU, stop reporting it as in the **current** official roster while retaining a bounded factual `LAST_KNOWN_ACE` association (source ID/code/name, optional documented source position). An explicit source deletion follows the same rule. Current real placements **never** disappear simply because their official reference changes.

A store-added product later removed from the accepted physical layout retains a `LAST_KNOWN_STORE_ADDED` association with the host area/modular and last **known accepted physical** position, when available. Never transform this into `LAST_KNOWN_ACE` unless an actual official Product Report establishes independent original source membership. For source members, `former physical location` is permitted **only** with evidence of an earlier accepted physical store position, not merely a corporate source position.

Truthful lookup examples:

- Placed, unverified import: `Aisle 5 · Tape · SEC 1–2` / `Ace source: SRC SEC 3 · ROW 4 (physical position unverified)`.
- Official current member omitted: `LOC — No current location` / `Current Ace planogram: Tape · SRC SEC 2` / `Not in current layout`.
- Former official member after replacement: `LOC — No current location` / `Last known Ace planogram: Tape` / `Original Ace source member`.
- Removed locally added DSD: `LOC — No current location` / `Last known store layout: Behind Counter` / `Store-added vendor merchandise, not an original Ace planogram member`.

## IndexedDB, backup, and transaction contracts

Read actual installed schema version at implementation; historic version 8 is not permission to assume the next version. `db.js` owns raw stores/indexes/upgrade, `store-locations/location-repository.js` owns domain CRUD and atomic acceptance, and policy modules own business classification. Location/index writes must not mutate Master/Local catalog authorities, `skuUpcs`, or SKU/UPC relationships. The current layout, active source roster, durable associations, custom-area registry, and import receipts are backed up together. A backup without the newly introduced location records **must not silently destroy** existing locations on restore; reject/require explicit safely explained action or preserve them with a documented atomic policy. Failed upgrade/restore/replace leaves old state intact.

Use indexed SKU reads primarily and validated UPC reads only with known identity provenance. Do not do a full-store scan for each barcode. Async lookup generation guards prevent old results appearing after a new scan. Location reads are local/offline, non-blocking, and do not affect verified AceNet/ASAP Level 2 pricing, Master fallback, NIF, Price Change, MISC, DSD, or export fields.

## Build boundaries and ownership

**Build 1:** establish pure location model, current source import association, reusable physical-area selection/creation, section assignment exclusivity, minimal source-member removal/restoration, compact lookup, durable historical associations, backup protection, and premium theme-matching management/detail UI.

**Build 2:** deliberate layout builder and scoped audit, scanned physical positions, approval of conflicting proposed changes, accepted store-added Ace/DSD placements, limited separated-duplicate review, existing Research workflow reuse. Preserve `YES`/`NO` semantics of existing duplicate-tag confirmation; NO discards repeated location observation including an already corrected duplicate while valid price work survives. No unrelated passive scanning or ordinary work-queue modernization in either build.

Each stage must obey `SOURCE_OWNERSHIP_MAP.md`, `REPOSITORY_BOUNDARIES_CONTRACT.md`, `ITEM_PRESENTATION_CONTRACT.md`, and current application contracts. New theme-fitting HTML/CSS must pass phone-width, dark theme, touch target, 200% text, keyboard, Back, overflow, screenshot, and accessibility checks. No GitHub push/deploy as a substitute for diagnosing and verifying a failed local change. No production migration, plugin permission change, publication, or APK release without separate authorization.

## Acceptance invariants

- Assigning `Aisle 5 · SEC 1–2` rejects a second active owner of `SEC 2` without explicit confirmation; after presenting the existing modular name and affected section and recording exact approval, allows deliberately shared physical space. A move to new overlapping sections requires new approval. Nonoverlapping assignments never prompt.
- `Behind Counter` registry rename does not break current and last-known locations; duplicate creation offers existing choices and guards exact duplicates.
- Build 1 may mark source SKU unplaced without losing its original official membership.
- A newer source omitting an old original member does not erase last-known Ace association; its previous source position is not mislabeled as former *physical* location.
- A locally added Ace or DSD item is never retrospectively declared original Ace source member.
- One SKU with four adjacent facings is one physical merchandise group and not automatically a second label.
- No source-to-physical row/column conversion without demonstrated mapping; source report ROW 52, COL 4 are source coordinates, not `PEG R52 C4`.
- A section-count reduction, source replacement, restore failure, or aborted audit cannot leave orphaned or partially replaced accepted placements.
- Location errors never block ordinary product/price lookup.

## Compact lookup clarification (v3.19)
- Aisle lookup identifies the area as `A17` (Aisle 17), never its registered section-range name. A modular's assigned sections represent the display footprint, not an individual SKU's physical position; do not show them as `S1–2–3` for an unscanned Ace source member.
- Product coordinates must be supported by a current official planogram import or an approved physical layout. Source-relative segment is `PS` and is never silently translated to a physical four-foot bay. Shelf-only type without source position is labeled as an unresolved Ace position, not represented as a complete location.
- Physical placement section/row/column information is shown only when it belongs to an accepted physical scan or correction. Do not manufacture a location from a display assignment or AI guess.

## Living-location authority and compact view (v3.08)
- Never withhold known source ROW/COL solely because an audit is unfinished. Official Ace positions are best-available current guidance until an employee approves an observed correction. The registered current store correction supersedes the Ace source. Approved absence supersedes source placement; source membership/history survives.
- Default lookup uses a one-line, non-scrolling premium data field labelled `LOC`, abbreviating A (aisle), S (four-foot bay), PS (source-only segment when physical bay correspondence is ambiguous), R (row), P (peg column), SH (shelf), SF (special fixture), and LFT/CL/CTR/CR/RGT for supported fixture zones. Preserve actual reported precision rather than falsely implying physical confirmation is mandatory.
- Saved active official planogram includes source nominal width, declared four-foot bay count and evidence. A newer import of the same Ace planogram updates source positions without erasing existing store modular assignment or employee-approved alterations.

## Build 2 observed-order lookup extension (v3.09 candidate)
- Accepted physical scans may persist `observedOrder` within a known row or shelf without claiming an exact physical hook column. Ordinary compact lookup may show `ORD3` (third observed merchandise group) when physical column is unknown; `ORD` is explicitly not `PEG P3` or an official Ace Product Report `COL 3`.
- Only a physically accepted source overrides the source-derived guidance. Unfinished observations have no authority and are recovered solely as draft data.
- Audits only classify not-observed merchandise inside explicitly completed physical sections; unresolved corporate source coordinates with no accepted physical section remain not verified.

## Build 2 custom-fixture and secondary-exception safeguards
- A modular with no numbered aisle bays is audited as the single selected custom-fixture scope. A transient audit-completion marker `FIXTURE` is not a real physical section and must never be stored on an accepted placement. Until the employee explicitly declares the whole fixture checked, unobserved merchandise remains not verified.
- Approved secondary placements bind to their actual SKU, stable placement identity, section, row and observed order. When those facts change, re-confirm the particular changed placement using the existing duplicate Yes/No dialog before atomic acceptance. A rejection leaves the accepted layout intact.

## Unified verification and task navigation (v3.18)
One accepted physical layout per saved modular remains the only current store placement authority. The guided scanner and visual Planogram Explorer must retain their distinct evidence collection methods and separate recoverable drafts. After an explicit completed confirmation, each records an evidence-typed event in the shared backed-up verification history under the existing meta store, keyed by modular ID: VISUAL_ACE_MATCH, VISUAL_STORE_LAYOUT, GUIDED_PHYSICAL_AUDIT, GUIDED_LAYOUT_BUILD or GUIDED_LAYOUT_CORRECTION. Each event references the exact Ace source revision and accepted physical layout fingerprint and carries immutable comparison snapshots, inspected-section scope, observed count and completion status. Visual confirmation never changes a source-derived item into a physically scanned placement. A guided audit with no corrections may be explicitly completed only after its inspection scope is marked complete and it has genuine scans with no unresolved observations, using the existing stale-revision guarded repository operation. A partial physical audit may be saved as partial, never as an entire display verified.
Both draft types remain independent, recoverable and clearly visible in one display-level dashboard. Older Explorer confirmations remain visible with an earlier-version qualification and without fabricated fresh proof. A confirmation whose Ace source or accepted layout subsequently changes remains history but is marked outdated for current status. View Differences can compare a confirmed guided scan layout or Explorer layout against the relevant saved Ace source snapshot; unchanged items are omitted.
Planograms & Locations groups store-area/physical assignments, guided scanning work, and official Ace planogram import/assignment in three named tabs. Field Session View Planogram and the main-menu Explorer shortcut open the same Explorer. Physical assignment actions from either audit navigate to the same location record; Ace source assignment remains a separate explicit action and does not happen automatically when a physical layout is built. All navigation and history inspection is read-only.

## Planogram item review tagging
The five visible tags (NIF, Price Change, General Review, Missing Label, Duplicate Item) must be individually selectable for any displayed merchandise even when a physical correction draft is not currently editable. No item is added to a Field Session just by viewing a planogram or selecting a tag. A clearly labeled **Add to Tag List** action explicitly hands selected tags and actual known UPC to the existing Work Session service and requires confirmation before a new tag list is first created. Existing same-UPC records are updated rather than duplicated; never fabricate an UPC, a label price, or verified live retail. The tag handoff never confirms, deletes, or overwrites planograms.

## Current Planogram Explorer confirmation and read-only differences
A Planogram Explorer edit never overwrites an Ace source or immediately overwrites the current physical layout. One quietly auto-saved draft per modular records viewed items, focus, Insert Before/After, Delete, Edit, and review tags. Confirmation is a whole-display user action accessed from the rightmost lookup settings gear and uses the existing source-signature/accepted-layout fingerprint guarded atomic repository write. Draft confirmation must preserve the last accepted arrangement until write success.
The gear opens viewport-contained Settings; action editing uses visible, mutually exclusive viewport-contained dialogs; NIF, Price Change, General Review, Missing Label and Duplicate Item remain directly visible. The user must never scroll to the bottom of the product card to locate a just-opened action.
Read-only View Differences is also available from Settings, occupying the full screen and selecting among confirmed planograms. It compares the confirmed store arrangement against the official Ace version used for confirmation, lists only truly inserted, deleted and changed placements, and excludes unchanged entries. Repeated SKU placements must be matched by stable source position or compatible evidence before inferring additional placements. An insertion alone must not label every subsequent item as moved. Missing historical evidence must be disclosed, not synthesized. No comparison action may modify source, accepted placements, draft data, tags or lists. Run real phone-width synthetic browser tests with actual Explorer controls before production release.

## v3.13 Planogram Explorer — normal lookup presentation correction
- Reuse the existing compact normal-item-lookup interaction and component vocabulary: the familiar two-button UPC/SKU mode toggle, numeric keypad, barcode scanner, small product image, both Level 2 prices, SKU, UPC, Order Multiple and Retail Units. Auto recognition is a background resolution policy, **not** a third dropdown option. Explicit UPC/SKU mode remains available.
- Scanning or typing the item identifier selects the matching position automatically; there is **no Jump to Position selector**. Browsing uses only compact red Previous and Next buttons with position count. The product card fits normal lookup density; no duplicate large Find Item or Current Display cards.
- An inline one-line display heading carries known aisle, display, certified footage and a compact Store/Ace source toggle. Source row/column remains marked unverified, with detailed import coordinates and guarded physical editing available behind a collapsed disclosure. Preserve the independent official source and accepted store-location rules.
- Reuse shared product image, current Level 2 library authority, and AceNet price checking without creating an alternate catalog. Not-located items use the same product card and can deliberately start a layout. Selecting the browsing activity creates no Work Session.

## v3.11 Planogram Explorer session entry
- **New Field Session > Field Session > Activity > View Planogram > Start Viewing** opens Planogram Explorer without requiring an item-list Work Session or saved list creation. View Planogram is not a List Type and never adds browse results to a merchandise list. No new location storage or scanner authority is introduced; the existing Explorer implementation remains the sole owner of browsing and confirmed physical corrections.

## v3.10 Planogram Explorer — browsing and direct correction
- Field Session and Planograms & Locations share one dedicated Explorer screen. Lookup inside Explorer does not add or modify a Work Session item. User-selected scans jump to a current display; multiple distinct displays require disambiguation.
- Official Ace positions are a separately labelled source-relative browse sequence, not verified physical peg or shelf positions. Physical browsing uses existing accepted placement section/row/observed order; facing counts represent adjacent stock, not duplicate item steps. Unknown source position precision is displayed as uncertain, never fabricated.
- Previous/Next, explicit jump selection and read-only catalog details work from locally persisted state; ordinary traversal never calls AceNet or creates new SKU↔UPC relationships.
- Single-item changes preview exact before/after and affected row positions. The established atomic `approvePhysicalLayout` rejects stale accepted revisions, stale corporate source and unapproved moved secondary placements. Delete means remove the one current physical placement, never delete product catalog/Ace source membership. Undo is limited to the last Explorer transaction with the same stale guards.
- Scan not found offers existing display or new aisle/custom-fixture creation. Reuse the existing location registry and guided Build Layout draft, carry initial scanned SKU/UPC forward, require explicit review/acceptance and refuse to discard an unfinished working layout. Never silently override another active owner of the physical section.
- Explorer is theme-consistent, accessible, phone-first with Back/history support. v3.09 remains the rollback reference until separately authorized publication of v3.10.

## Physical aisle registry and compact assigned planogram browsing (v3.19)
- One permanent aisle identity holds its explicit total number of four-foot sections independently of any particular planogram. Assignments reserve ordered subsequences of those sections for physical overlap detection. A planogram may be shorter than reserved occupancy without failure.
- Ordinal Ace source sections map to corresponding assigned physical aisle sections up to the shorter count. Additional reserved bays do not generate Ace merchandise positions. Remaining Ace source sections without a reserved aisle bay stay source-relative (PSn) pending physical confirmation.
- Layout selectors reveal one aisle and its selected display at a time. The selected details card owns editing and audit navigation; repetitive always-open status or display cards are prohibited. Changing aisle capacity or names must preserve existing IDs, display/source associations, item placements, and verification drafts; reject orphaning edits.

## Current physical section registry and removals (v3.24)
Aisle creation does not establish an immutable maximum length. Backed-up `sectionIds` may be created as 1–N and later extended by numeric ranges. Existing legacy sectionCount and modular footprints are included when the first explicit registry is saved. New modulars use created, consecutive four-foot sections. Available sections appear by default. A single deliberate overlap checkbox exposes occupied sections, with the named-holder preview and exact current overlap evidence guarding approval. Removing an unused section is atomic and rejects any active or inactive modular that still occupies it. Removing a modular requires explicit confirmation, atomically clears its current placements, preserves supported factual last-known store-added history, and unassigns rather than deleting its official Ace source, source membership or import receipts. Unfinished physical or visual work must be completed or discarded first. An aisle or custom area may be deleted only after all modular references (including inactive records) are removed or relocated, and only after explicit confirmation. Existing stable IDs survive edits.

## Physical aisle-face migration and section-only setup (v3.28)

A saved aisle has an optional `side` of `UNSPECIFIED`, `LEFT`, or `RIGHT`. Existing aisle IDs and existing saved assignments without `side` remain exactly intact and display as Unspecified. New Left/Right faces are separately identified records (for example `aisle-7-left`, `aisle-7-right`) with independent numbered four-foot section registries and occupancy. No automatic migration rewrites old modulars or source-to-placement data; occupied legacy aisles cannot be silently reclassified to a side. The compact location format uses A7L or A7R when side is recorded and A7 for legacy unknown side.

The Store Locations task only creates or changes an aisle face and its empty four-foot sections. It never automatically creates a modular or links an imported planogram. A new source placement is selected from Ace Planograms. The caller supplies a saved aisle face, a consecutive empty section range and a short modular name, and the location repository atomically creates that modular and links the source. Existing legacy display edits and explicit existing-source linking remain available. Official Ace source positions are never promoted into employee-confirmed physical hook evidence.
