/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/field-session/offline-price-check-controller.js
 * Owner: Field Session / Offline Price Check
 * Role: Offline observation capture and deferred price verification.
 * Responsibility: Save UPC, SKU and shelf-label observations without lookup; later compare exact-SKU Level 2 evidence and submit confirmed differences to the current Work Session.
 * Does not own: Scanner acquisition, AceNet extraction, catalog/identity mutation, register review or workbook export.
 * Side effects: Work Session persistence and explicit user-requested AceNet/local read-only queries.
 * Related code: lookup/lookup-router.js, pricing/price-authority.js, field-session/register-price-controller.js.
 */
const UPCOfflinePriceCheckController=(()=>{
 'use strict';
 function create({elementById,getCurrent,saveCurrent,normalizeSku,normalizeUpc,newId,localResolver,itemMapper,priceService,requestUpcs,relationships,diagnostic}={}){
  if(typeof elementById!=='function'||typeof getCurrent!=='function'||typeof saveCurrent!=='function'||typeof normalizeSku!=='function'||typeof normalizeUpc!=='function'||typeof newId!=='function'||!localResolver||!itemMapper||!priceService||typeof requestUpcs!=='function'||!relationships)throw Error('Offline Price Check dependencies missing');
  const $=elementById,diag=typeof diagnostic==='function'?diagnostic:()=>{};
  let capturing='',observedUpc='',step='sku',sku='',digits='',busy=false,validating=false;
  const applicable=()=>{const s=getCurrent();return s?.sessionType==='FIELD_SESSION'&&s.defaultTag==='Price Change'};
  const enabled=()=>applicable()&&getCurrent().offlinePriceMode===true;
  const rows=()=>Array.isArray(getCurrent()?.offlinePriceChecks)?getCurrent().offlinePriceChecks:[];
  const setText=(id,value)=>{if($(id))$(id).textContent=String(value)};
  const money=number=>'$'+Number(number).toFixed(2);
  function status(){
   const all=rows(),pending=all.filter(x=>x.status==='PENDING'||x.status==='REVIEW').length;
   setText('offlinePriceStatus',applicable()?all.length+' captured · '+pending+' pending/review · '+all.filter(x=>x.status==='ADDED').length+' differences · '+all.filter(x=>x.status==='MATCH').length+' matches':'Available for Price Change lists only.');
   if($('listOfflineMode')){$('listOfflineMode').checked=enabled();$('listOfflineMode').disabled=!applicable()||validating}
   if($('validateOfflinePriceChecks'))$('validateOfflinePriceChecks').disabled=!applicable()||validating||pending===0;
   const queue=$('offlinePriceQueue');
   if(queue&&queue.ownerDocument){queue.replaceChildren();
    for(const row of all.slice(-15).reverse()){
     const line=queue.ownerDocument.createElement('div');line.className='offlinePriceQueueItem';
     line.textContent='SKU '+row.sku+' · '+(row.scannedUpc||'UPC not scanned')+' · '+money(row.labelPrice)+' · '+String(row.status||'PENDING')+(row.reason?' · '+row.reason:'');
     queue.appendChild(line);
    }
   }
  }
  function render(){
   setText('offlinePriceStep',step==='sku'?'Step 1 of 2':'Step 2 of 2');
   setText('offlinePriceStage',step==='sku'?'Enter Ace SKU':'Enter shelf-label price');
   setText('offlinePriceIdentity',observedUpc?'Scanned UPC '+observedUpc:'Manual SKU');
   setText('offlinePriceValue',step==='sku'?(sku||'—'):money(Number(digits||'0')/100));
   setText('offlinePriceNext',step==='sku'?'Continue to Price':'Save & Next');
   $('offlinePriceBack')?.classList.toggle('hidden',step==='sku');
   $('offlinePriceNext').disabled=busy||(step==='sku'?!normalizeSku(sku):!digits);
  }
  function dismiss(){capturing='';busy=false;$('offlinePriceOverlay')?.classList.add('hidden')}
  function capture(value,{forceMode='UPC'}={}){
   if(!enabled())return false;
   if(capturing)return true;
   const typedSku=forceMode==='SKU';
   const upc=typedSku?'':normalizeUpc(value),enteredSku=typedSku?normalizeSku(value):'';
   if(!typedSku&&!upc){setText('status','Scan a valid UPC first.');return true}
   if(typedSku&&!enteredSku){setText('status','Enter a valid SKU first.');return true}
   capturing=getCurrent().id;observedUpc=upc;sku=enteredSku;digits='';step=enteredSku?'price':'sku';setText('offlinePriceError','');
   render();$('offlinePriceOverlay').classList.remove('hidden');
   diag('offline_price_capture_started',{listId:capturing,hasObservedUpc:!!upc});return true;
  }
  function keypad(value){
   if(!capturing||busy)return;
   let current=step==='sku'?sku:digits;
   if(value==='clear')current='';
   else if(value==='backspace')current=current.slice(0,-1);
   else if(/^[0-9]$/.test(value)&&current.length<(step==='sku'?16:9))current+=value;
   if(step==='sku')sku=current;else digits=current;
   setText('offlinePriceError','');render();
  }
  async function next(){
   if(!capturing||busy)return;
   const normalized=normalizeSku(sku);
   if(!normalized||!/^[0-9]+$/.test(normalized)){setText('offlinePriceError','Enter a numeric SKU.');return}
   if(step==='sku'){step='price';render();return}
   if(!digits){setText('offlinePriceError','Enter a label price.');return}
   const session=getCurrent();if(session?.id!==capturing||!enabled()){dismiss();return}
   const observation={id:newId(),sku:normalized,scannedUpc:observedUpc||null,labelPrice:Number(digits)/100,status:'PENDING',capturedAt:new Date().toISOString()};
   if(!Array.isArray(session.offlinePriceChecks))session.offlinePriceChecks=[];
   busy=true;render();session.offlinePriceChecks.push(observation);
   try{await saveCurrent();diag('offline_price_saved',{listId:session.id,observationId:observation.id});setText('status','Offline price saved. Scan the next item.');if($('upc'))$('upc').value='';dismiss();status()}
   catch(error){session.offlinePriceChecks=session.offlinePriceChecks.filter(x=>x!==observation);busy=false;setText('offlinePriceError','Save failed: '+(error?.message||error));render()}
  }
  async function evidence(sku,cache){
   if(!cache.has(sku))cache.set(sku,(async()=>{
    const resolved=await localResolver.resolveSKU(sku);
    const catalog=resolved?.status==='FOUND'?resolved.catalog:null;
    const local=catalog?.row?itemMapper.itemFromLibraryRow(catalog.row,{lookupMode:'OFFLINE_PRICE_CHECK',fallbackSku:sku,librarySource:catalog.provenance||'MASTER_LIBRARY',activeMasterRecordId:catalog.activeMasterRecordId}):null;
    let live;
    try{live=await priceService.requestPrice(sku,{upcEnrichment:false})}
    catch(error){live={status:'UNAVAILABLE'};diag('offline_price_live_unavailable',{sku,message:error?.message||String(error)})}
    const verified=live?.status==='VERIFIED'&&normalizeSku(live.sku)===sku&&Number.isFinite(live.price)&&live.price>=0;
    const item=local||{status:'FOUND',sku,upc:'',description:'',recordOrigin:'ACE_DERIVED',librarySource:'ACENET_VERIFIED',fields:{'ACE SKU':sku}};
    if(verified){item.aceNetPrice=Number(live.price).toFixed(2);item.aceNetPriceAuthority=UPCPriceAuthority.VERIFIED_ACENET_SOURCE;item.aceNetPriceStatus='VERIFIED'}
    let localUpcs=[];
    try{localUpcs=await relationships.getSkuUpcs(sku)}catch(error){diag('offline_price_saved_upcs_unavailable',{sku,message:error?.message||String(error)})}
    const known=(Array.isArray(localUpcs)?localUpcs:[]).map(row=>typeof row==='string'?row:(row?.upcKey??row?.upc));
    if(local?.upc)known.push(local.upc);
    let remote=[];
    if(verified)try{const response=await requestUpcs(sku);if(response?.status==='VERIFIED'&&normalizeSku(response.sku)===sku)remote=response.upcs||[]}catch(error){diag('offline_price_upcs_unavailable',{sku,message:error?.message||String(error)})}
    const currentUpcs=[...new Set(remote.map(normalizeUpc).filter(Boolean))],allUpcs=[...new Set([...currentUpcs,...known.map(normalizeUpc).filter(Boolean)])];
    return{item,verified,currentUpcs,allUpcs,masterLevel2:UPCPriceAuthority.level2(item.fields||{}),expected:UPCPriceAuthority.observedPrice(item)};
   })());
   try{return await cache.get(sku)}catch(error){cache.delete(sku);throw error}
  }
  async function compare(observation,cache){
   const sku=normalizeSku(observation.sku);
   if(!sku||!/^[0-9]+$/.test(sku))return{status:'REVIEW',reason:'Invalid SKU'};
   let info;try{info=await evidence(sku,cache)}catch(error){return{status:'PENDING',reason:'Lookup failed: '+(error?.message||error)}}
   const upc=normalizeUpc(observation.scannedUpc||'');
   if(upc){
    const link=await relationships.resolveUPC(upc);
    if(link.status==='CONFLICT'||link.status==='KNOWN'&&normalizeSku(link.sku)!==sku)return{status:'REVIEW',reason:'UPC and supplied SKU conflict'};
    if(info.currentUpcs.length&&!info.currentUpcs.includes(upc))return{status:'REVIEW',reason:'UPC absent from current verified AceNet set'};
    if(!info.allUpcs.includes(upc))return{status:'REVIEW',reason:'UPC not verified for this SKU'};
   }
   const outputUpc=upc||info.allUpcs[0]||'';
   if(!outputUpc)return{status:'REVIEW',reason:'No verified UPC for register scan'};
   if(info.expected==null)return{status:'PENDING',reason:'Level 2 Store Retail unavailable'};
   const label=Math.round(Number(observation.labelPrice)*100),reference=Math.round(info.expected*100);
   if(!Number.isSafeInteger(label)||label<0)return{status:'REVIEW',reason:'Invalid recorded label price'};
   if(label===reference)return{status:'MATCH',reason:'Label matches Level 2'};
   const item={...info.item,id:newId(),sku,upc:outputUpc,rawUPC:outputUpc,scannedUpc:upc||outputUpc,
    allUpcs:info.allUpcs,offlineObservationId:observation.id,
    labelPrice:label/100,libraryPrice:info.masterLevel2==null?null:Number(info.masterLevel2),
    priceDifference:(label-reference)/100,tags:['Price Change'],primaryPurpose:'Price Change',supplementalPurposes:[],
    addedAt:new Date().toISOString(),scannedAt:observation.capturedAt};
   return{status:'ADDED',reason:'Shelf label differs from Level 2',item};
  }
  async function validate(){
   if(validating||!applicable())return false;
   const session=getCurrent(),pending=rows().filter(x=>x.status==='PENDING'||x.status==='REVIEW');
   if(!pending.length)return false;
   validating=true;status();let added=0,matched=0,review=0;const cache=new Map();
   diag('offline_price_validation_started',{listId:session.id,count:pending.length});
   try{
    for(let index=0;index<pending.length;index++){
     if(getCurrent()?.id!==session.id)throw Error('Active list changed');
     const row=pending[index],before={...row},originalLength=session.items.length;
     setText('offlinePriceStatus','Validating '+(index+1)+' / '+pending.length+' · SKU '+row.sku);
     let result;try{result=await compare(row,cache)}catch(error){result={status:'PENDING',reason:'Error: '+(error?.message||error)}}
     if(getCurrent()?.id!==session.id)throw Error('Active list changed');
     if(result.status==='ADDED'&&session.items.some(x=>x.offlineObservationId===row.id))result={status:'ADDED',reason:'Already on Price Change list'};
     Object.assign(row,{status:result.status,reason:result.reason,validatedAt:new Date().toISOString()});
     if(result.status==='ADDED'&&result.item)session.items.push(result.item);
     try{await saveCurrent()}catch(error){Object.assign(row,before);if(before.reason===undefined)delete row.reason;if(before.validatedAt===undefined)delete row.validatedAt;session.items.splice(originalLength);throw Error('Could not save validation: '+(error?.message||error))}
     if(result.status==='ADDED')added++;else if(result.status==='MATCH')matched++;else review++;
     if($('itemCount'))$('itemCount').textContent=String(session.items.length);
    }
    setText('offlinePriceStatus','Complete · '+added+' price changes · '+matched+' matches · '+review+' needing review or retry.');
    diag('offline_price_validation_finished',{listId:session.id,added,matched,review});return true;
   }catch(error){setText('offlinePriceStatus','Stopped: '+(error?.message||error));diag('offline_price_validation_stopped',{message:error?.message||String(error)});return false}
   finally{validating=false;if($('listOfflineMode'))$('listOfflineMode').disabled=!applicable();if($('validateOfflinePriceChecks'))$('validateOfflinePriceChecks').disabled=!applicable()||!rows().some(x=>x.status==='PENDING'||x.status==='REVIEW')}
  }
  function bind(){
   $('offlinePriceKeypad').addEventListener('click',event=>{const key=event.target.closest('[data-offline-key]')?.dataset.offlineKey;if(key)keypad(key)});
   $('offlinePriceBack').addEventListener('click',()=>{if(!busy){step='sku';render()}});
   $('offlinePriceNext').addEventListener('click',()=>{void next()});
   $('offlinePriceCancel').addEventListener('click',()=>{if(!busy)dismiss()});
  }
  return Object.freeze({enabled,capture,validate,status,bind});
 }
 return Object.freeze({create});
})();
window.UPCOfflinePriceCheckController=UPCOfflinePriceCheckController;
