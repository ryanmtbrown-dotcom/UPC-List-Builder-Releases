/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/misc/misc-draft-model.js
 * Owner: ACE MISC Draft Domain
 * Role: Domain model
 * Responsibility: Owns canonical editable MISC draft transformations, user edits, verified UPC sets, snapshot application/detection, and export-readiness evaluation primitives.
 * Does not own: DOM, persistence, AceNet transport, or catalog writes.
 * Side effects: None beyond object construction/transformation.
 * Related code: Workspace and verification services consume this model; saved state persists through Work Session Service.
 */
const UPCMiscDraftModel=(()=>{
 function create({normalizeSku,normalizeUpc,parseMoney,newId,verificationStates,now=()=>new Date().toISOString()}={}){
  if(typeof normalizeSku!=='function'||typeof normalizeUpc!=='function'||typeof parseMoney!=='function'||typeof newId!=='function')throw new Error('MISC Draft Model dependencies are incomplete.');
  const states=verificationStates||{};
  function parseBulkSkus(raw){const found=String(raw??'').match(/\d+/g)||[],seen=new Set(),out=[];for(const value of found){const sku=normalizeSku(value);if(!sku||seen.has(sku))continue;seen.add(sku);out.push(sku)}return out}
  function bulkItemFromResolved(item,snapshot){const stamp=now(),source=snapshot?.source||'MASTER_LIBRARY_PLUS_ACENET_UPCS';return{...item,id:newId(),status:'FOUND',lookupStatus:'FOUND',upc:snapshot.orderedUpcs[0]||item.upc||'',rawUPC:snapshot.orderedUpcs[0]||item.rawUPC||'',addedAt:stamp,scannedAt:stamp,tags:[],primaryPurpose:null,supplementalPurposes:[],libraryPrice:parseMoney(item.price),aceNetPrice:null,labelPrice:null,priceDifference:null,aceMiscSnapshot:snapshot,aceMiscBulkSource:source}}
  function storedDraftUpcs(primaryUpc,refs=[]){const primary=normalizeUpc(primaryUpc),ordered=[...(refs||[]).filter(x=>x?.isMaster).map(x=>normalizeUpc(x.upcKey)),primary,...(refs||[]).filter(x=>!x?.isMaster).map(x=>normalizeUpc(x.upcKey))].filter(Boolean);return[...new Set(ordered)]}
  function decorateItem(item,snapshot,verification,aceNetStatus,aceNetPrice=null){const next={...item,aceMiscSnapshot:snapshot,aceMiscUpcVerification:verification,aceMiscAceNetStatus:aceNetStatus||null};if(aceNetPrice!==null&&aceNetPrice!==undefined&&String(aceNetPrice).trim()!==''){const parsed=parseMoney(aceNetPrice);if(parsed!==null&&parsed!==undefined&&Number.isFinite(Number(parsed))&&Number(parsed)>0){next.aceNetPrice=Number(parsed).toFixed(2);next.aceNetPriceAuthority='LEVEL2_STORE_RETAIL';}}return next}
  function verificationState(item){return String(item?.aceMiscUpcVerification||item?.aceMiscSnapshot?.upcVerification||'')}
  function verificationComplete(item){const state=verificationState(item);return state===states.VERIFIED_COMPLETE||state===states.VERIFIED_NO_ACENET_UPC_DATA||state===states.USER_CONFIRMED_COMPLETE}
  function applyResolutionToExistingItem(item,resolution){const fresh=resolution?.item;if(!item||!fresh)return false;const preserved={id:item.id,addedAt:item.addedAt,scannedAt:item.scannedAt,tags:item.tags,primaryPurpose:item.primaryPurpose,supplementalPurposes:item.supplementalPurposes,labelPrice:item.labelPrice,priceDifference:item.priceDifference};Object.assign(item,fresh);for(const [key,value] of Object.entries(preserved))if(value!==undefined)item[key]=value;return true}
  function applyUserConfirmedUpcs(item,upcs){const ordered=[...new Set((upcs||[]).map(normalizeUpc).filter(Boolean))];if(!item||!ordered.length)return false;const snapshot=item.aceMiscSnapshot;item.aceMiscSnapshot={...snapshot,version:2,orderedUpcs:ordered,upcVerification:states.USER_CONFIRMED_COMPLETE,capturedAt:now()};item.aceMiscUpcVerification=states.USER_CONFIRMED_COMPLETE;item.aceMiscAceNetStatus='NOT_FOUND_USER_CONFIRMED';item.upc=ordered[0];item.rawUPC=ordered[0];return true}
  function applyUserEdit(item,key,raw){
   if(!item||!key)return false;
   const value=String(raw??'').trim(),snapshot=item.aceMiscSnapshot,base=Array.isArray(snapshot?.baseRow)?[...snapshot.baseRow]:null;
   const writeBase=(index,next)=>{if(base)base[index]=next};
   if(key==='description'){item.description=value;writeBase(3,value)}
   else if(key==='sku'){const sku=normalizeSku(value);if(!sku)throw new Error('ACE MISC SKU must be numeric.');item.sku=sku;writeBase(0,sku)}
   else if(key==='upc'){const upc=normalizeUpc(value);if(!upc)throw new Error('ACE MISC UPC must be numeric.');const ordered=[upc,...(snapshot?.orderedUpcs||[]).map(normalizeUpc).filter(x=>x&&x!==upc)];item.upc=upc;item.rawUPC=upc;if(snapshot)item.aceMiscSnapshot={...snapshot,orderedUpcs:ordered,capturedAt:now()}}
   else if(key==='libraryPrice'){const price=value===''?null:parseMoney(value);if(value!==''&&price==null)throw new Error('Enter a valid Library Price.');item.libraryPrice=price;item.price=price;writeBase(16,price==null?'':Number(price).toFixed(2))}
   else if(key==='labelPrice'){const price=value===''?null:parseMoney(value);if(value!==''&&price==null)throw new Error('Enter a valid Label Price.');item.labelPrice=price}
   else if(key==='orderMultiple'){item.orderMultiple=value;writeBase(5,value)}
   else if(key==='retailUnits'){item.retailUnits=value;writeBase(6,value)}
   else return false;
   if(base)item.aceMiscSnapshot={...(item.aceMiscSnapshot||snapshot),baseRow:base,capturedAt:now()};
   const library=parseMoney(item.libraryPrice??item.price),label=parseMoney(item.labelPrice);item.priceDifference=(library!=null&&label!=null)?Math.round((label-library)*100)/100:null;
   return true;
  }

  function hasCanonicalSnapshot(item){const snapshot=item?.aceMiscSnapshot;return Array.isArray(snapshot?.baseRow)&&Array.isArray(snapshot?.orderedUpcs)&&snapshot.orderedUpcs.map(normalizeUpc).some(Boolean)}
  function exportReady(item){return verificationComplete(item)&&hasCanonicalSnapshot(item)}
  function applySnapshot(item,snapshot,{verification=null,aceNetStatus=null}={}){
   if(!item||!Array.isArray(snapshot?.baseRow)||!Array.isArray(snapshot?.orderedUpcs))return false;
   const ordered=[...new Set(snapshot.orderedUpcs.map(normalizeUpc).filter(Boolean))];if(!ordered.length)return false;
   item.aceMiscSnapshot={...snapshot,baseRow:[...snapshot.baseRow],orderedUpcs:ordered,capturedAt:now()};
   const state=verification||snapshot.upcVerification||item.aceMiscUpcVerification||null;if(state)item.aceMiscUpcVerification=state;
   if(aceNetStatus!==null)item.aceMiscAceNetStatus=aceNetStatus;
   item.upc=ordered[0];item.rawUPC=ordered[0];
   const base=item.aceMiscSnapshot.baseRow;
   if(normalizeSku(base[0]))item.sku=normalizeSku(base[0]);
   if(String(base[3]??'').trim())item.description=String(base[3]).trim();
   if(String(base[5]??'').trim())item.orderMultiple=String(base[5]).trim();
   if(String(base[6]??'').trim())item.retailUnits=String(base[6]).trim();
   return true;
  }
  return Object.freeze({parseBulkSkus,bulkItemFromResolved,storedDraftUpcs,decorateItem,verificationState,verificationComplete,hasCanonicalSnapshot,exportReady,applySnapshot,applyResolutionToExistingItem,applyUserConfirmedUpcs,applyUserEdit});
 }
 return Object.freeze({create});
})();
window.UPCMiscDraftModel=UPCMiscDraftModel;
