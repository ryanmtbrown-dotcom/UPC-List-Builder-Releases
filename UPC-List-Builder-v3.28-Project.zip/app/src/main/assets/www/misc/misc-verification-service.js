/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/misc/misc-verification-service.js
 * Owner: ACE MISC Verification
 * Role: Domain/workflow service
 * Responsibility: Owns MISC UPC completeness, retry/user-confirmation flow, canonical export-readiness checks, and verified retry persistence through Work Sessions.
 * Does not own: Raw persistence, UI layout, normal lookup, or native AceNet session/extraction.
 * Side effects: Calls injected resolver/prompt/WorkSession boundaries and persists only verified MISC session results.
 * Related code: Draft semantics belong to Misc Draft Model; UI action state belongs to Misc Workspace Controller.
 */
const UPCMiscVerificationService=(()=>{
 function create({draftModel,miscDomain,normalizeSku,normalizeUpc,resolveProvider,promptUser,messageUser,workSessionService,getCurrentSession,setCurrentSession,diagnostic}={}){
  if(!draftModel||!miscDomain||typeof normalizeSku!=='function'||typeof normalizeUpc!=='function'||typeof resolveProvider!=='function')throw new Error('MISC Verification Service resolution dependencies are incomplete.');
  if(typeof promptUser!=='function'||typeof messageUser!=='function'||!workSessionService||typeof getCurrentSession!=='function'||typeof setCurrentSession!=='function')throw new Error('MISC Verification Service persistence/UI dependencies are incomplete.');
  const ACEMisc=miscDomain,normalizeSKU=normalizeSku,normalizeUPC=normalizeUpc,diag=typeof diagnostic==='function'?diagnostic:()=>{};
  let retryRunning=false;
  function isRetryRunning(){return retryRunning}
  async function confirmAceMiscKnownUpcs(item){
   if(!item)return false;
   const sku=normalizeSKU(item.sku),snapshot=item.aceMiscSnapshot,existing=[...new Set((snapshot?.orderedUpcs||[]).map(normalizeUPC).filter(Boolean))];
   const answer=await promptUser(`AceNet reported SKU ${sku} was not found.\n\nEnter every additional UPC you know belongs to this item, separated by spaces or commas. If the UPCs already shown are the complete set, leave this box blank and choose OK. Choose Cancel if you cannot confirm the complete UPC set yet.\n\nCurrently known: ${existing.join(', ')||'none'}`,'','ACE MISC UPC Verification');
   if(answer===null)return false;
   const raw=String(answer||'').trim(),entered=[...new Set((raw.match(/\d{6,14}/g)||[]).map(normalizeUPC).filter(Boolean))];
   if(raw&&!entered.length){await messageUser('No valid 6–14 digit UPC was entered. UPC verification remains unresolved.','ACE MISC UPC Verification');return false}
   const all=[...new Set([...existing,...entered])];
   if(!all.length){await messageUser('There is no UPC available to confirm for this item.','ACE MISC UPC Verification');return false}
   draftModel.applyUserConfirmedUpcs(item,all);diag('ace_misc_user_confirmed_upc_set',{sku,upcCount:all.length,aceNetStatus:'NOT_FOUND',identityPersistence:false});return true;
  }
  async function verifyAceMiscExistingItem(item,{promptNotFound=false,forceRefresh=false,relationshipSource='ACENET_MISC_RETRY'}={}){
    const sku=normalizeSKU(item?.sku);if(!sku)return{status:'INVALID_SKU',complete:false};
    if(!forceRefresh&&draftModel.exportReady(item))return{status:'ALREADY_COMPLETE',complete:true};
    let resolution;
    try{resolution=await resolveProvider('ACE_MISC_VERIFY_EXISTING')(sku,{relationshipSource})}
    catch(e){
     // Preserve the saved UPC snapshot, but do not claim a successful current recheck.
     item.aceMiscUpcVerification=ACEMisc.UPC_VERIFICATION.PENDING_ACENET;
     item.aceMiscAceNetStatus='ERROR';
     diag('ace_misc_verification_retry_failed',{sku,message:e?.message||String(e),forceRefresh});
     return{status:'ERROR',complete:false,message:e?.message||String(e)};
    }
    if(resolution?.status==='FOUND'&&resolution.item&&draftModel.exportReady(resolution.item)){
     draftModel.applyResolutionToExistingItem(item,resolution);
     const state=draftModel.verificationState(item);
     return{status:state===ACEMisc.UPC_VERIFICATION.VERIFIED_NO_ACENET_UPC_DATA?'LIBRARY_UPC_FALLBACK':'VERIFIED_SELECTOR',complete:true};
    }
    if(resolution?.status==='NOT_FOUND'||resolution?.upcVerification===ACEMisc.UPC_VERIFICATION.NEEDS_USER_CONFIRMATION){
     item.aceMiscUpcVerification=ACEMisc.UPC_VERIFICATION.NEEDS_USER_CONFIRMATION;
     item.aceMiscAceNetStatus='NOT_FOUND';
     if(promptNotFound&&await confirmAceMiscKnownUpcs(item))return{status:'USER_CONFIRMED',complete:true};
     return{status:'NEEDS_USER_CONFIRMATION',complete:false};
    }
    item.aceMiscUpcVerification=ACEMisc.UPC_VERIFICATION.PENDING_ACENET;
    item.aceMiscAceNetStatus=resolution?.aceNetStatus||'PENDING_ACENET';
    return{status:resolution?.aceNetStatus||'PENDING_ACENET',complete:false};
   }
   async function retryPendingAceMiscVerification(list,{promptNotFound=false,includeComplete=false}={}){
    if(retryRunning||list?.sessionType!=='ACE_NEW_ITEMS_MISC')return{checked:0,completed:0,pending:0,full:0,fallback:0,failed:0,changed:0,level2:0,totalUpcs:0,details:[]};
    // Export-time recovery is pending-only. Explicit user verification rechecks every SKU.
    const candidates=(list.items||[]).filter(item=>includeComplete||!draftModel.exportReady(item));
    if(!candidates.length)return{checked:0,completed:0,pending:0,full:0,fallback:0,failed:0,changed:0,level2:0,totalUpcs:0,details:[]};
    retryRunning=true;
    const summary={checked:0,completed:0,pending:0,full:0,fallback:0,failed:0,changed:0,level2:0,totalUpcs:0,details:[]};
    const priceOf=item=>item?.aceNetPriceAuthority==='LEVEL2_STORE_RETAIL'?String(item.aceNetPrice??''):null;
    try{
     for(const item of candidates){
      const beforeUpcs=[...(item.aceMiscSnapshot?.orderedUpcs||[])],beforePrice=priceOf(item);
      const result=await verifyAceMiscExistingItem(item,{promptNotFound,forceRefresh:includeComplete,relationshipSource:includeComplete?'ACENET_MISC_EXPLICIT_RECHECK':'ACENET_MISC_PENDING_RETRY'});
      const afterUpcs=[...(item.aceMiscSnapshot?.orderedUpcs||[])],afterPrice=priceOf(item);
      const updated=beforeUpcs.join('|')!==afterUpcs.join('|')||beforePrice!==afterPrice;
      summary.checked++;
      if(result.complete)summary.completed++;else summary.failed++;
      if(result.status==='VERIFIED_SELECTOR')summary.full++;
      if(result.status==='LIBRARY_UPC_FALLBACK')summary.fallback++;
      if(updated)summary.changed++;
      if(afterPrice!==null)summary.level2++;
      summary.totalUpcs+=afterUpcs.length;
      summary.details.push({sku:normalizeSKU(item.sku),status:result.status,upcCount:afterUpcs.length,addedUpcs:afterUpcs.filter(upc=>!beforeUpcs.includes(upc)),updated,level2Verified:afterPrice!==null});
     }
     await workSessionService.save(list);
     if(getCurrentSession()?.id===list.id)setCurrentSession(list);
     summary.pending=(list.items||[]).filter(item=>!draftModel.exportReady(item)).length;
     diag('ace_misc_pending_verification_retry_complete',{listId:list.id,checked:summary.checked,completed:summary.completed,pending:summary.pending,full:summary.full,fallback:summary.fallback,failed:summary.failed,changed:summary.changed,level2:summary.level2,totalUpcs:summary.totalUpcs,promptNotFound,includeComplete});
     return summary;
    }finally{retryRunning=false}
   }
   async function ensureAceMiscExportReady(list){
   let pendingItems=(list?.items||[]).filter(item=>!draftModel.exportReady(item));if(!pendingItems.length)return true;
   await retryPendingAceMiscVerification(list,{promptNotFound:true});
   pendingItems=(list?.items||[]).filter(item=>!draftModel.exportReady(item));if(!pendingItems.length)return true;
   const skus=pendingItems.map(x=>normalizeSKU(x.sku)).filter(Boolean);
   throw new Error(`Complete UPC verification is still required for ${pendingItems.length} item${pendingItems.length===1?'':'s'}: SKU ${skus.join(', ')}. Reconnect AceNet or confirm the known UPC set for items AceNet reports as not found.`);
  }
  return Object.freeze({isRetryRunning,confirmAceMiscKnownUpcs,verifyAceMiscExistingItem,retryPendingAceMiscVerification,ensureAceMiscExportReady});
 }
 return Object.freeze({create});
})();
window.UPCMiscVerificationService=UPCMiscVerificationService;
