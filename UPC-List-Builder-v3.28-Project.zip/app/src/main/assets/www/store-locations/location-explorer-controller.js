/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/store-locations/location-explorer-controller.js
 * Owner: Store Locations / Planogram Explorer Presentation
 * Role: Workspace controller
 * Responsibility: Owns focused item browsing, explicit correction review, display choice and start-from-scan creation wizard.
 * Does not own: Product pricing authority, full layout drafts, raw location storage, scanner hardware or Work Sessions.
 * Side effects: Manipulates Explorer DOM, invokes injected domain services and established app navigation/scanner UI.
 * Related code: location-explorer-service.js, location-explorer-edit-service.js, location-work-controller.js.
 */
const UPCLocationExplorerController=(()=>{
 'use strict';
 function create({repository,read,edit,policy,elementById,documentRef,showScreen,goBack,startScanner,
  normalizeUPC,normalizeSKU,confirmUser,workController,idFactory,productImageService,priceService,comparisonEnabled,openIdentifierKeypad,drafts,differences,tagService,verification,onManageAssignment,tagNames=[]}={}){
  if(!repository||!read||!edit||!policy||!drafts||!differences||!tagService||!verification||!elementById||!documentRef||!showScreen||!goBack||!workController)throw Error('Explorer UI dependencies missing');
  const $=elementById,doc=documentRef;let model=null,index=0,identity=null,pending=null,undo=null,busy=false,token=0,insertScanning=false,manualMode='UPC',manualModeExplicit=false,draft=null,confirmation=null,localTagSelections=new Map();
  const el=(tag,className='',content='')=>{const e=doc.createElement(tag);if(className)e.className=className;if(content!=null)e.textContent=String(content);return e};
  const text=(id,value)=>{$(id).textContent=String(value??'')};
  // Highlight only an actual inclusive column range, not a location warning.
  // Build DOM text nodes instead of injecting location content as HTML.
  function locationSummary(value){
   const target=$('locationExplorerLocationSummary'),string=String(value??'');
   const range=/\bC[1-9]\d*:[1-9]\d*\b/g;let previous=0,match;
   target.replaceChildren();
   while((match=range.exec(string))){
    target.append(doc.createTextNode(string.slice(previous,match.index)));
    const strong=doc.createElement('span');strong.className='locationExplorerFacingRange';
    strong.textContent=match[0];target.append(strong);previous=range.lastIndex;
   }
   target.append(doc.createTextNode(string.slice(previous)));
  }
  const MODALS=['locationExplorerSettings','locationExplorerEditMenu','locationExplorerEdit','locationExplorerReview','locationExplorerDifferences'];
  function show(id,visible){
   $(id).classList.toggle('hidden',!visible);
   if(MODALS.includes(id)){
    const open=MODALS.some(name=>!$(name).classList.contains('hidden'));
    $('locationExplorerModalBackdrop').classList.toggle('hidden',!open);
    if(visible)$(id).focus?.({preventScroll:true});
   }
  }
  function closeModal(){
   for(const name of MODALS)show(name,false);
   pending=null;insertScanning=false;
  }
  const status=(message,kind='info')=>{text('locationExplorerStatus',message||'');$('locationExplorerStatus').dataset.kind=kind};
  function active(){return !$('locationExplorerScreen').classList.contains('hidden')}
  async function guard(fn){if(busy)return;busy=true;try{await fn()}catch(e){status(e?.message||String(e),'error')}finally{busy=false}}
  function resetViews(){$('locationExplorerScreen').classList.remove('has-display');show('locationExplorerSettings',false);show('locationExplorerDifferences',false);show('locationExplorerChoices',false);show('locationExplorerMissing',false);show('locationExplorerWizard',false);show('locationExplorerDisplay',false);show('locationExplorerEditMenu',false);show('locationExplorerEdit',false);show('locationExplorerReview',false)}
  function setLookupMode(kind,explicit=true){
   manualMode=kind==='SKU'?'SKU':'UPC';manualModeExplicit=explicit;
   doc.querySelectorAll('[data-explorer-lookup-mode]').forEach(button=>{
    const selected=button.dataset.explorerLookupMode===manualMode;button.classList.toggle('active',selected);button.setAttribute('aria-pressed',String(selected));
   });
   text('locationExplorerLookupLabel',manualMode);
   $('locationExplorerLookup').placeholder=manualMode==='SKU'?'Enter SKU':'Scan or enter UPC';
  }
  function openManualKeypad(){
   if(typeof openIdentifierKeypad!=='function')throw Error('Shared identifier keypad is unavailable');
   openIdentifierKeypad({title:'Enter '+manualMode,context:'Planogram lookup',value:$('locationExplorerLookup').value||'',maxLength:14,
    onAccept:async value=>{$('locationExplorerLookup').value=value;await guard(()=>search(value,manualModeExplicit?manualMode:'AUTO'))}});
  }
  async function open(){showScreen('locationExplorerScreen','Planogram Explorer');resetViews();model=null;draft=null;confirmation=null;pending=null;undo=null;identity=null;index=0;insertScanning=false;localTagSelections.clear();
   $('locationExplorerLookup').value='';setLookupMode('UPC',false);status('');}
  async function openDisplay(id){await open();await choose(id,null,null)}
  const current=()=>model?.items?.[index]||null;
  function locate(identity,rows){return rows.findIndex(p=>policy.same(p,identity))}
  const currency=value=>{const n=UPCPriceAuthority.money(value);return n===null?'—':'$'+n};
  function setImage(imageId,emptyId,url=null){
   const img=$(imageId),empty=$(emptyId);
   if(url){img.src=url;img.classList.remove('hidden');empty.classList.add('hidden')}
   else{img.removeAttribute('src');img.classList.add('hidden');empty.classList.remove('hidden')}
  }
  function enrich(details,imageId,emptyId,priceId,generation){
   const item=details?.product,valid=details?.catalogFound&&item?.status==='FOUND';
   setImage(imageId,emptyId);
   text(priceId,!valid?'—':typeof comparisonEnabled==='function'&&!comparisonEnabled()?'Disabled':'Checking…');
   if(!valid)return;
   if(productImageService?.lookupProductImage)void productImageService.lookupProductImage(item).then(result=>{
    if(generation!==token)return;
    const url=String(result?.url||'');
    if(url.startsWith('https://')||url.startsWith('data:image/')){setImage(imageId,emptyId,url);$(imageId).alt='Product image for '+details.description}
    else $(emptyId).textContent='Image unavailable';
   }).catch(()=>{if(generation===token)$(emptyId).textContent='Image unavailable'});
   if(typeof comparisonEnabled!=='function'||!comparisonEnabled()||!item.sku||!priceService?.requestPrice)return;
   void priceService.requestPrice(normalizeSKU(item.sku),{upcEnrichment:false}).then(result=>{
    if(generation!==token)return;
    const verified=result?.status==='VERIFIED'&&normalizeSKU(result.sku)===normalizeSKU(item.sku)&&Number.isFinite(result.price);
    text(priceId,verified?currency(result.price):'Unavailable');
   }).catch(()=>{if(generation===token)text(priceId,'Unavailable')});
  }
  async function lookupIdentity(value,type,format){
   if(type!=='AUTO')return read.resolveIdentity(value,type,format);
   try{return await read.resolveIdentity(value,'AUTO',format)}
   catch(error){
    if(!String(error?.message||'').includes('Auto could not confirm this identifier'))throw error;
    return read.resolveIdentity(value,manualMode,format);
   }
  }
  async function search(value,type='AUTO',format=null){
   const generation=++token;model=null;identity=await lookupIdentity(value,type,format);pending=null;undo=null;
   const choices=await read.candidates(identity);if(generation!==token)return;resetViews();
   if(!choices.length){
    const details=await read.details(identity);if(generation!==token)return;
    show('locationExplorerDisplay',true);show('locationExplorerMissing',true);
    show('locationExplorerContext',false);show('locationExplorerEvidence',false);
    show('locationExplorerLocation',false);show('locationExplorerNavigation',false);show('locationExplorerMore',false);
    $('locationExplorerScreen').classList.add('has-display');
    text('locationExplorerMissingItem',identity.skuKey?'SKU '+identity.skuKey:'UPC '+(identity.upcKey||'—'));
    text('locationExplorerItemName',details.description.toUpperCase());
    text('locationExplorerSku',details.sku);text('locationExplorerUpc',details.upc);
    text('locationExplorerRetail',currency(details.retail));text('locationExplorerOrderMultiple',details.orderMultiple??'—');
    text('locationExplorerRetailUnits',details.retailUnits??'—');
    $('locationExplorerImageEmpty').textContent='Image unavailable';
    enrich(details,'locationExplorerImage','locationExplorerImageEmpty','locationExplorerAceNetRetail',generation);
    status('');return;
   }
   if(choices.length===1){await choose(choices[0].modularId);return}
   const host=$('locationExplorerChoicesList');host.replaceChildren();
   for(const choice of choices){const button=el('button','locationExplorerChoice',choice.area+' · '+choice.name+' · '+(choice.physical?'Store-confirmed':'Ace source'));
    button.type='button';button.addEventListener('click',()=>void guard(()=>choose(choice.modularId)));host.append(button)}
   show('locationExplorerChoices',true);status('Multiple locations found. Choose the display.');
  }
  async function choose(modularId,mode=null,focusIdentity=identity){
    model=await read.display(modularId,mode);
    confirmation=await drafts.confirmed(modularId);
    const saved=await drafts.load(modularId);
    if(saved&&!drafts.isCurrent(saved,model)){
      draft=null;
      status('The Ace planogram or accepted store layout changed. Saved work is retained but cannot be applied until reviewed.','warning');
    }else{
      draft=saved||await drafts.save({...drafts.initial(model),tags:{...(confirmation?.tags||{})}});
      model.mode=mode||draft.mode||model.mode;
    }
    const items=displayed();
    const wanted=focusIdentity?locate(focusIdentity,items):-1;
    const resumed=focusIdentity==null?items.findIndex(p=>p.id===draft?.focusId):-1;
    index=wanted>=0?wanted:resumed>=0?resumed:Math.min(Math.max(0,Number(draft?.index)||0),Math.max(0,items.length-1));
    pending=null;resetViews();$('locationExplorerScreen').classList.add('has-display');
    for(const id of ['locationExplorerDisplay','locationExplorerContext','locationExplorerEvidence','locationExplorerLocation','locationExplorerNavigation'])show(id,true);
    await render();
   }
   function displayed(){return !model?[]:model.mode==='ACE'?model.ace:(draft?.items||model.store)}
   const identityKey=p=>policy.key(p)||p?.id||'';
   function locationText(p){
    if(!p)return 'No position recorded';
    const area=model.area.kind==='AISLE'?'A'+model.area.aisle:model.area.name;
    if(p.locationNote)return area+' · '+p.locationNote;
    const segments=model.source?.sourceSegments||[],sectionIds=model.modular.physicalSectionIds||[];
    const seg=segments.find(x=>String(x.id)===String(p.sourceSegment));
    const ordinal=Number(seg?.ordinal),sourceBays=Number(model.source?.nominalFourFootSections)||segments.length;
    const mapped=seg&&Number.isSafeInteger(ordinal)&&ordinal>0&&ordinal<=sourceBays?sectionIds[ordinal-1]:null;
    const section=p.physicalSectionId??mapped;
    const parts=[area];
    if(section!=null)parts.push('S'+section);
    else if(sectionIds.length&&!p.sourceOnly)parts.push('S'+sectionIds.join('–'));
    if(p.sourceOnly&&p.sourceSegment!=null&&!mapped)parts.push('Ace bay '+(seg?.ordinal||String(p.sourceSegment).replace(/^SOURCE-/,'')));
    if(p.fixtureType==='SPCFIX')parts.push('SF');
    else if(p.fixtureType==='SHELF'&&p.sourceRow==null&&p.rowOrdinal==null)parts.push('Shelf position unknown');
    if(p.sourceOnly){
      if(p.sourceRow!=null&&p.sourceRow!=='')parts.push((p.fixtureType==='SHELF'?'SH':'R')+p.sourceRow);
      if(p.sourceColumn!=null&&p.sourceColumn!=='')parts.push('C'+p.sourceColumn);
    }else{
      if(p.rowOrdinal!=null)parts.push('R'+p.rowOrdinal);
      if(p.columnOrdinal!=null)parts.push((p.fixtureType==='PEG'?'P':'C')+p.columnOrdinal);
      else if(p.observedOrder!=null)parts.push('ORD'+p.observedOrder);
    }
    if(['LFT','L-CNT','CNT','CNT-R','RGT','CL','CTR','CR'].includes(p.fixtureZone))parts.push(p.fixtureZone);
    if(parts.length===1)parts.push('Position not recorded');
    return parts.join(' · ');
   }
   async function persistView(){
    if(!draft||!model)return;
    const p=current();draft.mode=model.mode;draft.focusId=p?.id||null;draft.index=index;
    const key=identityKey(p);
    if(key&&!draft.viewed.includes(key))draft.viewed.push(key);
    draft=await drafts.save(draft);
   }
   function currentTags(p){
    const key=identityKey(p);
    return draft?.tags?.[key]||confirmation?.tags?.[key]||[];
   }
   function renderTags(p){
    const key=identityKey(p),tags=localTagSelections.get(key)||currentTags(p);
    doc.querySelectorAll('[data-explorer-tag]').forEach(button=>{
      const active=tags.includes(button.dataset.explorerTag);
      button.classList.toggle('active',active);button.setAttribute('aria-pressed',String(active));
    });
   }
   async function render(){
    if(!model)return;
    const generation=++token,items=displayed();model.items=items;
    index=items.length?Math.max(0,Math.min(index,items.length-1)):0;
    const item=current(),sections=model.modular.physicalSectionIds||[];
    const feet=Number(model.source?.nominalWidthFt)||(sections.length*4);
    const area=model.area.name||('Aisle '+(model.area.aisle||model.area.id));
    text('locationExplorerTitle',model.modular.name);text('locationExplorerArea',area);
    text('locationExplorerFootage',feet>0?feet+' ft':'Footage unknown');
    text('locationExplorerSpan',model.mode==='ACE'?(model.source?.nominalFourFootSections||'—')+' Ace bays':sections.length+' store sections');
    const store=$('locationExplorerStoreMode'),ace=$('locationExplorerAceMode');
    store.disabled=!model.store.length&&!draft;ace.disabled=!model.ace.length;
    for(const [button,selected] of [[store,model.mode==='STORE'],[ace,model.mode==='ACE']]){
      button.classList.toggle('active',selected);button.setAttribute('aria-pressed',String(selected));
    }
    text('locationExplorerEvidence',model.mode==='ACE'?'Official Ace planogram':draft?.edits?'Draft floor layout':confirmation?'Confirmed floor layout':'Store layout');
    text('locationExplorerCount',items.length?(model.mode==='ACE'&&model.ace.some(x=>x.sourceOrder!=null)
      ?(item?.sourceOrder!=null?'Item '+item.sourceOrder+' / '+new Set(model.ace.filter(x=>x.sourceOrder!=null).map(x=>x.sourceOrder)).size:'Order unresolved')
      :(index+1)+' / '+items.length):'0 / 0');
    text('locationExplorerSection',item?policy.position(item):'');
    text('locationExplorerLocationHeading','LOC');
    locationSummary(item?locationText(item):'No position recorded');
    text('locationExplorerLocationWarning','');
    text('locationExplorerSourceCoordinates',item?.sourceOnly?'Ace source: '+policy.position(item):'');
    $('locationExplorerPrevious').disabled=index===0;
    $('locationExplorerNext').disabled=index>=items.length-1;
    $('locationExplorerUndo').disabled=!undo;
    text('locationExplorerItemName',item?'Loading item…':'No items in this display');
    for(const id of ['locationExplorerSku','locationExplorerUpc','locationExplorerRetail','locationExplorerAceNetRetail','locationExplorerOrderMultiple','locationExplorerRetailUnits'])text(id,'—');
    setImage('locationExplorerImage','locationExplorerImageEmpty');$('locationExplorerImageEmpty').textContent='Image unavailable';
    for(const id of ['locationExplorerInsert','locationExplorerEditButton','locationExplorerDelete'])show(id,!!item&&!!draft);
    show('locationExplorerTagRow',!!item);
    doc.querySelectorAll('[data-explorer-tag]').forEach(button=>{button.disabled=!item;});
    $('locationExplorerAddTagged').disabled=!item||!(localTagSelections.get(identityKey(item))||currentTags(item)).length;
    show('locationExplorerMore',!!item);
    renderTags(item);
    if(draft)await persistView();
    if(!item)return;
    const details=await read.details(item);if(generation!==token)return;
    text('locationExplorerItemName',details.description.toUpperCase());
    text('locationExplorerSku',details.sku);text('locationExplorerUpc',details.upc);
    text('locationExplorerRetail',currency(details.retail));
    text('locationExplorerOrderMultiple',details.orderMultiple??'—');text('locationExplorerRetailUnits',details.retailUnits??'—');
    enrich(details,'locationExplorerImage','locationExplorerImageEmpty','locationExplorerAceNetRetail',generation);
   }
   async function mode(name){
    if(!model)return;
    const p=current(),key=identityKey(p),id=p?.id;
    model.mode=name;
    const at=displayed().findIndex(x=>x.id===id||identityKey(x)===key);
    index=at>=0?at:Math.min(index,Math.max(0,displayed().length-1));await render();
   }
   async function step(amount){if(!model)return;index=Math.max(0,Math.min(displayed().length-1,index+amount));await render();}
   function editForm(action='MOVE_TO'){
    if(!current()||!draft)return;
    pending=null;insertScanning=false;
    show('locationExplorerReview',false);show('locationExplorerEditMenu',false);
    show('locationExplorerSettings',false);show('locationExplorerEdit',true);
    const sections=$('locationExplorerEditSection');sections.replaceChildren();
    const empty=el('option','','Section not specified');empty.value='';sections.append(empty);
    for(const sec of model.modular.physicalSectionIds||[]){const option=el('option','','SEC '+sec);option.value=String(sec);sections.append(option)}
    sections.value=current().physicalSectionId||'';
    $('locationExplorerEditRow').value=current().rowOrdinal??'';
    $('locationExplorerEditFacing').value=String(current().facings||1);
    $('locationExplorerEditLocationNote').value=current().locationNote||'';
    $('locationExplorerEditIdentifier').value='';$('locationExplorerEditIdType').value='UPC';
    $('locationExplorerEditAction').value=action;
    const target=$('locationExplorerAnchor');target.replaceChildren();
    for(const p of draft.items.filter(x=>x.id!==current().id)){
      const opt=el('option','',(p.skuKey?'SKU '+p.skuKey:'UPC '+p.upcKey)+' · '+policy.position(p));
      opt.value=p.id;target.append(opt);
    }
    syncEdit();status('');
   }
   function openEditMenu(){editForm('MOVE_TO')}
   function syncEdit(){
    const action=$('locationExplorerEditAction').value;
    show('locationExplorerEditInsert',action.startsWith('INSERT_'));
    show('locationExplorerInsertOrder',action.startsWith('INSERT_'));
    show('locationExplorerEditKind',!action.startsWith('INSERT_'));
    doc.querySelectorAll('[data-explorer-insert-direction]').forEach(button=>{const selected=button.dataset.explorerInsertDirection===action;button.classList.toggle('active',selected);button.setAttribute('aria-pressed',String(selected));});
    show('locationExplorerEditTarget',action==='MOVE_TO');
    show('locationExplorerEditAnchor',action==='MOVE_BEFORE'||action==='MOVE_AFTER');
    show('locationExplorerEditFacings',action==='FACINGS');
    $('locationExplorerPrepare').textContent=action==='REMOVE'?'Review Deletion':'Preview Change';
   }
   async function prepare(){
    if(!draft||!model)throw Error('Choose a display first');
    const p=current(),action=$('locationExplorerEditAction').value,items=draft.items.map(x=>({...x}));
    let at=items.findIndex(x=>x.id===p?.id);
    if(at<0)at=items.findIndex(x=>policy.same(x,p));
    if(at<0)throw Error('Switch to Store view to edit this physical placement');
    const target=items[at];let focusId=target.id;
    if(action.startsWith('INSERT_')){
      const type=$('locationExplorerEditIdType').value,raw=$('locationExplorerEditIdentifier').value.trim();
      if(!raw)throw Error('Scan or enter the item to insert');
      const found=await read.resolveIdentity(type==='UPC'?normalizeUPC(raw):normalizeSKU(raw),type);
      if(!found.skuKey&&!found.upcKey)throw Error('Valid product identity required');
      if(items.some(x=>policy.same(x,found)))throw Error('Item already present. Use Edit to move it.');
      const facts=found.skuKey?await repository.bySku(found.skuKey):await repository.byUpc(found.upcKey);
      const activeIds=new Set((await repository.listModulars()).filter(x=>x.active!==false).map(x=>x.id));
      const elsewhere=(facts.placements||[]).some(x=>x.physicalEvidence===true&&x.modularId!==model.modular.id&&activeIds.has(x.modularId));
      const added={id:'explorer:'+idFactory(),modularId:model.modular.id,skuKey:found.skuKey||null,upcKey:found.upcKey||null,
        origin:'USER_EDIT',role:elsewhere?'SECONDARY':'HOME',physicalEvidence:false,
        fixtureType:target.fixtureType||'UNKNOWN',sourceOnly:false,storeAdded:!model.sourceMembers.some(x=>policy.same(x,found)),
        locationNote:null,physicalSectionId:null,rowOrdinal:null};
      items.splice(at+(action==='INSERT_AFTER'?1:0),0,added);focusId=added.id;
    }else if(action==='REMOVE')items.splice(at,1);
    else if(action==='MOVE_TO'){
      const note=$('locationExplorerEditLocationNote').value.trim();
      if(note.length>100)throw Error('Location description is too long');
      const section=$('locationExplorerEditSection').value||null,rawRow=$('locationExplorerEditRow').value.trim();
      const row=rawRow===''?null:Number(rawRow);
      if(row!=null&&(!Number.isInteger(row)||row<1||row>500))throw Error('Row must be between 1 and 500');
      items[at]={...target,sourceOnly:false,origin:'USER_EDIT',physicalEvidence:true,
        physicalSectionId:section,rowOrdinal:row,locationNote:note||null};
      if(JSON.stringify(items[at])===JSON.stringify(target))throw Error('No location change');
    }else if(action==='FACINGS'){
      const n=Number($('locationExplorerEditFacing').value);
      if(!Number.isInteger(n)||n<1||n>500)throw Error('Facings must be between 1 and 500');
      items[at]={...target,facings:n};
    }else if(action==='MOVE_BEFORE'||action==='MOVE_AFTER'){
      const id=$('locationExplorerAnchor').value,targetIdx=items.findIndex(x=>x.id===id);
      if(targetIdx<0||targetIdx===at)throw Error('Choose another item');
      const moving=items.splice(at,1)[0],newIdx=items.findIndex(x=>x.id===id);
      items.splice(newIdx+(action==='MOVE_AFTER'?1:0),0,moving);
    }else throw Error('Unknown correction action');
    if(!items.length)throw Error('A layout cannot be empty');
    pending={action,items,focusId,before:draft.items.map(x=>({...x}))};
    const host=$('locationExplorerReviewText');host.replaceChildren();
    host.append(el('strong','',action.replaceAll('_',' ')),el('p','','Current: '+locationText(p)));
    if(action.startsWith('INSERT_'))host.append(el('p','','Insertion next to '+(p.skuKey?'SKU '+p.skuKey:'UPC '+p.upcKey)));
    if(action==='MOVE_TO')host.append(el('p','','New location: '+($('locationExplorerEditLocationNote').value.trim()||'Selected section or row')));
    host.append(el('p','','This change is saved only as a draft until the whole floor layout is confirmed.'));
    show('locationExplorerEdit',false);show('locationExplorerReview',true);status('');
   }
   async function commit(){
    if(!pending||!draft)return;
    if(pending.action==='REMOVE'&&!await confirmUser('Delete this item from the draft layout? The original Ace planogram remains unchanged.','Delete Placement',{okLabel:'Delete'}))return;
    undo={items:draft.items.map(x=>({...x})),edits:draft.edits};
    draft.items=pending.items;draft.edits=(draft.edits||0)+1;
    const focusId=pending.focusId,wasDelete=pending.action==='REMOVE',formerIndex=index;
    draft=await drafts.save(draft);pending=null;insertScanning=false;
    model.mode='STORE';model.items=draft.items;
    index=wasDelete?Math.min(formerIndex,Math.max(0,draft.items.length-1)):Math.max(0,draft.items.findIndex(x=>x.id===focusId));
    show('locationExplorerEdit',false);show('locationExplorerReview',false);
    await render();status('Saved automatically as an unfinished floor layout.');
   }
   async function undoLast(){
    if(!undo||!draft)return;
    const previous=undo;undo=null;draft.items=previous.items;draft.edits=previous.edits;
    draft=await drafts.save(draft);model.mode='STORE';
    index=Math.min(index,Math.max(0,draft.items.length-1));
    await render();status('Last draft change reversed.');
   }
   async function quickDelete(){
    if(!draft||!current())return;
    const selected=current(),at=draft.items.findIndex(x=>x.id===selected.id||policy.same(x,selected));
    if(at<0)throw Error('Selected item does not exist in the working store layout');
    if(draft.items.length<=1)throw Error('Cannot delete the last item from the floor layout');
    if(!await confirmUser('Remove this item from the unfinished store layout? The original Ace planogram remains unchanged.','Delete Placement',{okLabel:'Delete'}))return;
    undo={items:draft.items.map(x=>({...x})),edits:draft.edits};
    draft.items=draft.items.filter((x,i)=>i!==at);
    draft.edits=(draft.edits||0)+1;draft=await drafts.save(draft);
    model.mode='STORE';index=Math.min(at,Math.max(0,draft.items.length-1));
    show('locationExplorerEdit',false);show('locationExplorerReview',false);
    await render();status('Item deleted from draft only. Original Ace planogram preserved.');
   }
   async function toggleTag(tag){
    if(!current()||!tagNames.includes(tag))return;
    const key=identityKey(current()),tags=[...(localTagSelections.get(key)||currentTags(current()))],at=tags.indexOf(tag);
    if(at>=0)tags.splice(at,1);else tags.push(tag);
    localTagSelections.set(key,tags);
    if(draft){draft.tags[key]=tags;draft=await drafts.save(draft);}
    renderTags(current());
    $('locationExplorerAddTagged').disabled=!tags.length;
   }
   async function addTaggedItem(){
    const selected=current();
    if(!selected)throw Error('Select an item to tag');
    const tags=localTagSelections.get(identityKey(selected))||currentTags(selected);
    if(!tags.length)throw Error('Select at least one tag first');
    const details=await read.details(selected);
    const result=await tagService.add({placement:selected,details,tags});
    if(result.status==='CANCELLED'){status('Tag-list creation cancelled. Your tag selection remains.');return}
    status((result.status==='UPDATED'?'Updated':'Added')+' item in '+result.name+'.');
   }
   function openSettings(){
    show('locationExplorerSettings',true);show('locationExplorerEdit',false);show('locationExplorerReview',false);
    $('locationExplorerSettingsConfirm').textContent=draft?.edits||draft?.basis==='STORE'?'Review & Confirm Floor Layout':'Confirm Store Matches Ace';
    $('locationExplorerSettingsConfirm').disabled=!model||!draft;
    show('locationExplorerSettingsDiscard',!!draft);
   }
   async function listPrevious(){
    const records=await drafts.list(),host=$('locationExplorerAuditList');host.replaceChildren();
    for(const saved of records){
      const button=el('button','locationExplorerChoice',(saved.name||saved.modularId)+' · '+(saved.edits||0)+' edits · '+(saved.viewed?.length||0)+' viewed');
      button.type='button';button.addEventListener('click',()=>void guard(async()=>{
        const fresh=await read.display(saved.modularId,saved.mode);
        if(!drafts.isCurrent(saved,fresh)){
          const discard=await confirmUser('This saved audit belongs to an earlier Ace planogram or store layout. It cannot be applied to the current display. Discard this old draft and start a fresh audit? The original Ace and last confirmed store layout will remain unchanged.','Outdated Saved Audit',{okLabel:'Discard Old Draft'});
          if(!discard)return;
          await drafts.discard(saved.modularId);
          await choose(saved.modularId,saved.mode,null);
          status('Outdated audit discarded. The current display is ready for a new review.');
          return;
        }
        await choose(saved.modularId,saved.mode,null);
      }));
      host.append(button);
    }
    if(!records.length)host.append(el('p','','No unfinished planograms.'));
    show('locationExplorerAuditList',true);
   }
   async function openDifferences(){
    const old=await drafts.listConfirmed(),newRecords=await verification.list(),seen=new Set(),all=[];
    for(const entry of newRecords){if(seen.has(entry.modularId))continue;seen.add(entry.modularId);all.push({...entry,name:entry.displayName,kind:entry.method==='VISUAL_ACE_MATCH'?'ACE':'STORE'})}
    for(const entry of old){if(!seen.has(entry.modularId)){seen.add(entry.modularId);all.push(entry)}}
    const options=$('locationExplorerDifferencesSelect');
    options.replaceChildren();
    for(const entry of all){
      // Confirmed historical source snapshots permit comparison after an Ace replacement.
      if(!entry.sourceId&&!Array.isArray(entry.sourceSnapshot))continue;
      const opt=el('option','',(entry.name||entry.modularId)+' · '+(entry.area||'Store'));
      opt.value=entry.modularId;options.append(opt);
    }
    show('locationExplorerSettings',false);show('locationExplorerDifferences',true);
    text('locationExplorerDifferencesStatus','');
    $('locationExplorerDifferencesSummary').replaceChildren();
    $('locationExplorerDifferencesList').replaceChildren();
    if(!options.options.length){
      text('locationExplorerDifferencesStatus','No confirmed planograms are available for comparison.');
      return;
    }
    const desired=model?.modular?.id;
    options.value=Array.from(options.options).some(o=>o.value===desired)?desired:options.options[0].value;
    await selectDifferences(options.value);
   }
   async function selectDifferences(id){
    if(!id)return;
    const saved=await verification.latest(id)||await drafts.confirmed(id);
    if(!saved)throw Error('Confirmed layout no longer exists');
    const summary=$('locationExplorerDifferencesSummary'),list=$('locationExplorerDifferencesList');
    summary.replaceChildren();list.replaceChildren();
    let ace=saved.sourceSnapshot,store=saved.storeSnapshot;
    if(saved.method==='VISUAL_ACE_MATCH'&&Array.isArray(ace))store=ace;
    if(!Array.isArray(ace)||!Array.isArray(store)){
      const currentDisplay=await read.display(id,'ACE');
      if(saved.sourceDigest!==(currentDisplay.source?.digest||null)){
        text('locationExplorerDifferencesStatus','The official Ace planogram changed after this earlier confirmation. Historical position details are unavailable; no differences are inferred.');
        return;
      }
      ace=currentDisplay.ace;
      store=saved.kind==='STORE'?currentDisplay.store:ace;
    }
    const result=differences.compare({ace,store});
    text('locationExplorerDifferencesStatus','Compared against the Ace planogram revision recorded at confirmation. Unchanged items are hidden.');
    for(const [label,n] of [['Inserted',result.inserted.length],['Deleted',result.deleted.length],['Changed',result.changed.length]]){
      const stat=el('div','locationExplorerDiffStat');
      stat.append(el('strong','',String(n)),el('span','',label));summary.append(stat);
    }
    if(result.total===0){list.append(el('p','locationExplorerDiffNone','No differences. This confirmed layout matches its Ace planogram.'));return}
    for(const [label,rows] of [['Inserted',result.inserted],['Deleted',result.deleted],['Location / Order Changed',result.changed]]){
      if(!rows.length)continue;
      const group=el('section','locationExplorerDiffGroup');group.append(el('h3','',label+' ('+rows.length+')'));
      for(const item of rows){
        const line=el('article','locationExplorerDiffEntry');line.append(el('strong','',item.identity));
        if(item.before)line.append(el('small','','Ace: '+item.before));
        if(item.after)line.append(el('small','','Store: '+item.after));
        if(item.description)line.append(el('small','',item.description));
        group.append(line);
      }
      list.append(group);
    }
   }
   async function confirmAudit(){
    if(!draft||!model)return;
    if(!drafts.isCurrent(draft,await read.display(model.modular.id,model.mode)))throw Error('Source or accepted store layout changed. Review before confirming.');
    const edited=Number(draft.edits)>0,storeConfirmation=edited||draft.basis==='STORE',approved=await confirmUser(
      storeConfirmation?'Have you visually checked the entire current store layout and confirmed it is correct? Original Ace planogram remains unchanged.':'Have you visually inspected this entire display and confirmed that the store matches the official Ace planogram?',
      storeConfirmation?'Confirm Floor Layout':'Confirm Store Matches Ace',{okLabel:'Confirm Layout'});
    if(!approved)return;
    let confirmedStoreItems=storeConfirmation?draft.items:model.ace;
    if(edited){
      const placements=draft.items.map((p,i)=>({
        id:p.sourceOnly?'accepted:'+p.id:p.id,modularId:model.modular.id,skuKey:p.skuKey||null,upcKey:p.upcKey||null,
        origin:p.sourceOnly?'ACE_IMPORT':'USER_EDIT',role:p.role||'HOME',storeAdded:p.storeAdded===true,
        physicalEvidence:p.sourceOnly!==true&&p.physicalEvidence===true,
        fixtureType:p.fixtureType||'UNKNOWN',physicalSectionId:p.sourceOnly?null:(p.physicalSectionId??null),
        rowOrdinal:p.sourceOnly?null:(p.rowOrdinal??null),columnOrdinal:p.sourceOnly?null:(p.columnOrdinal??null),observedOrder:null,
        sourceSegment:p.sourceSegment??null,sourceRow:p.sourceRow??null,sourceColumn:p.sourceColumn??null,
        fixtureZone:p.fixtureZone??null,facings:p.facings??null,explorerOrder:i+1,locationNote:p.locationNote||null,
        approvedException:p.approvedException??null
      }));
      for(const p of placements.filter(x=>x.role==='SECONDARY'&&!x.approvedException)){
        const yes=await confirmUser('Approve a separate stocked location for '+(p.skuKey?'SKU '+p.skuKey:'UPC '+p.upcKey)+' in this display?','Confirm Additional Location',{okLabel:'Approve Location'});
        if(!yes)return;
        p.approvedException={placementId:p.id,skuKey:p.skuKey||null,physicalSectionId:p.physicalSectionId??null,rowOrdinal:p.rowOrdinal??null,observedOrder:p.observedOrder??null,confirmedAt:Date.now()};
      }
      await repository.approvePhysicalLayout({modularId:model.modular.id,items:placements,
        expectedFingerprint:draft.fingerprint,expectedSourceSignature:draft.signature});
      confirmedStoreItems=placements;
    }
    const evidence=await verification.evidence(model.modular.id);
    await verification.record({modularId:model.modular.id,method:storeConfirmation?'VISUAL_STORE_LAYOUT':'VISUAL_ACE_MATCH',
      expectedSourceSignature:evidence.sourceSignature,expectedLayoutFingerprint:evidence.layoutFingerprint,
      complete:true,observedCount:0,changedCount:Number(draft.edits)||0});
    confirmation=await drafts.finish(model.modular.id,{kind:storeConfirmation?'STORE':'ACE',sourceId:draft.sourceId,
      sourceDigest:draft.sourceDigest,name:model.modular.name,area:model.area.name||'Aisle '+model.area.aisle,
      sourceSnapshot:model.ace.map(differences.take),storeSnapshot:confirmedStoreItems.map(differences.take),
      tags:draft.tags,viewed:draft.viewed,entryCount:draft.items.length});
    draft=null;undo=null;pending=null;
    model=await read.display(model.modular.id,storeConfirmation?'STORE':'ACE');
    index=Math.min(index,Math.max(0,model.items.length-1));
    show('locationExplorerSettings',false);await render();
    status(storeConfirmation?'Confirmed store layout saved.':'Store confirmed to match Ace.');
   }
   async function discardDraft(){
    if(!draft||!await confirmUser('Discard only unfinished Explorer work? The Ace planogram and last confirmed layout are preserved.','Discard Unfinished Audit'))return;
    await drafts.discard(model.modular.id);draft=null;undo=null;pending=null;
    model=await read.display(model.modular.id);index=0;show('locationExplorerSettings',false);
    await render();status('Unfinished audit discarded. Confirmed layouts preserved.');
   }
   async function wizard(fromSource=false){resetViews();show('locationExplorerWizard',true);const mods=(await repository.listModulars()).filter(m=>m.active!==false);
   const choices=$('locationExplorerWizardExisting');choices.replaceChildren();const def=el('option','','Create a new display');def.value='';choices.append(def);
   const preferred=fromSource?model?.modular.id:null;
   for(const m of mods){const opt=el('option','',m.name+' · '+(m.physicalSectionIds?.length?(m.physicalSectionIds.length*4)+' feet':'Custom fixture'));opt.value=m.id;choices.append(opt)}
   choices.value=preferred||'';$('locationExplorerWizardNew').classList.toggle('hidden',!!preferred);
   $('locationExplorerWizardAreaType').value='AISLE';$('locationExplorerWizardAisle').value='';$('locationExplorerWizardDisplay').value='';
   $('locationExplorerWizardStartSection').value='1';$('locationExplorerWizardEndSection').value='1';
   text('locationExplorerWizardItem',identity?.skuKey?'SKU '+identity.skuKey:'UPC '+(identity?.upcKey||'—'));
   await updateWizardSection();
   status('Choose an existing display or create a new physical location. The first item will carry into the existing layout builder.');
  }
  async function startWizard(){if(!identity)throw Error('Scan an item before creating a physical layout');
   if(await workController.hasUnfinishedDraft?.())throw Error('An unfinished physical layout draft exists. Resume or discard it before starting a different display.');
   let id=$('locationExplorerWizardExisting').value,section=null;
   if(!id){
    const areaType=$('locationExplorerWizardAreaType').value,aisle=$('locationExplorerWizardAisle').value.trim(),name=$('locationExplorerWizardDisplay').value.trim();
    if(!name||name.length>100)throw Error('Enter a display name (up to 100 characters)');
    const areas=await repository.listAreas(),mods=await repository.listModulars();let area,sections=[];
    if(areaType==='AISLE'){
     if(!/^\d{1,3}[A-Za-z]?$/.test(aisle))throw Error('Enter a valid aisle number');
     const start=Number($('locationExplorerWizardStartSection').value),end=Number($('locationExplorerWizardEndSection').value);
     if(!Number.isSafeInteger(start)||!Number.isSafeInteger(end)||start<1||end<start||end-start>=25)throw Error('Select a real four-foot section range (up to 25 sections)');
     sections=Array.from({length:end-start+1},(_,i)=>String(start+i));
     area=areas.find(a=>a.active!==false&&a.kind==='AISLE'&&String(a.aisle)===aisle);
     if(!area)area={id:'area:'+idFactory(),kind:'AISLE',aisle,name:'Aisle '+aisle,active:true};
     const collision=mods.find(m=>m.active!==false&&m.area?.kind==='AISLE'&&m.area?.aisle===aisle&&sections.some(s=>m.physicalSectionIds?.includes(s)));
     if(collision)throw Error('Those sections already belong to '+collision.name+'. Choose the existing display or a different section.');
    }else{
     const label=$('locationExplorerWizardCustom').value.trim();if(!label||label.length>100)throw Error('Name the custom area');
     area=areas.find(a=>a.active!==false&&a.kind==='CUSTOM'&&a.name?.toLowerCase()===label.toLowerCase());
     if(!area)area={id:'area:'+idFactory(),kind:'CUSTOM',name:label,active:true};
    }
    if(!areas.some(a=>a.id===area.id))await repository.saveArea(area);
    id='explorer-display:'+idFactory();
    await repository.saveModular({id,name,area:{kind:area.kind,id:area.id,...(area.kind==='AISLE'?{aisle:area.aisle}:{name:area.name})},physicalSectionIds:sections,
     fixtureId:area.kind==='CUSTOM'?'fixture:'+id:null,active:true});section=sections[0]||null;
   }else{
    const m=await repository.getModular(id);if(!m||m.active===false)throw Error('The selected display is no longer active');
    const s=$('locationExplorerWizardSection').value.trim();section=m.physicalSectionIds?.includes(s)?s:m.physicalSectionIds?.[0]||null;
   }
   showScreen('locationScreen','Planograms & Locations');$('locationLayoutTab').click();
   await workController.beginFromExplorer({modularId:id,section,identity});
   status('Layout builder opened with your original scanned item.');
  }
  async function updateWizardSection(){const id=$('locationExplorerWizardExisting').value;show('locationExplorerWizardNew',!id);
   const area=$('locationExplorerWizardSectionArea');show('locationExplorerWizardSectionArea',!!id);if(!id)return;
   const m=await repository.getModular(id);const s=$('locationExplorerWizardSection');s.replaceChildren();
   for(const section of m?.physicalSectionIds||[]){const o=el('option','','SEC '+section);o.value=section;s.append(o)}
   if(!s.options.length){const o=el('option','','Custom fixture');o.value='';s.append(o)}
  }
  async function onAcceptedScan({upc,format=null}={}){
   if(!active())return false;
   if(insertScanning&& !$('locationExplorerEdit').classList.contains('hidden')){
    $('locationExplorerEditIdType').value='UPC';$('locationExplorerEditIdentifier').value=normalizeUPC(upc);insertScanning=false;
    status('Scanned insertion UPC. Preview the correction to continue.');return true;
   }
   setLookupMode('UPC',false);$('locationExplorerLookup').value=upc;await guard(()=>search(normalizeUPC(upc),'UPC',format));return true;
  }
  function bind(){
   $('locationExploreOpen').addEventListener('click',()=>void guard(open));
   doc.querySelectorAll('[data-explorer-lookup-mode]').forEach(button=>button.addEventListener('click',()=>setLookupMode(button.dataset.explorerLookupMode,true)));
   $('locationExplorerFind').addEventListener('click',()=>{const value=$('locationExplorerLookup').value.trim();if(!value){openManualKeypad();return}void guard(()=>search(value,manualModeExplicit?manualMode:'AUTO'))});
   $('locationExplorerLookup').addEventListener('click',openManualKeypad);
   $('locationExplorerLookup').addEventListener('focus',e=>{e.target.blur();openManualKeypad()});
   $('locationExplorerScan').addEventListener('click',()=>startScanner());$('locationExplorerPrevious').addEventListener('click',()=>void guard(()=>step(-1)));
   $('locationExplorerNext').addEventListener('click',()=>void guard(()=>step(1)));$('locationExplorerStoreMode').addEventListener('click',()=>void guard(()=>mode('STORE')));
   $('locationExplorerAceMode').addEventListener('click',()=>void guard(()=>mode('ACE')));
   
   $('locationExplorerInsert').addEventListener('click',()=>editForm('INSERT_AFTER'));
   $('locationExplorerEditButton').addEventListener('click',openEditMenu);
   $('locationExplorerDelete').addEventListener('click',()=>void guard(quickDelete));
   doc.querySelectorAll('[data-explorer-tag]').forEach(button=>button.addEventListener('click',()=>void guard(()=>toggleTag(button.dataset.explorerTag))));
   $('locationExplorerAddTagged').addEventListener('click',()=>void guard(addTaggedItem));
   $('locationExplorerSettingsOpen').addEventListener('click',openSettings);
   $('locationExplorerSettingsClose').addEventListener('click',closeModal);
   $('locationExplorerModalBackdrop').addEventListener('click',closeModal);
   $('locationExplorerDifferencesClose').addEventListener('click',closeModal);
   $('locationExplorerSettingsDifferences').addEventListener('click',()=>void guard(openDifferences));
   $('locationExplorerSettingsAssignment').addEventListener('click',()=>void guard(async()=>{if(!model)throw Error('Select a display first');closeModal();await onManageAssignment?.(model.modular.id)}));
   $('locationExplorerDifferencesSelect').addEventListener('change',()=>void guard(()=>selectDifferences($('locationExplorerDifferencesSelect').value)));
   doc.addEventListener?.('keydown',event=>{if(event.key==='Escape'&&MODALS.some(name=>!$(name).classList.contains('hidden'))){event.preventDefault();closeModal();}});
   $('locationExplorerSettingsLoad').addEventListener('click',()=>void guard(listPrevious));
   $('locationExplorerSettingsConfirm').addEventListener('click',()=>void guard(confirmAudit));
   $('locationExplorerSettingsDiscard').addEventListener('click',()=>void guard(discardDraft));
   $('locationExplorerEditMenuCancel').addEventListener('click',()=>show('locationExplorerEditMenu',false));
   doc.querySelectorAll('#locationExplorerEditMenu [data-explorer-edit]').forEach(button=>button.addEventListener('click',()=>editForm(button.dataset.explorerEdit)));
   $('locationExplorerEditCancel').addEventListener('click',closeModal);
   $('locationExplorerEditAction').addEventListener('change',()=>{pending=null;show('locationExplorerReview',false);syncEdit()});
   doc.querySelectorAll('[data-explorer-insert-direction]').forEach(button=>button.addEventListener('click',()=>{if(!draft)return;$('locationExplorerEditAction').value=button.dataset.explorerInsertDirection;pending=null;syncEdit()}));
   $('locationExplorerEditScan').addEventListener('click',()=>{insertScanning=true;startScanner()});
   $('locationExplorerPrepare').addEventListener('click',()=>void guard(prepare));
   $('locationExplorerConfirm').addEventListener('click',()=>void guard(commit));
   $('locationExplorerCancelReview').addEventListener('click',()=>{pending=null;show('locationExplorerReview',false);show('locationExplorerEdit',true)});
   $('locationExplorerUndo').addEventListener('click',()=>void guard(undoLast));
   $('locationExplorerNewLayout').addEventListener('click',()=>void guard(()=>wizard()));
   $('locationExplorerExit').addEventListener('click',()=>goBack('explorer_not_found_exit'));
   $('locationExplorerWizardExisting').addEventListener('change',()=>void guard(updateWizardSection));
   $('locationExplorerWizardAreaType').addEventListener('change',()=>{
    const aisle=$('locationExplorerWizardAreaType').value==='AISLE';show('locationExplorerWizardAisleFields',aisle);show('locationExplorerWizardCustomFields',!aisle)});
   $('locationExplorerWizardStart').addEventListener('click',()=>void guard(startWizard));
   $('locationExplorerWizardCancel').addEventListener('click',()=>{resetViews();$('locationExplorerScreen').classList.add('has-display');show('locationExplorerDisplay',true);if(model){show('locationExplorerContext',true);show('locationExplorerEvidence',true);show('locationExplorerLocation',true);show('locationExplorerNavigation',true);show('locationExplorerMore',true);void render()}else{show('locationExplorerMissing',true);show('locationExplorerContext',false);show('locationExplorerEvidence',false);show('locationExplorerLocation',false);show('locationExplorerNavigation',false);show('locationExplorerMore',false)}});
  }
  return Object.freeze({open,openDisplay,active,onAcceptedScan,bind});
 }
 return Object.freeze({create});
})();
