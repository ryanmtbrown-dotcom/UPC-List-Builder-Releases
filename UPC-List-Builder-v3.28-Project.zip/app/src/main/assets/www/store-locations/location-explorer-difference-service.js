/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/store-locations/location-explorer-difference-service.js
 * Owner: Store Locations / Planogram Explorer Comparison
 * Role: Pure read-only domain service
 * Responsibility: Compare Ace source placements with confirmed store placements and return only material differences.
 * Does not own: DOM, database writes, source revision replacement, item tagging, or accepted store layout mutation.
 * Side effects: None.
 * Related code: location-explorer-controller.js, location-explorer-draft-service.js, location-explorer-policy.js.
 */
const UPCLocationExplorerDifferenceService=(()=>{
 'use strict';
 const take=p=>({
  id:String(p?.id||''),skuKey:p?.skuKey||null,upcKey:p?.upcKey||null,
  sourceSegment:p?.sourceSegment??null,sourceRow:p?.sourceRow??null,sourceColumn:p?.sourceColumn??null,
  fixtureType:p?.fixtureType||'UNKNOWN',fixtureZone:p?.fixtureZone??null,
  physicalSectionId:p?.physicalSectionId??null,rowOrdinal:p?.rowOrdinal??null,columnOrdinal:p?.columnOrdinal??null,
  locationNote:p?.locationNote||null,observedOrder:p?.observedOrder??null,facings:p?.facings??null,
  explorerOrder:p?.explorerOrder??null,sourceOnly:p?.sourceOnly===true,physicalEvidence:p?.physicalEvidence===true
 });
 const key=p=>p.skuKey?'SKU:'+p.skuKey:p.upcKey?'UPC:'+p.upcKey:'UNKNOWN:'+p.id;
 const fixedId=p=>String(p.id).replace(/^accepted:/,'');
 const sourceLoc=p=>[p.sourceSegment!=null?'SRC SEC '+String(p.sourceSegment).replace(/^SOURCE-/,''):null,
  p.sourceRow!=null?'ROW '+p.sourceRow:null,p.sourceColumn!=null?'COL '+p.sourceColumn:null,
  p.fixtureType==='SPCFIX'?'SF':null,p.fixtureZone||null].filter(Boolean).join(' · ')||'Ace position not specified';
 function storeLoc(p){
  if(p.locationNote)return p.locationNote;
  const parts=[p.physicalSectionId!=null?'SEC '+p.physicalSectionId:null,
   p.rowOrdinal!=null?'ROW '+p.rowOrdinal:null,
   p.columnOrdinal!=null?'COL '+p.columnOrdinal:null,p.observedOrder!=null?'ORDER '+p.observedOrder:null,
   p.fixtureType==='SPCFIX'?'SF':null,p.fixtureZone||null].filter(Boolean);
  return parts.length?parts.join(' · '):sourceLoc(p);
 }
 const material=p=>JSON.stringify([p.sourceSegment,p.sourceRow,p.sourceColumn,p.physicalSectionId,p.rowOrdinal,
  p.columnOrdinal,p.locationNote,p.fixtureType,p.fixtureZone,p.facings]);
 function compare({ace=[],store=[]}={}){
  if(!Array.isArray(ace)||!Array.isArray(store))throw Error('Ace and confirmed store positions required');
  const left=ace.map(take),right=store.map(take),lUsed=new Set(),rUsed=new Set(),pairs=[];
  const match=(a,b)=>{lUsed.add(a);rUsed.add(b);pairs.push([a,b])};
  // Stable source IDs survive confirmation as "accepted:source-member:...".
  left.forEach((a,i)=>{const j=right.findIndex((b,k)=>!rUsed.has(k)&&key(b)===key(a)&&fixedId(b)===fixedId(a)&&!!a.id);
   if(j>=0)match(i,j)});
  // Same SKU in several positions is not automatically a move or duplicate.
  left.forEach((a,i)=>{if(lUsed.has(i))return;
   const j=right.findIndex((b,k)=>!rUsed.has(k)&&key(a)===key(b)&&material(a)===material(b));
   if(j>=0)match(i,j)});
  left.forEach((a,i)=>{if(lUsed.has(i))return;
   const j=right.findIndex((b,k)=>!rUsed.has(k)&&key(a)===key(b));
   if(j>=0)match(i,j)});
  const pairsByAce=[...pairs].sort((a,b)=>a[0]-b[0]);
  const linkedRight=new Map(pairs.map(([i,j])=>[j,i]));
  const currentOrder=[...linkedRight.keys()].sort((a,b)=>a-b).map(j=>linkedRight.get(j));
  const expectedOrder=pairsByAce.map(x=>x[0]);
  const positionChanged=new Set();
  if(currentOrder.length===expectedOrder.length){
   currentOrder.forEach((i,k)=>{if(i!==expectedOrder[k])positionChanged.add(i)});
  }
  const inserted=right.flatMap((p,i)=>rUsed.has(i)?[]:[{kind:'INSERTED',identity:key(p),after:storeLoc(p),placementId:p.id}]);
  const deleted=left.flatMap((p,i)=>lUsed.has(i)?[]:[{kind:'DELETED',identity:key(p),before:sourceLoc(p),placementId:p.id}]);
  const changed=pairsByAce.flatMap(([i,j])=>{
   const a=left[i],b=right[j],relocated=material(a)!==material(b),reordered=positionChanged.has(i);
   if(!relocated&&!reordered)return [];
   return [{kind:'CHANGED',identity:key(b),before:sourceLoc(a),after:storeLoc(b),
    description:relocated&&reordered?'Location and order changed':relocated?'Location/details changed':'Relative order changed',
    placementId:b.id}];
  });
  return{inserted,deleted,changed,total:inserted.length+deleted.length+changed.length,
   sourceCount:left.length,storeCount:right.length};
 }
 return Object.freeze({take,compare,sourceLoc,storeLoc});
})();
