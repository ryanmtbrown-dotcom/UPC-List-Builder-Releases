/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/store-locations/location-explorer-draft-service.js
 * Owner: Store Locations / Explorer Audit Persistence
 * Role: IndexedDB-backed audit draft service
 * Responsibility: One quietly saved Explorer working copy per modular, backed up through existing meta store.
 * Does not own: Official Ace source, accepted physical placements, list records, or catalog fields.
 * Side effects: Reads/writes only Explorer-owned records in the existing meta store through injected UPCDB.
 * Related code: location-explorer-controller.js, location-explorer-feature.js, data-backup.js.
 */
const UPCLocationExplorerDraftService=(()=>{
 'use strict';
 const KEY='locationExplorerAudits.v1',MAX_ITEMS=3000,MAX_AUDITS=40;
 function create({db,repository,workPolicy}={}){
  if(!db||!repository||!workPolicy)throw Error('Explorer draft dependencies missing');
  let queue=Promise.resolve();
  const serialized=fn=>{const next=queue.then(fn);queue=next.catch(()=>{});return next};
  const read=async()=>{const row=await db.get('meta',KEY);return row?.key===KEY&&row.audits&&typeof row.audits==='object'?row:{key:KEY,audits:{},confirmed:{}}};
  const signature=m=>repository.sourceSignature(m.source?[m.source]:[]);
  const footprint=m=>workPolicy.fingerprint(m.placements||[]);
  const stamp=m=>({sourceId:m.source?.id||null,sourceDigest:m.source?.digest||null,signature:signature(m),fingerprint:footprint(m)});
  const isCurrent=(audit,m)=>!!audit&&audit.modularId===m.modular.id&&audit.signature===signature(m)&&audit.fingerprint===footprint(m)&&audit.sourceId===(m.source?.id||null)&&audit.sourceDigest===(m.source?.digest||null);
  async function list(){await queue;const r=await read();return Object.values(r.audits).filter(x=>x&&typeof x.modularId==='string').sort((a,b)=>String(b.updatedAt||'').localeCompare(String(a.updatedAt||'')))}
  async function load(id){await queue;const r=await read();return r.audits[id]||null}
  async function save(audit){
   if(!audit||typeof audit.modularId!=='string'||!audit.modularId||!Array.isArray(audit.items)||audit.items.length>MAX_ITEMS)throw Error('Invalid Explorer working copy');
   return serialized(async()=>{
    const r=await read(),now=new Date().toISOString(),copy={...audit,updatedAt:now};
    if(!r.audits[audit.modularId]&&Object.keys(r.audits).length>=MAX_AUDITS)throw Error('Too many unfinished displays. Confirm or discard an older audit.');
    r.audits[audit.modularId]=copy;await db.put('meta',r);return copy;
   });
  }
  async function discard(id){return serialized(async()=>{const r=await read();delete r.audits[id];await db.put('meta',r)})}
  async function finish(id,confirmation){
   return serialized(async()=>{
    const r=await read();
    r.confirmed??={};r.confirmed[id]={...confirmation,confirmedAt:new Date().toISOString()};
    delete r.audits[id];await db.put('meta',r);return r.confirmed[id];
   });
  }
  async function confirmed(id){await queue;const r=await read();return r.confirmed?.[id]||null}
  async function listConfirmed(){await queue;const r=await read();return Object.entries(r.confirmed||{}).map(([modularId,entry])=>({...entry,modularId})).sort((a,b)=>String(b.confirmedAt||'').localeCompare(String(a.confirmedAt||'')))}
  function initial(m){
   const baseline=m.store.length?m.store:m.ace;
   const evidence=stamp(m);
   return{modularId:m.modular.id,name:m.modular.name,area:m.area.name||('Aisle '+m.area.aisle),...evidence,
    mode:m.mode,basis:m.store.length?'STORE':'ACE',items:baseline.map(x=>({...x})),focusId:null,index:0,viewed:[],tags:{},edits:0,createdAt:new Date().toISOString()};
  }
  return Object.freeze({initial,load,list,save,discard,finish,confirmed,listConfirmed,isCurrent,signature,footprint});
 }
 return Object.freeze({create});
})();
