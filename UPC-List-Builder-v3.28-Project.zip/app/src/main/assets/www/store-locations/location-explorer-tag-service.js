/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/store-locations/location-explorer-tag-service.js
 * Owner: Store Locations / Explorer Field Session Tag Handoff
 * Role: Domain-to-Work-Session integration service
 * Responsibility: Save explicitly selected Explorer product tags into one ordinary Field Session through its existing service.
 * Does not own: Explorer layout acceptance, official Ace sources, raw IndexedDB, catalog authority or list presentation.
 * Side effects: After explicit user action, creates or updates an ordinary Field Session through injected WorkSessionService.
 * Related code: location-explorer-controller.js, work-sessions/work-session-service.js, field-session/field-session-controller.js.
 */
const UPCLocationExplorerTagService=(()=>{
 'use strict';
 const PRIMARY=['NIF','Price Change','General Review'];
 const SUPPLEMENTAL=['Missing Label','Duplicate Item'];
 const ALLOWED=[...PRIMARY,...SUPPLEMENTAL];
 const normalize=x=>String(x??'').trim();
 function create({sessionService,getCurrentSession,setCurrentSession,newId,sessionName,confirmUser,onSaved}={}){
  if(!sessionService||typeof getCurrentSession!=='function'||typeof setCurrentSession!=='function'||typeof newId!=='function'||typeof confirmUser!=='function')throw Error('Field Session tag handoff dependencies missing');
  async function add({placement,details,tags}={}){
   if(!placement||!details||!Array.isArray(tags))throw Error('Select an item and its review tags first');
   const selected=[...new Set(tags.filter(tag=>ALLOWED.includes(tag)))];
   if(!selected.length)throw Error('Select at least one tag before adding this item to a list');
   const sku=normalize(details.sku==='—'?'':details.sku||placement.skuKey),upc=normalize(details.upc==='—'?'':details.upc||placement.upcKey);
   if(!upc||!/^[0-9]{8,14}$/.test(upc))throw Error('A verified product UPC is required to add a Field Session tag. Scan its barcode or look up the product first.');
   const now=new Date().toISOString(),day=typeof sessionName==='function'?sessionName():now.slice(0,10);
   const active=getCurrentSession(),usable=active?.sessionType==='FIELD_SESSION';
   let base=usable?active:null;
   if(!base){
    const previous=typeof sessionService.list==='function'?await sessionService.list():[];
    const prior=(previous||[]).find(item=>item.sessionType==='FIELD_SESSION'&&item.planogramTagListDay===day);
    if(prior)base=typeof sessionService.open==='function'?(await sessionService.open(prior.id)||prior):prior;
   }
   if(!base){
    const ok=await confirmUser('No ordinary Field Session tag list is available for this session. Create a Planogram Tags list for these selected items? Simply browsing planograms does not create lists.','Create Tag List',{okLabel:'Create Tag List'});
    if(!ok)return{status:'CANCELLED'};
    base={id:newId(),name:'Planogram Tags · '+day,planogramTagListDay:day,
     createdAt:now,updatedAt:now,defaultTag:PRIMARY.find(t=>selected.includes(t))||'General Review',
     sessionType:'FIELD_SESSION',items:[],captures:[],promptLabelPriceAfterScan:false,autoAddPriceDifference:false};
   }
   const next={...base,items:[...(base.items||[])]},prevIndex=next.items.findIndex(p=>normalize(p.upc)===upc);
   const existing=prevIndex>=0?next.items[prevIndex]:null;
   const combined=[...new Set([...(existing?.tags||[]),...selected])];
   const primary=PRIMARY.find(t=>combined.includes(t))||existing?.primaryPurpose||'General Review';
   if(!combined.includes(primary))combined.unshift(primary);
   const supplements=combined.filter(t=>PRIMARY.includes(t)&&t!==primary);
   const fields=details.product||{},product={
    ...fields,id:existing?.id||newId(),upc,sku,description:normalize(details.description)||existing?.description||'Product review',
    addedAt:existing?.addedAt||now,scannedAt:now,lookupStatus:details.catalogFound?'FOUND':'NOT_FOUND',
    tags:combined,primaryPurpose:primary,supplementalPurposes:supplements,
    libraryPrice:existing?.libraryPrice??(details.retail!=null&&Number.isFinite(Number(details.retail))?Number(details.retail):null),
    aceNetPrice:existing?.aceNetPrice??null,labelPrice:existing?.labelPrice??null,
    priceDifference:existing?.priceDifference??null,
    planogramReview:{modularId:placement.modularId||null,source:'EXPLORER'}
   };
   if(existing)next.items[prevIndex]={...existing,...product};
   else next.items.push(product);
   if(base.createdAt===now)await sessionService.create(next);
   else await sessionService.save(next);
   setCurrentSession(next);
   onSaved?.();
   return{status:existing?'UPDATED':'ADDED',name:next.name,count:next.items.length,upc};
  }
  return Object.freeze({add});
 }
 return Object.freeze({create});
})();
