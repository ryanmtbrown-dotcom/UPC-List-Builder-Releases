/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/store-locations/location-maintenance-controller.js
 * Owner: Store Locations / premium location maintenance UI.
 * Role: Task-separated physical assignments and reusable area management.
 * Responsibility: Exact 4-foot section ranges, visual occupancy warnings, intentional shared-space confirmation.
 * Does not own: Raw IndexedDB, PDF extraction, official source membership, DSD or pricing.
 * Side effects: DOM presentation and explicit validated location repository mutations.
 * Related code: location-repository.js, location-policy.js, location-maintenance.css, planogram-import-controller.js.
 */
const UPCLocationMaintenanceController=(()=>{
'use strict';
function create({repository,policy,verification,elementById,showScreen,documentRef=document}={}){
 if(!repository||!policy||typeof elementById!=='function'||typeof showScreen!=='function')throw Error('Location UI dependencies missing');
 const $=elementById,doc=documentRef;
 let areas=[],modules=[],sources=[],editingAreaId=null,editingModularId=null,planogramRefresh=null,confirmUser=null,workRefresh=null,openVisual=null;
 let pendingFingerprint='',pendingConflicts=[];let selectedAisleId='',selectedModularId='';
 const make=(tag,cls,value)=>{const el=doc.createElement(tag);if(cls)el.className=cls;if(value!=null)el.textContent=value;return el};
 const set=(id,value)=>{const e=$(id);if(e)e.textContent=value};
 const namedArea=a=>a.kind==='AISLE'?'Aisle '+(a.aisle||a.id)+(a.side==='LEFT'?' · Left':a.side==='RIGHT'?' · Right':''):a.name;
 const areaOf=m=>areas.find(a=>a.id===m.areaId)||m.area;
 const namesOf=m=>m.physicalSectionIds?.length?'Sections '+m.physicalSectionIds.join(', '):'Fixture '+(m.fixtureId||'—');
 const status=(value,kind='info')=>{const e=$('locationMessage');e.textContent=value;e.dataset.kind=kind;e.classList.toggle('hidden',!value)};
 const numeric=(v)=>/^\d+$/.test(String(v))?Number(v):NaN;
 function physicalSections(){
  const a=numeric($('locationStartSection').value),b=numeric($('locationEndSection').value);
  if(!Number.isSafeInteger(a)||!Number.isSafeInteger(b)||a<1||b<a||a>9999||b>9999||b-a>=200)return null;
  return Array.from({length:b-a+1},(_,i)=>String(a+i));
 }
 function overlapFingerprint({name,areaId,sections,fixtureId,conflicts}){
  return JSON.stringify([editingModularId||'',name,areaId,sections,fixtureId,
   conflicts.map(x=>[x.otherId,[...x.sections].sort().join(',')])]);
 }
 function draft(approvals=[]){
  const area=areas.find(a=>a.id===$('locationModularArea').value&&a.active!==false);
  if(!area)throw Error('Choose a saved aisle or custom area first.');
  const source=sources.find(s=>s.id===$('locationPlanogramChoice').value);const name=$('locationModularName').value.trim()||source?.shortName||source?.name||'';
  if(!name)throw Error('Give this modular a name (for example, Tape).');
  const sections=area.kind==='AISLE'?physicalSections():[];
  if(!sections||area.kind==='AISLE'&&sections.some(n=>!createdSections(area).includes(n)))
   throw Error('Choose consecutive sections that are created in this aisle.');
  if(area.kind==='AISLE'&&sections.length>200)throw Error('One modular may claim at most 200 adjacent bays.');
  const fixtureId=area.kind==='CUSTOM'?$('locationFixtureId').value.trim()||null:null;
  if(area.kind==='CUSTOM'&&!fixtureId)throw Error('Enter the custom fixture name for this area.');
  return {id:editingModularId||'pending-preview',name,active:true,
   area:{kind:area.kind,id:area.id,aisle:area.aisle,side:area.side},physicalSectionIds:sections,fixtureId,overlapApprovals:approvals};
 }
 function createdSections(area){
  if(!area||area.kind!=='AISLE')return [];
  const ids=new Set();
  const initial=Array.isArray(area.sectionIds)?area.sectionIds:
   Number.isSafeInteger(area.sectionCount)&&area.sectionCount>0?
    Array.from({length:Math.min(200,area.sectionCount)},(_,i)=>String(i+1)):[];
  for(const id of initial)if(/^[1-9]\d*$/.test(String(id))&&Number(id)<=9999)ids.add(String(Number(id)));
  // Older stores may have assignments but no area section registry.
  for(const m of modules.filter(x=>(x.areaId||x.area?.id)===area.id))
   for(const id of m.physicalSectionIds||[])
    if(/^[1-9]\d*$/.test(String(id))&&Number(id)<=9999)ids.add(String(Number(id)));
  return [...ids].sort((a,b)=>Number(a)-Number(b));
 }
 function addSectionRange(before,start,end){
  const a=Number(start),b=Number(end);
  if(!Number.isSafeInteger(a)||!Number.isSafeInteger(b)||a<1||b<a||b>9999||b-a>=200)
   throw Error('Choose a starting and ending section, up to 200 sections at a time.');
  return [...new Set([...(before||[]),...Array.from({length:b-a+1},(_,i)=>String(a+i))])].sort((a,b)=>Number(a)-Number(b));
 }
 function nextUnusedSection(areaId){
  const area=areas.find(a=>a.id===areaId),occupied=new Set(
   modules.filter(m=>m.active!==false&&(m.areaId||m.area?.id)===areaId).flatMap(m=>m.physicalSectionIds||[]).map(String));
  return createdSections(area).find(id=>!occupied.has(id))||'';
 }
 function populateSectionChoices(){
  const area=areas.find(a=>a.id===$('locationModularArea').value);
  const all=createdSections(area);
  const occupied=new Set(modules.filter(m=>m.active!==false&&(m.areaId||m.area?.id)===area?.id&&m.id!==editingModularId)
   .flatMap(m=>m.physicalSectionIds||[]).map(String));
  const permitted=$('locationOverlapConfirmed').checked?all:all.filter(n=>!occupied.has(n));
  const first=$('locationStartSection'),last=$('locationEndSection');
  const oldStart=first.value,oldEnd=last.value;
  first.replaceChildren();
  for(const id of permitted){const o=make('option','','Section '+id);o.value=id;first.append(o)}
  first.value=permitted.includes(oldStart)?oldStart:permitted[0]||'';
  last.replaceChildren();
  const start=Number(first.value);
  for(const id of permitted){
   const end=Number(id);
   if(end<start)continue;
   if(end-start>=200)break;
   const span=Array.from({length:end-start+1},(_,i)=>String(start+i));
   if(span.some(x=>!permitted.includes(x)))break;
   const o=make('option','','Section '+id);o.value=id;last.append(o);
  }
  last.value=[...last.options].some(o=>o.value===oldEnd)?oldEnd:first.value;
 }
 function startNewAssignment(areaId){
  const area=areas.find(a=>a.id===areaId&&a.active!==false);
  if(!area){$('locationAreaManager').open=true;$('locationAreaManager').scrollIntoView?.({block:'start'});return}
  const created=createdSections(area);
  if(area.kind==='AISLE'&&!created.length){
   selectedAisleId=area.id;renderModulars();
   $('locationAddSectionStart').scrollIntoView?.({block:'center'});
   return status('Create at least one four-foot section in this aisle before assigning a modular.','warning');
  }
  resetModular();selectedAisleId=area.id;selectedModularId='';
  $('locationModularArea').value=area.id;
  $('locationOverlapConfirmed').checked=false;
  $('locationStartSection').value='';$('locationEndSection').value='';
  $('locationPlanogramChoice').value='';$('locationAssignmentDisclosure').open=true;
  renderModulars();renderAssignmentPreview();$('locationModularName').scrollIntoView?.({block:'center'});
 }
 async function removeSection(){
   const id=$('locationAisleBrowse').value,area=areas.find(a=>a.id===id);
   const section=$('locationRemoveSectionChoice').value;
   if(!area||!section)return status('Choose an aisle and a created section.','error');
   const holders=modules.filter(m=>(m.areaId||m.area?.id)===id&&(m.physicalSectionIds||[]).includes(section));
   if(holders.length)return status('Section '+section+' is assigned to '+holders.map(m=>m.name).join(', ')+'. Move or remove its modular first.','warning');
   if(!confirmUser||!await confirmUser('Remove section '+section+' from '+namedArea(area)+'? All other sections and modulars stay unchanged.','Remove Four-Foot Section',{okLabel:'Remove Section'}))return;
   try{await repository.removeSections(id,[section]);await refresh(id);status('Section '+section+' removed. Other sections and modulars are unchanged.')}
   catch(e){status('Section not removed: '+e.message,'error')}
  }
  async function removeArea(area){
   if(modules.some(m=>(m.areaId||m.area?.id)===area.id))return status('Remove or relocate every modular in '+namedArea(area)+' before deleting it.','warning');
   if(!confirmUser||!await confirmUser('Delete '+namedArea(area)+' and its created sections? Original Ace planograms remain in the library.','Delete Store Area',{okLabel:'Delete Area'}))return;
   try{await repository.removeArea(area.id);selectedAisleId='';selectedModularId='';resetArea();await refresh();
    status(namedArea(area)+' deleted. Other store areas are unchanged.')}
   catch(e){status('Area not deleted: '+e.message,'error')}
  }
  async function removeModular(modular){
   if(verification){
    const entry=(await verification.summary()).find(x=>x.modularId===modular.id);
    if(entry?.guided||entry?.visual)return status('Finish or discard unfinished physical or visual work for '+modular.name+' before removing it.','warning');
   }
   const source=sources.find(s=>s.current===true&&s.modularId===modular.id);
   const placements=await repository.listPlacements(modular.id);
   if(!confirmUser||!await confirmUser('Remove '+modular.name+' from its location? This clears '+placements.length+' current product placement'+(placements.length===1?'':'s')+
    (source?' and returns '+(source.shortName||source.name||source.planogramId)+' to the unassigned Ace planogram library':'')+
    '. Other modulars and original Ace merchandise records remain unchanged.',
    'Remove Modular Assignment',{okLabel:'Remove Assignment'}))return;
   try{await repository.removeModular(modular.id);if(editingModularId===modular.id)resetModular();
    selectedModularId='';await refresh(modular.areaId||modular.area?.id);
    status(modular.name+' removed. Its four-foot sections are available for another modular.')}
   catch(e){status('Assignment not removed: '+e.message,'error')}
  }
  async function addSections(){
  const area=areas.find(a=>a.id===$('locationAisleBrowse').value&&a.active!==false);
  if(!area||area.kind!=='AISLE')return status('Choose a saved aisle first.','error');
  let ids;
  try{ids=addSectionRange(createdSections(area),$('locationAddSectionStart').value,$('locationAddSectionEnd').value)}
  catch(e){return status(e.message,'error')}
  try{
   await repository.saveArea({...area,sectionIds:ids});selectedAisleId=area.id;
   await refresh(area.id);status('Sections created for '+namedArea(area)+'. Choose Assign modular to use them.');
  }catch(e){status('Sections not created: '+e.message,'error')}
 }
function renderAssignmentPreview(){
  const preview=$('locationSectionChoices'),warning=$('locationOverlapBox');
  preview.replaceChildren();warning.classList.add('hidden');pendingFingerprint='';pendingConflicts=[];
  populateSectionChoices();
  const area=areas.find(x=>x.id===$('locationModularArea').value);
  $('locationBayFields').classList.toggle('hidden',area?.kind==='CUSTOM');
  $('locationFixtureWrap').classList.toggle('hidden',area?.kind!=='CUSTOM');
  if(!area){preview.append(make('span','locationPreviewQuiet','Choose a saved location to begin.'));return}
  const sections=area.kind==='AISLE'?physicalSections():[];
   if(sections===null){preview.append(make('strong','locationPreviewError','Enter a valid start/end section (1–9999; up to 200 bays per modular).'));return}
  const label=make('strong','locationPreviewTitle',namedArea(area)+' · '+(sections.length?'Sections '+sections[0]+(sections.length>1?'–'+sections.at(-1):'')+' · '+(sections.length*4)+' ft':'Custom fixture'));
  preview.append(label);
  if(area.kind==='AISLE')preview.append(make('small','locationPreviewQuiet','Each section is one specific 4-foot bay, counted from the same end of this aisle face.'));
  const name=$('locationModularName').value.trim(),fixtureId=$('locationFixtureId').value.trim();
  // Do not warn about occupied bays when the user has not started an assignment.
  const incoming={id:editingModularId||'pending-preview',name:name||'New display',area:{kind:area.kind,id:area.id,aisle:area.aisle,side:area.side},physicalSectionIds:sections,fixtureId:fixtureId||null,active:true};
  try{
   const check=policy.validateActiveSectionAssignment(incoming,modules);
   if(check.conflicts.length){
    warning.classList.remove('hidden');
    pendingConflicts=check.conflicts;
    const entries=check.conflicts.map(x=>x.otherName+' — '+(x.sections.includes('FIXTURE')?'same fixture':'section'+(x.sections.length>1?'s':'')+' '+x.sections.join(', ')));
    set('locationOverlapDescription','Shared with '+entries.join('; ')+'. Uncheck Allow overlapping sections to choose unused bays instead.');
    pendingFingerprint=overlapFingerprint({name,areaId:area.id,sections,fixtureId,conflicts:check.conflicts});
   }else set('locationOverlapDescription','');
  }catch(e){preview.append(make('span','locationPreviewError',e.message))}
 }
 function renderAreas(preferId=''){
  const list=$('locationAreaList'),selector=$('locationModularArea'),old=preferId||selector.value||selectedAisleId;
  list.replaceChildren();selector.replaceChildren();
  const empty=make('option','','Choose aisle or custom area…');empty.value='';selector.append(empty);
  const active=areas.filter(a=>a.active!==false).sort((a,b)=>namedArea(a).localeCompare(namedArea(b),undefined,{numeric:true}));
  for(const area of active){
   const option=make('option','',namedArea(area));option.value=area.id;selector.append(option);
   const row=make('div','locationSavedRow'),info=make('div','locationSavedCopy');
   const assigned=modules.filter(m=>m.active!==false&&(m.areaId||m.area?.id)===area.id);
   const count=createdSections(area).length;
   info.append(make('strong','',namedArea(area)),make('small','',area.kind==='AISLE'?count+' created section'+(count===1?'':'s')+' · '+assigned.length+' modular'+(assigned.length===1?'':'s'):assigned.length+' modular'+(assigned.length===1?'':'s')));
   const edit=make('button','secondary','Edit area');edit.type='button';
   edit.addEventListener('click',()=>{
    editingAreaId=area.id;$('locationAreaManager').open=true;$('locationAreaKind').value=area.kind;
    $('locationAreaName').value=area.kind==='AISLE'?(area.aisle||area.id):area.name;
    $('locationAreaSide').value=area.kind==='AISLE'?(area.side||'UNSPECIFIED'):'UNSPECIFIED';
    $('locationInitialSectionEnd').value='';setAreaInputLabel();$('locationAreaSave').textContent='Save changes';
    $('locationAreaName').scrollIntoView?.({block:'center'});
   });
   const assign=make('button','secondary','Assign planogram');assign.type='button';
   assign.addEventListener('click',()=>openPlanogramAssignment(area.id));
   const remove=make('button','locationDangerAction','Delete area');remove.type='button';
   remove.addEventListener('click',()=>void removeArea(area).catch(e=>status(e.message,'error')));
   row.append(info,edit,assign,remove);list.append(row);
  }
  if(active.some(a=>a.id===old))selector.value=old;
  if(!active.length)list.append(make('p','locationEmpty','No saved aisles yet. Create an aisle to begin.'));
 }
function renderModulars(){
 const aisle=$('locationAisleBrowse'),select=$('locationDisplayBrowse'),host=$('locationModularList');
 aisle.replaceChildren();select.replaceChildren();host.replaceChildren();
 let o=make('option','','Choose aisle…');o.value='';aisle.append(o);
 for(const area of areas.filter(a=>a.active!==false).sort((a,b)=>namedArea(a).localeCompare(namedArea(b),undefined,{numeric:true}))){o=make('option','',namedArea(area));o.value=area.id;aisle.append(o)}
 if(areas.some(a=>a.id===selectedAisleId&&a.active!==false))aisle.value=selectedAisleId;
  else if(aisle.options.length>1){aisle.selectedIndex=1;selectedAisleId=aisle.value;}
 const matches=modules.filter(m=>(m.areaId||m.area?.id)===aisle.value).sort((a,b)=>a.name.localeCompare(b.name));
  const occupied=$('locationAisleAssignments');occupied.replaceChildren();const bySection=new Map();
  for(const m of matches.filter(m=>m.active!==false))for(const n of m.physicalSectionIds||[]){
   if(!bySection.has(String(n)))bySection.set(String(n),[]);
   bySection.get(String(n)).push(m.name);
  }
  if(bySection.size){
   occupied.append(make('strong','locationSectionLabel','ASSIGNED FOUR-FOOT SECTIONS'));
   for(const [n,names] of [...bySection].sort((a,b)=>Number(a[0])-Number(b[0])))
    occupied.append(make('p',names.length>1?'locationOccupancyShared':'locationOccupancyRow',
      'Section '+n+' · '+names.join(' + ')+(names.length>1?' · Shared space':'')));
  }else occupied.append(make('p','locationHelp',aisle.value?'No modulars assigned yet. Start with section 1.':'Choose an aisle to see assigned sections.'));
  if(aisle.value){
   const selectedArea=areas.find(a=>a.id===aisle.value),created=createdSections(selectedArea);
   occupied.append(make('p','locationHelp',created.length?
    'Created sections: '+created.join(', ')+(nextUnusedSection(aisle.value)?' · Next available: '+nextUnusedSection(aisle.value):' · No unused sections'):
    'No four-foot sections created yet. Add a range below.'));
   const following=created.length?String(Math.max(...created.map(Number))+1):'1';
   $('locationAddSectionStart').value=following;$('locationAddSectionEnd').value=following;
  }
  $('locationAddSectionsWrap').classList.toggle('hidden',!aisle.value||areas.find(a=>a.id===aisle.value)?.kind!=='AISLE');
   const removeChoice=$('locationRemoveSectionChoice'),priorSection=removeChoice.value;
   removeChoice.replaceChildren();const blank=make('option','','Choose a created section…');blank.value='';removeChoice.append(blank);
   const selectedArea=areas.find(a=>a.id===aisle.value);
   for(const n of createdSections(selectedArea)){
    const holders=matches.filter(m=>(m.physicalSectionIds||[]).includes(n));
    const option=make('option','','Section '+n+(holders.length?' · In use: '+holders.map(m=>m.name).join(', '):' · Available'));
    option.value=n;option.disabled=holders.length>0;removeChoice.append(option);
   }
   if([...removeChoice.options].some(o=>o.value===priorSection&&!o.disabled))removeChoice.value=priorSection;

 o=make('option','','Choose display…');o.value='';select.append(o);
 for(const m of matches){o=make('option','',m.name+' · '+namesOf(m));o.value=m.id;select.append(o)}
 if(matches.some(m=>m.id===selectedModularId))select.value=selectedModularId;
  else if(matches.length){select.selectedIndex=1;selectedModularId=select.value;}
 const m=matches.find(m=>m.id===select.value);
 if(!m){host.append(make('p','locationEmpty',aisle.value?'Choose a display to see its information.':'Choose an aisle to see its planograms.'));return}
 const source=sources.find(s=>s.current&&s.modularId===m.id),row=make('div','locationSelectedDetail');
 row.append(make('strong','',m.name),make('p','locationHelp',namesOf(m)+' · '+(source?'Ace: '+(source.shortName||source.name||source.planogramId):'No Ace source')+(m.active===false?' · Inactive':'')));
 const tools=make('div','locationButtonRow'),edit=make('button','secondary','Edit assignment'),toggle=make('button','locationQuiet',m.active===false?'Activate':'Deactivate');
 edit.type='button';edit.dataset.locationEdit=m.id;
 edit.addEventListener('click',()=>{
   editingModularId=m.id;$('locationAssignmentDisclosure').open=true;
   $('locationModularArea').value=m.areaId||m.area?.id||'';$('locationModularName').value=m.name;
   $('locationFixtureId').value=m.fixtureId||'';$('locationPlanogramChoice').value=source?.id||'';
   const conflicts=policy.validateActiveSectionAssignment({...m,area:areaOf(m)},modules).conflicts;
   $('locationOverlapConfirmed').checked=conflicts.length>0;
   const nums=(m.physicalSectionIds||[]).map(Number).filter(Number.isInteger).sort((a,b)=>a-b);
   $('locationStartSection').value=nums.length?String(nums[0]):'';
   $('locationEndSection').value=nums.length?String(nums.at(-1)):'';
   $('locationModularSave').textContent='Save assignment changes';$('locationModularCancel').classList.remove('hidden');
   renderAssignmentPreview();$('locationAssignmentDisclosure').scrollIntoView?.({block:'start'});
  });
 toggle.type='button';toggle.addEventListener('click',async()=>{const active=m.active===false;if(!confirmUser||!await confirmUser((active?'Activate ':'Deactivate ')+m.name+'? Saved placements will remain intact.','Confirm display status'))return;try{await repository.saveModular({...m,active});await refresh()}catch(e){status(e.message,'error')}});
 const remove=make('button','locationDangerAction','Remove modular');remove.type='button';
 remove.addEventListener('click',()=>void removeModular(m).catch(e=>status(e.message,'error')));
 tools.append(edit,toggle,remove);row.append(tools);host.append(row);
}
function renderSources(){
 const select=$('locationPlanogramChoice'),prior=select.value;select.replaceChildren();
 let opt=make('option','','Select imported Ace planogram…');opt.value='';select.append(opt);
 for(const s of sources.filter(s=>s.current).sort((a,b)=>(a.shortName||a.name).localeCompare(b.shortName||b.name))){opt=make('option','',(s.shortName||s.name||s.planogramId)+(s.modularId?' · assigned':''));opt.value=s.id;select.append(opt)}
 if(sources.some(s=>s.id===prior&&s.current))select.value=prior;
}
async function refreshOverview(){
  const host=$('locationVerificationList');if(!host||!verification)return;
  host.replaceChildren();
  const displays=await verification.summary();
  if(!displays.length||!selectedModularId){host.append(make('p','locationEmpty',displays.length?'Select an aisle and display to see its audit status.':'No saved display audits yet.'));return}
  for(const display of displays.filter(x=>x.modularId===selectedModularId)){
   const modular=modules.find(x=>x.id===display.modularId),area=modular?areaOf(modular):null;
   const source=sources.find(x=>x.current===true&&x.modularId===display.modularId);
   const card=make('details','locationVerificationItem'),head=make('summary','locationVerificationName'),summary=make('strong','',display.name);
   const place=area?(namedArea(area)+' · '+namesOf(modular)):'Location unavailable';
   const flags=[place,source?'Ace: '+(source.name||source.planogramId):'No Ace source assigned'];
   if(display.guided)flags.push('Unfinished '+(display.guided.mode==='AUDIT'?'physical audit':'layout build')+' · '+display.guided.recorded+' scans');
   if(display.visual)flags.push('Unfinished visual review · '+display.visual.edits+' edits');
   let proof=display.latest;
   if(proof){
    let valid=false;
    try{const e=await verification.evidence(display.modularId);valid=e.sourceSignature===proof.sourceSignature&&e.layoutFingerprint===proof.layoutFingerprint}catch{}
    const method=({VISUAL_ACE_MATCH:'Visually confirmed to match Ace',VISUAL_STORE_LAYOUT:'Visual store-layout confirmation',
     GUIDED_PHYSICAL_AUDIT:'Physical scan audit',GUIDED_LAYOUT_BUILD:'Scanned floor-layout build',
     GUIDED_LAYOUT_CORRECTION:'Scanned layout correction'})[proof.method]||'Verification';
    flags.push((valid?'Verified':'Prior verification — layout or Ace source has changed')+' · '+method+(proof.complete===false?' (partial)':'')+' · '+new Date(proof.confirmedAt).toLocaleDateString());
   }else if(display.legacy)flags.push('Previous visual confirmation · '+(display.legacy.kind==='ACE'?'Ace match':'Store layout')+' · '+new Date(display.legacy.confirmedAt).toLocaleDateString()+' (earlier version, review current revision)');
   else flags.push('Not yet verified');
   head.append(summary,make('small','',flags.join(' | ')));card.append(head);
   const tools=make('div','locationVerificationActions');
   const add=(label,fn)=>{const b=make('button','secondary',label);b.type='button';b.addEventListener('click',()=>{void Promise.resolve().then(fn).catch(e=>status(e.message,'error'))});tools.append(b)};
   add(display.visual?'Resume Visual':'Visual Review',()=>openVisual?.(display.modularId));
   add(display.guided?'Resume Guided':'Guided Audit',()=>openWork(display.modularId));
   add('Physical Assignment',()=>openAssignment(display.modularId));
   add('Ace Assignment',()=>openSourceAssignment(display.modularId));
   card.append(tools);host.append(card);
  }
 }
 async function openAssignment(modularId){
  showScreen('locationScreen','Planograms & Locations');showTab('layout');await refresh();
  const selected=modules.find(m=>m.id===modularId);selectedAisleId=selected?.areaId||'';selectedModularId=modularId;renderModulars();
   const button=[...doc.querySelectorAll('#locationModularList [data-location-edit]')].find(b=>b.dataset.locationEdit===modularId);
  if(!button)throw Error('Physical display assignment was not found');
  button.click();$('locationModularName').scrollIntoView?.({block:'center'});
 }
 async function openWork(modularId){
  showScreen('locationScreen','Planograms & Locations');showTab('work');await refresh();
  const input=$('locationWorkModular');input.value=modularId;input.dispatchEvent(new Event('change',{bubbles:true}));
  $('locationWorkHeading').scrollIntoView?.({block:'start'});
 }
 async function openSourceAssignment(modularId){
  showScreen('locationScreen','Planograms & Locations');showTab('planograms');await refresh();
  if(planogramRefresh)await planogramRefresh();
  const input=$('planogramModularAssignSelect');input.value=modularId;input.dispatchEvent(new Event('change',{bubbles:true}));
 }
 async function refresh(preferArea=''){
  try{[areas,modules,sources]=await Promise.all([repository.listAreas(),repository.listModulars(),repository.listSources()]);
   // Resolve older saved layouts whose authoritative area reference is only areaId.
   modules=modules.map(m=>m.area?m:{...m,area:areas.find(a=>a.id===m.areaId)||null});
   renderAreas(preferArea);renderModulars();renderSources();populateSectionChoices();renderAssignmentPreview();
   await refreshOverview();
   if(workRefresh)void Promise.resolve().then(workRefresh).catch(()=>{});
   if(!areas.some(a=>a.active!==false))$('locationAreaManager').open=true;
  }catch(e){status('Could not load saved locations: '+e.message,'error')}
 }
 function openPlanogramAssignment(areaId){
  showTab('planograms');
  Promise.resolve(planogramRefresh?.()).then(()=>{
   if($('planogramAssignArea')){$('planogramAssignArea').value=areaId;$('planogramAssignArea').dispatchEvent(new Event('change',{bubbles:true}))}
  }).catch(error=>status('Could not open planogram assignment: '+error.message,'error'));
 }
 function showTab(name){
  for(const [mode,tab,pane] of [['layout','locationLayoutTab','locationLayoutPane'],['work','locationWorkTab','locationWorkPane'],['planograms','locationPlanogramTab','locationPlanogramPane']]){
   const active=mode===name;$(tab).classList.toggle('active',active);$(tab).setAttribute('aria-selected',String(active));
   $(pane).classList.toggle('hidden',!active);
  }
  if(name==='planograms'&&planogramRefresh)void Promise.resolve().then(planogramRefresh).catch(()=>{});
 }
 async function open(){showScreen('locationScreen','Planograms & Locations');showTab('layout');await refresh()}
 function resetArea(){editingAreaId=null;$('locationAreaName').value='';$('locationInitialSectionEnd').value='';$('locationAreaSide').value='UNSPECIFIED';$('locationAreaSeparate').checked=false;
  $('locationAreaSeparateWrap').classList.add('hidden');$('locationAreaSave').textContent='Save area';set('locationAreaSuggestions','')}
 function resetModular(){editingModularId=null;$('locationModularName').value='';$('locationFixtureId').value='';
  $('locationModularSave').textContent='Save display location';$('locationModularCancel').classList.add('hidden');
  $('locationStartSection').value='';$('locationEndSection').value='';$('locationOverlapConfirmed').checked=false;renderAssignmentPreview()}
 function setAreaInputLabel(){$('locationInitialSectionWrap').classList.toggle('hidden',$('locationAreaKind').value!=='AISLE');$('locationAreaSideWrap').classList.toggle('hidden',$('locationAreaKind').value!=='AISLE');set('locationAreaNameLabelText',$('locationAreaKind').value==='AISLE'?'Aisle number':'Custom area name');
  $('locationAreaName').placeholder=$('locationAreaKind').value==='AISLE'?'Example: 8':'Example: Behind Counter'}
 async function saveArea(){
  const kind=$('locationAreaKind').value,raw=$('locationAreaName').value.trim();
  if(!raw)return status('Enter the aisle number or custom area name.','error');
  if(kind==='AISLE'&&!/^\d{1,3}[A-Za-z]?$/.test(raw))return status('Enter an aisle number such as 8 or 8A.','error');
  const side=kind==='AISLE'?policy.normalizeAisleSide($('locationAreaSide').value):'UNSPECIFIED';
  const name=kind==='AISLE'?'Aisle '+raw+(side==='LEFT'?' · Left':side==='RIGHT'?' · Right':''):raw;
  const candidates=policy.findPotentialAreaDuplicates(name,areas,editingAreaId);
  if(candidates.some(x=>x.match==='EXACT')){set('locationAreaSuggestions','This aisle already exists. Use Edit area or Assign modular in the full Saved Areas list below.');return status('Duplicate area blocked.','error')}
  const near=candidates.find(c=>c.match==='REVIEW'&&!(areas.find(a=>a.id===c.id)?.kind==='AISLE'&&areas.find(a=>a.id===c.id)?.aisle===raw));
  if(near&&!$('locationAreaSeparate').checked){set('locationAreaSuggestions','Possibly the same place as '+near.name+'. Select the existing area or confirm these really differ.');
   $('locationAreaSeparateWrap').classList.remove('hidden');return status('Confirm which area you mean.','warning')}
  const prior=areas.find(a=>a.id===editingAreaId);
  const id=editingAreaId||(kind==='AISLE'?'aisle-'+raw+(side==='LEFT'?'-left':side==='RIGHT'?'-right':''):doc.defaultView?.crypto?.randomUUID?.()||'area-'+Date.now().toString(36));
  let sectionIds=prior&&prior.kind==='AISLE'?createdSections(prior):[];
  if(kind==='AISLE'&&$('locationInitialSectionEnd').value.trim()){
   try{sectionIds=addSectionRange(sectionIds,'1',$('locationInitialSectionEnd').value.trim())}
   catch(e){return status(e.message,'error')}
  }
  const data=kind==='AISLE'?{id,kind,name,aisle:raw,side,sectionCount:null,sectionIds,active:true}:{id,kind,name,active:true};
  try{await repository.saveArea(prior?{...prior,...data}:data);selectedAisleId=id;resetArea();await refresh(id);$('locationAreaManager').open=false;
   // Sections are independent physical inventory. Do not automatically open modular assignment.
   status(namedArea(data)+' saved. '+(sectionIds.length?'Choose Assign modular to place a planogram.':'Create your four-foot sections, then assign modulars.'))}
  catch(e){status('Area not saved: '+e.message,'error')}
 }
 async function saveModular(){
  let input;
  try{input=draft()}catch(e){return status(e.message,'error')}
  const check=policy.validateActiveSectionAssignment(input,modules);
  let confirmed=[];
  if(check.conflicts.length){
   const mark=overlapFingerprint({name:input.name,areaId:input.area.id,sections:input.physicalSectionIds,fixtureId:input.fixtureId||'',conflicts:check.conflicts});
   if(mark!==pendingFingerprint||!$('locationOverlapConfirmed').checked){renderAssignmentPreview();return status('Check Allow overlapping sections and review the named conflicts before saving.','warning')}
   confirmed=check.conflicts.map(x=>({modularId:x.otherId,sections:x.sections,confirmedAt:Date.now()}));
  }
  const sourceId=$('locationPlanogramChoice').value,chosen=sources.find(x=>x.id===sourceId&&x.current);
   // Store-built layouts must remain available without an official Ace planogram.
   if(chosen?.modularId&&chosen.modularId!==editingModularId)return status('That planogram is already assigned. Edit its current display rather than duplicating the assignment.','error');
   if(editingModularId&&chosen&&sources.some(x=>x.current&&x.modularId===editingModularId&&x.id!==sourceId))return status('This display already has another Ace planogram. Review that assignment separately before replacing its source.','error');
   const newId=editingModularId||doc.defaultView?.crypto?.randomUUID?.()||'modular-'+Date.now().toString(36);
  try{const original=modules.find(m=>m.id===editingModularId);const result=await repository.saveModular({...original,...input,id:newId,overlapApprovals:confirmed});
   const detail=input.physicalSectionIds.length?'sections '+input.physicalSectionIds.join('–'):'fixture '+input.fixtureId;
   if(chosen&&!chosen.modularId){
      try{await repository.assignSource({sourceId:chosen.id,modularId:newId,seedIfEmpty:true})}
      catch(e){await refresh(input.area.id);selectedAisleId=input.area.id;selectedModularId=newId;renderModulars();return status('Display location saved, but linking the Ace planogram failed: '+e.message+'. Review this display before proceeding.','error')}
     }
     selectedAisleId=input.area.id;selectedModularId=newId;resetModular();await refresh(input.area.id);
     status(result.name+' assigned to '+detail+(confirmed.length?' with confirmed overlapping sections.':'.'));
  }catch(e){status('No changes saved: '+e.message,'error')}
 }
 function bind(){
  $('openLocations').addEventListener('click',open);
  $('locationLayoutTab').addEventListener('click',()=>showTab('layout'));
  $('locationWorkTab').addEventListener('click',()=>showTab('work'));
  $('locationPlanogramTab').addEventListener('click',()=>showTab('planograms'));
  $('locationGoLayout').addEventListener('click',()=>showTab('layout'));
  const createArea=()=>{$('locationAreaManager').open=true;$('locationAreaManager').scrollIntoView({block:'start',behavior:'smooth'});resetArea();$('locationAreaName').focus()};
  $('locationCreateArea').addEventListener('click',createArea);
  $('locationBrowseCreateArea').addEventListener('click',createArea);
  $('locationAddModularForAisle').addEventListener('click',()=>openPlanogramAssignment($('locationAisleBrowse').value));
  $('locationModularArea').addEventListener('change',()=>{$('locationOverlapConfirmed').checked=false;$('locationStartSection').value='';$('locationEndSection').value='';renderAssignmentPreview()});
  $('locationOverlapConfirmed').addEventListener('change',()=>renderAssignmentPreview());
  $('locationAddSections').addEventListener('click',addSections);
   $('locationRemoveSection').addEventListener('click',removeSection);
  for(const id of ['locationStartSection','locationEndSection','locationFixtureId','locationModularName'])$(id).addEventListener('input',renderAssignmentPreview);
  $('locationStartSection').addEventListener('change',()=>{$('locationEndSection').value='';renderAssignmentPreview()});
  populateSectionChoices();
   $('locationAreaSave').addEventListener('click',saveArea);$('locationAreaCancel').addEventListener('click',resetArea);
  $('locationModularSave').addEventListener('click',saveModular);$('locationModularCancel').addEventListener('click',()=>{resetModular();status('Edit canceled.')});
  $('locationAreaKind').addEventListener('change',()=>{set('locationAreaSuggestions','');$('locationAreaSeparateWrap').classList.add('hidden');setAreaInputLabel()});
  $('locationAisleBrowse').addEventListener('change',()=>{selectedAisleId=$('locationAisleBrowse').value;selectedModularId='';renderModulars();void refreshOverview()});
   $('locationDisplayBrowse').addEventListener('change',()=>{selectedModularId=$('locationDisplayBrowse').value;renderModulars();void refreshOverview()});
   $('locationPlanogramChoice').addEventListener('change',()=>{const src=sources.find(s=>s.id===$('locationPlanogramChoice').value);if(src&&!editingModularId)$('locationModularName').value=src.shortName||src.name||'';renderAssignmentPreview()});
   $('locationAreaName').addEventListener('input',()=>{set('locationAreaSuggestions','');$('locationAreaSeparate').checked=false;$('locationAreaSeparateWrap').classList.add('hidden')});
  setAreaInputLabel();renderAssignmentPreview();
 }
 return Object.freeze({bind,open,refresh,openAssignment,openWork,openSourceAssignment,
  setOpenVisual(callback){openVisual=callback},setPlanogramRefresh(callback){planogramRefresh=callback},
  setConfirmUser(callback){confirmUser=callback},setWorkRefresh(callback){workRefresh=callback}});
}
return Object.freeze({create});
})();
