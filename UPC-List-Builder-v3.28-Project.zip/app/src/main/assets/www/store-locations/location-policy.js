/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/store-locations/location-policy.js
 * Owner: Store Locations (B1.1 pure policy)
 * Role: Pure area, assignment, placement, provenance and location-formatter rules.
 * Responsibility: Normalize valid location drafts and reject conflicting/invented position claims.
 * Does not own: IndexedDB, HTML/DOM, network, PDF extraction, product catalog or active workflow.
 * Side effects: None.
 * Related code: STORE_LOCATION_CONTRACT.md, PLANOGRAM_IMPORT_CONTRACT.md; future focused repository and UI owners.
 */
const UPCStoreLocationPolicy=(()=>{
'use strict';
const areaName=n=>{
 if(typeof n!=='string')throw Error('Area name must be text');
 let v=n.normalize('NFKC').trim().replace(/\s+/g,' ');
 if(!v||v.length>100||/[\x00-\x1f\x7f]/.test(v))throw Error('Invalid area name');
 return v;
};
const normalizeAreaName=n=>areaName(n).toUpperCase().replace(/[^\p{L}\p{N}]+/gu,' ').trim().replace(/\s+/g,' ');
const expand=n=>normalizeAreaName(n).split(' ').map(t=>({CTR:'COUNTER',CNTR:'COUNTER',FRNT:'FRONT',REG:'REGISTERS'}[t]||t)).join(' ');
function findPotentialAreaDuplicates(name,areas=[],excludeId=null){
 const key=normalizeAreaName(name),expanded=expand(name);
 return areas.filter(a=>a?.active!==false&&a?.id!==excludeId&&typeof a.name==='string')
 .map(a=>{
  const labels=[a.name,...(Array.isArray(a.aliases)?a.aliases:[])].filter(s=>typeof s==='string');
  const exact=labels.some(s=>normalizeAreaName(s)===key);
  let similar=!exact&&labels.some(s=>expand(s)===expanded);
  if(!exact&&!similar){
   const l=new Set(expanded.split(' ')),r=new Set(expand(a.name).split(' '));
   similar=[...l].filter(t=>r.has(t)).length/Math.max(l.size,r.size)>=.67;
  }
  return{id:a.id,name:a.name,match:exact?'EXACT':'REVIEW',candidate:exact||similar};
 }).filter(x=>x.candidate).sort((a,b)=>(a.match==='EXACT'?0:1)-(b.match==='EXACT'?0:1));
}
function normalizeAisleSide(value){const side=String(value??'UNSPECIFIED').trim().toUpperCase();if(!['UNSPECIFIED','LEFT','RIGHT'].includes(side))throw Error('Invalid aisle side');return side}
function validateAreaReference(area){
 if(!area||!['AISLE','CUSTOM'].includes(area.kind)||typeof area.id!=='string'||!area.id.trim())throw Error('Invalid area reference');
 if(area.kind==='AISLE'&&!/^\d{1,3}[A-Za-z]?$/.test(String(area.aisle??area.id)))throw Error('Invalid aisle');
 if(area.kind==='CUSTOM'&&area.name!=null)areaName(area.name);
 const canonical={kind:area.kind,id:area.id.trim()};
 if(area.kind==='AISLE'){canonical.aisle=String(area.aisle??area.id).trim();canonical.side=normalizeAisleSide(area.side)}
 return canonical;
}
function normalizeLocationDraft(d){
 if(!d||typeof d!=='object')throw Error('Location draft required');
 const area=d.area==null?null:validateAreaReference(d.area),ids=d.physicalSectionIds??[];
 if(!Array.isArray(ids)||ids.some(s=>typeof s!=='string'&&!(Number.isInteger(s)&&s>0)))throw Error('Invalid sections');
 const sections=ids.map(s=>String(s).trim());
 if(sections.some(s=>!s)||new Set(sections).size!==sections.length)throw Error('Duplicate/blank section');
 const active=d.active===true,fixtureId=d.fixtureId==null?null:String(d.fixtureId).trim()||null;
 if(active&&!area)throw Error('Active layout requires area');
 if(active&&area.kind==='AISLE'&&!sections.length)throw Error('Active aisle requires section');
 if(active&&area.kind==='CUSTOM'&&!sections.length&&!fixtureId)throw Error('Custom display requires fixture identity');
 const approvals=d.overlapApprovals??[];
 if(!Array.isArray(approvals)||approvals.some(x=>!x||typeof x.modularId!=='string'||!x.modularId.trim()||!Array.isArray(x.sections)||!x.sections.length||x.sections.some(v=>typeof v!=='string'||!(/^[1-9]\d*$/.test(v)||v==='FIXTURE'))))throw Error('Invalid overlap approval evidence');
 const normalizedApprovals=approvals.map(x=>({modularId:x.modularId,sections:[...new Set(x.sections)].sort((a,b)=>Number(a)-Number(b)),confirmedAt:Number.isFinite(x.confirmedAt)?x.confirmedAt:null}));
 const sourceFeet=d.sourceNominalFeet==null?null:Number(d.sourceNominalFeet);
 if(sourceFeet!=null&&(!Number.isFinite(sourceFeet)||sourceFeet<=0||sourceFeet>200))throw Error('Invalid source length');
 return{id:String(d.id||''),name:String(d.name||'').trim(),area,physicalSectionIds:sections,
 sourceSegmentIds:Array.isArray(d.sourceSegmentIds)?d.sourceSegmentIds.map(String):[],sourceNominalFeet:sourceFeet,fixtureId,active,overlapApprovals:normalizedApprovals};
}
function validateActiveSectionAssignment(request,others=[]){
 const draft=normalizeLocationDraft(request),conflicts=[];
 if(draft.active)for(const prior of others){
  if(!prior||prior.active===false||String(prior.id)===draft.id||prior.area?.kind!==draft.area.kind||prior.area?.id!==draft.area.id)continue;
  const old=(prior.physicalSectionIds||[]).map(String);
  let overlap=draft.physicalSectionIds.filter(x=>old.includes(x));
  if(draft.area.kind==='CUSTOM'&&!overlap.length&&draft.fixtureId&&draft.fixtureId===prior.fixtureId)overlap=['FIXTURE'];
  if(overlap.length)conflicts.push({otherId:String(prior.id),otherName:String(prior.name||''),sections:overlap});
 }
 const unapprovedConflicts=conflicts.filter(c=>!draft.overlapApprovals.some(a=>a.modularId===c.otherId&&
   a.sections.length===c.sections.length&&a.sections.every(s=>c.sections.includes(s))));
 return{valid:!unapprovedConflicts.length,conflicts,unapprovedConflicts,draft};
}
function validatePhysicalSectionEdit(request,old,placements=[]){
 const next=normalizeLocationDraft(request),previous=normalizeLocationDraft(old),removedSections=previous.physicalSectionIds.filter(x=>!next.physicalSectionIds.includes(x));
 const orphans=placements.filter(p=>p?.modularId===next.id&&p.physicalSectionId!=null&&removedSections.includes(String(p.physicalSectionId))).map(p=>({placementId:p.id,section:String(p.physicalSectionId)}));
 return{valid:!orphans.length,removedSections,orphans};
}
function normalizePlacement(p){
 if(!p||!String(p.skuKey||p.upcKey||'').trim())throw Error('Placement product identity required');
 if(!['ACE_IMPORT','USER_SCAN','USER_EDIT'].includes(p.origin)||!['HOME','SECONDARY'].includes(p.role??'HOME'))throw Error('Placement origin/role invalid');
 const physicalSectionId=p.physicalSectionId==null?null:String(p.physicalSectionId);
 if(p.origin==='ACE_IMPORT'&&p.physicalEvidence!==true&&(physicalSectionId||p.rowOrdinal!=null||p.columnOrdinal!=null))throw Error('Cannot treat corporate coordinates as physical');
 const ordinal=(n,label)=>{if(n==null||n==='')return null;if(!Number.isSafeInteger(n)||n<=0||n>500)throw Error('Invalid '+label);return n};
 if(p.fixtureType!=null&&!['PEG','SHELF','SPCFIX','OTHER','UNKNOWN'].includes(p.fixtureType))throw Error('Invalid fixture');
 return{id:p.id??null,modularId:String(p.modularId||''),skuKey:p.skuKey??null,upcKey:p.upcKey??null,
 origin:p.origin,role:p.role??'HOME',storeAdded:p.storeAdded===true,physicalSectionId,physicalEvidence:p.physicalEvidence===true,
 rowOrdinal:ordinal(p.rowOrdinal,'row'),columnOrdinal:ordinal(p.columnOrdinal,'column'),observedOrder:ordinal(p.observedOrder,'observed order'),facings:ordinal(p.facings,'facings'),
 fixtureType:p.fixtureType??null,sourceSegment:p.sourceSegment??null,sourceRow:p.sourceRow??null,sourceColumn:p.sourceColumn??null,fixtureZone:p.fixtureZone??null,
 explorerOrder:ordinal(p.explorerOrder,'explorer order'),
 locationNote:typeof p.locationNote==='string'?p.locationNote.trim().slice(0,100):null,
 approvedException:p.approvedException!=null&&p.id!=null&&p.approvedException.placementId===p.id&&p.approvedException.skuKey===(p.skuKey??null)&&String(p.approvedException.physicalSectionId??'')===String(physicalSectionId??'')&&p.approvedException.rowOrdinal===p.rowOrdinal&&p.approvedException.observedOrder===p.observedOrder?p.approvedException:null};
}
function classifySourceMembership(p){
 return p?.sourceMember===true&&p.sourceEvidence?.planogramId&&p.sourceEvidence?.reportRowId
 ?{kind:'OFFICIAL_SOURCE_MEMBER',sourceId:String(p.sourceEvidence.planogramId),rowId:String(p.sourceEvidence.reportRowId)}
 :{kind:p?.storeAdded===true?'STORE_ADDED':'UNVERIFIED',sourceId:null,rowId:null};
}
function updateLastKnownAssociation(existing=[],p){
 if(!p||!['LAST_KNOWN_ACE','LAST_KNOWN_STORE_ADDED'].includes(p.kind)||!String(p.skuKey||'').trim())throw Error('Invalid history evidence');
 if(p.kind==='LAST_KNOWN_ACE'&&(!p.officialEvidence||!p.sourceId))throw Error('Official membership proof required');
 if(p.kind==='LAST_KNOWN_STORE_ADDED'&&(!p.acceptedPhysicalPlacement||!p.areaId))throw Error('Accepted placement proof required');
 const contextId=String(p.contextId||p.sourceId||p.modularId||'');
 if(!contextId)throw Error('Association context missing');
 const next={skuKey:p.skuKey,kind:p.kind,contextId,sourceId:p.sourceId||null,sourceName:p.sourceName||null,
 sourcePosition:p.sourcePosition||null,modularId:p.modularId||null,areaId:p.areaId||null,areaName:p.areaName||null,
 physicalSectionId:p.acceptedPhysicalPlacement===true?(p.physicalSectionId??null):null};
 return[...(Array.isArray(existing)?existing:[]).filter(x=>!(x.skuKey===next.skuKey&&x.kind===next.kind&&x.contextId===contextId)),next];
}
function classifySourceReplacementCandidate(incoming,current){
 if(!current)return{kind:'NEW',requiresConfirmation:false};
 const exact=!!incoming?.planogramId&&String(incoming.planogramId)===String(current.planogramId||'')&&String(incoming.commodityCode||'')===String(current.commodityCode||'');
 return{kind:exact?'EXACT':'POSSIBLE_MATCH',requiresConfirmation:!exact};
}
function validGTIN(value){
 if(!/^\d+$/.test(value)||![8,12,13,14].includes(value.length)||/^0+$/.test(value))return false;
 let n=0;for(let i=value.length-2,m=0;i>=0;i--,m++)n+=Number(value[i])*(m%2===0?3:1);
 return(10-n%10)%10===Number(value.at(-1));
}
function matchGTINToProductKey(gtin,p){
 const s=String(gtin??'').trim();
 if(!validGTIN(s)||!p||typeof p.skuKey!=='string'||!p.skuKey.trim())return null;
 return[p.gtin,p.upc,p.ean].filter(x=>typeof x==='string'&&validGTIN(x)).some(x=>x===s||(s.length===14&&x.length===12&&s==='00'+x))?p.skuKey:null;
}
function formatCompactLocation(d){
 const x=d?.current;
 if(!x)return 'No current location';
 // Area identity is always the aisle, never the modular's descriptive title
 // or its full reserved four-foot section range.
 const face=String(x.aisleSide||'UNSPECIFIED').toUpperCase();
 const place=x.aisle!=null?'A'+String(x.aisle)+(face==='LEFT'?'L':face==='RIGHT'?'R':''):x.areaName||x.fixtureName||'';
 const pieces=[place],fromSource=x.origin==='ACE_IMPORT'&&!x.physicalEvidence;
 // Explicitly mapped Ace source ordinal takes its corresponding reserved bay.
 // Approved physical observations use only their accepted physical section.
 const section=fromSource?x.resolvedSection:(x.physicalEvidence===true?x.physicalSectionId:null);
 if(section!=null&&String(section).trim())pieces.push('S'+String(section).trim());
 else if(fromSource&&x.unmappedSourceSegment!=null)pieces.push('PS'+String(x.unmappedSourceSegment));
 const kind=x.fixtureType||'UNKNOWN';
 const row=fromSource?x.sourceRow:x.rowOrdinal;
 const col=fromSource?x.sourceColumn:x.columnOrdinal;
 const zone=fromSource?x.fixtureZone:x.zone;
 const hasRow=row!=null&&String(row).trim()!=='';
 const hasCol=col!=null&&String(col).trim()!=='';
 const hasZone=zone&&['LFT','L-CNT','CNT','CNT-R','RGT','CL','CTR','CR'].includes(zone);
 const note=String(x.sourcePositionNote||'').trim();
 if(kind==='SPCFIX')pieces.push('SF');
 // Shelf rows are shelf ordinals; never show a bare SH with no shelf number.
 if(kind==='SHELF'){
  if(hasRow)pieces.push('SH'+String(row).trim());
 }else if(hasRow)pieces.push('R'+String(row).trim());
 if(hasCol)pieces.push('C'+String(col).trim());
 if(!fromSource&&!hasCol&&x.observedOrder!=null)pieces.push('ORD'+String(x.observedOrder));
 if(hasZone)pieces.push(zone);
 // Best-effort diagram descriptions remain explicitly source-relative rather
 // than manufactured numeric coordinates.
 if(fromSource&&!hasRow&&!hasCol&&!hasZone){
  if(x.sourcePositionStatus==='DIAGRAM_ESTIMATE'&&note)pieces.push('Ace: '+note);
  else pieces.push('Ace position unknown');
 }
 return pieces.filter(Boolean).join(' · ')||'No location';
}
function formatExpandedLocation(d){
 const x=d?.current,parts=[formatCompactLocation(d)];
 if(x?.sourceSegment!=null)parts.push('Ace source: SRC SEC '+x.sourceSegment);
 if(x?.sourceRow!=null)parts.push('PLANOGRAM ROW '+x.sourceRow);
 if(x?.sourceColumn!=null)parts.push('SOURCE COL '+x.sourceColumn);
 // Source coordinates are valid location evidence until an approved store correction supersedes them.
 if(!x&&d?.currentSource?.sourceMember===true)parts.push('Current Ace planogram: '+(d.currentSource.name||d.currentSource.id||'Unknown')+' · NOT IN CURRENT LAYOUT');
 if(d?.lastKnown?.kind==='LAST_KNOWN_STORE_ADDED')parts.push('Store-added merchandise; not original Ace source member');
 return parts.join(' | ');
}
return Object.freeze({normalizeAreaName,normalizeAisleSide,findPotentialAreaDuplicates,validateAreaReference,normalizeLocationDraft,
 validateActiveSectionAssignment,validatePhysicalSectionEdit,normalizePlacement,classifySourceMembership,
 updateLastKnownAssociation,classifySourceReplacementCandidate,matchGTINToProductKey,formatCompactLocation,formatExpandedLocation});
})();