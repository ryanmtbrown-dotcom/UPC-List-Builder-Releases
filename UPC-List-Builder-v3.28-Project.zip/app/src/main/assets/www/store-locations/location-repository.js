/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/store-locations/location-repository.js
 * Owner: Store Locations / IndexedDB repository.
 * Role: Atomic current physical locations, official source members and durable product associations.
 * Responsibility: Use indexed read paths and strictly bounded, transactional domain mutations.
 * Does not own: Product catalog identity, PDF parsing, DSD, UI, location policy or native pairing.
 * Side effects: Transactional access to the seven designated store-location IndexedDB stores.
 * Related code: db.js, data-backup.js, store-locations/location-policy.js, STORE_LOCATION_CONTRACT.md.
 */
const UPCLocationRepository=(()=>{
 'use strict';
 const P=UPCStoreLocationPolicy;
 const STORES=Object.freeze(['storeAreas','storeModulars','storeSources','storeSourceMembers','storePlacements','storeHistory','storeImportReceipts']);
 const req=(request)=>new Promise((resolve,reject)=>{request.onsuccess=()=>resolve(request.result);request.onerror=()=>reject(request.error||Error('Location storage request failed'));});
 async function read(stores,callback){
  const db=await UPCDB.open();
  const tx=db.transaction(stores,'readonly');
  const result=callback(tx);
  return result;
 }
 function write(stores,setup){
  return UPCDB.open().then(db=>new Promise((resolve,reject)=>{
   const tx=db.transaction(stores,'readwrite');let result,abortReason=null;
   const fail=error=>{result=null;abortReason=error instanceof Error?error:new Error(String(error||'Location validation refused'));try{tx.abort()}catch{};};
   tx.oncomplete=()=>resolve(result);
   tx.onerror=()=>reject(tx.error||Error('Location transaction failed'));
   tx.onabort=()=>reject(abortReason||tx.error||Error('Location transaction aborted'));
   try{setup(tx,v=>{result=v},fail)}catch(e){fail(e)}
  }));
 }
 async function bySku(skuKey){
  if(typeof skuKey!=='string'||!skuKey.trim())return{placements:[],sourceMembers:[],history:[]};
  return read(['storePlacements','storeSourceMembers','storeHistory'],async tx=>{
   const [placements,sourceMembers,history]=await Promise.all([
    req(tx.objectStore('storePlacements').index('bySku').getAll(skuKey)),
    req(tx.objectStore('storeSourceMembers').index('bySku').getAll(skuKey)),
    req(tx.objectStore('storeHistory').index('bySku').getAll(skuKey))]);
   return{placements,sourceMembers,history};
  });
 }
 async function byUpc(upcKey){
  if(typeof upcKey!=='string'||!upcKey.trim())return{placements:[],sourceMembers:[]};
  return read(['storePlacements','storeSourceMembers'],async tx=>{
   const [placements,sourceMembers]=await Promise.all([
    req(tx.objectStore('storePlacements').index('byUpc').getAll(upcKey)),
    req(tx.objectStore('storeSourceMembers').index('byUpc').getAll(upcKey))]);
   return{placements,sourceMembers};
  });
 }
 async function getArea(id){return UPCDB.get('storeAreas',id)}
 async function getModular(id){return UPCDB.get('storeModulars',id)}
 async function getSource(id){return UPCDB.get('storeSources',id)}
 async function getReceipt(batchId){return UPCDB.get('storeImportReceipts',batchId)}
 async function listAreas(){return UPCDB.all('storeAreas')}
 async function listModulars(){return UPCDB.all('storeModulars')}
 async function listSources(){return UPCDB.all('storeSources')}
 function saveArea(area){
  if(!area||typeof area.id!=='string'||!area.id.trim()||!['AISLE','CUSTOM'].includes(area.kind))throw Error('Valid stable area ID required');
  const side=area.kind==='AISLE'?P.normalizeAisleSide(area.side):'UNSPECIFIED';
  const label=area.kind==='CUSTOM'?String(area.name||''):('Aisle '+String(area.aisle??area.id)+(side==='LEFT'?' · Left':side==='RIGHT'?' · Right':''));
  const nameKey=P.normalizeAreaName(label);
  P.validateAreaReference(area);
  if(area.kind==='AISLE'&&area.sectionCount!=null&&(!Number.isSafeInteger(area.sectionCount)||area.sectionCount<1||area.sectionCount>200))throw Error('Aisle four-foot section count must be 1–200');
  return write(['storeAreas','storeModulars'],(tx,set,fail)=>{
   const store=tx.objectStore('storeAreas'),query=store.getAll(),assignments=tx.objectStore('storeModulars').getAll();
   let ready=0;const verify=()=>{if(++ready<2)return;
    const existing=query.result||[];
    if(area.active===false&&(assignments.result||[]).some(m=>m.active!==false&&m.areaId===area.id))
     return fail(Error('Area has active modular assignments; reassign or deactivate the displays first'));
    if(P.findPotentialAreaDuplicates(label,existing,area.id).some(x=>x.match==='EXACT'))return fail(Error('Duplicate active custom area'));
     const current=existing.find(a=>a.id===area.id);
     if(current&&current.kind==='AISLE'&&(String(current.aisle||'')!==String(area.aisle||'')||P.normalizeAisleSide(current.side)!==side)
      &&(assignments.result||[]).some(m=>(m.areaId||m.area?.id)===area.id))return fail(Error('Aisle face has assigned displays; move them before changing its number or side.'));
     // A saved section registry is authoritative. Do not orphan an assignment.
     if(area.kind==='AISLE'&&Array.isArray(area.sectionIds)){
      const ids=area.sectionIds.map(String);
      if(ids.some(n=>!(/^[1-9][0-9]*$/.test(n))||Number(n)>9999)||new Set(ids).size!==ids.length)
       return fail(Error('Aisle sections must be unique positive numbers up to 9999'));
      const occupied=(assignments.result||[]).filter(m=>(m.areaId||m.area?.id)===area.id)
       .flatMap(m=>m.physicalSectionIds||[]).map(String);
      if(occupied.some(n=>!ids.includes(n)))return fail(Error('Section in use. Remove or relocate the modular before deleting that section.'));
     }
     // No declared aisle-wide maximum is needed. Individual modular assignments own occupied bays.
     // Missing capacity on legacy records stays unknown until user review.
     if(!Array.isArray(area.sectionIds)&&current?.kind==='AISLE'&&current.sectionCount!=null&&area.sectionCount==null)area.sectionCount=current.sectionCount;
    const row={...area,...(area.kind==='AISLE'?{side}:{}),name:label,normalizedName:nameKey,active:area.active!==false};
    store.put(row);set(row);
   };
   query.onsuccess=verify;assignments.onsuccess=verify;
   query.onerror=()=>fail(query.error);assignments.onerror=()=>fail(assignments.error);
  });
 }
 function saveModular(input){
  const draft=P.normalizeLocationDraft(input);
  if(!draft.id)throw Error('Modular stable ID required');
  const entry={...draft,areaId:draft.area?.id||null};
  return write(['storeAreas','storeModulars','storePlacements'],(tx,set,fail)=>{
   const areas=tx.objectStore('storeAreas'),mods=tx.objectStore('storeModulars'),placementStore=tx.objectStore('storePlacements');
   const areaReq=draft.area?areas.get(draft.area.id):null,areaListReq=areas.getAll(),allReq=mods.getAll(),oldReq=mods.get(draft.id),
    placementsReq=placementStore.index('byModular').getAll(draft.id);
   const outstanding=[areaReq,areaListReq,allReq,oldReq,placementsReq].filter(Boolean);let pending=outstanding.length;
   const finish=()=>{if(--pending)return;
    if(draft.area&&(!areaReq.result||areaReq.result.active===false||areaReq.result.kind!==draft.area.kind))return fail(Error('Selected physical area is not active'));
     if(draft.area?.kind==='AISLE'&&Array.isArray(areaReq.result?.sectionIds)){
      const permitted=new Set(areaReq.result.sectionIds.map(String));
      if(draft.physicalSectionIds.some(n=>!permitted.has(n)))return fail(Error('Create the selected four-foot sections before assigning this modular'));
     }
     // Ignore historic sectionCount metadata; protect actual occupied bays through collision and orphan checks.
    const savedAreas=areaListReq.result||[];
    const materialize=m=>{
     if(!m||m.area)return m;
     const saved=savedAreas.find(a=>a.id===m.areaId);
     return saved?{...m,area:{kind:saved.kind,id:saved.id,aisle:saved.aisle,name:saved.name}}:m;
    };
    const otherLayouts=(allReq.result||[]).map(materialize);
    const collision=P.validateActiveSectionAssignment(draft,otherLayouts);
    if(!collision.valid)return fail(Error('Physical sections overlap '+collision.unapprovedConflicts.map(x=>x.otherName+' (sections '+x.sections.join(', ')+')').join('; ')+'. Review and explicitly confirm shared sections.'));
    if(oldReq.result){
     const prior=P.validatePhysicalSectionEdit(draft,materialize(oldReq.result),placementsReq.result||[]);
     if(!prior.valid)return fail(Error('Section edit would orphan '+prior.orphans.length+' merchandise placements'));
    }
    mods.put(entry);set(entry);
   };
   for(const q of outstanding){q.onsuccess=finish;q.onerror=()=>fail(q.error)}
  });
 }
 function removeArea(areaId){
  if(!areaId)throw Error('Choose an aisle or custom area');
  return write(['storeAreas','storeModulars'],(tx,set,fail)=>{
   const areas=tx.objectStore('storeAreas'),modules=tx.objectStore('storeModulars');
   const area=areas.get(areaId),assigned=modules.getAll();let pending=2;
   const done=()=>{if(--pending)return;
    if(!area.result)return fail(Error('Area no longer exists. Refresh the location list.'));
    const holders=(assigned.result||[]).filter(m=>(m.areaId||m.area?.id)===areaId);
    if(holders.length)return fail(Error('Remove or relocate '+holders.map(m=>m.name).join(', ')+' before deleting this area.'));
    areas.delete(areaId);set({removed:true,areaId});
   };
   for(const q of [area,assigned]){q.onsuccess=done;q.onerror=()=>fail(q.error)}
  });
 }
 function removeSections(areaId,sectionIds){
  if(!areaId||!Array.isArray(sectionIds)||!sectionIds.length)throw Error('Choose sections to remove');
  const selected=new Set(sectionIds.map(String));
  if([...selected].some(n=>!(/^[1-9][0-9]*$/.test(n))||Number(n)>9999))
   throw Error('Invalid section number');
  return write(['storeAreas','storeModulars'],(tx,set,fail)=>{
   const areas=tx.objectStore('storeAreas'),modules=tx.objectStore('storeModulars');
   const area=areas.get(areaId),assigned=modules.getAll();let pending=2;
   const done=()=>{if(--pending)return;
    const a=area.result;
    if(!a||a.kind!=='AISLE')return fail(Error('Saved aisle not found'));
    const existing=Array.isArray(a.sectionIds)?a.sectionIds.map(String):
     Number.isInteger(a.sectionCount)&&a.sectionCount>0?
      Array.from({length:a.sectionCount},(_,i)=>String(i+1)):[];
    const occupied=(assigned.result||[]).filter(m=>(m.areaId||m.area?.id)===areaId)
     .flatMap(m=>m.physicalSectionIds||[]).map(String);
    const all=new Set([...existing,...occupied]);
    if([...selected].some(n=>!all.has(n)))return fail(Error('Section no longer exists; refresh before removing it'));
    const blocked=(assigned.result||[]).filter(m=>(m.areaId||m.area?.id)===areaId
      &&(m.physicalSectionIds||[]).some(n=>selected.has(String(n))));
    if(blocked.length)return fail(Error('These sections are assigned to '+blocked.map(m=>m.name).join(', ')+'. Remove or relocate the modular first.'));
    const remaining=[...all].filter(n=>!selected.has(n)).sort((a,b)=>Number(a)-Number(b));
    areas.put({...a,sectionIds:remaining,sectionCount:null});
    set({removed:[...selected],remaining:remaining.length});
   };
   for(const q of [area,assigned]){q.onsuccess=done;q.onerror=()=>fail(q.error)}
  });
 }
 function removeModular(modularId){
  if(!modularId)throw Error('Choose a modular assignment to remove');
  return write(['storeModulars','storePlacements','storeSources','storeHistory'],(tx,set,fail)=>{
   const modules=tx.objectStore('storeModulars'),placements=tx.objectStore('storePlacements'),
    sources=tx.objectStore('storeSources'),history=tx.objectStore('storeHistory');
   const current=modules.get(modularId),rows=placements.index('byModular').getAll(modularId),
    linked=sources.index('byModular').getAll(modularId);let pending=3;
   const done=()=>{if(--pending)return;
    const modular=current.result;
    if(!modular)return fail(Error('Modular assignment no longer exists; refresh before removing it'));
    for(const p of rows.result||[]){
     placements.delete(p.id);
     if(p.storeAdded===true&&p.physicalEvidence===true&&p.skuKey)
      history.put({skuKey:p.skuKey,kind:'LAST_KNOWN_STORE_ADDED',contextId:modularId,
       areaId:modular.areaId||modular.area?.id,modularId,
       physicalSectionId:p.physicalSectionId??null,areaName:null,updatedAt:Date.now()});
    }
    for(const source of linked.result||[])sources.put({...source,modularId:null});
    modules.delete(modularId);
    set({removed:true,modularId,placementsRemoved:(rows.result||[]).length,
     sourcesUnassigned:(linked.result||[]).length});
   };
   for(const q of [current,rows,linked]){q.onsuccess=done;q.onerror=()=>fail(q.error)}
  });
 }
 function replacePlacements(modularId,items){
  if(typeof modularId!=='string'||!modularId||!Array.isArray(items))throw Error('Invalid accepted layout');
  const placements=items.map(x=>P.normalizePlacement(x));
  if(placements.some(x=>x.modularId!==modularId||!x.id))throw Error('Placement ID or modular mismatch');
  if(new Set(placements.map(x=>x.id)).size!==placements.length)throw Error('Duplicate placement ID');
  return write(['storeModulars','storePlacements','storeHistory'],(tx,set,fail)=>{
   const mods=tx.objectStore('storeModulars'),store=tx.objectStore('storePlacements'),history=tx.objectStore('storeHistory');
   const request=mods.get(modularId),old=store.index('byModular').getAll(modularId);let finished=0;
   const accept=()=>{if(++finished<2)return;const modular=request.result;
    if(!modular||modular.active===false)return fail(Error('Modular does not exist or is inactive'));
    for(const x of placements)if(x.physicalSectionId!=null&&!modular.physicalSectionIds.includes(x.physicalSectionId))
      return fail(Error('Physical section is not assigned to modular'));
    const before=old.result||[];
    const continuing=new Set(placements.map(p=>p.id));
    for(const x of before){
     store.delete(x.id);
     if(!continuing.has(x.id)&&x.storeAdded===true&&x.physicalEvidence===true&&x.skuKey){
      history.put({skuKey:x.skuKey,kind:'LAST_KNOWN_STORE_ADDED',contextId:modularId,
       areaId:modular.areaId,modularId,physicalSectionId:x.physicalSectionId??null,
       areaName:null,updatedAt:Date.now()});
     }
    }
    for(const x of placements)store.put(x);set({accepted:true,previousCount:before.length,currentCount:placements.length});
   };
   request.onsuccess=accept;old.onsuccess=accept;request.onerror=()=>fail(request.error);old.onerror=()=>fail(old.error);
  });
 }
 // Build 2: audit reads are scoped to the existing authoritative location stores.
 function listPlacements(modularId){
  if(!modularId)throw Error('Modular required');
  return read(['storePlacements'],tx=>req(tx.objectStore('storePlacements').index('byModular').getAll(modularId)));
 }
 function listSourceMembers(sourceId){
  if(!sourceId)return Promise.resolve([]);
  return read(['storeSourceMembers'],tx=>req(tx.objectStore('storeSourceMembers').index('bySource').getAll(sourceId)));
 }
 function listSourcesForModular(modularId){
  return read(['storeSources'],tx=>req(tx.objectStore('storeSources').index('byModular').getAll(modularId)));
 }
 const sourceSignature=rows=>JSON.stringify((rows||[]).filter(x=>x.current===true).map(x=>x.id+':'+(x.digest||'')).sort());
 // Read, compare and commit in ONE IndexedDB transaction; stale working copies cannot erase accepted locations.
 function approvePhysicalLayout({modularId,items,expectedFingerprint,expectedSourceSignature}){
  if(!modularId||!Array.isArray(items)||typeof expectedFingerprint!=='string'||typeof expectedSourceSignature!=='string')
   throw Error('Reviewed physical layout, accepted revision and source evidence required');
  const proposed=items.map(p=>P.normalizePlacement(p));
  if(proposed.some(p=>p.modularId!==modularId||!p.id)||new Set(proposed.map(p=>p.id)).size!==proposed.length)
   throw Error('Invalid physical placement or duplicate stable ID');
  return write(['storeModulars','storePlacements','storeHistory','storeSources','storeSourceMembers'],(tx,set,fail)=>{
   const mods=tx.objectStore('storeModulars'),placements=tx.objectStore('storePlacements'),
    history=tx.objectStore('storeHistory'),sources=tx.objectStore('storeSources'),members=tx.objectStore('storeSourceMembers');
   const queries=[mods.get(modularId),placements.index('byModular').getAll(modularId),
    sources.index('byModular').getAll(modularId)];
   let pending=queries.length;
   const commit=()=>{if(--pending)return;
    const modular=queries[0].result,before=queries[1].result||[],currentSources=queries[2].result||[];
    if(!modular||modular.active===false)return fail(Error('Display is no longer active'));
    if(UPCLocationWorkPolicy.fingerprint(before)!==expectedFingerprint)return fail(Error('Accepted layout changed since this draft began. Review the current layout and begin again.'));
    if(sourceSignature(currentSources)!==expectedSourceSignature)return fail(Error('Official Ace source changed since the audit started. Review before applying corrections.'));
    for(const p of proposed){
     if(p.physicalSectionId!=null&&!modular.physicalSectionIds.includes(p.physicalSectionId))return fail(Error('Physical section is no longer assigned to display'));
     if(p.role==='SECONDARY'&&(!p.approvedException||p.approvedException.placementId!==p.id
      ||p.approvedException.skuKey!==(p.skuKey||null)
      ||String(p.approvedException.physicalSectionId??'')!==String(p.physicalSectionId??'')
      ||p.approvedException.rowOrdinal!==p.rowOrdinal||p.approvedException.observedOrder!==p.observedOrder))
      return fail(Error('Secondary placement requires approval for this specific product and position'));
    }
    const nextIds=new Set(proposed.map(p=>p.id));
    for(const prior of before){
     placements.delete(prior.id);
     if(!nextIds.has(prior.id)&&prior.storeAdded===true&&prior.physicalEvidence===true&&prior.skuKey)
      history.put({skuKey:prior.skuKey,kind:'LAST_KNOWN_STORE_ADDED',contextId:modularId,
       areaId:modular.areaId,modularId,physicalSectionId:prior.physicalSectionId??null,updatedAt:Date.now()});
    }
    for(const p of proposed)placements.put(p);
    // Local notPlaced is a store decision; it does not destroy official Ace membership or positions.
    const current=currentSources.filter(x=>x.current===true);
    if(current.length>1)return fail(Error('More than one active official source assigned to display'));
    if(current.length){
     const src=current[0],scope=members.index('bySource').getAll(src.id);
     scope.onsuccess=()=>{for(const member of scope.result||[]){
      const stillPresent=proposed.some(p=>p.skuKey===member.skuKey);
      if(member.notPlaced!==!stillPresent)members.put({...member,notPlaced:!stillPresent});
     }};
     scope.onerror=()=>fail(scope.error||Error('Could not retain corporate membership'));
    }
    set({accepted:true,previousCount:before.length,currentCount:proposed.length});
   };
   for(const q of queries){q.onsuccess=commit;q.onerror=()=>fail(q.error)}
  });
 }
 function acceptSource({source,items,replaceSourceId=null,batchId}){
  if(!source||typeof source.id!=='string'||!source.id||typeof source.planogramId!=='string'||!source.planogramId
   ||typeof source.digest!=='string'||!source.digest||!Array.isArray(items)||!batchId)throw Error('Source identity and verified batch required');
  const skuSet=new Set();
  const validated=items.map(item=>{
   if(!item||typeof item.skuKey!=='string'||!item.skuKey||!Array.isArray(item.sourceRowIds)||!item.sourceRowIds.length)throw Error('Verified merchandise and source rows required');
   if(skuSet.has(item.skuKey))throw Error('Duplicate merchandise SKU');skuSet.add(item.skuKey);
   return {skuKey:item.skuKey,upcKey:item.upcKey??null,sourceRowIds:item.sourceRowIds.map(String),positions:Array.isArray(item.positions)?item.positions:[],sourceMember:true};
  });
  return write(['storeSources','storeSourceMembers','storeHistory','storeImportReceipts','storePlacements'],(tx,set,fail)=>{
   const sources=tx.objectStore('storeSources'),members=tx.objectStore('storeSourceMembers'),hist=tx.objectStore('storeHistory'),
    receipts=tx.objectStore('storeImportReceipts'),placements=tx.objectStore('storePlacements');
   const checks=[receipts.get(batchId),sources.getAll(),members.getAll(),placements.getAll()];let ready=0;
   const apply=()=>{if(++ready!==checks.length)return;
    const prior=checks[0].result,all=checks[1].result||[],membersBefore=checks[2].result||[],placementsBefore=checks[3].result||[];
    if(prior){if(prior.digest!==source.digest)return fail(Error('Reused import receipt does not match source digest'));set({accepted:true,replayed:true});return;}
    const matches=all.filter(x=>x.current&&x.planogramId===source.planogramId);
    if(matches.length>1)return fail(Error('Multiple current versions need review before re-import'));
    const old=matches[0]||null;
    if(old&&replaceSourceId!==old.id)return fail(Error('Planogram already imported. Explicitly approve replacement before accepting.'));
    if(replaceSourceId&&(!old||old.id!==replaceSourceId))return fail(Error('Replacement source identity does not match'));
    const id=old?old.id:source.id,modularId=old?.modularId||source.modularId||null;
    // Preserve user-assigned short names across exact Ace source replacements.
     const entry={...source,id,modularId,current:true,shortName:String(source.shortName||old?.shortName||'').trim().slice(0,80)};
    if(old){
     for(const row of membersBefore.filter(x=>x.sourceId===id))members.delete([id,row.skuKey]);
     for(const placement of placementsBefore.filter(x=>x.origin==='ACE_IMPORT'&&x.sourceId===id||x.origin==='ACE_IMPORT'&&x.id?.startsWith('source:'+id+':')))
      placements.delete(placement.id);
    }
    const oldBySku=new Map(membersBefore.filter(x=>x.sourceId===id).map(x=>[x.skuKey,x]));
    for(const item of validated){
     const previous=oldBySku.get(item.skuKey);
     members.put({...item,sourceId:id,notPlaced:previous?.notPlaced===true});
     hist.put({skuKey:item.skuKey,kind:'LAST_KNOWN_ACE',contextId:modularId||entry.planogramId,
      sourceId:id,sourceName:entry.name||entry.planogramId,sourcePosition:item.positions[0]||null,updatedAt:Date.now()});
     if(modularId&&previous?.notPlaced!==true){
      const hasApproved=placementsBefore.some(p=>p.modularId===modularId&&p.skuKey===item.skuKey&&p.origin!=='ACE_IMPORT');
      if(!hasApproved){const pos=item.positions[0]||{};
       placements.put({id:'source:'+id+':'+item.skuKey,sourceId:id,modularId,skuKey:item.skuKey,upcKey:item.upcKey,
        origin:'ACE_IMPORT',role:'HOME',physicalEvidence:false,physicalSectionId:null,sourceSegment:pos.sourceSegment??null,
        sourceRow:pos.sourceRow??null,sourceColumn:pos.sourceColumn??null,fixtureZone:pos.fixtureZone??null,
        fixtureType:pos.fixtureType??'UNKNOWN',sourcePositionStatus:pos.sourcePositionStatus??null,sourcePositionNote:pos.sourcePositionNote??null,sourceOrder:pos.sourceOrder??null,storeAdded:false});}
     }
    }
    sources.put(entry);
    receipts.put({batchId,digest:entry.digest,sourceId:id,acceptedAt:new Date().toISOString()});
    set({accepted:true,replayed:false,replaced:!!old,memberCount:validated.length,modularId});
   };
   for(const req of checks){req.onsuccess=apply;req.onerror=()=>fail(req.error)}
  });
 }
 function renameSource(sourceId,shortName){
   const value=String(shortName||'').trim();
   if(!value||value.length>80||/[\\x00-\\x1f\\x7f]/.test(value))throw Error('Use a short name of 1–80 characters');
   return write(['storeSources'],(tx,set,fail)=>{
    const store=tx.objectStore('storeSources'),request=store.get(sourceId);
    request.onsuccess=()=>{if(!request.result||request.result.current!==true)return fail(Error('Saved planogram not found'));
     const next={...request.result,shortName:value};store.put(next);set(next)};
    request.onerror=()=>fail(request.error);
   });
  }
  function assignSource({sourceId,modularId,replaceSourceId=null,seedIfEmpty=true}){
  if(typeof sourceId!=='string'||!sourceId||typeof modularId!=='string'||!modularId)throw Error('Source and physical modular required');
  return write(['storeSources','storeModulars','storeSourceMembers','storePlacements'],(tx,set,fail)=>{
   const sources=tx.objectStore('storeSources'),mods=tx.objectStore('storeModulars'),members=tx.objectStore('storeSourceMembers'),placements=tx.objectStore('storePlacements');
   const a=sources.get(sourceId),b=mods.get(modularId),c=sources.getAll(),d=members.index('bySource').getAll(sourceId),e=placements.index('byModular').getAll(modularId);
   let outstanding=5;
   const finish=()=>{if(--outstanding>0)return;
    const source=a.result,modular=b.result;
    if(!source||source.current!==true) return fail(Error('Official planogram not available'));
    if(!modular||modular.active!==true) return fail(Error('Choose an active physical modular'));
    if(source.modularId&&source.modularId!==modularId)return fail(Error('Planogram already assigned elsewhere'));
    const conflicts=(c.result||[]).filter(x=>x.current===true&&x.modularId===modularId&&x.id!==sourceId);
    if(conflicts.length&&(!replaceSourceId||conflicts.some(x=>x.id!==replaceSourceId)))return fail(Error('Physical modular already has active planogram; explicitly choose replacement'));
    if(replaceSourceId&&conflicts.length!==1)return fail(Error('Replacement source mismatch'));
    if(replaceSourceId){
     const previous=conflicts[0];
     const cursor=members.index('bySource').openCursor(IDBKeyRange.only(previous.id));
     cursor.onsuccess=()=>{const x=cursor.result;if(x){x.delete();x.continue()}};
     cursor.onerror=()=>fail(cursor.error);
     sources.delete(previous.id);
    }
    let seeded=0;
    if(seedIfEmpty&&!(e.result||[]).length){
     for(const item of d.result||[]){
      const pos=item.positions?.[0]||{};
      // Accepted imported locations know only their modular's whole physical
      // span and the PDF's relative position, never an invented physical hook.
      placements.put({id:'source:'+sourceId+':'+item.skuKey,modularId,skuKey:item.skuKey,upcKey:item.upcKey,
       origin:'ACE_IMPORT',sourceId,role:'HOME',physicalEvidence:false,physicalSectionId:null,
       sourceSegment:pos.sourceSegment??null,sourceRow:pos.sourceRow??null,
       sourceColumn:pos.sourceColumn??null,fixtureZone:pos.fixtureZone??null,fixtureType:pos.fixtureType??'UNKNOWN',sourcePositionStatus:pos.sourcePositionStatus??null,sourcePositionNote:pos.sourcePositionNote??null,sourceOrder:pos.sourceOrder??null,storeAdded:false});
      seeded++;
     }
    }
    sources.put({...source,modularId});set({assigned:true,seeded,modularId,sourceId,replaced:replaceSourceId||null});
   };
   for(const q of [a,b,c,d,e]){q.onsuccess=finish;q.onerror=()=>fail(q.error)}
  });
 }

 function assignSourceToNewModular({sourceId,areaId,firstSection,lastSection,shortName,modularId}={}){
  const name=String(shortName||'').trim(),a=Number(firstSection),b=Number(lastSection);
  if(!sourceId||!areaId||!modularId||!name||name.length>100)throw Error('Choose an official source, saved aisle and short modular name');
  if(!/^[1-9]\d*$/.test(String(firstSection))||!/^[1-9]\d*$/.test(String(lastSection))||
      !Number.isSafeInteger(a)||!Number.isSafeInteger(b)||a>9999||b<a||b-a>=200)throw Error('Choose one consecutive range of 1–200 created four-foot sections');
  const selected=Array.from({length:b-a+1},(_,i)=>String(a+i));
  // One IndexedDB transaction owns BOTH the physical display and its official source.
  // No preliminary modular is saved if source validation, occupancy, or seeding fails.
  return write(['storeAreas','storeModulars','storeSources','storeSourceMembers','storePlacements'],(tx,set,fail)=>{
   const areaStore=tx.objectStore('storeAreas'),moduleStore=tx.objectStore('storeModulars'),
    sourceStore=tx.objectStore('storeSources'),memberStore=tx.objectStore('storeSourceMembers'),
    placementStore=tx.objectStore('storePlacements');
   const area=areaStore.get(areaId),modules=moduleStore.getAll(),prior=moduleStore.get(modularId),
    source=sourceStore.get(sourceId),sources=sourceStore.getAll(),members=memberStore.index('bySource').getAll(sourceId),savedPlacements=placementStore.getAll();
   let waiting=7;
   const ready=()=>{if(--waiting)return;
    const target=area.result,official=source.result;
    if(!target||target.active===false||target.kind!=='AISLE')return fail(Error('Choose an active saved aisle face'));
    if(!official||official.current!==true||official.modularId)return fail(Error('Choose an unassigned current Ace planogram'));
    if(prior.result)return fail(Error('New display ID already in use; retry assignment'));
    if((savedPlacements.result||[]).some(p=>p.sourceId===sourceId))return fail(Error('Existing source placements require review before reassignment'));
    const others=modules.result||[],saved=Array.isArray(target.sectionIds)?target.sectionIds.map(String):
     Number.isSafeInteger(target.sectionCount)&&target.sectionCount>0?Array.from({length:target.sectionCount},(_,i)=>String(i+1)):[];
    const legacy=others.filter(m=>(m.areaId||m.area?.id)===areaId).flatMap(m=>m.physicalSectionIds||[]).map(String);
    const permitted=new Set([...saved,...legacy]);
    if(selected.some(n=>!permitted.has(n)))return fail(Error('Create those four-foot sections in Store Locations first'));
    const occupied=others.filter(m=>m.active!==false&&(m.areaId||m.area?.id)===areaId);
    const collisions=occupied.filter(m=>(m.physicalSectionIds||[]).some(n=>selected.includes(String(n))));
    if(collisions.length)return fail(Error('Sections are already assigned to '+collisions.map(m=>m.name).join(', ')+'. Choose empty sections.'));
    if((sources.result||[]).some(s=>s.current===true&&s.id!==sourceId&&s.modularId===modularId))
     return fail(Error('Another planogram already uses this display'));
    const location=P.normalizeLocationDraft({id:modularId,name,active:true,
     area:{kind:'AISLE',id:target.id,aisle:target.aisle,side:target.side},
     physicalSectionIds:selected,sourceNominalFeet:official.nominalWidthFt??null,overlapApprovals:[]});
    const record={...location,areaId:target.id};
    // Corporate report sections and rows remain source-relative; a physical
    // peg position cannot be inferred from only a reserved four-foot range.
    for(const member of members.result||[]){
     const pos=member.positions?.[0]||{};
     placementStore.put({id:'source:'+sourceId+':'+member.skuKey,modularId,skuKey:member.skuKey,upcKey:member.upcKey,
      origin:'ACE_IMPORT',sourceId,role:'HOME',physicalEvidence:false,physicalSectionId:null,
      sourceSegment:pos.sourceSegment??null,sourceRow:pos.sourceRow??null,
      sourceColumn:pos.sourceColumn??null,fixtureZone:pos.fixtureZone??null,
      fixtureType:pos.fixtureType??'UNKNOWN',sourcePositionStatus:pos.sourcePositionStatus??null,
      sourcePositionNote:pos.sourcePositionNote??null,sourceOrder:pos.sourceOrder??null,storeAdded:false});
    }
    moduleStore.put(record);sourceStore.put({...official,modularId});
    set({assigned:true,modularId,sourceId,seeded:(members.result||[]).length,sections:selected});
   };
   for(const request of [area,modules,prior,source,sources,members,savedPlacements]){request.onsuccess=ready;request.onerror=()=>fail(request.error)}
  });
 }
 function markSourceMemberNotPlaced({sourceId,skuKey}){
  if(typeof sourceId!=='string'||!sourceId||typeof skuKey!=='string'||!skuKey)throw Error('Select a planogram and valid Ace SKU');
  return write(['storeSources','storeSourceMembers','storePlacements'],(tx,set,fail)=>{
   const sources=tx.objectStore('storeSources'),members=tx.objectStore('storeSourceMembers'),places=tx.objectStore('storePlacements');
   const a=sources.get(sourceId),b=members.get([sourceId,skuKey]),c=places.index('bySku').getAll(skuKey);let ready=0;
   const finish=()=>{if(++ready<3)return;
    if(!a.result||!a.result.current||!a.result.modularId||!b.result)return fail(Error('SKU is not a current member of an assigned official planogram'));
    const associated=(c.result||[]).filter(x=>x.modularId===a.result.modularId);
    if(associated.length>1)return fail(Error('Multiple current placements require individual physical review'));
    for(const x of associated)places.delete(x.id);
    members.put({...b.result,notPlaced:true});
    // Official membership and last-known references remain intact.
    set({markedNotPlaced:true,removedPlacements:associated.length,sourceId,skuKey});
   };
   for(const req of [a,b,c]){req.onsuccess=finish;req.onerror=()=>fail(req.error)}
  });
 }
 function restoreSourceMember({sourceId,skuKey}){
  if(typeof sourceId!=='string'||!sourceId||typeof skuKey!=='string'||!skuKey)throw Error('Select a planogram and valid Ace SKU');
  return write(['storeSources','storeSourceMembers','storeModulars','storePlacements'],(tx,set,fail)=>{
   const sources=tx.objectStore('storeSources'),members=tx.objectStore('storeSourceMembers'),mods=tx.objectStore('storeModulars'),places=tx.objectStore('storePlacements');
   const a=sources.get(sourceId),b=members.get([sourceId,skuKey]),c=places.index('bySku').getAll(skuKey);let ready=0;
   const finish=()=>{if(++ready<3)return;
    const source=a.result,member=b.result;
    if(!source||!source.current||!source.modularId||!member)return fail(Error('SKU is not currently assigned to this Ace planogram'));
    const existing=c.result||[];
    if(existing.length)return fail(Error('SKU already has a current location. Review before adding a second placement.'));
    const mr=mods.get(source.modularId);
    mr.onsuccess=()=>{
     if(!mr.result||mr.result.active===false)return fail(Error('Physical modular unavailable'));
     const position=member.positions?.[0]||{};
     members.put({...member,notPlaced:false});
     places.put({id:'source:'+sourceId+':'+skuKey,sourceId,modularId:source.modularId,skuKey,upcKey:member.upcKey,
      origin:'ACE_IMPORT',role:'HOME',physicalEvidence:false,physicalSectionId:null,
      sourceSegment:position.sourceSegment??null,sourceRow:position.sourceRow??null,
      sourceColumn:position.sourceColumn??null,fixtureZone:position.fixtureZone??null,fixtureType:position.fixtureType??'UNKNOWN',sourcePositionStatus:position.sourcePositionStatus??null,sourcePositionNote:position.sourcePositionNote??null,sourceOrder:position.sourceOrder??null,storeAdded:false});
     set({restored:true,sourceId,skuKey,modularId:source.modularId,sourceDerived:true});
    };mr.onerror=()=>fail(mr.error);
   };
   for(const req of [a,b,c]){req.onsuccess=finish;req.onerror=()=>fail(req.error)}
  });
 }
 function removeSource(sourceId){
  if(!sourceId)throw Error('Source ID required');
  return write(['storeSources','storeSourceMembers'],(tx,set,fail)=>{
   const ss=tx.objectStore('storeSources'),items=tx.objectStore('storeSourceMembers');
   const r=ss.get(sourceId);r.onsuccess=()=>{
    if(!r.result){set({deleted:false});return}
    const cursor=items.index('bySource').openCursor(IDBKeyRange.only(sourceId));
    cursor.onsuccess=()=>{const c=cursor.result;if(c){c.delete();c.continue()}};
    cursor.onerror=()=>fail(cursor.error);
    ss.delete(sourceId);set({deleted:true});
   };r.onerror=()=>fail(r.error);
  });
 }
 return Object.freeze({STORES,bySku,byUpc,getArea,getModular,getSource,getReceipt,listAreas,listModulars,listSources,
  saveArea,saveModular,removeArea,removeSections,removeModular,renameSource,replacePlacements,listPlacements,listSourceMembers,listSourcesForModular,sourceSignature,approvePhysicalLayout,acceptSource,assignSource,assignSourceToNewModular,markSourceMemberNotPlaced,restoreSourceMember,removeSource});
})();