/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/store-locations/location-verification-service.js
 * Owner: Store Locations / Shared Verification Evidence
 * Role: Location domain verification and draft-status read service
 * Responsibility: Record one bounded, evidence-typed verification history per display and project existing audit drafts.
 * Does not own: Ace source membership, physical placement mutations, UI, Work Sessions, scanner, or independent layout snapshots.
 * Side effects: Reads/writes a backed-up meta record through UPCDB only after explicit confirmation.
 * Related code: location-work-controller.js, location-explorer-controller.js, location-maintenance-controller.js.
 */
const UPCLocationVerificationService=(()=>{
 'use strict';
 const KEY='locationVerification.v1',WORK='storeLocationWorkV1',EXPLORER='locationExplorerAudits.v1',PER_DISPLAY=12,MAX_DISPLAYS=100;
 const METHODS=['VISUAL_ACE_MATCH','VISUAL_STORE_LAYOUT','GUIDED_PHYSICAL_AUDIT','GUIDED_LAYOUT_BUILD','GUIDED_LAYOUT_CORRECTION'];
 function create({db,repository,explorerPolicy,workPolicy}={}){
  if(!db||!repository||!explorerPolicy||!workPolicy)throw Error('Shared location verification dependencies missing');
  let queue=Promise.resolve();
  const serialized=fn=>{const next=queue.then(fn);queue=next.catch(()=>{});return next};
  const read=async()=>{const r=await db.get('meta',KEY);return r?.key===KEY&&r.displays&&typeof r.displays==='object'?r:{key:KEY,displays:{}}};
  const sourceSignature=sources=>repository.sourceSignature(sources);
  async function evidence(modularId){
   const modular=await repository.getModular(modularId);
   if(!modular||modular.active===false)throw Error('Display unavailable for verification');
   const [placements,sources]=await Promise.all([repository.listPlacements(modularId),repository.listSourcesForModular(modularId)]);
   const active=sources.filter(s=>s.current===true);
   if(active.length>1)throw Error('More than one official Ace source assigned');
   const source=active[0]||null;
   const members=source?await repository.listSourceMembers(source.id):[];
   return {modular,placements,source,sourceSignature:sourceSignature(sources),layoutFingerprint:workPolicy.fingerprint(placements),
    sourceSnapshot:source?explorerPolicy.ordered({modular,source,sourceMembers:members,mode:'ACE'}):[],
    storeSnapshot:explorerPolicy.ordered({modular,placements,mode:'STORE'})};
  }
  async function record({modularId,method,expectedSourceSignature,expectedLayoutFingerprint,sections=[],complete=false,observedCount=0,changedCount=0}={}){
   if(!modularId||!METHODS.includes(method))throw Error('Select a display and supported verification method');
   if(typeof expectedSourceSignature!=='string'||typeof expectedLayoutFingerprint!=='string')throw Error('Confirmation revision evidence required');
   const e=await evidence(modularId);
   if(e.sourceSignature!==expectedSourceSignature||e.layoutFingerprint!==expectedLayoutFingerprint)
    throw Error('Source or accepted store layout changed before verification was recorded. Reopen and review this display.');
   if(method==='VISUAL_ACE_MATCH'&&!e.source)throw Error('Visual Ace match requires an assigned official source');
   return serialized(async()=>{
    const row=await read(),prior=row.displays[modularId]||[],now=new Date().toISOString();
    const entry={id:modularId+':'+now+':'+Math.random().toString(36).slice(2,8),modularId,displayName:e.modular.name,
     method,confirmedAt:now,sourceId:e.source?.id||null,sourceName:e.source?.name||null,sourceDigest:e.source?.digest||null,
     sourceSignature:e.sourceSignature,layoutFingerprint:e.layoutFingerprint,
     complete:complete===true,sections:[...new Set((sections||[]).map(String))].slice(0,32),
     observedCount:Number(observedCount)||0,changedCount:Number(changedCount)||0,
     sourceSnapshot:e.sourceSnapshot.map(p=>({...p})),
     storeSnapshot:(method==='VISUAL_ACE_MATCH'?e.sourceSnapshot:e.storeSnapshot).map(p=>({...p}))};
    // Save verification evidence; never update the source, placement, or audit-draft authorities.
    row.displays[modularId]=[entry,...prior].slice(0,PER_DISPLAY);
    if(Object.keys(row.displays).length>MAX_DISPLAYS){
     const expired=Object.keys(row.displays).filter(id=>id!==modularId).sort((a,b)=>String(row.displays[a]?.[0]?.confirmedAt||'').localeCompare(String(row.displays[b]?.[0]?.confirmedAt||'')));
     for(const id of expired.slice(0,Object.keys(row.displays).length-MAX_DISPLAYS))delete row.displays[id];
    }
    await db.put('meta',row);return entry;
   });
  }
  async function list(){await queue;const data=await read();return Object.values(data.displays).flat().sort((a,b)=>String(b.confirmedAt).localeCompare(String(a.confirmedAt)))}
  async function latest(modularId){await queue;const data=await read();return data.displays[modularId]?.[0]||null}
  async function summary(){
   await queue;
   const [modules,work,explorer,data]=await Promise.all([repository.listModulars(),db.get('meta',WORK),db.get('meta',EXPLORER),read()]);
   const guided=work?.workspace||null,visual=explorer?.audits||{};
   return modules.filter(m=>m.active!==false).map(m=>({
    modularId:m.id,name:m.name,areaId:m.areaId,sections:m.physicalSectionIds||[],
    guided:guided?.modularId===m.id?{mode:guided.mode,recorded:guided.observations?.length||0,updatedAt:guided.updatedAt||null}:null,
    visual:visual[m.id]?{viewed:visual[m.id].viewed?.length||0,edits:visual[m.id].edits||0,updatedAt:visual[m.id].updatedAt||null}:null,
    latest:data.displays[m.id]?.[0]||null,
    legacy:explorer?.confirmed?.[m.id]||null
   }));
  }
  return Object.freeze({record,list,latest,summary,evidence});
 }
 return Object.freeze({create});
})();
