/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/store-locations/location-work-controller.js
 * Owner: Store Locations / Build 2 / Physical Work User Interface
 * Role: Workspace controller
 * Responsibility: Owns guided position controls, audit review, and accepted scanner observation routing.
 * Does not own: Official Ace PDF interpretation, Master or Local product identity, pricing, passive ordinary scanner capture, or a separate Research repository.
 * Side effects: Mutates only the dedicated Build 2 DOM and calls the injected physical work service.
 * Related code: location-work-service.js, scanner/scanner-workspace-router.js, lookup/item-presentation-controller.js
 */
const UPCLocationWorkController=(()=>{
'use strict';
function create({repository,service,policy,elementById,documentRef,startScanner,resolveUPC,
 normalizeUPC,normalizeSKU,promptDuplicate,confirmUser,relationshipService,verification,onManageAssignment}={}){
 if(!repository||!service||!policy||!elementById||!documentRef||!startScanner||!resolveUPC)throw Error('Physical work UI dependencies missing');
 const $=elementById;let draft=null,busy=false;
 const make=(tag,cls,text)=>{const e=documentRef.createElement(tag);if(cls)e.className=cls;if(text!=null)e.textContent=String(text);return e};
 const writeStatus=(text,kind='info')=>{const x=$('locationWorkStatus');x.textContent=text||'';x.dataset.kind=kind};
 const ident=o=>o.skuKey?'SKU '+o.skuKey:'UPC '+(o.upcKey||'unresolved');
 const pos=o=>'SEC '+(o.physicalSectionId||'—')+' · '+(o.fixtureType==='SHELF'?'Shelf':'Row')+' '+(o.rowOrdinal||'—')+(o.observedOrder?' · order '+o.observedOrder:'');
 function active(){return !!draft&&!$('locationScreen').classList.contains('hidden')
  &&!$('locationWorkPane').classList.contains('hidden')&&!$('locationWorkActive').classList.contains('hidden')}
 async function guarded(fn){if(busy)return;busy=true;try{await fn()}catch(e){writeStatus(e?.message||String(e),'error')}finally{busy=false}}
 async function refreshChoices(){
  const mods=(await repository.listModulars()).filter(m=>m.active!==false);
  const areas=await repository.listAreas(),select=$('locationWorkModular'),selected=select.value;
  select.replaceChildren(make('option','', 'Choose a saved display…'));
  select.firstChild.value='';
  for(const m of mods){const area=areas.find(x=>x.id===(m.areaId||m.area?.id));
   const option=make('option','', (area?.name||area?.aisle&&'Aisle '+area.aisle||'Store')+' · '+m.name+
    ' · '+(m.physicalSectionIds||[]).map(s=>'S'+s).join(', '));
   option.value=m.id;select.append(option);
  }
  if(mods.some(m=>m.id===selected))select.value=selected;
  showSections();
  const old=await service.resume();
  $('locationWorkResume').classList.toggle('hidden',!old);
  $('locationWorkResumeText').textContent=old?('Unfinished '+(old.mode==='AUDIT'?'audit':'layout')+' · '+old.modularName+
   ' · '+old.observations.length+' recorded items'):'';
 }
 async function showSections(){
  const m=await repository.getModular($('locationWorkModular').value).catch(()=>null);
  const host=$('locationWorkSections');host.replaceChildren();
  if(!m){$('locationWorkHint').textContent='Create an aisle or custom area and assign its display above, then select the display here.';return}
  const n=(m.physicalSectionIds||[]).length;
  $('locationWorkHint').textContent='Actual display: '+m.name+' · '+(n? n+' four-foot sections · '+(n*4)+' feet':'custom fixture')+'.';
  if(!n)host.append(make('p','locationHelp','This custom fixture is one physical audit scope. Declare the entire fixture checked only when complete.'));
  for(const sec of m.physicalSectionIds||[]){
   const label=make('label','locationWorkSectionCheck'),check=make('input');check.type='checkbox';check.value=String(sec);check.checked=true;
   label.append(check,make('span','', 'SEC '+sec));host.append(label);
  }
 }
 function renderContext(){
  $('locationWorkModeTitle').textContent=draft.mode==='AUDIT'?'Physical Assortment Audit':'Build Physical Layout';
  $('locationWorkActiveFixture').value=draft.fixtureType;
  const section=draft.sections[draft.sectionIndex]||'Custom fixture';
  $('locationWorkContext').textContent=draft.modularName+' · '+(section==='Custom fixture'?section:'SEC '+section)+
   ' · '+(draft.fixtureType==='SHELF'?'Shelf':'Row')+' '+draft.rowOrdinal;
  $('locationWorkCount').textContent=draft.observations.length+' recorded groups'+
   (draft.baseline.length?' · '+draft.baseline.length+' accepted before this draft':' · new display');
  $('locationWorkFinish').textContent=draft.mode==='LAYOUT'&&draft.baseline.length===0?'Finish & Use Layout':'Review Proposed Corrections';
  $('locationWorkAuditScope').classList.toggle('hidden',draft.mode!=='AUDIT');
  const sectionHost=$('locationWorkCompletedSections');sectionHost.replaceChildren();
  for(const section of (draft.sections.length?draft.sections:['FIXTURE'])){
   const label=make('label','locationWorkSectionCheck'),checkbox=make('input');
   checkbox.type='checkbox';checkbox.checked=draft.completeSections.includes(String(section));
   checkbox.addEventListener('change',()=>guarded(async()=>{draft=await service.markSectionComplete(draft,String(section),checkbox.checked);renderContext();writeStatus(checkbox.checked?'Section '+section+' declared fully checked.':'Section '+section+' is unfinished.')}));
   label.append(checkbox,make('span','',section==='FIXTURE'?'Entire custom fixture fully checked':'Complete SEC '+section));sectionHost.append(label);
  }
 }
 function renderObservations(){
  const host=$('locationWorkItems');host.replaceChildren();
  if(!draft.observations.length){host.append(make('p','locationHelp','No products recorded yet. Scan the first merchandise group or enter an identifier.'));return}
  draft.observations.forEach((o,index)=>{
   const card=make('div','locationWorkItem'),top=make('div','locationWorkItemHead'),
    copy=make('div');copy.append(make('strong','',ident(o)),make('small','',pos(o)+(o.origin==='USER_EDIT'?' · manually entered':'')));
   top.append(copy,make('span','locationWorkPill',o.facings+' facing'+(o.facings===1?'':'s')));
   card.append(top);
   const tools=make('div','locationWorkItemActions');
   function button(label,fn){const b=make('button','secondary',label);b.type='button';b.addEventListener('click',()=>guarded(fn));tools.append(b);return b}
   button('− Facing',async()=>{draft=await service.changeFacing(draft,o.id,-1);render()});
   button('+ Facing',async()=>{draft=await service.changeFacing(draft,o.id,1);render()});
   const up=button('↑ Move',async()=>{draft=await service.reorder(draft,o.id,-1);render()});up.disabled=index===0;
   const down=button('↓ Move',async()=>{draft=await service.reorder(draft,o.id,1);render()});down.disabled=index===draft.observations.length-1;
   button('Remove scan',async()=>{draft=await service.removeObservation(draft,o.id);render();writeStatus('Observation removed from this draft only.')});
   const advanced=make('details','locationWorkMove'),summary=make('summary','', 'Move to section / row');
   const controls=make('div','locationWorkMoveControls'),sectionSelect=make('select'),rowInput=make('input');
   sectionSelect.setAttribute('aria-label','Target physical section');
   for(const sec of draft.sections){const opt=make('option','', 'SEC '+sec);opt.value=String(sec);sectionSelect.append(opt)}
   sectionSelect.value=o.physicalSectionId||draft.sections[0]||'';
   rowInput.type='number';rowInput.min='1';rowInput.max='500';rowInput.value=String(o.rowOrdinal||1);
   rowInput.setAttribute('aria-label','Target row or shelf');
   const go=make('button','secondary','Move item');go.type='button';
   go.addEventListener('click',()=>guarded(async()=>{
    if(o.role==='SECONDARY'){
     const yes=await promptDuplicate({upc:o.upcKey,description:ident(o)+' (approve changed secondary placement)'});
     if(!yes)return writeStatus('Secondary placement move canceled.');
    }
    draft=await service.move(draft,o.id,{section:sectionSelect.value,row:Number(rowInput.value),confirmSecondary:o.role==='SECONDARY'});render();
   }));
   controls.append(sectionSelect,rowInput,go);advanced.append(summary,controls);card.append(tools,advanced);host.append(card);
  });
 }
 function render(){
  $('locationWorkStartArea').classList.toggle('hidden',!!draft);
  $('locationWorkActive').classList.toggle('hidden',!draft);
  if(!draft)return;
  renderContext();renderObservations();
  $('locationWorkReview').classList.add('hidden');
 }
 async function start(){
  const id=$('locationWorkModular').value;
  if(!id)throw Error('Choose an assigned display');
  const existing=await service.resume();
  if(existing){writeStatus('Resume or explicitly discard the unfinished draft before starting a different one.','warning');return}
  const sections=[...$('locationWorkSections').querySelectorAll('input:checked')].map(e=>e.value);
  draft=await service.start({modularId:id,mode:$('locationWorkMode').value,sections,fixtureType:$('locationWorkFixture').value});
  render();writeStatus(draft.baseline.length?'Proposed correction: accepted locations stay unchanged until approved.':'New physical layout: scan in actual order; official Ace planogram is optional.');
 }
 async function recordIdentity(identity,origin){
  if(!active())return false;
  const repeated=draft.observations.some(x=>policy.matches(x,identity));
  let otherPlacements=[],activeModularIds=[];
  if(!repeated&&!draft.baseline.some(x=>policy.matches(x,identity))){
   const facts=identity.skuKey?await repository.bySku(identity.skuKey):await repository.byUpc(identity.upcKey);
   otherPlacements=(facts?.placements||[]).filter(p=>p.physicalEvidence===true&&p.modularId!==draft.modularId&&policy.matches(p,identity));
   const ids=[...new Set(otherPlacements.map(p=>p.modularId))];
   const mods=await Promise.all(ids.map(id=>repository.getModular(id)));
   activeModularIds=mods.filter(m=>m&&m.active!==false).map(m=>m.id);
  }
  const ask=policy.needsSeparateLocationConfirmation({identity,observations:draft.observations,
   baseline:draft.baseline,otherPlacements,activeModularIds,modularId:draft.modularId});
  let secondary=false;
  if(ask){
   secondary=await promptDuplicate({upc:identity.upcKey,description:ident(identity)+
    (repeated?' · already recorded in this layout':' · already stocked in another active display')});
   if(!secondary){writeStatus('Repeated or additional-location observation discarded. Existing saved locations and tag work are unchanged.');return true}
  }
  draft=await service.record(draft,{...identity,origin,secondary});
  render();writeStatus((origin==='USER_SCAN'?'Scanned ':'Manually entered ')+ident(identity)+
   (secondary?' as a separately approved placement.':' · '+pos(draft.observations.at(-1))));
  return true;
 }
 async function onAcceptedScan({upc,format}={}){
  if(!active())return false;
  const code=normalizeUPC(upc);if(!code)return true;
  await guarded(async()=>{
   let skuKey=null;
   try{const result=await resolveUPC(code,format);skuKey=result?.skuKey||null}catch{}
   await recordIdentity({skuKey,upcKey:code},'USER_SCAN');
  });
  return true;
 }
 async function manual(){
  const v=$('locationWorkManual').value.trim(),mode=$('locationWorkManualType').value;
  const key=mode==='SKU'?normalizeSKU(v):normalizeUPC(v);
  if(!key)throw Error('Enter a usable '+mode);
  const identity=mode==='SKU'?{skuKey:key,upcKey:null}:{skuKey:null,upcKey:key};
  if(mode==='UPC'){try{identity.skuKey=(await resolveUPC(key,null))?.skuKey||null}catch{}}
  await recordIdentity(identity,'USER_EDIT');$('locationWorkManual').value='';
 }
 async function recordVerification({changed=0}={}){
  if(!verification)return;
  const evidence=await verification.evidence(draft.modularId);
  await verification.record({modularId:draft.modularId,
   method:draft.mode==='AUDIT'?'GUIDED_PHYSICAL_AUDIT':draft.baseline.length?'GUIDED_LAYOUT_CORRECTION':'GUIDED_LAYOUT_BUILD',
   expectedSourceSignature:evidence.sourceSignature,expectedLayoutFingerprint:evidence.layoutFingerprint,
   sections:draft.completeSections,complete:draft.mode!=='AUDIT'||(draft.sections.length?draft.sections:['FIXTURE']).every(x=>draft.completeSections.includes(String(x))),
   observedCount:draft.observations.length,changedCount:changed});
 }
 function renderReview(){
  const host=$('locationWorkReview'),{proposals,findings}=service.review(draft);
  host.replaceChildren();host.classList.remove('hidden');
  const intro=make('div','locationWorkSummary');
  if(draft.mode==='AUDIT'){
   intro.append(make('strong','','Audit findings · '+(findings.partial?'PARTIAL / UNFINISHED':'DECLARED COMPLETE')),
    make('p','',findings.foundAsExpected.length+' found as expected · '+findings.storeAdded.length+
     ' store-added · '+findings.expectedAceUnplaced.length+' expected by Ace but unplaced · '+
     findings.wrongSection.length+' wrong section · '+findings.possibleSeparateDuplicate.length+
     ' possible separate duplicate · '+findings.notObserved.length+' not observed · '+
     findings.notVerified.length+' not verified.'));
   intro.append(make('p','','Not observed means review required, not discontinued or physically absent. Unfinished sections never create missing-item findings.'));
  }else intro.append(make('strong','','Review additions, removals, and position corrections. Existing locations remain authoritative until you approve.'));
  host.append(intro);
  const changes=proposals.filter(p=>p.type!=='UNCHANGED'&&(draft.mode!=='AUDIT'||p.type!=='REMOVE'));
  if(!changes.length){
   host.append(make('p','locationHelp','No proposed placement corrections. Your accepted layout has not changed.'));
   if(draft.mode==='AUDIT'){
    const done=make('button','primary','Complete Audit — No Changes');done.type='button';
    done.addEventListener('click',()=>guarded(async()=>{
     if(!await confirmUser('Confirm that every selected physical section was scanned and checked, with no outstanding placement discrepancies?','Complete Physical Audit',{okLabel:'Confirm No Changes'}))return;
     await service.confirmNoChanges(draft);await recordVerification({changed:0});draft=null;render();
     await refreshChoices();writeStatus('Physical audit completed without layout changes.');
    }));host.append(done);
   }
  }
  for(const p of changes){
   const line=make('label','locationWorkProposal'),checkbox=make('input'),copy=make('span');
   checkbox.type='checkbox';checkbox.value=p.id;checkbox.className='locationWorkApproveCheck';
   copy.textContent=p.type+' · '+ident(p.after||p.before)+' · '+(p.after?pos(p.after):pos(p.before))+
    (p.type==='REMOVE'?' · this will remove the current accepted placement':'');
   line.append(checkbox,copy);host.append(line);
  }
  if(draft.mode==='AUDIT'){
   const groups=[
    {label:'Found as expected',entries:findings.foundAsExpected,pick:x=>x.observation},
    {label:'Store-added merchandise',entries:findings.storeAdded,pick:x=>x.observation},
    {label:'Wrong section',entries:findings.wrongSection,pick:x=>x.observation,
     more:x=>' · accepted: '+pos(x.current)},
    {label:'Possible separate duplicate',entries:findings.possibleSeparateDuplicate,pick:x=>x.observation},
    {label:'Not verified',entries:findings.notVerified,pick:x=>x.current}
   ];
   for(const group of groups){
    if(!group.entries.length)continue;
    const details=make('details','locationWorkFindings'),summary=make('summary','',group.label+' · '+group.entries.length);
    details.append(summary);
    for(const finding of group.entries){
     const item=group.pick(finding),p=make('p','',ident(item)+' · '+pos(item)+(group.more?.(finding)||''));
     details.append(p);
    }
    host.append(details);
   }
  }
  if(draft.mode==='AUDIT'&&findings.notObserved.length){
   const missing=make('div','locationWorkFindings');missing.append(make('strong','','Not observed in completed sections — review, do not automatically remove'));
   for(const m of findings.notObserved)missing.append(make('p','',ident(m.current)+' · '+pos(m.current)));
   host.append(missing);
  }
  if(draft.mode==='AUDIT'&&findings.expectedAceUnplaced.length){
   const expected=make('div','locationWorkFindings');expected.append(make('strong','','Corporate source membership, not an accepted physical placement'));
   for(const m of findings.expectedAceUnplaced.slice(0,100))expected.append(make('p','',ident(m.member)));
   host.append(expected);
  }
  const actions=make('div','locationWorkActions'),apply=make('button','primary','Approve selected changes');
  apply.type='button';apply.addEventListener('click',()=>guarded(async()=>{
   const selected=[...host.querySelectorAll('.locationWorkApproveCheck:checked')].map(x=>x.value);
   if(!selected.length)return writeStatus('Select the actual changes you approve. No location was altered.','warning');
   const secondaryApprovals=[];
   for(const proposal of proposals.filter(p=>selected.includes(p.id)&&p.after&&policy.requiresSecondaryApproval(p.after))){
    const yes=await promptDuplicate({upc:proposal.after.upcKey,description:ident(proposal.after)+' · changed secondary stocking location'});
    if(!yes)return writeStatus('Secondary change was not approved. All accepted locations remain unchanged.','warning');
    secondaryApprovals.push(proposal.id);
   }
   const result=await service.approve(draft,selected,secondaryApprovals);
   await recordVerification({changed:(result.ADD||0)+(result.MOVE||0)+(result.REMOVE||0)});draft=null;render();
   await refreshChoices();writeStatus('Accepted physical layout updated atomically: '+result.ADD+' added, '+result.MOVE+' moved, '+result.REMOVE+' removed.');
  }));
  actions.append(apply);host.append(actions);
  if(draft.mode==='AUDIT'){
   const note=make('p','locationHelp','Audit observations are temporary. For unresolved SKU findings, use the existing Items Needing Research workflow.');
   host.append(note);
   const research=make('button','secondary','Send unresolved SKU to Research');
   research.type='button';research.addEventListener('click',()=>guarded(async()=>{
    const sku=normalizeSKU($('locationWorkResearchSku').value);
    if(!sku)throw Error('Enter the unresolved SKU below before sending it to Research');
    await relationshipService.enqueueResearch({sku,upcs:[],reason:'LOCATION_AUDIT_DISCREPANCY',source:'PHYSICAL_LOCATION_AUDIT'});
    writeStatus('SKU '+sku+' added to existing Items Needing Research.');
   }));
   const input=make('input');input.id='locationWorkResearchSku';input.placeholder='Unresolved SKU';input.setAttribute('aria-label','SKU needing research');
   host.append(input,research);
  }
 }
 async function resume(){draft=await service.resume();render();writeStatus(draft?'Unfinished work recovered. Accepted layout has not changed.':'No unfinished layout draft.');}
 function bind(){
  $('locationWorkModular').addEventListener('change',()=>void showSections());
  $('locationWorkManageAssignment').addEventListener('click',()=>{const id=draft?.modularId||$('locationWorkModular').value;if(id&&onManageAssignment)void onManageAssignment(id)});
  $('locationWorkStart').addEventListener('click',()=>guarded(start));
  $('locationWorkResumeButton').addEventListener('click',()=>guarded(resume));
  $('locationWorkScan').addEventListener('click',()=>{if(active())startScanner()});
  $('locationWorkManualAdd').addEventListener('click',()=>guarded(manual));
  $('locationWorkActiveFixture').addEventListener('change',()=>guarded(async()=>{draft=await service.changeFixture(draft,$('locationWorkActiveFixture').value);render();writeStatus('Fixture changed. Starting at its first row or shelf.')}));
  for(const [id,type] of [['locationWorkNextRow','ROW'],['locationWorkNextShelf','SHELF'],['locationWorkNextSection','SECTION']])
   $(id).addEventListener('click',()=>guarded(async()=>{draft=await service.advance(draft,type);render()}));
  $('locationWorkFinish').addEventListener('click',()=>guarded(async()=>{
   const {proposals}=service.review(draft);
   if(draft.mode==='LAYOUT'&&draft.baseline.length===0){
    const ids=proposals.filter(p=>p.type==='ADD').map(p=>p.id);
    if(!ids.length)throw Error('Scan or enter at least one product before using this new display');
    const saved=await service.approve(draft,ids);await recordVerification({changed:saved.ADD||0});draft=null;render();await refreshChoices();
    return writeStatus('New physical layout is now searchable. '+saved.ADD+' merchandise groups saved.');
   }
   renderReview();
  }));
  $('locationWorkClose').addEventListener('click',()=>{draft=null;render();void refreshChoices();writeStatus('Draft safely stored. Resume when ready.')});
  $('locationWorkDiscard').addEventListener('click',()=>guarded(async()=>{
   if(!await confirmUser('Discard only the unfinished physical layout draft? The accepted store layout will remain unchanged.','Discard Working Draft'))return;
   await service.clear();draft=null;render();await refreshChoices();writeStatus('Only the unfinished draft was discarded.');
  }));
  $('openLocations').addEventListener('click',()=>void refreshChoices().catch(e=>writeStatus(e.message,'error')));
  void refreshChoices().catch(()=>{});
 }
 async function beginFromExplorer({modularId,section=null,identity}={}){
  if(!identity?.skuKey&&!identity?.upcKey)throw Error('Explorer item identity unavailable');
  const old=await service.resume();
  if(old)throw Error('An unfinished physical layout draft already exists. Resume or discard that draft before starting a different display.');
  const modular=await repository.getModular(modularId);
  if(!modular||modular.active===false)throw Error('Selected physical display is inactive');
  $('locationWorkTab').click();await refreshChoices();
  $('locationWorkModular').value=modularId;await showSections();
  const sections=section==null?(modular.physicalSectionIds||[]):[String(section)];
  draft=await service.start({modularId,mode:'LAYOUT',sections,fixtureType:'PEG'});
  draft=await service.save({...draft,seedOnly:true});
  render();await recordIdentity(identity,'USER_EDIT');
  writeStatus('Explorer scan carried into physical layout. Finish and approve the actual merchandise arrangement.');
 }
 return Object.freeze({bind,active,onAcceptedScan,refreshChoices,resume,beginFromExplorer,hasUnfinishedDraft:()=>service.resume()});
}
return Object.freeze({create});
})();