/**
 * OWNERSHIP:
 * File: app/src/main/assets/www/store-locations/planogram-import-controller.js
 * Owner: Store Locations / official planogram staged-import review UI.
 * Role: Present pending AI-extracted reports, local acceptance, official assignment.
 * Responsibility: User-approved import and post-commit receipt acknowledgment.
 * Does not own: PDF parsing, DSD invoice import, raw persistence, scanner or pricing.
 * Side effects: DOM and explicit delegated device requests / IndexedDB repository methods.
 * Related code: planogram-import-service.js, planogram-import-adapter.js, location-repository.js.
 */
const UPCPlanogramImportController=(()=>{
'use strict';
function create({repository,adapter,service,elementById,documentRef=document,confirmUser,getSkuDetails,productImageService,priceService,comparisonEnabled}={}){
 if(!repository||!adapter||!service||typeof elementById!=='function')throw Error('Planogram import dependencies missing');
 const $=elementById,doc=documentRef;
 let batches=[],current=null,validated=null,sources=[],modulars=[],areas=[],assigning=false,selectedSourceId='',inspectionToken=0,inspectionItems=[],inspectionIndex=0;
 const message=(s,level='info')=>{const node=$('planogramImportStatus');if(node){node.textContent=s;node.dataset.kind=level}};
 const option=(label,value)=>{const o=doc.createElement('option');o.textContent=label;o.value=value;return o};
 
 const friendly=source=>String(source?.shortName||source?.name||source?.planogramId||'Planogram').replace(/\s+\d+(?:FT|IN)\b/gi,'').replace(/\s+(?:NATIONAL|L-R|R-L|NA)\b/gi,'').replace(/\s+/g,' ').trim().slice(0,80);
 const node=(tag,cls,value)=>{const el=doc.createElement(tag);if(cls)el.className=cls;if(value!=null)el.textContent=String(value);return el};

 const sectionOrdinal=(p,segments)=>{
  const id=String(p?.sourceSegment??'').trim();
  if(!id)return'';
  const found=(segments||[]).find(x=>String(x.id)===id);
  if(found&&Number.isInteger(Number(found.ordinal))&&Number(found.ordinal)>0)return String(found.ordinal);
  const suffix=id.match(/^(?:SOURCE|SECTION|SEC|S)[-_ ]*(\d+)$/i);
  return /^\d+$/.test(id)?id:suffix?suffix[1]:'';
 };
 const coordinates=(p,segments)=>{
  const s=sectionOrdinal(p,segments);
  const row=p?.sourceRow??p?.visualShelf??p?.reportRow;
  const column=p?.sourceColumn??p?.reportColumn;
  const zone=p?.visualZone||p?.fixtureZone;
  const rowLabel=p?.fixtureType==='SHELF'?'SH':'R';
  const r=row!=null&&String(row).trim()?rowLabel+String(row).replace(/^(?:SH|R)/i,''):'';
  const c=column!=null&&String(column).trim()?'C'+String(column).replace(/^C/i,''):'';
  return{section:s?'S'+s:'',row:r,column:c,zone:zone||'',unknown:!r&&!c&&!zone};
 };
 const positionText=(p,segments)=>{
  const loc=coordinates(p,segments),parts=[loc.section,loc.row,loc.column||loc.zone].filter(Boolean);
  if(loc.unknown)parts.push('Position unresolved');
  return parts.join(' · ')||'Position unresolved';
 };
 function sortedSkuEntries(items,segments){
  const grouped=new Map();
  for(const item of items||[]){
   const sku=String(item?.skuKey||item?.sku||'').trim();if(!sku)continue;
   const positions=Array.isArray(item.positions)?item.positions:[item];
   for(const p of positions){
    // V2 counts one visual item even when several Product Report rows describe its facings.
    // Distinct nonadjacent appearances of a SKU must remain separately navigable.
    const order=p.sourceOrder??p.visualOrder;
    const key=order!=null&&Number.isFinite(Number(order))?sku+'@'+order:sku+'@legacy';
    let entry=grouped.get(key);
    if(!entry){entry={skuKey:sku,description:String(item.description||''),upcs:new Set(),positions:[],order:order!=null?Number(order):null};grouped.set(key,entry)}
    if(!entry.description&&item.description)entry.description=String(item.description);
    if(item.upcKey||item.upcOrGtin)entry.upcs.add(String(item.upcKey||item.upcOrGtin));
    entry.positions.push(p);
   }
  }
  const positionRank=p=>{
   const c=coordinates(p,segments);
   const numeric=x=>x&&/^\D*\d+$/.test(x)?Number(x.replace(/\D/g,'')):Number.POSITIVE_INFINITY;
   const col=numeric(c.column?.split(':')[0]);
   return[numeric(c.section),numeric(c.row),col];
  };
  for(const entry of grouped.values())entry.positions.sort((a,b)=>{
   const left=positionRank(a),right=positionRank(b);
   for(let i=0;i<3;i++)if(left[i]!==right[i])return left[i]-right[i];
   return 0;
  });
  const locationKey=entry=>positionRank(entry.positions[0]||{});
  return [...grouped.values()].sort((a,b)=>{
   if(a.order!=null&&b.order!=null)return a.order-b.order||a.skuKey.localeCompare(b.skuKey);
   if(a.order!=null)return-1;if(b.order!=null)return 1;
   const left=locationKey(a),right=locationKey(b);
   for(let i=0;i<3;i++)if(left[i]!==right[i])return left[i]-right[i];
   return a.skuKey.localeCompare(b.skuKey);
  });
 }
 async function inspectSku(index){
  const entry=inspectionItems[index];if(!entry)return;
  inspectionIndex=index;
  const sku=entry.skuKey,dialog=$('planogramSkuDialog'),host=$('planogramSkuDetails'),turn=++inspectionToken;
  const previous=$('planogramSkuPrevious'),next=$('planogramSkuNext'),count=$('planogramSkuPosition');
  previous.disabled=index===0;next.disabled=index>=inspectionItems.length-1;
  count.textContent=(index+1)+' of '+inspectionItems.length;
  host.replaceChildren(node('p','locationHelp','Looking up '+sku+'…'));
  if(!dialog.open)dialog.showModal();
  host.scrollTop=0;
  try{
   const data=await getSkuDetails(sku);
   if(turn!==inspectionToken||!dialog.open)return;
   const product=data?.product,found=Boolean(data?.catalogFound||product?.status==='FOUND');
   const card=node('div','productPanel');
   const state=node('div','resultState');
   state.append(node('span','badge '+(found?'found':'notfound'),found?'FOUND':'NOT FOUND'));
   const description=node('div','productDescription',(data?.description||entry.description||'Description unavailable offline').toUpperCase());
   const skuLine=node('div','skuLine');skuLine.append(node('span','','SKU:'),node('strong','',sku));
   const frame=node('div','productImageFrame');
   const unavailable=node('div','productImageUnavailable');unavailable.append(node('strong','','Image not available'));frame.append(unavailable);
   const stack=node('div','priceLocationStack'),prices=node('div','priceCompare');
   const priceRow=(name,value)=>{const row=node('div','libraryPriceRow');row.append(node('span','',name),node('strong','',value));prices.append(row);return row};
   const money=value=>value==null||!Number.isFinite(Number(value))?'—':'$'+Number(value).toFixed(2);
   priceRow('Library Level 2 Retail',money(data?.retail));
   const compare=Boolean(comparisonEnabled?.()),liveRow=compare?priceRow('AceNet Level 2 Retail',product?.status==='FOUND'?'Checking…':'Unavailable'):null;
   const loc=node('section','locationQuickCard');
   loc.append(node('span','locationQuickKicker','LOC'));
   const headline=node('strong','',positionText(entry.positions[0],entry.segments));
   const location=coordinates(entry.positions[0],entry.segments);
   if(location.column?.includes(':')){
    const phrase=headline.textContent,at=phrase.lastIndexOf(location.column);
    if(at>=0){headline.textContent=phrase.slice(0,at);headline.append(node('span','locationSkuRange',location.column))}
   }
   loc.append(headline);stack.append(prices,loc);
   const facts=node('div','facts');
   const fact=(label,value)=>{const cell=node('div');cell.append(node('span','',label),node('strong','',value==null||value===''?'—':value));facts.append(cell)};
   fact('UPC',data?.upc||'—');fact('Order Multiple',data?.orderMultiple);fact('Retail Units',data?.retailUnits);
   card.append(state,description,skuLine,frame,stack,facts);host.replaceChildren(card);
   if(liveRow&&product?.status==='FOUND'&&product.sku&&priceService?.requestPrice){
    void priceService.requestPrice(String(product.sku).replace(/\D/g,''),{upcEnrichment:false}).then(result=>{
     if(turn!==inspectionToken||!dialog.open)return;
     const valid=result?.status==='VERIFIED'&&String(result.sku).replace(/\D/g,'')===String(product.sku).replace(/\D/g,'')&&Number.isFinite(result.price);
     liveRow.querySelector('strong').textContent=valid?money(result.price):'Unavailable';
    }).catch(()=>{if(turn===inspectionToken&&dialog.open)liveRow.querySelector('strong').textContent='Unavailable'});
   }else if(liveRow)liveRow.querySelector('strong').textContent='Unavailable';
   if(product?.status==='FOUND'&&productImageService?.lookupProductImage){
    const image=await productImageService.lookupProductImage(product).catch(()=>null);
    if(turn!==inspectionToken||!dialog.open)return;
    const url=String(image?.url||'');
    if(url.startsWith('https://')||url.startsWith('data:image/')){
     const img=node('img','productImage');img.src=url;img.alt='Image of '+(data.description||entry.description||sku);
     frame.replaceChildren(img);
    }
   }
  }catch(e){
   if(turn===inspectionToken&&dialog.open)host.replaceChildren(node('p','locationHelp','No verified local details for SKU '+sku+'. '+(e.message||e)));
  }
 }
 function renderSkuList(host,items,segments=[]){
  host.replaceChildren();
  const all=sortedSkuEntries(items,segments).map(item=>({...item,segments}));
  if(!all.length){host.append(node('p','locationHelp','No merchandise SKUs available.'));return}
  const search=node('input','locationSkuSearch');search.type='search';search.placeholder='Search SKU or description';
  search.setAttribute('aria-label','Search planogram SKUs');
  const count=node('small','locationHelp'),list=node('div','locationProductRows');
  const render=()=>{
   list.replaceChildren();const term=search.value.trim().toLowerCase();
   const matching=all.filter(item=>!term||(item.skuKey+' '+item.description+' '+[...item.upcs].join(' ')).toLowerCase().includes(term));
   for(const [index,item] of matching.entries()){
    if(index>=100)break;
    const button=node('button','locationProductButton');button.type='button';
    button.append(node('strong','',item.skuKey),node('small','',positionText(item.positions[0],segments)));
    button.addEventListener('click',()=>{inspectionItems=matching;void inspectSku(index)});
    list.append(button);
   }
   count.textContent=matching.length+' of '+all.length+' positions'+(matching.length>100?' · first 100 shown':'');
   if(!matching.length)list.append(node('p','locationHelp','No matching SKUs.'));
  };
  search.addEventListener('input',render);host.append(search,count,list);render();
 }
 async function showSaved(){
  const host=$('locationSourceList');host.replaceChildren();
  const src=sources.find(x=>x.current&&x.id===selectedSourceId);
  if(!src){host.append(node('p','locationHelp','Select a saved planogram to view its details and merchandise.'));return}
  host.append(node('h3','',src.shortName||friendly(src)),node('p','locationHelp',src.name+' · '+src.planogramId+' · '+(src.nominalWidthFt||'—')+' ft · '+(src.modularId?'Assigned':'Unassigned')));
  const label=node('label','locationField','Short name'),input=node('input');input.type='text';input.maxLength=80;input.value=src.shortName||friendly(src);label.append(input);
  const save=node('button','secondary','Save name');save.type='button';save.addEventListener('click',async()=>{try{await repository.renameSource(src.id,input.value);message('Short name saved.');await refreshSources()}catch(e){message(e.message,'error')}});
  const products=node('div','locationProductsPanel');host.append(label,save,products);
  try{const members=await repository.listSourceMembers(src.id);if(selectedSourceId===src.id)renderSkuList(products,members,src.sourceSegments||[])}catch(e){products.replaceChildren(node('p','locationHelp',e.message))}
 }
 function renderBatchChoices(){const select=$('planogramBatchSelect'),before=select.value;select.replaceChildren(option('Choose a pending planogram…',''));
  for(const b of batches)select.append(option((b.sourceName||b.planogramId)+' · '+(b.sourceReportRows||0)+' source rows',b.batchId));
  select.value=batches.some(b=>b.batchId===before)?before:'';
 }
 async function check(){current=null;validated=null;$('planogramImportReview').classList.add('hidden');
  try{message('Checking paired ChatGPT planogram queue…');const response=await adapter.list();
   batches=Array.isArray(response.batches)?response.batches:[];
   renderBatchChoices();message(batches.length?batches.length+' planogram import(s) awaiting review.':'No pending planograms. Import a PDF through the ChatGPT @UPC plugin first.');
  }catch(e){message('Planogram check unavailable: '+e.message,'error')}
 }
 async function review(){const id=$('planogramBatchSelect').value;
  if(!batches.some(x=>x.batchId===id))return message('Select a pending planogram.','error');
  try{message('Checking source rows, exceptions and payload integrity…');const payload=await adapter.get(id);
   validated=await service.verify(payload);current=payload;
   const {source,reconciliation:r}=payload;
   $('planogramReviewName').textContent=source.name+' · '+source.planogramId;
   const prior=sources.find(x=>x.current&&x.planogramId===source.planogramId);
   $('planogramReviewShortName').value=prior?.shortName||friendly(source);
   renderSkuList($('planogramPendingProducts'),payload.placements.filter(x=>x.membershipDisposition==='MERCHANDISE'),payload.sourceSegments||[]);
   $('planogramReviewFacts').textContent=source.nominalWidthFt+' ft · '+source.nominalFourFootSections+' × 4-ft bays · '+r.sourceReportRows+' source rows · '+r.distinctMerchandiseSkus+' different SKUs · '+r.excludedNonMerchandiseRows+' fixtures/signs excluded · '+r.unresolvedRows+' unresolved · '+r.unrepresentedRows+' unrepresented';
   $('planogramReviewProvenance').textContent='Width: '+source.widthEvidence+' · '+source.sourceIdentityEvidence;
   const existing=sources.find(x=>x.current&&x.planogramId===source.planogramId);
   if(existing)message('Updated Ace report for '+source.name+' detected. Confirm replacement before saving; your store corrections remain.');
   $('planogramReviewExceptions').textContent=validated.hasUnresolved?'Some source rows are unresolved or missing. Resolve omissions before accepting this as a complete planogram.':'Every source report row is accounted for.';
   $('planogramAccept').disabled=payload.manifest.status!=='COMPLETE'||r.unrepresentedRows>0;
   $('planogramImportReview').classList.remove('hidden');
   message('Report validated. Review source counts before saving locally.');
  }catch(e){current=null;validated=null;$('planogramImportReview').classList.add('hidden');message('Source validation failed: '+e.message,'error')}
 }
 async function accept(){if(!current||!validated)return message('Review a validated source first.','error');
  const batchId=current.batchId;
  if(current.manifest.status!=='COMPLETE'||current.reconciliation.unrepresentedRows)return message('Incomplete Product Report cannot be accepted.','error');
  if(validated.hasUnresolved&&typeof confirmUser==='function'&&!await confirmUser(
   'Some source positions or SKUs remain unresolved. Import only verified Ace source members while keeping all unresolved rows noted in the source?','Review unresolved source',{okLabel:'Import verified members'}))return;
  if(validated.hasUnresolved&&typeof confirmUser!=='function')return message('Import confirmation unavailable. Source not accepted.','error');
  const prior=sources.find(x=>x.current&&x.planogramId===current.source.planogramId);
  if(prior&&(typeof confirmUser!=='function'||!await confirmUser('Re-import '+current.source.name+' ('+current.source.nominalWidthFt+' ft / '+current.source.nominalFourFootSections+' bays)? Update the official coordinates while preserving Aisle/Sections, employee-approved positions and items marked not placed.','Replace existing planogram',{okLabel:'Replace planogram'})))return;
  try{
   const result=await repository.acceptSource({replaceSourceId:prior?.id||null,source:{id:'source-'+batchId,planogramId:current.source.planogramId,
    name:current.source.name,shortName:$('planogramReviewShortName').value.trim()||friendly(current.source),commodityCode:current.source.commodityCode,sourceIdentityEvidence:current.source.sourceIdentityEvidence,
    nominalWidthFt:current.source.nominalWidthFt,nominalFourFootSections:current.source.nominalFourFootSections,widthEvidence:current.source.widthEvidence,sourceSegments:current.sourceSegments,
    sourceReportRows:current.reconciliation.sourceReportRows,excludedRows:current.reconciliation.excludedNonMerchandiseRows,
    unresolvedRows:current.reconciliation.unresolvedRows,digest:validated.digest},
    items:service.stageSource(current),batchId});
   message(result.replayed?'Already saved on this device. Retrying receipt…':result.replaced?'Planogram refreshed; store assignments and approved corrections preserved.':'Saved official source locally. Assign it to a display below.');
   try{await adapter.ack(batchId);message(result.replaced?'Re-import complete. Existing display assignment retained.':'Planogram saved. Assign it to a physical modular below.');}
   catch(e){message('Saved locally. Server receipt pending; tap Check and import again to retry safely. '+e.message,'warning')}
   await refreshSources();
  }catch(e){message('Local import failed; nothing was acknowledged: '+e.message,'error')}
 }
 function updateAssignmentComparison(){
  const source=sources.find(x=>x.id===$('planogramSourceAssignSelect').value);
  const target=modulars.find(x=>x.id===$('planogramModularAssignSelect').value),area=areas.find(x=>x.id===$('planogramAssignArea').value);
  const node=$('planogramAssignmentComparison');if(!node)return;
  if(!source){node.textContent='Select a saved Ace planogram to see its intended length.';return;}
  const official=source.nominalFourFootSections;
  let label=source.nominalWidthFt!=null?'Ace source: '+source.nominalWidthFt+' ft · '+official+' × 4-ft bays.':'Ace source footage unavailable; re-import through the plugin.';
  if(target){const actual=target.physicalSectionIds?.length||0;
   label+=' Your display: '+(target.physicalSectionIds?.length?'S'+target.physicalSectionIds.join('–')+' · ':'')+(actual?actual*4+' ft · '+actual+' bays.':'Custom fixture.');
   if(Number.isInteger(official)&&actual)label+=actual<official?' Condensed layout.':actual>official?' Expanded layout.':' Matching length.';
  }
  if(area){const first=$('planogramAssignStart').value,last=$('planogramAssignEnd').value,count=first&&last?Number(last)-Number(first)+1:0;label+=' Selected '+(area.name||'Aisle '+area.aisle)+(count>0?' · sections '+first+'–'+last+' · '+count*4+' ft':' · choose empty sections')+'.'}
  node.textContent=label;
 }

 function renderAssignmentSections(){
  const area=areas.find(x=>x.id===$('planogramAssignArea').value&&x.active!==false),start=$('planogramAssignStart'),end=$('planogramAssignEnd');
  const oldStart=start.value,oldEnd=end.value,mods=modulars.filter(m=>(m.areaId||m.area?.id)===area?.id);
  const occupied=new Set(mods.filter(m=>m.active!==false).flatMap(m=>m.physicalSectionIds||[]).map(String));
  const base=Array.isArray(area?.sectionIds)?area.sectionIds:Number.isSafeInteger(area?.sectionCount)&&area.sectionCount>0?Array.from({length:area.sectionCount},(_,i)=>String(i+1)):[];
  const free=[...new Set([...base,...mods.flatMap(m=>m.physicalSectionIds||[])].map(String))]
   .filter(x=>/^[1-9]\d*$/.test(x)&&!occupied.has(x)).sort((x,y)=>Number(x)-Number(y));
  start.replaceChildren(option('First empty section…',''));
  for(const n of free)start.append(option('Section '+n,n));
  start.value=free.includes(oldStart)?oldStart:free[0]||'';
  end.replaceChildren(option('Last empty section…',''));
  if(start.value){
   for(const n of free){const a=Number(start.value),b=Number(n);if(b<a)continue;if(b-a>=200)break;
    if(Array.from({length:b-a+1},(_,i)=>String(a+i)).some(x=>!free.includes(x)))break;
    end.append(option('Section '+n,n));
   }
   end.value=[...end.options].some(x=>x.value===oldEnd)?oldEnd:start.value;
  }
  $('planogramSectionAvailability').textContent=area?(free.length?free.length+' available four-foot sections; occupied sections excluded.':'No empty sections. Create more or free occupied sections in Store Locations.'):'Choose a saved aisle face.';
  updateAssignmentComparison();
 }
 async function refreshSources(){
  try{[sources,modulars,areas]=await Promise.all([repository.listSources(),repository.listModulars(),repository.listAreas()]);
   const s=$('planogramSourceAssignSelect'),m=$('planogramModularAssignSelect'),prior=s.value,previousModular=m.value;
   s.replaceChildren(option('Select imported planogram…',''));m.replaceChildren(option('Select store modular…',''));
   for(const src of sources.filter(x=>x.current))s.append(option((src.shortName||friendly(src))+' · '+(src.nominalWidthFt!=null?src.nominalWidthFt+' ft · '+src.nominalFourFootSections+' bays':'Width not yet provided')+(src.modularId?' · assigned':' · unassigned'),src.id));
   for(const mod of modulars.filter(x=>x.active))m.append(option(mod.name+' · '+(mod.physicalSectionIds?.length?'SEC '+mod.physicalSectionIds.join(', '):mod.fixtureId||'Custom display'),mod.id));
   s.value=sources.some(x=>x.id===prior)?prior:'';m.value=modulars.some(x=>x.id===previousModular)?previousModular:'';
   const areaPicker=$('planogramAssignArea'),oldArea=areaPicker.value;areaPicker.replaceChildren(option('Choose saved aisle face…',''));
   for(const area of areas.filter(x=>x.kind==='AISLE'&&x.active!==false).sort((x,y)=>String(x.name).localeCompare(String(y.name),undefined,{numeric:true})))
    areaPicker.append(option(area.name||'Aisle '+area.aisle,area.id));
   areaPicker.value=areas.some(x=>x.id===oldArea)?oldArea:'';
   if(s.value&&!$('planogramAssignName').value.trim()){const src=sources.find(x=>x.id===s.value);$('planogramAssignName').value=src?.shortName||src?.name||''}
   renderAssignmentSections();
   const picker=$('locationSourceBrowse'),old=selectedSourceId||picker.value;picker.replaceChildren(option('Select saved planogram…',''));
   for(const src of sources.filter(x=>x.current).sort((a,b)=>(a.shortName||friendly(a)).localeCompare(b.shortName||friendly(b))))picker.append(option((src.shortName||friendly(src))+(src.modularId?' · assigned':' · unassigned'),src.id));
   picker.value=sources.some(x=>x.current&&x.id===old)?old:'';selectedSourceId=picker.value;
   await showSaved();
  }catch(e){message('Local planogram library unavailable: '+e.message,'error')}
 }
 async function assignExisting(){const sourceId=$('planogramSourceAssignSelect').value,modularId=$('planogramModularAssignSelect').value;
  if(!sourceId||!modularId)return message('Choose both the official planogram and physical modular.','error');
  const currentPlan=sources.find(x=>x.id===sourceId),target=modulars.find(m=>m.id===modularId),previous=sources.find(x=>x.id!==sourceId&&x.current&&x.modularId===modularId);
  if(!currentPlan||!target)return message('Selected planogram or modular no longer exists.','error');
  if(previous){
   if(typeof confirmUser!=='function')return message('Replacement needs confirmation. No change made.','error');
   if(!await confirmUser('Replace the current official '+(previous.name||previous.planogramId)+' reference for '+target.name+' with '+(currentPlan.name||currentPlan.planogramId)+'? Existing store placements and old per-item references will be retained.','Replace official source',{okLabel:'Replace source'}))return;
  }
  try{const result=await repository.assignSource({sourceId,modularId,replaceSourceId:previous?.id||null,seedIfEmpty:true});
   message('Assigned '+target.name+'. '+result.seeded+' products available at Ace planogram positions.');
   await refreshSources();
  }catch(e){message('Planogram assignment rejected: '+e.message,'error')}
 }
 async function assign(){
  if(assigning)return;
  const sourceId=$('planogramSourceAssignSelect').value,areaId=$('planogramAssignArea').value,
   start=$('planogramAssignStart').value,end=$('planogramAssignEnd').value,name=$('planogramAssignName').value.trim();
  const selected=sources.find(x=>x.id===sourceId&&x.current);
  if(!selected||selected.modularId)return message('Choose an unassigned current Ace planogram.','error');
  if(!areaId||!start||!end||!name)return message('Choose saved aisle, empty sections and short modular name.','error');
  assigning=true;$('planogramAssign').disabled=true;
  try{
   const modularId=doc.defaultView?.crypto?.randomUUID?.()||'modular-'+Date.now().toString(36);
   const result=await repository.assignSourceToNewModular({sourceId,areaId,firstSection:start,lastSection:end,shortName:name,modularId});
   message(name+' assigned to four-foot sections '+result.sections.join('–')+'. '+result.seeded+' source items available.');
   $('planogramAssignName').value='';await refreshSources();
  }catch(error){message('No changes saved: '+error.message,'error')}
  finally{assigning=false;$('planogramAssign').disabled=false}
 }
 async function deleteCurrent(){const id=$('planogramSourceAssignSelect').value,source=sources.find(x=>x.id===id);
  if(!source)return message('Select a current planogram.','error');
  if(typeof confirmUser!=='function'||!await confirmUser('Delete current official reference '+(source.name||source.planogramId)+'? Saved physical placements and factual last-known product references remain.','Delete official reference',{okLabel:'Delete reference'}))return;
  try{await repository.removeSource(id);message('Current official reference deleted; physical layout retained.');await refreshSources()}catch(e){message(e.message,'error')}
 }
 async function correctOne(restore=false){
  const sourceId=$('planogramSourceAssignSelect').value,skuKey=$('planogramPlacementSku').value.trim();
  const source=sources.find(x=>x.id===sourceId&&x.current&&x.modularId);
  if(!source||!skuKey)return message('Select an assigned current planogram and enter its exact Ace SKU.','error');
  if(!restore){
   if(typeof confirmUser!=='function'||!await confirmUser('Mark SKU '+skuKey+' as not located in the current store layout for '+(source.name||source.planogramId)+'? The official Ace source and last-known reference remain available.','Remove current placement',{okLabel:'Mark not placed'}))return;
  }
  try{
   const result=restore?await repository.restoreSourceMember({sourceId,skuKey}):await repository.markSourceMemberNotPlaced({sourceId,skuKey});
   message(restore?'Restored Ace planogram location for '+skuKey+'.':'Marked '+skuKey+' as not in the current layout. Original Ace planogram membership retained.');
   $('planogramPlacementSku').value='';
  }catch(e){message('Placement not changed: '+e.message,'error')}
 }
 function bind(){
  $('locationSourceBrowse').addEventListener('change',()=>{selectedSourceId=$('locationSourceBrowse').value;void showSaved()});
  $('planogramSkuPrevious').addEventListener('click',()=>void inspectSku(inspectionIndex-1));
  $('planogramSkuNext').addEventListener('click',()=>void inspectSku(inspectionIndex+1));
  $('planogramSkuClose').addEventListener('click',()=>{inspectionToken++;$('planogramSkuDialog').close()});
  $('planogramSkuDialog').addEventListener('close',()=>{inspectionToken++});
  $('planogramSourceAssignSelect').addEventListener('change',()=>{const src=sources.find(x=>x.id===$('planogramSourceAssignSelect').value);$('planogramAssignName').value=src?.shortName||src?.name||'';updateAssignmentComparison()});
  $('planogramAssignArea').addEventListener('change',renderAssignmentSections);
  $('planogramAssignStart').addEventListener('change',renderAssignmentSections);
  $('planogramAssignEnd').addEventListener('change',updateAssignmentComparison);
  $('planogramModularAssignSelect').addEventListener('change',updateAssignmentComparison);
  $('planogramCheck').addEventListener('click',()=>{void check()});
  $('planogramReview').addEventListener('click',()=>{void review()});
  $('planogramAccept').addEventListener('click',()=>{void accept()});
  $('planogramAssign').addEventListener('click',()=>{void assign()});$('planogramAssignExisting').addEventListener('click',()=>{void assignExisting()});
  $('planogramDelete').addEventListener('click',()=>{void deleteCurrent()});
  $('planogramMarkNotPlaced').addEventListener('click',()=>{void correctOne(false)});
  $('planogramRestoreItem').addEventListener('click',()=>{void correctOne(true)});
  void refreshSources();
 }
 return Object.freeze({bind,check,review,accept,refreshSources});
}
return Object.freeze({create});
})();
