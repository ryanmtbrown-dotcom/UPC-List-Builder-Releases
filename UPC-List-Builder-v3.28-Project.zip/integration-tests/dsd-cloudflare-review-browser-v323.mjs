/** Real, offline Chromium interaction gate for the Cloudflare DSD review widget.
 * Host protocol responses are synthetic; no Cloudflare, user invoice, OAuth or D1 calls.
 */
import assert from 'node:assert/strict';
import {REVIEW_UI_HTML} from '../integrations/chatgpt-mcp/cloudflare/src/review-ui.mjs';
import {prepareReview} from '../integrations/chatgpt-mcp/cloudflare/src/review-policy.mjs';

const modulePath=process.env.UPC_PLAYWRIGHT_MODULE;
assert.ok(modulePath,'UPC_PLAYWRIGHT_MODULE is required');
const {chromium}=await import(modulePath.startsWith('/')?'file://'+modulePath:modulePath);
const browser=await chromium.launch({headless:true,...(process.env.UPC_CHROME_EXECUTABLE?{executablePath:process.env.UPC_CHROME_EXECUTABLE}:{}),args:['--no-sandbox']});
const fixedCosts=['2.15','6.45','12.99','25.00'];
const invoice=()=>prepareReview({
 invoice:{primaryVendor:'SYNTHETIC TEST MANUFACTURER',invoiceNumber:'TEST-20261016',department:'46',defaultRetailMethod:'MARKUP',defaultMarkup:'35'},
 items:Array.from({length:40},(_,i)=>({
  upc:'8402905289'+String(i).padStart(2,'0'),description:'TEST ARTICLE '+String(i+1).padStart(2,'0'),
  originalDescription:'Test article '+(i+1)+' unabridged manufacturer description',mfg:'MODEL-'+i,
  serialNumber:i<2?'TESTSN-'+i:'',orderMultiple:'1',caseCost:fixedCosts[i%fixedCosts.length],
  department:i>=20?'72':'46',retailMethod:'MARKUP',markup:i>=20?'50':'35'
 }))
});
try {
 const page=await browser.newPage({viewport:{width:360,height:780},hasTouch:true,isMobile:true});
 const errors=[];page.on('pageerror',e=>errors.push(e.message));
 page.on('request',r=>{if(!r.url().startsWith('about:'))errors.push('Unexpected network request: '+r.url())});
 await page.setContent('<!doctype html><html><body style="margin:0"><iframe id="review" title="DSD Invoice Review" style="width:100%;height:730px;border:0"></iframe></body></html>');
 await page.evaluate(()=>{
  window.__reviewCalls=[];window.__hostFailures=[];
  window.addEventListener('message',e=>{
   const m=e.data;if(e.source!==document.getElementById('review').contentWindow||m?.jsonrpc!=='2.0'||!m.id)return;
   const name=m.params?.name;
   window.__reviewCalls.push({method:m.method,name,arguments:m.params?.arguments});
   let response={};
   if(m.method==='ui/initialize')response={protocolVersion:'2026-01-26'};
   else if(name==='record_dsd_review_rendered')response={structuredContent:{uiRendered:true}};
   else if(name==='submit_dsd_import')response={structuredContent:{id:'offline-test-only',state:'pending'}};
   e.source.postMessage({jsonrpc:'2.0',id:m.id,result:response},'*');
  });
 });
 await page.locator('#review').evaluate((frame,markup)=>{const d=frame.contentDocument;d.open();d.write(markup);d.close()},REVIEW_UI_HTML);
 const frame=page.frameLocator('#review');
 const source=invoice();
 source.research=[];source.itemCount=40;source.reviewId='00000000-0000-4000-8000-000000000001';
 const payload={structuredContent:source,_meta:{approvalProof:'offline-proof-for-ui-only'}};
 await page.locator('#review').evaluate((frame,data)=>{frame.contentWindow.postMessage({jsonrpc:'2.0',method:'ui/notifications/tool-result',params:data},'*')},payload);
 await frame.locator('#submit:not([disabled])').waitFor({timeout:6000});
 assert.equal(await frame.locator('#items article').count(),10);
 assert.match(await frame.locator('#pages').innerText(),/Page 1 of 4/);
 const options=await frame.locator('#default option').allTextContents();
 assert.ok(options.some(s=>s.includes('46')&&s.includes('Firearms')));
 assert.ok(options.some(s=>s.includes('72')&&s.includes('Sporting Goods')));
 assert.ok(options.length>=20);
 assert.match(await frame.locator('#summary').innerText(),/46 \/ 35%: 20/);
 assert.match(await frame.locator('#summary').innerText(),/72 \/ 50%: 20/);
 assert.equal(await frame.locator('select[aria-label="Item 1 department"]').inputValue(),'46');
 await frame.locator('select[aria-label="Item 1 department"]').selectOption('72');
 await frame.locator('input[aria-label="Item 1 pricing amount"]').fill('45');
 assert.match(await frame.locator('#summary').innerText(),/72 \/ 45%: 1/);
 await frame.locator('#next').click();
 assert.match(await frame.locator('#pages').innerText(),/Page 2 of 4/);
 assert.equal(await frame.locator('#items article').count(),10);
 const method=frame.locator('select[aria-label="Item 11 pricing method"]');
 await method.selectOption('DIRECT');
 assert.equal(await frame.locator('#submit').isDisabled(),true);
 await frame.locator('input[aria-label="Item 11 pricing amount"]').fill('39.99');
 assert.equal(await frame.locator('#submit').isEnabled(),true);
 await frame.locator('#next').click();await frame.locator('#next').click();
 assert.match(await frame.locator('#pages').innerText(),/Page 4 of 4/);
 await frame.locator('#search').fill('MODEL-38');
 assert.equal(await frame.locator('#items article').count(),1);
 assert.match(await frame.locator('#items').innerText(),/MODEL-38/);
 await frame.locator('#search').fill('');
 await frame.locator('#filterProblems').click();
 assert.equal(await frame.locator('#items article').count(),0);
 await frame.locator('#filterProblems').click();
 for(const width of [320,360,412,740]){
  await page.setViewportSize({width,height:820});
  const dims=await page.locator('#review').evaluate(frame=>({scroll:frame.contentDocument.documentElement.scrollWidth,client:frame.contentWindow.innerWidth}));
  assert.ok(dims.scroll<=dims.client+2,'Review overflow '+width+': '+JSON.stringify(dims));
 }
 await frame.locator('#submit').click();
 await frame.locator('#status').filter({hasText:/Submitted/}).waitFor({timeout:6000});
 const calls=await page.evaluate(()=>window.__reviewCalls.filter(c=>c.name==='submit_dsd_import'));
 assert.equal(calls.length,1,'Exactly one user-approved submit');
 assert.equal(calls[0].arguments.decisions.itemPricing.length,40);
 assert.equal(calls[0].arguments.decisions.itemDepartments[0],'72');
 assert.equal(calls[0].arguments.decisions.itemPricing[0].markup,'45');
 assert.equal(calls[0].arguments.decisions.itemPricing[10].retailMethod,'DIRECT');
 assert.equal(calls[0].arguments.decisions.itemPricing[10].retail,'39.99');
 assert.deepEqual(errors,[]);
 console.log('Cloudflare DSD v3 offline Chromium PASS: 40 items, live populated department choices, item pricing, 4 pages, search, exception filter, 320/360/412/740, explicit single approval');
}finally{await browser.close()}
