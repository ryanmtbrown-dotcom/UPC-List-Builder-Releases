/** Non-network real Chromium DSD workflow gate against production DOM, controllers, and CSS. Synthetic workbook. */
import fs from 'node:fs';
import assert from 'node:assert/strict';
const root=new URL('../app/src/main/assets/www/',import.meta.url).pathname;
const read=x=>fs.readFileSync(root+x,'utf8');
const index=read('index.html'),start=index.indexOf('<section id="dsdScreen"'),end=index.indexOf('<section id="builder"',start);
assert.ok(start>=0&&end>start);
const modulePath=process.env.UPC_PLAYWRIGHT_MODULE;assert.ok(modulePath,'UPC_PLAYWRIGHT_MODULE required for offline Chromium gate');
const {chromium}=await import(modulePath.startsWith('/')?'file://'+modulePath:modulePath);
const browser=await chromium.launch({headless:true,...(process.env.UPC_CHROME_EXECUTABLE?{executablePath:process.env.UPC_CHROME_EXECUTABLE}:{}),args:['--no-sandbox']});
try {
 const page=await browser.newPage({viewport:{width:360,height:780}}),errors=[];
 page.on('pageerror',e=>errors.push(e.message));
 await page.setContent('<!doctype html><meta name="viewport" content="width=device-width,initial-scale=1"><body>'+index.slice(start,end)+'</body>');
 for(const f of ['styles.v059.css','dsd/dsd.css'])await page.addStyleTag({content:read(f)});
 await page.addStyleTag({content:':root{--surface-primary:#fff;--surface-raised:#fff;--surface-muted:#f1f3f5;--text-primary:#191d27;--text-secondary:#555f6c;--accent:#c70b35;--border-strong:#cbd1d5;--border-subtle:#dce1e6}.hidden{display:none!important}body{margin:0;background:#f3f4f7}'});
 await page.addScriptTag({content:`window.XLSXImporter={importFile:async()=>({needsUPCMapping:false,headers:['2 UPC','3 Dept','(4) (10) Description','(5) (300) Order Mult','6 CASE COST','9 RETAIL/MSRP','13 VENDOR','299 MFG#','Serial#'],records:[{fields:{'2 UPC':'647484132683','3 Dept':'72','(4) (10) Description':"MEN'S RANA PVC LUG CHEST WADER SIZE 13",'(5) (300) Order Mult':'1','6 CASE COST':'25','9 RETAIL/MSRP':'59.99','13 VENDOR':window.__importVendor||'GUNTERSVILLE BREATHABLES WWD 663','299 MFG#':'MPN-12345678901234567890','Serial#':''}}]})};
 window.XLSXExporter={MIME:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',build:async(headers,rows)=>{window.__lastExport={headers,rows};return new Uint8Array([80,75])}};`});
 await page.addScriptTag({content:read('ace-dsd.js')});
 await page.addScriptTag({content:read('dsd/dsd-workspace-controller.js')});
 await page.evaluate(()=>{let session=null,saves=0;window.__dsd={get session(){return session},get saves(){return saves},exported:null};
  const h=window.UPCDsdWorkspaceController.create({domain:ACEDSD,elementById:id=>document.getElementById(id),queryAll:x=>document.querySelectorAll(x),escapeHtml:s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])),getSession:()=>session,setSession:v=>{session=v},saveSession:async()=>{saves++},newId:()=>String(saves+1),sessionName:()=>'',showScreen:()=>{document.getElementById('dsdScreen').classList.remove('hidden')},confirmUser:async()=>true,alertUser:msg=>{window.__dsd.lastAlert=msg},refreshSavedLists:async()=>{},diagnostic:()=>{},fileDelivery:{deliverBytes:(bytes,name,mime)=>{window.__dsd.exported={length:bytes.length,name,mime}}}});
  h.bind({on:(id,type,handler)=>document.getElementById(id).addEventListener(type,handler),startScanner:()=>{}});window.__dsd.controller=h;h.startNew();document.getElementById('dsdScreen').classList.remove('hidden');
 });
 async function importFile(){await page.locator('#dsdImportFile').setInputFiles({name:'ACE New DSD Items GUNTERSVILLE BREATHABLES WWD INV-1580200.xlsx',mimeType:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',buffer:Buffer.from('synthetic')});}
 // Cancel must produce no invoice.
 await importFile();await page.locator('#dsdVendorImportDialog:not(.hidden)').waitFor();
 assert.equal(await page.locator('#dsdVendorImported').innerText(),'GUNTERSVILLE BREATHABLES WWD 663');
 await page.locator('#dsdVendorCancel').click();await page.waitForFunction(()=>document.getElementById('dsdVendorImportDialog').classList.contains('hidden'));
 assert.deepEqual(await page.evaluate(()=>({saves:__dsd.saves,hasSession:!!__dsd.session})),{saves:0,hasSession:false});
 // Keep imported vendor and edit imported item.
 await importFile();await page.locator('#dsdVendorImportDialog:not(.hidden)').waitFor();await page.locator('#dsdVendorKeep').click();
 await page.locator('#dsdEntry:not(.hidden)').waitFor();
 const saved=await page.evaluate(()=>({saves:__dsd.saves,invoice:__dsd.session.dsdInvoice,items:__dsd.session.items}));
 assert.equal(saved.invoice.vendor,'GUNTERSVILLE BREATHABLES WWD 663');assert.equal(saved.items.length,1);assert.equal(saved.items[0].retail,59.99);assert.equal(saved.items[0].mfg,'MPN-12345678901234567890');assert.ok(saved.items[0].description.length<=24);
 await page.locator('[data-dsd-edit="0"]').click();
 assert.equal(await page.locator('#dsdItemNumber').innerText(),'Edit Item 1');
 assert.ok((await page.locator('#dsdOriginalDescription').innerText()).includes('WADER'));
 await page.locator('#dsdDescription').fill('GREEN NECKLACE WITH A VERY LONG ORIGINAL DESCRIPTION');
 assert.match(await page.locator('#dsdDescriptionPreview').innerText(),/Export description.*24/);
 await page.locator('#dsdAddItem').click();await page.waitForFunction(()=>document.getElementById('dsdItemNumber').textContent.includes('Item 2'));
 assert.ok((await page.evaluate(()=>__dsd.session.items[0].description)).length<=24);
 await page.locator('#dsdExport').click();await page.waitForFunction(()=>!!window.__dsd.exported);
 const exported=await page.evaluate(()=>({e:__dsd.exported,rows:__lastExport.rows}));
 assert.match(exported.e.name,/GUNTERSVILLE BREATHABLES WWD INV-1580200/);assert.equal(exported.rows[0][7],'GUNTERSVILLE BREATHABLES WWD 663');assert.equal(exported.rows[0][14],'MPN-12345678901234567890');assert.equal(exported.rows[0][6],59.99);assert.ok(exported.rows[0][3].length<=24);
 // Explicit default after a divergent vendor changes invoice vendor only.
 await page.evaluate(()=>__dsd.controller.startNew());await importFile();await page.locator('#dsdVendorImportDialog:not(.hidden)').waitFor();await page.locator('#dsdVendorUseDefault').click();await page.locator('#dsdEntry:not(.hidden)').waitFor();
 assert.equal(await page.evaluate(()=>__dsd.session.dsdInvoice.vendor),'WWD 663');
 assert.equal(await page.evaluate(()=>__dsd.session.items[0].mfg),'MPN-12345678901234567890');
 for(const width of [320,360,412]){await page.setViewportSize({width,height:720});const dim=await page.evaluate(()=>({scroll:document.documentElement.scrollWidth,width:innerWidth}));assert.ok(dim.scroll<=dim.width+2,'DSD UI overflow '+width+': '+JSON.stringify(dim))}
 assert.deepEqual(errors,[],'No runtime browser exceptions');
 console.log('DSD production DOM offline Chromium gate PASS: cancel, keep vendor, edit item, preview, export, use WWD 663; 320/360/412px; no console exceptions');
}finally{await browser.close()}
