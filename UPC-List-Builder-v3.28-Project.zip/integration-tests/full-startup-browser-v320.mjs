/**
 * OWNERSHIP: integration-tests/full-startup-browser-v320.mjs
 * Exercise the ACTUAL full application entry point with clean synthetic browser
 * storage. Guards dependency-construction order and readiness, rather than
 * testing the isolated Planogram controller only. No user data is accessed.
 */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import {pathToFileURL} from 'node:url';

const root=path.resolve('app/src/main/assets/www');
const authoredVersion=fs.readFileSync('gradle.properties','utf8').match(/^UPC_VERSION_NAME=(.+)$/m)?.[1]?.trim();
assert.ok(authoredVersion,'Current release version must come from gradle.properties');
const shell=fs.readFileSync(path.join(root,'application/application-shell.js'),'utf8');
const required=['const {aceNetPriceCheckEnabled,','const aceNetPriceService=','const itemRecordMapper=','const productImageService='];
const consumer=shell.indexOf('const planogramImportController=UPCPlanogramImportController.create(');
assert.ok(consumer>0,'Planogram controller construction missing');
for(const owner of required){
 const index=shell.indexOf(owner);
 assert.ok(index>=0&&index<consumer,owner+' must initialize before its planogram consumer, not merely be captured in a callback');
}
assert.ok(shell.indexOf('planogramImportController.bind()')>consumer,'Planogram controller must bind after construction');

const types={'.html':'text/html','.js':'application/javascript','.mjs':'application/javascript','.css':'text/css','.json':'application/json','.webmanifest':'application/manifest+json','.svg':'image/svg+xml','.png':'image/png','.woff2':'font/woff2'};
const missing=[];
const server=http.createServer((req,res)=>{
 const raw=new URL(req.url,'http://localhost').pathname;
 let relative;
 try{relative=decodeURIComponent(raw).replace(/^\/+/, '')||'index.html'}catch{res.writeHead(400);res.end();return}
 const full=path.resolve(root,relative);
 if(full!==root&&!full.startsWith(root+path.sep)){res.writeHead(403);res.end();return}
 try{const data=fs.readFileSync(full);res.writeHead(200,{'Content-Type':types[path.extname(full)]||'application/octet-stream','Cache-Control':'no-store'});res.end(data)}
 catch(e){missing.push(relative);res.writeHead(404);res.end('Not found')}
});
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const modulePath=process.env.UPC_PLAYWRIGHT_MODULE;
assert.ok(modulePath,'Playwright must be installed by the CI browser setup');
const {chromium}=await import(modulePath.startsWith('/')?pathToFileURL(modulePath).href:modulePath);
const browser=await chromium.launch({headless:true,args:['--no-sandbox'],...(process.env.UPC_CHROME_EXECUTABLE?{executablePath:process.env.UPC_CHROME_EXECUTABLE}:{})});
try{
 const page=await browser.newPage({viewport:{width:390,height:844}});
 const pageErrors=[],fatalConsole=[];
 page.on('pageerror',e=>pageErrors.push(e.stack||e.message));
 page.on('console',m=>{if(m.type()==='error'&&m.text().includes('[UPC-BOOT]'))fatalConsole.push(m.text())});
 await page.goto('http://127.0.0.1:'+server.address().port+'/index.html',{waitUntil:'domcontentloaded'});
 try{
  await page.waitForFunction(expectedVersion=>document.querySelector('#home:not(.hidden)')&&window.UPC_RELEASE_INFO?.version===expectedVersion,authoredVersion,{timeout:30000});
  await page.waitForFunction(()=>!document.getElementById('splash')||document.getElementById('splash').classList.contains('exit'),null,{timeout:40000});
 }catch(e){
  const state=await page.evaluate(()=>({stage:document.getElementById('splashStage')?.textContent,percent:document.getElementById('splashPercent')?.textContent,homeHidden:document.getElementById('home')?.classList.contains('hidden'),splash:!!document.getElementById('splash'),version:window.UPC_RELEASE_INFO?.version}));
  throw new Error('Full startup failed: '+JSON.stringify({state,pageErrors,fatalConsole,missing})+' ; '+e.message);
 }
 assert.ok(!pageErrors.length,'Uncaught full-startup browser errors: '+pageErrors.join('; '));
 assert.deepEqual(fatalConsole,[],'Fatal application shell startup console error');
 assert.notEqual(await page.locator('#splashStage').count()?await page.locator('#splashStage').innerText():'Ready','Startup failed');
 await page.locator('#openLocations').click();
 await page.locator('#locationScreen').waitFor({state:'visible'});
 await page.locator('#locationPlanogramTab').click();
 await page.locator('#locationPlanogramPane').waitFor({state:'visible'});
 assert.ok(await page.locator('#locationSourceBrowse').count()>0,'Planogram picker missing after real boot');
 assert.deepEqual(pageErrors,[],'No startup or navigation uncaught errors');
 console.log('Current-release FULL application startup: real index, real composition, clean IndexedDB, home ready, splash exits, locations open — PASS');
}finally{await browser.close();await new Promise(resolve=>server.close(resolve))}
