/** Offline-only Chromium verification of the production Explorer markup, JS and CSS.
 * Uses synthetic data and a controlled storage shim, never localhost or user data.
 * Requires UPC_PLAYWRIGHT_MODULE and optionally UPC_CHROME_EXECUTABLE.
 */
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
const root=path.resolve('app/src/main/assets/www');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');
const src=read('index.html');
const start=src.indexOf('<section id="locationExplorerScreen"'),end=src.indexOf('<section id="locationScreen"',start);
assert.ok(start>0 && end>start);
const explorer=src.slice(start,end);
const settingsStart=src.indexOf('<section id="settingsScreen"',end);
const locations=src.slice(end,settingsStart);
const modal='<div id="appDialogOverlay" class="modal hidden"><div class="appDialog"><strong id="appDialogTitle"></strong><p id="appDialogMessage"></p><div id="appDialogInputWrap" class="appDialogInputWrap"><input id="appDialogInput"></div><button id="appDialogCancel">Cancel</button><button id="appDialogOk">OK</button></div></div>';
const modulePath=process.env.UPC_PLAYWRIGHT_MODULE;
assert.ok(modulePath,'UPC_PLAYWRIGHT_MODULE is required for local isolated Chromium test');
const {chromium}=await import(modulePath.startsWith('/')?'file://'+modulePath:modulePath);
const browser=await chromium.launch({headless:true,...(process.env.UPC_CHROME_EXECUTABLE?{executablePath:process.env.UPC_CHROME_EXECUTABLE}:{}),args:['--no-sandbox']});
try {
 const page=await browser.newPage({viewport:{width:320,height:720}});const errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.setContent('<!doctype html><meta name="viewport" content="width=device-width,initial-scale=1"><body><button id="openLocations">Locations</button>'+explorer+locations+modal+'</body>');
 await page.evaluate(()=>{const values=new Map();Object.defineProperty(window,'localStorage',{value:{getItem:k=>values.has(k)?values.get(k):null,setItem:(k,v)=>values.set(k,String(v)),removeItem:k=>values.delete(k)},configurable:true});});
 for(const file of ['styles.v059.css','store-locations/location-explorer.css','store-locations/location-maintenance.css','store-locations/location-work.css','application/dialogs.css'])await page.addStyleTag({content:read(file)});
 await page.addStyleTag({content:':root{--surface-primary:#fff;--surface-raised:#fff;--surface-muted:#f1f3f5;--text-primary:#191d27;--text-secondary:#555f6c;--accent:#c70b35;--accent-strong:#a10a2b;--border-strong:#cbd1d5;--border-subtle:#dce1e6;--danger:#a10a2b;--shadow-sm:0 3px 12px #0001;}body{margin:0;background:#f3f4f7}.hidden{display:none!important}'});
 for(const file of ['store-locations/location-policy.js','store-locations/location-explorer-policy.js','store-locations/location-work-policy.js','store-locations/location-explorer-draft-service.js','store-locations/location-verification-service.js','store-locations/location-explorer-difference-service.js','store-locations/location-explorer-tag-service.js','application/dialog-service.js','store-locations/location-explorer-controller.js','store-locations/location-maintenance-controller.js'])await page.addScriptTag({content:read(file)});
 await page.addScriptTag({content:fs.readFileSync('integration-tests/planogram-explorer-synthetic-fixture-v316.js','utf8')});
 assert.ok(await page.evaluate(()=>!!window.__fixture),'Synthetic fixture controller initialized');
 await page.evaluate(()=>{let original=window.__fixture.read.display;window.__fixture.read.display=async(id,mode)=>{const v=await original(id,mode); if(v.ace?.length){v.ace[0].sourceColumn='3:5';v.ace[0].sourceRow=5; v.ace[0].sourceOnly=true; v.ace[0].sourceOrder=1; v.ace[0].fixtureType='PEG';v.ace.forEach((entry,i)=>{entry.sourceOrder=i+1});v.ace[1].locationNote='Custom fixture with very narrow necklaces · far extended fixture series · A17 · S3 · SF · L-CNT · R5 · C12:19';}v.items=v.ace;v.mode='ACE';return v;};});
 await page.evaluate(()=>window.__fixture.ctl.open());
 await page.evaluate(()=>window.__fixture.ctl.onAcceptedScan({upc:'100'}));
 await page.waitForFunction(()=>document.getElementById('locationExplorerItemName').textContent.includes('PRODUCT 100'));
 const first=await page.evaluate(()=>{const x=document.getElementById('locationExplorerLocationSummary'),range=x.querySelector('.locationExplorerFacingRange'); return {value:x.textContent,range:range?.textContent,color:range?getComputedStyle(range).color:null,wrap:getComputedStyle(x).whiteSpace,width:document.documentElement.scrollWidth,viewport:window.innerWidth};});
 assert.equal(await page.locator('#locationExplorerCount').innerText(),'Item 1 / 4');
 assert.match(first.value,/C3:5/);assert.equal(first.range,'C3:5');assert.equal(first.color,'rgb(161, 10, 43)');assert.equal(first.wrap,'normal');assert.ok(first.width<=first.viewport+1,'No horizontal viewport overflow');
 await page.locator('#locationExplorerNext').click();
 const second=await page.evaluate(()=>{const x=document.getElementById('locationExplorerLocationSummary');return {location:x.textContent,range:x.querySelector('.locationExplorerFacingRange')?.textContent??null,width:document.documentElement.scrollWidth,viewport:innerWidth};});
 assert.equal(await page.locator('#locationExplorerCount').innerText(),'Item 2 / 4');
 assert.match(second.location,/Custom fixture with very narrow necklaces/);assert.equal(second.range,'C12:19');assert.ok(second.width<=second.viewport+1,'Long specialty-fixture location cannot overflow viewport');
 if(process.env.UPC_BROWSER_SCREENSHOT)await page.screenshot({path:process.env.UPC_BROWSER_SCREENSHOT});
 for(const width of [360,412,740]){await page.setViewportSize({width,height:820});const dim=await page.evaluate(()=>({width:document.documentElement.scrollWidth,viewport:innerWidth,text:document.getElementById('locationExplorerLocationSummary').textContent}));assert.ok(dim.width<=dim.viewport+1,'Overflow at '+width);}
 assert.deepEqual(errors,[],'No runtime exceptions');
 console.log('Planogram v3.22 offline Chromium: inclusive range, custom fixture wrapping, visual order and 4 viewport sizes PASS',JSON.stringify({first,second,widths:[320,360,412,740]}));
}finally{await browser.close()}
