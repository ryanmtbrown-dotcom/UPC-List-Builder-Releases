/** v3.19 real Chromium acceptance: isolated planogram library and pending import. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import {pathToFileURL} from 'node:url';
const root=path.resolve('app/src/main/assets/www');
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
const start=html.indexOf('<section id="locationScreen"'),end=html.indexOf('<section id="settingsScreen"',start);
assert.ok(start>=0&&end>start,'Planograms & Locations screen exists');
const markup=html.slice(start,end);
const fixture='<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'+
 '<link rel="stylesheet" href="/styles.v059.css"><link rel="stylesheet" href="/store-locations/location-maintenance.css">'+
 '<style>body{margin:0}.hidden{display:none!important}:root{--surface-primary:#fff;--surface-raised:#fff;--surface-muted:#f2f3f6;--text-primary:#1a2231;--text-secondary:#4d5260;--border-subtle:#dde0e8;--border-strong:#c4c9d2;--accent:#a42038;--accent-strong:#a42038;--shadow-md:0 3px 15px #0002}</style>'+
 '</head><body>'+markup+
 '<script src="/store-locations/planogram-import-controller.js"></script>'+
 '<script src="/__fixture.js"></script></body></html>';
function bootstrap(){
 const source={id:'src1',planogramId:'NAIL-8',name:'NAILS & SCREWS 8FT NATIONAL',shortName:'Nails & Screws',
  nominalWidthFt:8,nominalFourFootSections:2,current:true,modularId:null,sourceSegments:[{id:'SOURCE-1',ordinal:1},{id:'SOURCE-2',ordinal:2}]};
 const members=[
  {skuKey:'1111111',description:'General construction screws',positions:[{sourceSegment:'SOURCE-1',sourceRow:'1',sourceColumn:'1'},{sourceSegment:'SOURCE-2',sourceRow:'2',sourceColumn:'2'}]},
  {skuKey:'2222222',description:'Picture hanger nails',positions:[{sourceSegment:'SOURCE-2',sourceRow:'2',sourceColumn:'4'}]}
 ];
 const batch={batchId:'batch1',source:{name:'Nails & Screws',planogramId:'NAIL-8',nominalWidthFt:8,nominalFourFootSections:2,widthEvidence:'source title',sourceIdentityEvidence:'report',commodityCode:'42'},
  sourceSegments:[{id:'SOURCE-1',ordinal:1},{id:'SOURCE-2',ordinal:2}],
  placements:[
   {sku:'1111111',description:'General construction screws',upcOrGtin:'123456789012',sourceSegment:'SOURCE-1',reportRow:'1',reportColumn:'1',membershipDisposition:'MERCHANDISE'},
   {sku:'1111111',description:'General construction screws',upcOrGtin:'123456789012',sourceSegment:'SOURCE-2',reportRow:'2',reportColumn:'2',membershipDisposition:'MERCHANDISE'},
   {sku:'2222222',description:'Picture hanger nails',sourceSegment:'SOURCE-2',reportRow:'2',reportColumn:'4',membershipDisposition:'MERCHANDISE'}],
  reconciliation:{sourceReportRows:3,distinctMerchandiseSkus:2,excludedNonMerchandiseRows:0,unresolvedRows:0,unrepresentedRows:0},
  manifest:{status:'COMPLETE'}};
 const saved=[source],calls={lookups:[],accepted:[],acked:[],renamed:[]};
 const repo={listSources:async()=>saved,listModulars:async()=>[],listAreas:async()=>[],listSourceMembers:async id=>{if(id!=='src1')throw Error('Wrong source');return members},
  renameSource:async(id,name)=>{calls.renamed.push([id,name]);saved[0]={...saved[0],shortName:name};return saved[0]},
  acceptSource:async args=>{calls.accepted.push(args);return{accepted:true,replaced:true}},
  assignSource:async()=>{throw Error('No assignment was requested')},removeSource:async()=>{}};
 const adapter={list:async()=>({batches:[{batchId:'batch1',sourceName:'Nails & Screws',sourceReportRows:3}]}),
  get:async()=>batch,ack:async id=>{calls.acked.push(id)}};
 const ctl=UPCPlanogramImportController.create({repository:repo,adapter,
  service:{verify:async()=>({digest:'test-digest',hasUnresolved:false}),stageSource:()=>members},
  elementById:id=>document.getElementById(id),documentRef:document,confirmUser:async()=>true,
  getSkuDetails:async sku=>{calls.lookups.push(sku);return{sku,description:'SYNTHETIC ITEM '+sku,retail:13.99,
   upc:'123456789012',orderMultiple:6,retailUnits:1,catalogFound:true,product:null}},
  comparisonEnabled:()=>false});
 ctl.bind();window.__test={ctl,calls,source:()=>saved[0],members,batch};
}
const testJs='('+bootstrap.toString()+')();';
const server=http.createServer((req,res)=>{
 const u=new URL(req.url,'http://localhost').pathname;
 if(u==='/__library'){res.writeHead(200,{'Content-Type':'text/html'});return res.end(fixture)}
 if(u==='/__fixture.js'){res.writeHead(200,{'Content-Type':'text/javascript'});return res.end(testJs)}
 const rel=path.normalize(decodeURIComponent(u)).replace(/^[/\\]+/,'');
 if(rel.startsWith('..')){res.writeHead(403);return res.end()}
 try{const data=fs.readFileSync(path.join(root,rel));res.writeHead(200,{'Content-Type':rel.endsWith('.css')?'text/css':'text/javascript'});res.end(data)}
 catch{res.writeHead(404);res.end('Not found')}
});
await new Promise(ok=>server.listen(0,'127.0.0.1',ok));
const mod=process.env.UPC_PLAYWRIGHT_MODULE;assert.ok(mod,'Chromium module must be installed by the CI runner');
const {chromium}=await import(mod.startsWith('/')?pathToFileURL(mod).href:mod);
const browser=await chromium.launch({headless:true,args:['--no-sandbox'],
 ...(process.env.UPC_CHROME_EXECUTABLE?{executablePath:process.env.UPC_CHROME_EXECUTABLE}:{})});
const errors=[];
try{
 const page=await browser.newPage({viewport:{width:390,height:844}});
 page.on('pageerror',e=>errors.push(e.message));
 await page.goto('http://127.0.0.1:'+server.address().port+'/__library');
 // The synthetic harness supplies the real app's initially hidden screen;
 // reveal only this task pane, as normal navigation would.
 await page.evaluate(()=>{document.getElementById('locationScreen').classList.remove('hidden');document.getElementById('locationPlanogramPane').classList.remove('hidden')});
 await page.locator('#locationSourceBrowse').selectOption('src1');
 await page.locator('#locationSourceList h3').getByText('Nails & Screws').waitFor();
 assert.equal(await page.locator('#locationSourceList .locationProductButton').count(),2,'Repeat SKU positions grouped');
 await page.locator('#locationSourceList .locationSkuSearch').fill('2222222');
 assert.equal(await page.locator('#locationSourceList .locationProductButton').count(),1);
 await page.locator('#locationSourceList .locationProductButton').click();
 assert.equal(await page.locator('#planogramSkuDialog').evaluate(e=>e.open),true);
 assert.match(await page.locator('#planogramSkuDetails').innerText(),/SYNTHETIC ITEM 2222222/);
 assert.match(await page.locator('#planogramSkuDetails').innerText(),/13\.99/);
 assert.match(await page.locator('#planogramSkuDetails').innerText(),/S2 · R2 · C4/,'Compact source location, not product-report metadata');
 assert.equal(await page.locator('#planogramSkuNext').isDisabled(),true,'Filtered last item has no next');
 await page.locator('#planogramSkuClose').click();
 await page.locator('#locationSourceList .locationSkuSearch').fill('');
 assert.equal(await page.locator('#locationSourceList .locationProductButton').first().locator('strong').innerText(),'1111111','SKU list ordered by location');
 await page.locator('#locationSourceList .locationProductButton').last().click();
 assert.equal(await page.locator('#planogramSkuPosition').innerText(),'2 of 2');
 assert.equal(await page.locator('#planogramSkuPrevious').isEnabled(),true);
 await page.locator('#planogramSkuPrevious').click();
 assert.match(await page.locator('#planogramSkuDetails').innerText(),/S1 · R1 · C1/,'Previous follows official position sequence');
 assert.equal(await page.locator('#planogramSkuPosition').innerText(),'1 of 2');
 assert.equal(await page.locator('#planogramSkuPrevious').isDisabled(),true);
 assert.equal(await page.locator('#planogramSkuNext').isEnabled(),true);
 const footerInViewport=await page.evaluate(()=>{
  const dialog=document.querySelector('#planogramSkuDialog'),details=document.querySelector('#planogramSkuDetails'),
   footer=document.querySelector('.locationSkuNavigation'),rect=footer.getBoundingClientRect();
  return dialog.open&&rect.top>details.getBoundingClientRect().top&&rect.bottom<=window.innerHeight;
 });
 assert.equal(footerInViewport,true,'Navigation stays below details and within visible phone area');
 await page.locator('#planogramSkuNext').click();
 assert.match(await page.locator('#planogramSkuDetails').innerText(),/S2 · R2 · C4/,'Next restores the next located item');
 await page.locator('#planogramSkuClose').click();
 assert.equal(await page.locator('#planogramSkuDialog').evaluate(e=>e.open),false);
 await page.locator('#locationSourceList input[type="text"]').fill('Fasteners');
 await page.locator('#locationSourceList').getByRole('button',{name:'Save name'}).click();
 assert.equal(await page.evaluate(()=>window.__test.source().shortName),'Fasteners');
 await page.locator('#planogramCheck').click();
 await page.locator('#planogramBatchSelect').selectOption('batch1');
 await page.locator('#planogramReview').click();
 await page.locator('#planogramImportReview').waitFor({state:'visible'});
 assert.equal(await page.locator('#planogramPendingProducts .locationProductButton').count(),2,'Pending SKU rows grouped');
 await page.locator('#planogramPendingProducts .locationSkuSearch').fill('1111111');
 await page.locator('#planogramPendingProducts .locationProductButton').click();
 assert.match(await page.locator('#planogramSkuDetails').innerText(),/S1 · R1 · C1/);
 assert.doesNotMatch(await page.locator('#planogramSkuDetails').innerText(),/Product Report|Item 1 ·|SOURCE-2/,'No verbose source metadata in lookup');
 await page.locator('#planogramSkuClose').click();
 await page.locator('#planogramReviewShortName').fill('Fasteners New');
 await page.locator('#planogramAccept').click();
 const result=await page.evaluate(()=>window.__test.calls);
 assert.deepEqual(result.acked,['batch1'],'Remote ACK occurs only after local commit');
 assert.equal(result.accepted[0].source.shortName,'Fasteners New');
 assert.deepEqual(result.lookups,['2222222','2222222','1111111','2222222','1111111']);
 assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth<=window.innerWidth),true,'Mobile layout must not overflow');
 assert.deepEqual(errors,[],'No browser runtime errors');
 console.log('Planogram library Chromium: compact themed lookup, physical-order browsing, bottom navigation, saved/pending search and import ACK PASS');
}finally{await browser.close();await new Promise(resolve=>server.close(resolve))}
