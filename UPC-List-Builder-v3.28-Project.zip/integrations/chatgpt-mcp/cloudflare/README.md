# Free Cloudflare deployment — UPC List Builder ChatGPT DSD bridge

**Status:** The review/approval candidate is in PR #79. Source, tests and preview builds do not establish production deployment. The existing production Worker must be identified by live readback and hosted-client verification. Android updater publication is separate.

Read [WORKFLOW_CONTRACT.md](WORKFLOW_CONTRACT.md) before changing or deploying invoice review, tool visibility, approval or recovery.

## Design

One Cloudflare Worker at `https://upc-dsd-chatgpt.<your-subdomain>.workers.dev` serves:
- `/mcp`: stateless OAuth-protected ChatGPT tools for staging your own invoice data;
- `/authorize`, `/callback`, `/oauth/token`: separate GitHub identity sign-in + Cloudflare OAuth provider;
- `/api/v1/...`: paired-device API for the installed Android app;
- `/health`: no-secrets health check.

Cloudflare Workers free plan supplies the HTTPS address. D1 free tier stores invoices, hashed pairing codes, hashed device tokens. Workers KV `OAUTH_KV` stores downstream OAuth state/tokens. Third-party users can connect their **own GitHub identities** in ChatGPT's OAuth flow, but they do not need to provide their ChatGPT passwords or OpenAI API keys. GitHub permission is limited to identifying the signed-in user (`read:user`), not reading their repositories.

Unknown UPC/cost/retail/department fields remain blank in an editable DSD draft. The invoice department is the default for optional item-level departments; explicit item departments are preserved on mixed-department invoices. A supplied serial number does not by itself establish firearm classification. Multiple printed serials are split into distinct DSD rows; missing serials are allowed. Clear firearm and identifiable ammunition descriptions are handled by explicit classification checks. Missing DSD order multiples normalize to 1 with the equivalent verified one-unit `caseCost`; `orderedQuantity`, `eachCost`, and `lineTotal` are extraction-only hints used for reconciliation, never exported as extra Android fields. Zero-cost display/merchandising fixtures are excluded and reported, not silently imported. The only invoice/item editor is the existing ACE New DSD Items Work Session; authoritative DSD export validation blocks incomplete values. No supplier PDF itself is uploaded to Cloudflare.

## Review workflow (candidate source only)\n\nThe MCP service adds a read-only `review_dsd_import` preflight tool and a responsive interactive MCP Apps review resource. Preflight checks invoice identity, cost normalization, possible department suggestions and preferred manufacturer display names. The optional host-backed invoiceFile parameter lets Cloudflare retrieve, fingerprint and bind original supplier-document bytes; without a received file, the existing per-item research report is required. A receipt proves receipt of bytes and supported PDF/image format, NOT independently verified supplier authenticity or invoice content. The subsequent `submit_dsd_import` action remains separately authenticated and requires an explicit `missingDepartmentsAcknowledged` flag when any effective item department is missing. Existing Android department/pricing/export rules remain authoritative. No real product pricing is calculated in the UI. `review-policy.mjs` mirrors the Android Myers department registry with a test preventing divergence. Mobile UI, Cloudflare deployed runtime, and physical Android behavior must be tested before releasing this candidate.\n\n## Step-by-step for the Cloudflare account owner

These steps are not automatable without the account owner's login and authorization.

1. Register at https://dash.cloudflare.com/sign-up and choose the **Free** plan. Do not buy a domain. Complete any verification Cloudflare requests.
2. In **Workers & Pages** ensure your free `workers.dev` account subdomain is active. Example Worker name `upc-dsd-chatgpt`; published server URL will look like `https://upc-dsd-chatgpt.YOUR-SUBDOMAIN.workers.dev`. This address is not a secret.
3. In **Storage & databases → D1**, create a database named `upc-dsd-imports`. Take note of the database ID (non-secret). In **Workers KV**, create namespace `OAUTH_KV` and record its ID (non-secret). Replace the two `REPLACE_WITH_...` placeholders in `wrangler.jsonc` with their actual IDs **on the draft branch**, not on public `main`.
4. In your GitHub account navigate to https://github.com/settings/developers → **OAuth Apps → New OAuth App**. Set name `UPC List Builder DSD Import`; homepage to your Worker HTTPS origin; authorization callback URL to that origin plus `/callback`. **Never share the generated client secret.** Do not give this OAuth App repository or organization permissions. It authenticates people using their own GitHub logins.
5. In Cloudflare's Worker Settings → Variables and Secrets, add **encrypted secrets** `GITHUB_CLIENT_ID` and `GITHUB_CLIENT_SECRET` (paste their actual values in the dashboard, not GitHub/source/ChatGPT). No OpenAI API key is required. Configure only after the Worker has been created, before testing OAuth.
6. Connect **GitHub** as the Worker deployment source through Cloudflare's dashboard. Grant Cloudflare access **only** to `ryanmtbrown-dotcom/UPC-List-Builder` if possible. The worker's project/root directory must be `integrations/chatgpt-mcp/cloudflare`. Build command may be left empty; deployment command is `npx wrangler deploy` from that directory. **Do not connect auto-deploy of the Android app or its public updater.**
7. Alternatively, on a trusted laptop/Termux checkout of this draft branch with Node 24+, run the following inside `integrations/chatgpt-mcp/cloudflare`:
   - `npm install`
   - `npx wrangler login` (browser-based sign-in; tokens stay with your machine)
   - `npx wrangler d1 migrations apply DB --remote` (creates the D1 tables)
   - `npx wrangler secret put GITHUB_CLIENT_ID` and then `npx wrangler secret put GITHUB_CLIENT_SECRET`, entering them locally
   - `npx wrangler deploy`
   - Never send tokens/secrets through ChatGPT or store them in git.
8. If using the **dashboard-only** route, open the D1 database **Console**, paste/run the SQL from `migrations/0001_import_queue.sql` and then `migrations/0002_review_gate.sql` (once each), then deploy the Worker from GitHub. The migration creates only the new optional service tables, not any mobile app databases. The OAuth KV is managed automatically by the provider.
9. Confirm the deployed `https://upc-dsd-chatgpt.YOUR-SUBDOMAIN.workers.dev/health` identifies `workflowVersion: "2.0.0"` and `reviewRequired: true`. This checks only the server route, **not** GitHub sign-in, MCP authentication, or device pairing.
10. On ChatGPT **web**, open Plugins, add a custom MCP server at `https://upc-dsd-chatgpt.YOUR-SUBDOMAIN.workers.dev/mcp`, choose OAuth, install, and complete the GitHub sign-in. Test `create_dsd_pairing_code`. It returns a one-use 24-character code that expires in 10 minutes.
11. Once the updated UPC List Builder Android APK has been separately published and installed, enable ChatGPT Invoice Import in ACE New DSD Items, enter the server **origin** (without `/mcp`), paste the pairing code and press Pair This Device. Check Pending Imports and select Import into DSD (saves an editable Work Session and acknowledges the pending batch) or Reject Pending (deletes only that account's pending batch). Verify price, cost, order multiple, UPC and department in the existing DSD editor before export.

**Important:** Cloudflare free tier has request/CPU and D1 usage limits. The source cannot bypass the Cloudflare account registration, creating OAuth App credentials, nor a real installed Android test.

## Security / release gates

- Do not activate a public worker before confirming only HTTPS, OAuth scope, user isolation, short-lived one-use codes, and per-device revocation work end-to-end.
- The identity provider is GitHub; this **does not** require that users have ChatGPT paid API access. They need a ChatGPT account with custom MCP plugin access and an external GitHub account to sign in.
- Encrypted secrets: GitHub OAuth client credentials only in Cloudflare's Secret storage. Other users' ChatGPT or GitHub passwords are never handled by UPC List Builder.
- Mobile tokens remain Keystore-backed (separate from AceNet). Browser preview tokens are memory-only.
- Each Cloudflare D1 database includes user-specific pending/acknowledged batches. Same payload is idempotent. No cross-user reads. Batch rejection is restricted to the paired owner and state=pending; accepted/imported batches cannot be rejected.
- D1 deletion/expiry is lazy; backup and privacy retention policies need review before offering the service broadly.
- The plugin owns manufacturer and document-number interpretation, not the Android app. WWD is primary only when no other primary manufacturer is established; with another primary manufacturer, WWD is secondary. For the DSD invoice field use primary manufacturer invoice > primary manufacturer PO with prefix PO > 00000 placeholder. Buyer POs and secondary invoice numbers never override the primary manufacturer's number. Clarify contradictory source labels before submission. Test this with at least two supplier document styles and an installed Android app before removing draft status or publishing.

## DSD review v3 candidate (not production)

- Supported file-parameter shape: `invoiceFile: {download_url,file_id,mime_type?,file_name?}`, registered with `_meta['openai/fileParams']`. ChatGPT must supply this as an authorized file input; never invent a signed URL or claim a filename proves possession. Worker retrieves up to 10 MiB via allowlisted HTTPS origins; an operator may configure additional trusted hosts through `INVOICE_FILE_HOSTS`. File bytes and URLs are not persisted or passed to Android.
- Receipt `document_received` records SHA-256, type and byte size, but does not attest that the contents are an actual invoice. The visible user approval still reviews the invoice identity and merchandise facts. Additional independent content-recognition capability remains an explicit, separately scoped follow-up if required.
- The server rejects unrecognized pricing methods, inconsistent percentage/dollar units and repeated or excessive serialized quantities, providing recoverable error codes and steps to repair without requesting new user input unnecessarily.
- Review v3 is a searchable, paged ten-rows-at-a-time interface with real department choices, per-row pricing inputs, compact summary and expandable notes; no 440px nested items viewport.
- Re-created reviews invalidate earlier unapproved versions. Existing owner-bound approval, timeouts, receipts and Cloudflare queue idempotency remain intact.
- No migration, OAuth, pairing, boot/startup or unrelated planogram changes are included. Host file inputs and actual Android touch behavior still require integrated verification.

## Document recognition requirement

The current candidate uses the `AI` Worker binding for server-side PDF/image text conversion. File bytes alone are not evidence of a matching supplier invoice. A matching invoice number and product identifier in extracted document text are required before waiving repeated internet research. Inability to inspect content fails closed or uses an already-complete external research report. The conversion service may consume Workers AI free allocation for images; keep the plan and usage limits under review. Do not claim supplier authenticity or all line items have been independently certified.
