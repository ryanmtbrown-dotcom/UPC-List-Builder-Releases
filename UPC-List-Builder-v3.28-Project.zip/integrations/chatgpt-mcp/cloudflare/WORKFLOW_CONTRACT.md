# DSD invoice review and approval contract

Status: implemented candidate; deployment and hosted-client verification are separate requirements.

## Owners

- `tools.mjs`: MCP schemas, descriptions, visibility, server initialization instructions and composition.
- `review-policy.mjs`: pure invoice normalization, department suggestions and research-report validation.
- `review-store.mjs`: durable account-bound reviews, rendered callbacks, immutable approval choices, expiration and receipt recovery.
- `review-ui.mjs`: item/source presentation, department/markup choices, uncertainty acknowledgment and the Approve & send interaction.
- `workflow-errors.mjs`: safe, model-readable blocked-step feedback.
- `queue.mjs`: pending batches, payload idempotency, pairing and device delivery. Android remains final pricing, validation, SKU and export authority.

## Required flow

1. For a supplier invoice attached in ChatGPT, pass the actual file through the host-backed `invoiceFile` tool parameter. The Worker fetches up to 10 MiB of the original PDF/image bytes from an allowlisted HTTPS file host, checks a supported signature, calculates SHA-256 and stores ONLY a bound metadata receipt in its account-owned review. Filename, claimed hash, file ID alone, or `invoiceProvided: true` is NOT proof. Without a received document, every retained merchandise item requires the current structured `researchEvidence` report. Source-reported identity is evidence, not server-verified truth.
2. Call `review_dsd_import`. The Worker normalizes costs, strict case-insensitive pricing names and explicit `%` / `# DSD invoice review and approval contract

Status: implemented candidate; deployment and hosted-client verification are separate requirements.

## Owners

- `tools.mjs`: MCP schemas, descriptions, visibility, server initialization instructions and composition.
- `review-policy.mjs`: pure invoice normalization, department suggestions and research-report validation.
- `review-store.mjs`: durable account-bound reviews, rendered callbacks, immutable approval choices, expiration and receipt recovery.
- `review-ui.mjs`: item/source presentation, department/markup choices, uncertainty acknowledgment and the Approve & send interaction.
- `workflow-errors.mjs`: safe, model-readable blocked-step feedback.
- `queue.mjs`: pending batches, payload idempotency, pairing and device delivery. Android remains final pricing, validation, SKU and export authority.

## Required flow

1. For a supplier invoice attached in ChatGPT, pass the actual file through the host-backed `invoiceFile` tool parameter. The Worker fetches up to 10 MiB of the original PDF/image bytes from an allowlisted HTTPS file host, checks a supported signature, calculates SHA-256 and stores ONLY a bound metadata receipt in its account-owned review. Filename, claimed hash, file ID alone, or `invoiceProvided: true` is NOT proof. Without a received document, every retained merchandise item requires the current structured `researchEvidence` report. Source-reported identity is evidence, not server-verified truth.
 values, splits printed serials into separate DSD rows, and rejects unknown or conflicting pricing with actionable errors. Missing serials remain allowed. It then validates invoice-file possession OR research coverage and creates an expiring owner-bound review. Raw invoice bytes/URLs never enter D1 or Android pending batches. Source receipt proves actual file bytes were received, **NOT supplier authenticity or independently extracted invoice fields**.
3. The registered MCP Apps component initializes the host bridge, presents a compact searchable/pageable (10 items/page) review, displays the department registry and editable per-item method, `%` or `# DSD invoice review and approval contract

Status: implemented candidate; deployment and hosted-client verification are separate requirements.

## Owners

- `tools.mjs`: MCP schemas, descriptions, visibility, server initialization instructions and composition.
- `review-policy.mjs`: pure invoice normalization, department suggestions and research-report validation.
- `review-store.mjs`: durable account-bound reviews, rendered callbacks, immutable approval choices, expiration and receipt recovery.
- `review-ui.mjs`: item/source presentation, department/markup choices, uncertainty acknowledgment and the Approve & send interaction.
- `workflow-errors.mjs`: safe, model-readable blocked-step feedback.
- `queue.mjs`: pending batches, payload idempotency, pairing and device delivery. Android remains final pricing, validation, SKU and export authority.

## Required flow

1. For a supplier invoice attached in ChatGPT, pass the actual file through the host-backed `invoiceFile` tool parameter. The Worker fetches up to 10 MiB of the original PDF/image bytes from an allowlisted HTTPS file host, checks a supported signature, calculates SHA-256 and stores ONLY a bound metadata receipt in its account-owned review. Filename, claimed hash, file ID alone, or `invoiceProvided: true` is NOT proof. Without a received document, every retained merchandise item requires the current structured `researchEvidence` report. Source-reported identity is evidence, not server-verified truth.
2. Call `review_dsd_import`. The Worker normalizes costs, strict case-insensitive pricing names and explicit `%` / `# DSD invoice review and approval contract

Status: implemented candidate; deployment and hosted-client verification are separate requirements.

## Owners

- `tools.mjs`: MCP schemas, descriptions, visibility, server initialization instructions and composition.
- `review-policy.mjs`: pure invoice normalization, department suggestions and research-report validation.
- `review-store.mjs`: durable account-bound reviews, rendered callbacks, immutable approval choices, expiration and receipt recovery.
- `review-ui.mjs`: item/source presentation, department/markup choices, uncertainty acknowledgment and the Approve & send interaction.
- `workflow-errors.mjs`: safe, model-readable blocked-step feedback.
- `queue.mjs`: pending batches, payload idempotency, pairing and device delivery. Android remains final pricing, validation, SKU and export authority.

## Required flow

1. For a supplier invoice attached in ChatGPT, pass the actual file through the host-backed `invoiceFile` tool parameter. The Worker fetches up to 10 MiB of the original PDF/image bytes from an allowlisted HTTPS file host, checks a supported signature, calculates SHA-256 and stores ONLY a bound metadata receipt in its account-owned review. Filename, claimed hash, file ID alone, or `invoiceProvided: true` is NOT proof. Without a received document, every retained merchandise item requires the current structured `researchEvidence` report. Source-reported identity is evidence, not server-verified truth.
 values, splits printed serials into separate DSD rows, and rejects unknown or conflicting pricing with actionable errors. Missing serials remain allowed. It then validates invoice-file possession OR research coverage and creates an expiring owner-bound review. Raw invoice bytes/URLs never enter D1 or Android pending batches. Source receipt proves actual file bytes were received, **NOT supplier authenticity or independently extracted invoice fields**.
 input, source receipt, warnings and supporting details, then calls app-only `record_dsd_review_rendered`. The component approval proof is in result `_meta`, hidden from model content, stored only as a hash, bound to account and review, and is not an OAuth credential.
4. The user chooses invoice/item departments and invoice/default/item pricing method and corresponding percentage or dollar value. All selectors must contain approved options. If none load, approval is disabled. Ambiguous or conflicting price units are blocked by the server. Unresolved/unavailable research and blank departments require separate explicit acknowledgments. A serial number keeps department 46. Correcting identity, quantity/cost, UPC or other product facts requires a new review.
5. Only the component Approve & send action calls app-only `submit_dsd_import` with review ID, proof and allowed choices, including an itemPricing decision for every merchandise row. The Worker independently validates the final values, not just the UI controls. Raw invoice submissions and completion flags do not satisfy the gate. The server verifies account, proof, expiry, rendered callback, research uncertainty acknowledgment and selections before the queue receives anything. The first approval locks the choices. A new review of the same invoice supersedes any earlier unapproved review, which cannot be submitted. Same-choice retries return the same queue batch; different choices cannot reuse that approval.
6. Normalized pending data reaches the existing Android DSD editor through its existing paired-device API. A server submission receipt means pending, not imported or exported.

## Recovery and trust limits

- Recoverable business failures return MCP `isError: true`, plain-language `content` and structured `code`, `missingSteps`, `nextTool`, `retrySameRequest` and `submitted`. The model must repair the named steps and must not claim success without a batch receipt.
- If a queue write or receipt confirmation is uncertain, `submitted` is null. Approved choices remain locked and exact retries safely resume payload-idempotent staging. Neither server nor UI falsely says nothing was submitted in this case. UI requests time out after 15 seconds instead of spinning indefinitely.
- The recorded research is explicitly **assistant-reported**. Requiring names, queries and URLs cannot independently prove that external search happened or that a page supports a claim. This deployment does not add a search provider or claim server-owned search execution. Independent research proof requires a separately configured server-owned lookup/search integration.
- A rendered callback proves a component-origin protocol event under a compatible host, not that a person read every item. The approval button is the normal host-mediated interaction; `_meta` and app-only visibility do not replace OAuth/account authorization and are not cryptographic proof of human attention. An authenticated custom client controlling its own account can emulate the component protocol.
- A non-UI host can inspect the model-visible review but cannot stage an invoice using completion booleans. It must use a compatible review client. The server cannot reject ordinary chat text or require a tool invocation when the assistant makes no request.
- Hosted UI compatibility, CSP and mobile layout require a live client test. DOM/bridge tests and a Worker build do not establish hosted rendering, production deployment or physical Android behavior.

## Deployment

1. Verify the candidate's Cloudflare tests, syntax checks, Worker dry-run build and maintained project checks. Preserve the current production OAuth fixes when promoting the candidate.
2. Apply `migrations/0002_review_gate.sql` to the existing D1 database before activating the Worker. This creates only the new review table and index; it does not modify existing batches/devices or Android storage. Missing review storage fails closed with `REVIEW_STORAGE_UNAVAILABLE`.
3. Deploy the tested Worker source through the existing Cloudflare deployment branch/configuration. This does not publish an Android APK or updater change.
4. Read back `/health`: candidate code identifies `workflowVersion: "2.0.0"` and `reviewRequired: true`; a basic status response alone is insufficient to identify the candidate. Health alone does not prove D1 migration, OAuth or hosted UI.
5. Verify the connected plugin discovers `review_dsd_import` and its v2 HTML resource. The model-facing workflow uses pairing, review and status tools; rendered callback and submission are app-only. Perform a live review, explicit approval, pending delivery and device import test before declaring end-to-end completion. Refresh/reinstall discovery through the controls actually available in the client; do not assume a Refresh button exists.
6. Full Android PR #79 publication remains separate and must follow `DEPLOYMENT_CONTRACT.md`, exact-head CI and physical-device requirements. Do not move the public updater merely to deploy this server gate.

## Hard validation and recovered workflow errors

- Pricing methods are `MARKUP` and `DIRECT`, matched without case sensitivity. A mistyped method with no unequivocal `%` or `$` signal is an error, not a fallback. The method and the amount unit must agree. No silent switch to direct retail at the Worker or Android handoff.
- Each provided serial number becomes its own DSD line, preserving repeated UPC, cost and markup. An invoice with 12 unnumbered firearms stays one item with a blank serial. For partial serial listings, the known serials receive individual rows and remaining unnumbered quantity stays one separate row with a notice. An excess/duplicate serial produces an error. A serial number does **not** itself classify a product as a firearm.
- Printed invoice UPC, MFG, quantity, cost and serials are preferred over third-party website claims; use external research when missing, ambiguous or necessary for product restriction classification.
- Cloudflare file receipt attests to downloaded bytes and format only; it does not authenticate the supplier or inspect image/PDF contents. The review should accurately display that limitation. Automated independent invoice-content verification needs a separately approved parsing/OCR capability; do not represent it as completed.
- Error codes must identify whether to correct pricing, serial quantity, department, host file availability or evidence; preserve the existing `missingSteps`, `nextTool`, `submitted` and idempotent retry semantics.
- Host file support is optional, so if a file cannot be passed/retrieved the workflow falls back to recorded research, **not** an invented invoice receipt. File-host allowlisting is configured using `INVOICE_FILE_HOSTS` only when necessary and must never be widened to arbitrary URL fetches.

## Scope

This candidate does not change DSD workbook/export pricing authority, startup, OAuth, device pairing, application launch, planogram import, or the public updater. Hosted ChatGPT file-parameter compatibility, file-host identity, 40-row phone UX and Android physical behavior must be verified before promotion.

## Hosted file-parameter compatibility and mobile recovery gate

- The native ChatGPT file parameter contract declares `download_url`, `file_id`, and optional `mime_type` / `file_name`; never manually fabricate a file object. Support both `file_...` and `file-...` identifiers, but **require** a Worker-retrieved actual byte stream from a trusted source for a proof receipt.
- ChatGPT mobile may omit or fail to resolve an attached file parameter. The plugin must not create an invoice receipt from a filename, description, screenshot reference string, hash supplied by the assistant or affirmative claim. If file bytes are unavailable, return actionable evidence errors; continue with independent product research when available. Reattaching/picking a source file is a last resort, not an automatic user demand.
- The file receipt establishes possession of a PDF/image with a matching magic signature, byte count and digest. It **does not** independently verify invoice content, supplier identity or per-item extracted fields. Do not describe that stronger verification as implemented; separate actual-document classification/inspection is a required future security enhancement if evidence policy demands genuine-invoice authentication.
- Mobile ChatGPT host fileParams and live v3 review interactions must be tested against a connected deployment before any production research exemption is considered verified. Existing production remains unchanged until then.

## Server-owned document content verification

- An uploaded file never exempts item research merely because its byte signature is PDF/JPEG/PNG/WEBP or its hash exists. Cloudflare's configured `AI.toMarkdown` binding must independently extract invoice text; `invoice-content-policy.mjs` requires recognizable invoice headings, the exact normalized primary invoice number and at least one matching UPC or manufacturer identifier from the reviewed items. The extracted text and document bytes are used transiently and are never persisted in the pending invoice queue.
- Missing AI binding, conversion errors, unreadable pages, unrelated files or mismatched invoice numbers/identifiers return actionable `INVOICE_INSPECTION_UNAVAILABLE`, `INVOICE_INSPECTION_FAILED` or `INVOICE_CONTENT_NOT_VERIFIED`. If complete independent `researchEvidence` was already supplied, the review can seamlessly continue without the invoice exemption. No `invoiceProvided` Boolean, filename or user/model assertion may grant it.
- A successful match verifies recognizable content and at least one submitted identifier; it is **not forensic supplier authentication** and does not certify every line. Targeted web classification remains necessary for uncertain firearm/ammunition/accessory descriptions. Cloudflare Workers AI free daily limits may be exhausted; never bill or upgrade without the account owner's consent, and never bypass a failed recognition because of service quotas. Clear document recognition uses Workers AI Markdown Conversion, which processes supplied invoice contents within Cloudflare.
