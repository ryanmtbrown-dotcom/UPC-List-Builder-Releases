/** OWNERSHIP: Pure invoice-content evidence matching after server-owned document conversion.
 * No file retrieval, OCR, persistence, pricing or supplier-authenticity assertions.
 */
const compact=x=>String(x??'').toUpperCase().replace(/[^A-Z0-9]/g,'');
const printable=x=>String(x??'').toUpperCase().replace(/\s+/g,' ').trim();
function matches(text,id){const key=compact(id);return key.length>=4&&compact(text).includes(key)}
export function checkInvoiceContent(markdown,invoice,items){
 const text=String(markdown??'').slice(0,130000);
 const clean=printable(text);
 if(clean.length<45)throw Error('Cloudflare could not extract enough readable invoice text.');
 if(!/\b(INVOICE|INV\b|INVOICE\s*(?:NO|NUMBER|ID|#)|BILL\s+TO|SHIP\s+TO|QTY|QUANTITY|UNIT\s+COST|ITEM\s+NO|PURCHASE\s+ORDER)\b/i.test(clean))
  throw Error('The uploaded document does not contain recognizable invoice headings.');
 if(!matches(clean,invoice?.invoiceNumber))
  throw Error('The manufacturer invoice number was not found in the uploaded document.');
 const ids=[...new Set((items||[]).flatMap(i=>[i.upc,i.mfg].map(compact)).filter(id=>id.length>=5))];
 const found=ids.filter(id=>compact(clean).includes(id));
 if(ids.length&&!found.length)
  throw Error('No submitted UPC or manufacturer number could be independently matched to the uploaded invoice.');
 if(!ids.length)throw Error('An invoice must contain at least one identifying UPC or manufacturer number to skip independent research.');
 return Object.freeze({invoiceContentVerified:true,verification:'cloudflare_document_text_match',matchedInvoiceNumber:true,matchedProductIdentifiers:found.length,
  sourceAuthenticityVerified:false});
}
