/** OWNERSHIP: Authenticated invoice-file reference retrieval and byte-level evidence receipt.
 * No image/PDF interpretation, document authenticity assertion, persistence or UI decisions.
 */
import {WorkflowError} from './workflow-errors.mjs';
import {checkInvoiceContent} from './invoice-content-policy.mjs';
const MAX_BYTES=10*1024*1024;
const sourceFail=(code,message,steps=['attach_original_invoice_file','retry_review'])=>
 new WorkflowError(code,message,steps,'review_dsd_import');
function allowedHost(host,env={}){
 const defaults=['oaiusercontent.com'];
 const configured=String(env.INVOICE_FILE_HOSTS||'').split(',').map(x=>x.trim().toLowerCase()).filter(Boolean);
 return [...defaults,...configured].some(d=>host===d||host.endsWith('.'+d));
}
function sourceUrl(raw,env){
 let url;
 try{url=new URL(raw)}catch{throw sourceFail('INVOICE_FILE_URL_INVALID','The invoice attachment has no valid temporary download URL. Attach the original file again.')}
 if(url.protocol!=='https:'||url.username||url.password||url.port&&url.port!=='443'||!allowedHost(url.hostname.toLowerCase(),env))
  throw sourceFail('INVOICE_FILE_HOST_UNSUPPORTED','The file link cannot be securely retrieved from its current host. Attach the original PDF or image through the supported ChatGPT file input.',['attach_original_invoice_file','check_supported_file_host']);
 return url;
}
function fileKind(b){
 const prefix=(...x)=>x.every((v,i)=>b[i]===v);
 if(prefix(37,80,68,70,45))return 'PDF';
 if(prefix(255,216,255))return 'JPEG';
 if(prefix(137,80,78,71,13,10,26,10))return 'PNG';
 if(prefix(73,73,42,0)||prefix(77,77,0,42))return 'TIFF';
 if(b.length>12&&prefix(82,73,70,70)&&b[8]===87&&b[9]===69&&b[10]===66&&b[11]===80)return 'WEBP';
 return '';
}
export async function receiveInvoiceSource(file,env={},download=fetch,expected={}){
 if(!file||typeof file!=='object'||Array.isArray(file))
  throw sourceFail('INVOICE_FILE_REQUIRED','The invoice-source exemption requires an actual ChatGPT file attachment, not a filename or claim.');
 const fileId=String(file.file_id||'');
 if(!/^file[-_][a-zA-Z0-9_-]{6,}$/.test(fileId))
  throw sourceFail('INVOICE_FILE_ID_INVALID','The file attachment reference is missing or invalid. Reattach the original invoice.');
 let url=sourceUrl(file.download_url,env),reply;
 try{
  for(let hop=0;hop<3;hop++){
   reply=await download(url.href,{redirect:'manual',cache:'no-store',signal:AbortSignal.timeout(15000)});
   if(![301,302,303,307,308].includes(reply.status))break;
   if(hop===2)throw Error('Too many redirects');
   url=sourceUrl(new URL(reply.headers.get('location')||'',url).href,env);
  }
 }catch(error){
  if(error instanceof WorkflowError)throw error;
  throw sourceFail('INVOICE_DOWNLOAD_UNAVAILABLE','Cloudflare could not retrieve the original invoice attachment. Reattach it, or provide independent product research.');
 }
 if(!reply?.ok||!reply.body)throw sourceFail('INVOICE_DOWNLOAD_UNAVAILABLE','The attachment download was not available. Reattach it or use the research workflow.');
 const claimed=Number(reply.headers.get('content-length'));
 if(Number.isFinite(claimed)&&claimed>MAX_BYTES)
  throw sourceFail('INVOICE_FILE_TOO_LARGE','Invoice exceeds the 10 MiB source verification limit. Provide a smaller original invoice file.');
 let parts=[],total=0;const reader=reply.body.getReader();
 try{
  while(true){
   const {done,value}=await reader.read();if(done)break;
   total+=value.byteLength;
   if(total>MAX_BYTES)throw sourceFail('INVOICE_FILE_TOO_LARGE','Invoice exceeds the 10 MiB source verification limit.');
   parts.push(value);
  }
 }catch(e){await reader.cancel().catch(()=>{});if(e instanceof WorkflowError)throw e;throw sourceFail('INVOICE_DOWNLOAD_UNAVAILABLE','The invoice download was interrupted. Retry the attachment or use researched evidence.');}
 if(total<64)throw sourceFail('INVOICE_FILE_UNRECOGNIZED','File is too small to be a supported invoice document.');
 const bytes=new Uint8Array(total);let offset=0;
 for(const part of parts){bytes.set(part,offset);offset+=part.length}
 parts=[];
 const kind=fileKind(bytes);
 if(!kind)throw sourceFail('INVOICE_FILE_UNRECOGNIZED','This attachment is not a recognizable PDF or image. Attach the invoice as PDF, JPEG, PNG, TIFF or WEBP.');
 if(!['PDF','JPEG','PNG','WEBP'].includes(kind))
  throw sourceFail('INVOICE_FILE_UNSUPPORTED','Cloudflare document recognition currently accepts PDF, JPEG, PNG and WEBP. Provide one of these formats or use independent research.');
 if(typeof env.AI?.toMarkdown!=='function')
  throw sourceFail('INVOICE_INSPECTION_UNAVAILABLE','Invoice document recognition is unavailable. Use independently researched product evidence; do not claim the invoice was verified.', ['research_product_identities','operator_enable_invoice_recognition']);
 let parsed;
 try {
  const mime={PDF:'application/pdf',JPEG:'image/jpeg',PNG:'image/png',WEBP:'image/webp'}[kind];
  const output=await env.AI.toMarkdown({name:'invoice.'+kind.toLowerCase(),blob:new Blob([bytes],{type:mime})});
  parsed=Array.isArray(output)?output[0]:Array.isArray(output?.results)?output.results[0]:output;
  if(!parsed||parsed.format==='error'||typeof parsed.data!=='string')throw Error('Document conversion returned no readable text.');
 }catch(error){throw sourceFail('INVOICE_INSPECTION_FAILED','Cloudflare could not inspect this invoice document. Use independent research or provide a clearer PDF/image; do not skip verification.', ['research_product_identities','retry_original_invoice']);}
 let evidence;
 try{evidence=checkInvoiceContent(parsed.data,expected.invoice,expected.items);}
 catch(error){throw sourceFail('INVOICE_CONTENT_NOT_VERIFIED',error.message+' Use independent research or a legible matching invoice.', ['research_product_identities','correct_invoice_transcription','retry_original_invoice']);}
 const digest=await crypto.subtle.digest('SHA-256',bytes);
 const sha256=Array.from(new Uint8Array(digest),x=>x.toString(16).padStart(2,'0')).join('');
 return Object.freeze({status:'document_received',fileId,sha256,bytes:total,format:kind,
  fileName:String(file.file_name||'').slice(0,120),
  verification:'cloudflare_downloaded_file_bytes',
  ...evidence});
}
