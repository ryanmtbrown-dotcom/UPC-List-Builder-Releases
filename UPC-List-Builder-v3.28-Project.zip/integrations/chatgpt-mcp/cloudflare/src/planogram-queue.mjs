/**
 * OWNERSHIP: Isolated planogram D1 owner-scoped staging and complete-batch transport.
 * Does not own: DSD queues, OAuth consent, PDF interpretation, Android layout changes.
 * Side effects: D1 SQL; never stores PDF/blob or unaccepted physical placements.
 */
import {validatePlanogram,validatePlanogramHeader,validateChunkRows,verifySourceDigest,MAX_CHUNKS} from './planogram-validate.mjs';
const DAY=86400000;
const ownerId=owner=>{if(typeof owner!=='string'||!/^github:\d{1,20}$/.test(owner))throw Error('Not authenticated');return owner};
const hex=async value=>[...new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(value)))].map(x=>x.toString(16).padStart(2,'0')).join('');
export function createPlanogramQueue(db){
 if(!db||typeof db.prepare!=='function')throw Error('Planogram D1 unavailable');
 async function prune(){const t=Date.now();await db.batch([
  db.prepare('DELETE FROM planogram_chunks WHERE session_id IN (SELECT id FROM planogram_sessions WHERE created < ?)').bind(t-2*DAY),
  db.prepare('DELETE FROM planogram_sessions WHERE created < ?').bind(t-2*DAY),
  db.prepare("DELETE FROM planogram_batches WHERE state='imported' AND updated < ?").bind(t-30*DAY),
  db.prepare("DELETE FROM planogram_batches WHERE state='pending' AND created < ?").bind(t-90*DAY)]);}
 async function store(owner,source){
  ownerId(owner);const item=validatePlanogram(source),digest=await verifySourceDigest(item);
  if(item.manifest.expectedChunks!==1)throw Error('Use chunked import for multiple chunks');
  const content=JSON.stringify({...item,manifest:{...item.manifest,sourceDigest:digest}});
  const id=crypto.randomUUID(),t=Date.now();
  await db.prepare("INSERT OR IGNORE INTO planogram_batches(id,owner,digest,payload,state,created,updated) VALUES (?,?,?,?,?,?,?)")
   .bind(id,owner,digest,content,'pending',t,t).run();
  const row=await db.prepare('SELECT id,state FROM planogram_batches WHERE owner=? AND digest=?').bind(owner,digest).first();
  return{batchId:row.id,state:row.state,sourceId:item.source.planogramId,sourceRowCount:item.reconciliation.sourceReportRows,
    distinctSkuCount:item.reconciliation.distinctMerchandiseSkus,needsReview:!!(item.reconciliation.unresolvedRows||item.reconciliation.unrepresentedRows),digest};
 }
 async function begin(owner,input){
  ownerId(owner);await prune();const header=validatePlanogramHeader(input),id=crypto.randomUUID();
  await db.prepare('INSERT INTO planogram_sessions(id,owner,header,created) VALUES (?,?,?,?)')
   .bind(id,owner,JSON.stringify(header),Date.now()).run();
  return{sessionId:id,expectedChunks:header.manifest.expectedChunks};
 }
 async function append(owner,sessionId,index,rows){
  ownerId(owner);if(typeof sessionId!=='string'||!/^[0-9a-f-]{36}$/i.test(sessionId))throw Error('Invalid session ID');
  const s=await db.prepare('SELECT header FROM planogram_sessions WHERE id=? AND owner=? AND created>?')
   .bind(sessionId,owner,Date.now()-2*DAY).first();if(!s)throw Error('Session unavailable or expired');
  const header=JSON.parse(s.header);if(!Number.isSafeInteger(index)||index<0||index>=header.manifest.expectedChunks||index>=MAX_CHUNKS)throw Error('Chunk index out of range');
  const cleaned=validateChunkRows(rows,header.schemaVersion),payload=JSON.stringify(cleaned),digest=await hex(payload);
  await db.prepare('INSERT OR IGNORE INTO planogram_chunks(session_id,owner,chunk_index,digest,payload,created) VALUES (?,?,?,?,?,?)')
   .bind(sessionId,owner,index,digest,payload,Date.now()).run();
  const current=await db.prepare('SELECT digest FROM planogram_chunks WHERE session_id=? AND owner=? AND chunk_index=?').bind(sessionId,owner,index).first();
  if(current?.digest!==digest)throw Error('Chunk replay differs from original payload');
  return{sessionId,index,accepted:true,rowCount:cleaned.length};
 }
 async function finalize(owner,sessionId){
  ownerId(owner);if(typeof sessionId!=='string'||!/^[0-9a-f-]{36}$/i.test(sessionId))throw Error('Invalid session ID');
  const s=await db.prepare('SELECT header FROM planogram_sessions WHERE id=? AND owner=? AND created>?').bind(sessionId,owner,Date.now()-2*DAY).first();
  if(!s)throw Error('Session unavailable or expired');
  const header=JSON.parse(s.header);const rows=(await db.prepare('SELECT chunk_index,payload FROM planogram_chunks WHERE session_id=? AND owner=? ORDER BY chunk_index').bind(sessionId,owner).all()).results||[];
  if(rows.length!==header.manifest.expectedChunks)throw Error('Unfinished planogram: chunks missing');
  for(let i=0;i<rows.length;i++)if(rows[i].chunk_index!==i)throw Error('Missing chunk sequence');
  const placements=rows.flatMap(r=>JSON.parse(r.payload));
  const source=validatePlanogram({...header,placements});
  const digest=await verifySourceDigest(source);const content=JSON.stringify({...source,manifest:{...source.manifest,sourceDigest:digest}}),id=crypto.randomUUID(),t=Date.now();
  // D1 batch executes atomically: device sees a completed batch, never a partial chunk.
  await db.batch([
   db.prepare("INSERT OR IGNORE INTO planogram_batches(id,owner,digest,payload,state,created,updated) VALUES (?,?,?,?,?,?,?)").bind(id,owner,digest,content,'pending',t,t),
   db.prepare('DELETE FROM planogram_chunks WHERE session_id=? AND owner=?').bind(sessionId,owner),
   db.prepare('DELETE FROM planogram_sessions WHERE id=? AND owner=?').bind(sessionId,owner)
  ]);
  const batch=await db.prepare('SELECT id,state FROM planogram_batches WHERE owner=? AND digest=?').bind(owner,digest).first();
  return{batchId:batch.id,state:batch.state,sourceId:source.source.planogramId,sourceRowCount:placements.length,digest,
   needsReview:!!(source.reconciliation.unresolvedRows||source.reconciliation.unrepresentedRows)};
 }
 async function list(owner){ownerId(owner);await prune();const r=await db.prepare("SELECT id,created,payload FROM planogram_batches WHERE owner=? AND state='pending' ORDER BY created ASC LIMIT 40").bind(owner).all();return(r.results||[]).map(row=>{const p=JSON.parse(row.payload);return{batchId:row.id,created:row.created,planogramId:p.source.planogramId,sourceName:p.source.name,sourceReportRows:p.reconciliation.sourceReportRows,distinctMerchandiseSkus:p.reconciliation.distinctMerchandiseSkus,unresolvedRows:p.reconciliation.unresolvedRows,unrepresentedRows:p.reconciliation.unrepresentedRows}})}
 async function get(owner,id){ownerId(owner);const r=await db.prepare('SELECT id,payload,state FROM planogram_batches WHERE id=? AND owner=?').bind(id,owner).first();return r?{batchId:r.id,state:r.state,...JSON.parse(r.payload)}:null}
 async function status(owner,id){ownerId(owner);return await db.prepare('SELECT id,state,updated FROM planogram_batches WHERE id=? AND owner=?').bind(id,owner).first()}
 async function acknowledge(owner,id){ownerId(owner);const r=await db.prepare("UPDATE planogram_batches SET state='imported',updated=? WHERE id=? AND owner=? AND state='pending'").bind(Date.now(),id,owner).run();return r.meta?.changes===1||(await status(owner,id))?.state==='imported'}
 async function reject(owner,id){ownerId(owner);const r=await db.prepare("DELETE FROM planogram_batches WHERE id=? AND owner=? AND state='pending'").bind(id,owner).run();return r.meta?.changes===1}
 return Object.freeze({store,begin,append,finalize,list,get,status,acknowledge,reject});
}
