/**
 * OWNERSHIP: Strict, versioned AI-interpreted planogram data validation.
 * Does not own: PDF parsing, source inference, DSD pricing, persistence, or UI.
 * Side effects: None; source JSON remains untrusted until accepted by the user.
 */
export const PLANOGRAM_SCHEMA='PLANOGRAM_IMPORT_V2';
export const PLANOGRAM_LEGACY_SCHEMA='PLANOGRAM_IMPORT_V1';
const supportedSchema=s=>s===PLANOGRAM_SCHEMA||s===PLANOGRAM_LEGACY_SCHEMA;
export const MAX_SOURCE_ROWS=3500, MAX_CHUNK_ROWS=100, MAX_CHUNKS=64;
const types=new Set(['PEG','SHELF','SPCFIX','OTHER','UNKNOWN']);
const states=new Set(['MERCHANDISE','NON_MERCHANDISE','UNRESOLVED']);
const sourcePositions=new Set(['REPORTED','DIAGRAM_ESTIMATE','UNRESOLVED']);
const visualModes=new Set(['COUNTED','ZONE','REPORTED','UNRESOLVED']);
const visualZones=new Set(['LFT','L-CNT','CNT','CNT-R','RGT']);
function obj(x,label,allowed,required=[]){
 if(!x||Array.isArray(x)||typeof x!=='object')throw Error(label+' must be an object');
 for(const k of Object.keys(x))if(!allowed.includes(k))throw Error(label+' has unsupported field '+k);
 for(const k of required)if(!Object.hasOwn(x,k))throw Error(label+' requires '+k);
 return x;
}
function str(x,label,max=240,{optional=false}={}){
 if((x===null||x===undefined||x==='')&&optional)return null;
 if(typeof x!=='string'||x.length>max||!x.trim()||/[\u0000-\u001f\u007f]/.test(x))throw Error(label+' is invalid');
 return x.trim();
}
function num(x,label,max,zero=true){if(!Number.isSafeInteger(x)||x<Number(!zero)||x>max)throw Error(label+' invalid');return x}
function arr(x,label,max){if(!Array.isArray(x)||x.length>max)throw Error(label+' invalid');return x}
function one(x,label,choices){if(!choices.has(x))throw Error(label+' invalid');return x}
export function sourceHeader(input){
 const x=obj(input,'source',['planogramId','name','commodityCode','commodityGroup','liveDate','nominalWidthFt','nominalFourFootSections','widthEvidence','sourceFilename','sourceIdentityEvidence'],['planogramId','name','sourceIdentityEvidence','nominalWidthFt','nominalFourFootSections','widthEvidence']);
 const s={planogramId:str(x.planogramId,'source ID',100),name:str(x.name,'source name',180),
  commodityCode:str(x.commodityCode,'commodity code',100,{optional:true}),
  commodityGroup:str(x.commodityGroup,'commodity group',180,{optional:true}),
  liveDate:str(x.liveDate,'printed live date',45,{optional:true}),
  nominalWidthFt:x.nominalWidthFt,nominalFourFootSections:x.nominalFourFootSections,
  widthEvidence:str(x.widthEvidence,'source width evidence',550),
  sourceFilename:str(x.sourceFilename,'source filename',200,{optional:true}),
  sourceIdentityEvidence:str(x.sourceIdentityEvidence,'source identity evidence',550)};
 if(!Number.isFinite(s.nominalWidthFt)||s.nominalWidthFt<=0||s.nominalWidthFt>200)throw Error('Nominal width invalid');
 if(!Number.isSafeInteger(s.nominalFourFootSections)||s.nominalFourFootSections<1||s.nominalFourFootSections>50||s.nominalFourFootSections!==Math.ceil(s.nominalWidthFt/4))throw Error('AI-declared four-foot section count does not match supported source width');
 if(s.liveDate&&!/^\d{4}-\d{2}-\d{2}$/.test(s.liveDate))throw Error('Date must be source-supported ISO date');
 return s;
}
function segments(input){
 const list=arr(input,'source segments',80);const seen=new Set();
 return list.map((v,i)=>{obj(v,'segment',['id','ordinal','fixtureType','description'],['id','ordinal']);
 const id=str(v.id,'segment ID',70);if(seen.has(id))throw Error('Duplicate source segment');seen.add(id);
 return{id,ordinal:num(v.ordinal,'segment ordinal',1000,false),
  fixtureType:v.fixtureType==null?null:one(v.fixtureType,'segment fixture type',types),
  description:str(v.description,'segment description',240,{optional:true})};
 });
}
export function placementRow(v,schema=PLANOGRAM_LEGACY_SCHEMA){
 obj(v,'source row',['sourceRowId','sku','upcOrGtin','description','sourceSegment','fixtureType','reportRow','reportColumn','fixtureLabel','fixtureZone','facings','sourcePage','sourcePositionStatus','sourcePositionNote',...(schema===PLANOGRAM_SCHEMA?['visualMode','visualOrder','visualShelf','visualColumnStart','visualColumnEnd','visualZone']:[]),'membershipDisposition'],['sourceRowId','membershipDisposition']);
 const p={sourceRowId:str(v.sourceRowId,'source row ID',80),sku:str(v.sku,'SKU',80,{optional:true}),
 upcOrGtin:str(v.upcOrGtin,'GTIN',30,{optional:true}),description:str(v.description,'description',300,{optional:true}),
 sourceSegment:str(v.sourceSegment,'source segment',80,{optional:true}),
 fixtureType:v.fixtureType==null?'UNKNOWN':one(v.fixtureType,'fixture type',types),
 reportRow:v.reportRow==null?null:str(String(v.reportRow),'reported row',70),
 reportColumn:v.reportColumn==null?null:str(String(v.reportColumn),'reported column',70),
 fixtureLabel:str(v.fixtureLabel,'source fixture',120,{optional:true}),
  fixtureZone:v.fixtureZone==null?null:one(v.fixtureZone,'fixture zone',new Set(['LFT','CL','CTR','CR','RGT'])),
 facings:v.facings==null?null:num(v.facings,'source facings',200,false),
 sourcePage:v.sourcePage==null?null:num(v.sourcePage,'source page',10000,false),
 sourcePositionStatus:v.sourcePositionStatus==null?null:one(v.sourcePositionStatus,'source position status',sourcePositions),
 sourcePositionNote:str(v.sourcePositionNote,'source position evidence or uncertainty',240,{optional:true}),
 membershipDisposition:one(v.membershipDisposition,'membership disposition',states)};
 if(schema===PLANOGRAM_SCHEMA){
  p.visualMode=v.visualMode==null?null:one(v.visualMode,'visual mode',visualModes);
  p.visualOrder=v.visualOrder==null?null:num(v.visualOrder,'visual item order',MAX_SOURCE_ROWS,false);
  p.visualShelf=v.visualShelf==null?null:num(v.visualShelf,'visual shelf ordinal',200,false);
  p.visualColumnStart=v.visualColumnStart==null?null:num(v.visualColumnStart,'visual column start',400,false);
  p.visualColumnEnd=v.visualColumnEnd==null?null:num(v.visualColumnEnd,'visual column end',400,false);
  p.visualZone=v.visualZone==null?null:one(v.visualZone,'visual zone',visualZones);
 }
 if(p.upcOrGtin){
  if(!/^\d{8}$|^\d{12,14}$/.test(p.upcOrGtin))throw Error('GTIN unsupported; preserve only 8/12/13/14-digit identifiers');
  if(/^0+$/.test(p.upcOrGtin))throw Error('GTIN all-zero placeholder is invalid');
  let sum=0;for(let i=p.upcOrGtin.length-2,j=0;i>=0;i--,j++)sum+=Number(p.upcOrGtin[i])*(j%2===0?3:1);
  if((10-sum%10)%10!==Number(p.upcOrGtin.at(-1)))throw Error('GTIN failed checksum');
 }
 if(p.membershipDisposition==='MERCHANDISE'&&!p.sku)throw Error('Merchandise without verified SKU must be unresolved');
 if(p.membershipDisposition==='MERCHANDISE'&&p.fixtureType==='SHELF'){
  if(!p.sourcePositionStatus||!p.sourcePositionNote)throw Error('Shelf merchandise requires source position status and evidence note');
  const reported=p.reportRow!=null||p.reportColumn!=null||p.fixtureZone!=null;
  if(p.sourcePositionStatus==='REPORTED'&&!reported)throw Error('Reported shelf position requires actual ROW/COL or zone');
  if(p.sourcePositionStatus==='DIAGRAM_ESTIMATE'&&/^(unknown|none|unavailable|shelf)$/i.test(p.sourcePositionNote))throw Error('Diagram shelf estimate must describe the source-supported position');
  if(p.sourcePositionStatus==='UNRESOLVED'&&reported)throw Error('Shelf with actual ROW/COL cannot be unresolved');
 }
 if(p.membershipDisposition==='MERCHANDISE'&&p.fixtureType==='PEG'&&(!p.reportRow||!p.reportColumn))throw Error('Peg merchandise must retain Product Report ROW and COL; classify uncertain row as UNRESOLVED');
 if(schema===PLANOGRAM_SCHEMA)validateVisualPlacement(p);
 return p;
}
/** Visual placement is the authoritative Ace planogram position, regardless of
 * whether its coordinates were read from a printed table or counted in the art.
 * Printed reportRow/reportColumn stay available solely as original evidence. */
function validateVisualPlacement(p){
 if(p.membershipDisposition!=='MERCHANDISE'){
  if(p.visualMode!=null||p.visualOrder!=null||p.visualShelf!=null||p.visualColumnStart!=null||p.visualColumnEnd!=null||p.visualZone!=null)throw Error('Nonmerchandise cannot claim a visual position');
  return;
 }
 if(!p.visualMode)throw Error('V2 merchandise requires visual mode');
 const shelf=p.fixtureType==='SHELF',special=p.fixtureType==='SPCFIX';
 if(p.visualMode==='COUNTED'){
  if(!(shelf||special||p.fixtureType==='PEG')||p.visualColumnStart==null||p.visualColumnEnd==null||p.visualColumnEnd<p.visualColumnStart||p.visualZone!=null)throw Error('Counted visual location requires inclusive start and end with no zone');
  if(shelf&&p.visualShelf==null)throw Error('Counted shelf requires shelf ordinal');
  if(p.fixtureType!=='PEG'&&p.facings!=null&&p.facings!==p.visualColumnEnd-p.visualColumnStart+1)throw Error('Inclusive visual span must match facings');
 }else if(p.visualMode==='ZONE'){
  if(!(shelf||special)||!p.visualZone||p.visualColumnStart!=null||p.visualColumnEnd!=null)throw Error('Visual zone requires dense shelf or fixture and no columns');
  if(shelf&&p.visualShelf==null)throw Error('Zoned shelf requires shelf ordinal');
 }else{
  if(p.visualColumnStart!=null||p.visualColumnEnd!=null||p.visualZone!=null)throw Error('Reported or unresolved visual mode must not claim derived columns or zone');
  if(p.visualMode==='REPORTED'&&p.reportRow==null&&p.reportColumn==null&&p.fixtureZone==null)throw Error('Reported visual location requires printed position');
 }
 if(p.sourcePositionStatus==='UNRESOLVED'&&p.visualMode!=='UNRESOLVED')throw Error('Unresolved position evidence cannot claim a verified visual location');
 if(p.visualMode==='UNRESOLVED'){
  if(p.visualOrder!=null)throw Error('Unresolved visual position cannot claim confirmed item order');
  if(!p.sourcePositionNote)throw Error('Unresolved visual position requires explanation');
 }else if(p.visualOrder==null)throw Error('Positioned V2 merchandise requires visual item order');
 if((shelf||special)&&!p.sourcePositionNote)throw Error('Shelf or specialty position requires diagram evidence');
}
/** Compare positional identity for duplicate Product Report rows for one visual item. */
function checkVisualSequence(placements,sourceSegments){
 const seen=new Map(),columns=new Map();
 for(const p of placements.filter(x=>x.membershipDisposition==='MERCHANDISE')){
  if(p.visualOrder!=null){
   const signature=JSON.stringify([p.sku,p.sourceSegment,p.fixtureType,p.visualMode,p.visualShelf,p.visualColumnStart,p.visualColumnEnd,p.visualZone,p.reportRow,p.fixtureType==='PEG'&&p.visualMode==='COUNTED'?null:p.reportColumn]);
   const prior=seen.get(p.visualOrder);
   if(prior!=null&&prior!==signature)throw Error('Visual item number reused by a different placement');
   seen.set(p.visualOrder,signature);
  }
  if((p.fixtureType==='SHELF'||p.fixtureType==='PEG')&&p.visualMode==='COUNTED'){
   const key=p.sourceSegment+'|'+p.fixtureType+'|'+(p.fixtureType==='SHELF'?p.visualShelf:p.reportRow);
   if(p.fixtureType==='PEG'&&(!/^\d+$/.test(p.reportColumn)||Number(p.reportColumn)<p.visualColumnStart||Number(p.reportColumn)>p.visualColumnEnd))throw Error('Peg report column must fall inside confirmed facing span');
   if(!columns.has(key))columns.set(key,new Map());
   for(let c=p.visualColumnStart;c<=p.visualColumnEnd;c++){
    const occupied=columns.get(key).get(c);
    if(occupied!=null&&occupied!==p.visualOrder)throw Error('Different visual placements overlap counted columns');
    columns.get(key).set(c,p.visualOrder);
   }
  }
 }
 // For a repeated peg-hook record, the shared item range is one location.
 // Each original Product Report column must be an actual occupied slot; do not manufacture a gap.
 const pegGroups=new Map();for(const p of placements.filter(x=>x.fixtureType==='PEG'&&x.visualMode==='COUNTED'&&x.visualOrder!=null)){
  if(!pegGroups.has(p.visualOrder))pegGroups.set(p.visualOrder,[]);pegGroups.get(p.visualOrder).push(p);
 }
 for(const group of pegGroups.values())if(group.length>1){
  const positions=new Set(group.map(x=>Number(x.reportColumn)));
  if(positions.size!==group.length||group.some(x=>x.facings!=null&&x.facings!==1))throw Error('Repeated peg facings must be one record per distinct hook');
  const first=group[0];for(let col=first.visualColumnStart;col<=first.visualColumnEnd;col++)if(!positions.has(col))throw Error('Counted peg group has a missing hook position');
 }else{const p=group[0];if(p.facings!=null&&p.facings!==p.visualColumnEnd-p.visualColumnStart+1)throw Error('Single peg record facings disagree with span');}
 // Where diagram ordinals are explicit, the order must not contradict the left-to-right,
 // top-to-bottom sequence within an Ace source segment. Mixed crowded zones/columns
 // have no comparable numeric coordinate, so preserve the interpreter's asserted order.
 const bySegment=new Map();
 for(const p of placements.filter(x=>x.membershipDisposition==='MERCHANDISE'&&x.visualOrder!=null)){
  if(p.visualShelf==null)continue;
  if(!bySegment.has(p.sourceSegment))bySegment.set(p.sourceSegment,[]);
  bySegment.get(p.sourceSegment).push(p);
 }
 const zoneRank=new Map([['LFT',1],['L-CNT',2],['CNT',3],['CNT-R',4],['RGT',5]]);
 for(const positions of bySegment.values())for(let i=0;i<positions.length;i++)for(let j=i+1;j<positions.length;j++){
  const a=positions[i],b=positions[j];if(a.visualOrder===b.visualOrder)continue;
  const expected=a.visualShelf!==b.visualShelf?Math.sign(a.visualShelf-b.visualShelf):
   a.visualMode==='COUNTED'&&b.visualMode==='COUNTED'?Math.sign(a.visualColumnStart-b.visualColumnStart):
   a.visualMode==='ZONE'&&b.visualMode==='ZONE'?Math.sign(zoneRank.get(a.visualZone)-zoneRank.get(b.visualZone)):0;
  if(expected&&Math.sign(a.visualOrder-b.visualOrder)!==expected)throw Error('Visual item order contradicts diagram shelf/column direction');
 }
 const ordered=[...seen.keys()].sort((a,b)=>a-b);
 for(let i=0;i<ordered.length;i++)if(ordered[i]!==i+1)throw Error('Visual item numbers must be consecutive from 1');
}
function exceptions(input,label){
 return arr(input,label,MAX_SOURCE_ROWS).map(e=>{obj(e,label+' entry',['sourceRowId','reason','sourcePage','evidence'],['sourceRowId','reason']);return{
 sourceRowId:str(e.sourceRowId,label+' row',80),reason:str(e.reason,label+' reason',320),
 sourcePage:e.sourcePage==null?null:num(e.sourcePage,label+' page',10000,false),
 evidence:str(e.evidence,label+' source evidence',350,{optional:true})};});
}
function counts(input){
 obj(input,'reconciliation',['sourceReportRows','submittedRowRecords','merchandiseRows','excludedNonMerchandiseRows','unresolvedRows','distinctMerchandiseSkus','unrepresentedRows'],['sourceReportRows','submittedRowRecords','merchandiseRows','excludedNonMerchandiseRows','unresolvedRows','distinctMerchandiseSkus','unrepresentedRows']);
 return Object.fromEntries(Object.entries(input).map(([k,v])=>[k,num(v,'reconciliation '+k,MAX_SOURCE_ROWS)]));
}
function manifest(input){
 obj(input,'manifest',['submissionId','expectedChunks','sourceDigest','status'],['submissionId','expectedChunks','status']);
 return{submissionId:str(input.submissionId,'submission ID',80),expectedChunks:num(input.expectedChunks,'expected chunks',MAX_CHUNKS,false),
 sourceDigest:str(input.sourceDigest,'content digest',64,{optional:true}),status:one(input.status,'import status',new Set(['COMPLETE','INCOMPLETE']))};
}
export function validatePlanogram(input,{maxRows=MAX_SOURCE_ROWS}={}){
 obj(input,'planogram',['schemaVersion','source','sourceSegments','placements','reconciliation','exclusions','unresolved','manifest'],['schemaVersion','source','sourceSegments','placements','reconciliation','exclusions','unresolved','manifest']);
 if(!supportedSchema(input.schemaVersion))throw Error('Unsupported planogram schema');
 const source=sourceHeader(input.source),sourceSegments=segments(input.sourceSegments),
  placements=arr(input.placements,'placements',Math.min(maxRows,MAX_SOURCE_ROWS)).map(x=>placementRow(x,input.schemaVersion)),
  reconciliation=counts(input.reconciliation),exclusions=exceptions(input.exclusions,'exclusions'),
  unresolved=exceptions(input.unresolved,'unresolved'),metadata=manifest(input.manifest);
 const ids=new Set(),sids=new Set(sourceSegments.map(x=>x.id));
 for(const p of placements){
  if(ids.has(p.sourceRowId))throw Error('Repeated sourceRowId '+p.sourceRowId);
  ids.add(p.sourceRowId);
  if(p.sourceSegment&&!sids.has(p.sourceSegment))throw Error('Placement uses unknown source segment');
 }
 if(input.schemaVersion===PLANOGRAM_SCHEMA)checkVisualSequence(placements,sourceSegments);
 const filtered=kind=>placements.filter(p=>p.membershipDisposition===kind);
 const merchandise=filtered('MERCHANDISE'),excluded=filtered('NON_MERCHANDISE'),pending=filtered('UNRESOLVED');
 const check=(actual,expected,name)=>{if(actual!==expected)throw Error('Source row reconciliation mismatch: '+name)};
 check(placements.length,reconciliation.submittedRowRecords,'submittedRowRecords');
 check(merchandise.length,reconciliation.merchandiseRows,'merchandiseRows');
 check(excluded.length,reconciliation.excludedNonMerchandiseRows,'excludedNonMerchandiseRows');
 check(pending.length,reconciliation.unresolvedRows,'unresolvedRows');
 check(new Set(merchandise.map(x=>x.sku)).size,reconciliation.distinctMerchandiseSkus,'distinctMerchandiseSkus');
 check(reconciliation.submittedRowRecords+reconciliation.unrepresentedRows,reconciliation.sourceReportRows,'sourceReportRows');
 check(exclusions.length,excluded.length,'exclusions');check(unresolved.length,pending.length,'unresolved');
 for(const [list,k] of [[exclusions,'NON_MERCHANDISE'],[unresolved,'UNRESOLVED']]){
  const seen=new Set();for(const x of list){if(seen.has(x.sourceRowId)||!placements.some(p=>p.sourceRowId===x.sourceRowId&&p.membershipDisposition===k))throw Error('Exception row not accounted for or duplicate');seen.add(x.sourceRowId)}
 }
 if(metadata.status==='COMPLETE'&&reconciliation.unrepresentedRows!==0)throw Error('Source report missing rows; cannot mark complete');
 const result={schemaVersion:input.schemaVersion,source,sourceSegments,placements,reconciliation,exclusions,unresolved,manifest:metadata};
 if(JSON.stringify(result).length>800000)throw Error('Planogram exceeds maximum validated size');
 return result;
}
// Stable source bytes, excluding transport-only digest and chunk count.
export function canonicalSourcePayload(x){
 const value=JSON.parse(JSON.stringify(x));
 if(value.manifest){value.manifest.sourceDigest=null;value.manifest.expectedChunks=1;}
 return JSON.stringify(value);
}
export async function digestSource(x){
 const bytes=new TextEncoder().encode(canonicalSourcePayload(x));
 const sha=await crypto.subtle.digest('SHA-256',bytes);
 return [...new Uint8Array(sha)].map(x=>x.toString(16).padStart(2,'0')).join('');
}
export async function verifySourceDigest(x){const digest=await digestSource(x);if(x.manifest.sourceDigest&&x.manifest.sourceDigest!==digest)throw Error('Source digest mismatch');return digest}
export function validateChunkRows(rows,schema=PLANOGRAM_LEGACY_SCHEMA){const checked=arr(rows,'chunk rows',MAX_CHUNK_ROWS).map(x=>placementRow(x,schema)),seen=new Set();for(const row of checked){if(seen.has(row.sourceRowId))throw Error('Duplicate source row in chunk');seen.add(row.sourceRowId)}return checked}
export function validatePlanogramHeader(input){
 obj(input,'planogram header',['schemaVersion','source','sourceSegments','reconciliation','exclusions','unresolved','manifest'],['schemaVersion','source','sourceSegments','reconciliation','exclusions','unresolved','manifest']);
 if(!supportedSchema(input.schemaVersion))throw Error('Unsupported planogram schema');
 const header={schemaVersion:input.schemaVersion,source:sourceHeader(input.source),sourceSegments:segments(input.sourceSegments),reconciliation:counts(input.reconciliation),exclusions:exceptions(input.exclusions,'exclusions'),unresolved:exceptions(input.unresolved,'unresolved'),manifest:manifest(input.manifest)};
 if(header.manifest.expectedChunks<2)throw Error('Use submit_planogram_import for single chunk');
 if(JSON.stringify(header).length>50000)throw Error('Header too large');
 return header;
}
