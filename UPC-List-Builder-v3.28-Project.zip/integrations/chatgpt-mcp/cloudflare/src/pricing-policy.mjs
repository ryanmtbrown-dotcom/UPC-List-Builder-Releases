/** OWNERSHIP: Strict DSD pricing input normalization and conflict detection.
 * Does not calculate a retail price. Unknown modes never become DIRECT.
 */
const val=x=>String(x??'').trim();
const fail=(where,msg)=>{throw Error(where+': '+msg)};
export function amount(raw,kind,where){
 const s=val(raw);
 if(!s)return '';
 if(!/^(?:\$)?(?:0|[1-9]\d*)(?:\.\d{1,4})?%?$/.test(s))
  fail(where,'Enter a valid '+(kind==='markup'?'percentage':'dollar amount')+'.');
 const pct=s.endsWith('%'),dollar=s.startsWith('$');
 if(kind==='markup'&&dollar)fail(where,'Dollar sign conflicts with a percentage markup.');
 if(kind==='retail'&&pct)fail(where,'Percentage sign conflicts with a dollar retail price.');
 const number=Number(s.replace(/[$%]/g,''));
 if(!Number.isFinite(number)||number<0||number>1000000)fail(where,'Pricing amount is outside the supported range.');
 if(kind==='markup'&&number>10000)fail(where,'Markup may not exceed 10000%.');
 if(kind==='retail'&&!Number.isInteger(Math.round(number*10000)))fail(where,'Invalid retail amount.');
 return String(number);
}
export function pricingMode(method,{markup='',retail=''}={},where='Pricing'){
 const raw=val(method),key=raw.toUpperCase().replace(/[-_ ]+/g,'');
 if(key==='MARKUP'||key==='MARKUP%'||key==='PERCENTMARKUP'||key==='PERCENTAGE')return 'MARKUP';
 if(key==='DIRECT'||key==='MANUALRETAIL'||key==='DIRECTRETAIL'||key==='MSRP')return 'DIRECT';
 const m=val(markup),r=val(retail),hasPct=m.endsWith('%')||r.endsWith('%'),hasDollar=m.startsWith('$')||r.startsWith('$');
 if(hasPct&&hasDollar)fail(where,'Both dollar and percentage indicators were supplied; select one pricing method.');
 if(hasPct)return 'MARKUP';
 if(hasDollar)return 'DIRECT';
 if(raw)fail(where,'Unrecognized retail method "'+raw+'". Use MARKUP or DIRECT, or specify 35% / $35.00 explicitly.');
 if(m&&!r)return 'MARKUP';
 if(r&&!m)return 'DIRECT';
 if(m&&r)fail(where,'Pricing method is ambiguous; choose MARKUP or DIRECT.');
 return '';
}
export function normalizePricing(invoice,items,warnings=[]){
 const head={...invoice};
 const method=pricingMode(head.defaultRetailMethod,{markup:head.defaultMarkup},'Invoice pricing method');
 if(val(head.defaultRetailMethod)&&method!==val(head.defaultRetailMethod).toUpperCase())
  warnings.push('Invoice pricing method was normalized to '+method+' from explicit evidence.');
 head.defaultRetailMethod=method;
 head.defaultMarkup=amount(head.defaultMarkup,'markup','Invoice default markup');
 if(method==='DIRECT'&&head.defaultMarkup!=='')
  fail('Invoice pricing','Manual retail mode cannot carry a percentage default markup.');
 const rows=items.map((i,j)=>{
  const item={...i},where='Item '+(j+1),mode=pricingMode(item.retailMethod,{markup:item.markup,retail:item.retail},where+' retail method');
  if(val(item.retailMethod)&&mode!==val(item.retailMethod).toUpperCase())
   warnings.push(where+' pricing method was normalized to '+mode+' using explicit pricing evidence.');
  item.retailMethod=mode||((item.markup===''&&item.retail==='')?head.defaultRetailMethod:'');
  item.markup=amount(item.markup,'markup',where+' markup');
  item.retail=amount(item.retail,'retail',where+' retail');
  if(item.retailMethod==='DIRECT'&&item.markup!=='')
   fail(where,'Dollar pricing conflicts with an item markup value.');
  if(item.retailMethod==='MARKUP'&&item.retail!==''&&item.retailOverrideConfirmed!==true)
   fail(where,'A manual retail override was given with markup pricing; explicitly confirm the override or clear retail.');
  return item;
 });
 return{invoice:head,items:rows,warnings};
}
export function requireValidPricing(batch){
 const warnings=[];
 const priced=normalizePricing(batch.invoice,batch.items,warnings);
 for(const [i,row] of priced.items.entries()){
  const method=row.retailMethod||priced.invoice.defaultRetailMethod;
  if(!method)fail('Item '+(i+1),'Select MARKUP or DIRECT before approval.');
  if(method==='MARKUP'&&row.markup===''&&priced.invoice.defaultMarkup==='')
   fail('Item '+(i+1),'Enter a markup percentage; do not substitute manual retail.');
  if(method==='DIRECT'&&row.retail==='')fail('Item '+(i+1),'Enter a dollar retail amount.');
 }
 return priced;
}
