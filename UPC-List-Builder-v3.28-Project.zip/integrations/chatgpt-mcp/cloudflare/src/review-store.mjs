/**
 * OWNERSHIP: Account-bound, expiring D1 invoice review and UI approval receipts.
 * Does not own: product research execution, pricing, OAuth or Android persistence.
 * Side effects: D1 review SQL and the injected staging queue after UI approval.
 */
import {prepareReview,requireMissingDepartmentAcknowledgment,validateResearch,DEPARTMENTS} from './review-policy.mjs';
import {WorkflowError} from './workflow-errors.mjs';
import {receiveInvoiceSource} from './invoice-source.mjs';
import {requireValidPricing} from './pricing-policy.mjs';
const encode=new TextEncoder();
const hash=async value=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',encode.encode(value))),x=>x.toString(16).padStart(2,'0')).join('');
const ownerId=owner=>{if(!/^github:\d{1,20}$/.test(owner||''))throw new WorkflowError('AUTH_REQUIRED','An authenticated account is required.',['authenticate'],'reconnect_plugin');};
const blocked=(code,message,steps)=>new WorkflowError(code,message,steps);
function invoiceFailure(error){
 const msg=String(error?.message||'Invoice facts could not be validated.');
 if(/serial number|serials|serialized/i.test(msg))
  return blocked('SERIAL_RECONCILIATION_REQUIRED',msg,['separate_one_serial_per_item','reconcile_invoice_quantity']);
 if(/retail|markup|pricing|percentage|dollar/i.test(msg))
  return blocked('PRICING_VALIDATION_REQUIRED',msg,['correct_method_or_unambiguous_unit','verify_item_pricing']);
 if(/cost|quantity|line total/i.test(msg))
  return blocked('COST_RECONCILIATION_REQUIRED',msg,['reconcile_unit_cost_quantity_and_total']);
 return blocked('INVOICE_VALIDATION_FAILED',msg,['verify_invoice_facts']);
}
export function createReviewStore(db,queue,sourceEnv={}) {
 async function create(owner,input) {
  ownerId(owner);
  // The original file URL and file ID must never enter the durable pending queue.
  const {invoiceFile,researchEvidence,...invoiceFacts}=input;
  let review;
  try{review=prepareReview(invoiceFacts);}catch(error){throw invoiceFailure(error);}
  let sourceError=null;
  if(invoiceFile){
   try{review.invoiceSource=await receiveInvoiceSource(invoiceFile,sourceEnv,fetch,review.batch);}
   catch(error){sourceError=error;review.invoiceSource=null;}
  }else review.invoiceSource=null;
  // Failed recognition never grants an invoice exemption. Complete existing
  // external research can recover without interrupting the user.
  if(sourceError){
   try{validateResearch(researchEvidence,review.batch.items.length);}
   catch{throw sourceError;}
   review.warnings.push('Invoice source was not independently verified; the complete research-evidence path was used instead.');
  }
  review.research=review.invoiceSource
   ? (researchEvidence?.length?validateResearch(researchEvidence,review.batch.items.length):[])
   : validateResearch(researchEvidence,review.batch.items.length);
  delete review.batch.researchEvidence;
  for(const evidence of review.research)for(const index of evidence.itemIndexes){
   const item=review.items[index];
   if(!item.effectiveDepartment&&evidence.status==='identified'&&evidence.suggestedDepartment){
    item.suggestedDepartment=evidence.suggestedDepartment;
    item.suggestionBasis='Research report: '+evidence.productName;
    item.confidence='user_review_required';
   }
  }
  review.suggestedCount=review.items.filter(x=>x.suggestedDepartment).length;
  const id=crypto.randomUUID(),proof=crypto.randomUUID()+crypto.randomUUID(),expires=Date.now()+30*60_000;
  // Fail closed when the deployment's review migration has not been applied.
  try {
   await db.prepare('DELETE FROM dsd_reviews WHERE expires < ?').bind(Date.now()).run();
   // Supersede earlier unapproved reviews of this invoice, so old screens
   // cannot submit different versions after the newest review is generated.
   // D1 CHECK only supports review/processing/submitted: use expires=0 as a
   // non-submittable superseded tombstone, scoped to the same manufacturer.
   await db.prepare("UPDATE dsd_reviews SET expires=0 WHERE owner=? AND state='review' AND json_extract(payload,'$.invoice.invoiceNumber')=? AND json_extract(payload,'$.invoice.primaryVendor')=?")
    .bind(owner,review.invoice.invoiceNumber,review.invoice.primaryVendor).run();
   await db.prepare('INSERT INTO dsd_reviews(id,owner,proof_hash,payload,state,expires) VALUES (?,?,?,?,?,?)')
    .bind(id,owner,await hash(proof),JSON.stringify(review),'review',expires).run();
  } catch {throw blocked('REVIEW_STORAGE_UNAVAILABLE','The review service is not ready. An operator must apply the review migration; do not bypass review.',['deploy_review_storage']);}
  return {...review,reviewId:id,expiresAt:expires,workflowVersion:'2.0.0',
   checklist:{researchEvidenceRecorded:review.research.length>0,originalInvoiceBytesReceived:!!review.invoiceSource,uiRendered:false,approvalRecorded:false,submitted:false},
   // Proof is returned only in tool-result _meta for the UI, never model content.
   approvalProof:proof};
 }
 async function getReview(owner,input){
  ownerId(owner);
  if(!input?.reviewId||!input?.approvalProof)
   throw blocked('REVIEW_REQUIRED','Submission requires the invoice review screen and its Approve & send action. A department/markup answer alone is not approval.',['product_research','show_item_review','user_approval']);
  let row;
  try {row=await db.prepare('SELECT * FROM dsd_reviews WHERE id=? AND owner=? AND proof_hash=? AND expires>?')
   .bind(input.reviewId,owner,await hash(input.approvalProof),Date.now()).first();}
  catch {throw blocked('REVIEW_STORAGE_UNAVAILABLE','The review service is unavailable. Do not stage the invoice.',['deploy_review_storage']);}
  if(!row){
   let previous=null;
   try{previous=await db.prepare('SELECT expires FROM dsd_reviews WHERE id=? AND owner=? AND proof_hash=?').bind(input.reviewId,owner,await hash(input.approvalProof)).first()}catch{}
   if(previous?.expires===0)throw blocked('REVIEW_SUPERSEDED','A newer review exists for this supplier invoice. Use the latest version; this one cannot be approved.',['show_latest_item_review']);
   throw blocked('REVIEW_EXPIRED_OR_INVALID','This review has expired or is unavailable to this account. Generate a fresh review.',['show_item_review','user_approval']);
  }
  return row;
 }
 async function rendered(owner,input){
  const row=await getReview(owner,input);
  if(row.rendered_at)return {reviewId:input.reviewId,uiRendered:true,approvalRecorded:row.state!=='review',
   submitted:row.state==='submitted',approvedChoices:row.approved_choices?JSON.parse(row.approved_choices):null,
   receipt:row.receipt?JSON.parse(row.receipt):null};
  await db.prepare("UPDATE dsd_reviews SET rendered_at=? WHERE id=? AND owner=? AND state='review'")
   .bind(Date.now(),input.reviewId,owner).run();
  return {reviewId:input.reviewId,uiRendered:true,submitted:false};
 }
 async function submit(owner,input) {
  const row=await getReview(owner,input);
  if(!row.rendered_at)throw blocked('UI_REVIEW_REQUIRED','The item review screen has not confirmed loading. Present the review and wait for approval through its Approve & send button.',['show_item_review','user_approval']);
  if(Object.keys(input).some(key=>!['reviewId','approvalProof','decisions'].includes(key)))
   throw blocked('REVIEW_CHANGED','Do not send replacement invoice facts or completion flags. Approve the stored review or regenerate it.',['show_updated_item_review','user_approval']);
  const review=JSON.parse(row.payload),batch=structuredClone(review.batch),decisions=input.decisions||{};
  if(Object.keys(decisions).some(key=>!['invoice','itemDepartments','itemPricing','missingDepartmentsAcknowledged','unresolvedResearchAcknowledged'].includes(key)))
   throw blocked('REVIEW_CHANGED','Unknown review choices were supplied. Regenerate the review.',['show_updated_item_review']);
  for(const key of Object.keys(decisions.invoice||{})) {
   if(!['department','defaultMarkup','defaultRetailMethod'].includes(key))
    throw blocked('REVIEW_CHANGED','Invoice identity or product facts changed. Regenerate the item review.',['show_updated_item_review','user_approval']);
   batch.invoice[key]=decisions.invoice[key];
  }
  if(decisions.itemDepartments) {
   if(decisions.itemDepartments.length!==batch.items.length)
    throw blocked('REVIEW_CHANGED','The reviewed item count changed. Regenerate the review.',['show_updated_item_review']);
   decisions.itemDepartments.forEach((department,index)=>{batch.items[index].department=department;});
  }
  if(decisions.itemPricing!==undefined){
   if(!Array.isArray(decisions.itemPricing)||decisions.itemPricing.length!==batch.items.length)
    throw blocked('REVIEW_CHANGED','Item pricing decisions must cover the same number of reviewed rows.',['review_all_item_pricing']);
   decisions.itemPricing.forEach((price,index)=>{
    if(!price||typeof price!=='object'||Object.keys(price).some(k=>!['retailMethod','markup','retail','retailOverrideConfirmed'].includes(k)))
     throw blocked('REVIEW_CHANGED','Unknown item pricing choice; regenerate the review.',['review_all_item_pricing']);
    for(const key of ['retailMethod','markup','retail'])if(Object.hasOwn(price,key))batch.items[index][key]=price[key];
    if(price.retailOverrideConfirmed===true)batch.items[index].retailOverrideConfirmed=true;
   });
  }
  if([batch.invoice.department,...batch.items.map(x=>x.department)].some(value=>
   String(value??'').trim()&&!DEPARTMENTS.some(([code])=>code===String(value).trim())))
   throw blocked('DEPARTMENT_REVIEW_REQUIRED','Choose a listed Myers department or leave it blank for explicit acknowledgment.',['department_selection_or_acknowledgment']);
  const markup=String(batch.invoice.defaultMarkup??'').trim();
  if(markup&&(!Number.isFinite(Number(markup))||Number(markup)<0))
   throw blocked('MARKUP_REVIEW_REQUIRED','Requested markup must be a nonnegative number or blank.',['review_markup']);
  batch.missingDepartmentsAcknowledged=decisions.missingDepartmentsAcknowledged===true;
  const unresolved=review.research.filter(x=>x.status!=='identified');
  if(unresolved.length&&decisions.unresolvedResearchAcknowledged!==true)
   throw blocked('RESEARCH_REVIEW_REQUIRED','Research did not identify every product. Show the recorded attempts and uncertainties, then obtain the user\'s acknowledgment.',['review_unresolved_research','user_acknowledgment']);
  // Normalize all submitted facts FIRST. Otherwise a pricing error thrown during
  // implicit normalization inside department validation is mislabeled as a department failure.
  let normalized;
  try{normalized=prepareReview(batch).batch;}catch(error){throw invoiceFailure(error);}
  try {requireMissingDepartmentAcknowledgment(batch,normalized);}catch(error){
   throw blocked('DEPARTMENT_REVIEW_REQUIRED',error.message,['department_selection_or_acknowledgment']);
  }
  try{requireValidPricing(normalized);}catch(error){throw blocked('PRICING_REVIEW_REQUIRED',error.message,['correct_pricing_method_or_amount']);}
  const missing=normalized.items.map((item,index)=>{
   const gaps=[];
   if(!/^\d{6,}$/.test(String(item.upc||'')))gaps.push('UPC');
   if(!String(item.description||'').trim())gaps.push('description');
   if(String(item.caseCost??'').trim()==='')gaps.push('cost');
   if(!Number.isFinite(Number(item.orderMultiple))||Number(item.orderMultiple)<=0)gaps.push('order multiple');
   return gaps.length?'Item '+(index+1)+': '+gaps.join(', '):'';
  }).filter(Boolean);
  if(missing.length)throw blocked('ITEM_REVIEW_REQUIRED',
   'Correct incomplete merchandise facts before approval: '+missing.slice(0,6).join('; ')+'.',
   ['correct_invoice_items','regenerate_review']);
  const digest=await hash(JSON.stringify(normalized));
  if(row.state==='submitted') {
   if(row.decision_digest!==digest)throw blocked('REVIEW_ALREADY_USED','This review already submitted different choices. Generate a new review.',['show_updated_item_review','user_approval']);
   return JSON.parse(row.receipt);
  }
  const claimed=await db.prepare("UPDATE dsd_reviews SET state='processing',decision_digest=?,approved_choices=? WHERE id=? AND owner=? AND state='review' AND expires>? RETURNING id")
   .bind(digest,JSON.stringify(decisions),input.reviewId,owner,Date.now()).first();
  if(!claimed){
   const current=await getReview(owner,input);
   if(current.decision_digest!==digest)throw blocked('REVIEW_ALREADY_USED','This review already approved different choices. Generate a new review.',['show_updated_item_review','user_approval']);
   if(current.state==='submitted')return JSON.parse(current.receipt);
   // Exact-choice retries resume the queue's owner+payload idempotent write.
  }
  try {
   const receipt=await queue.submit(owner,{...normalized,missingDepartmentsAcknowledged:batch.missingDepartmentsAcknowledged});
   await db.prepare("UPDATE dsd_reviews SET state='submitted',receipt=? WHERE id=? AND owner=? AND state='processing'")
    .bind(JSON.stringify(receipt),input.reviewId,owner).run();
   return receipt;
  } catch {
   const error=blocked('SUBMISSION_UNCONFIRMED','The submission receipt could not be confirmed. Retry the exact approved choices; do not create another invoice or claim success.',['confirm_submission_receipt']);
   error.submitted=null;error.retrySameRequest=true;error.nextTool='submit_dsd_import';
   throw error;
  }
 }
 return Object.freeze({create,rendered,submit});
}
