/**
 * OWNERSHIP: Regression coverage for the Cloudflare OAuth consent and GitHub handoff.
 * Never use real GitHub credentials or OAuth tokens in these tests.
 */
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {authRoute} from '../src/auth.mjs';

const origin='https://upc-dsd-chatgpt.ryan-m-t-brown.workers.dev';
function testEnv(overrides={}){
 return {
  GITHUB_CLIENT_ID:'test-public-client-id',
  GITHUB_CLIENT_SECRET:'test-private-secret-never-leak',
  OAUTH_PROVIDER:{
   approveConsent:async()=>({request:{scope:['dsd:write']},headers:new Headers({'Cache-Control':'no-store'})}),
   beginUpstream:async(_request,{headers})=>({state:'test-upstream-state',headers}),
   ...overrides
  }
 };
}
function postConsent(){
 return new Request(origin+'/authorize',{
  method:'POST',
  headers:{'Content-Type':'application/x-www-form-urlencoded'},
  body:new URLSearchParams({handle:'test-handle',decision:'approve',scope:'dsd:write'})
 });
}
test('approved consent redirects to GitHub with callback and state, not secrets',async()=>{
 const response=await authRoute(postConsent(),testEnv());
 assert.equal(response.status,302);
 const github=new URL(response.headers.get('Location'));
 assert.equal(github.origin,'https://github.com');
 assert.equal(github.pathname,'/login/oauth/authorize');
 assert.equal(github.searchParams.get('client_id'),'test-public-client-id');
 assert.equal(github.searchParams.get('redirect_uri'),origin+'/callback');
 assert.equal(github.searchParams.get('scope'),'read:user');
 assert.equal(github.searchParams.get('state'),'test-upstream-state');
 assert.ok(!github.href.includes('test-private-secret'));
});
test('browser-binding failures return a safe consent stage, not raw errors',async()=>{
 const error=new Error('do not leak test-secret-value');
 error.name='AuthorizationError';
 error.description='This authorization was not started in this browser; start again';
 const env=testEnv({approveConsent:async()=>{throw error;}});
 const response=await authRoute(postConsent(),env);
 assert.equal(response.status,400);
 const body=await response.text();
 assert.match(body,/consent-approval \(missing-consent-cookie\)/);
 assert.doesNotMatch(body,/test-secret-value|test-private-secret|test-handle/);
});
// Consent approval failures must remain distinct without reflecting OAuth cookie,
// handle, authorization state, or upstream error text to an unauthenticated page.
const consentFailures=[
 ['Missing transaction handle','missing-consent-handle'],
 ['This authorization was not started in this browser; start again','missing-consent-cookie'],
 ['This authorization belongs to a different browser session; start again','consent-cookie-mismatch'],
 ['This authorization expired or was already used; start again','consent-expired-or-used'],
 ['Approved scopes must be ones this server supports','unsupported-consent-scope'],
 ['Secret detail USER-SESSION-TOKEN-DO-NOT-REVEAL','oauth-request']
];
for(const [description,category] of consentFailures){
 test('consent approval classifies '+category+' without leaking details',async()=>{
  const error=new Error('PRIVATE-COOKIE-VALUE');
  error.name='AuthorizationError';
  error.description=description;
  const response=await authRoute(postConsent(),testEnv({approveConsent:async()=>{throw error;}}));
  assert.equal(response.status,400);
  assert.equal(await response.text(),'Authorization failed at consent-approval ('+category+'). Restart the connection from ChatGPT.');
  assert.equal(response.headers.get('Cache-Control'),'no-store');
  assert.ok(!response.headers.get('Set-Cookie'));
 });
}
test('consent GET forwards library browser-binding cookie unchanged',async()=>{
 const cookie='__Host-oauth-consent-abc=OPAQUE-CONSENT-COOKIE; Path=/; Secure; HttpOnly; SameSite=Lax; Max-Age=600';
 const env=testEnv({
  parseAuthRequest:async()=>({clientId:'chatgpt-verified',scope:['dsd:write']}),
  describeConsent:async()=>({clientName:'ChatGPT',clientDomain:'chatgpt.com',redirectHost:'chatgpt.com',redirectIsLoopback:false,scope:['dsd:write']}),
  beginConsent:async()=>({handle:'opaque-one-time-handle',headers:new Headers({'Set-Cookie':cookie,'Cache-Control':'no-store','Content-Security-Policy':"frame-ancestors 'none'",'X-Frame-Options':'DENY'})})
 });
 const response=await authRoute(new Request(origin+'/authorize?client_id=TEST&response_type=code'),env);
 assert.equal(response.status,200);
 assert.equal(response.headers.get('Set-Cookie'),cookie);
 assert.equal(response.headers.get('Cache-Control'),'no-store');
 assert.equal(response.headers.get('X-Frame-Options'),'DENY');
 assert.match(await response.text(),/name="handle" value="opaque-one-time-handle"/);
});
test('upstream errors are reported as a fixed safe stage',async()=>{
 const env=testEnv({beginUpstream:async()=>{throw new TypeError('test-private-secret-never-leak');}});
 const response=await authRoute(postConsent(),env);
 assert.equal(response.status,400);
 const body=await response.text();
 assert.match(body,/github-redirect \(server-error\)/);
 assert.doesNotMatch(body,/test-private-secret-never-leak/);
});
test('callback errors are reported safely without echoing query strings',async()=>{
 const env=testEnv({finishUpstream:async()=>{throw new Error('do-not-echo-code');}});
 const response=await authRoute(new Request(origin+'/callback?code=do-not-echo-code&state=test-state'),env);
 assert.equal(response.status,400);
 const body=await response.text();
 assert.match(body,/upstream-callback \(server-error\)/);
 assert.doesNotMatch(body,/do-not-echo-code|test-state/);
});
test('missing staging permission never proceeds to GitHub',async()=>{
 let upstreamCalled=false;
 const env=testEnv({
  approveConsent:async()=>({request:{scope:[]},headers:new Headers()}),
  beginUpstream:async()=>{upstreamCalled=true;throw new Error('must not call');}
 });
 const response=await authRoute(postConsent(),env);
 assert.equal(response.status,400);
 assert.equal(upstreamCalled,false);
 assert.match(await response.text(),/A staging permission was not granted/);
});

// Exact Cloudflare OAuth helper failures must remain distinguishable without
// leaking states, authorization codes or cookie contents to end users.
const upstreamFailures=[
 ['Missing state parameter','missing-state'],
 ['This authorization was not started in this browser; start again','missing-browser-cookie'],
 ['This authorization belongs to a different browser session; start again','cookie-mismatch'],
 ['This authorization expired or was already used; start again','expired-or-reused-state']
];
for(const [description,code] of upstreamFailures){
 test('upstream callback reports safe failure '+code,async()=>{
  const error=new Error('SECRET-from-upstream-not-for-users');
  error.name='AuthorizationError';
  error.description=description;
  const env=testEnv({finishUpstream:async()=>{throw error;}});
  const req=new Request(origin+'/callback?state=PRIVATE-STATE&code=PRIVATE-CODE');
  const response=await authRoute(req,env);
  assert.equal(response.status,400);
  const body=await response.text();
  assert.equal(body,'Authorization failed at upstream-callback ('+code+'). Restart the connection from ChatGPT.');
  assert.doesNotMatch(body,/SECRET|PRIVATE|cookie=/);
 });
}

test('GitHub redirect forwards both consent-clear and upstream binding cookies',async()=>{
 const env=testEnv({
  approveConsent:async()=>({
   request:{scope:['dsd:write']},
   headers:new Headers({'Set-Cookie':'__Host-oauth-consent-test=; Path=/; Secure; HttpOnly; SameSite=Lax; Max-Age=0'})
  }),
  beginUpstream:async(_request,{headers})=>{
   headers.append('Set-Cookie','__Host-oauth-upstream-test=opaque; Path=/; Secure; HttpOnly; SameSite=Lax; Max-Age=600');
   return {state:'upstream-test',headers};
  }
 });
 const response=await authRoute(postConsent(),env);
 assert.equal(response.status,302);
 const setCookies=response.headers.getSetCookie();
 assert.equal(setCookies.length,2);
 assert.ok(setCookies.some(x=>x.startsWith('__Host-oauth-consent-test=')));
 assert.ok(setCookies.some(x=>x.startsWith('__Host-oauth-upstream-test=')));
});

test('successful GitHub callback finishes OAuth with colon-free userId and preserves namespaced queue owner',async(t)=>{
 const githubAccountId=421337;
 const gitHubToken='TEST-GITHUB-TOKEN-NEVER-OUTPUT';
 const responseCookie='__Host-oauth-upstream-transaction=; Path=/; Secure; HttpOnly; SameSite=Lax; Max-Age=0';
 let completedOptions;
 const originalRequest={clientId:'test-client',redirectUri:'https://chatgpt.com/connect_platform_oauth_redirect',scope:['dsd:write']};
 const env=testEnv({
  finishUpstream:async()=>({request:originalRequest,headers:new Headers({'Set-Cookie':responseCookie})}),
  completeAuthorization:async(options)=>{
   // Cloudflare OAuth provider rejects userId values containing a colon.
   assert.ok(options.userId && !options.userId.includes(':'),'OAuth userId cannot contain a colon');
   assert.equal(options.userId,String(githubAccountId));
   assert.equal(options.props.subject,'github:'+githubAccountId);
   assert.equal(options.request,originalRequest);
   assert.deepEqual(options.scope,['dsd:write']);
   completedOptions=options;
   return {redirectTo:originalRequest.redirectUri+'?code=TEST-CODE&state=TEST-STATE'};
  }
 });
 let requests=0;
 t.mock.method(globalThis,'fetch',async(url,init)=>{
  requests++;
  if(String(url)==='https://github.com/login/oauth/access_token'){
   const sent=JSON.parse(init.body);
   assert.equal(sent.code,'TEST-GITHUB-CODE');
   assert.equal(sent.client_id,'test-public-client-id');
   assert.equal(sent.redirect_uri,origin+'/callback');
   return Response.json({access_token:gitHubToken});
  }
  if(String(url)==='https://api.github.com/user'){
   assert.equal(init.headers.Authorization,'Bearer '+gitHubToken);
   return Response.json({id:githubAccountId,login:'test-user'});
  }
  throw new Error('Unexpected network destination');
 });
 const response=await authRoute(new Request(origin+'/callback?state=TEST-UPSTREAM-STATE&code=TEST-GITHUB-CODE'),env);
 assert.equal(response.status,302);
 assert.equal(response.headers.get('Location'),originalRequest.redirectUri+'?code=TEST-CODE&state=TEST-STATE');
 assert.equal(response.headers.get('Set-Cookie'),responseCookie);
 assert.equal(requests,2);
 assert.ok(completedOptions);
 assert.ok(!response.headers.get('Location').includes(gitHubToken));
});


// A new ChatGPT connection must offer both separate staging permissions.
// Each scope remains optional at consent; the server must not silently promote
// a legacy invoice-only token to a planogram-write grant.
test('connection consent presents both separate import scopes clearly',async()=>{
 const scopes=['dsd:write','planogram:write'];
 const env=testEnv({
  parseAuthRequest:async()=>({clientId:'chatgpt-test',scope:scopes}),
  describeConsent:async()=>({clientName:'ChatGPT',clientDomain:'chatgpt.com',redirectHost:'chatgpt.com',redirectIsLoopback:false,scope:scopes}),
  beginConsent:async()=>({handle:'test-handle',headers:new Headers()})
 });
 const response=await authRoute(new Request(origin+'/authorize?client_id=chatgpt-test'),env);
 assert.equal(response.status,200);
 const body=await response.text();
 assert.match(body,/value="dsd:write" checked/);
 assert.match(body,/value="planogram:write" checked/);
 assert.match(body,/Stage supplier invoices for review/);
 assert.match(body,/Stage Ace planograms for review/);
});
test('consenting to both permissions retains exact scopes for OAuth',async()=>{
 const selected=['dsd:write','planogram:write'];
 let granted;
 const env=testEnv({approveConsent:async(_request,_handle,{scope})=>{
   granted=scope;
   return{request:{scope},headers:new Headers()};
 }});
 const response=await authRoute(new Request(origin+'/authorize',{
  method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},
  body:new URLSearchParams([['handle','test-handle'],['decision','approve'],...selected.map(scope=>['scope',scope])])
 }),env);
 assert.equal(response.status,302);
 assert.deepEqual(granted,selected);
 assert.equal(new URL(response.headers.get('Location')).host,'github.com');
});
test('legacy invoice-only consent remains valid without planogram authorization',async()=>{
 const response=await authRoute(postConsent(),testEnv());
 assert.equal(response.status,302);
});
test('initial MCP scope catalogue requests both separately enforced import rights',()=>{
 const index=new URL('../src/index.mjs',import.meta.url);
 const tools=new URL('../src/tools.mjs',import.meta.url);
 const source=fs.readFileSync(index,'utf8');
 const toolSource=fs.readFileSync(tools,'utf8');
 assert.match(source,/requiredScopes:\s*\['dsd:write','planogram:write'\]/);
 assert.match(source,/scopesSupported:\s*\['dsd:write','planogram:write','offline_access'\]/);
 assert.match(toolSource,/const planogramSecurity=\[\{type:'oauth2',scopes:\['planogram:write'\]\}\]/);
 assert.match(toolSource,/authorize\('planogram:write'\)/);
 assert.match(toolSource,/authorize\('dsd:write'\)/);
});

// Regression for the production screenshot: ChatGPT may initiate authorization
// with dsd:write only; our consent must still explicitly offer planogram:write.
test('DSD-only request offers BOTH staging permissions without granting either silently',async()=>{
 const requested=['dsd:write'];
 const env=testEnv({
  parseAuthRequest:async()=>({clientId:'chatgpt-test',scope:requested}),
  describeConsent:async()=>({clientName:'ChatGPT',clientDomain:'chatgpt.com',redirectHost:'chatgpt.com',redirectIsLoopback:false,scope:requested}),
  beginConsent:async()=>({handle:'test-handle',headers:new Headers({'Cache-Control':'no-store'})})
 });
 const res=await authRoute(new Request(origin+'/authorize?client_id=chatgpt-test'),env);
 assert.equal(res.status,200);
 const body=await res.text();
 assert.equal((body.match(/name="scope"/g)||[]).length,2);
 assert.match(body,/name="scope" value="dsd:write" checked/);
 assert.match(body,/name="scope" value="planogram:write" checked/);
 assert.match(body,/Stage supplier invoices for review/);
 assert.match(body,/Stage Ace planograms for review/);
 assert.match(body,/additional, optional permission/);
 assert.match(body,/width:min\(100%,620px\)/);
});
test('user can approve planogram alone; server receives exact selected permission',async()=>{
 let selected;
 const env=testEnv({approveConsent:async(_req,_handle,opts)=>{
  selected=opts.scope;
  return {request:{scope:opts.scope},headers:new Headers()};
 }});
 const res=await authRoute(new Request(origin+'/authorize',{
  method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},
  body:new URLSearchParams([['handle','test-handle'],['decision','approve'],['scope','planogram:write']])
 }),env);
 assert.equal(res.status,302);
 assert.deepEqual(selected,['planogram:write']);
});
test('user can deselect planogram; DSD-only grant remains DSD-only',async()=>{
 let selected;
 const env=testEnv({approveConsent:async(_req,_handle,opts)=>{
  selected=opts.scope;
  return {request:{scope:opts.scope},headers:new Headers()};
 }});
 const res=await authRoute(postConsent(),env);
 assert.equal(res.status,302);
 assert.deepEqual(selected,['dsd:write']);
});

// Matching prior production behavior: one requested staging permission also
// presents the other; a plain offline request does not silently grant writes.
test('planogram-only request offers both choices and preserves requested order',async()=>{
 const requested=['planogram:write'];
 const env=testEnv({
  parseAuthRequest:async()=>({clientId:'chatgpt-test',scope:requested}),
  describeConsent:async()=>({clientName:'ChatGPT',clientDomain:'chatgpt.com',redirectHost:'chatgpt.com',redirectIsLoopback:false,scope:requested}),
  beginConsent:async()=>({handle:'test-handle',headers:new Headers()})
 });
 const res=await authRoute(new Request(origin+'/authorize?client_id=chatgpt-test'),env);
 const body=await res.text();
 assert.equal(res.status,200);
 assert.equal((body.match(/name="scope"/g)||[]).length,2);
 assert.ok(body.indexOf('value="planogram:write"')<body.indexOf('value="dsd:write"'));
});
test('offline-only request never silently offers write permissions',async()=>{
 const requested=['offline_access'];
 const env=testEnv({
  parseAuthRequest:async()=>({clientId:'chatgpt-test',scope:requested}),
  describeConsent:async()=>({clientName:'ChatGPT',clientDomain:'chatgpt.com',redirectHost:'chatgpt.com',redirectIsLoopback:false,scope:requested}),
  beginConsent:async()=>({handle:'test-handle',headers:new Headers()})
 });
 const res=await authRoute(new Request(origin+'/authorize?client_id=chatgpt-test'),env);
 const body=await res.text();
 assert.equal(res.status,200);
 assert.match(body,/name="scope" value="offline_access" checked/);
 assert.doesNotMatch(body,/value="dsd:write"/);
 assert.doesNotMatch(body,/value="planogram:write"/);
});
