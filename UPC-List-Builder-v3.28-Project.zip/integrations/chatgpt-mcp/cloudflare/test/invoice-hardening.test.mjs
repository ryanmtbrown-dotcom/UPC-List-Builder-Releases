/** Contract tests for supplier invoice source, safe pricing and serial handling. */
import test from 'node:test';
import assert from 'node:assert/strict';
import {validateBatch} from '../src/validate.mjs';
import {pricingMode,normalizePricing,requireValidPricing} from '../src/pricing-policy.mjs';
import {receiveInvoiceSource} from '../src/invoice-source.mjs';
import {checkInvoiceContent} from '../src/invoice-content-policy.mjs';

const batch=()=>({invoice:{primaryVendor:'Manufacturer',invoiceNumber:'INV-2026',department:'46',
 defaultRetailMethod:'MARKUP',defaultMarkup:'35'},
 items:[{upc:'840290528934',description:'TEST REVOLVER 22LR',originalDescription:'22LR REVOLVER',
 mfg:'R-01',department:'46',caseCost:'691.89',orderMultiple:'1',retailMethod:'MARKUP',markup:'35'}]});

test('case-independent known pricing methods; invalid unknown method cannot become direct',()=>{
 assert.equal(pricingMode('markup'),'MARKUP');
 assert.equal(pricingMode('MarkUp'),'MARKUP');
 assert.equal(pricingMode('direct'),'DIRECT');
 assert.equal(pricingMode('markupp',{markup:'35%'}),'MARKUP');
 assert.throws(()=>pricingMode('markupp',{markup:'35'}),/Unrecognized retail method/);
 assert.throws(()=>pricingMode('dirrect',{retail:'35'}),/Unrecognized retail method/);
 assert.equal(pricingMode('dirrect',{retail:'$35'}),'DIRECT');
 assert.throws(()=>normalizePricing({defaultRetailMethod:'MARKUP',defaultMarkup:'$35'},[]),/Dollar sign conflicts/);
 assert.throws(()=>normalizePricing({defaultRetailMethod:'DIRECT',defaultMarkup:'35'},[]),/cannot carry/);
});

test('each printed serial becomes a unique DSD row, preserving UPC, cost and percentage',()=>{
 const x=batch();x.items[0].serialNumber='14M25L07082, 14M25L07086';x.items[0].orderedQuantity=2;
 x.items[0].eachCost='691.89';x.items[0].lineTotal='1383.78';
 const z=validateBatch(x);
 assert.equal(z.items.length,2);
 assert.deepEqual(z.items.map(a=>a.serialNumber),['14M25L07082','14M25L07086']);
 assert.deepEqual(z.items.map(a=>a.upc),['840290528934','840290528934']);
 assert.deepEqual(z.items.map(a=>a.caseCost),['691.89','691.89']);
 assert.ok(z.items.every(a=>a.orderMultiple==='1'&&a.retailMethod==='MARKUP'&&a.markup==='35'));
});

test('firearms can be recorded with no serial; quantity does not become order multiple',()=>{
 const x=batch();x.items[0].orderedQuantity=12;x.items[0].serialNumber='';
 x.items[0].eachCost='90.00';x.items[0].lineTotal='1080.00';x.items[0].caseCost='90.00';
 const z=validateBatch(x);assert.equal(z.items.length,1);assert.equal(z.items[0].serialNumber,'');
 assert.equal(z.items[0].orderMultiple,'1');assert.equal(z.items[0].caseCost,'90');
});

test('partial printed serials remain separate from one unnumbered remainder line',()=>{
 const x=batch();x.items[0].orderedQuantity=3;x.items[0].serialNumber='S1; S2';
 const z=validateBatch(x);assert.deepEqual(z.items.map(a=>a.serialNumber),['S1','S2','']);
 assert.ok(z.warnings.some(w=>w.includes('unnumbered')));
});

test('serials are never an automatic firearm classification; duplicate serials and quantity mismatch stop',()=>{
 const x=batch();x.invoice.department='72';x.items[0].department='72';
 x.items[0].description='SERIALIZED TOOL';x.items[0].originalDescription='SERIALIZED TOOL';
 x.items[0].serialNumber='TOOL-01';
 assert.equal(validateBatch(x).items[0].department,'72');
 x.items[0].serialNumber='A, B';x.items[0].orderedQuantity=1;
 assert.throws(()=>validateBatch(x),/more serial numbers/);
 x.items[0].orderedQuantity=2;x.items.push({...x.items[0],serialNumber:'A',orderedQuantity:1});
 assert.throws(()=>validateBatch(x),/repeats serial/);
 x.items=[{...x.items[0],originalDescription:'22LR REVOLVER',serialNumber:''}];
 assert.throws(()=>validateBatch(x),/describes a firearm/);
});

test('Cloudflare cannot approve an unknown method, unpriced markup or missing manual dollars',()=>{
 const x=batch(),z=validateBatch(x);
 requireValidPricing(z);
 z.invoice.defaultMarkup='';z.items[0].markup='';
 assert.throws(()=>requireValidPricing(z),/markup percentage/);
 z.invoice.defaultRetailMethod='DIRECT';z.items[0].retailMethod='DIRECT';z.items[0].retail='';
 assert.throws(()=>requireValidPricing(z),/dollar retail amount/);
 z.items[0].retail='9.99';z.items[0].markup='';
 requireValidPricing(z);
});

test('invoice source must be server-downloaded original PDF or image bytes, never a claimed hash',async()=>{
 const file={file_id:'file_invoice01234567890',file_name:'invoice.pdf',download_url:'https://files.oaiusercontent.com/source/opaque'};
 const bytes=new TextEncoder().encode('%PDF-1.7\n'+'X'.repeat(150));
 let calls=0;const download=async(url,opts)=>{calls++;assert.equal(opts.redirect,'manual');return new Response(bytes,{status:200,headers:{'content-type':'application/pdf'}})};
 const env={AI:{toMarkdown:async()=>({format:'markdown',data:'SUPPLIER INVOICE INV-2026 QTY 1 UPC 840290528934 MANUFACTURER R-01 $691.89'})}};
 const expectation={invoice:batch().invoice,items:batch().items};
 const good=await receiveInvoiceSource(file,env,download,expectation);
 assert.equal(good.format,'PDF');assert.equal(good.status,'document_received');
 assert.equal(good.invoiceContentVerified,true);assert.equal(good.sourceAuthenticityVerified,false);assert.ok(good.matchedProductIdentifiers>=1);
 assert.equal(good.sha256.length,64);assert.equal(calls,1);
 const apiStyle=await receiveInvoiceSource({...file,file_id:'file-abc1234567'}, env,download,expectation);
 assert.equal(apiStyle.sha256,good.sha256);
 await assert.rejects(receiveInvoiceSource({file_id:file.file_id,download_url:'https://127.0.0.1/document'}, env,download,expectation),/cannot be securely retrieved/);
 await assert.rejects(receiveInvoiceSource({file_id:file.file_id,download_url:'https://example.com/document'}, env,download,expectation),/cannot be securely retrieved/);
 await assert.rejects(receiveInvoiceSource({file_id:'file_fake',download_url:file.download_url}, env,download,expectation),/reference is missing or invalid/);
});

test('non-invoice files and mismatched invoice identities never waive research',async()=>{
 const input=batch(),env={AI:{toMarkdown:async()=>({format:'markdown',data:'NOTES FROM A TRAINING SLIDE WITH NO INVOICE FIELDS'})}};
 const f={file_id:'file_invoice987654321',download_url:'https://files.oaiusercontent.com/exact'};
 const bytes=new TextEncoder().encode('%PDF-1.7\\n'+'A'.repeat(150));
 const read=async()=>new Response(bytes,{status:200});
 await assert.rejects(receiveInvoiceSource(f,env,read,{invoice:input.invoice,items:input.items}),e=>e.code==='INVOICE_CONTENT_NOT_VERIFIED');
 env.AI.toMarkdown=async()=>({format:'markdown',data:'INVOICE WRONG-99877 QTY 1 840290528934'});
 await assert.rejects(receiveInvoiceSource(f,env,read,{invoice:input.invoice,items:input.items}),e=>e.code==='INVOICE_CONTENT_NOT_VERIFIED');
 env.AI.toMarkdown=async()=>({format:'markdown',data:'INVOICE INV-2026 QTY 1 PRODUCT XYZ-000000'});
 await assert.rejects(receiveInvoiceSource(f,env,read,{invoice:input.invoice,items:input.items}),e=>e.code==='INVOICE_CONTENT_NOT_VERIFIED');
 assert.throws(()=>checkInvoiceContent('INVOICE INV-2026 QTY 1 UNRELATED STOCK NUMBER 999999999 OTHER SUPPLIER REFERENCE ABCDEF',input.invoice,input.items),/No submitted UPC/);
});
