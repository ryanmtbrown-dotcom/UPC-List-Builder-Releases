/**
 * OWNERSHIP: In-memory MCP client handshake and tool discovery verification.
 * Does not call D1, invoke pairing, perform OAuth, or contact a network.
 */
import test from 'node:test';
import assert from 'node:assert/strict';
import { Client, InMemoryTransport } from '@modelcontextprotocol/client';
import { makeMcp } from '../src/tools.mjs';

test('MCP SDK client discovers review and app-only approval tools without calling any tool',async()=>{
 const server=makeMcp({DB:{prepare(){throw new Error('D1 calls are forbidden during tool discovery');}}},'github:42');
 const client=new Client({name:'dsd-test-client',version:'0.1.0'});
 const [clientTransport,serverTransport]=InMemoryTransport.createLinkedPair();
 try{
  await Promise.all([server.connect(serverTransport),client.connect(clientTransport)]);
  const listing=await client.listTools();
  const tools=listing.tools||[];
  assert.deepEqual(tools.map(tool=>tool.name).sort(),[
   'append_planogram_chunk',
   'begin_planogram_import',
   'create_dsd_pairing_code',
   'finalize_planogram_import',
   'get_dsd_import_status',
   'get_planogram_import_status',
   'record_dsd_review_rendered',
   'review_dsd_import',
   'submit_dsd_import',
   'submit_planogram_import',
  ]);
  for(const tool of tools)assert.ok(tool.inputSchema,'Missing input schema: '+tool.name);
  const reviewer=tools.find(tool=>tool.name==='review_dsd_import');
  assert.equal(reviewer._meta?.ui?.resourceUri,'ui://upc-list-builder/dsd-review-v3.html');
  const resources=await client.listResources();
  assert.ok(resources.resources?.some(x=>x.uri==='ui://upc-list-builder/dsd-review-v3.html'));
  const importer=tools.find(tool=>tool.name==='submit_dsd_import');
  assert.deepEqual(importer._meta.ui.visibility,['app']);
  assert.deepEqual(tools.find(x=>x.name==='record_dsd_review_rendered')._meta.ui.visibility,['app']);
  assert.match(client.getInstructions(),/review_dsd_import/);
  assert.deepEqual(reviewer._meta['openai/fileParams'],['invoiceFile']);
  const schema=JSON.stringify(reviewer.inputSchema);
  for(const key of ['invoiceFile','download_url','file_id','orderedQuantity','eachCost','lineTotal','orderMultiple','department','serialNumber'])
   assert.ok(schema.includes('"'+key+'"'),'Missing DSD field '+key);
  for(const phrase of ['default','one','display','serial number','ammunition','variant','invoiceFile','Cloudflare'])
   assert.ok(reviewer.description.toLowerCase().includes(phrase.toLowerCase()),
    'Missing importer contract: '+phrase);
 }finally{
  await Promise.allSettled([client.close(),server.close()]);
 }
});
