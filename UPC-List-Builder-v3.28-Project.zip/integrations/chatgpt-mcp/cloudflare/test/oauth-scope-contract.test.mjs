/**
 * Regression: ChatGPT's first OAuth authorization must request BOTH capabilities.
 * Keep this independent of the user's issued tokens and secrets.
 */
import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';

const entry=readFileSync(new URL('../src/index.mjs',import.meta.url),'utf8');
function scopesFor(key){
 const match=entry.match(new RegExp(key+'\\s*:\\s*\\[([^\\]]+)\\]'));
 assert.ok(match,'Missing '+key+' in OAuth configuration');
 return [...match[1].matchAll(/'([^']+)'/g)].map(x=>x[1]);
}
test('MCP scope metadata requests planogram and DSD at connection time',()=>{
 const needed=scopesFor('requiredScopes');
 assert.deepEqual(needed,['dsd:write','planogram:write']);
 const supported=scopesFor('scopesSupported');
 assert.ok(needed.every(scope=>supported.includes(scope)));
 assert.ok(!needed.includes('offline_access'));
});
