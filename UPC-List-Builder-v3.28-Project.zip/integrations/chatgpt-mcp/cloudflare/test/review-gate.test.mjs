/** Durable review approval enforcement and model-visible recovery; no network. */
import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync} from 'node:fs';
import {Client,InMemoryTransport} from '@modelcontextprotocol/client';
import {makeMcp} from '../src/tools.mjs';
import {createQueue} from '../src/queue.mjs';
import {createReviewStore} from '../src/review-store.mjs';
import {validateResearch} from '../src/review-policy.mjs';
import {workflowFailure} from '../src/workflow-errors.mjs';
export function harness(env={}){
 const sql=new DatabaseSync(':memory:');
 for(const file of ['0001_import_queue.sql','0002_review_gate.sql'])sql.exec(readFileSync(new URL('../migrations/'+file,import.meta.url),'utf8'));
 const db={prepare(query){let args=[];const op={bind(...v){args=v;return op},async run(){return{meta:{changes:sql.prepare(query).run(...args).changes}}},async first(){return sql.prepare(query).get(...args)||null},async all(){return{results:sql.prepare(query).all(...args)}}};return op},async batch(ops){return Promise.all(ops.map(x=>x.run()))}};
 const queue=createQueue(db);return {sql,db,queue,reviews:createReviewStore(db,queue,env)};
}
export function invoice(){return {invoice:{primaryVendor:'PRADCO',invoiceNumber:'114774552',department:'72',defaultRetailMethod:'MARKUP',defaultMarkup:65},items:[{upc:'657139063378',description:'SEX SHAD 4',mfg:'WESFS419',eachCost:7.10,orderedQuantity:12,lineTotal:85.20}],researchEvidence:[{itemIndexes:[0],query:'War Eagle WESFS419 Sexxy Shad 4 Sonar Flash Spoon',productName:'War Eagle fishing spoon 4 inch Sexxy Shad',status:'identified',sources:['https://example.com/products/sonar-spoon'],notes:'Exact model, size and color reported matched; test fixture only.',suggestedDepartment:'72'}]}}
const approval=r=>({reviewId:r.reviewId,approvalProof:r.approvalProof,decisions:{}});
const rejects=(promise,code)=>assert.rejects(promise,e=>e.code===code);
test('raw imports and claimed booleans cannot submit',async()=>{const h=harness();try{for(const input of [invoice(),{uiPresented:true,userApproved:true},{}])await rejects(h.reviews.submit('github:42',input),'REVIEW_REQUIRED');assert.equal((await h.queue.list('github:42')).length,0)}finally{h.sql.close()}});
test('research covers every row and requires sources or honest uncertainty',()=>{const e=invoice().researchEvidence;assert.throws(()=>validateResearch(undefined,1));assert.throws(()=>validateResearch(e,2));for(const sources of [[],['javascript:alert(1)'],['https://secret:password@example.com/x']])assert.throws(()=>validateResearch([{...e[0],sources}],1));assert.throws(()=>validateResearch([{...e[0],itemIndexes:[0,0]}],1));assert.throws(()=>validateResearch([{...e[0],status:'unavailable',notes:''}],1));assert.equal(validateResearch([{...e[0],status:'unavailable',sources:[]}],1)[0].provenance,'assistant_reported')});
test('UI callback, correct account and proof are required; expired reviews blocked',async()=>{const h=harness();try{const r=await h.reviews.create('github:42',invoice()),a=approval(r);await rejects(h.reviews.submit('github:42',a),'UI_REVIEW_REQUIRED');await rejects(h.reviews.rendered('github:43',a),'REVIEW_EXPIRED_OR_INVALID');await rejects(h.reviews.rendered('github:42',{...a,approvalProof:'fabricated'}),'REVIEW_EXPIRED_OR_INVALID');assert.notEqual(h.sql.prepare('SELECT proof_hash FROM dsd_reviews').get().proof_hash,r.approvalProof);await h.reviews.rendered('github:42',a);h.sql.prepare('UPDATE dsd_reviews SET expires=?').run(Date.now()-1);await rejects(h.reviews.submit('github:42',a),'REVIEW_EXPIRED_OR_INVALID');assert.equal((await h.queue.list('github:42')).length,0)}finally{h.sql.close()}});
test('ten concurrent exact approvals and replay create one batch; changed replay blocked',async()=>{const h=harness();try{const r=await h.reviews.create('github:42',invoice()),a=approval(r);await h.reviews.rendered('github:42',a);const receipts=await Promise.all(Array.from({length:10},()=>h.reviews.submit('github:42',a)));assert.equal(new Set(receipts.map(x=>x.id)).size,1);assert.equal((await h.queue.list('github:42')).length,1);assert.deepEqual(await h.reviews.submit('github:42',a),receipts[0]);await rejects(h.reviews.submit('github:42',{...a,decisions:{invoice:{defaultMarkup:70}}}),'REVIEW_ALREADY_USED');const b=await h.queue.get('github:42',receipts[0].id);assert.equal(Number(b.items[0].caseCost),7.10);assert.equal(b.items[0].orderMultiple,'1');assert.equal(b.invoice.defaultMarkup,'65');assert.equal(b.researchEvidence,undefined);const reopened=await h.reviews.rendered('github:42',a);assert.equal(reopened.approvalRecorded,true);assert.equal(reopened.receipt.id,receipts[0].id)}finally{h.sql.close()}});
test('replacement facts, bool flags and invalid choices cannot bypass review',async()=>{const h=harness();try{const r=await h.reviews.create('github:42',invoice()),a=approval(r);await h.reviews.rendered('github:42',a);for(const decisions of [{invoice:{invoiceNumber:'OTHER'}},{uiPresented:true},{itemDepartments:['72','46']}])await rejects(h.reviews.submit('github:42',{...a,decisions}),'REVIEW_CHANGED');await rejects(h.reviews.submit('github:42',{...a,uiPresented:true}),'REVIEW_CHANGED');await rejects(h.reviews.submit('github:42',{...a,decisions:{invoice:{department:'999'},missingDepartmentsAcknowledged:true}}),'DEPARTMENT_REVIEW_REQUIRED');await rejects(h.reviews.submit('github:42',{...a,decisions:{invoice:{defaultMarkup:'garbage'}}}),'MARKUP_REVIEW_REQUIRED');assert.equal((await h.queue.list('github:42')).length,0)}finally{h.sql.close()}});
test('unresolved research and blank departments need separate acknowledgment',async()=>{const h=harness();try{const x=invoice();x.invoice.department='';x.researchEvidence[0]={...x.researchEvidence[0],status:'unavailable',sources:[],suggestedDepartment:'',notes:'Test: research service unavailable; identity unconfirmed.'};const r=await h.reviews.create('github:42',x),a=approval(r);await h.reviews.rendered('github:42',a);await rejects(h.reviews.submit('github:42',a),'RESEARCH_REVIEW_REQUIRED');a.decisions.unresolvedResearchAcknowledged=true;await rejects(h.reviews.submit('github:42',a),'DEPARTMENT_REVIEW_REQUIRED');a.decisions.missingDepartmentsAcknowledged=true;assert.ok((await h.reviews.submit('github:42',a)).id)}finally{h.sql.close()}});
test('free display removal retains merchandise and its research suggestion',async()=>{const h=harness();try{const x=invoice();x.invoice.department='';x.items.unshift({description:'FREE COUNTER DISPLAY',caseCost:0});const r=await h.reviews.create('github:42',x);assert.equal(r.itemCount,1);assert.equal(r.items[0].upc,'657139063378');assert.equal(r.items[0].suggestedDepartment,'72');assert.ok(r.warnings.some(x=>x.includes('excluded')))}finally{h.sql.close()}});
test('receipt failure preserves choices and idempotent retries recover',async()=>{const h=harness();try{let fail=true;const db={...h.db,prepare(query){const op=h.db.prepare(query);if(query.includes("SET state='submitted'")){const run=op.run;op.run=async()=>{if(fail){fail=false;throw Error('private database diagnostic')}return run()}}return op}};const reviews=createReviewStore(db,h.queue),r=await reviews.create('github:42',invoice()),a=approval(r);await reviews.rendered('github:42',a);let err;try{await reviews.submit('github:42',a)}catch(e){err=e}assert.equal(err.code,'SUBMISSION_UNCONFIRMED');const msg=workflowFailure(err);assert.equal(msg.structuredContent.submitted,null);assert.equal(msg.structuredContent.retrySameRequest,true);assert.doesNotMatch(msg.content[0].text,/Nothing was submitted|private database/);await rejects(reviews.submit('github:42',{...a,decisions:{invoice:{defaultMarkup:70}}}),'REVIEW_ALREADY_USED');assert.ok((await reviews.submit('github:42',a)).id);assert.equal((await h.queue.list('github:42')).length,1)}finally{h.sql.close()}});
test('missing review migration fails closed',async()=>{const h=harness();try{h.sql.exec('DROP TABLE dsd_reviews');await rejects(h.reviews.create('github:42',invoice()),'REVIEW_STORAGE_UNAVAILABLE');assert.equal((await h.queue.list('github:42')).length,0)}finally{h.sql.close()}});
test('MCP exposes actionable errors and hides proof from model content',async()=>{const h=harness(),server=makeMcp({DB:h.db},'github:42'),client=new Client({name:'gate-test',version:'1'}),[c,s]=InMemoryTransport.createLinkedPair();try{await Promise.all([server.connect(s),client.connect(c)]);const raw=await client.callTool({name:'submit_dsd_import',arguments:{...invoice(),uiPresented:true}});assert.equal(raw.isError,true);assert.equal(raw.structuredContent.code,'REVIEW_REQUIRED');assert.ok(raw.structuredContent.missingSteps.includes('show_item_review'));assert.match(raw.content[0].text,/Next: review_dsd_import/);const missing=invoice();delete missing.researchEvidence;assert.equal((await client.callTool({name:'review_dsd_import',arguments:missing})).structuredContent.code,'RESEARCH_REQUIRED');const r=await client.callTool({name:'review_dsd_import',arguments:invoice()});assert.ok(r._meta.approvalProof);assert.equal(r.structuredContent.approvalProof,undefined);assert.ok(!JSON.stringify({content:r.content,structuredContent:r.structuredContent}).includes(r._meta.approvalProof));const a={reviewId:r.structuredContent.reviewId,approvalProof:r._meta.approvalProof};await client.callTool({name:'record_dsd_review_rendered',arguments:a});assert.ok((await client.callTool({name:'submit_dsd_import',arguments:a})).structuredContent.id)}finally{await Promise.allSettled([client.close(),server.close()]);h.sql.close()}});
test('generic errors do not leak internal messages',()=>{assert.doesNotMatch(workflowFailure(Error('secret-token')).content[0].text,/secret-token/)});

test('attached supplier source waives internet citations only after Cloudflare receives file bytes',async()=>{
 const h=harness({AI:{toMarkdown:async()=>({format:'markdown',data:'PRADCO INVOICE 114774552 QTY 12 657139063378 WESFS419 UNIT COST $7.10'})}}),oldFetch=globalThis.fetch;
 const pdf=new TextEncoder().encode('%PDF-1.7\\n'+'A'.repeat(150));
 globalThis.fetch=async()=>new Response(pdf,{status:200,headers:{'content-type':'application/pdf'}});
 try{
  const input=invoice();delete input.researchEvidence;
  input.invoiceFile={file_id:'file_actualSupplierInvoice1234',download_url:'https://files.oaiusercontent.com/secure/invoice',file_name:'source.pdf'};
  const r=await h.reviews.create('github:42',input);
  assert.equal(r.invoiceSource.status,'document_received');
  assert.equal(r.checklist.originalInvoiceBytesReceived,true);
  assert.equal(r.checklist.researchEvidenceRecorded,false);
  assert.equal(r.invoiceSource.invoiceContentVerified,true);
  assert.equal(r.invoiceSource.sourceAuthenticityVerified,false);
  assert.equal(JSON.stringify(r.batch).includes('download_url'),false);
  assert.equal(JSON.stringify(r.batch).includes('file_actualSupplierInvoice1234'),false);
  const a=approval(r);await h.reviews.rendered('github:42',a);
  const receipt=await h.reviews.submit('github:42',a);
  const pending=await h.queue.get('github:42',receipt.id);
  assert.equal(JSON.stringify(pending).includes('download_url'),false);
 }finally{globalThis.fetch=oldFetch;h.sql.close()}
});
test('new revision supersedes the older unapproved review; item pricing is server revalidated',async()=>{
 const h=harness();try{
  const old=await h.reviews.create('github:42',invoice()),a1=approval(old);
  const fresh=await h.reviews.create('github:42',invoice()),a2=approval(fresh);
  await rejects(h.reviews.rendered('github:42',a1),'REVIEW_SUPERSEDED');
  await h.reviews.rendered('github:42',a2);
  const corrupt={...a2,decisions:{itemPricing:[{retailMethod:'markupp',markup:'35',retail:''}]}};
  await rejects(h.reviews.submit('github:42',corrupt),'PRICING_VALIDATION_REQUIRED');
  const proper={...a2,decisions:{itemPricing:[{retailMethod:'DIRECT',markup:'',retail:'12.99'}]}};
  const done=await h.reviews.submit('github:42',proper);
  const staged=await h.queue.get('github:42',done.id);
  assert.equal(staged.items[0].retailMethod,'DIRECT');assert.equal(staged.items[0].retail,'12.99');
 }finally{h.sql.close()}
});
