import {readWebRuntimeSource} from './helpers/runtime-source-tree.mjs';
import fs from 'node:fs';
import vm from 'node:vm';
const must=(v,m)=>{if(!v)throw new Error(m)};
const dsd=fs.readFileSync('app/src/main/assets/www/ace-dsd.js','utf8');
const dsdWorkspace=fs.readFileSync('app/src/main/assets/www/dsd/dsd-workspace-controller.js','utf8');
const app=readWebRuntimeSource();
const gradle=fs.readFileSync('gradle.properties','utf8');
const html=fs.readFileSync('app/src/main/assets/www/index.html','utf8');
const expected=[
 ['46','Firearms'],['55','Cleaning Supplies'],['56','Paint and Paint Supplies'],['57','Hand Tools and Tool Accessories'],['58','Power Tools'],['59','Flashlights and Lighting Supplies'],['60','Electrical Supplies'],['61','Plumbing Supplies and Fixtures'],['62','Heating and Cooling Supplies'],['63','Hardware'],['64','Fasteners'],['67','Building Materials and Products'],['68','Appliances and Home Entertainment'],['69','Housewares and Gifts'],['70','Lawn Garden / Farm Supplies'],['71','Outdoor Equipment and Power Tools'],['72','Sporting Goods'],['73','Automotive'],['74','Outdoor Living and Furniture'],['75','Stationary Supplies / Office Equipment'],['77','Notions and Miscellaneous'],['170','Major Department - Ace']
];
for(const [n,name] of expected) must(dsd.includes(`['${n}','${name}']`),`missing Myers department ${n} ${name}`);
must(!dsd.includes("['72','Notions and Miscellaneous']"),'obsolete v2.34 department 72 mapping remains');
must(!dsd.includes("['76','Sporting Goods']"),'obsolete department 76 Sporting Goods remains');
must(!dsd.includes("['78','Automotive']"),'obsolete department 78 Automotive remains');
must(dsd.includes("deptName(x.department)"),'DSD validation must continue using shared registry');
must(dsdWorkspace.includes("ACEDSD.DEPARTMENTS.map"),'Help picker must continue rendering shared registry');
must(html.includes('id="dsdPrettyRetail"')&&html.includes('inputmode="decimal"'),'Pretty Retail must be an editable decimal input');
must(html.includes('id="dsdPreloadPrevious" type="checkbox"')&&html.includes('Preload previous item data for similar item'),'previous-item preload checkbox missing');
must(!html.includes('id="dsdSimilar"')&&!html.includes('id="dsdBlank"'),'old after-add choice buttons must be removed');
must(dsdWorkspace.includes("retail:method==='MARKUP'?$('dsdPrettyRetail').value:$('dsdRetail').value"),'markup mode must save editable Pretty Retail');
must(dsdWorkspace.includes("if(wasNew)startNext($('dsdPreloadPrevious').checked)"),'new item must immediately reset/preload according to checkbox');
must(dsd.includes("(clean(draft.retail)!==''?money(draft.retail):calc?.pretty)"),'saved markup retail must preserve user override through rebuild/export');
must(dsd.includes("retailFromMarkup(caseCost,order,draft.markup,department)"),'markup rebuild must route automatic pricing through authoritative item department');
must(dsdWorkspace.includes("on('dsdPrettyRetail','input',()=>syncRetailUi(true))"),'manual Retail edits must refresh information without replacing the typed retail');
must(dsdWorkspace.includes("ACEDSD.retailFromMarkup($('dsdCaseCost').value,$('dsdOrderMult').value,$('dsdMarkup').value,department)"),'workspace pricing must pass current item department to the domain');
must(html.includes('Suggested automatically from markup. You may override this retail.'),'markup Retail UI must explicitly preserve manual override');
must(html.includes('aria-describedby="dsdRawRetail"')&&html.includes('aria-live="polite"'),'markup information line must remain accessible and informational');
const ctx={};vm.createContext(ctx);vm.runInContext(dsd+';globalThis.__ACEDSD=ACEDSD;',ctx);const api=ctx.__ACEDSD;
const inv={primaryVendor:'banish',secondaryVendor:'north west',invoiceNumber:'inv-ab12',department:'72',defaultRetailMethod:'DIRECT',defaultMarkup:''};
// The DSD domain alone generates final SKUs; MISC and normal lookup are independent.
const exampleUpc='082901234567';
for(const department of ['46','72'])must(api.sku(department,exampleUpc)==='7234567',`DSD department ${department} must use 7 plus the final six UPC digits`);
must(api.sku('63',exampleUpc)==='6334567','DSD standard department must use its full number plus the final five UPC digits');
must(api.sku('170',exampleUpc)==='17034567','DSD three-digit department must retain its full number');
must(api.sku('46','000012340056')==='7340056','DSD UPC suffix must retain leading zeros');
must(api.sku('63','000012340056')==='6340056','DSD standard SKU must retain UPC suffix leading zeros');
must(api.sku('46','12345')===''&&api.sku('',exampleUpc)==='','DSD must retain missing/short identifier rejection');
const skuInvoice={...inv,department:'63'};
const skuDraft={upc:exampleUpc,description:'SKU TEST',orderMultiple:'1',caseCost:'10',retailMethod:'DIRECT',retail:'19.99'};
const inherited=api.buildItem(skuDraft,skuInvoice);
must(inherited.department==='63'&&inherited.sku==='6334567','DSD item must inherit the invoice department for SKU generation');
const specialOverride=api.buildItem({...skuDraft,department:'46'},skuInvoice);
must(specialOverride.sku==='7234567','DSD item-level 46 override must use special SKU policy');
const specialSporting=api.buildItem({...skuDraft,department:'72'},skuInvoice);
must(specialSporting.sku==='7234567','DSD item-level 72 override must use special SKU policy');
const exportedSpecial=api.row({...specialOverride,sku:'WRONG'},skuInvoice);
must(exportedSpecial[0]==='7234567'&&exportedSpecial[8]==='7234567'&&exportedSpecial[13]==='7234567','DSD export must regenerate every SKU column from the final item department');
const exportedStandard=api.row({...inherited,sku:'WRONG'},skuInvoice);
must(exportedStandard[0]==='6334567'&&exportedStandard[8]==='6334567'&&exportedStandard[13]==='6334567','DSD export must regenerate standard SKUs consistently');
must(api.withLegacyDepartment({upc:exampleUpc},skuInvoice).sku==='6334567','DSD legacy department inheritance must use the corrected formula');
must(api.isFirearmDepartment('46')&&!api.isFirearmDepartment('72'),'firearm state must derive from department 46 only');
for(const department of ['46','72']){
 for(const markup of [30,35,40,45,50,55,60,65,70,75,80,85,90,95,100]){
  const calc=api.retailFromMarkup('100','1',String(markup),department);
  must(calc&&Math.round(calc.pretty*100)%100===99,`department ${department} markup ${markup}% must end in .99`);
 }
}
for(const department of ['55','56','63','70','73','170']){
 for(const markup of [30,45,60,75,100]){
  const calc=api.retailFromMarkup('100','1',String(markup),department),ending=Math.round(calc.pretty*100)%100;
  must([39,49,59,69,79,89,99].includes(ending),`department ${department} markup ${markup}% returned illegal ending ${ending}`);
 }
}
const manualMarkup=api.buildItem({upc:'082901234500',department:'46',description:'manual retail',mfg:'x',orderMultiple:'1',caseCost:'100',retailMethod:'MARKUP',retail:'177.49',markup:'45'},inv);
must(manualMarkup.retail===177.49,'manual Retail override must remain authoritative even when automatic department pricing would suggest another value');
const auto46=api.buildItem({upc:'082901234501',department:'46',description:'auto firearm',mfg:'x',orderMultiple:'1',caseCost:'100',retailMethod:'MARKUP',retail:'',markup:'45'},inv);
must(Math.round(auto46.retail*100)%100===99,'blank markup Retail must fall back to department 46 .99 automatic pricing');
const auto63=api.buildItem({upc:'082901234502',department:'63',description:'auto hardware',mfg:'x',orderMultiple:'1',caseCost:'100',retailMethod:'MARKUP',retail:'',markup:'45'},inv);
must([39,49,59,69,79,89,99].includes(Math.round(auto63.retail*100)%100),'blank markup Retail outside 46/72 must use approved seven-ending automatic pricing');
must(Math.abs(api.actualMarkup('100','1','145.49')-45.49)<1e-9,'actual markup helper must describe the current Retail value rather than the requested markup');
for(const markup of [0,25,27.5,110,250]){
 const firearm=api.retailFromMarkup('4','4',String(markup),'46');
 const standard=api.retailFromMarkup('4','4',String(markup),'63');
 must(firearm&&Number.isFinite(firearm.pretty),`department 46 must accept arbitrary valid markup ${markup}%`);
 must(Math.round(firearm.pretty*100)%100===99,`department 46 arbitrary markup ${markup}% must retain .99 ending`);
 must(standard&&Number.isFinite(standard.pretty),`standard department must accept arbitrary valid markup ${markup}%`);
 must([39,49,59,69,79,89,99].includes(Math.round(standard.pretty*100)%100),`standard department arbitrary markup ${markup}% must retain approved ending`);
}
must(api.retailFromMarkup('4','4','-1','63')===null,'negative markup must remain invalid');
must(api.retailFromMarkup('4','4','not-a-number','63')===null,'non-numeric markup must remain invalid');
const twentyFive=api.retailFromMarkup('4','4','25','63');
must(Math.abs(twentyFive.raw-1.25)<1e-9,'25% markup on $4 case cost / 4 units must produce a $1.25 mathematical target');
must(api.departmentForFirearmState(true)==='46'&&api.departmentForFirearmState(false)==='72','Firearm toggle must map on to 46 and off to 72');
const firearmDefault=api.buildItem({upc:'082901234568',description:'test firearm',mfg:'x',orderMultiple:'1',caseCost:'100',retailMethod:'DIRECT',retail:'199.99'},{...inv,department:'46'});
must(firearmDefault.department==='46'&&firearmDefault.sku===api.sku('46',firearmDefault.upc),'invoice department 46 must create new items as department 46');
const manualFirearm=api.buildItem({upc:'082901234569',department:'46',description:'manual firearm',mfg:'y',orderMultiple:'1',caseCost:'100',retailMethod:'DIRECT',retail:'199.99'},{...inv,department:'63'});
must(manualFirearm.department==='46'&&manualFirearm.sku===api.sku('46',manualFirearm.upc),'manual item department 46 must control firearm SKU regardless of invoice default');
must(!Object.prototype.hasOwnProperty.call(manualFirearm,'firearm'),'department must remain the only persisted firearm classification truth');

const item=api.buildItem({upc:'082901234567',description:'Suppressor cover Black',mfg:'mfg-aB9',orderMultiple:'1',caseCost:'12',retailMethod:'DIRECT',retail:'19.99',markup:''},inv);
must(item.description==='SUPPRESSOR COVER BLACK','DSD description must uppercase when item is built/saved');
must(item.mfg==='MFG-AB9','DSD manufacturer number must uppercase when item is built/saved');
must(item.vendor==='WWD 663','generated DSD vendor must uppercase');
const row=api.row({...item,description:'legacy mixed Case',mfg:'old-xYz'},inv);
must(row[3]==='LEGACY MIXED CASE'&&row[7]==='WWD 663'&&row[14]==='OLD-XYZ','DSD export row must independently uppercase textual fields');
must(dsdWorkspace.includes("primaryVendor:ACEDSD.upper($('dsdPrimaryVendor').value)")&&dsdWorkspace.includes("invoiceNumber:ACEDSD.invoiceNumbers($('dsdInvoice').value)"),'DSD invoice text must uppercase and normalize spacing before persistence');
must(dsd.includes("safeInvoice=invoiceNumbers(list.dsdInvoice.invoiceNumber)"),'DSD export filename invoice numbers must be normalized again while preserving spaces');
must(html.includes('id="dsdItemDepartment"'),'DSD item-level department control missing');
must(html.includes('id="dsdFirearmToggle"')&&html.includes('aria-pressed="false"'),'DSD firearm toggle control missing');
must(dsd.includes("FIREARM_DEPARTMENT='46'")&&dsd.includes("NON_FIREARM_DEPARTMENT='72'"),'firearm toggle departments must be defined by the DSD domain');
must(dsdWorkspace.includes("ACEDSD.isFirearmDepartment($('dsdItemDepartment').value)")&&dsdWorkspace.includes("on('dsdFirearmToggle','click',toggleFirearm)"),'DSD firearm control must be driven by the current item department');
must(dsdWorkspace.includes("select.value=ACEDSD.departmentForFirearmState(!active)"),'Firearm toggle must update the authoritative item department');
must(!dsdWorkspace.includes('firearmToggleEligible')&&!dsd.includes('firearmToggleEligible'),'firearm visibility must not introduce persisted eligibility provenance');

must(html.includes('id="dsdSerialNumber"')&&html.includes('Serial Number'),'optional DSD serial-number control missing');
must(html.includes('id="dsdImportButton"')&&html.includes('id="dsdImportFile"'),'existing DSD workbook import controls missing');
must(dsdWorkspace.includes("department:$('dsdItemDepartment').value"),'DSD item draft must persist item-level department');
must(dsdWorkspace.includes("Default Dept ${inv.department||'needed'}"),'invoice summary must label invoice department as a default rather than implying row-wide authority');
must(dsdWorkspace.includes("serialNumber:$('dsdSerialNumber').value"),'DSD item draft must persist optional serial number');
must(dsdWorkspace.includes("ACEDSD.withLegacyDepartment(x,previousInvoice)"),'legacy DSD items must be frozen to their prior department before invoice-default edits');
must(dsdWorkspace.includes("fillDraft({...prev,serialNumber:''})"),'previous-item preload must never copy a serial number');
must(dsdWorkspace.includes("ACEDSD.importWorkbook(file"),'DSD workbook import must use the dedicated DSD import owner');
const override=api.buildItem({upc:'082901234567',department:'72',description:'shooting gloves',mfg:'g-1',serialNumber:'sn-ab12',orderMultiple:'1',caseCost:'10',retailMethod:'DIRECT',retail:'19.99',markup:''},{...inv,department:'46'});
must(override.department==='72','item department override must supersede invoice default');
must(override.sku===api.sku('72',override.upc),'item SKU must use the item department');
must(override.serialNumber==='SN-AB12','serial number must persist as normalized optional item data');
must(api.validateInvoice({...inv,primaryVendor:'3M'}).some(x=>x.includes('Manufacturer names cannot contain numbers')),'manufacturer names containing digits must be rejected');
must(api.validateInvoice({...inv,invoiceNumber:'INVABC'}).some(x=>x.includes('Each invoice number must contain at least one number')),'invoice identifiers without a digit must be rejected');
must(api.validateInvoice({...inv,invoiceNumber:'INV1 B2 300'}).length===0,'multiple invoice identifiers containing digits must be accepted');
const overrideRow=api.row(override,{...inv,department:'46'});must(overrideRow[2]==='72'&&overrideRow[17]==='SN-AB12','export row must use item department and Serial# column');
const frozen=api.withLegacyDepartment({upc:'082901111111',description:'legacy'}, {...inv,department:'46'});must(frozen.department==='46'&&frozen.sku===api.sku('46',frozen.upc),'legacy item department freeze must use the prior invoice department');
must(api.filenameParts('ACE New DSD Items RSR GROUP 4022834166.xlsx').manufacturerText==='RSR GROUP','manufacturer text must be recovered before the first digit-bearing invoice token');
must(api.invoiceNumberFromFilename('ACE New DSD Items RSR GROUP 4022834166.xlsx')==='4022834166','invoice number must be recoverable from the correct DSD filename');
must(api.invoiceNumbers('  inv-1   inv-2  inv-3 ')==='INV-1 INV-2 INV-3','multiple invoice numbers must normalize to one ordered single-space string');
must(api.invoiceNumberFromFilename('ACE_New_DSD_Items_RSR_GROUP_INV-1_INV-2_INV-3.xlsx')==='INV-1 INV-2 INV-3','legacy underscore-separated DSD filenames must remain import-compatible');
must(api.invoiceNumberFromFilename('ACE New DSD Items RSR GROUP INV-1 INV-2 INV-3.xlsx')==='INV-1 INV-2 INV-3','new manufacturer-plus-invoice filename must round-trip invoice identifiers');
must(api.filenameParts('ACE New DSD Items RSR GROUP INV-1 INV-2 INV-3.xlsx').manufacturerText==='RSR GROUP','new filename must preserve manufacturer text before invoice identifiers');
must(dsdWorkspace.includes("invoiceNumber:ACEDSD.invoiceNumbers($('dsdInvoice').value)"),'invoice form must persist normalized multiple invoice numbers in the DSD workspace owner');
must(html.includes('Invoice Number(s)')&&html.includes('separated by spaces'),'DSD invoice UI must explain multiple invoice numbers');
must(html.includes('<strong>Manufacturer *</strong>')&&html.includes('<strong>Second Manufacturer</strong>'),'DSD invoice UI must expose manufacturer and optional second manufacturer');
must(dsd.includes("Manufacturer names cannot contain numbers."),'manufacturer digit validation missing');
must(dsd.includes("Each invoice number must contain at least one number."),'invoice token digit validation missing');
must(dsd.includes("name=`ACE New DSD Items ${manufacturer} ${safeInvoice}`"),'DSD export filename must use spaces with manufacturer(s) before invoice number(s)');
const importHeaders=[...api.HEADERS];
ctx.XLSXImporter={importFile:async()=>({needsUPCMapping:false,headers:importHeaders,records:[{fields:{'2 UPC':'082901999999','3 Dept':'72','(4) (10) Description':'shooting gloves','(5) (300) Order Mult':'1','6 CASE COST':'12.00','9 RETAIL/MSRP':'19.99','13 VENDOR':'RSR GROUP 663','299 MFG#':'RG-9','Serial#':'abc-123'}}]}),continueWithMapping:async()=>{throw new Error('unexpected mapping continuation')}};
const imported=await api.importWorkbook({name:'ACE New DSD Items RSR GROUP 00000.xlsx'},()=>{});
must(imported.invoice.invoiceNumber==='00000'&&imported.invoice.department==='72','DSD import must restore editable invoice identity/default department');
must(imported.invoice.primaryVendor==='RSR GROUP'&&imported.invoice.secondaryVendor==='','DSD import must preserve generated vendor text without duplicating suffix 663');
must(imported.items.length===1&&imported.items[0].department==='72'&&imported.items[0].serialNumber==='ABC-123','DSD import must restore editable item department and serial number');
must(imported.items[0].retailMethod==='DIRECT','import must not invent an unrecoverable historical markup method');
ctx.XLSXImporter.importFile=async()=>({needsUPCMapping:false,headers:importHeaders,records:[
 {fields:{'2 UPC':'082901999991','3 Dept':'46','(4) (10) Description':'firearm','(5) (300) Order Mult':'1','6 CASE COST':'100','9 RETAIL/MSRP':'199.99','13 VENDOR':'RSR GROUP 663','299 MFG#':'GUN-1','Serial#':'SER-1'}},
 {fields:{'2 UPC':'082901999992','3 Dept':'72','(4) (10) Description':'shooting gloves','(5) (300) Order Mult':'1','6 CASE COST':'20','9 RETAIL/MSRP':'39.99','13 VENDOR':'RSR GROUP 663','299 MFG#':'GLV-1','Serial#':''}}
]});
const mixedImported=await api.importWorkbook({name:'ACE New DSD Items RSR GROUP 00001.xlsx'},()=>{});
must(mixedImported.needsInvoiceReview&&mixedImported.warnings.some(x=>x.includes('default department cannot be recovered')),'mixed-department import must require invoice-default review instead of silently claiming the original default');
console.log('ACE New DSD department authority + per-item department + serial + editable workbook import: PASS');
