import {readWebRuntimeSource} from './helpers/runtime-source-tree.mjs';
import fs from 'node:fs';
const app=readWebRuntimeSource(),broker=fs.readFileSync('app/src/main/assets/www/acenet-client.js','utf8'),misc=fs.readFileSync('app/src/main/assets/www/ace-misc.js','utf8'),workspace=fs.readFileSync('app/src/main/assets/www/misc/misc-workspace-controller.js','utf8'),verification=fs.readFileSync('app/src/main/assets/www/misc/misc-verification-service.js','utf8'),resolution=fs.readFileSync('app/src/main/assets/www/misc/misc-resolution-service.js','utf8'),dsd=fs.readFileSync('app/src/main/assets/www/ace-dsd.js','utf8'),html=fs.readFileSync('app/src/main/assets/www/index.html','utf8');
const must=(v,m)=>{if(!v)throw new Error(m)};
const rowsStart=misc.indexOf('async function rowsForList(list){'),rowsEnd=misc.indexOf('\n async function build(list){',rowsStart),rowsSource=misc.slice(rowsStart,rowsEnd);
must(html.includes('id="aceMiscSearchUpcs"')&&html.includes('Verify UPCs with AceNet'),'MISC verification action missing');
must(workspace.includes("current?.sessionType!=='ACE_NEW_ITEMS_MISC'"),'action must be MISC-only');
must(workspace.includes('verificationService.retryPendingAceMiscVerification')&&verification.includes("resolveProvider('ACE_MISC_VERIFY_EXISTING')")&&resolution.includes("requestAceNetCatalog(key,{misc:true})"),'MISC verification must retry through full exact-SKU catalog retrieval');
must(verification.includes('confirmAceMiscKnownUpcs')&&verification.includes('NEEDS_USER_CONFIRMATION'),'AceNet NOT_FOUND must require explicit user UPC confirmation');
must(misc.includes("VERIFIED_COMPLETE")&&misc.includes("VERIFIED_NO_ACENET_UPC_DATA")&&misc.includes("USER_CONFIRMED_COMPLETE"),'MISC must expose explicit exportable UPC completeness states');
must(misc.includes('cannot be exported')&&misc.includes('complete UPC verification'),'MISC export must block incomplete UPC sets');
must(broker.includes('BROKER_TIMEOUT_FALLBACK_MS=52000')&&broker.includes('productionBrokerTimeout'),'MISC broker ownership must follow the shared production incident policy');
must(misc.includes("if(itemIndex<uniqueItems.length-1)rows.push(Array(HEADERS.length).fill(''))"),'MISC export must retain blank SKU separators');
must(misc.includes('missing its canonical ACE MISC draft'),'MISC export must reject items missing canonical draft state rather than silently reconstructing it');
must(!rowsSource.includes('UPCEffectiveCatalogResolver')&&!rowsSource.includes('UPCIdentifierRelationshipService'),'MISC export must not rebuild canonical draft state from catalog/identity repositories');
must(!/promotedMaster|MASTER_PROMOTED_LOCAL|LOCAL_LIBRARY_PROMOTED/.test(misc),'retired promoted-Master compatibility must not remain in MISC export runtime');
must(!html.includes('id="dsdSearchUpcs"'),'DSD must not contain additional UPC action');
must(!dsd.includes('mergeAdditionalUpcs')&&!dsd.includes('groupedExportRows'),'incorrect DSD enrichment must be absent');
console.log('ACE New Items MISC UPC enrichment + snapshot compatibility v2.57 PASS');

 // MISC explicit recheck and Level 2 regression: exercise the real domain
 // modules against the photographed two-UPC SKU and observed no-selector path.
import assert from 'node:assert/strict';
import vm from 'node:vm';
const root='app/src/main/assets/www/';
const read=path=>fs.readFileSync(root+path,'utf8');
const normSku=x=>String(x??'').replace(/\D/g,'');
const normUpc=x=>String(x??'').replace(/\D/g,'');
const money=x=>x===null||x===undefined||String(x).trim()===''?null:Number(String(x).replace(/[,$]/g,''));
let nextId=0;
const ctx={
 window:null,console,
 UPCIdentifierNormalization:{normalizeSKU:normSku,normalizeUPC:normUpc},
 UPCStandardExportSchema:{ACE_MISC_HEADERS:Array.from({length:33},(_,i)=>'Column '+i)},
 UPCCatalogMappers:{normalizeAceNetWeight:x=>String(x||'')},
 XLSXExporter:{MIME:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',build:(heads,rows)=>({heads,rows})}
};
ctx.window=ctx;vm.createContext(ctx);
for(const path of ['pricing/price-authority.js','ace-misc.js','misc/misc-draft-model.js','misc/misc-verification-service.js'])vm.runInContext(read(path),ctx,{filename:path});
const domain=vm.runInContext('ACEMisc',ctx);
const model=ctx.UPCMiscDraftModel.create({normalizeSku:normSku,normalizeUpc:normUpc,parseMoney:money,newId:()=>String(++nextId),verificationStates:domain.UPC_VERIFICATION,now:()=>new Date('2026-10-14T23:00:00Z').toISOString()});
function library(sku,upc,price='20.99'){
 return{skuKey:sku,upcKey:upc,originalUPC:upc,fields:{
  'ACE SKU':sku,'UPC/EAN':upc,'Description':'TURPENTINE 1Q','MFG #':'QGT694',
  'Order Multiple':'1','Retail Units':'1','Weight':'1.2','Retailer Each Cost':'12.00',
  'Ace Retail Price':'19.99','Level 2 Retail Price':price,
  'Commodity Group':'14','Merchandise Class Number':'143','Product Group Number':'5'
 }};
}
function liveCatalog(sku,upcs,price){
 return{sku,allUpcs:upcs,manufacturerNumber:'QGT694',orderMultiple:'1',omWeight:'1.2',retailerEachCost:'12.00',
 aceRetailPrice:'19.99',level2RetailPrice:price,commodityGroup:'14',merchandiseClassNumber:'143',productGroupNumber:'5'};
}
const sku='1433085',first='030192069158',second='030192150696',record=library(sku,first);
const oldSnapshot=domain.snapshotFromMasterRecord(record,sku,[first]);
const oldItem=model.decorateItem(model.bulkItemFromResolved({sku,upc:first,description:'TURPENTINE 1Q',price:'20.99',fields:record.fields},oldSnapshot),{...oldSnapshot,upcVerification:domain.UPC_VERIFICATION.VERIFIED_COMPLETE},domain.UPC_VERIFICATION.VERIFIED_COMPLETE,'VERIFIED');
oldItem.labelPrice=21.99;oldItem.tags=['Needs Review'];
const verifiedCatalog=liveCatalog(sku,[first,second],'25.99');
const verifiedSnapshot=domain.snapshotFromLibraryAndAceNet(record,sku,verifiedCatalog);
assert.deepEqual(Array.from(verifiedSnapshot.orderedUpcs),[first,second],'complete selector must preserve both UPCs in order');
assert.equal(verifiedSnapshot.baseRow[16],'19.99','Ace Retail remains its own column');
assert.equal(verifiedSnapshot.baseRow[18],'25.99','live Store/Level 2 must overwrite stale Library Level 2 in MISC export');
const newItem=model.decorateItem(model.bulkItemFromResolved({sku,upc:first,description:'TURPENTINE 1Q',price:'20.99',fields:record.fields},verifiedSnapshot),verifiedSnapshot,domain.UPC_VERIFICATION.VERIFIED_COMPLETE,'VERIFIED',verifiedCatalog.level2RetailPrice);
assert.equal(ctx.UPCPriceAuthority.observedAceNetPrice(newItem),25.99,'fresh MISC Level 2 price must have verified provenance');
assert.equal(ctx.UPCPriceAuthority.observedAceNetPrice(model.decorateItem({...newItem,aceNetPrice:null,aceNetPriceAuthority:null},verifiedSnapshot,domain.UPC_VERIFICATION.VERIFIED_COMPLETE,'VERIFIED',null)),null,'missing Level 2 must not invent verified price');
const fallbackSku='9098974',fallbackUpc='816018022442',fallbackRecord=library(fallbackSku,fallbackUpc,'31.99'),fallbackCatalog=liveCatalog(fallbackSku,[],'31.99');
const fallbackSnapshot=domain.snapshotFromLibraryAndAceNet(fallbackRecord,fallbackSku,fallbackCatalog,{fallbackUpcs:[fallbackUpc],upcVerification:domain.UPC_VERIFICATION.VERIFIED_NO_ACENET_UPC_DATA});
const fallbackNew=model.decorateItem(model.bulkItemFromResolved({sku:fallbackSku,upc:fallbackUpc,price:'31.99',fields:fallbackRecord.fields},fallbackSnapshot),fallbackSnapshot,domain.UPC_VERIFICATION.VERIFIED_NO_ACENET_UPC_DATA,'VERIFIED_NO_UPC_DATA','31.99');
const fallbackOld=model.decorateItem(model.bulkItemFromResolved({sku:fallbackSku,upc:fallbackUpc,price:'31.99',fields:fallbackRecord.fields},fallbackSnapshot),fallbackSnapshot,domain.UPC_VERIFICATION.VERIFIED_NO_ACENET_UPC_DATA,'VERIFIED_NO_UPC_DATA');
const errorSku='9107882',errorUpc='816018022169',errorRecord=library(errorSku,errorUpc),errorSnapshot=domain.snapshotFromMasterRecord(errorRecord,errorSku,[errorUpc]);
const errorItem=model.decorateItem(model.bulkItemFromResolved({sku:errorSku,upc:errorUpc,fields:errorRecord.fields},errorSnapshot),{...errorSnapshot,upcVerification:domain.UPC_VERIFICATION.VERIFIED_COMPLETE},domain.UPC_VERIFICATION.VERIFIED_COMPLETE,'VERIFIED');
const list={id:'misc-test',sessionType:'ACE_NEW_ITEMS_MISC',items:[oldItem,fallbackOld,errorItem]};
const requested=[],saved=[];
const verify=ctx.UPCMiscVerificationService.create({
 draftModel:model,miscDomain:domain,normalizeSku:normSku,normalizeUpc:normUpc,
 resolveProvider:()=>async key=>{requested.push(key);if(key===sku)return{status:'FOUND',item:newItem};if(key===fallbackSku)return{status:'FOUND',item:fallbackNew};throw new Error('AceNet unavailable')},
 promptUser:async()=>null,messageUser:async()=>{},workSessionService:{save:async x=>saved.push(x.id)},
 getCurrentSession:()=>list,setCurrentSession:()=>{},diagnostic:()=>{}
});
const outcome=await verify.retryPendingAceMiscVerification(list,{includeComplete:true});
assert.deepEqual(requested,[sku,fallbackSku,errorSku],'explicit verification must actually request already-COMPLETE SKUs');
assert.equal(outcome.checked,3);assert.equal(outcome.full,1);assert.equal(outcome.fallback,1);assert.equal(outcome.failed,1);
assert.equal(outcome.changed,2,'new UPC and newly retrieved Level 2 price must count as changes');
assert.deepEqual(Array.from(oldItem.aceMiscSnapshot.orderedUpcs),[first,second]);
assert.equal(oldItem.aceNetPriceAuthority,'LEVEL2_STORE_RETAIL');
assert.equal(ctx.UPCPriceAuthority.observedAceNetPrice(oldItem),25.99);
assert.deepEqual(Array.from(oldItem.tags),['Needs Review'],'user tags survive verified refresh');
assert.equal(oldItem.labelPrice,21.99,'user label survives verified refresh');
assert.equal(fallbackOld.aceMiscUpcVerification,domain.UPC_VERIFICATION.VERIFIED_NO_ACENET_UPC_DATA,'no selector data must remain an explicitly labeled Library fallback');
assert.equal(errorItem.aceMiscUpcVerification,domain.UPC_VERIFICATION.PENDING_ACENET,'unsuccessful recheck must not be presented as current COMPLETE');
assert.deepEqual(Array.from(errorItem.aceMiscSnapshot.orderedUpcs),[errorUpc],'failed refresh must not destroy existing UPC draft');
await assert.rejects(()=>domain.rowsForList(list),/cannot be exported/);
list.items=[oldItem,fallbackOld];
const rows=await domain.rowsForList(list);
assert.equal(rows.length,4,'two UPC rows, blank separator, and one fallback row');
assert.equal(rows[0][21],first);assert.equal(rows[1][21],second);assert.equal(rows[0][18],'25.99');
assert.equal(rows[3][21],fallbackUpc);assert.equal(rows[3][18],'31.99');
const requestsBefore=requested.length;const pendingOnly=await verify.retryPendingAceMiscVerification(list);
assert.equal(pendingOnly.checked,0,'export-time retry must remain pending-only');
assert.equal(requested.length,requestsBefore);
assert.ok(read('misc/misc-workspace-controller.js').includes('includeComplete:true'),'MISC button must trigger full recheck');
assert.ok(read('work-sessions/list-item-controller.js').includes('Library UPC fallback; AceNet selector unavailable'),'saved-list evidence must disclose fallback status');
console.log('MISC explicit recheck and Level 2 regression PASS');
