import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
const read=path=>fs.readFileSync(path,'utf8');
const adapter=read('app/src/main/assets/www/dsd/dsd-chatgpt-import.js');
const workspace=read('app/src/main/assets/www/dsd/dsd-workspace-controller.js');
const lists=read('app/src/main/assets/www/work-sessions/work-session-controller.js');
const domain=read('app/src/main/assets/www/ace-dsd.js');
const html=read('app/src/main/assets/www/index.html');
const shell=read('app/src/main/assets/www/application/application-shell.js');
const styles=read('app/src/main/assets/www/styles.v059.css');
const vault=read('app/src/main/java/com/rmtb/upclistbuilder/ChatGPTConnectionVault.kt');
const native=read('app/src/main/java/com/rmtb/upclistbuilder/MainActivity.kt');
const backend=read('integrations/chatgpt-mcp/server.mjs');
const store=read('integrations/chatgpt-mcp/store.mjs');
const cloud=read('integrations/chatgpt-mcp/cloudflare/src/index.mjs');
const queue=read('integrations/chatgpt-mcp/cloudflare/src/queue.mjs');
const context={window:{},URL,Intl,Date,setTimeout,clearTimeout,AbortController};
vm.createContext(context);
vm.runInContext([adapter,domain,workspace,lists].join('\n')+
 ';globalThis.testDsdDomain=ACEDSD;',context);
const url=context.window.UPCDsdChatGPTImport.normalizeUrl;
assert.equal(url('https://mcp.example.com/'),'https://mcp.example.com');
for(const invalid of ['http://mcp.example.com','https://user:pass@mcp.example.com','https://mcp.example.com/path','https://mcp.example.com?token=x']){
 assert.throws(()=>url(invalid),/HTTPS/);
}
for(const id of ['dsdChatGPTEnabled','dsdChatGPTUrl','dsdChatGPTCode','dsdChatGPTPair',
 'dsdChatGPTDisconnect','dsdChatGPTCheck','dsdChatGPTBatch','dsdChatGPTLoad',
 'dsdChatGPTReject','dsdChatGPTStatus']){
 assert.ok(html.includes('id="'+id+'"'),id+' missing');
}
assert.ok(!html.includes('id="dsdChatGPTPreview"'),'Duplicate review UI remains');
assert.ok(!html.includes('id="dsdChatGPTCommit"'),'Duplicate confirmation step remains');
assert.ok(html.includes('Import into DSD')&&html.includes('Reject Pending'),'Pending actions missing');
assert.ok(shell.includes('UPCDsdChatGPTImport.create')&&shell.includes('confirmUser:appConfirm'));
assert.ok(shell.includes('dsdChatGPTImportController.bind({on})'));
assert.ok(adapter.includes("method:'DELETE'")&&cloud.includes('queue.reject(owner,match[1])'));
assert.ok(queue.includes("DELETE FROM dsd_batches WHERE id=? AND owner=? AND state='pending'"));
assert.ok(!adapter.includes('UPCDB.')&&!adapter.includes('UPCAceNetClient')&&!adapter.includes('MasterLibrary'));
assert.ok(adapter.indexOf('await acceptImported(')<adapter.indexOf("+'/ack'"),'Receipt must follow Work Session persistence');
assert.ok(adapter.includes('previous.some(x=>x.dsdImportBatchId===id)'),'Replayed batch must not create duplicate local list');
assert.ok(adapter.includes('transient={url,token:data.token}'),'Browser credentials must remain memory only');
assert.ok(!adapter.split('\n').some(line=>line.includes('storage.setItem(')&&/(?:token|code)/.test(line)),'A device token or pairing code must never be written to localStorage');
assert.ok(vault.includes('AndroidKeyStore')&&vault.includes('AES/GCM/NoPadding'));
assert.ok(native.includes('chatGPTConnectionVault = ChatGPTConnectionVault(this)'));
assert.ok(native.includes('if (!request.isForMainFrame) return true'));
assert.ok(html.includes('frame-src &#39;none&#39;'));
assert.ok(backend.includes('audience:publicUrl.href')&&backend.includes('algorithms:'));
assert.ok(store.includes('UNIQUE(owner, digest)')&&store.includes('WHERE id=? AND owner=?'));
assert.ok(styles.includes('.savedListDsd .savedListCopy strong'));
const api=context.testDsdDomain;
assert.equal(api.listName({primaryVendor:'PRADCO',secondaryVendor:'WWD',invoiceNumber:'114774552'}),
 'ACE New DSD Items · WWD PRADCO · 114774552');
assert.equal(api.listName({primaryVendor:'PRADCO',invoiceNumber:'114774552'}),
 'ACE New DSD Items · PRADCO · 114774552');
assert.equal(api.validateItem(api.buildItem({upc:'012345678901',description:'Item',department:'72',orderMultiple:2,caseCost:10,retail:8.99,retailMethod:'DIRECT'},
 {primaryVendor:'ACME',invoiceNumber:'INV-1',department:'72'})).length,0);
function makeElement(){
 const css=new Set();
 return{value:'',textContent:'',innerHTML:'',checked:false,
  classList:{add:x=>css.add(x),remove:x=>css.delete(x),toggle:(x,flag)=>flag?css.add(x):css.delete(x),contains:x=>css.has(x)},
  focus(){},setAttribute(){}};
}
const elements=new Map(),el=id=>{if(!elements.has(id))elements.set(id,makeElement());return elements.get(id);};
let current=null,saved=0;
const created=context.window.UPCDsdWorkspaceController.create({
 domain:api,elementById:el,queryAll:()=>[],escapeHtml:String,
 getSession:()=>current,setSession:x=>(current=x),saveSession:async()=>{saved++},
 newId:()=>String(Math.random()),sessionName:()=> 'DATE-TIME-FALLBACK',
 showScreen:()=>{},refreshSavedLists:async()=>{},fileDelivery:{deliverBytes(){}},
 diagnostic:()=>{}
});
const incomplete=await created.acceptImported({
 dsdImportBatchId:'4d7d986a-3b49-4aef-a3f3-b93bdadbdc99',
 invoice:{primaryVendor:'PRADCO',secondaryVendor:'WWD',invoiceNumber:'114774552',
  department:'',defaultRetailMethod:'MARKUP',defaultMarkup:'65'},
 items:[{upc:'657139063378',description:'WAR SNR',mfg:'WESFS419',
  orderMultiple:'1',caseCost:'7.10',retailMethod:'MARKUP',markup:'65',retail:''}]
});
assert.equal(current.id,incomplete);
assert.equal(saved,1);
assert.equal(current.dsdInvoice.secondaryVendor,'WWD');
assert.equal(current.dsdInvoice.invoiceNumber,'114774552');
assert.equal(current.name,'ACE New DSD Items · WWD PRADCO · 114774552');
assert.equal(current.items.length,1);
assert.equal(current.items[0].department,'');
assert.equal(current.items[0].retail,'','Unknown department must not generate department-specific retail');
assert.match(el('dsdRows').innerHTML,/Retail needed/);
await assert.rejects(api.exportList(current),/Choose a valid Myers Department/);
current.dsdInvoice.department='72';current.items[0].department='72';
await assert.rejects(api.exportList({...current,items:[{...current.items[0],caseCost:''}]}),/needs Case Cost/);
const calculated=api.retailFromMarkup('7.10','1','65','72');
assert.ok(calculated?.pretty>0);
await created.acceptImported({
 invoice:{primaryVendor:'PRADCO',invoiceNumber:'114774553',department:'72',defaultRetailMethod:'MARKUP',defaultMarkup:'65'},
 items:[{upc:'657139063378',description:'WAR SNR',orderMultiple:'1',caseCost:'7.10',markup:'65',retailMethod:'MARKUP',retail:''}]
});
assert.equal(current.items[0].retail,String(calculated.pretty));
assert.equal(current.items[0].orderMultiple,'1');
// v2.99 pricing-handoff regression: preserve verified markup semantics in the premium v3.00 UI.
assert.equal(api.retailFromMarkup('7.10','1','','72'),null,'Blank markup must not silently price at 0%.');
assert.equal(api.retailFromMarkup('7.10','1','65',''),null,'No department means no department-specific retail.');
assert.ok(api.retailFromMarkup('7.10','1','0','72')?.pretty>0,'Explicit 0% markup is valid.');
const incompleteCost=api.buildItem({upc:'012345678908',department:'72',description:'UNPRICED',orderMultiple:'',caseCost:'',retailMethod:'MARKUP',markup:'',retail:''},
 {primaryVendor:'ACME',invoiceNumber:'INV457',department:'72'});
assert.equal(incompleteCost.caseCost,null,'Blank case cost must not become a zero-valued purchase.');
assert.equal(incompleteCost.orderMultiple,null,'Blank order multiple must remain missing.');
assert.equal(incompleteCost.markup,null,'Blank markup must remain missing rather than 0%.');
assert.equal(incompleteCost.retail??null,null,'Blank retail must remain missing, not a zero price.');
const priced=api.fillMissingMarkupRetail({retailMethod:'MARKUP',department:'72',caseCost:'7.10',orderMultiple:'1',markup:'65',retail:''},
 {department:'72'});
assert.equal(priced.retail,String(calculated.pretty),'Complete markup draft must fill missing retail.');
assert.equal(api.fillMissingMarkupRetail({...priced,retail:'19.99'},{department:'72'}).retail,'19.99','Manual retail override must survive calculation.');
assert.equal(api.fillMissingMarkupRetail({...priced,department:'',retail:''},{department:''}).retail,'','Unknown department must not be priced.');
assert.ok(workspace.includes('ACEDSD.fillMissingMarkupRetail(ACEDSD.withLegacyDepartment(x,previousInvoice),inv)'),
 'Editing invoice defaults must complete otherwise-unpriced markup rows after department selection.');
await created.acceptImported({
 invoice:{primaryVendor:'ACME',invoiceNumber:'INV457',department:'72',defaultMarkup:'65'},
 items:[
  {upc:'012345678904',description:'INFER ITEM MARKUP',orderMultiple:'1',caseCost:'7.10',markup:'65',retail:''},
  {upc:'012345678905',description:'EXPLICIT DIRECT',orderMultiple:'1',caseCost:'7.10',retailMethod:'DIRECT',markup:'',retail:'12.34'},
  {upc:'012345678906',description:'INHERIT DEFAULT',orderMultiple:'1',caseCost:'7.10',retail:''}
 ]
});
assert.equal(current.dsdInvoice.defaultRetailMethod,'MARKUP','Markup-only invoice must infer default markup mode.');
assert.deepEqual(Array.from(current.items,x=>x.retailMethod),['MARKUP','DIRECT','MARKUP'],
 'Explicit item method wins; absent method inherits item markup or invoice default.');
assert.equal(current.items[0].retail,String(calculated.pretty));
assert.equal(current.items[1].retail,'12.34','Explicit direct retail must not be recalculated.');
assert.equal(current.items[2].retail,String(calculated.pretty),'Default invoice markup must price otherwise-complete imported item.');

const listElements=new Map(),li=id=>{if(!listElements.has(id))listElements.set(id,makeElement());return listElements.get(id)};
const savedRows=[
 {id:'dsd-1',sessionType:'ACE_NEW_DSD_ITEMS',name:'Old DSD time label',
  dsdInvoice:{primaryVendor:'PRADCO',secondaryVendor:'WWD',invoiceNumber:'114774552'},
  items:[{upc:'657139063378'}],createdAt:'2026-10-08T20:00:00Z'},
 {id:'field-2',sessionType:'FIELD_SESSION',name:'Normal field list',items:[],
  createdAt:'2026-10-08T20:00:00Z'}
];
const savedController=context.window.UPCWorkSessionController.create({
 elementById:li,service:{list:async()=>savedRows},fieldTags:[],newId:()=>'',sessionName:()=>'',escapeHtml:String,
 dsdListName:api.listName,
 diagnostic:()=>{},startOperation:()=>{},finishOperation:()=>{},showScreen:()=>{},goBack:()=>{},
 confirmUser:async()=>false,alertUser:()=>{}
});
await savedController.openLists();
const markup=li('savedLists').innerHTML;
assert.match(markup,/savedListDsd/);
assert.match(markup,/WWD PRADCO/);
assert.match(markup,/114774552/);
assert.ok(!/savedListDsd[\\s\\S]*?Creation time unavailable/.test(markup));
assert.match(markup,/savedListCreated/,'Normal list dates should remain visible');

// A DSD invoice may specify a default department and override only selected items.
await created.acceptImported({
 invoice:{primaryVendor:'ACME',invoiceNumber:'INV456',department:'72',defaultRetailMethod:'DIRECT'},
 items:[
  {upc:'012345678901',description:'SPORTS ITEM',orderMultiple:1,caseCost:10,retail:17},
  {upc:'012345678902',description:'SERIALIZED ITEM',serialNumber:'SN123',department:'46',orderMultiple:1,caseCost:90,retail:149},
  {upc:'012345678903',description:'OTHER ITEM',department:'69',orderMultiple:1,caseCost:14,retail:24}
 ]
});
assert.equal(current.dsdInvoice.department,'72');
assert.deepEqual(Array.from(current.items,item=>item.department),['72','46','69']);
assert.deepEqual(Array.from(current.items,item=>api.row(item,current.dsdInvoice)[2]),['72','46','69']);
// Revocation is impossible unless the user explicitly confirms; cancelling leaves token intact.
const css=read('app/src/main/assets/www/dsd/dsd.css');
assert.match(css,/\.dsdChatGPTHero/);
assert.match(css,/\.dsdChatGPTGlyph/);
assert.match(css,/\.dsdChatGPTDisconnect/);
assert.ok(!css.includes('background:rgba(12,18,29,.34)'),'Obsolete solid gray importer panel remains');
assert.match(html,/id="dsdChatGPTEnabled"[^>]+role="switch"/);
assert.match(html,/id="dsdChatGPTPanel" class="dsdChatGPTPanel"/);
let deviceConnected=true,requests=0,confirmations=0,permit=false;
const appEvents=new Map();
const secureBridge={
 getChatGPTConnection:()=>deviceConnected?JSON.stringify({url:'https://mcp.example.com',token:'test'}):'',
 deleteChatGPTConnection:()=>{deviceConnected=false;return true}
};
const connectionController=context.window.UPCDsdChatGPTImport.create({
 domain:api,elementById:el,escapeHtml:String,
 nativeBridgeProvider:()=>secureBridge,
 acceptImported:async()=>{},listSessions:async()=>[],
 storage:{getItem:()=> 'true',setItem(){}},
 fetchFn:async()=>{requests++;return {ok:true,json:async()=>({})}},
 confirmUser:async()=>{confirmations++;return permit},
 diagnostic:()=>{}
});
connectionController.bind({on:(id,event,handler)=>appEvents.set(id+':'+event,handler)});
const disconnectClick=appEvents.get('dsdChatGPTDisconnect:click');
assert.equal(typeof disconnectClick,'function');
disconnectClick();
await new Promise(resolve=>setTimeout(resolve,0));
assert.equal(confirmations,1,'Disconnect must request confirmation');
assert.equal(requests,0,'Cancellation must make no revoke request');
assert.equal(deviceConnected,true,'Cancellation must retain the device token');
permit=true;
disconnectClick();
await new Promise(resolve=>setTimeout(resolve,0));
assert.equal(confirmations,2);
assert.equal(requests,1,'Confirmation must issue exactly one revoke request');
assert.equal(deviceConnected,false,'Confirmed disconnect must clear the device token');

console.log('ChatGPT DSD single-editor, premium UI, optional departments, confirmed disconnect and queue contracts PASS');
