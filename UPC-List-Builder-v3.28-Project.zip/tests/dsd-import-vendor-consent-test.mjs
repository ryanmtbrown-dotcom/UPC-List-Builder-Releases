/** OWNERSHIP: Standalone DSD vendor import consent and invoice-edit regression (no external dependencies). */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';

const html=fs.readFileSync('app/src/main/assets/www/index.html','utf8');
for(const id of ['dsdVendorImportDialog','dsdVendorUseDefault','dsdVendorKeep','dsdVendorCancel','dsdVendorEdit','dsdInvoiceVendor','dsdImportReviewSummary'])assert.ok(html.includes('id="'+id+'"'),id+' missing from DSD UI');
const doc={activeElement:null};
const elements=new Map();
const $=id=>{if(!elements.has(id)){
 const names=new Set(['hidden']);
 const el={value:'',textContent:'',innerHTML:'',checked:false,files:[],classList:{
  add:v=>names.add(v),remove:v=>names.delete(v),contains:v=>names.has(v),toggle:(v,force)=>{const active=force===undefined?!names.has(v):Boolean(force);active?names.add(v):names.delete(v);return active}},
  focus(){doc.activeElement=this},setAttribute(){},addEventListener(){},removeEventListener(){},
  querySelector(){return {focus(){doc.activeElement=this}}},querySelectorAll(){return[]}
 };
 elements.set(id,el);
 }return elements.get(id)};
const ctx={window:{},document:doc,XLSXImporter:{importFile:async()=>({needsUPCMapping:false,headers:['2 UPC','3 Dept','(4) (10) Description','(5) (300) Order Mult','6 CASE COST','9 RETAIL/MSRP','13 VENDOR','299 MFG#','Serial#'],records:[{fields:{
 '2 UPC':'647484132683','3 Dept':'72','(4) (10) Description':"MEN'S RANA PVC LUG CHEST WADER SIZE 13",'(5) (300) Order Mult':'1','6 CASE COST':'25','9 RETAIL/MSRP':'59.99','13 VENDOR':'GUNTERSVILLE BREATHABLES WWD 663','299 MFG#':'MPN-12345678901234567890','Serial#':''}}]})}};
vm.createContext(ctx);
vm.runInContext(fs.readFileSync('app/src/main/assets/www/ace-dsd.js','utf8')+';globalThis.domain=ACEDSD;',ctx);
vm.runInContext(fs.readFileSync('app/src/main/assets/www/dsd/dsd-workspace-controller.js','utf8'),ctx);
let current=null,saves=0;
const controller=ctx.window.UPCDsdWorkspaceController.create({domain:ctx.domain,elementById:$,queryAll:()=>[],escapeHtml:String,
 getSession:()=>current,setSession:v=>{current=v},saveSession:async()=>{saves++},newId:()=>String(saves+1),sessionName:()=>'',showScreen:()=>{},refreshSavedLists:async()=>{},fileDelivery:{deliverBytes(){}},diagnostic:()=>{}});
const handlers=new Map();controller.bind({on:(id,type,callback)=>handlers.set(id,callback),startScanner:()=>{}});
const fakeFile={name:'ACE New DSD Items GUNTERSVILLE BREATHABLES WWD INV-1580200.xlsx',size:6532};
$('dsdImportFile').files=[fakeFile];
controller.startNew();
const importing=handlers.get('dsdImportFile')();
for(let i=0;i<10;i++)await Promise.resolve();
assert.equal(saves,0,'must wait for vendor consent before persisting');
assert.equal($('dsdVendorImportDialog').classList.contains('hidden'),false,'vendor dialog visible');
assert.equal($('dsdVendorImported').textContent,'GUNTERSVILLE BREATHABLES WWD 663');
$('dsdVendorUseDefault').onclick();await importing;
assert.equal(saves,1);assert.equal(current.dsdInvoice.vendor,'WWD 663');
assert.equal(current.items[0].mfg,'MPN-12345678901234567890');
assert.equal(current.items[0].retail,59.99);
assert.equal(current.items[0].sourceDescription,"MEN'S RANA PVC LUG CHEST WADER SIZE 13");
assert.ok(current.items[0].description.length<=24);
assert.ok(current.dsdImportNotices?.some(x=>x.includes('shortened')));

controller.startNew();const priorSaves=saves;
$('dsdImportFile').files=[fakeFile];const canceled=handlers.get('dsdImportFile')();
for(let i=0;i<10;i++)await Promise.resolve();
$('dsdVendorCancel').onclick();await canceled;
assert.equal(saves,priorSaves,'canceled import must not persist');assert.equal(current,null);

controller.startNew();$('dsdPrimaryVendor').value='GUNTERSVILLE BREATHABLES';$('dsdSecondaryVendor').value='WWD';
$('dsdInvoiceVendor').value='CUSTOM VENDOR 77';$('dsdInvoice').value='INV-1580200';$('dsdDepartment').value='72';
await handlers.get('dsdSetupNext')();
assert.equal(current.dsdInvoice.vendor,'CUSTOM VENDOR 77');
controller.showSetup(true);
assert.equal($('dsdInvoiceVendor').value,'CUSTOM VENDOR 77');
assert.ok(current.name.includes('WWD')&&!current.name.includes('CUSTOM VENDOR 77'));
console.log('DSD vendor import consent, descriptions, invoice override PASS');
