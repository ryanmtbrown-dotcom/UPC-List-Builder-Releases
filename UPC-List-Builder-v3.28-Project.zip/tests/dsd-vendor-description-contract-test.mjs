/** OWNERSHIP: Contract test for DSD vendor/description identity and XLSX field semantics. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
const ctx={};vm.createContext(ctx);
vm.runInContext(fs.readFileSync('app/src/main/assets/www/ace-dsd.js','utf8')+';globalThis.domain=ACEDSD',ctx);
const api=ctx.domain;
const invoice={primaryVendor:'GUNTERSVILLE BREATHABLES',secondaryVendor:'WWD',vendor:'WWD 663',invoiceNumber:'INV-1580200',department:'72',defaultRetailMethod:'DIRECT',defaultMarkup:''};
assert.equal(api.MAX_DESCRIPTION,24);
assert.equal(api.vendor(invoice),'WWD 663');
assert.equal(api.vendor({primaryVendor:'ACME',secondaryVendor:'WWD'}),'WWD 663');
assert.equal(api.vendor({...invoice,vendor:'CUSTOM 442'}),'CUSTOM 442');
assert.equal(api.shortDescription('Great Stuff Pro Tool CLN'),'GREAT STUFF PRO TOOL CLN');
assert.equal(api.shortDescription('Great Stuff Pro Tool Foam Cleaner'),'GREAT STUFF PRO TOOL');
assert.ok(api.shortDescription('ABCDEFGHIJKLMNOPQRSTUVWXYZZ').length<=24);
assert.ok(api.shortDescription('PVC TUBE 5/8 X 3/4 100 L').length<=24);

const original="MEN'S VAPOR RAIN SUIT BLUE/GRAY XL/2X";
const draft={upc:'647484191062',department:'72',description:original,mfg:'1VP111-618-XL/2X',orderMultiple:'1',caseCost:'20',retailMethod:'DIRECT',retail:'43.99'};
const item=api.buildItem(draft,invoice);
assert.ok(item.description.length<=24);
assert.equal(item.sourceDescription,original);
assert.equal(item.mfg,draft.mfg);
assert.equal(item.retail,43.99);
assert.equal(item.vendor,'WWD 663');
const row=api.row({...item,description:original},invoice);
assert.ok(row[3].length<=24);
assert.equal(row[14],draft.mfg);
assert.equal(row[6],43.99);
assert.equal(row[7],'WWD 663');
assert.equal(api.row(item,{...invoice,vendor:'DIFFERENT 171'})[7],'DIFFERENT 171');
let built;
ctx.XLSXExporter={MIME:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',build:async(headers,rows)=>{built={headers,rows};return Uint8Array.from([80,75])}};
const exported=await api.exportList({dsdInvoice:invoice,items:[item]});
assert.equal(exported.name,'ACE New DSD Items GUNTERSVILLE BREATHABLES WWD INV-1580200.xlsx');
assert.equal(built.rows[0][7],'WWD 663');
assert.equal(built.rows[0][14],draft.mfg);
assert.equal(built.rows[0][6],43.99);
assert.ok(built.rows[0][3].length<=24);

ctx.XLSXImporter={importFile:async()=>({needsUPCMapping:false,headers:api.HEADERS,records:[{fields:{
 '2 UPC':'647484132683','3 Dept':'72','(4) (10) Description':"MEN'S RANA PVC LUG CHEST WADER SIZE 13",
 '(5) (300) Order Mult':'1','6 CASE COST':'25','9 RETAIL/MSRP':'59.99','13 VENDOR':'GUNTERSVILLE BREATHABLES WWD 663','299 MFG#':'2RN011-304-130','Serial#':''
}}]})};
const imported=await api.importWorkbook({name:'ACE New DSD Items GUNTERSVILLE BREATHABLES WWD INV-1580200.xlsx'});
assert.equal(imported.invoice.vendor,'GUNTERSVILLE BREATHABLES WWD 663');
assert.equal(imported.importedVendors[0],'GUNTERSVILLE BREATHABLES WWD 663');
assert.ok(imported.items[0].description.length<=24);
assert.equal(imported.items[0].sourceDescription,"MEN'S RANA PVC LUG CHEST WADER SIZE 13");
assert.equal(imported.items[0].mfg,'2RN011-304-130');
assert.equal(imported.items[0].retail,59.99);
assert.equal(imported.needsInvoiceReview,false,'complete invoice should show descriptive warnings without forcing invoice setup');
assert.ok(imported.warnings.some(x=>x.includes('shortened')));
assert.ok(imported.warnings.some(x=>x.includes('imported vendor')));
console.log('DSD field/vendor/description contract PASS');
