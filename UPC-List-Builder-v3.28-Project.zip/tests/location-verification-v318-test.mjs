/** Shared display verification: synthetic Ace, guided audit, visual review, stale revisions and draft projection. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
const root='app/src/main/assets/www/store-locations/';
const context=vm.createContext({});
vm.runInContext(fs.readFileSync(root+'location-explorer-policy.js','utf8'),context);
vm.runInContext(fs.readFileSync(root+'location-work-policy.js','utf8'),context);
vm.runInContext(fs.readFileSync(root+'location-verification-service.js','utf8'),context);
const policy=vm.runInContext('UPCLocationExplorerPolicy',context);
const work=vm.runInContext('UPCLocationWorkPolicy',context);
const Service=vm.runInContext('UPCLocationVerificationService',context);
const persisted=new Map();
const copy=x=>JSON.parse(JSON.stringify(x));
const db={get:async(store,key)=>copy(persisted.get(store+':'+key)||null),put:async(store,obj)=>{persisted.set(store+':'+obj.key,copy(obj));return obj}};
const modular={id:'tape',name:'Tape',active:true,areaId:'aisle-8',physicalSectionIds:['1','2']};
const source={id:'source-tape',current:true,modularId:'tape',name:'Ace Tape',digest:'src-001'};
const members=[
 {sourceId:source.id,skuKey:'123',positions:[{sourceSegment:'SOURCE-1',sourceRow:1,sourceColumn:1}]},
 {sourceId:source.id,skuKey:'234',positions:[{sourceSegment:'SOURCE-1',sourceRow:1,sourceColumn:2}]}
];
let placements=[];
const repo={getModular:async id=>id==='tape'?copy(modular):null,
 listModulars:async()=>[copy(modular)],
 listPlacements:async()=>copy(placements),listSourcesForModular:async()=>[copy(source)],
 listSourceMembers:async()=>copy(members),
 sourceSignature:r=>JSON.stringify(r.filter(x=>x.current).map(x=>x.id+':'+x.digest).sort()),
 approvePhysicalLayout:async({items,expectedFingerprint,expectedSourceSignature})=>{
  if(work.fingerprint(placements)!==expectedFingerprint||repo.sourceSignature([source])!==expectedSourceSignature)throw Error('stale acceptance');
  placements=copy(items);return{accepted:true};
 }};
const service=Service.create({db,repository:repo,explorerPolicy:policy,workPolicy:work});
const initial=await service.evidence('tape');
assert.equal(initial.sourceSnapshot.length,2);
assert.equal(initial.storeSnapshot.length,0);
const visual=await service.record({modularId:'tape',method:'VISUAL_ACE_MATCH',
 expectedSourceSignature:initial.sourceSignature,expectedLayoutFingerprint:initial.layoutFingerprint,complete:true});
assert.equal(visual.method,'VISUAL_ACE_MATCH');
assert.equal(visual.sourceSnapshot.length,2);
assert.equal(visual.storeSnapshot.length,2,'Visual match compares Ace with Ace without creating physical placements');
assert.equal(placements.length,0,'Visual confirmation does not assert that each item was physically scanned');
persisted.set('meta:storeLocationWorkV1',{key:'storeLocationWorkV1',workspace:{modularId:'tape',mode:'AUDIT',observations:[{skuKey:'123'}]}});
persisted.set('meta:locationExplorerAudits.v1',{key:'locationExplorerAudits.v1',audits:{tape:{modularId:'tape',edits:2,viewed:['123','234']}}});
const dashboard=await service.summary();
assert.equal(dashboard[0].guided.recorded,1);
assert.equal(dashboard[0].visual.edits,2);
assert.equal(dashboard[0].latest.method,'VISUAL_ACE_MATCH');
assert.equal((await service.list()).length,1);
placements=[{id:'actual:1',modularId:'tape',skuKey:'123',physicalEvidence:true,physicalSectionId:'1',rowOrdinal:1,observedOrder:1,origin:'USER_SCAN',fixtureType:'PEG'}];
const physical=await service.evidence('tape');
await assert.rejects(service.record({modularId:'tape',method:'GUIDED_PHYSICAL_AUDIT',
 expectedSourceSignature:initial.sourceSignature,expectedLayoutFingerprint:initial.layoutFingerprint,complete:true}),/changed before verification/);
const guided=await service.record({modularId:'tape',method:'GUIDED_PHYSICAL_AUDIT',
 expectedSourceSignature:physical.sourceSignature,expectedLayoutFingerprint:physical.layoutFingerprint,
 sections:['1','2'],complete:true,observedCount:2,changedCount:1});
assert.equal(guided.storeSnapshot.length,1);
assert.equal((await service.latest('tape')).method,'GUIDED_PHYSICAL_AUDIT');
assert.equal((await service.list()).length,2,'Visual and guided history share one display');
assert.equal(placements.length,1,'Verification does not mutate approved physical placements');
assert.equal(members.length,2,'Verification never rewrites Ace source memberships');
assert.equal((await db.get('meta','storeLocationWorkV1')).workspace.mode,'AUDIT','Existing guided draft untouched');
assert.equal((await db.get('meta','locationExplorerAudits.v1')).audits.tape.edits,2,'Existing visual draft untouched');
vm.runInContext(fs.readFileSync(root+'location-work-service.js','utf8'),context);
const Guided=vm.runInContext('UPCLocationWorkService',context);
const guidedService=Guided.create({repository:repo,db,idFactory:()=>String(Date.now())});
let working=await guidedService.start({modularId:'tape',mode:'AUDIT',sections:['1'],fixtureType:'PEG'});
await assert.rejects(guidedService.confirmNoChanges(working),/Mark every selected section/);
working=await guidedService.record(working,{skuKey:'123',origin:'USER_SCAN'});
working=await guidedService.markSectionComplete(working,'1',true);
const unchanged=copy(placements);
const done=await guidedService.confirmNoChanges(working);
assert.equal(done.confirmedWithoutChanges,true);
assert.deepEqual(placements,unchanged,'No-change completion cannot invent or modify placements');
assert.equal((await db.get('meta','storeLocationWorkV1')).workspace,null,'Completed draft is cleared');
console.log('v3.18 shared synthetic Ace/Store verification, no false scans, no-change audit and draft visibility PASS');
