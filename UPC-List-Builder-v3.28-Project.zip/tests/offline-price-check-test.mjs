import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
const root='app/src/main/assets/www/';
const script=fs.readFileSync(root+'field-session/offline-price-check-controller.js','utf8');
const context={window:{},Date,Number,String,Array,Math,Set,Map,Promise,Error};
context.UPCPriceAuthority={VERIFIED_ACENET_SOURCE:'LEVEL2_STORE_RETAIL',level2:f=>f?.['Level 2 Retail Price']??null,observedPrice:item=>item.aceNetPriceAuthority==='LEVEL2_STORE_RETAIL'?Number(item.aceNetPrice):item.fields?.['Level 2 Retail Price']?Number(item.fields['Level 2 Retail Price']):null};
vm.createContext(context);vm.runInContext(script,context);
const html=fs.readFileSync(root+'index.html','utf8');
for(const id of ['listOfflineMode','validateOfflinePriceChecks','offlinePriceOverlay','offlinePriceKeypad','offlinePriceNext'])assert.ok(html.includes('id="'+id+'"'));
const source=fs.readFileSync(root+'lookup/lookup-router.js','utf8');assert.match(source,/offlinePriceProvider/);
let session={id:'session1',sessionType:'FIELD_SESSION',defaultTag:'Price Change',offlinePriceMode:true,offlinePriceChecks:[],items:[]};
const nodes={},listeners={};for(const id of ['offlinePriceOverlay','offlinePriceKeypad','offlinePriceNext','offlinePriceBack','offlinePriceCancel','offlinePriceValue','offlinePriceIdentity','offlinePriceError','offlinePriceStatus','offlinePriceStep','offlinePriceStage','listOfflineMode','validateOfflinePriceChecks','status','upc','itemCount'])nodes[id]={classList:{add(){},remove(){},toggle(){}},addEventListener:(type,fn)=>{listeners[id]=fn},textContent:'',value:'',disabled:false};
let priceCalls=0,saveCalls=0,id=0,remoteUpcs=0;
const svc=context.window.UPCOfflinePriceCheckController.create({elementById:x=>nodes[x],getCurrent:()=>session,saveCurrent:async()=>{saveCalls++},normalizeSku:x=>/^\d+$/.test(String(x))?String(x):'',normalizeUpc:x=>String(x||'').replace(/\D/g,''),newId:()=>String(++id),
 localResolver:{resolveSKU:async()=>({status:'FOUND',catalog:{provenance:'MASTER_LIBRARY',row:{skuKey:'12345',upcKey:'123456789012',fields:{'Level 2 Retail Price':'14.99'}}}})},
 itemMapper:{itemFromLibraryRow:row=>({status:'FOUND',sku:row.skuKey,upc:row.upcKey,fields:row.fields,recordOrigin:'ACE_DERIVED',description:'Test'})},
 priceService:{requestPrice:async sku=>{priceCalls++;return{status:'VERIFIED',sku,price:14.99}}},
 requestUpcs:async sku=>{remoteUpcs++;return{status:'VERIFIED',sku,upcs:['123456789012','123456789013']}},
 relationships:{getSkuUpcs:async()=>[{upcKey:'123456789012'}],resolveUPC:async()=>({status:'KNOWN',sku:'12345'})}
});
svc.bind();assert.equal(svc.capture('123456789012',{forceMode:'UPC'}),true);
for(const n of '12345')listeners.offlinePriceKeypad({target:{closest:()=>({dataset:{offlineKey:n}})}});listeners.offlinePriceNext();
for(const n of '1299')listeners.offlinePriceKeypad({target:{closest:()=>({dataset:{offlineKey:n}})}});listeners.offlinePriceNext();
await new Promise(resolve=>setImmediate(resolve));
assert.equal(priceCalls,0,'capture must not perform network requests');assert.equal(session.offlinePriceChecks[0].labelPrice,12.99);
assert.equal(await svc.validate(),true);assert.equal(session.offlinePriceChecks[0].status,'ADDED');assert.equal(session.items.length,1);assert.equal(session.items[0].priceDifference,-2);assert.equal(session.items[0].allUpcs.length,2);assert.equal(remoteUpcs,1);
assert.equal(await svc.validate(),false);assert.equal(session.items.length,1,'repeat validation must not duplicate');
session.offlinePriceChecks.push({id:'match',sku:'12345',scannedUpc:'123456789012',labelPrice:14.99,status:'PENDING',capturedAt:'2026-10-16T00:00:00Z'});
assert.equal(await svc.validate(),true);assert.equal(session.offlinePriceChecks[1].status,'MATCH');assert.equal(session.items.length,1);
session.offlinePriceChecks.push({id:'unknown',sku:'12345',scannedUpc:'000000000000',labelPrice:12.99,status:'PENDING',capturedAt:'2026-10-16T00:00:00Z'});
assert.equal(await svc.validate(),true);assert.equal(session.offlinePriceChecks[2].status,'REVIEW');assert.equal(session.items.length,1);
console.log('Offline capture, deferred Level 2, UPC guard, matched/skipped, existing Price Change export-compatible item PASS');
