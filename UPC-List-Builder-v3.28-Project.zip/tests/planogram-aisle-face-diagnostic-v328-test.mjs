import fs from 'node:fs';import vm from 'node:vm';import assert from 'node:assert/strict';
const web='app/src/main/assets/www/';
const policySource=fs.readFileSync(web+'store-locations/location-policy.js','utf8');
const c=vm.createContext({});vm.runInContext(policySource,c);const policy=vm.runInContext('UPCStoreLocationPolicy',c);
assert.equal(policy.normalizeAisleSide(undefined),'UNSPECIFIED');
assert.equal(policy.normalizeAisleSide('left'),'LEFT');
assert.equal(policy.normalizeAisleSide('RIGHT'),'RIGHT');
assert.throws(()=>policy.normalizeAisleSide('MIDDLE'),/Invalid aisle side/);
assert.equal(policy.validateAreaReference({kind:'AISLE',id:'aisle-7',aisle:'7'}).side,'UNSPECIFIED');
assert.equal(policy.validateAreaReference({kind:'AISLE',id:'aisle-7-left',aisle:'7',side:'LEFT'}).side,'LEFT');
assert.equal(policy.formatCompactLocation({current:{aisle:'7',aisleSide:'LEFT',resolvedSection:'1',origin:'ACE_IMPORT',fixtureType:'PEG',sourceRow:'1',sourceColumn:'2'}}),'A7L · S1 · R1 · C2');
assert.equal(policy.formatCompactLocation({current:{aisle:'7',aisleSide:'RIGHT',resolvedSection:'1',origin:'ACE_IMPORT',fixtureType:'PEG',sourceRow:'1',sourceColumn:'2'}}),'A7R · S1 · R1 · C2');
assert.equal(policy.formatCompactLocation({current:{aisle:'7',resolvedSection:'1',origin:'ACE_IMPORT',fixtureType:'PEG'}}),'A7 · S1 · Ace position unknown');
const repo=fs.readFileSync(web+'store-locations/location-repository.js','utf8');
const screen=fs.readFileSync(web+'store-locations/planogram-import-controller.js','utf8');
const maintenance=fs.readFileSync(web+'store-locations/location-maintenance-controller.js','utf8');
const lookup=fs.readFileSync(web+'store-locations/location-lookup-service.js','utf8');
const html=fs.readFileSync(web+'index.html','utf8');
for(const id of ['locationAreaSide','planogramAssignArea','planogramAssignStart','planogramAssignEnd','planogramAssignName','planogramAssignExisting','planogramSectionAvailability'])
 assert.ok(html.includes('id="'+id+'"'),id);
for(const source of [repo,screen,maintenance,lookup])vm.runInNewContext(source,{UPCStoreLocationPolicy:policy});
assert.match(maintenance,/openPlanogramAssignment\(/);
assert.doesNotMatch(maintenance,/if\(!prior&&sectionIds\.length\)startNewAssignment/);
assert.match(repo,/function assignSourceToNewModular\(/);
assert.match(repo,/write\(\['storeAreas','storeModulars','storeSources','storeSourceMembers','storePlacements'\]/);
assert.match(repo,/collisions\.length/);
assert.match(repo,/Existing source placements require review/);
assert.match(repo,/selected\.some\(n=>!permitted\.has\(n\)\)/);
assert.match(repo,/sourceStore\.put\(\{\.\.\.official,modularId\}\)/);
assert.match(repo,/physicalEvidence:false,physicalSectionId:null/);
assert.match(repo,/move them before changing its number or side/);
assert.match(screen,/repository\.assignSourceToNewModular/);
assert.match(screen,/occupied\.has\(x\)/);
assert.match(lookup,/aisleSide:area\.side\|\|'UNSPECIFIED'/);

const diagnosticSource=fs.readFileSync(web+'diagnostics/diagnostic-export-service.js','utf8');
const ui={};for(const id of ['diagSummary','settingsDiagnosticExportStatus','downloadDiag','settingsDiag'])
 ui[id]={textContent:'',disabled:false};
const finished=[],ops=[],sent=[],status=[];
let nativeId='';
const bridge={getNativeDiagnosticJournal:()=> '[]',getNetworkConnectivityState:()=> '{}',
 beginDiagnosticExport:(id,name)=>{nativeId=id;status.push(name)},appendDiagnosticExportChunk:(id,data)=>{assert.equal(id,nativeId);sent.push(data)},
 finishDiagnosticExport:id=>{assert.equal(id,nativeId);status.push('finish')},abortDiagnosticExport:id=>status.push('abort')};
const glob={window:{},Date,Number,String,Array,Map,Set,Math,Promise,Error,JSON,setTimeout,clearTimeout};
vm.createContext(glob);vm.runInContext(diagnosticSource,glob);
const make=(native)=>glob.window.UPCDiagnosticExportService.create({
 elementById:id=>ui[id],diagRows:()=>[{event:'startup',timestamp:'2026-10-16T00:00:00Z',sequence:1}],
 markCurrentStartupSession:()=>({rows:[{event:'startup',timestamp:'2026-10-16T00:00:00Z',sequence:1}],currentStartupSessionId:'test',currentCount:1,invariant:'CURRENT'}),
 diagnostic:()=>{},diagnosticStatus:()=>({deepDiagnosticMode:false}),startOperation:(...args)=>ops.push(args),
 finishOperation:(...args)=>finished.push(args),appVersion:'3.28',appBuild:'test',startupSessionId:'test',
 startupSnapshot:()=>({}),navigationSnapshot:()=>({}),scannerSnapshot:()=>({}),nativeBridgeProvider:()=>native,
 windowRef:{innerWidth:400,innerHeight:800,devicePixelRatio:1,screen:{width:400,height:800}},
 documentRef:{visibilityState:'visible'},navigatorRef:{onLine:true,serviceWorker:{},userAgent:'test',platform:'test',language:'en',mediaDevices:null},
 locationRef:{href:'https://localhost/'},matchMediaFn:()=>({matches:false}),secureContext:()=>true,urlRef:URL,blobCtor:Blob
});
const service=make(bridge);
assert.equal(await service.downloadDiagnostics(),true);assert.ok(nativeId);assert.equal(ui.downloadDiag.disabled,true);
assert.equal(finished.length,0,'cannot report success before native save acknowledgement');
service.acceptNativeExportTransferEvent({id:nativeId,phase:'ready'});
await new Promise(resolve=>setTimeout(resolve,10));
assert.ok(sent.length>0);
service.acceptNativeExportTransferEvent({id:nativeId,phase:'chunk'});
await new Promise(resolve=>setTimeout(resolve,10));
assert.ok(status.includes('finish'));
service.acceptNativeExportTransferEvent({id:nativeId,phase:'saved'});
assert.equal(finished.at(-1)[2],'PASS');assert.equal(ui.settingsDiag.disabled,false);
assert.match(ui.settingsDiagnosticExportStatus.textContent,/Saved to Downloads/);
assert.equal(JSON.parse(sent.join('')).diagnosticSchemaVersion,2);
const absent=make({getNativeDiagnosticJournal:()=> '[]'});
assert.equal(await absent.downloadDiagnostics(),false,'incomplete Android bridge must not claim a browser download');
assert.match(ui.settingsDiagnosticExportStatus.textContent,/unavailable/);
console.log('Aisle face migration, atomic planogram handoff, native diagnostic progress and saved-only success PASS');
