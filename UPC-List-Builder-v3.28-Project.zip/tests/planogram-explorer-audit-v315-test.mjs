/** v3.15 focused regression: resumable draft without mutating Ace source or lists. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
const root='app/src/main/assets/www/',read=p=>fs.readFileSync(root+p,'utf8');
const ctx=vm.createContext({console});
vm.runInContext(read('store-locations/location-explorer-draft-service.js'),ctx);
vm.runInContext(read('store-locations/location-explorer-policy.js'),ctx);
const Drafts=vm.runInContext('UPCLocationExplorerDraftService',ctx);
const Policy=vm.runInContext('UPCLocationExplorerPolicy',ctx);
const database=new Map();
const db={get:async(store,key)=>database.get(store+':'+key),put:async(store,row)=>database.set(store+':'+row.key,structuredClone(row))};
const repository={sourceSignature:rows=>JSON.stringify(rows.map(x=>[x.id,x.digest]))};
const workPolicy={fingerprint:rows=>JSON.stringify(rows)};
const drafts=Drafts.create({db,repository,workPolicy});
function model(id){
 const source={id:id+'-ace',digest:'official-unchanged',name:id,modularId:id,sourceSegments:[{id:'SOURCE-1',ordinal:1}]};
 const ace=[{id:id+':1',skuKey:'123',sourceOnly:true,sourceSegment:'SOURCE-1',sourceRow:2,sourceColumn:8},
 {id:id+':2',skuKey:'456',sourceOnly:true,sourceSegment:'SOURCE-1',sourceRow:3,sourceColumn:2}];
 return{modular:{id,name:id,physicalSectionIds:['1']},area:{name:'Aisle 8'},source,store:[],ace,placements:[],mode:'ACE'};
}
const tape=model('tape'),bolt=model('bolt');
let first=await drafts.save(drafts.initial(tape));
assert.equal(first.basis,'ACE');
assert.equal(first.items.length,2);
assert.equal(first.viewed.length,0);
first.items.splice(1,0,{id:'new-item',skuKey:'999',origin:'USER_EDIT',physicalEvidence:false});
first.viewed=['SKU:123'];first.index=1;first.focusId='new-item';first.edits=1;
first.tags['SKU:123']=['NIF','Price Change'];
first=await drafts.save(first);
const second=await drafts.save(drafts.initial(bolt));
assert.equal((await drafts.list()).length,2,'Multiple independent planograms must be resumable');
assert.equal((await drafts.load('tape')).items[1].skuKey,'999');
assert.deepEqual((await drafts.load('tape')).tags['SKU:123'],['NIF','Price Change']);
assert.equal((await drafts.load('tape')).viewed.length,1);
assert.equal((await drafts.load('tape')).index,1);
assert.equal(drafts.isCurrent(first,tape),true);
assert.equal(drafts.isCurrent(first,{...tape,source:{...tape.source,digest:'new Ace revision'}}),false);
assert.equal(tape.ace.length,2,'Draft corrections cannot mutate Ace source rows');
assert.equal(tape.ace[1].skuKey,'456','Official source order remains intact');
await drafts.finish('tape',{kind:'STORE',sourceId:tape.source.id,tags:first.tags,viewed:first.viewed});
assert.equal(await drafts.load('tape'),null);
assert.equal((await drafts.list()).length,1,'Confirming one audit must preserve other unfinished work');
assert.equal((await drafts.confirmed('tape')).tags['SKU:123'][0],'NIF');
assert.equal((await drafts.load('bolt')).items.length,second.items.length);
await drafts.discard('bolt');
assert.equal((await drafts.list()).length,0);
const saved=Policy.ordered({modular:{physicalSectionIds:['1']},placements:[
 {id:'a',skuKey:'1',origin:'ACE_IMPORT',physicalEvidence:false,explorerOrder:2},
 {id:'b',skuKey:'2',origin:'USER_EDIT',physicalEvidence:false,explorerOrder:1}
],mode:'STORE'});
assert.equal(saved.length,2,'Ordered store layout must retain members without inventing physical coordinates');
assert.equal(saved[0].skuKey,'2');
assert.equal(saved[1].sourceOnly,true);
const html=read('index.html'),controller=read('store-locations/location-explorer-controller.js');
for(const id of ['locationExplorerInsert','locationExplorerEditButton','locationExplorerDelete','locationExplorerSettingsOpen',
 'locationExplorerSettingsLoad','locationExplorerSettingsConfirm','locationExplorerSettingsDiscard','locationExplorerTagPanel',
 'locationExplorerEditLocationNote'])assert.ok(html.includes('id="'+id+'"'),id);
assert.match(controller,/original Ace planogram remains unchanged/i);
assert.match(controller,/await repository\.approvePhysicalLayout/);
assert.match(controller,/await drafts\.finish/);
assert.match(controller,/show\('locationExplorerSettings',true\)/);
assert.doesNotMatch(controller,/Ace source · unverified/);
assert.ok(html.includes('location-explorer-draft-service.js'));
console.log('v3.15 multiple audits, saved location edits, source integrity, tags and settings: PASS');
