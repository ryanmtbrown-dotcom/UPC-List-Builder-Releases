/** v3.16 synthetic Ace/store comparison: duplicates, edits, order and evidence integrity. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
const base='app/src/main/assets/www/';
const ctx=vm.createContext({});
vm.runInContext(fs.readFileSync(base+'store-locations/location-explorer-difference-service.js','utf8'),ctx);
const svc=vm.runInContext('UPCLocationExplorerDifferenceService',ctx);
const ace=[
 {id:'source-member:ace:A:0',skuKey:'A',sourceSegment:'SOURCE-1',sourceRow:1,sourceColumn:1},
 {id:'source-member:ace:B:0',skuKey:'B',sourceSegment:'SOURCE-1',sourceRow:1,sourceColumn:2},
 {id:'source-member:ace:B:1',skuKey:'B',sourceSegment:'SOURCE-1',sourceRow:2,sourceColumn:1},
 {id:'source-member:ace:C:0',skuKey:'C',sourceSegment:'SOURCE-1',sourceRow:2,sourceColumn:2},
 {id:'source-member:ace:D:0',skuKey:'D',sourceSegment:'SOURCE-1',sourceRow:2,sourceColumn:3}
];
const unchanged=ace.map((p,i)=>({...p,id:'accepted:'+p.id,explorerOrder:i+1}));
const unchangedResult=svc.compare({ace,store:unchanged});
assert.equal(unchangedResult.total,0,'Ace-imported positions do not count as altered solely because they are accepted');
const revised=[
 unchanged[0],unchanged[1],unchanged[2],
 {...unchanged[3],locationNote:'A8 · S1 · SF · R3 · P23'},
 {id:'explorer:new',skuKey:'X',locationNote:'A8 · S2 · SH · R4 · C1',explorerOrder:5}
];
const r=svc.compare({ace,store:revised});
assert.equal(r.inserted.length,1);
assert.equal(r.deleted.length,1);
assert.equal(r.changed.length,1);
assert.equal(r.inserted[0].identity,'SKU:X');
assert.equal(r.deleted[0].identity,'SKU:D');
assert.equal(r.changed[0].identity,'SKU:C');
assert.match(r.changed[0].after,/P23/);
assert.ok(![...r.inserted,...r.deleted,...r.changed].some(x=>x.identity==='SKU:B'),
 'An unchanged repeated SKU must not become a false change');
assert.equal(ace[3].locationNote,undefined,'Comparison cannot rewrite source');
assert.equal(unchanged[3].locationNote,undefined,'Comparison cannot rewrite accepted store');
const reorder=svc.compare({ace,store:[unchanged[1],unchanged[0],...unchanged.slice(2)]});
assert.equal(reorder.inserted.length,0);
assert.equal(reorder.deleted.length,0);
assert.equal(reorder.changed.length,2,'Only genuinely reordered shared items are changed');
const inserted=svc.compare({ace,store:[unchanged[0],{id:'new',skuKey:'X'},...unchanged.slice(1)]});
assert.equal(inserted.changed.length,0,'Insertion does not falsely mark all subsequent items moved');
const html=fs.readFileSync(base+'index.html','utf8'),js=fs.readFileSync(base+'store-locations/location-explorer-controller.js','utf8');
const screen=html.slice(html.indexOf('<section id="locationExplorerScreen"'),html.indexOf('<section id="locationScreen"'));
assert.ok(screen.indexOf('data-explorer-lookup-mode="SKU"')<screen.indexOf('id="locationExplorerSettingsOpen"'),'gear must follow UPC/SKU selector');
assert.doesNotMatch(screen,/<button[^>]+id="locationExplorerTags"/);
assert.match(screen,/id="locationExplorerSettingsDifferences"/);
assert.match(screen,/id="locationExplorerDifferences"/);
assert.match(js,/sourceSnapshot:model\.ace\.map\(differences\.take\)/);
assert.match(js,/storeSnapshot:confirmedStoreItems\.map\(differences\.take\)/);
console.log('v3.16 synthetic source/layout differences, duplicates, inserts, locations and immutable evidence PASS');
