/** V2 planogram visual coordinate, sequence, compact zone, and device parity contracts. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import {webcrypto} from 'node:crypto';
import {validatePlanogram,digestSource,validateChunkRows,validatePlanogramHeader} from '../integrations/chatgpt-mcp/cloudflare/src/planogram-validate.mjs';
const root='app/src/main/assets/www/store-locations/';
const context=vm.createContext({crypto:webcrypto,TextEncoder,console});
for(const file of ['planogram-import-service.js','location-explorer-policy.js','location-policy.js'])vm.runInContext(fs.readFileSync(root+file,'utf8'),context);
const device=vm.runInContext('UPCPlanogramImportService',context);
const explorer=vm.runInContext('UPCLocationExplorerPolicy',context);
const formatter=vm.runInContext('UPCStoreLocationPolicy',context);
const clone=structuredClone;
const row=(sourceRowId,sku,visualOrder,extras={})=>({sourceRowId,sku,sourceSegment:'SOURCE-1',fixtureType:'SHELF',
 sourcePositionStatus:'DIAGRAM_ESTIMATE',sourcePositionNote:'Illustration page 2, exact top-to-bottom shelf and left-to-right placement',
 visualMode:'COUNTED',visualOrder,visualShelf:1,facings:1,visualColumnStart:1,visualColumnEnd:1,membershipDisposition:'MERCHANDISE',...extras});
const fixture=()=>({schemaVersion:'PLANOGRAM_IMPORT_V2',
 source:{planogramId:'S1TAPE04',name:'Tape and Accessories',sourceIdentityEvidence:'Ace cover',nominalWidthFt:8,nominalFourFootSections:2,widthEvidence:'Cover shows 8 ft'},
 sourceSegments:[{id:'SOURCE-1',ordinal:1,fixtureType:'SHELF'},{id:'SOURCE-2',ordinal:2,fixtureType:'SPCFIX'}],
 placements:[
 row('row-1','A',1,{facings:2,visualColumnStart:1,visualColumnEnd:2}),
 row('row-2','B',2,{facings:3,visualColumnStart:3,visualColumnEnd:5}),
 row('row-3','C',3,{visualColumnStart:6,visualColumnEnd:6}),
 row('row-4','D',4,{visualShelf:2,visualColumnStart:1,visualColumnEnd:1}),
 row('row-5','E',5,{sourceSegment:'SOURCE-2',fixtureType:'SPCFIX',facings:null,visualMode:'ZONE',visualShelf:null,visualColumnStart:null,visualColumnEnd:null,visualZone:'CNT-R',sourcePositionNote:'Small necklaces on crowded compact fixture, visual zone much faster than counting'}),
 row('row-6','A',1,{facings:2,visualColumnStart:1,visualColumnEnd:2}),
 {sourceRowId:'row-7',description:'Shelf divider',sourceSegment:'SOURCE-1',fixtureType:'OTHER',membershipDisposition:'NON_MERCHANDISE'}],
 reconciliation:{sourceReportRows:7,submittedRowRecords:7,merchandiseRows:6,excludedNonMerchandiseRows:1,unresolvedRows:0,distinctMerchandiseSkus:5,unrepresentedRows:0},
 exclusions:[{sourceRowId:'row-7',reason:'Fixture, not retail merchandise'}],unresolved:[],
 manifest:{submissionId:'visual-order-1',expectedChunks:1,sourceDigest:null,status:'COMPLETE'}});
const valid=validatePlanogram(fixture());
assert.equal(valid.schemaVersion,'PLANOGRAM_IMPORT_V2');
const legacy={...fixture(),schemaVersion:'PLANOGRAM_IMPORT_V1',placements:[{sourceRowId:'row-1',sku:'A',sourceSegment:'SOURCE-1',fixtureType:'PEG',reportRow:'1',reportColumn:'1',membershipDisposition:'MERCHANDISE'}],reconciliation:{sourceReportRows:1,submittedRowRecords:1,merchandiseRows:1,excludedNonMerchandiseRows:0,unresolvedRows:0,distinctMerchandiseSkus:1,unrepresentedRows:0},exclusions:[]};
assert.equal(validatePlanogram(legacy).schemaVersion,'PLANOGRAM_IMPORT_V1');
const pkg={batchId:'98765432-1234-4abc-8aaa-123456789012',state:'pending',...valid};
pkg.manifest.sourceDigest=await digestSource(valid);
assert.equal((await device.verify(pkg)).distinctMerchandiseSkus,5);
const sourceMembers=device.stageSource(pkg);
const first=sourceMembers.find(m=>m.skuKey==='A'),second=sourceMembers.find(m=>m.skuKey==='B'),zone=sourceMembers.find(m=>m.skuKey==='E');
assert.equal(first.positions.length,2,'repeated report rows preserved');
assert.equal(first.positions[0].sourceColumn,'1:2');
assert.equal(second.positions[0].sourceColumn,'3:5','inclusive facing range');
assert.equal(second.positions[0].sourceRow,1,'diagram position is effective official shelf coordinate');
assert.equal(second.positions[0].sourceOrder,2);
assert.equal(zone.positions[0].fixtureZone,'CNT-R');
assert.equal(zone.positions[0].sourceColumn,null);
const source={id:'accepted',name:'Tape',modularId:'m1'},modular={id:'m1',physicalSectionIds:['1','2']};
const shuffled=[...sourceMembers].reverse();
const ace=explorer.ordered({modular,source,sourceMembers:shuffled,mode:'ACE'});
assert.deepEqual(ace.map(x=>x.skuKey),['A','B','C','D','E'],'next/previous follows visual item sequence, not SKU or source member order');
assert.equal(ace.length,5,'two Product Report rows for exactly one visual placement have one Next stop');
assert.equal(ace[1].sourceOrder,2);
assert.equal(formatter.formatCompactLocation({current:{origin:'ACE_IMPORT',physicalEvidence:false,aisle:'8',resolvedSection:'1',fixtureType:'SHELF',...second.positions[0]}}),'A8 · S1 · SH1 · C3:5');
assert.equal(formatter.formatCompactLocation({current:{origin:'ACE_IMPORT',physicalEvidence:false,aisle:'8',resolvedSection:'2',fixtureType:'SPCFIX',...zone.positions[0]}}),'A8 · S2 · SF · CNT-R');
const testFail=(change,re)=>{const x=fixture();change(x);assert.throws(()=>validatePlanogram(x),re);assert.throws(()=>device.validate({...pkg,...x,manifest:{...pkg.manifest}}),/./);};
testFail(x=>{x.placements[1].visualColumnEnd=6},/span must match facings/);
testFail(x=>{x.placements[1].visualColumnStart=2},/overlap|span must match facings/);
testFail(x=>{x.placements[1].visualOrder=4},/reused by a different placement/);
testFail(x=>{x.placements[4].visualZone='FAR-L'},/visual zone invalid/);
testFail(x=>{x.placements[4].visualColumnStart=15},/requires dense shelf|no columns/);
testFail(x=>{x.placements[1].visualOrder=7},/consecutive|contradicts/);
testFail(x=>{x.placements[0].visualOrder=2;x.placements[1].visualOrder=1;x.placements[5].visualOrder=2},/contradicts/);
testFail(x=>{x.placements[1].sourcePositionStatus='UNRESOLVED'},/Unresolved position evidence/);
const uncertain=fixture();uncertain.placements[4]={...uncertain.placements[4],visualMode:'UNRESOLVED',visualOrder:null,visualZone:null,sourcePositionStatus:'UNRESOLVED'};
assert.equal(validatePlanogram(uncertain).placements[4].visualOrder,null);
assert.equal(device.validate({...pkg,...uncertain,manifest:pkg.manifest}).sourceRows.length,6);
for(const z of ['LFT','L-CNT','CNT','CNT-R','RGT']){
 const x=fixture();x.placements[4].visualZone=z;
 assert.equal(validatePlanogram(x).placements[4].visualZone,z);
 assert.equal(device.validate({...pkg,...x,manifest:pkg.manifest}).sourceRows[4].visualZone,z);
}
const header=fixture();delete header.placements;header.manifest.expectedChunks=2;
assert.equal(validatePlanogramHeader(header).schemaVersion,'PLANOGRAM_IMPORT_V2');
assert.equal(validateChunkRows(fixture().placements.slice(0,2),'PLANOGRAM_IMPORT_V2').length,2);
assert.throws(()=>validateChunkRows([{...fixture().placements[1],visualZone:'INVALID'}],'PLANOGRAM_IMPORT_V2'),/visual zone invalid/);
const tampered=clone(pkg);tampered.placements[1].visualColumnEnd=6;
await assert.rejects(()=>device.verify(tampered),/span and facings mismatch/);

// Regression: one peg SKU across adjacent actual report columns must have ONE Next stop.
const pegFixture=()=>{
 const x=fixture();x.sourceSegments=[{id:'SOURCE-1',ordinal:1,fixtureType:'PEG'}];
 x.placements=[
  {sourceRowId:'hook-3',sku:'PEG-A',sourceSegment:'SOURCE-1',fixtureType:'PEG',reportRow:'5',reportColumn:'3',facings:1,visualMode:'COUNTED',visualOrder:1,visualColumnStart:3,visualColumnEnd:5,membershipDisposition:'MERCHANDISE'},
  {sourceRowId:'hook-4',sku:'PEG-A',sourceSegment:'SOURCE-1',fixtureType:'PEG',reportRow:'5',reportColumn:'4',facings:1,visualMode:'COUNTED',visualOrder:1,visualColumnStart:3,visualColumnEnd:5,membershipDisposition:'MERCHANDISE'},
  {sourceRowId:'hook-5',sku:'PEG-A',sourceSegment:'SOURCE-1',fixtureType:'PEG',reportRow:'5',reportColumn:'5',facings:1,visualMode:'COUNTED',visualOrder:1,visualColumnStart:3,visualColumnEnd:5,membershipDisposition:'MERCHANDISE'},
  {sourceRowId:'hook-6',sku:'PEG-B',sourceSegment:'SOURCE-1',fixtureType:'PEG',reportRow:'5',reportColumn:'6',facings:1,visualMode:'COUNTED',visualOrder:2,visualColumnStart:6,visualColumnEnd:6,membershipDisposition:'MERCHANDISE'},
  {sourceRowId:'hook-7',sku:'PEG-A',sourceSegment:'SOURCE-1',fixtureType:'PEG',reportRow:'5',reportColumn:'7',facings:1,visualMode:'COUNTED',visualOrder:3,visualColumnStart:7,visualColumnEnd:7,membershipDisposition:'MERCHANDISE'}
 ];
 x.reconciliation={sourceReportRows:5,submittedRowRecords:5,merchandiseRows:5,excludedNonMerchandiseRows:0,unresolvedRows:0,distinctMerchandiseSkus:2,unrepresentedRows:0};x.exclusions=[];return x;
};
const pegValidated=validatePlanogram(pegFixture());
const pegPacket={...pkg,...pegValidated,manifest:{...pkg.manifest}};
assert.equal(device.validate(pegPacket).sourceRows.length,5);
const pegMembers=device.stageSource(pegPacket);
assert.deepEqual(Array.from(pegMembers.find(x=>x.skuKey==='PEG-A').positions,p=>p.sourceColumn),['3:5','3:5','3:5','7']);
const pegAce=explorer.ordered({modular,source,sourceMembers:pegMembers,mode:'ACE'});
assert.deepEqual(Array.from(pegAce,x=>x.skuKey),['PEG-A','PEG-B','PEG-A']);
assert.deepEqual(Array.from(pegAce,x=>x.sourceColumn),['3:5','6','7']);
const pegRange=formatter.formatCompactLocation({current:{origin:'ACE_IMPORT',physicalEvidence:false,aisle:'17',resolvedSection:'3',...pegMembers[0].positions[0]}});
assert.equal(pegRange,'A17 · S3 · R5 · C3:5');
const pegFailure=(modify,serverError,deviceError)=>{
 const x=pegFixture();modify(x);
 assert.throws(()=>validatePlanogram(x),serverError);
 assert.throws(()=>device.validate({...pkg,...x}),deviceError||/./);
};
pegFailure(x=>{x.placements[1].visualOrder=2},/Different visual placements overlap counted columns|Visual item number reused/,/Overlapping counted positions|Visual order collision/);
pegFailure(x=>{x.placements[1].reportColumn='8'},/Peg report column must fall inside/,/Peg report column must fall inside/);
pegFailure(x=>{x.placements.splice(1,1);x.reconciliation.sourceReportRows--;x.reconciliation.submittedRowRecords--;x.reconciliation.merchandiseRows--},/missing hook position/,/Missing hook/);
pegFailure(x=>{x.placements[1].visualColumnEnd=4},/Visual item number reused/,/Visual order collision/);
// A single aggregate PEG row may count several facings; each individual hook row counts one.
const aggregated=pegFixture();aggregated.placements.splice(1,2);aggregated.placements[0].facings=3;
aggregated.reconciliation.sourceReportRows=3;aggregated.reconciliation.submittedRowRecords=3;aggregated.reconciliation.merchandiseRows=3;
assert.equal(validatePlanogram(aggregated).placements[0].visualColumnEnd,5);
assert.equal(device.validate({...pkg,...aggregated,manifest:{...pkg.manifest}}).sourceRows.length,3);
// Accent spans are built with safe DOM nodes and only for inclusive column ranges.
const explorerUi=fs.readFileSync(root+'location-explorer-controller.js','utf8');
const explorerCss=fs.readFileSync(root+'location-explorer.css','utf8');
assert.match(explorerUi,/function locationSummary\(value\)/);
assert.match(explorerUi,/target\.append\(doc\.createTextNode/);
assert.match(explorerCss,/\.locationExplorerFacingRange\{color:var\(--accent-strong\)/);
console.log('V2 verified: device/server parity, numeric inclusive facings, zones, source grouping, visual Next order, old V1 and digest protection PASS');
