/** Permanent v3.10 Explorer order/identity/atomic correction/wizard integration contracts. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
const root='app/src/main/assets/www/';
const read=f=>fs.readFileSync(root+f,'utf8');
const context=vm.createContext({Date,console});
for(const f of ['store-locations/location-explorer-policy.js','store-locations/location-explorer-service.js','store-locations/location-explorer-edit-service.js','store-locations/location-work-policy.js','store-locations/location-policy.js'])vm.runInContext(read(f),context);
const P=vm.runInContext('UPCLocationExplorerPolicy',context),R=vm.runInContext('UPCLocationExplorerService',context),E=vm.runInContext('UPCLocationExplorerEditService',context),W=vm.runInContext('UPCLocationWorkPolicy',context);
const modular={id:'Tape',active:true,areaId:'A7',name:'Tape',physicalSectionIds:['1','2']},area={id:'A7',kind:'AISLE',aisle:'7',name:'Aisle 7',active:true};
const row=(sku,sec,order,row=1)=>({id:'p:'+sku,modularId:'Tape',skuKey:sku,upcKey:null,origin:'USER_SCAN',role:'HOME',physicalEvidence:true,physicalSectionId:sec,fixtureType:'PEG',rowOrdinal:row,observedOrder:order,facings:1,storeAdded:false});
const original=[row('100','1',2),row('200','1',1),row('300','2',1),row('400','1',1,2)];
assert.deepEqual(P.ordered({modular,placements:original,mode:'STORE'}).map(p=>p.skuKey),['200','100','400','300']);
assert.equal(P.position(original[0]),'SEC 1 · Row 1 · Order 2 · 1 facings');
const source={id:'SRC',current:true,name:'Tape 8ft',modularId:'Tape'};
const sourceMembers=[{skuKey:'100',positions:[{sourceSegment:'SOURCE-2',sourceRow:'52',sourceColumn:'4'}]},{skuKey:'200',positions:[{sourceSegment:'SOURCE-1',sourceRow:'2',sourceColumn:'1'}]},{skuKey:'300',positions:[]}];
const ace=P.ordered({modular,source,sourceMembers,mode:'ACE'});
assert.deepEqual(ace.map(p=>p.skuKey),['200','100','300']);
assert.equal(ace.every(x=>x.sourceOnly&&!x.physicalEvidence),true);
assert.match(P.position(ace[1]),/R52/);
assert.match(P.position(ace[2]),/Order not verified/);
assert.equal(P.ordered({modular,placements:[],mode:'STORE'}).length,0);
const identity={skuKey:'100',upcKey:null};
assert.equal(P.same(identity,original[0]),true);
const moved=P.propose({baseline:original,modular,action:'MOVE_TO',targetId:'p:100',section:'2',row:3});
assert.equal(moved.placements.length,original.length);
assert.equal(moved.placements.find(p=>p.id==='p:100').physicalSectionId,'2');
assert.equal(moved.placements.find(p=>p.id==='p:200').physicalSectionId,'1');
assert.equal(original[0].physicalSectionId,'1','proposal must not modify existing accepted evidence');
const inserted=P.propose({baseline:original,modular,action:'INSERT_BEFORE',targetId:'p:100',identity:{skuKey:'NEW',role:'HOME',storeAdded:true},idFactory:()=> 'inserted'});
assert.equal(inserted.placements.length,original.length+1);
assert.deepEqual(P.ordered({modular,placements:inserted.placements,mode:'STORE'}).filter(p=>p.physicalSectionId==='1'&&p.rowOrdinal===1).map(p=>p.skuKey),['200','NEW','100']);
assert.equal(inserted.placements.find(p=>p.skuKey==='NEW').storeAdded,true);
const removed=P.propose({baseline:original,modular,action:'REMOVE',targetId:'p:200'});
assert.equal(removed.placements.length,original.length-1);
assert.equal(removed.placements.find(p=>p.skuKey==='100').observedOrder,1);
assert.ok(!removed.placements.some(p=>p.id==='p:200'));
const facings=P.propose({baseline:original,modular,action:'FACINGS',targetId:'p:100',facings:4});
assert.equal(facings.placements.find(p=>p.id==='p:100').facings,4);
assert.equal(facings.changed.length,1);
assert.throws(()=>P.propose({baseline:original,modular,action:'FACINGS',targetId:'p:100',facings:501}),/Facings/);
assert.throws(()=>P.propose({baseline:original,modular,action:'MOVE_TO',targetId:'p:100',section:'3',row:1}),/real section/);
const fixture={...modular,physicalSectionIds:[],id:'COUNTER'};
const custom=[{...row('SKU1',null,1),id:'custom',modularId:'COUNTER'}];
const customMove=P.propose({baseline:custom,modular:fixture,action:'MOVE_TO',targetId:'custom',section:null,row:5});
assert.equal(customMove.placements[0].physicalSectionId,null);
assert.equal(customMove.placements[0].rowOrdinal,5);
const secondary=[{...row('S1','1',1),role:'SECONDARY',approvedException:{placementId:'p:S1',skuKey:'S1',physicalSectionId:'1',rowOrdinal:1,observedOrder:1,confirmedAt:42}},row('S2','1',2)];
const secondaryShift=P.propose({baseline:secondary,modular,action:'INSERT_BEFORE',targetId:'p:S1',identity:{skuKey:'ADDED',role:'HOME'},idFactory:()=> 'new'});
assert.equal(secondaryShift.requiresSecondary.length,1,'secondary moved by a row insertion requires renewed exact consent');
assert.equal(secondaryShift.requiresSecondary[0].approvedException,null);
let state=[...original],sourceDigest='[]',seq=0,commits=0;
const repository={
 getModular:async id=>id==='Tape'?modular:id==='COUNTER'?fixture:null,
 getArea:async()=>area,
 listModulars:async()=>[modular],
 listPlacements:async()=>structuredClone(state),listSourcesForModular:async()=>[],listSourceMembers:async()=>sourceMembers,
 getSource:async id=>id==='SRC'?source:null,
 bySku:async sku=>({placements:state.filter(p=>p.skuKey===sku),sourceMembers:sourceMembers.filter(p=>p.skuKey===sku).map(x=>({...x,sourceId:'SRC'}))}),
 byUpc:async()=>({placements:[],sourceMembers:[]}),
 sourceSignature:()=>sourceDigest,
 async approvePhysicalLayout(command){
  if(command.expectedFingerprint!==W.fingerprint(state))throw Error('Accepted layout changed since this draft began');
  if(command.expectedSourceSignature!==sourceDigest)throw Error('Official source changed');
  for(const p of command.items)if(p.role==='SECONDARY'&&(!p.approvedException||p.approvedException.placementId!==p.id))throw Error('Secondary approval missing');
  state=structuredClone(command.items);commits++;return{accepted:true};
 }
};
const catalog={resolveSKU:async sku=>({status:'FOUND',row:{skuKey:sku,description:'Tape merchandise '+sku,upc:'123456789012',price:'2.49',orderMultiple:'6',retailUnits:'EA'}}),
 resolveDirectUPC:async()=>({status:'FOUND',row:{skuKey:'100',description:'Tape merchandise 100'}})};
const service=R.create({repository,catalog,policy:P});
assert.equal((await service.resolveIdentity('100','SKU')).skuKey,'100');
assert.equal((await service.resolveIdentity('123456789012','UPC')).skuKey,'100');
assert.equal((await service.candidates({skuKey:'100'}))[0].modularId,'Tape');
const initial=await service.display('Tape');assert.equal(initial.mode,'STORE');assert.equal(initial.store.length,4);assert.equal(initial.ace.length,0);
assert.equal((await service.details(initial.items[0])).description,'Tape merchandise 200');
const edit=E.create({repository,policy:P,workPolicy:W,idFactory:()=>String(++seq)});
let prepared=await edit.prepare('Tape','FACINGS',{targetId:'p:100',facings:3});
assert.equal(state.find(p=>p.id==='p:100').facings,1,'preview does not write');
let committed=await edit.commit(prepared);assert.equal(commits,1);assert.equal(state.find(p=>p.id==='p:100').facings,3);
await edit.undo(committed.undo);assert.equal(commits,2);assert.equal(state.find(p=>p.id==='p:100').facings,1);
prepared=await edit.prepare('Tape','FACINGS',{targetId:'p:100',facings:2});
state=state.map(p=>p.id==='p:300'?{...p,facings:2}:p);
await assert.rejects(edit.commit(prepared),/Accepted layout changed/);assert.equal(commits,2);
prepared=await edit.prepare('Tape','REMOVE',{targetId:'p:200'});sourceDigest='["new-source"]';
await assert.rejects(edit.commit(prepared),/Official source changed/);sourceDigest='[]';
state=[...secondary];prepared=await edit.prepare('Tape','INSERT_BEFORE',{targetId:'p:S1',identity:{skuKey:'NEW',role:'HOME'},idFactory:()=> 'something'});
await assert.rejects(edit.commit(prepared),/Separate stocked location needs confirmation/);
await edit.commit(prepared,prepared.requiresSecondary.map(p=>p.id));
assert.equal(state.find(p=>p.skuKey==='S1').approvedException.observedOrder,2);
const sourceUnplaced=P.ordered({modular,source,sourceMembers,mode:'ACE'});
assert.equal(sourceUnplaced[0].physicalSectionId,undefined,'source browse never fabricates physical section');
const html=read('index.html');for(const id of ['locationExploreOpen','locationExplorerScreen','locationExplorerPrevious','locationExplorerNext','locationExplorerConfirm','locationExplorerWizardStart','locationExplorerUndo'])assert.ok(html.includes('id="'+id+'"'),id+' missing');
assert.match(read('application/navigation-controller.js'),/locationExplorerScreen/);
assert.match(read('scanner/scanner-workspace-router.js'),/explorerProvider/);
assert.match(read('application/application-shell.js'),/UPCLocationExplorerFeature\.create/);
assert.match(read('store-locations/location-work-controller.js'),/beginFromExplorer/);
assert.match(read('store-locations/location-explorer-controller.js'),/hasUnfinishedDraft/);
assert.match(read('store-locations/location-work-controller.js'),/seedOnly:true/);
assert.match(read('store-locations/location-work-service.js'),/!work.seedOnly\|\|p.type!=='REMOVE'/,'Explorer single-item seed cannot propose removing unscanned neighbors');
assert.ok(!read('store-locations/location-explorer-controller.js').includes('saveCurrent('),'Explorer must not create/modify Work Session records');
console.log('Planogram Explorer v3.10 traversal, source evidence, confirmed editing, staleness, undo, secondary reapproval, wizard routing: PASS');
