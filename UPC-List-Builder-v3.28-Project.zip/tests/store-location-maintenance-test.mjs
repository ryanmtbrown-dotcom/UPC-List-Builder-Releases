import fs from 'node:fs';import vm from 'node:vm';import assert from 'node:assert/strict';
const source=fs.readFileSync('app/src/main/assets/www/store-locations/location-maintenance-controller.js','utf8');
const css=fs.readFileSync('app/src/main/assets/www/store-locations/location-maintenance.css','utf8');
const html=fs.readFileSync('app/src/main/assets/www/index.html','utf8');
const shell=fs.readFileSync('app/src/main/assets/www/application/application-shell.js','utf8');
vm.runInNewContext(source,{});
for(const id of ['openLocations','locationScreen','locationLayoutPane','locationPlanogramPane','locationModularArea','locationModularName','locationStartSection','locationEndSection','locationSectionChoices','locationOverlapBox','locationOverlapConfirmed','locationModularSave','locationModularCancel','locationAreaManager','locationCreateArea','locationAreaKind','locationAreaName','locationAreaSave','locationAreaList','locationAisleAssignments','locationAddModularForAisle','locationBrowseCreateArea','locationAddSectionStart','locationAddSectionEnd','locationAddSections','locationRemoveSectionChoice','locationRemoveSection','locationInitialSectionEnd','locationSourceList','locationMessage','locationFixtureId','locationAreaSuggestions','locationModularList','planogramBatchSelect','planogramSourceAssignSelect'])assert.ok(html.includes('id="'+id+'"'),'Missing UI element '+id);
assert.match(shell,/UPCLocationMaintenanceController\.create/);assert.match(shell,/locationMaintenanceController\.setPlanogramRefresh/);
assert.ok(css.includes('var(--accent)')&&css.includes('var(--surface-raised)'));
assert.ok(css.includes('@media(max-width:520px)'));
assert.ok(!source.includes('innerHTML'),'Names must use safe textContent');
assert.ok(!css.includes('position:sticky')&&!css.includes('position:fixed'),'Do not overlay the viewport with permanent status bar');
assert.match(source,/locationOverlapConfirmed/);assert.match(source,/confirmedAt:Date.now/);
console.log('Location assignment UI separation, premium style and explicit overlapping-space confirmation PASS');

assert.ok(!html.includes('id="locationAreaCapacity"'),'The old immutable aisle maximum field is gone');
assert.ok(html.indexOf('id="locationAisleBrowse"')<html.indexOf('id="locationAssignmentDisclosure"'),'Aisle selection precedes assignment');
assert.ok(html.indexOf('id="locationPlanogramChoice"')>html.indexOf('id="locationEndSection"'),'Planogram follows section selection');
for(const term of ['function createdSections(', 'function addSectionRange(', 'function removeSection(', 'function removeArea(', 'function removeModular(','locationRemoveSectionChoice','locationDangerAction','Allow overlapping sections'])assert.ok(source.includes(term)||html.includes(term),'Missing location behavior '+term);
const repo=fs.readFileSync('app/src/main/assets/www/store-locations/location-repository.js','utf8');
for(const op of ['removeArea','removeSections','removeModular'])assert.ok(repo.includes('function '+op+'('),'Missing repository operation '+op);
assert.match(repo,/sources\.put\(\{\.\.\.source,modularId:null\}\)/);
console.log('Aisle-first creation, assignment and removal structure PASS');

assert.match(source,/modules=modules\.map\(m=>m\.area\?m:/,'read legacy areaId-only modulars');
assert.match(source,/validateActiveSectionAssignment\(\{\.\.\.m,area:areaOf\(m\)\}/,'edit legacy areaId-only modulars');
