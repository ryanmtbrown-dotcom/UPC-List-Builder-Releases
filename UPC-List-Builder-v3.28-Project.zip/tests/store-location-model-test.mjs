/** B1.1 pure policy regression, no runtime side effects. */
import assert from 'node:assert/strict';import vm from 'node:vm';import fs from 'node:fs';
const c=vm.createContext({});vm.runInContext(fs.readFileSync('app/src/main/assets/www/store-locations/location-policy.js','utf8'),c);const p=vm.runInContext('UPCStoreLocationPolicy',c);
let a={id:'tape',name:'Tape',area:{kind:'AISLE',id:'5'},physicalSectionIds:[1,2],sourceNominalFeet:12,active:true};assert.equal(p.normalizeLocationDraft(a).sourceNominalFeet,12);assert.equal(p.validateActiveSectionAssignment({...a,id:'tools',physicalSectionIds:[2,3]},[a]).valid,false);assert.equal(p.validateActiveSectionAssignment({...a,id:'tools',physicalSectionIds:[3,4]},[a]).valid,true);assert.equal(p.validatePhysicalSectionEdit({...a,physicalSectionIds:[1]},a,[{modularId:'tape',physicalSectionId:'2'}]).valid,false);assert.throws(()=>p.normalizePlacement({skuKey:'1',origin:'ACE_IMPORT',physicalSectionId:'1'}));assert.equal(p.normalizePlacement({skuKey:'DSD01',origin:'USER_SCAN',storeAdded:true,physicalEvidence:true}).storeAdded,true,'store-added provenance must survive normalizing');assert.ok(p.formatExpandedLocation({current:{aisle:'5',areaName:'Aisle 5',modularName:'Tape',assignedSections:['1','2'],sourceSegment:'3',sourceRow:'52',sourceColumn:'4',fixtureType:'PEG',origin:'ACE_IMPORT'}}).includes('A5 · R52 · C4'));assert.equal(p.formatCompactLocation({current:{aisle:'8',resolvedSection:'2',origin:'ACE_IMPORT',fixtureType:'SPCFIX',sourceRow:'3',fixtureZone:'CL'}}),'A8 · S2 · SF · R3 · CL');assert.equal(p.formatCompactLocation({current:{aisle:'8',resolvedSection:'2',origin:'ACE_IMPORT',fixtureType:'SPCFIX',sourceRow:'3',fixtureZone:'CR'}}),'A8 · S2 · SF · R3 · CR');
console.log('Assignment and location: PASS');

// Deliberate physical overlap: exact counterpart and shared section must be recorded.
const first={id:'tape',name:'Tape',area:{kind:'AISLE',id:'8'},physicalSectionIds:['1','2'],active:true};
const second={id:'tools',name:'Tools',area:{kind:'AISLE',id:'8'},physicalSectionIds:['2','3'],active:true};
assert.equal(p.validateActiveSectionAssignment(second,[first]).valid,false,'unconfirmed overlap rejected');
const approved={...second,overlapApprovals:[{modularId:'tape',sections:['2'],confirmedAt:123456}]};
assert.equal(p.validateActiveSectionAssignment(approved,[first]).valid,true,'exact confirmed physical shared section accepted');
assert.equal(p.normalizeLocationDraft(approved).overlapApprovals[0].sections[0],'2','confirmation persists');
assert.equal(p.validateActiveSectionAssignment({...approved,physicalSectionIds:['1','2','3']},[first]).valid,false,'changed overlap invalidates old confirmation');
assert.equal(p.validateActiveSectionAssignment({...approved,overlapApprovals:[{modularId:'wrong',sections:['2']}]},[first]).valid,false,'different modular not approved');
assert.equal(p.validateActiveSectionAssignment({...approved,physicalSectionIds:['3','4'],overlapApprovals:[]},[first]).valid,true,'separate four-foot bays accepted');
const customA={id:'firstFixture',name:'Key rack',area:{kind:'CUSTOM',id:'behindCounter'},physicalSectionIds:[],fixtureId:'rack-one',active:true};
const customB={id:'secondFixture',name:'Vendors',area:{kind:'CUSTOM',id:'behindCounter'},physicalSectionIds:[],fixtureId:'rack-one',active:true};
assert.equal(p.validateActiveSectionAssignment(customB,[customA]).valid,false,'custom fixture collision rejected');
assert.equal(p.validateActiveSectionAssignment({...customB,overlapApprovals:[{modularId:'firstFixture',sections:['FIXTURE']}]},[customA]).valid,true,'intentional shared custom fixture allowed');
console.log('Specific four-foot section and exact approved overlap cases PASS');

// Aisle number survives repeated normalization (repository revalidates a normalized draft).
const roundTrip=p.normalizeLocationDraft({id:'tape',name:'Tape',active:true,area:{kind:'AISLE',id:'aisle-8',aisle:'8'},physicalSectionIds:['1','2']});
assert.equal(roundTrip.area.aisle,'8');
assert.equal(p.validateActiveSectionAssignment(roundTrip,[]).valid,true,'Repository second validation must accept aisle-stable-id references');
