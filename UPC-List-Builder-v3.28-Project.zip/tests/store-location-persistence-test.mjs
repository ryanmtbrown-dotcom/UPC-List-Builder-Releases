/** B1.2 IndexedDB facade structural/safe routing regression. */
import assert from 'node:assert/strict';import fs from 'node:fs';import vm from 'node:vm';
const src=fs.readFileSync('app/src/main/assets/www/store-locations/location-repository.js','utf8');
const db=fs.readFileSync('app/src/main/assets/www/db.js','utf8');
const backups=fs.readFileSync('app/src/main/assets/www/data-backup.js','utf8');
const html=fs.readFileSync('app/src/main/assets/www/index.html','utf8');
assert.ok(html.includes('store-locations/location-repository.js'));
for(const name of ['storeAreas','storeModulars','storeSources','storeSourceMembers','storePlacements','storeHistory','storeImportReceipts']){assert.ok(db.includes("createObjectStore('"+name+"'"));assert.ok(backups.includes("'"+name+"'"))}
assert.match(src,/index\('bySku'\)\.getAll/);assert.match(src,/index\('byUpc'\)\.getAll/);assert.match(src,/byModular/);
const fakePolicy={normalizeAreaName:()=>'',validateAreaReference:()=>({kind:'CUSTOM',id:'a'}),
 findPotentialAreaDuplicates:()=>[],normalizeLocationDraft:()=>({id:'t',area:null,physicalSectionIds:[],active:false}),
 validateActiveSectionAssignment:()=>({valid:true}),validatePhysicalSectionEdit:()=>({valid:true}),
 normalizePlacement:p=>p};
const context=vm.createContext({UPCStoreLocationPolicy:fakePolicy,UPCDB:{open:async()=>{throw Error('expected storage failure')},get:async()=>null,all:async()=>[]}});
vm.runInContext(src,context);
const repository=vm.runInContext('UPCLocationRepository',context);
assert.equal(repository.STORES.length,7);
assert.equal((await repository.bySku('')).placements.length,0);
assert.equal((await repository.byUpc('')).sourceMembers.length,0);
await assert.rejects(repository.bySku('123'),/expected storage failure/);
assert.throws(()=>repository.replacePlacements('',[]));
assert.throws(()=>repository.acceptSource({source:null,items:[],batchId:'a'}));
assert.throws(()=>repository.saveArea({id:'',kind:'CUSTOM'}));
console.log('B1.2 repository boundaries, indexed lookup and storage-failure guards PASS');
for(const op of ['removeArea','removeSections','removeModular'])assert.equal(typeof repository[op],'function');
assert.throws(()=>repository.removeArea(''),/Choose/);
assert.throws(()=>repository.removeSections('aisle-5',[]),/Choose sections/);
assert.throws(()=>repository.removeModular(''),/Choose/);
assert.match(src,/Section in use\. Remove or relocate the modular/);
assert.match(src,/sources\.put\(\{\.\.\.source,modularId:null\}\)/);
console.log('Atomic location removal repository boundary PASS');

assert.match(src,/areaListReq=areas\.getAll\(\)/,'read saved areas to resolve older areaId-only modulars');
assert.match(src,/otherLayouts=\(allReq\.result\|\|\[\]\)\.map\(materialize\)/,'enforce overlaps against legacy modulars');
assert.match(src,/validatePhysicalSectionEdit\(draft,materialize\(oldReq\.result\)/,'edit must preserve old area semantics');
